﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};

if (athoc.iws.alert) {
    athoc.iws.alert.list = function () {
        var datasource = null;
        var filter = {};
        var getChannels = true;
        var sortState = null;
        var isRepeated = false;
        var isSimpleSearch = true;
        return {
            urls: {},
            resources: {},
            gridSelector: "",
            IsRightToLeft: false,
            selectedArray: new Array(),
            viewModel: null,
            parameters: {},
            filter: {},
            originalGridOffset: {},

            loadParam: function (parameters) { 
                var self = this;

                this.urls = parameters.urls;
                this.resources = parameters.resources;
                this.gridSelector = parameters.gridSelector;
                this.parameters = parameters;

            },

            resizeGrid: function () {
                var pillContainerHeight = $('.filter-col .pill-container').height();
                if (pillContainerHeight && (pillContainerHeight > 0)) {
                    $('#alertList').css({ top: (pillContainerHeight - 10 + (this.originalGridOffset.Top - 1) + 'px') });
                    $('#alertList .k-grid-header').css({ top: pillContainerHeight - 10 + this.originalGridOffset.headerTop + 'px' });
                    $('.row-fluid .whiteout').height(pillContainerHeight - 10 + this.originalGridOffset.whiteoutHeight);

                } else {
                    $('#alertList').css("margin-top", "0");
                    $('#alertList').css({ top: (this.originalGridOffset.Top - 1) + 'px' });
                    $('#alertList .k-grid-header').css({ top: this.originalGridOffset.headerTop + 'px' });
                    $('.row-fluid .whiteout').height(this.originalGridOffset.whiteoutHeight);
                }
            },
            switchView: function (view) {
                switch (view) {
                    case "simple":
                        $("#advancedSearch").css("display", "block");
                        $("#simpleSearch").css("display", "none");
                        $("#advancedPane").css("display", "none");
                        break;
                    case "advanced":
                        $("#advancedSearch").css("display", "none");
                        $("#simpleSearch").css("display", "block");
                        $("#advancedPane").css("display", "block");
                        break;
                }
            },

            search: function () {
                var self = this;
                this.switchView("simple");
                $("#advancedSearch").on("click", $.proxy(function () {
                    this.switchView("advanced");
                }, this));
                //back to simple search
                $("#simpleSearch").on("click", $.proxy(function () {
                    this.switchView("simple");
                    $("#advancedSearch").focus();
                }, this));
                $(".pill-close").on("click", $.proxy(function (e) {
                    if (e.target.id === "quickSearchPillClose") {
                        self.viewModel.quickSearchPill(false);
                        self.viewModel.quickSearchPillText("");
                        $(self.parameters.textSearchInput).val("");
                    } else if (e.target.id === "severityPillClose") {
                        self.viewModel.severityPill(false);
                        self.viewModel.severityPillSerialized("");
                        self.viewModel.ResetToAllSeverity();
                    } else if (e.target.id === "eventTypePillClose") {
                        self.viewModel.eventTypePill(false);
                        self.viewModel.eventTypePillSerialized("");
                        self.viewModel.ResetToAllEvent();
                    } else if (e.target.id === "dateFromPillClose") {
                        self.viewModel.dateFromPill(false);
                        self.viewModel.FromDateValue(undefined);
                    } else if (e.target.id === "dateToPillClose") {
                        self.viewModel.dateToPill(false);
                        self.viewModel.ToDateValue(undefined);
                    } else if (e.target.id === "dateRangePillClose") {
                        self.viewModel.dateRangePill(false);
                        self.viewModel.ToDateValue(undefined);
                        self.viewModel.FromDateValue(undefined);
                    } else if (e.target.id === "statusPillClose") {
                        self.viewModel.statusPill(false);
                        self.viewModel.ResetToAllStatus();
                    } else if (e.target.id === "channelPillClose") {
                        self.viewModel.channelPill(false);
                        self.viewModel.ResetChannel();
                    } else if (e.target.id === "publisherPillClose") {
                        self.viewModel.publisherPill(false);
                        self.viewModel.ResetPublisher();
                    }
                    self.executeSearch();


                }, this));


            },

            setPills: function () {
                var self = this;
                var searchText = $(self.parameters.textSearchInput).val();
                if (searchText !== "") {
                    self.viewModel.canClearAll(true);
                    self.viewModel.quickSearchPill(true);
                    self.viewModel.quickSearchPillText(searchText);
                } else {
                    self.viewModel.quickSearchPill(false);
                }
                if (self.viewModel.SelectedSeverityArray().length > 0) {
                    self.viewModel.canClearAll(true);
                    self.viewModel.severityPill(true);
                    self.viewModel.severityPillSerialized(self.viewModel.SelectedSerialized(self._getSelectedNames(self.viewModel.AllSeverityArray(), self.viewModel.SelectedSeverityArray())).join(", "));
                } else {
                    self.viewModel.severityPill(false);
                }
                if (self.viewModel.SelectedEventArray().length > 0) {
                    self.viewModel.canClearAll(true);
                    self.viewModel.eventTypePill(true);
                    self.viewModel.eventTypePillSerialized(self.viewModel.SelectedSerialized(self._getSelectedNames(self.viewModel.AllEventTypesArray(), self.viewModel.SelectedEventArray())).join(", "));
                } else {
                    self.viewModel.eventTypePill(false);
                }
                if (self.viewModel.ToDateValueForServer !== "" && self.viewModel.FromDateValueForServer !== "") {
                    self.viewModel.canClearAll(true);
                    self.viewModel.dateRangePill(true);
                    self.viewModel.dateToPill(false);
                    self.viewModel.dateFromPill(false);
                } else {
                    self.viewModel.dateRangePill(false);
                    if (self.viewModel.FromDateValueForServer !== "") {
                        self.viewModel.canClearAll(true);
                        self.viewModel.dateFromPill(true);
                    } else {
                        self.viewModel.dateFromPill(false);
                    }
                    if (self.viewModel.ToDateValueForServer !== "") {
                        self.viewModel.canClearAll(true);
                        self.viewModel.dateToPill(true);
                    } else {
                        self.viewModel.dateToPill(false);
                    }
                }

                if ((self.viewModel.ChannelToFilter() !== -1) && ($.isNumeric(self.viewModel.ChannelToFilter()))) {
                    self.viewModel.canClearAll(true);
                    self.viewModel.channelPill(true);
                    self.viewModel.channelPillSerialized(self._getSelectedChannelName(self.viewModel.AllChannelsArray(), self.viewModel.ChannelToFilter()));
                } else {
                    self.viewModel.channelPill(false);
                }
                if (self.viewModel.PublisherToFilter() !== this.viewModel.defaultPublisher) {
                    self.viewModel.canClearAll(true);
                    self.viewModel.publisherPill(true);
                    self.viewModel.publisherPillText(self.viewModel.PublisherToFilter());
                } else {
                    self.viewModel.publisherPill(false);
                }
                if (self.viewModel.SelectedStatusArray().length > 0 &&
                    self.viewModel.SelectedStatusArray().length < self.viewModel.SearchableStatusArray().length &&
                    self.viewModel.SelectedStatusArray()[0] !== "-1") {
                    self.viewModel.canClearAll(true);
                    self.viewModel.statusPill(true);
                    self.viewModel.statusPillSerialized(self.viewModel.SelectedSerialized(self._getSelectedStatuses(self.viewModel.SearchableStatusArray(), self.viewModel.SelectedStatusArray())).join(", "));
                } else {
                    self.viewModel.statusPill(false);
                }
                this.switchView("simple");
            },

            _getSelectedChannelName: function (allElementArray, selectedElementId) {
                for (var i = 0; i < allElementArray.length; i++) {
                    if (allElementArray[i].Id === selectedElementId) {
                        return allElementArray[i].Name;
                    }
                }
            },

            _getSelectedNames: function (allElementArray, selectedArray) {
                var selectedNames = ko.observableArray();
                for (var i = 0; i < selectedArray.length; i++) {
                    for (var j = 0; j < allElementArray.length; j++) {
                        if (selectedArray[i] === allElementArray[j].Id) {
                            selectedNames.push(allElementArray[j].Name);
                            break;
                        }
                    }
                }
                return selectedNames;
            },

            _getSelectedStatuses: function (allElementArray, selectedArray) {
                var selectedStatuses = ko.observableArray();
                for (var i = 0; i < selectedArray.length; i++) {
                    for (var j = 0; j < allElementArray.length; j++) {
                        if (selectedArray[i] === allElementArray[j].id) {
                            selectedStatuses.push(allElementArray[j].label);
                            break;
                        }
                    }
                }
                return selectedStatuses;
            },

            load: function () {
                var self = this;

                self.search();

                athoc.iws.alert.action = '';
                athoc.iws.alert.source = '';

                this.bindActionButtons();

                var url = this.urls.GetAlertListUrl;

                var initialStatusFilterArray = [];
                if (this.parameters.initialFilter.length != "") { //need status filter initially
                    initialStatusFilterArray = this.parameters.initialFilter.split(',');
                }

                this.viewModel = new this.listViewModel(this, initialStatusFilterArray);
                self.setFilter({ StatusFilter: self.viewModel.SelectedSerialized(self.viewModel.SelectedStatusArray) });

                ko.applyBindings(this.viewModel, $(this.parameters.koBoundListSelector).get(0));
                ko.applyBindings(this.viewModel, $(this.parameters.koBoundNavigationSelector).get(0));

                this.fillChannelDropdown();
                this.fillPublisherDropdown();
                this.fillEventTypeDropdown();
                this.fillSeverityDropdown();


                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, filter);
                            //$.extend(options, { "StatusFilter": ["Live"] });
                            options.getChannels = getChannels;

                            var newState = JSON.stringify(options.sort);
                            if ((sortState) && newState != sortState) {
                                sortState = newState;
                                isRepeated = true;
                                options.page = 1;
                                options.skip = 0;
                                datasource.page(1);
                            }
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                        //isRepeated flag is to save duplicate calls to 
                        //server during sorting
                        if (isRepeated) {
                            e.preventDefault();
                            isRepeated = false;
                        }
                    },
                    requestEnd: function (e) {
                        sortState = JSON.stringify(e.sender._sort);
                        if (e.response) {
                            //add IsChecked property to the data
                            _.each(e.response.Data, function (item, index) {
                                item.IsChecked = self.viewModel.IsSelected(item.AlertId);
                            });
                            $.AjaxLoader.hideLoader();
                        }
                        self.resizeGrid();
                        //remove page info from filter
                        delete filter.page;
                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                    },
                    serverPaging: true,
                    serverSorting: true,
                    serverFiltering: true,
                    sort: { field: "StartTime", dir: "desc" },
                    pageSize: 50,
                    error: function (e) {
                        var errorCallBack = function (returnedErrorObject) {
                            $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());;
                        };
                        AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);

                    }
                });

                $("#pageInfo").kendoPager({
                    dataSource: datasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: this.resources.Alert_List_PageInfo,
                        empty: this.resources.Alert_List_PageInfo_NoRecords
                    }
                });

                var grid = $(this.gridSelector).kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    resizable: true,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Summary),
                                empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Items_Per_Page),
                                first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                                next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        },
                    },
                    columns:
                            [
                                {
                                    field: "AlertId",
                                    hidden: true
                                },
                                {
                                    field: "IsChecked",
                                    template: $("#alert-checkbox-template").html(),
                                    width: 25,
                                    headerTemplate: kendo.format('<input type="checkbox" class="senario-select" id="alert-select-all" title="{0}" tabindex="240" />', this.resources.Alert_List_SelectAll),
                                    sortable: false,
                                    headerAttributes: {
                                        style: "cursor: default",
                                    }
                                },
                                {
                                    field: "Title",
                                    title: this.resources.Alert_List_Title,
                                    width: 175, 
                                    headerAttributes: {
                                        tabindex: "240",
                                        title: this.resources.Alert_List_Title,
                                    }

                                },
                                {
                                    field: "Status",
                                    title: $.htmlDecode(this.resources.Alert_List_Status),
                                    template: '<span title="#=StatusLabel#">#=StatusLabel#</span>',
                                    width: 80,
                                    headerAttributes: {
                                        tabindex: "240"
                                    }
                                },
                                {
                                    field: "StartTime",
                                    title: $.htmlDecode(this.resources.Alert_List_Start_Time),
                                    template: '<span class="cellTooltip" title="#=StartTimeDisplayString#">#=StartTimeDisplayString#</span>',
                                    width: 140,
                                    headerAttributes: {
                                        tabindex: "240"
                                    }
                                },
                                {
                                    field: "Publisher",
                                    title: $.htmlDecode(this.resources.Alert_List_Publisher),
                                    template: '<span title="#=Publisher#">#=Publisher#</span>',
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', $.htmlDecode(this.resources.Alert_List_Publisher), $.htmlDecode(this.resources.Alert_List_Publisher)),
                                    width: 100,
                                    headerAttributes: {
                                        tabindex: "240"
                                    }
                                },
                                {
                                    field: "Targeted",
                                    title: $.htmlDecode(this.resources.Alert_List_Targeted),
                                    width: 60,
                                    template: $("#alert-targeted-column-template").html(),
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', $.htmlDecode(this.resources.Alert_List_Targeted), $.htmlDecode(this.resources.Alert_List_Targeted)),
                                    sortable: false,
                                    attributes: {
                                        "class": "align-right"
                                    },
                                    headerAttributes: {
                                        style: "cursor: default"
                                    }
                                },
                                {
                                    field: "Sent",
                                    title: $.htmlDecode(this.resources.Alert_List_Sent),
                                    width: 60,
                                    template: $("#alert-sent-column-template").html(),
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', $.htmlDecode(this.resources.Alert_List_Sent), $.htmlDecode(this.resources.Alert_List_Sent)),
                                    sortable: false,
                                    attributes: {
                                        "class": "align-right"
                                    },
                                    headerAttributes: {
                                        style: "cursor: default"
                                    }
                                },
                                {
                                    field: "Responded",
                                    title:$.htmlDecode( this.resources.Alert_List_Responded),
                                    template: $("#alert-responded-column-template").html(),
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', $.htmlDecode(this.resources.Alert_List_Responded), $.htmlDecode(this.resources.Alert_List_Responded)),
                                    width: 70,
                                    sortable: false,
                                    attributes: {
                                        "class": "align-right"
                                    },
                                    headerAttributes: {
                                        style: "cursor: default"
                                    }
                                },
                                {
                                    field: "Error",
                                    title:$.htmlDecode( this.resources.Alert_List_Error),
                                    template: $("#alert-error-column-template").html(),
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', $.htmlDecode(this.resources.Alert_List_Error), $.htmlDecode(this.resources.Alert_List_Error)),
                                    width: 40,
                                    sortable: false,
                                    headerAttributes: {
                                        style: "cursor: default"
                                    }
                                }
                            ],
                    columnResize: function (e) { 
                        $("#alertList .k-grid-header table").css("width", "100%");
                        $("#alertList .k-grid-content table").css("width", "100%");
                    },
                    dataBound: this.OnDataBound
                }).data().kendoGrid;

                var lastMouseX;
                var $template = kendo.template($("#alert-tooltip-template").html());
                var alertListTooltip = $("#alertList").kendoTooltip({
                    filter: "td:nth-child(3)",
                    position: "right",
                    show: function () {
                        $(this.popup.wrapper).css({
                            left: lastMouseX + 60
                        });                       
                    },
                    content: function (e) {
                        e.sender.content.parent().addClass('alert-list-tooltip');
                        var dataItem = $("#alertList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },
                    animation: false
                }).on('mouseout', function (e) {
                    alertListTooltip.data('kendoTooltip').hide();
                });

                $(document).on("mousemove", function (e) {
                    lastMouseX = e.pageX;                    
                    $(".alert-list-tooltip").parent().css({
                        left: lastMouseX + 60
                    });
                });

                this.refreshGrid();
                this.bindSelectAll();

                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");


                athoc.kendoGrid.utils.setStickyHeader();

                this.viewModel.SearchDisabled(true);
                this.viewModel.canClearAll(false);

                //this.originalGridOffset.Top = $('#alertList').offset().top;
                this.originalGridOffset.Top = $('#alertList').position().top;

                //this.originalGridOffset.headerTop = $('#alertList .k-grid-header').offset().top;
                this.originalGridOffset.headerTop = $('#alertList .k-grid-header').position().top;

                this.originalGridOffset.whiteoutHeight = $('.row-fluid .whiteout').height();

            },


            refreshGrid: function () {
                //show the loader when we make a request to the server...
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.wrap-all'), imageURL: this.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: this.resources.General_LoadingMessage }).showLoader();
                datasource.page(1);
                $('#alertList').css("margin-top", "21px");
            },

            OnDataBound: function (e) {

                $("html,body").scrollTop(0);
                athoc.iws.alert.list.bindOneCheckboxClick();
                athoc.iws.alert.list.checkAndSelectAll(); //check all if necessary



                $(athoc.iws.alert.list.gridSelector + " tbody").find("tr").attr("tabindex", "0");

                var grid = $(athoc.iws.alert.list.gridSelector).data("kendoGrid");
                var data = grid.dataSource.data();

                $(grid.tbody).unbind("click");

                $(grid.tbody).on("click", "td", function (event) {
                    var row = $(this).closest("tr");
                    var rowIdx = $("tr", grid.tbody).index(row);
                    var model = data[rowIdx];
                    var colIdx = $("td", row).index(this);
                    if (colIdx != 1) {
                        athoc.iws.alert.list.viewAlertDetail(model);
                    }
                });

                if (athoc.iws.alert.list.IsRightToLeft) {
                    $(this.gridSelector).find('.pull-right').addClass('pull-left');
                    $(this.gridSelector).find('.pull-right').removeClass('pull-right');
                }
            },

            bindSelectAll: function () {
                var self = this;
                $("#alert-select-all").change(function () {
                    var checked = $(this).is(':checked');
                    var grid = $(self.gridSelector).data().kendoGrid;
                    //dataSource.view() returns the page not the entire dataset.
                    if ($(this).is(':checked')) {
                        var array = grid.dataSource.data().toJSON();
                        self.viewModel.AddSelected(array);
                    } else {
                        var idsToDelete = grid.dataSource.data().map(function (val) { return val.AlertId; });
                        self.viewModel.RemoveSelected(idsToDelete);
                    }
                    $(".each-alert-select").prop('checked', $(this).is(':checked'));
                });
            },

            bindOneCheckboxClick: function () {
                var self = this;
                var grid = $(this.gridSelector).data("kendoGrid");
                $('.each-alert-select').on('click', function () {
                    var data = grid.dataSource.data();
                    var row = $(this).closest("tr");
                    var rowIdx = $("tr", grid.tbody).index(row);
                    var model = data[rowIdx];

                    if ($(this).is(':checked')) {
                        self.viewModel.AddSelected(new Array(model.toJSON()));
                        self.checkAndSelectAll();
                    } else {
                        self.viewModel.RemoveSelected([model.AlertId]);
                        $("#alert-select-all").prop('checked', false);
                    }
                });
            },

            checkAndSelectAll: function () {
                var checkboxes = $(this.gridSelector + " tbody").find("[type='checkbox']");
                if (checkboxes.length != 0) //if list is empty don't checkall
                {
                    var checkedCheckboxes = $(this.gridSelector + " tbody").find("input:checked");
                    if (checkedCheckboxes.length == checkboxes.length) {
                        $("#alert-select-all").prop('checked', true);
                    } else {
                        $("#alert-select-all").prop('checked', false);
                    }
                }
            },

            bindActionButtons: function () {
                var self = this;
                //new button
                $(this.parameters.newButtonSelector).on('click', function () {
                    window.location = self.parameters.urls.ScenarioPublisherUrl;
                });

                //edit button
                $(this.parameters.editButtonSelector).on('click', function () {
                    if (!self.viewModel.EditDisabled()) {
                        var alert = self.viewModel.GetSelectedAlertsArray()[0];
                        if (alert.Status == "Live") {
                            athoc.iws.publishing.createRequest("/athoc-iws/alertmanager?nav=v&id=" + alert.AlertId);                         
                        }

                        $(".alert-nav").hide();
                        $(".edit-alert").show();
                        navigateToPage('alertDetail', function () { });
                        athoc.iws.alert.detail.editAlert(alert.AlertId);
                        var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                        breadcrumbsModel.SelectedPage('alertDetail');
                        $.titleCrumb("pageBreadcrumbs");
                        $(document).scrollTop(0);
                        $.AjaxLoader.hideLoader();
                    }
                });

                //edit button
                $(this.parameters.publishButtonSelector).on('click', function () {
                    if (!self.viewModel.PublishDisabled()) {
                        athoc.iws.publishing.view.PublishAlert(self.viewModel.GetSelectedIdsArray()[0]);
                        athoc.iws.publishing.view.OnCloseAfterPublish = function () {
                            athoc.iws.alert.list.viewModel.ClearSelectedArray();
                            athoc.iws.alert.list.refreshGrid();
                            $('#dialogReviewAndPublish').modal('hide');
                        };
                    }
                });

                $(this.parameters.duplicateButtonSelector).on('click', function () {
                    if (!self.viewModel.DuplicateDisabled()) {
                        $(".alert-nav").hide();
                        $(".new-alert").show();

                        navigateToPage('alertDetail', function () { });
                        athoc.iws.alert.detail.duplicateAlert(self.viewModel.GetSelectedIdsArray()[0]);

                        var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                        breadcrumbsModel.SelectedPage('alertDuplicate');
                        $.titleCrumb("pageBreadcrumbs");
                        $(document).scrollTop(0);

                        $.AjaxLoader.hideLoader();
                    }
                });

                $(this.parameters.searchButtonSelector).on('click', function () {
                    if (!self.viewModel.SearchDisabled()) {
                        self.executeSearch();
                        self.setPills();
                    }
                });

                $(this.parameters.textSearchInput).keypress(function (e) {
                    self.viewModel.SearchDisabled(false);
                    self.viewModel.canClearAll(true);
                    if (e.which == 13) {
                        if (!self.viewModel.SearchDisabled()) {
                            self.executeSearch();
                            self.setPills();
                        }
                    }
                });

                $(this.parameters.toDateInput + "," + this.parameters.fromDateInput).keypress(function (e) {
                    self.viewModel.SearchDisabled(false);
                    self.viewModel.canClearAll(true);
                });

                $(this.parameters.textSearchInput).on('input', function (e) {
                    if ($('#textSearchInput').val() != "") {
                        self.viewModel.SearchDisabled(false);
                        self.viewModel.canClearAll(true);
                    }

                });

                $(this.parameters.btnClearAll).on('click', function (e) {
                    $(self.parameters.textSearchInput).val("");
                    self.viewModel.ResetToAllStatus();
                    self.viewModel.ResetChannel();
                    self.viewModel.ResetPublisher();
                    self.viewModel.ResetToAllSeverity();
                    self.viewModel.ResetToAllEvent();
                    self.viewModel.ToDateValue(undefined);
                    self.viewModel.FromDateValue(undefined);
                    self.viewModel.SearchDisabled(true);
                    self.viewModel.canClearAll(false);
                    self.viewModel.quickSearchPill(false);
                    self.viewModel.quickSearchPillText("");

                    self.viewModel.severityPill(false);
                    self.viewModel.severityPillSerialized("");

                    self.viewModel.eventTypePill(false);
                    self.viewModel.eventTypePillSerialized("");

                    self.viewModel.dateFromPill(false);
                    self.viewModel.dateToPill(false);
                    self.viewModel.dateRangePill(false);
                    self.viewModel.statusPill(false);
                    self.viewModel.channelPill(false);
                    self.viewModel.publisherPill(false);

                    self.executeSearch();
                });

                var actionSuccessCallback = function (data, textStatus, jqXHR) {
                    if (data.Success) {
                        self.refreshGrid();
                        //wipe out selections
                        self.viewModel.ClearSelectedArray();
                    }
                }

                $(this.parameters.deleteButtonSelector).on('click', function () {
                    if (!self.viewModel.DeleteDisabled()) {
                        self.parameters.alertActionFunction("delete", self.viewModel.GetSelectedAlertsArray(), actionSuccessCallback);
                    }
                });

                $(this.parameters.endButtonSelector).on('click', function () {
                    if (!self.viewModel.EndDisabled()) {
                        self.parameters.alertActionFunction("end", self.viewModel.GetSelectedAlertsArray(), actionSuccessCallback);
                    }
                });


            },
            executeSearch: function () {
                var self = this;
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: self.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: self.resources.General_LoadingMessage }).showLoader();

                //if "any publisher" is selected, send empty string to server for publisher
                var publisher = self.viewModel.PublisherToFilter();
                if ($(self.parameters.publisherDropDown).find("option").first().is(":selected")) {
                    publisher = "";
                }

                var from = new Date(self.viewModel.FromDateValueForServer);
                var to = new Date(self.viewModel.ToDateValueForServer);

                if (from > to) {
                    self.viewModel.FromDateValue(to);
                    $("#fromDatePicker").data("datetimepicker").setDate(to);
                }

                self.setFilter({
                    page: 1,
                    StatusFilter: self.viewModel.SelectedSerialized(self.viewModel.SelectedStatusArray),
                    SearchText: $(self.parameters.textSearchInput).val(), //binding to knockout model didn't work on IE9 with keypress, thus getting value using jq
                    FromDateString: self.viewModel.FromDateValueForServer,
                    ToDateString: self.viewModel.ToDateValueForServer,
                    ChannelId: self.viewModel.ChannelToFilter(),
                    Publisher: publisher,
                    Severities: self.viewModel.SelectedSerialized(self.viewModel.SelectedSeverityArray),
                    Events: self.viewModel.SelectedSerialized(self.viewModel.SelectedEventArray)
                });

                datasource.page(1);
                self.viewModel.ClearSelectedArray();
                $("#alert-select-all").prop('checked', false);

            },
            setFilter: function (filterOptions) {
                filter = filterOptions;
            },

            //refresh on load
            refreshOnLoad: false,

            viewAlertList: function (refresh) {
                athoc.iws.alert.action = '';
                athoc.iws.alert.source = '';

                var isModified = athoc.iws.publishing.detail.isChanged();

                if (isModified == true) {
                    var confirmLeave = confirm(athoc.iws.publishing.resources.Unsaved_Data_Text);
                    if (!confirmLeave) {
                        return;
                    } else {
                        athoc.iws.publishing.targetUsers.resetTargetingInfo();
                    }
                } else {
                    athoc.iws.publishing.targetUsers.resetTargetingInfo();
                }

                $("#btn_review_and_publish_tooltip").hide();
                athoc.iws.publishing.detail.setChanged(false);

                navigateToPage('alertList', function () { });
                var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                breadcrumbsModel.SelectedPage('alertList');
                $(document).scrollTop(0);

                //create grid if not pre-created
                if (!$(this.gridSelector).hasClass('k-grid')) {
                    athoc.iws.alert.list.load();
                }
                else if ((refresh != undefined && refresh) || athoc.iws.alert.list.refreshOnLoad) {
                    athoc.iws.alert.list.viewModel.ClearSelectedArray();
                    athoc.iws.alert.list.refreshGrid();
                }
                athoc.iws.alert.list.refreshOnLoad = false;

            },

            viewAlertDetail: function (selectedObj) {
                athoc.iws.alert.list.refreshOnLoad = false;

                if (selectedObj.Status == "Live" || selectedObj.Status == "Ended" || selectedObj.Status == "Publishing"){
                    window.location = kendo.format("/athoc-iws/AlertManager/ReportView?id={0}", selectedObj.AlertId);
                } 
                else if (athoc.iws.alert.IsAlertPublisher == 'False') {
                    window.location = "/client/alertmanager/Summary/" + selectedObj.AlertId;
                }
                else {
                    $(".alert-nav").hide();
                    $(".edit-alert").show();

                    navigateToPage('alertDetail', function () { });
                    athoc.iws.alert.detail.editAlert(selectedObj.AlertId);

                    var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                    breadcrumbsModel.SelectedPage('alertDetail');
                    $.titleCrumb("pageBreadcrumbs");
                    $(document).scrollTop(0);

                    $.AjaxLoader.hideLoader();
                }
            },

            createAlertFromScenairo: function (id) {
                $(".alert-nav").hide();
                $(".new-alert").show();

                navigateToPage('alertDetail', function () { });
                athoc.iws.alert.detail.createAlertFromScenario(id);

                var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;

                if (athoc.iws.alert.source == "event") {
                    breadcrumbsModel.SelectedPage('alertForward');
                } else {
                    breadcrumbsModel.SelectedPage('alertCreate');
                }

                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);

                $.AjaxLoader.hideLoader();
            },
            createAlertFromRbt: function (id, rbtdetails) {
                $(".alert-nav").hide();
                $(".new-alert").show();

                navigateToPage('alertDetail', function () { });
                athoc.iws.alert.detail.createAlertFromRbt(id, rbtdetails);

                var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;

                if (athoc.iws.alert.source == "event") {
                    breadcrumbsModel.SelectedPage('alertForward');
                } else {
                    breadcrumbsModel.SelectedPage('alertCreate');
                }

                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);

                $.AjaxLoader.hideLoader();
            },
            viewAlertSummary: function (id) {
                $(".alert-nav").hide();
                $(".new-alert").show();

                navigateToPage('alertView', function () { });
                athoc.iws.alert.detail.viewAlert(id);

                var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                breadcrumbsModel.SelectedPage('alertDetail');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);

                $.AjaxLoader.hideLoader();
            },

            fillSeverityDropdown: function () {
                var self = this;
                var myAjaxOptions = {
                    url: this.urls.GetSeverityUrl,
                    cache: false
                };
                var successFunction = function (data) {
                    _.each(data, function (item) {
                        self.viewModel.AllSeverityArray.push(item);
                    });
                }
                var ajaxOptions = $.extend({}, AjaxUtility(null, successFunction).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
            },


            fillEventTypeDropdown: function () {
                var self = this;
                var myAjaxOptions = {
                    url: this.urls.GetEventtypeUrl,
                    cache: false
                };
                var successFunction = function (data) {
                    _.each(data, function (item) {
                        self.viewModel.AllEventTypesArray.push(item);
                    });
                }
                var ajaxOptions = $.extend({}, AjaxUtility(null, successFunction).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
            },


            fillChannelDropdown: function () {
                var self = this;
                var myAjaxOptions = {
                    url: this.urls.GetChannelsUrl,
                    cache: false
                };

                var successFunction = function (data) {
                    _.each(data, function (item) {
                        self.viewModel.AllChannelsArray.push(item);
                    });

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, successFunction).ajaxPostOptions, myAjaxOptions);

                $.ajax(ajaxOptions);
            },
            fillPublisherDropdown: function () {

                var self = this;

                $(self.parameters.publisherDropDown).prop('disabled', true).selectpicker('refresh');


                var myAjaxOptions = {
                    url: this.urls.GetPublishersUrl,
                    cache: false
                };

                var successFunction = function (data) {
                    _.each(data.Messages, function (item) {
                        self.viewModel.AllPublishersArray.push({ Name: item, id: 1 });
                    });
                    $(self.parameters.publisherDropDown).prop('disabled', false).selectpicker('refresh');
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, successFunction).ajaxPostOptions, myAjaxOptions);

                $.ajax(ajaxOptions);
            },
            listViewModel: function (creatorReference, intialStatusArray) { //vm for ko binding
                var self = this;

                /*Search related */
                this.quickSearchPill = ko.observable(false);
                this.quickSearchPillText = ko.observable();

                this.severityPill = ko.observable(false);
                this.severityPillSerialized = ko.observable();

                this.eventTypePill = ko.observable(false);
                this.eventTypePillSerialized = ko.observable();
                this.dateFromPill = ko.observable(false);
                this.dateToPill = ko.observable(false);

                this.statusPill = ko.observable(false);
                this.statusPillSerialized = ko.observable();
                this.channelPill = ko.observable(false);
                this.channelPillSerialized = ko.observable();
                this.publisherPill = ko.observable(false);
                this.publisherPillText = ko.observable();
                this.defaultPublisher = creatorReference.resources.Alert_List_Any_Publisher;
                this.dateRangePill = ko.observable(false);

                /*---------------*/

                this.SearchDisabled = ko.observable(true);
                this.canClearAll = ko.observable(false);
                this.SelectedArray = ko.observableArray();
                this.SearchableStatusArray = athoc.iws.publishing.settings.IsSchedulingSupported
                ? ko.observableArray([{ id: "Ended", label: creatorReference.resources.Alert_Status_Ended }, { id: "Draft", label: creatorReference.resources.Alert_Status_Standby }, { id: "Scheduled", label: creatorReference.resources.Alert_Status_Scheduled }, { id: "Live", label: creatorReference.resources.Alert_Status_Live }])
                : ko.observableArray([{ id: "Ended", label: creatorReference.resources.Alert_Status_Ended }, { id: "Draft", label: creatorReference.resources.Alert_Status_Standby }, { id: "Live", label: creatorReference.resources.Alert_Status_Live }]);

                if (intialStatusArray.length == 0) { //no filter, then select all. 
                    intialStatusArray = ko.toJS(this.SearchableStatusArray()).map(function (item) { return item.id; });
                }
                this.SelectedStatusArray = ko.observableArray(intialStatusArray);
                this.SelectedStatusArray.subscribe(function (newValue) {
                    self.SearchDisabled(false);
                    self.canClearAll(true);
                    if (newValue.length == 0) { //select all status
                        self.SelectedStatusArray.push("-1");//when no status is selected, add a bogus value to cause the alert API to return nothing
                    }
                });

                this.ResetToAllStatus = function () {
                    self.SelectedStatusArray(ko.toJS(self.SearchableStatusArray()).map(function (item) { return item.id; }));
                };

                this.SelectedSerialized = function (selectedArray) {
                    return ko.toJS(selectedArray);
                };

                this.AllEventTypesArray = ko.observableArray();
                this.AllSeverityArray = ko.observableArray();
                this.SelectedSeverityArray = ko.observable(ko.toJS(self.AllSeverityArray()).map(function (item) { return item.id; }));
                this.SelectedSeverityArray.subscribe(function (newValue) {
                    self.SearchDisabled(false);
                    self.canClearAll(true);
                });
                this.SelectedEventArray = ko.observable(ko.toJS(self.AllEventTypesArray()).map(function (item) { return item.id; }));
                this.SelectedEventArray.subscribe(function (newValue) {
                    self.SearchDisabled(false);
                    self.canClearAll(true);
                });
                this.ResetToAllSeverity = function () {
                    self.SelectedSeverityArray([]);
                }
                this.ResetToAllEvent = function () {
                    self.SelectedEventArray([]);
                }

                //channel dd
                this.ChannelToFilter = ko.observable(creatorReference.resources.Alert_List_All_Channels);
                this.ChannelToFilter.subscribe(function (newValue) {
                    self.SearchDisabled(false);
                    self.canClearAll(true);
                });
                this.AllChannelsArray = ko.observableArray([{ Id: -1, Name: creatorReference.resources.Alert_List_All_Channels }]);
                this.ResetChannel = function () {
                    $(creatorReference.parameters.channelFilter).val(-1).change();
                    this.ChannelToFilter(-1);
                }
                this.AllPublishersArray = ko.observableArray([{ Name: creatorReference.resources.Alert_List_Any_Publisher }]);

                //operator dd
                this.PublisherToFilter = ko.observable();
                this.PublisherToFilter.subscribe(function (newValue) {
                    self.SearchDisabled(false);
                    self.canClearAll(true);
                });
                this.ResetPublisher = function () {
                    $(creatorReference.parameters.publisherDropDown).val(creatorReference.resources.Alert_List_Any_Publisher).change();
                    this.PublisherToFilter(creatorReference.resources.Alert_List_Any_Publisher);
                }



                this.AddSelected = function (newSelectedArray) {
                    var self = this;
                    _.each(newSelectedArray, function (itemToAdd, index) {
                        var found = _.find(self.SelectedArray(), function (item) {
                            return (item.AlertId == itemToAdd.AlertId);
                        });
                        if (!found) {
                            self.SelectedArray.push(itemToAdd);
                        }
                    });
                };
                this.RemoveSelected = function (idsToRemove) {
                    var tempArray = ko.toJS(this.SelectedArray()); //copy array so count gets updated in UI only after array cleanup is done

                    for (i = 0; i < tempArray.length; i++) {
                        var index = idsToRemove.indexOf(tempArray[i].AlertId);
                        if (index > -1) {
                            //remove item from idsToRemove
                            idsToRemove.splice(index, 1);
                            //remove item from selected array
                            tempArray.splice(i, 1);
                            i--;
                        }
                        if (idsToRemove.length == 0) {
                            break;
                        }
                    }
                    this.SelectedArray(tempArray);
                };
                this.SelectedCount = ko.computed(function () {
                    return this.SelectedArray().length;
                }, this);
                this.IsSelected = function (alertId) {
                    var bl = false;
                    _.each(this.SelectedArray(), function (item, index) {
                        if (item.AlertId == alertId) {
                            bl = true;
                        }
                    });
                    return bl;
                };
                this.DuplicateDisabled = ko.computed(function () {
                    if (this.SelectedArray().length == 0 || this.SelectedArray().length > 1)
                        return true;
                    if (this.SelectedArray()[0].CanDuplicate) {
                        return false;
                    }
                    return true;
                }, this);
                this.EditDisabled = ko.computed(function () {
                    if (this.SelectedArray().length == 0 || this.SelectedArray().length > 1)
                        return true;
                    if (this.SelectedArray()[0].CanEdit) {
                        return false;
                    }
                    return true;
                }, this);
                this.PublishDisabled = ko.computed(function () {
                    if (this.SelectedArray().length == 0 || this.SelectedArray().length > 1)
                        return true;
                    if (this.SelectedArray()[0].CanPublish) {
                        return false;
                    }
                    return true;
                }, this);
                this.DeleteDisabled = ko.computed(function () {
                    if (this.SelectedArray().length == 0)
                        return true;
                    var found = _.find(this.SelectedArray(), function (item) {
                        return (!item.CanDelete);
                    });

                    if (!found) { //undeletable items don't exist, can enable button!
                        return false;
                    }
                    return true;
                }, this);
                this.EndDisabled = ko.computed(function () {
                    if (this.SelectedArray().length == 0)
                        return true;
                    var found = _.find(this.SelectedArray(), function (item) {
                        return (!item.CanEnd);
                    });

                    if (!found) { //undeletable items don't exist, can enable button!
                        return false;
                    }
                    return true;

                }, this);

                this.GetSelectedIdsArray = function () {
                    return this.SelectedArray().map(function (item) { return item.AlertId; });
                },
                this.GetSelectedNamesArray = function () {
                    return this.SelectedArray().map(function (item) { return item.Title; });
                },
                this.GetSelectedAlertsArray = function () {
                    return this.SelectedArray();
                }
                this.ClearSelectedArray = function () {
                    this.SelectedArray([]);
                }
                //date & datetime
                this.FromDateValueForServer = "";
                this.PreviousFromDateValue = "";

                this.FromDateValue = ko.observable();
                this.FromDateValue.subscribe(function (newValue) {

                    self.SearchDisabled(false);
                    self.canClearAll(true);

                    if (newValue == null || newValue.length == 0) {
                        $(creatorReference.parameters.toDatePicker).data("datetimepicker").setStartDate(-Infinity);
                        self.FromDateValueForServer = "";
                    } else if (typeof newValue == "string") { //ingore if not dateTime object
                        return;
                    } else {
                        var newDate = moment(newValue);
                        if (newDate.isValid()) {
                            var newDate = moment(newValue).format("M/D/YYYY");
                            self.FromDateValueForServer = newDate;
                            $(creatorReference.parameters.toDatePicker).data("datetimepicker").setStartDate(newValue);

                            //need to convert to datetime object for accurate comparison.
                            var todate = new Date(self.ToDateValue());
                            //when input is typed in and is invalid (from is after to date and vice versa), copy that value. 
                            if (todate < newValue) {
                                self.ToDateValue(newValue);
                                $(creatorReference.parameters.toDatePicker).data("datetimepicker").setDate(newValue);
                            }
                        } else {
                            $(creatorReference.parameters.toDatePicker).data("datetimepicker").setStartDate(-Infinity);
                            self.FromDateValueForServer = "";
                        }
                    }

                });
                this.ToDateValueForServer = "";
                this.PreviousToDateValue = "";
                this.ToDateValue = ko.observable();


                this.ToDateValue.subscribe(function (newValue) {

                    self.SearchDisabled(false);
                    self.canClearAll(true);

                    if (newValue == null || newValue.length == 0) {
                        $(creatorReference.parameters.fromDatePicker).data("datetimepicker").setEndDate(Infinity);
                        self.ToDateValueForServer = "";
                    } else if (typeof newValue == "string") { //ingore if not dateTime object
                        return;
                    } else {
                        var newDate = moment(newValue);
                        if (newDate.isValid()) {

                            var newDate = moment(newValue).format("M/D/YYYY");

                            self.ToDateValueForServer = newDate;
                            $(creatorReference.parameters.fromDatePicker).data("datetimepicker").setEndDate(newValue);

                            //need to convert to datetime object for accurate comparison.
                            var fromdate = new Date(self.FromDateValue());
                            //when input is typed in and is invalid (from is after to date and vice versa), copy that value. 
                            if (fromdate > newValue) {
                                self.FromDateValue(newValue);
                                $(creatorReference.parameters.fromDatePicker).data("datetimepicker").setDate(newValue);
                            }
                        } else {
                            $(creatorReference.parameters.fromDatePicker).data("datetimepicker").setEndDate(Infinity);
                            self.ToDateValueForServer = ""; 
                        }
                    }


                });

                this.DateRange = ko.computed(function () {
                    var dateRangeText = "";
                    if (self.FromDateValue() && self.ToDateValue()) {
                        dateRangeText = moment(self.FromDateValue()).format(dateformat.toUpperCase()) + " - " +
                            moment(self.ToDateValue()).format(dateformat.toUpperCase());
                    }
                    return dateRangeText;
                });

            }
        };
    }();
}