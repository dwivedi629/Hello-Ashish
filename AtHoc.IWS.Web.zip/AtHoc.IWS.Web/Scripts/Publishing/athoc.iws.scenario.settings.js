﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.scenario = athoc.iws.scenario || {};

if (athoc.iws.scenario) {
    athoc.iws.scenario.settings = function () {
        return {
            isChanged: false,
            IsRightToLeft: false,
            bindflag: true,
            selectedCount: 0,
            enabledDevices: [],
            errorflag: false,
            isFillCountEnabled: false,
            viewModel: {
                scenariosettingstmp: ko.observableArray(),
                scenariosettings: ko.observableArray(),
            },
            officerVM: kendo.observable(
            {
                IsAccountabilityOfficerMessagesVisible: true,
                Visible: true,
                Collapsed: false,
                Readonly: false,
            }),
            ReadonlyViewModel:
            {
                applysettings: [],
            },
            load: function () {
                //To open scenario settings popup
                $("#btn_scenariosettings").click(function () {
                    athoc.iws.scenario.settings.bindflag = false;
                    $("#ScenarioSettings").show();
                    $("#backshade").show();
                    athoc.iws.scenario.settings.resizeModalBasedOnScreen($("#ScenarioSettings"));
                    $('.finger-tab.scenario-content').click();
                });
                //To save scenario setting details
                $("#btn_SettingsSave").click(function () {
                    athoc.iws.scenario.settings.saveUserSettings();
                    if (!athoc.iws.scenario.settings.errorflag)
                        $("#backshade").hide();
                    athoc.iws.scenario.settings.bindflag = true;
                });

                //To redirect to Scenario Page
                $("#btn_SettingsCancel").click(function () {
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp = ko.mapping.fromJS(athoc.iws.scenario.settings.viewModel.scenariosettings);
                    athoc.iws.scenario.settings.bindflag = true;
                    ko.cleanNode($("#ContentSettings").get(0));
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#ContentSettings").get(0));

                    ko.cleanNode($("#UserSettings").get(0));
                    $("#personaldevicesdisplaysettings").html("");
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#UserSettings").get(0));

                    if ($("#DevicesSettings").length > 0) {
                        ko.cleanNode($("#DevicesSettings").get(0));
                        $("#massdevicesdisplaysettings").html("");
                        ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#DevicesSettings").get(0));
                    }
                    if ($("#ScheduleSettings").length > 0) {
                        ko.cleanNode($("#ScheduleSettings").get(0));
                        ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#ScheduleSettings").get(0));
                    }

                    if ($("#OrganizationSettings").length > 0) {
                        ko.cleanNode($("#OrganizationSettings").get(0));
                        ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#OrganizationSettings").get(0));
                    }

                    if (athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization && !(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByAreaEnabled()))
                        ($("#chkEnableTargByArea")[0].checked) = false;

                    $("#ScenarioSettings").hide();
                    $("#backshade").hide();
                });
                /*START finger tabs*/
                $('.finger-tab.scenario-content').click(function () {
                    $('.finger-tab').removeClass('selected');
                    $('.finger-tab.scenario-content').addClass('selected');
                    $('#scenarioUsers,  #scenarioOrganization, #scenarioDevices, #scheduleSettings, #userWorkflow, #officerWorkflow').hide();
                    $('#scenarioContent').show();
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp = ko.mapping.fromJS(athoc.iws.scenario.settings.viewModel.scenariosettings);
                    if (!(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByAreaEnabled()))
                        ($("#chkEnableTargByArea")[0].checked) = false;
                });
                $('.finger-tab.scenario-users').click(function () {
                    $('.finger-tab').removeClass('selected');
                    $('.finger-tab.scenario-users').addClass('selected');
                    $('#scenarioContent,  #scenarioOrganization, #scenarioDevices, #scheduleSettings, #userWorkflow, #officerWorkflow').hide();
                    $('#scenarioUsers').show();
                });
                $('.finger-tab.scenario-organization').click(function () {
                    $('.finger-tab').removeClass('selected');
                    $('.finger-tab.scenario-organization').addClass('selected');
                    $('#scenarioUsers,  #scenarioContent, #scenarioDevices, #scheduleSettings').hide();
                    $('#scenarioOrganization').show();
                });
                $('.finger-tab.scenario-devices').click(function () {
                    $('.finger-tab').removeClass('selected');
                    $('.finger-tab.scenario-devices').addClass('selected');
                    $('#scenarioUsers,  #scenarioOrganization, #scenarioContent, #scheduleSettings').hide();
                    $('#scenarioDevices').show();
                });
                $('.finger-tab.scenario-schedule').click(function () {
                    $('.finger-tab').removeClass('selected');
                    $('.finger-tab.scenario-schedule').addClass('selected');
                    $('#scenarioUsers,  #scenarioOrganization, #scenarioDevices, #scenarioContent').hide();
                    $('#scheduleSettings').show();
                });
                /*END finger tabs*/


            },
            //To set the finger Tab as per the selection in Scenario page
            Modalpopup: function (mode) {
                athoc.iws.scenario.settings.bindflag = false;
                $("#btn_scenariosettings").click();
                switch (mode) {
                    case 0:
                        $('.finger-tab.scenario-content').click();
                        break
                    case 1:
                        $('.finger-tab.scenario-users').click();
                        break;
                    case 2:
                        $('.finger-tab.scenario-organization').click();
                        break;
                    case 3:
                        $('.finger-tab.scenario-devices').click();
                        break;
                    case 4:
                        $('.finger-tab.scenario-schedule').click();
                        break;
                    default:
                        $("#btn_scenariosettings").click();
                        break;
                }
            },
            //To append the Personal device list
            formatPersonalDeviceList: function (data) {
                var groupList = [];
                var deviceList = [];
                var groupId = 0;
                var groupName = "";
                var filterData = data;

                if (filterData.length > 0) {
                    $(filterData).each(function (index) {

                        if (groupId != filterData[index].GroupId) {
                            groupId = filterData[index].GroupId;
                            if (deviceList.length > 0) {

                                groupList.push({ GroupName: groupName, DeviceList: deviceList, GroupId: groupId });
                                deviceList = [];
                            }
                            deviceList.push(filterData[index]);
                            groupName = filterData[index].GroupName;



                        } else {
                            deviceList.push(filterData[index]);

                        }

                    });
                    groupList.push({ GroupName: groupName, DeviceList: deviceList, GroupId: groupId });
                }
                return groupList;
            },
            //To append the mass device list
            formatMassDeviceList: function (data) {
                var groupList = [];
                var deviceList = [];
                var groupId = 0;
                var groupName = "";
                var filterData = data;

                if (filterData.length > 0) {
                    $(filterData).each(function (index) {

                        if (groupId != filterData[index].GroupId) {
                            groupId = filterData[index].GroupId;
                            if (deviceList.length > 0) {

                                groupList.push({ GroupName: groupName, DeviceList: deviceList, GroupId: groupId });
                                deviceList = [];
                            }
                            deviceList.push(filterData[index]);
                            groupName = filterData[index].GroupName;



                        } else {
                            deviceList.push(filterData[index]);

                        }

                    });
                    groupList.push({ GroupName: groupName, DeviceList: deviceList, GroupId: groupId });
                }
                return groupList;
            },
            //To Bind the Settings data
            bind: function (data) {

                athoc.iws.scenario.settings.viewModel.scenariosettingstmp = ko.mapping.fromJS(data);
                ko.cleanNode($("#ContentSettings").get(0));
                ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#ContentSettings").get(0));

                ko.cleanNode($("#UserSettings").get(0));
                $("#personaldevicesdisplaysettings").html("");
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.PersonalDeviceList = ko.mapping.fromJS(athoc.iws.scenario.settings.formatPersonalDeviceList(data.PersonalDeviceList));
                ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#UserSettings").get(0));

                if ($("#DevicesSettings").length > 0) {
                    ko.cleanNode($("#DevicesSettings").get(0));
                    $("#massdevicesdisplaysettings").html("");
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.MassDeviceList = ko.mapping.fromJS(athoc.iws.scenario.settings.formatMassDeviceList(data.MassDeviceList));
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#DevicesSettings").get(0));
                }
                if ($("#ScheduleSettings").length > 0) {
                    ko.cleanNode($("#ScheduleSettings").get(0));
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#ScheduleSettings").get(0));
                }

                if ($("#OrganizationSettings").length > 0) {
                    ko.cleanNode($("#OrganizationSettings").get(0));
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#OrganizationSettings").get(0));
                }
                //bind account template settings data...
                if ($("#EventUserWorkflowSettings").length > 0) {
                    ko.cleanNode($("#EventUserWorkflowSettings").get(0));
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.ShowWorkflowSection = ko.computed({
                        read: function() {
                            return this.IsAccountabilityMessagesVisible().toString();
                        },
                        write: function(newValue) {
                            this.disableWorkflowCollapsed(newValue === "false");
                            this.disableWorkflowReadonly(newValue === "false");
                            var val = newValue === "true";
                            this.IsAccountabilityMessagesCollapsed(val);
                            //for some reason 2 way binding is not working...
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesCollapsed(val);
                            this.IsAccountabilityMessagesVisible(val);
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesVisible(val);
                        },
                        owner: athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow
                    });
                    //for some reason 2 way binding is not working...
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesCollapsed.subscribe(function (newValue) {
                        athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesCollapsed(newValue);
                    });
                    //for some reason 2 way binding is not working...
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesReadonly.subscribe(function (newValue) {
                        athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesReadonly(newValue);
                    });
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.disableWorkflowCollapsed = ko.observable(false);
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.disableWorkflowReadonly = ko.observable(false);
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow, $("#EventUserWorkflowSettings").get(0));
                }

                athoc.iws.scenario.settings.officerVM.set("IsAccountabilityOfficerMessagesVisible", data.AccountabilityOfficer.IsAccountabilityOfficerMessagesVisible);
                athoc.iws.scenario.settings.officerVM.set("Visible", data.AccountabilityOfficer.Visible);
                athoc.iws.scenario.settings.officerVM.set("Collapsed", data.AccountabilityOfficer.Collapsed);
                athoc.iws.scenario.settings.officerVM.set("Readonly", data.AccountabilityOfficer.Readonly);

                athoc.iws.scenario.settings.viewModel.scenariosettings = ko.mapping.toJS(athoc.iws.scenario.settings.viewModel.scenariosettingstmp);


            },
            isMassDeviceChanged: function (device) {
                _.each(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.MassDeviceList(), function (item) {
                    var dev = _.find(item.DeviceList(), function (item2) {
                        return device.DeviceId() === item2.DeviceId();
                    });
                    if (dev) {
                        dev.Selected(device.Selected());
                        return false;

                    }
                });
                return true;
            },

            isPDChanged: function (device) {
                _.each(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.PersonalDeviceList(), function (item) {
                    var dev = _.find(item.DeviceList(), function (item2) {
                        return device.DeviceId() === item2.DeviceId();
                    });
                    if (dev) {
                        dev.Selected(device.Selected());
                        return false;

                    }
                });
                return true;
            },
            ApplyOrgsettingsOnFingerTabs: function (data) {
                $("#targetOrgByName").css("display", "none");
                $("#targetOrgByArea").css("display", "none");
                $("#fingerOrgName").css("display", "none");
                $("#fingerOrgArea").css("display", "none");
                $("#targetOrgNameCount").css("display", "none");
                $("#targetOrgAreaCount").css("display", "none");
                $("#targetOrgCount").css("display", "none");

                //For Target By Area Org
                if (data.TargetByAreaEnabled) {
                    $("#targetOrgByArea").css("display", "");
                    $("#fingerOrgArea").css("display", "");
                    $("#targetOrgAreaCount").css("display", "");
                    $("#targetOrgByArea").show();
                }
                //For Target By NameOrg                
                if (data.TargetByNameEnabled) {
                    $("#targetOrgByName").css("display", "");
                    $("#fingerOrgName").css("display", "");
                    $("#targetOrgNameCount").css("display", "");
                    $("#fingerOrgName").show();
                }

                if ((data.TargetByNameEnabled) && (data.TargetByAreaEnabled)) {
                    $("#targetOrgCount").css("display", "");
                    $("#fingerOrgName").addClass("selected");
                    $("#targetOrgByArea").hide();
                }
                if (!(data.TargetByNameEnabled) && !(data.TargetByAreaEnabled)) {
                    $('#inclAllOrg').prop("disabled", true);
                }
                else
                    $('#inclAllOrg').prop("disabled", false);



            },
            //To apply settings on  finger tabs 
            ApplysettingsOnFingerTabs: function (data) {
                var selectTab = -1;
                $("#targetGroups").css("display", "none");
                $("#targetContentGroups").css("display", "none");
                $("#targetSryGroups").css("display", "none");
                $("#targetUsers").css("display", "none");
                $("#targetContentUsers").css("display", "none");
                $("#targetSryUsers").css("display", "none");
                $("#targetQuery").css("display", "none");
                $("#targetContentQuery").css("display", "none");
                $("#targetSryQuery").css("display", "none");
                $("#targetArea").css("display", "none");
                $("#targetContentArea").css("display", "none");
                $("#targetSryArea").css("display", "none");
                var firstTab = -1;
                $(data).each(function (index) {
                    switch (data[index]) {
                        case 0:
                            $("#targetGroups").css("display", "");
                            $("#targetContentGroups").css("display", "");
                            $("#targetSryGroups").css("display", "");
                            firstTab = 0;
                            if (selectTab == -1 && (athoc.iws.publishing.targetUsers.getModel().TargetingNodes != null && athoc.iws.publishing.targetUsers.getModel().TargetingNodes.length > 0))
                                selectTab = 0;
                            break;
                        case 1:
                            $("#targetUsers").css("display", "");
                            $("#targetContentUsers").css("display", "");
                            $("#targetSryUsers").css("display", "");
                            if (firstTab == -1) firstTab = 1;
                            if (selectTab == -1 && (athoc.iws.publishing.targetUsers.getModel().TargetedBlockedUsers != null && athoc.iws.publishing.targetUsers.getModel().TargetedBlockedUsers.length > 0))
                                selectTab = 1;
                            break;

                        case 5:
                            $("#targetArea").css("display", "");
                            $("#targetContentArea").css("display", "");
                            $("#targetSryArea").css("display", "");
                            if (firstTab == -1 || firstTab == 3) firstTab = 5;
                            if ((selectTab == -1 || selectTab == 3) && ((athoc.iws.publishing.settings.IsTargetByAreaSupported) && (athoc.iws.publishing.geo.viewModel.isGeoSelected()) && (athoc.iws.publishing.geo.viewModel.isUsersTargeted())))
                                selectTab = 5;
                            break;

                        case 3:
                            $("#targetQuery").css("display", "");
                            $("#targetContentQuery").css("display", "");
                            $("#targetSryQuery").css("display", "");
                            if (firstTab == -1) firstTab = 3;
                            if (selectTab == -1 && (athoc.iws.publishing.targetUsers.getModel().TargetedCriteria != null && athoc.iws.publishing.targetUsers.getModel().TargetedCriteria.selections.length > 0))
                                selectTab = 3;
                            break;

                    }
                });
                if (selectTab == -1)
                    selectTab = firstTab;

                switch (selectTab) {
                    case -1:
                        $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                        $('.finger-tab.personal-devices').addClass('selected');
                        $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                        $('.finger-tab.personal-devices').css('margin-top', '0px');
                        $('#targetContentDevices').show();
                        break;

                    case 0:
                        $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                        $('.finger-tab.by-groups').addClass('selected');
                        $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                        $('#targetContentGroups').show();
                        break;
                    case 1:

                        $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                        $('.finger-tab.by-users').addClass('selected');
                        $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                        $('#targetContentUsers').show();
                        break;
                    case 3:
                        $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                        $('.finger-tab.by-query').addClass('selected');
                        $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                        $('#targetContentQuery').show();
                        break;
                    case 5:
                        $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                        $('.finger-tab.by-area').addClass('selected');
                        $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                        $('#targetContentArea').show();
                        break;
                }

            },
            //To Bind User Target Devices Data
            bindTargetdevices: function (Userdevicesdata) {
                var dGroupName = new Array();
                var dGroupId = new Array();

                $(Userdevicesdata()).each(function (index) {
                    if (!(dGroupName.indexOf(Userdevicesdata()[index].GroupName()) > 0)) {
                        dGroupName[index] = Userdevicesdata()[index].GroupName();
                        dGroupId[index] = Userdevicesdata()[index].GroupId();
                    }
                });

                $('#divGroupDevices').html('');
                var html = "<ul>";
                $(dGroupName).each(function (index) {
                    if (dGroupName[index] != undefined) {

                        var chkcount = 0;
                        var itemscount = 0;
                        var subCheckbox = "";
                        $(Userdevicesdata()).each(function (j) {

                            if (dGroupName[index] == Userdevicesdata()[j].GroupName()) {
                                subCheckbox += "<ul>";
                                var checked = athoc.iws.scenario.settings.checkDeviceExists(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.EnabledDevices(), Userdevicesdata()[j].DeviceId()) ? "checked" : "";
                                if (checked == "checked")
                                    chkcount++;
                                subCheckbox += "<li><input  class='checkbox' type='checkbox' id=chk_" + dGroupId[index] + "_" + Userdevicesdata()[j].DeviceId() + "  value=" + Userdevicesdata()[j].DeviceId() + " " + checked + "></input>" + Userdevicesdata()[j].DeviceName() + "</li>";
                                subCheckbox += "</ul>";
                                itemscount++;
                            }
                        });
                        checked = (itemscount == chkcount) ? "checked" : " ";

                        html += "<li class='color-light-grey'>" + dGroupName[index] + "</li>" + subCheckbox;

                    }
                });
                html += "</ul>";
                $(html).appendTo('#divGroupDevices');

            },

            //To check whether the de
            checkDeviceExists: function (data, deviceId) {
                if (athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Id() == -1)
                    return true;
                var item = _.find(data, function (i) {
                    return i == deviceId;
                });
                if (item != null)
                    return true;
                else
                    return false;
            },

            //for User Devices Parent check
            SelectUserDevicesAll: function (chkParent) {
                if (chkParent.checked) {
                    $("#divGroupDevices input[id*='" + chkParent.id + "_']:checkbox").each(function (j) {
                        $("#divGroupDevices input[id*='" + chkParent.id + "_']:checkbox")[j].checked = true;
                    });
                }
                else
                    $("#divGroupDevices input[id*='" + chkParent.id + "_']:checkbox").attr("checked", false);
                //return false;
            },

            //for User Devices Children check
            SelectUserDevicesChild: function (chkChild, ParentId) {

                if (chkChild.checked) {
                    var TotalCheckboxes = $("#divGroupDevices  input[id*='" + ParentId.id + "_']:checkbox").length;
                    var CheckedCount = $("#divGroupDevices  input[id*='" + ParentId.id + "_']:checkbox:checked").length;
                    if (TotalCheckboxes == CheckedCount)
                        $("#divGroupDevices input[id='" + ParentId.id + "']:checkbox")[0].checked = true;
                    else
                        $("#divGroupDevices input[id='" + ParentId.id + "']:checkbox").attr("checked", false);
                }
                else
                    $("#divGroupDevices input[id='" + ParentId.id + "']:checkbox").attr("checked", false);

            },


            //To Bind Mass Devices Data
            bindMassdevices: function (Massdevicesdata) {
                return ko.mapping.fromJS(athoc.iws.publishing.massdevices.formatMassDeviceList(Massdevicesdata));
            },
            //for Mass Devices Parent check
            SelectMassDevicesAll: function (chkParent) {
                if (chkParent.checked) {
                    $("#divMassDevices input[id*='" + chkParent.id + "_']:checkbox").each(function (j) {
                        $("#divMassDevices input[id*='" + chkParent.id + "_']:checkbox")[j].checked = true;
                    });
                }
                else
                    $("#divMassDevices input[id*='" + chkParent.id + "_']:checkbox").attr("checked", false);

            },

            //for Mass Devices Children check
            SelectMassDevicesChild: function (chkChild, ParentId) {

                if (chkChild.checked) {
                    var TotalCheckboxes = $("#divMassDevices  input[id*='" + ParentId.id + "_']:checkbox").length;
                    var CheckedCount = $("#divMassDevices  input[id*='" + ParentId.id + "_']:checkbox:checked").length;
                    if (TotalCheckboxes == CheckedCount)
                        $("#divMassDevices input[id='" + ParentId.id + "']:checkbox")[0].checked = true;
                    else
                        $("#divMassDevices input[id='" + ParentId.id + "']:checkbox").attr("checked", false);
                }
                else
                    $("#divMassDevices input[id='" + ParentId.id + "']:checkbox").attr("checked", false);

            },
            //for selected checkboxes in Targetusers
            EnableDevicesData: function () {
                var selectedCheckBoxArray = new Array();

                $("#divGroupDevices input[type=checkbox]:checked").each(function () {
                    selectedCheckBoxArray.push($(this).val());
                });
                selectedCheckBoxArray = selectedCheckBoxArray.join(',');
            },
            //this method will be called when data is required for updating
            getModel: function () {

                return ko.mapping.toJS(athoc.iws.scenario.settings.viewModel.scenariosettings);
            },
            //To resize setting popup based on screen resolution
            resizeModalBasedOnScreen: function (modal) {
                modal.find(".modal-body").css("max-height", 621);
                var windowHeight = $(window).height();
                var extrSpace = athoc.iws.publishing.contextName == "AccountTemplate" ? 80 : 40;
                if (windowHeight > 770) {                    
                    modal.css("margin-top", 40 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                    $('#ScenarioSettings .finger-tab-content').css("height", windowHeight - (340 + extrSpace));
                    $('#ScenarioSettings .inner-bucket-grid-wrap').css("height", windowHeight - (440 + extrSpace));
                    if (athoc.iws.publishing.contextName == "AccountTemplate") {
                        $('#ScenarioSettings .inner-bucket-grid-wrap').css("max-height", windowHeight - (470 + extrSpace));
                    }
                } else {

                    modal.css("margin-top", 40 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 240);
                    $('#ScenarioSettings .finger-tab-content').css("max-height", windowHeight - (240));
                    $('#ScenarioSettings .inner-bucket-grid-wrap').css("max-height", windowHeight - (290 + extrSpace));

                    $('#ScenarioSettings .finger-tab-content').css("height", windowHeight - (240));
                    $('#ScenarioSettings .inner-bucket-grid-wrap').css("height", windowHeight - (290 + extrSpace));
                }

                if (athoc.iws.publishing.contextName != "AccountTemplate")
                    $('#ScenarioSettings .inner-bucket-grid-wrap').css("width", 665);

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }


            },
            //Error handling
            handleError: function (e) {
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },
            //w.r.t condition toggle duplicate and delete buttons
            toggleButtonStates: function (count) {
                if (count < 1) {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", true);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", true);
                }
                else if (count == 1) {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", false);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", false);
                }
                else {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", true);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", false);
                }
            },
            //Settings scenario setting values to the model.
            AssigningValues: function (enabledDevices) {

                var arrDevicesSelected = new Array();
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.EnabledDevices(enabledDevices);

                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.Visible = ($("#rdContentShow")[0].checked) ? "Y" : "N";
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.Visible = ($("#rdTargetShow")[0].checked) ? "Y" : "N";
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.Visible = ($("#rdOrgShow")[0].checked) ? "Y" : "N";
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.Visible = ( $("#rdDeviceShow")[0] && $("#rdDeviceShow")[0].checked) ? "Y" : "N";
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Advanced.Visible = ($("#rdScheduleShow")[0] && $("#rdScheduleShow")[0].checked) ? "Y" : "N";

                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.Readonly = ($("#chkContentread")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.Readonly = ($("#chkTUreadonly")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.Readonly = ($("#chkShowReadOnly")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.Readonly = ($("#chkDeliveryReadonly")[0] && $("#chkDeliveryReadonly")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Advanced.Readonly = ($("#chkAdvanceReadonly")[0] && $("#chkAdvanceReadonly")[0].checked) ? true : false;

                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.Collapsed = ($("#chkContentCollapse")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.Collapsed = ($("#chkTUCollapse")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.Collapsed = ($("#chkShowInCollapsed")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.Collapsed = ($("#chkDeliveryCollapse")[0] && $("#chkDeliveryCollapse")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Advanced.Collapsed = ($("#chkAdvanceCollapse")[0] && $("#chkAdvanceCollapse")[0].checked) ? true : false;

                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.LocationEnabled = ($("#chkLocation")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.LocationMandatoryEnabled = ($("#chkLocationMandatory")[0].checked) ? true : false;
                //if (athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.LocationEnabled && athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.LocationMandatoryEnabled)
                //    athoc.iws.publishing.content.checkReadyNotReady();
                if ($("#chkContentResponse").length > 0)
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.ResponseOptionEnabled = ($("#chkContentResponse")[0].checked) ? true : false;
               
              //athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.DropboxEnabled = ($("#chkDropdown")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.DropboxEnabled = ($("#chkDropdown").is(':checked'));

                if ($("#chkFillCount").length > 0)
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.FillCount = ($("#chkFillCount")[0].checked) ? true : false;

                athoc.iws.scenario.settings.isFillCountEnabled = athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.FillCount;
                if (!athoc.iws.scenario.settings.isFillCountEnabled) {
                    athoc.iws.publishing.fillcount.clearFillCountData(athoc.iws.scenario.settings.isFillCountEnabled, athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                }
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByNameEnabled = ($("#chkEnableTargByName")[0].checked) ? true : false;
                if ($("#chkLocation")[0].checked)
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByAreaEnabled = ($("#chkEnableTargByArea")[0].checked) ? true : false;


                var arrEnableTargetType = new Array();
                if ($("#chkTargettingGroup")[0].checked)
                    arrEnableTargetType.push(parseInt($("#chkTargettingGroup").val()));
                if ($("#chkTargettingName")[0].checked)
                    arrEnableTargetType.push(parseInt($("#chkTargettingName").val()));
                if ($("#chkTargettingQuery")[0].checked)
                    arrEnableTargetType.push(parseInt($("#chkTargettingQuery").val()));
                if ($("#chkTargettingArea")[0].checked)
                    arrEnableTargetType.push(parseInt($("#chkTargettingArea").val()));
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.EnabledTargetingTypes(arrEnableTargetType);

                athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(arrEnableTargetType);
                athoc.iws.scenario.settings.ApplyOrgsettingsOnFingerTabs(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization);


                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.LocationEnabled ? $("#dvContentLocation").css("display", "") : $("#dvContentLocation").css("display", "none");
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.ResponseOptionEnabled ? $("#dvContentResponseOpt").css("display", "") : $("#dvContentResponseOpt").css("display", "none");
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.ResponseOptionEnabled ? $("#dvContentAddResponseOpt").css("display", "") : $("#dvContentAddResponseOpt").css("display", "none");
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.DropboxEnabled ? $("#dvContentDropBox").css("display", "") : $("#dvContentDropBox").css("display", "none");
                //for Scenario always readonly=false
              
                if (athoc.iws.publishing.contextName != "AccountTemplate")
                    athoc.iws.publishing.fillcount.enableFillCountSummary( athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.FillCount);

            },
            //To get the devices which are selected
            getDeviceList: function (data, isPersonalDevice) {


                var resultdata = [];
                var data = ko.mapping.toJS(data);
                //if (isPersonalDevice)
                //    data.sort(function (l, r) { return l.GroupId < r.GroupId ? -1 : 1 })
                var i = 0;
                $(data).each(function (index) {
                    i = 0;
                    $(data[index].DeviceList).each(function (index2) {

                        if (data[index].DeviceList[index2].Selected) {
                            i++;
                            if (i == 1)
                                data[index].DeviceList[index2].GroupChange = true;
                            resultdata.push(data[index].DeviceList[index2]);
                            athoc.iws.scenario.settings.enabledDevices.push(data[index].DeviceList[index2].DeviceId);
                        }
                    });
                });
                if (resultdata.length > 0)
                    athoc.iws.scenario.settings.selectedCount++;
                return resultdata;
            },
            // to save User Settings in the database
            saveUserSettings: function () {
                athoc.iws.scenario.settings.errorflag = false;
                if (($("#chkTargettingGroup")[0].checked) ||
                    ($("#chkTargettingName")[0].checked) ||
                    ($("#chkTargettingQuery")[0].checked) ||
                    ($("#chkTargettingArea")[0].checked)) {

                    if (!($("#chkLocation")[0].checked) && ($("#chkLocationMandatory")[0].checked))
                    {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_Locationmsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }
                    else if ((athoc.iws.publishing.targetUsers.getModel().TargetingNodes.length > 0) && (!$("#chkTargettingGroup")[0].checked) && ($('#targetGroups').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_Groupsmsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }

                    else if ((athoc.iws.publishing.targetUsers.getModel().TargetedBlockedUsers.length > 0) && (!$("#chkTargettingName")[0].checked) && ($('#targetUsers').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_Usersmsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }

                    else if ((athoc.iws.publishing.geo.viewModel.isUsersTargeted() && athoc.iws.publishing.geo.geoJson != null) && (!$("#chkTargettingArea")[0].checked) && ($('#targetArea').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_Areamsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }
                    else if ((athoc.iws.publishing.targetUsers.viewModelInstance.numberQueryCriteria() > 0) && (!$("#chkTargettingQuery")[0].checked) && ($('#targetQuery').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_Querymsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }
                        //Org Name Data check
                    else if ((athoc.iws.publishing.targetOrg.OrgViewModel && athoc.iws.publishing.targetOrg.OrgViewModel.OrgSelected().length > 0) && (!$("#chkEnableTargByName")[0].checked) && ($('#targetOrgByName').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_OrganizationNamemsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }
                        //Org Area Data check
                    else if ((athoc.iws.publishing.targetOrg.OrgViewModel && athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea()) && (!$("#chkEnableTargByArea")[0].checked) && ($('#targetOrgByArea').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_OrganizationLocmsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }
                    else {

                        athoc.iws.scenario.settings.enabledDevices = [];
                        var massdata = athoc.iws.scenario.settings.getDeviceList(ko.mapping.toJS(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.MassDeviceList), false);
                        var personaldata = athoc.iws.scenario.settings.getDeviceList(ko.mapping.toJS(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.PersonalDeviceList), true);
                        athoc.iws.scenario.settings.assignIsPhoneAndEnabledProperties(personaldata);
                        if (massdata.length == 0)
                            $('#MassDeviceFlatList').hide();
                        else
                            $('#MassDeviceFlatList').show();

                        if ((massdata.length > 0) || (personaldata.length > 0)) {
                            $('#ScenarioSettings').hide();
                            athoc.iws.scenario.settings.AssigningValues(athoc.iws.scenario.settings.enabledDevices);
                            //perpare mass device list for binding 

                            if (athoc.iws.publishing.contextName != "AccountTemplate") {// don't refresh mass device for event template as it would throw error...
                                athoc.iws.publishing.massdevices.refreshMassDevicesList(massdata);
                            }
                            // bind the details on parent page
                            // hide/show based on the Scenario Settings 
                            athoc.iws.publishing.targetUsers.refreshPersonalDevices(personaldata);
                            // apply settings on main model for save
                            if ((athoc.iws.scenario.settings.viewModel.scenariosettings.Organization.TargetByNameEnabled != athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByNameEnabled) && (athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByNameEnabled) && athoc.iws.publishing.targetOrg.OrgViewModel.TargetAllOrg())
                                athoc.iws.publishing.targetOrg.OrgViewModel.SelectAll();

                            $('#location-mandatory').css("display", "none");
                            athoc.iws.scenario.settings.viewModel.scenariosettings = ko.mapping.toJS(athoc.iws.scenario.settings.viewModel.scenariosettingstmp);
                            athoc.iws.scenario.settings.viewModel.scenariosettings.AccountabilityOfficer = athoc.iws.scenario.settings.officerVM.toJSON();
                            if (athoc.iws.scenario.settings.viewModel.scenariosettings.Content.LocationEnabled) {
                                
                                athoc.iws.publishing.content.checkReadyNotReady();
                            }

                        }
                        else {
                            $('.finger-tab').removeClass('selected');
                            $('.finger-tab.scenario-users').addClass('selected');
                            $('#scenarioContent,  #scenarioOrganization, #scenarioDevices, #scenarioSchedule').hide();
                            $('#scenarioUsers').show();

                            alert(athoc.iws.scenario.settings.resources.ScenarioSettings_AtleastOneDevice);
                        }


                      

                    }

                }

                else {
                    alert(athoc.iws.scenario.settings.resources.ScenarioSettings_AtleastOneTargerUserOption);
                    athoc.iws.scenario.settings.errorflag = true;
                }
               // athoc.iws.scenario.settings.RefreshContentSectionReadyStatus();
            },

            //Assign the IsPhone and Enabled Property to setting PersonalData.
            assignIsPhoneAndEnabledProperties: function (settingPersonalDevices) {
                var tagetUserPersonalDevices = ko.mapping.toJS(athoc.iws.publishing.targetUsers.viewModelInstance.Devices);
                _.each(settingPersonalDevices, function (settingsDeviceitem, settingsIndex) {
                    _.each(tagetUserPersonalDevices, function (targetUsersDeviceitem, targetUsersIndex) {
                        if (settingsDeviceitem.DeviceId == targetUsersDeviceitem.DeviceId) {
                            settingsDeviceitem.Enabled = targetUsersDeviceitem.Enabled;
                            settingsDeviceitem.IsPhone = targetUsersDeviceitem.IsPhone;
                        }
                    });
                });

            },

            //To Show/Hide Location,Dropbox,Response option depending on settings on Scenarion & Alert page .
            applyAlertContentSettings: function (content) {
                var targetDIV = ($("#alert-content-edit").is(':visible') ? "#publishing-content-edit" : "#publishing-content-detail");
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Readonly) {
                    if (content.LocationEnabled && (athoc.iws.publishing.view.viewModel.isGeoSelected() || content.LocationMandatoryEnabled))
                        $(targetDIV).find("#dvContentLocation").css("display", "");
                    else
                        $(targetDIV).find("#dvContentLocation").css("display", "none");
                }
                else {
                    if (content.LocationEnabled)
                        $(targetDIV).find("#dvContentLocation").css("display", "");
                    else
                        $(targetDIV).find("#dvContentLocation").css("display", "none");
                }


                if (content.ResponseOptionEnabled) {
                    $(targetDIV).find("#dvContentResponseOpt").css("display", "");
                    $(targetDIV).find("#dvContentAddResponseOpt").css("display", "");
                }
                else {
                    $(targetDIV).find("#dvContentResponseOpt").css("display", "none");
                    $(targetDIV).find("#dvContentAddResponseOpt").css("display", "none");
                }

                if (content.DropboxEnabled) {
                    $(targetDIV).find("#dvContentDropBox").css("display", "");
                    // $(targetDIV).find("#dvContentMoreInfo").css("display", "");
                }
                else {
                    $(targetDIV).find("#dvContentDropBox").css("display", "none");
                    // $(targetDIV).find("#dvContentMoreInfo").css("display", "none");
                }
            },
            //To Show/Hide Location,Dropbox,Response option depending on settings on Scenarion & Alert page .
            applyScenarioContentSettings: function (content) {
                if (content.LocationEnabled)
                    $("#dvContentLocation").css("display", "");
                else
                    $("#dvContentLocation").css("display", "none");


                if (content.ResponseOptionEnabled) {
                    $("#dvContentResponseOpt").css("display", "");
                    $("#dvContentAddResponseOpt").css("display", "");
                }
                else {
                    $("#dvContentResponseOpt").css("display", "none");
                    $("#dvContentAddResponseOpt").css("display", "none");
                }

                if (content.DropboxEnabled) {
                    $("#dvContentDropBox").css("display", "");
                    // $("#dvContentMoreInfo").css("display", "");
                }
                else {
                    $("#dvContentDropBox").css("display", "none");
                    //$("#dvContentMoreInfo").css("display", "none");
                }
            },
            //toogle the view based on the settings
            applySettingsOnAlert: function (settingData, data) {
                athoc.iws.scenario.settings.ReadonlyViewModel.applysettings = settingData;
                athoc.iws.publishing.content.ReadonlyViewModel.data = data;

                // Apply Readonly Settings
                athoc.iws.scenario.settings.applyReadOnlySettingsOnAlert(data);

            },
            //To apply readonly settings for Alert details
            applyReadOnlySettingsOnAlert: function (data) {
                athoc.iws.publishing.view.targetingChanged(data);
                athoc.iws.publishing.view.isMassDeviceReady(data);
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Readonly && athoc.iws.publishing.content.isReadyToPublish() && athoc.iws.publishing.content.isValid()) {
                    if ((athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled && athoc.iws.publishing.view.viewModel.isGeoSelected())
                    || (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled && athoc.iws.publishing.view.viewModel.isGeoSelected())
                        || (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled && !athoc.iws.publishing.view.viewModel.isGeoSelected())) {
                        $("#alert-content-edit").hide();
                        $("#alert-content-detail").show();

                        //Added the below lines of code to display readonly view in edit alert
                        athoc.iws.publishing.view.bindContentSection(data, $("#alert-content-detail"));
                        athoc.iws.publishing.view.bindGeoLocation(data.Content.LocationGeo, $("#alert-content-detail"));
                    }                        
                    else
                        athoc.iws.publishing.content.bind(data.Content, data.Context);
                }
                else
                    athoc.iws.publishing.content.bind(data.Content, data.Context);


                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly && athoc.iws.publishing.targetUsers.isReadyToPublish) {
                    $("#alert-user-edit").hide();
                    $("#alert-user-detail").show();
                    athoc.iws.publishing.source = "readonly";
                    athoc.iws.publishing.iut.bind(data.TargetUsers.TargetedBlockedUsers);

                    //Added the below line of code to display readonly view in edit alert
                    athoc.iws.publishing.view.bindTargetUsers(data, $("#alert-user-detail"));

                }
                else {
                    athoc.iws.publishing.targetUsers.bind(data.TargetUsers, data.PresetDeviceGroupOptions);
                    athoc.iws.publishing.iut.bind(data.TargetUsers.TargetedBlockedUsers);
                }

                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.Readonly) {
                    $("#alert-org-edit").hide();
                    $("#alert-ord-detail").show();
                    athoc.iws.publishing.targetOrg.bindReadOnlyViewModel(data.TargetOrg.TargetedOrganizations, $("#alert-ord-detail"));
                }
                else
                    athoc.iws.publishing.targetOrg.load(data.TargetOrg);


                //do not run following for PA
                if (athoc.iws.publishing.contextName == "Alert") { 
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Delivery.Readonly && athoc.iws.publishing.massdevices.isReadyToPublish) {
                        $("#alert-mass-edit").hide();
                        $("#alert-mass-detail").show();
                        athoc.iws.publishing.massdevices.bindReadOnlyView(data.MassDevices, "#alert-mass-detail");
                    } else
                        athoc.iws.publishing.massdevices.bind(data.MassDevices, data.Context, data.ScenarioSettings.Delivery.Readonly, data.PresetDeviceGroupOptions);

                    //if mass device or target users section is read only, must retrieve custom text via ajax.  
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly || athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Delivery.Readonly) {
                        athoc.iws.publishing.view.getCustomTextViaAjax(data.PresetDeviceGroupOptions);
                    }
                }

                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Advanced.Readonly && athoc.iws.publishing.scenario.isReadyToPublish()) {
                    $("#alert-schedule-edit").hide();
                    $("#alert-schedule-detail").show();
                    athoc.iws.alert.schedule.bindReadOnlyView(data.AlertScheduleSettings, "#alert-schedule-detail");
                }
                athoc.iws.scenario.settings.applyVisibleSettingsOnAlert();
            },
            //To apply collapse settings for Alert details
            applyCollapseSettingsOnAlert: function () {
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Visible == 'Y') {
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Collapsed)
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-content-edit").is(':visible') ? "#publishing-content-edit" : "#publishing-content-detail"), true, $("#alert-content-edit").is(':visible'));
                    else
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-content-edit").is(':visible') ? "#publishing-content-edit" : "#publishing-content-detail"), false, $("#alert-content-edit").is(':visible'));
                }

                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Visible == 'Y') {
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Collapsed)

                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-user-edit").is(':visible') ? "#publishing-user-edit" : "#publishing-user-detail"), true, $("#alert-user-edit").is(':visible'));
                    else
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-user-edit").is(':visible') ? "#publishing-user-edit" : "#publishing-user-detail"), false, $("#alert-user-edit").is(':visible'));
                }
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.Visible == 'Y') {
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.Collapsed)
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-org-edit").is(':visible') ? "#targetOrgSection" : "#targetOrgDetail"), true, $("#alert-org-edit").is(':visible'));
                    else
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-org-edit").is(':visible') ? "#targetOrgSection" : "#targetOrgDetail"), false, $("#alert-org-edit").is(':visible'));
                }
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Delivery.Visible == 'Y') {
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Delivery.Collapsed) {
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-mass-edit").is(':visible') ? "#publishing-mass-edit" : "#publishing-mass-view"), true, $("#alert-mass-edit").is(':visible'));
                        $("#massDeviceOptionsLink").hide();
                    } else {
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-mass-edit").is(':visible') ? "#publishing-mass-edit" : "#publishing-mass-view"), false, $("#alert-mass-edit").is(':visible'));
                        $("#massDeviceOptionsLink").show();
                    }
                }
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Advanced.Visible == 'Y') {

                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Advanced.Collapsed)
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-schedule-edit").is(':visible') ? "#publishing-alert-edit" : "#publishing-alert-view"), true, (athoc.iws.publishing.detail.viewModel.AlertStatus != "Live" ? true : $("#alert-schedule-edit").is(':visible')));
                    else
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-schedule-edit").is(':visible') ? "#publishing-alert-edit" : "#publishing-alert-view"), false, (athoc.iws.publishing.detail.viewModel.AlertStatus != "Live" ? true : $("#alert-schedule-edit").is(':visible')));

                }
            },
            //To apply Visible settings for Alert details
            applyVisibleSettingsOnAlert: function () {                
                var data = athoc.iws.scenario.settings.ReadonlyViewModel.applysettings;
				// todo: this check is for PA case where we load only preview mode, and have no settings
				// todo: review with Nishith
                if (data.length == 0) {
                    return;
                }
                if (data.Content.Visible == 'N' && athoc.iws.publishing.content.isReadyToPublish() && athoc.iws.publishing.content.isValid())
                    $("#publishing-content-edit").hide();
                else
                    $("#publishing-content-edit").show();

                if ((athoc.iws.publishing.targetUsers.isReadyToPublish || (!athoc.iws.publishing.targetUsers.isReadyToPublish && !athoc.iws.publishing.targetUsers.isInErrorState)) && (data.Targeting.Visible == 'N' || data.Targeting.Readonly))
                    $("#publishing-user-edit").hide();
                else
                    $("#publishing-user-edit").show();
                //iws#12702
                if (data.Organization.Visible == 'N' || data.Organization.Readonly)
                    $("#alert-org-edit").hide();
                else
                    $("#alert-org-edit").show();
                if (data.Delivery.Visible == 'N' && (athoc.iws.publishing.massdevices.isReadyToPublish || (!athoc.iws.publishing.massdevices.isReadyToPublish && !athoc.iws.publishing.massdevices.isInErrorState)))
                    $("#publishing-mass-edit").hide();
                else
                    $("#publishing-mass-edit").show();
                if (data.Advanced.Visible == 'N' && athoc.iws.publishing.scenario.isReadyToPublish())
                    $("#publishing-alert-edit").hide();
                else
                    $("#publishing-alert-edit").show();
            },
            //To change readonly state for check boxes on click
            changeReadOnlyState: function (id) {
                if (!athoc.iws.scenario.settings.bindflag) {
                    switch (id) {
                        case "chkContentread":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.Readonly($("#" + id).is(':checked'));
                            break;
                        case "chkContentCollapse":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.Collapsed($("#" + id).is(':checked'));
                            break;
                        case "chkTUreadonly":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.Readonly($("#" + id).is(':checked'));
                            break;
                        case "chkTUCollapse":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.Collapsed($("#" + id).is(':checked'));
                            break;
                        case "chkShowReadOnly":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.Readonly($("#" + id).is(':checked'));
                            break;
                        case "chkShowInCollapsed":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.Collapsed($("#" + id).is(':checked'));
                            break;
                        case "chkDeliveryReadonly":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.Readonly($("#" + id).is(':checked'));
                            break;
                        case "chkDeliveryCollapsed":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.Collapsed($("#" + id).is(':checked'));
                            break;
                        case "chkAdvanceReadonly":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Advanced.Readonly($("#" + id).is(':checked'));
                            break;
                        case "chkAdvanceCollapsed":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Advanced.Collapsed($("#" + id).is(':checked'));
                            break;

                        case "chkLocation":

                            if ($("#chkLocation")[0].checked) {
                                $("#chkTargettingArea")[0].checked = true;
                                $("#chkEnableTargByArea")[0].checked = true;

                                var arrEnableTargetType = new Array();
                                if ($("#chkTargettingGroup")[0].checked)
                                    arrEnableTargetType.push(parseInt($("#chkTargettingGroup").val()));
                                if ($("#chkTargettingName")[0].checked)
                                    arrEnableTargetType.push(parseInt($("#chkTargettingName").val()));
                                if ($("#chkTargettingQuery")[0].checked)
                                    arrEnableTargetType.push(parseInt($("#chkTargettingQuery").val()));
                                if ($("#chkTargettingArea")[0].checked)
                                    arrEnableTargetType.push(parseInt($("#chkTargettingArea").val()));
                                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.EnabledTargetingTypes(arrEnableTargetType);

                                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByAreaEnabled = true;
                            }
                            else {
                                $("#chkTargettingArea")[0].checked = false;
                                $("#chkEnableTargByArea")[0].checked = false;
                                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByAreaEnabled = false;
                            }
                            break;

                        case "chkShowSeverity":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsContentSeverityVisible($("#" + id).is(':checked'));
                            break;

                        case "chkShowType":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsContentTypeVisible($("#" + id).is(':checked'));
                            break;

                        case "rbContentVisible":
                            if ($("#rdContentShow")[0].checked)
                                $("#chkContentCollapse")[0].checked = true;
                            break;

                        case "rdContentHide":
                            $("#chkContentCollapse")[0].checked = false;
                            break;


                        case "rdTargetShow":
                            if ($("#rdTargetShow")[0].checked)
                                $("#chkTUCollapse")[0].checked = true;
                            break;

                        case "rdTargetHide":
                            $("#chkTUCollapse")[0].checked = false;
                            break;

                        case "rdOrgShow":
                            if ($("#rdOrgShow")[0].checked)
                                $("#chkShowInCollapsed")[0].checked = true;
                            break;

                        case "rdOrgHide":
                            $("#chkShowInCollapsed")[0].checked = false;
                            break;

                        case "rdDeviceShow":
                            if ($("#rdDeviceShow")[0].checked)
                                $("#chkDeliveryCollapse")[0].checked = true;
                            break;

                        case "rdDeviceHide":
                            $("#chkDeliveryCollapse")[0].checked = false;
                            break;

                        case "rdScheduleShow":
                            if ($("#rdScheduleShow")[0].checked)
                                $("#chkAdvanceCollapse")[0].checked = true;
                            break;

                        case "rdScheduleHide":
                            $("#chkAdvanceCollapse")[0].checked = false;
                            break;


                    }
                }
            },
            //Toggling open & closed for alert section
            toggleAlertSections: function (divId, isCollapse, isEdit) {
                var targetDiv = $(divId);
                if (targetDiv.length == 0)
                    return;
                targetDiv.find('.section-title, .expand-arrow-open, .expand-arrow-closed').unbind("click");
                targetDiv.find('#bucketTitle').unbind("click");
                $('.bucket-toggle h2').unbind("click");
                $('.bucket-toggle h2').bind('click', function (e) {
                    if (!e.isDefaultPrevented()) {
                        $(this).parent().find('.row').slideToggle(500);
                        $(this).parent().find('.expand-arrow-open').toggle();
                        $(this).parent().find('.expand-arrow-closed').toggle();
                    }
                    e.preventDefault();
                });
                //show bucket expanded by default
                if (isCollapse) {
                    targetDiv.find(".bucket-toggle .row").hide();
                    targetDiv.find(".bucket-toggle .expand-arrow-open").hide();
                    targetDiv.find(".bucket-toggle .expand-arrow-closed").show();
                }
                else {
                    targetDiv.find(".bucket-toggle .row").show();
                    targetDiv.find(".bucket-toggle .expand-arrow-open").show();
                    targetDiv.find(".bucket-toggle .expand-arrow-closed").hide();
                }

            },
            //To display settings icon
            displaysettingsIcon: function (display) {

                $("#dvContentIcon").css("display", display);
                $("#dvTargetUsersIcon").css("display", display);
                $("#dvOrgIcon").css("display", display);
                $("#dvMassDevicesIcon").css("display", display);
                $("#dvScheduleSettingsIcon").css("display", display);

            },

            RefreshContentSectionReadyStatus: function () {
                if (athoc.iws.publishing.content.isValid()) {
                    athoc.iws.publishing.content.viewModel.status('ready');
                    athoc.iws.publishing.content.viewModel.statusTooltip(athoc.iws.publishing.resources.Publishing_Section_Ready_Tooltip);
                } else {
                    athoc.iws.publishing.content.viewModel.status('not-ready');
                    athoc.iws.publishing.content.viewModel.statusTooltip(athoc.iws.publishing.resources.Publishing_Section_NotReady_Tooltip);
                }
            },


        };
    }();
}