﻿define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dijit/_WidgetBase",
"dijit/_TemplatedMixin",
"dojo/Evented",
"dojo/dom-style",
"dojo/on",
"dojo/query",
"dojo/text!publishing/AudioUploader/AudioUploaderTemplate.html",
"dojox/form/Uploader",
"publishing/AudioUploader/recorder"
],
function (declare, lang, array, widgetBase, templatedMixin, evented, domStyle, on, query, template, uploader) {
    var audioUploader = declare("athoc.iws.publishing.AudioUploader", [widgetBase, templatedMixin, evented], {
        templateString: template,
        constructor: function (options, srcRefNode, resource) {
            var self = this;
            //common code for tool

            //Timer Properties
            //self.timerProperties = { maxrecordingtime: 60, timer: null, timerCounter: 0 };

            // Recording Properties
            //self.recordingProperties = { audio_context: null, recorder: null, isPlaying: false, AudioURL: null, recordedAudioData: '' };

            //Audio Recording Properties
            audio_context = null;
            localStream = ""; // workaround to display MIC in the firefox browser
            self.recorder = null;
            AudioURL = "";
            self.startAt = "";
            self.recordedAudioData = '';
            self.isRecording = false;
            maxRecordingTime = 60;
            recordedLength = 0;
            fileData = null;
            timer = null;
            // Audio Component Properties
            self.audioProperties = {
                isValid: (options.audioId != "" || options.fileName != "") ? true : false,
                audioId: options.audioId,
                fileName: options.fileName,
                fileStream: options.fileStream,
                isRequired: options.isRequired,
                isReadOnly: options.isReadOnly,
                isBrowseSpecific: options.isBrowseSpecific,
                isChanged: false,
                operator: options.operator,
                isRecordedMessage: false,
                resources: resource.resources,
            };
            
            //define viewmodel here...
            self.viewModel = ko.mapping.fromJS(self.audioProperties);
            //Assign the validation to the viewModel
            self.Strings = resource.resources;
            self.Urls = resource.urls;


        },

        // Count Down Timer for Audio Recording
        startTimer: function () {
            // Prepare timer object.
            this.timerCounter = this.maxrecordingtime + 1;
            this.timerCount();


        },
        // Stops the recording for Count Down is complete in case if user is recording more than defined time .
        stopTimer: function () {
            // Stop timer.
            clearTimeout(self.timer);
            this.stopRecording();

        },
        // Formatting the time string
        str_pad_left: function (string, pad, length) {
            return (new Array(length + 1).join(pad) + string).slice(-length);
        },
        // Time formatting 
        formatTimewithSeconds: function (timerSeconds) {
            var time = timerSeconds;
            var minutes = Math.floor(time / 60);
            var seconds = time - minutes * 60;
            return this.str_pad_left(minutes, '0', 2) + ':' + this.str_pad_left(seconds, '0', 2);
        },
        // Perform Timer Validation
        timerCount: function () {
            // Decrement total count and check if we have reached the maximum time.
            this.timerCounter--;
            if (this.timerCounter == 0) {
                // Stop the recording.
                this.stopTimer();
                return;
            }

            // Update the Timer display.
            this.updateRecordingTime();

            // Continue the timer.
            this.timer = setTimeout(this.timerCount(), 1000);
        },

        pad: function (num, size) {
            var s = "0000" + num;
            return s.substr(s.length - size);
        },
        formatTime: function (time) {
            var h = m = s = ms = 0;
            var newTime = '';
            m = Math.floor(time / (60 * 1000));
            time = time % (60 * 1000);
            s = Math.floor(time / 1000);
            ms = time % 1000;
            newTime = pad(m, 2) + ':' + pad(s, 2) + ':' + pad(ms, 3);
            return newTime;
        },
        // Update Recording Control
        updateRecordingTime: function (time) {

            if (this.timerCounter > 0)
                $("#RecordingTime", this.domNode).text(this.formatTime(time));
            //RecordingTime
        },
        // To initiate component
        startup: function () {
            var self = this;
            dom = this.domNode;
            self.inherited(arguments);
            ko.applyBindings(self.viewModel, $(dom).get(0));
            var fileName = $("#aFileName", this.domNode);
           
            //DOJO Upload Component  Initialization
            if (!self.isReadOnly) {
                var aUpload = $("#aUpload", this.domNode);
                $(aUpload).fileupload({
                    dataType: 'json',
                    autoUpload: false,
                    maxFileSize: 5000000,
                    url: self.Urls.GetAudioFileDataUrl,
                    formData: { isIE: !(navigator.userAgent.toLowerCase().indexOf('trident') == -1) },
                    done: function (e, data) {

                        $.AjaxLoader.hideLoader();
                        if (data.result.Success) {
                            dom = this.domNode;
                            //file size validation for IE9
                            if (data.result.fileSize > 10) {
                                self.audioProperties.isValid = false;
                                self.resetAudioControls();
                                self.ToggleButtons(false);
                                self.viewModel.fileStream("");
                                oFileName = $("#aFileName", dom);
                                oFileName.val('');
                                oFileName[0].title = '';
                                $('.warning').text("Audio file must be less than 10 MB");
                            } else {
                                fileData.files.clear();
                                fileData.originalFiles.clear();
                                self.stopAudio();
                                self.resetAudioControls();
                                self.viewModel.fileStream(data.result.audioData);
                                self.audioProperties.isValid = true;
                                self.audioProperties.isChanged = true;
                                self.viewModel.isChanged(true);

                                $("#playRecord", dom).prop('disabled', false);
                                $("#downloadRecord", dom).prop('disabled', false);
                                oFileName = $("#aFileName", dom);
                                oFileName.val(self.viewModel.fileName());
                                oFileName[0].title = self.viewModel.fileName();
                            }
                        } else if (data.result.HasErrors) {                            
                            $('.warning').text(data.result.HasErrors);
                        } else {

                        }
                        
                    },
                    error: function (e, data) {
                        fileData.files.clear();
                        fileData.originalFiles.clear();
                        $.AjaxLoader.hideLoader();
                    },
                    add: function (e, data) {
                        fileData = data;
                        $('.warning').text("");
                        $.each(data.files, function (index, file) {
                            var ext = file.name.split(".")[file.name.split(".").length - 1].toLowerCase();
                            switch (ext) {
                                //if .jpg/.gif/.png do something
                                case 'wav':
                                    {
                                        self.stopAudio();
                                        if (!self.performValidation(file)) {
                                            self.audioProperties.isValid = false;
                                            self.resetAudioControls();
                                            self.ToggleButtons(false);
                                            return false;
                                        }
                                        self.ToggleButtons(true);
                                        self.viewModel.fileName(file.name);
                                        fileName[0].title = self.viewModel.fileName();
                                        fileName[0].name = self.viewModel.fileName();
                                        AudioURL = "";
                                        // Submits the audio file after the selection
                                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.recording'), imageURL: self.Urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: self.audioProperties.resources.General_LoadingMessage }).showLoader();

                                        fileData.submit();
                                        break;
                                    }
                                    //if .zip/.rar do something else
                                default:
                                    self.viewModel.fileName("");
                                    self.audioProperties.isValid = false;
                                    self.resetAudioControls();
                                    self.ToggleButtons(false);
                                    $("#aFileName").val("");
                                    fileName[0].title = self.viewModel.fileName();
                                    fileName[0].name = self.viewModel.fileName();
                                    $('.warning').text(self.Strings.Settings_AudioFile_AudioFilePattern);
                                    break;
                            } // end of switch case

                        }); // end of for-each
                    },
                });

                self.resetAudioControls();
                fileName[0].name = self.viewModel.fileName();
                fileName[0].title = self.viewModel.fileName();
            } else {
                //self.getAudioData();
                //to fix buttons visibility issue when it’s in Compatible view of review and publish  
                $("#btnBrowse", this.domNode).hide();
                $("#modalOnModal", this.domNode).hide();

            }
            // Initialize component buttons
            if (self.viewModel.fileName() != "") {
                this.ToggleButtons(true);

                //set file name tooltip in R&P play audio pop-up 
                //$('#uploader input[type=file]').addClass("btn hover");

                fileName[0].title = self.viewModel.fileName();
            } else
                this.ToggleButtons(false);

            // Component  
            this.emit("ready", {});
            $("#textBrowse").html(self.Strings.Settings_AudioFile_BrowseButton);
        },

        ToggleButtons: function (toggleFlag) {
            dom = this.domNode;
            if (!toggleFlag) {

                $(".btn-play", dom).parent().toggleClass('disabled', true);
                $(".btn-stop", dom).parent().toggleClass('disabled', true);
                if (navigator.userAgent.toLowerCase().indexOf('trident') == -1) {
                    $(".btn-play", dom).parent().toggleClass('hide', false);
                    $(".btn-stop", dom).parent().toggleClass('hide', true);
                    $(".btn-stop", dom).parent().toggleClass('disabled', true);
                }
                $(".btn-download-file", dom).parent().toggleClass('disabled', true);
            } else {

                $(".btn-play", dom).parent().toggleClass('disabled', false);
                $(".btn-stop", dom).parent().toggleClass('disabled', false);
                if (navigator.userAgent.toLowerCase().indexOf('trident') == -1) {
                    $(".btn-play", dom).parent().toggleClass('hide', false);
                    $(".btn-stop", dom).parent().toggleClass('hide', true);
                }
                $(".btn-download-file", dom).parent().toggleClass('disabled', false);
            }

        },

        // To get Audio Filestream based on AudioId
        getAudioData: function () {
            //TODO: Need to get the fileStream for the given audioId.
            //TODO: Enabled the Play and Download Buttons
            if (this.audioId != "" && this.audioId != undefined) {
                var self = this;
                var myAjaxOptions = {
                    type: "POST",
                    url: this.Urls.GetMediaFileUrl,
                    data: { id: this.viewModel.audioId() },
                    cache: false,

                    error: function (e) {
                    }
                };

                var successCallBack = function (data) {
                    self.viewModel.fileStream(data);
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, successCallBack).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

            }
            //else if (this.audioId == "" && this.isReadOnly) {
            //    //TODO: Label display
            //    $("#audioControls", dom).addClass("display-none");
            //    // TODO: remove the line after making the neccessary changes
            //    $("#noAudioFile", dom).removeClass("display-none");
            //}
        },

        // To show error message in cases of invalid audio input
        showValidation: function () {
            //Checking the validations
            $(".warning").text(this.Strings.AudioFile_IsRequired);
        },

        //To Perform validtion on Audio Component 
        performValidation: function (fileData) {
            if ($('#btnBrowse')[0].className.indexOf("disabled") > -1)
                return false;

            $('.warning').text("");
            var reqError = "";
            if (fileData.name != "" || fileData.name != undefined) {
                var allowedFiles = [".wav"];
                var regex = new RegExp(allowedFiles);
                if (!regex.test(fileData.name.toLowerCase())) {

                    this.ToggleButtons(false);
                    this.audioProperties.isValid = false;
                    this.ToggleButtons(false);
                    $("#aFileName").val(""); // need to check 
                    this.viewModel.fileName("");

                    $('.warning').text(self.Strings.AudioFile_Type);
                    return false;
                }
            }
            if (fileData.size > 0) {
                var sizeInMB = (fileData.size / (1024 * 1024)).toFixed(2);

                if (parseFloat(sizeInMB) > 10) {
                    this.audioProperties.isValid = false;
                    this.ToggleButtons(false);
                    $("#aFileName").val(""); // need to check 
                    this.viewModel.fileName("");
                    $('.warning').text(self.Strings.Alert_AudioFile_ErrorAudioSizeMsg);
                    return false;
                }
            }
            return true;
        },

        // To Reset Audio Component 
        resetAudioControls: function () {
            this.stopAudioStream();
            $("#uploader").toggleClass('disabled', false);
        },

        // To play audio file through component
        playAudio: function () {
            dom = this.domNode;
            if ($(".btn-play", dom).parent()[0].className.indexOf("disabled") > -1)
                return false;
            //Chrome or Firefox or Safari
            if (navigator.userAgent.toLowerCase().indexOf('trident') == -1) {
                var self = this;
                var audioData = this.viewModel.fileStream();
                if (self.viewModel.audioId() != "" && !self.viewModel.isChanged()) {
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.recording'), imageURL: self.Urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: self.audioProperties.resources.General_LoadingMessage }).showLoader();
                    var myAjaxOptions = {
                        type: "POST",
                        url: this.Urls.GetPlayAudioFileUrl,
                        data: { audioId: self.viewModel.audioId(), isChanged: self.viewModel.isChanged(), isIE: false},
                        cache: false,
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                        }
                    };
                    var successCallBack = function (data) {
                        self.viewModel.fileStream(data.audioData);
                        $.AjaxLoader.hideLoader();
                        self.playAudioStream();
                    };
                    var ajaxOptions = $.extend({}, AjaxUtility(null, successCallBack).ajaxPostOptions, myAjaxOptions);
                    $.ajax(ajaxOptions);
                } else {
                    self.playAudioStream();
                }
            }
                //IE
            else {
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.recording'), imageURL: this.Urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.audioProperties.resources.General_LoadingMessage }).showLoader();

                $("#bgPlay", dom).attr("src", this.Urls.GetPlayAudioFileUrl + "?audioId=" + this.viewModel.audioId() + "&isChanged=" + this.viewModel.isChanged() + "&isIE=" + true);
                $.AjaxLoader.hideLoader();
                //for IE Browse, Play, Stop and Download buttons should be enabled while playing..
                $(".btn-download-file", dom).parent().toggleClass('disabled', false);
                $(".btn-play", dom).parent().toggleClass('hide', false);
                // $(".btn-stop", dom).parent().toggleClass('hide', false);
                $("#modalOnModal").toggleClass('disabled', true);
                $("#btnBrowse").attr('disabled', false);
                $("#dvBrowse").toggleClass('disabled', false);
            }

        },
        isAudioRunning: function () {

            var bgPlay = $("#bgPlay", dom)[0];
            console.log(bgPlay.volume);
            //  if (bgPlay.src!=""0) {
            //      clearInterval(timer);
            //     this.stopAudio();
            //}

        },
        playAudioStream: function () {
            dom = this.domNode;
            var playButton = $("#audio", dom);
            playButton.on("ended", this.endedPlayAudio);
            playButton.on("timeupdate", this.timeUpdate);
            if (AudioURL != "")
                playButton.attr("src", recordedAudioData).trigger("play"); // Fix for IWS-27315 : Reading from converted getBase64 media data rather from blob Audio URL
            else {
                playButton.attr("src", "data:audio/wav;base64," + this.viewModel.fileStream()).trigger("play");
            }
            $(".btn-download-file", dom).parent().toggleClass('disabled', true);
            $(".btn-stop", dom).parent().toggleClass('disabled', false);
            if (navigator.userAgent.toLowerCase().indexOf('trident') == -1) {
                $(".btn-play", dom).parent().toggleClass('hide', true);
                $(".btn-stop", dom).parent().toggleClass('hide', false);
            }
            $("#uploader").toggleClass('disabled', true);
            $("#modalOnModal").toggleClass('disabled', true);
            $("#aUpload").parent().toggleClass('disabled', true);
            $('#uploader input[type=file]').prop('disabled', true);
            $("#btnBrowse").attr('disabled', true);
            $("#dvBrowse").toggleClass('disabled', true);
        },

        endedPlayAudio: function () {
            dom = this.domNode;
            $("#uploader").toggleClass('disabled', false);
            $(".btn-download-file", dom).parent().toggleClass('disabled', false);
            if ((navigator.userAgent.toLowerCase().indexOf('trident') == -1)) {
                $(".btn-play", dom).parent().toggleClass('hide', false);
                $(".btn-stop", dom).parent().toggleClass('hide', true);
            }
            $("#modalOnModal").toggleClass('disabled', false);
            $('#btnRecordAudio').toggleClass('disabled', false); // Enabled the Record button when Stop is clicked
            $('#btnUseRecording').toggleClass('disabled', false); // Enabled the Use Recording button when Stop is clicked
            $("#aUpload").parent().toggleClass('disabled', false);
            $('#uploader input[type=file]').prop('disabled', false);
            $("#RecordingTime", this.domNode).text(recordedLength);
            $("#btnBrowse").attr('disabled', false);
            $("#dvBrowse").toggleClass('disabled', false);
        },

        setAudioProperties: function (audioId, fileName, fileStream, recordedMessage) {
            var self = this;
            var dom = this.domNode;
            self.audioProperties.audioId = audioId;
            self.audioProperties.fileStream = fileStream;
            self.audioProperties.fileName = fileName;
            self.audioProperties.isRecordedMessage = recordedMessage != undefined ? recordedMessage : false;
            if (!self.audioProperties.isRecordedMessage)
                AudioURL = "";
            //define viewmodel here...
            self.viewModel = ko.mapping.fromJS(self.audioProperties);
            /*// KO Binding
            var dom = this.domNode;
            ko.cleanNode($(dom).get(0));
            ko.applyBindings(this.viewModel, $(dom).get(0));
            */

            var oFileName = $("#aFileName", this.domNode);
            oFileName.val(fileName);
            oFileName[0].title = fileName;

            if (fileName != null && fileName != "") {
                $(".btn-play", dom).parent().toggleClass('disabled', false);
                $(".btn-stop", dom).parent().toggleClass('disabled', false);
                $(".btn-download-file", dom).parent().toggleClass('disabled', false);
                if (navigator.userAgent.toLowerCase().indexOf('trident') == -1) {
                    $(".btn-stop", dom).parent().toggleClass('hide', true);
                }
            } else {
                $(".btn-play", dom).parent().toggleClass('disabled', true);
                $(".btn-stop", dom).parent().toggleClass('disabled', true);
                $(".btn-download-file", dom).parent().toggleClass('disabled', true);
                if (navigator.userAgent.toLowerCase().indexOf('trident') == -1) {
                    $(".btn-stop", dom).parent().toggleClass('hide', true);
                }
            }

            if ((self.audioProperties.fileName != null && self.audioProperties.fileName != "") || self.audioProperties.audioId != "") {
                self.audioProperties.isValid = true;
                self.viewModel.isChanged(false);
            } else
                self.audioProperties.isValid = false;
            // hide validation message
            $(".warning").text("");
            $("#aFileName", dom).prop('disabled', true);
        },

        setAudioId: function (audioId) {
            var self = this;
            self.audioProperties.audioId = audioId;
        },

        setAudioName: function (fileName) {
            var self = this;
            self.audioProperties.fileName = fileName;
            self.viewModel = ko.mapping.fromJS(self.audioProperties);
            // KO Binding
            var dom = this.domNode;
            ko.cleanNode($(dom).get(0));
            ko.applyBindings(this.viewModel, $(dom).get(0));
            var oFileName = $("#aFileName", this.domNode);
            oFileName[0].title = fileName;
            if (fileName != null && fileName != "") {
                $(".btn-play", dom).parent().toggleClass('hide', false);
                $(".btn-play", dom).parent().toggleClass('disabled', false);
                $(".btn-download-file", dom).parent().toggleClass('disabled', false);
                if (navigator.userAgent.toLowerCase().indexOf('trident')== -1) {
                    $(".btn-stop", dom).parent().toggleClass('hide', true);
                    $(".btn-stop", dom).parent().toggleClass('disabled', false);
                }
            } else {
                $(".btn-play", dom).parent().toggleClass('hide', false);
                $(".btn-play", dom).parent().toggleClass('disabled', true);
                $(".btn-download-file", dom).parent().toggleClass('disabled', true);
                if (navigator.userAgent.toLowerCase().indexOf('trident') == -1) {
                    $(".btn-stop", dom).parent().toggleClass('hide', true);
                    $(".btn-stop", dom).parent().toggleClass('disabled', true);
                }
            }
        },

        setFileStream: function (fileStream) {
            var self = this;
            self.audioProperties.fileStream = fileStream;
        },

        // To audio Properties from the component
        getAudioProperties: function () {
            this.viewModel.isValid = (this.viewModel.audioId() != '' || this.viewModel.fileName() != '') ? true : false;
            this.audioProperties = ko.mapping.toJS(this.viewModel);
            return this.audioProperties;
        },
        // To download audio file, Change this method to DOJO request call
        downloadAudio: function () {
            dom = this.domNode;
            if ($(".btn-download-file", dom).parent()[0].className.indexOf("disabled") > -1)
                return false;

            var fileName = this.viewModel.fileName();
            var audioData = this.viewModel.fileStream();
            var audioId = this.viewModel.audioId();
            var title = athoc.iws.publishing.content.viewModel.data.Title == undefined ? athoc.iws.publishing.view.viewModel.data.Content.Title() : athoc.iws.publishing.content.viewModel.data.Title();
            //bug
            if (!this.audioProperties.isBrowseSpecific && fileName != "")
                fileName = this.audioProperties.isRecordedMessage ? (fileName.replace('.WAV', ('_' + title + '.WAV'))) : fileName;

            $.fileDownload(this.Urls.GetDownloadAudioFileUrl, {
                httpMethod: "POST",
                data: { audioId: audioId, audioData: audioData, audioName: fileName },
                successCallback: function () {
                },
                failureCallback: function (error) {
                }
            });
        },
        //To stop the playing audio stream
        stopAudioStream: function () {
            dom = this.domNode;

            if (navigator.userAgent.toLowerCase().indexOf('trident') == -1)
                $("#audio", dom).attr("src", "");
            else
                $("#bgPlay", dom).attr("src", "");
        },
        // To Stop the playing Audio
        stopAudio: function () {
            dom = this.domNode;
            this.stopAudioStream();
            if (this.viewModel.fileName() != "")
                $(".btn-download-file", dom).parent().toggleClass('disabled', false);
            $("#uploader").toggleClass('disabled', false);
            if ((navigator.userAgent.toLowerCase().indexOf('trident') == -1)) {
                $(".btn-play", dom).parent().toggleClass('hide', false);
                $(".btn-stop", dom).parent().toggleClass('hide', true);
            }
            $("#modalOnModal").toggleClass('disabled', false);
            $("#aUpload").parent().toggleClass('disabled', false);
            $('#uploader input[type=file]').prop('disabled', false);
            $('#uploader .dijitUploader >span.dijitButtonNode').removeClass("dijitdisabled");
            //$('#uploader input[type=file]').removeClass("audioButtonDisabled");
            $("#btnBrowse").attr('disabled', false);
            $("#dvBrowse").toggleClass('disabled', false);
        },
        // To Show  Recording Popup
        showRecording: function () {

            this.stopAudio();


            $('#dialogRecordAudio').modal().css(
            {
                'z-index': '3000',

            });
            $('#dialogRecordAudio').modal('show');
            $('#dialogRecordAudio').find(".modal").css({ 'margin-top': '-182px', 'margin-left': '-151px' });
            $("#dialogRecordAudio").parent(0).append('<div id="displayRecord" class="modal-backdrop fade in"></div>');
            $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('hide', false); // Visible the Play button(Clicks on the use recording button when recorded  audio is playing) when the record popup is loaded
            $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('disabled', true); // Disabling the Play button when the record popup is loaded
            this.initializeRecordingProperties();
        },
        initializeRecordingProperties: function () {
            this.isRecording = false;
            $("#RecordingTime", this.domNode).text("0:00");
            $('#btnRecordAudio').attr("title", this.Strings.Alert_AudioFile_Record);
            $('#btnRecordAudio').text(this.Strings.Alert_AudioFile_Record);
            $('#btnRecordAudio').toggleClass('disabled', false); // Enabling the Record button (Clicks on the cancel button when recorded  audio is playing) when the record popup is loaded;
            $('#btnUseRecording').toggleClass('disabled', true); // Disabling the Use Reocrding button when the record popup is loaded
            $("#MaxRecordingTime").css('display', "inline-block");
            $("#MaxRecordingTime", this.domNode).text(Math.floor(self.maxRecordingTime / 60) + ":00");
            $(".warning").text("");
        },

        // Initializing Audio context
        initAudioContext: function () {
            try {
                // webkit shim
                window.AudioContext = window.AudioContext || window.webkitAudioContext || window.mozAudioContext;
                navigator.getUserMedia = (navigator.getUserMedia ||
                                 navigator.webkitGetUserMedia ||
                                 navigator.mozGetUserMedia ||
                                 navigator.msGetUserMedia);
                window.URL = window.URL || window.webkitURL || window.mozURL;

                if (audio_context == null) // bug # 14451
                    audio_context = new AudioContext();

                console.log('Audio context set up.');
                console.log('navigator.getUserMedia ' + (navigator.getUserMedia ? 'available.' : 'not present!'));
                navigator.getUserMedia({ audio: true },  this.startUserMedia, function (e) {});
                this.isRecording = true; // TODO : Move to successcallback method of startUserMedia
            } catch (e) {
                console.warn('No web audio support in this browser!');
            }
        },

        // To create Media Stream
        startUserMedia: function (stream) {
            localStream = stream; // making sure that the stream is not garbage collected.
            var input = audio_context.createMediaStreamSource(stream);
            console.log('Media stream created.');
            recorder = new Recorder(input);

            if (recorder) {
                recorder.record();
                $("#RecordingTime", this.domNode).text("0:00");
                $("#MaxRecordingTime").css('display', "");
                $('#btnRecordAudio').attr("title", self.Resources.Alert_AudioFile_Stop);
                $('#btnRecordAudio').text(self.Resources.Alert_AudioFile_Stop);
                $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('hide', false);
                $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('disabled', true);
                $('#dialogRecordAudio').find(".btn-stop").parent().toggleClass('hide', true);
                startAt = (new Date()).getTime();
                $('#btnUseRecording').toggleClass('disabled', true);// Disabled the Use Recording button when Record is clicked
            }
            else {
                // Show error message on recording control if recording does not work for that instance
                $(".warning").text("");
            }
        },

        // To Record  an Audio through Component
        recordAudio: function () {
            if ($('#btnRecordAudio').text() == this.Strings.Alert_AudioFile_Record) {
                this.isRecording = false;
                recordedLength = 0;
                $("#MaxRecordingTime", this.domNode).css('display', "inline-block");
                $("#MaxRecordingTime", this.domNode).text(Math.floor(self.maxRecordingTime / 60) + ":00");
                this.initAudioContext();
            } else {
                this.stopRecording();
            }
        },
        stopRecording: function () {
            if (recorder != undefined) {
                recorder.stop();
                $("#RecordingTime", this.domNode).text(recordedLength);
                $("#MaxRecordingTime").css('display', "none");
                $('#btnRecordAudio').attr("title", this.Strings.Alert_AudioFile_Record);
                $('#btnRecordAudio').text(this.Strings.Alert_AudioFile_Record);
                $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('disabled', false);
                $('#dialogRecordAudio').find(".btn-stop").parent().toggleClass('hide', true);
                $("#btnUseRecording").toggleClass('disabled', false);
                $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('disabled', false);
                this.getAudioURL();
                recorder.clear();
                this.isRecording = false;
            }
        },
        // To Cancel an audio recording
        recordCancel: function () {
            $('#dialogRecordAudio').modal('hide');
            $("#deviceOptionTabBody").find('#displayRecord').remove();
            $("#audio", dom).attr("src", ""); // Stop playing the audio when cancel is clicked.
            $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('hide', false);
            $('#dialogRecordAudio').find(".btn-stop").parent().toggleClass('hide', true);
            if (typeof (recorder) != "undefined") 
                recorder.clear();
            if ($("#aFileName", dom).val() == "")
                $(".btn-download-file", dom).parent().toggleClass('disabled', true);
            AudioURL = "";
        },

        // To Play an recorded audio
        playRecordedAudio: function () {
            dom = this.domNode;
            $("#audio", dom).on("ended", this.endedPlayAudio);
            $("#audio", dom).on("timeupdate", this.timeUpdate);
            $("#audio", dom).attr("src", recordedAudioData).trigger("play"); // Fix for IWS-27315 : Reading from converted getBase64 media data rather from blob Audio URL
            $("#MaxRecordingTime").css('display', "none");
            $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('hide', true);
            $('#dialogRecordAudio').find(".btn-stop").parent().toggleClass('disabled', false);
            $('#dialogRecordAudio').find(".btn-stop").parent().toggleClass('hide', false);
            $('#btnRecordAudio').toggleClass('disabled', true); // Disabled the Record button when Play is clicked.
            $('#btnUseRecording').toggleClass('disabled', true);// Disabled the Use Recording button when Play is clicked


        },

        //To stop playing recorded audio
        stopRecordedAudio: function () {
            this.stopAudioStream(); // Stop playing the audio when cancel is clicked.
            $("#RecordingTime", this.domNode).text(recordedLength);
            this.timeUpdate();
            $("#MaxRecordingTime").css('display', "none");
            $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('hide', false);
            $('#dialogRecordAudio').find(".btn-stop").parent().toggleClass('hide', true);
            $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('disabled', false);
            $('#btnRecordAudio').toggleClass('disabled', false);// Enabled the Record button when Stop is clicked
            $('#btnUseRecording').toggleClass('disabled', false);// Enabled the Use Recording button when Stop is clicked

        },

        timeUpdate: function () {
            var duration = parseInt(document.getElementById("audio").duration);
            var currentTime = parseInt(document.getElementById("audio").currentTime);
            var timeLeft = currentTime;

            if (!isNaN(duration)) {
                var s = timeLeft % 60;
                var m = Math.floor(timeLeft / 60) % 60;
                s = s < 10 ? "0" + s : s;
                //m = m < 10 ? "0" + m : m;
                $("#RecordingTime", this.domNode).text(m + ":" + s);
            }
        },
        //To get recorded Audio URL
        getAudioURL: function () {
            recorder && recorder.exportWAV(function (blob) {
                AudioURL = URL.createObjectURL(blob);
            });
        },

        //To Updating the fileName and fileStream to viewModel
        useRecording: function () {
            //TODO: Need to form audioFileName 
            //TODO: Assign fileStream and fileName to viewModel
            this.stopAudioStream(); // Stop playing the audio when cancel is clicked.
            var self = this;
            if (recordedAudioData != "") {
                //+ self.audioProperties.templateName

                var vpstimeformat = ($.getVPSLocalDateTime(new Date(), $.getMomentDateTimeFormat($.vpsTimeZone.dateTimeFormat))).replace(' ', '_');
                var fileName = self.audioProperties.operator + '_' + vpstimeformat.replace(' ', '_') + '.WAV';
                self.setAudioProperties(self.audioProperties.audioId, fileName, recordedAudioData.split(',')[1], true);
                //recordedAudioData = ""; // // Fix for IWS-27315 : We need to persist this data as long as AudioURL is valid. Also, when new object is created it is refreshed.
                $('#dialogRecordAudio').parent(0).find('#displayRecord').remove();
                $('.modal-backdrop.in')[2].remove(); //removing the div 
                $('#dialogRecordAudio').modal('hide');
                self.viewModel.isChanged(true);
            }
            else {
                // display error message if recorded message not available to pass to main popup(device options)
                $(".warning").text(this.Strings.AudioFile_AudioFile_Required);

            }
        },


        // To trigger Knock Validation in case of invalid file selectio       
        getValidation: function () {
            var validationMapping = {
                fileName: {
                    create: function (options) {
                        return ko.observable(options.data).extend({
                            required: true,
                            pattern: {
                                message: 'Audio file must be a WAV file',
                                params: ".*\.(WAV|wav)$"
                            }
                        });
                    }
                },
            };

            return validationMapping;
        },

        destroy: function () {
            this.inherited(arguments);
        }
    });

    return audioUploader;

});