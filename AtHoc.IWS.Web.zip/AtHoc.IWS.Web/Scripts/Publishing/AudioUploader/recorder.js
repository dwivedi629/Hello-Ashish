(function (window) {

    var WORKER_PATH = audioUploader.urls.WorkerUrl;

    var Recorder = function (source, cfg) {
        var config = cfg || {};
        var bufferLen = config.bufferLen || 4096;
        var numChannels = config.numChannels || 2;
        this.context = source.context;
        this.node = (this.context.createScriptProcessor ||
                     this.context.createJavaScriptNode).call(this.context,
                     bufferLen, numChannels, numChannels);
        var worker = new Worker(config.workerPath || WORKER_PATH);
        worker.postMessage({
            command: 'init',
            config: {
                sampleRate: this.context.sampleRate,
                numChannels: numChannels
            }
        });
        var recording = false, currCallback, min = 0, timeCounter = 0, timerFrequency = (navigator.userAgent.indexOf('Firefox') != -1) ? 0.094 : 0.0865;

        this.pad=   function (num, size) {
            var s = "0000" + num;
            return s.substr(s.length - size);
        }
        this.formatTime = function (time) {
            var h = m = s = ms = 0;
            m = Math.floor( time / (60 * 1000) );
            time = time % (60 * 1000);
            s = Math.floor(time / 1000);
            ms = time % 1000;
            newTime = recorder.pad(m, 1) + ':' + recorder.pad(s, 2) ;
            return newTime;
        }
        this.stopRecording = function () {
           
            recorder.stop();
            $("#RecordingTime", this.domNode).text(recordedLength);
                $('#btnRecordAudio').attr("title", "Record");
                $('#btnRecordAudio').text("Record");
                $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('disabled', false);
                $('#dialogRecordAudio').find(".btn-stop").parent().toggleClass('hide', true);
                $("#btnUseRecording").toggleClass('disabled', false);
                $("#MaxRecordingTime", dom).css('display', "none");
                $('#dialogRecordAudio').find(".btn-play").parent().toggleClass('disabled', false);
               
                recorder.getAudioURL();
                recorder.clear();
              
            
        }
        this.getAudioURL= function () {
            recorder && recorder.exportWAV(function (blob) {
                AudioURL = URL.createObjectURL(blob);
            });
        }

        this.node.onaudioprocess = function (e)
        {
            if (!recording) return;

            timeCounter++;
           
            if (recordedLength == recorder.formatTime(maxRecordingTime * 1000))
            {
                recording = false;
                timeCounter = 0;
                recorder.stopRecording();
                return;
            } 
           

            var buffer = [];
            for (var channel = 0; channel < numChannels; channel++) {
                buffer.push(e.inputBuffer.getChannelData(channel));
            }
            recordedLength = recorder.formatTime(timeCounter * 1000 * timerFrequency);
            $("#RecordingTime", this.domNode).text(recorder.formatTime(timeCounter * 1000 * timerFrequency));

            worker.postMessage({
                command: 'record',
                buffer: buffer
            });
          
        }

        this.configure = function (cfg) {
            for (var prop in cfg) {
                if (cfg.hasOwnProperty(prop)) {
                    config[prop] = cfg[prop];
                }
            }
        }

        this.record = function () {
            recording = true;
        }

        this.stop = function () {
            recording = false;
        }

        this.clear = function () {
                
            recording = false;
            worker.postMessage({ command: 'clear' });
        }

        this.getBuffer = function (cb) {
            currCallback = cb || config.callback;
            worker.postMessage({ command: 'getBuffer' });
        }

        this.exportWAV = function (cb, type) {
            currCallback = cb || config.callback;
            type = type || config.type || 'audio/wav';
            if (!currCallback) throw new Error('Callback not set');
            worker.postMessage({
                command: 'exportWAV',
                type: type
            });
        }

        worker.onmessage = function (e) {
            var blob = e.data;
            getBase64(blob); // Converting audio file into base64 
            currCallback(blob);
        }

        source.connect(this.node);
        this.node.connect(this.context.destination);    //this should not be necessary
    };
    function getBase64(wavData) {
        var reader = new window.FileReader();
        reader.readAsDataURL(wavData);
        reader.onloadend = function () {
            recordedAudioData = reader.result;
        }
    }
    Recorder.forceDownload = function (blob, filename) {
        var url = (window.URL || window.webkitURL).createObjectURL(blob);
        var link = window.document.createElement('a');
        link.href = url;
        link.download = filename || 'output.wav';
        var click = document.createEvent("Event");
        click.initEvent("click", true, true);
        link.dispatchEvent(click);
    }

    window.Recorder = Recorder;

})(window);
