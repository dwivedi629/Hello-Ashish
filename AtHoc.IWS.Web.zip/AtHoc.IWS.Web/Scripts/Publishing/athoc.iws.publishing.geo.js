﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.geo = function () {
        return {
            viewModel: {
                geoTargetingEnabled: ko.observable(true),

                //geo location
                isGeoSelected: ko.observable(false),

                geoImageUrl: ko.observable(''),

                shapes: ko.observable([]),

                isUsersTargeted: ko.observable(false),

                isOrganizationsTargeted: ko.observable(false),

                usersCount: ko.observable(0),

                organizationsCount: ko.observable(0),

                onTargetUserByAreaChange: function () {
                    if (!athoc.iws.publishing.geo.viewModel.isUsersTargeted())
                        athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria(0);
                    else
                        athoc.iws.publishing.geo.updateTargetingSummary();
                    athoc.iws.publishing.geo.updateContactPieChart();
                    return true;
                }
            },

            geoJson: null, //stores geoJson for currently loaded alert/scenario
            geoTargetMap: null, //map component
            miniMap: null,

            //triggered onload, function can have any load logic
            load: function () {
                //athoc.iws.publishing.geo.loadMap();
            },

            //load map component
            loadMap: function () {

                /*IWS-19267 
                1) removed esri minimap reference. 
                2) commented minimap creation using esri
                3) commented restoring geo coordinates for minimap
                4) called new method called bindAlertMiniMap
                5) impelemted GeoTargetingSummary maps  using leaflet on screen and r&p window 
                
                */
                //require(["maps/GeoTargetMap", "maps/MiniMap"], function (GeoTargetMap, MiniMap) {
                require(["maps/GeoTargetMap"], function (GeoTargetMap) {
                    athoc.iws.publishing.geo.geoTargetMap = new GeoTargetMap({ i18n: athoc.iws.publishing.mapResources, culture: languageParams.currentCulture }, "geoTargetMapHolder");

                    /* IWS-19267 - commnted out min map code implementation using esri. */

                    //athoc.iws.publishing.geo.miniMap = new MiniMap(null, "miniMapHolder");

                    athoc.iws.publishing.geo.geoTargetMap.startup();
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.on("orgTargetComplete", function (e) {
                        if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                            //e.orgIds
                            athoc.iws.publishing.targetOrg.OrgViewModel.OrgCountByArea(e.selectedOrgs);
                            athoc.iws.publishing.targetOrg.OrgViewModel.SelectedOrgsByArea(e.orgIds);
                        }
                    });

                    athoc.iws.publishing.geo.geoTargetMap.on("close", function () {
                      
                        athoc.iws.publishing.geo.geoJson = athoc.iws.publishing.geo.geoTargetMap.toGeoJson();
                        if (!athoc.iws.publishing.geo.geoJson || !athoc.iws.publishing.geo.geoJson.features || athoc.iws.publishing.geo.geoJson.features.length === 0) {
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                            athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                            athoc.iws.publishing.geo.updateTargetingSummary();
                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(false);
                            athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(false);
                            if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                                athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(false);
                            }
                        } else {
                            athoc.iws.publishing.content.dataChanged();
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                            athoc.iws.publishing.content.viewModel.isGeoSelected(true);

                            /*IWS-19267 - commented out restoring selected shape coordinates using esri mini map*/

                            //athoc.iws.publishing.geo.miniMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                            //athoc.iws.publishing.geo.miniMap.restore(athoc.iws.publishing.geo.geoJson);

                            /*IWS-19267 - calling new method to bind selected shape coordinates in leaflet map*/
                            athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);

                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(athoc.iws.publishing.geo.geoTargetMap.isTargetingUser);
                            athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg);
                            if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                                athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg);
                            }
                            athoc.iws.publishing.geo.updateTargetingSummary();
                        }
                        athoc.iws.publishing.geo.updateContactPieChart();
                        athoc.iws.publishing.content.checkReadyNotReady();
                    });

                    $('#dialogGeoTargetingSummary').on('shown.bs.modal', function () {
                        /*IWS-19267 - removed olde code and impelemted using leaflet */

                        //if (!athoc.iws.publishing.geo.summaryMap) {
                        //    athoc.iws.publishing.geo.summaryMap = new MiniMap({ width: 980, height: 300 }, "dialogGeoTargetingSummaryContent");
                        //}
                        //athoc.iws.publishing.geo.summaryMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                        //athoc.iws.publishing.geo.summaryMap.restore(athoc.iws.publishing.geo.geoJson);
                        //setTimeout(function () {
                        //    athoc.iws.publishing.geo.summaryMap.resize();
                        //    athoc.iws.publishing.geo.summaryMap.zoomToFit();
                        //}, 500);


                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.geo.summaryMap) {
                                athoc.iws.publishing.geo.summaryMap = new Map("dialogGeoTargetingSummaryContent", { i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                            }
                            athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.summaryMap, athoc.iws.publishing.geo.geoJson);
                        });
                    });

                    /*IWS-19267 - removed olde code and impelemted using leaflet in R&P publish window binding to display in all places like home and alerts screen*/
                    //the second popup modal in review and publish page
                   
                    $('#dialogGeoPublish').on('shown.bs.modal', function () {
                        /* if (!athoc.iws.publishing.geo.summaryMapOnRP) {
                            athoc.iws.publishing.geo.summaryMapOnRP = new MiniMap({ width: 980, height: 300 }, "dialogGeoPublishContent");
                        }
                        athoc.iws.publishing.geo.summaryMapOnRP.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                        athoc.iws.publishing.geo.summaryMapOnRP.restore(athoc.iws.publishing.geo.geoJson);
                        setTimeout(function () {
                            athoc.iws.publishing.geo.summaryMapOnRP.resize();
                            athoc.iws.publishing.geo.summaryMapOnRP.zoomToFit();
                        }, 500); */

                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.view.summaryMapReadOnly) {
                                athoc.iws.publishing.view.summaryMapReadOnly = new Map("dialogGeoPublishContent", {
                                    i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.summaryMapReadOnly, athoc.iws.publishing.geo.geoJson);
                        });

                    });
                   


                });
            },


            /* IWS-19267 - Written new method to removing old ge coordinates then adding new geo coordinates*/
            bindAlertMiniMap: function (miniMap,geoLocationsJson) {
                if (miniMap != null || miniMap) {
                    miniMap.removeGeoJson();
                    miniMap.addGeoJson(geoLocationsJson);
                    miniMap.centerAt([0, 0]);
                    miniMap.zoomToFit();
                }
            },

            //called when geo targeting model gets binded
            bind: function (data, isUsersTargeted, isOrganizationsTargeted) {
                athoc.iws.publishing.geo.viewModel.isUsersTargeted(isUsersTargeted);
                athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(isOrganizationsTargeted);
                var geoJson = data != "" ? JSON.parse(data) : null;
                //if (data == null || data == '') {
                if (geoJson == null || geoJson.features.length == 0) {// condition to stop loading generic map.

                    athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                    athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                    athoc.iws.publishing.geo.viewModel.geoImageUrl('');
                } else {
                    if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                        athoc.iws.publishing.geo.loadMap();
                    }

                    athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                    athoc.iws.publishing.content.viewModel.isGeoSelected(true);
                    athoc.iws.publishing.geo.geoJson = JSON.parse(data);

                    athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();

                   
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.restore(athoc.iws.publishing.geo.geoJson);


                    /*IWS-19267- commented out restoring selected shape coordinates using esri mini map*/

                    //athoc.iws.publishing.geo.miniMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                    //athoc.iws.publishing.geo.miniMap.restore(athoc.iws.publishing.geo.geoJson);

                    /*IWS-19267 - written code to create mini map using leaflet and binding geo coordinates. this section will call while editing drafted alert*/
                    if (athoc.iws.publishing.geo.geoJson != "" || athoc.iws.publishing.geo.geoJson != null) {

                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.geo.miniMap) {
                                if (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content || !athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Collapsed) {
                                    athoc.iws.publishing.geo.miniMap = new Map("miniMapHolder", {i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                                    athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                                }
                            }
                            else {
                                athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                            }

                        });
                    }
                }

                //Binding
                if ($("#targetContentArea").length > 0) {
                    ko.cleanNode($("#targetContentArea").get(0));
                    ko.applyBindings(athoc.iws.publishing.geo.viewModel, $("#targetContentArea").get(0));
                }

                athoc.iws.publishing.geo.updateTargetingSummary();
            },

            //called to get model for persisting
            getModel: function () {
                //return shape data for persisting
                if (athoc.iws.publishing.geo.geoJson != null) {
                    return JSON.stringify(athoc.iws.publishing.geo.geoJson);
                } else {
                    return null;
                }
            },

            //add geo location, entry point when alert/scenario does not have any existing location
            add: function () {
                var params = {};
                params.isNewMap = false;
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap==null) {
                    athoc.iws.publishing.geo.loadMap();
                    params.isNewMap = true;
                }
                var isTargetByUserEnabled = (($("#targetArea").length > 0) && ($('#targetArea').css('display') != 'none'));
                if (isTargetByUserEnabled) {
                    isTargetByUserEnabled = (($("#publishing-user-edit").length > 0) && ($('#publishing-user-edit').css('display') != 'none'));
                }

                var isTargetOrganizationEnabled = (($(".org-by-area").length > 0) && ($('.org-by-area').css('display') != 'none'));
                if (isTargetOrganizationEnabled && ($("#alert-org-edit").length > 0)) {
                    isTargetOrganizationEnabled = ($('#alert-org-edit').css('display') != 'none');
                } else  if (isTargetOrganizationEnabled &&  ($("#targetOrgSection").length > 0)) {
                    isTargetOrganizationEnabled = ($('#targetOrgSection').css('display') != 'none');
                }

                if (isTargetByUserEnabled || isTargetOrganizationEnabled) {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(true);
                } else {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(false);
                }

                athoc.iws.publishing.geo.geoTargetMap.setUserTargetable(isTargetByUserEnabled);
                athoc.iws.publishing.geo.geoTargetMap.setOrgTargetable(isTargetOrganizationEnabled);

                athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();

                athoc.iws.publishing.geo.geoTargetMap.isTargetingUser = isTargetByUserEnabled;
                athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg = isTargetOrganizationEnabled;


                athoc.iws.publishing.geo.geoTargetMap.show(params);

                /*IWS-19267 - Creating mini map instance using leaflet*/
                require(["widget/Map"], function (Map) {

                    if (!athoc.iws.publishing.geo.miniMap) {
                        // updating map div visible
                        athoc.iws.publishing.content.viewModel.isGeoSelected(true);
                        athoc.iws.publishing.geo.miniMap = new Map("miniMapHolder", { i18n: athoc.iws.publishing.mapResources,zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                    }
                });
            },

            //remove/clear shapes
            remove: function () {
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                    athoc.iws.publishing.geo.loadMap();
                }
                athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                athoc.iws.publishing.geo.viewModel.geoImageUrl('');
                athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();
                athoc.iws.publishing.geo.geoJson = null;
                athoc.iws.publishing.geo.updateTargetingSummary();
                athoc.iws.publishing.geo.viewModel.isUsersTargeted(false);
                athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(false);
                if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                    athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(false);
                    athoc.iws.publishing.targetOrg.OrgViewModel.OrgCountByArea(0);
                    athoc.iws.publishing.targetOrg.OrgViewModel.SelectedOrgsByArea([]);
                }
                athoc.iws.publishing.geo.updateContactPieChart();
                athoc.iws.publishing.content.checkReadyNotReady();
            },

            //edit alert/scenario location
            edit: function () {
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                    athoc.iws.publishing.geo.loadMap();
                }
                var isTargetByUserEnabled = (($("#targetArea").length > 0) && ($('#targetArea').css('display') != 'none'));
                if (isTargetByUserEnabled) {
                    isTargetByUserEnabled = (($("#publishing-user-edit").length > 0) && ($('#publishing-user-edit').css('display') != 'none'));
                }

                var isTargetOrganizationEnabled = (($(".org-by-area").length > 0) && ($('.org-by-area').css('display') != 'none'));
                if (isTargetOrganizationEnabled && ($("#alert-org-edit").length > 0)) {
                    isTargetOrganizationEnabled = ($('#alert-org-edit').css('display') != 'none');
                } else if (isTargetOrganizationEnabled && ($("#targetOrgSection").length > 0)) {
                    isTargetOrganizationEnabled = ($('#targetOrgSection').css('display') != 'none');
                }

                if (isTargetByUserEnabled || isTargetOrganizationEnabled) {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(true);
                } else {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(false);
                }

                athoc.iws.publishing.geo.geoTargetMap.setUserTargetable(isTargetByUserEnabled);
                athoc.iws.publishing.geo.geoTargetMap.setOrgTargetable(isTargetOrganizationEnabled);

                /*athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();
                if (athoc.iws.publishing.geo.geoJson != null) {
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.restore(athoc.iws.publishing.geo.geoJson);
                } */

                athoc.iws.publishing.geo.geoTargetMap.isTargetingUser = athoc.iws.publishing.geo.viewModel.isUsersTargeted() && isTargetByUserEnabled;                
                athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg = athoc.iws.publishing.targetOrg.OrgViewModel && athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea() && isTargetOrganizationEnabled;

                athoc.iws.publishing.geo.geoTargetMap.show();
            },

            //reflect map selection in targeting summary
            updateTargetingSummary: function () {
                var objectCount = 0, nonPoint;
                if (athoc.iws.publishing.geo.geoJson
                    && athoc.iws.publishing.geo.geoJson.features
                    && athoc.iws.publishing.geo.viewModel.isUsersTargeted()) {
                    nonPoint = $.grep(athoc.iws.publishing.geo.geoJson.features, function (item, idx) {
                        return item.geometry.type.toLowerCase() !== 'point';
                    });
                    objectCount = nonPoint.length;
                }

                if(athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria)
                athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria(objectCount);
            },

            //update contact pie chart based on geo-location
            updateContactPieChart: function () {
                athoc.iws.publishing.targetUsers.updateContactInfo();
                athoc.iws.publishing.targetUsers.targetingChanged();
            },

            //apply map changes from add/edit dialog 
            applyMapChanges: function () {
                //TODO: apply map changes may be recalculate users (not sure yet)
            },

            //make a json call to get users and organizations based on selected area
            getUsersAndOrgsForSelectedArea: function () {
                //TODO: send shape information in ajax request and get user and organization
            },

        };
    }();
}