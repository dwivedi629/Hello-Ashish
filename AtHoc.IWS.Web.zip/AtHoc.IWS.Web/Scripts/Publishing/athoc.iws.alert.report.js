﻿var athoc = athoc || {}; 
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};

if (athoc.iws.alert) {
    athoc.iws.alert.Report = function () {
        var self = this;
        var _alertId = 0;
        var dim = 0; //0: user, 1: org, 2: mass, 3:Detail
        var viewModel = kendo.observable(
        {
            TargetedUserCount: 0,
            TargetedOrgCount: 0,
            TargetedMassCount: 0,
            TimeStamp: "",
            StatusTimeStamp: "",
            Status: "",
            StatusLocalized: "",
            TimeDiff:"",
            StatusMsg: function () {
                return kendo.format(athoc.iws.alert.report.resources.Alert_Report_AlertIs, this.get("StatusLocalized"));
            },
            RefreshReport: function (e) {               
                loadSummaryReports(_alertId);               
            },
            LoadDetailReport:function(e) {
                dim = 3;//need to reset dim
                var visible = athoc.iws.publishing.view.viewModel.loadTargetUsers();
                if (!visible) { //don't load again when clicking on the same tab...
                    athoc.iws.publishing.view.viewModel.loadTargetUsers(true);
                    loadAlert(_alertId);
                }
                $("#rptForm").show();//show form when data is ready to render.
            },
            loadTargetUser: false,
            LoadUserReport: function (e) {
                dim = 0;//need to reset dim
                var visible = $("#target-contentarea #second").is(":visible");
                if (!visible) { //don't load again when clicking on the same tab...
                    loadSummaryReports(_alertId);
                }
            },
            LoadOrgReport: function (e) {
                dim = 1;//need to reset dim
                var visible = $("#target-contentarea #third").is(":visible");
                if (!visible) {
                    loadSummaryReports(_alertId);
                }
            },
            LoadMassReport: function (e) {
                dim = 2;//need to reset dim
                var visible = $("#target-contentarea #four").is(":visible");
                if (!visible) {
                    loadSummaryReports(_alertId);
                }
            },
            UserVisible: function () {
                return this.get("TargetedUserCount") > 0;
            },
            OrgVisible: function () {
                return this.get("TargetedOrgCount") > 0;
            },
            MassVisible: function () {
                return this.get("TargetedMassCount") > 0;
            },

           
            HasFillCount: false,
            FillCount: 0,
            FillCountMet: false,
            FillCountMsg: function () {
                return this.get("FillCountMet")
                    ? kendo.format(athoc.iws.alert.report.resources.Alert_Report_FillCountMet1, this.get("FillCount"), this.get("FillCount"))
                    : kendo.format(athoc.iws.alert.report.resources.Alert_Report_FillCountNotMet, this.get("FillCount"));
            },
            EndBtnVisible: function () {
                return (this.get("Status") == "Live" || this.get("Status") == "Publishing") && athoc.iws.alert.report.IsAlertPublisher=='True';;
            },
            EndAlert: function () {
                var alertId = athoc.iws.publishing.detail.viewModel.EntityId;
                var alertTitle = athoc.iws.publishing.detail.viewModel.Content.Title;
                if (alertId != 0) {
                    var showProgressFunc = function () {
                        kendo.ui.progress($("#mainContainer"), true);
                    };
                    var hideProgressFunc = function () {
                        $("#mainContainer").css("position", "");
                        kendo.ui.progress($("#mainContainer"), false);
                    };
                    executeEndAlert(self)(alertId, alertTitle, showProgressFunc, hideProgressFunc);
                }
            },
            SaveAlert: function () {
                athoc.iws.alert.detail.saveReportAlertDetails(self.parameters.urls.SaveAlertUrl, true);
                //$(this).removeClass("active");

            }

        });

        this.parameters = {};

        this.init = function (args) {
            this.parameters = args;

            initBreadcrumb();
            kendo.bind($(".kendoBound"), viewModel);

            /*For vertical main Tabs*/
            var tabContainers = $('div#target-contentarea > div');

            $('ul.tabselect a.tab-button').click(function() {

                if (viewModel.get("Status") != "Ended"){ //Save will not be visible for ended alert
                    $('#btn_save_alert').toggle($(this).attr('id') == '#first' && athoc.iws.alert.report.IsAlertPublisher == 'True');
                    $('#btn_end_alert').toggle($(this).attr('id') != '#first' && athoc.iws.alert.report.IsAlertPublisher == 'True');
                }

                tabContainers.hide().filter($(this).attr('id')).show();

                $('ul.tabselect a.tab-button').removeClass('selected');
                $(this).addClass('selected');

                return false;
            });

            var charttable = $('div#charttable_container > div');

            $('span.chart-table-action a').click(function() {
                charttable.hide().filter($(this).attr('id')).show();
                $('span.chart-table-action a').removeClass('selected');
                $(this).addClass('selected');

                return false;
            });

            var chartsec = $('div#chart-container > div');

            $('div#chart-sec-links a').click(function() {
                chartsec.hide().filter($(this).attr('id')).show();

                $('div#chart-sec-links a').removeClass('selected');
                $(this).addClass('selected');

                return false;
            });


        };

        //load method, will be tirggered on document load
        this.load = function (id) {
            _alertId = id;
            athoc.iws.publishing.view.viewModel.loadTargetUsers(false); 
            loadAlert(id);
            bindBreadcrumb();

        };

        //code is added to convert the request from GET to POST in case of dowlnloading ExportDeliverySummaryReport
        this.ExportDeliverySummaryReport = function (params) {
            var form = document.createElement("form");
            var sUrl = "/client/ReportsViews/ExportDetailedReport.aspx?" + params;
            var form = document.createElement("form");
            document.body.appendChild(form);
            form.setAttribute("id", "tempForm");
            form.action = sUrl;
            form.method = "POST"; //"GET";
            form.target = "_self"
            form.submit();
            document.body.removeChild(form);
        };
        this.resources = {};

        var breadcrumbsModel = new BreadcrumbModel();

        var initBreadcrumb = function () {

            //Sub-level breadcrumb
            var alertReportBreadCrumb = new Breadcrumb('dlLink', self.resources.NavBar_Sent_Alerts, '', function () {
                athoc.iws.publishing.createRequest("./");
            });

            //Page breadcrumb
            var alertReportPageBreadCrumb = new PageBreadcrumb('reportPage', '', [alertReportBreadCrumb], '');

            breadcrumbsModel.addPage(alertReportPageBreadCrumb);
        };

        var bindBreadcrumb = function () {
            breadcrumbsModel.SelectedPage('reportPage');

            var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
            ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
            $.titleCrumb("pageBreadcrumbs");
        };

        var theme = 'flat'; //'bootstrap' 'metro'

        var loadAlert = function (id) {
            var loadTargetUsers = athoc.iws.publishing.view.viewModel.loadTargetUsers();
            if (typeof loadTargetUsers === 'undefined') { loadTargetUsers = 'true'; }

            var url = kendo.format("GetAlertDetail?id={0}&loadTargetUser={1}", id, loadTargetUsers);

            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: '/athoc-cdn/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

            var dlSuccess = function (data) {
                $(".publishing-detail").show();

                if (data.Success) {
                    initialize(data.Data);
                    bindDetailView(data);
                } else {
                    $.AjaxLoader.hideLoader();
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            };

            var dlAjaxOption =
            {
                type: "POST",
                url: url,
            };

            var ajaxOptions = $.extend({}, AjaxUtility(null, dlSuccess).ajaxPostOptions, dlAjaxOption);
            $.ajax(ajaxOptions);
        };
      
        var initialize = function (alert) {
            viewModel.set("Status", alert.AlertStatus);
            viewModel.set("TargetedUserCount", alert.TargetUsers.TargetedUserCountForLiveEndedAlert);

            if (viewModel.get("Status") == "Ended") {
                viewModel.set("StatusTimeStamp", "(" + self.resources.Alert_Report_Event_Ended_At_Text + ": " + alert.AlertScheduleSettings.ScheduleAlertpublishEndDateInput + ")");
            }

            athoc.iws.publishing.view.viewModel.TotalUsers(alert.TargetUsers.TargetedUserCountForLiveEndedAlert);            
            if(alert.rbt==null)
                viewModel.set("TargetedOrgCount", alert.TargetOrg.TargetedOrganizations.length);
            var selectedMassDevices = alert.MassDevices.filter(function (d) {
                return d.Selected;
            });
            if (alert.rbt == null)
                viewModel.set("TargetedMassCount", selectedMassDevices.length);

            //setting default dim here...
            if (viewModel.get("TargetedOrgCount") > 0 && viewModel.get("TargetedUserCount") < 1) {
                dim = 1;
            }
            else if (viewModel.get("TargetedMassCount") > 0 && viewModel.get("TargetedUserCount") < 1 && viewModel.get("TargetedOrgCount") < 1) {
                dim = 2;
            }

            if (alert.FillCount) {
                viewModel.set("FillCount", alert.FillCount.FillCount);
                viewModel.set("HasFillCount", true);
            }

            var status = ["Publishing", "Live", "Ended", "Scheduled"];
            if (status.indexOf(alert.AlertStatus) > -1) {
                //defaults to user report when alert is live.
                //$("#userTab").click();
                loadSummaryReports(_alertId);
                var tabs = ["#second", "#third", "#four"];
                if (athoc.iws.publishing.view.viewModel.loadTargetUsers() == false) {
                    $('div#target-contentarea > div').hide().filter(tabs[dim]).show();
                    //$('ul.tabselect a.tab-button').removeClass('selected');
                    $('ul.tabselect tab-button').removeClass('selected');
                    $($('ul.tabselect a.tab-button')[dim]).addClass('selected');
                    var interval = 60 * 1000; //auto refresh every min
                    setInterval(function () {
                        loadSummaryReports(_alertId);
                    }, interval);
                    var title = kendo.format(self.resources.Alert_Report_Title, alert.Content.Title, _alertId);
                    breadcrumbsModel.updateTitle(title);
                    $("#rptForm").show();//show form when data is ready to render.
                }
            }
                       
        };

        var StatusUpdateTimeStamp = function () {

            var days, hours, mins, seconds, timeRemain;
            timeRemain = viewModel.get("TimeDiff").split(":");

            if (timeRemain.length == 3)
            {
                hours=timeRemain[0];
                mins=timeRemain[1];
                seconds=timeRemain[2];
            }

            else if(timeRemain.length == 2)
            {
                days = timeRemain[0].replace("d", "");
                hours= timeRemain[1].replace("h", "");
            }

            if (viewModel.get("Status") == "Live") {
                if (days > 0) {
                    viewModel.set("StatusTimeStamp", kendo.format("( " + self.resources.Alert_Report_TimeSpan + " )", days, hours));
                } else {
                    viewModel.set("StatusTimeStamp", kendo.format("( " + self.resources.Alert_Report_TimeSpanHHMMSS + " )", hours, mins, seconds));
                }
            }
        }
        //bind publishing model to ui with knockout
        var bindDetailView = function (data) {

            athoc.iws.publishing.detail.bindFingerTabs();

            athoc.iws.publishing.detail.viewModel = data.Data;

            $.AjaxLoader.hideLoader();

            //remove old validation
            $(".warning").each(function () { $(this).parent().remove(); });

            athoc.iws.publishing.rbt = data.Data.rbt;
            athoc.iws.publishing.detail.bindReadonlyView(data.Data);

            athoc.iws.publishing.context = data.Data.Context;
            athoc.iws.publishing.contextName = data.Data.ContextName;
            athoc.iws.publishing.entityId = data.Data.EntityId;

            athoc.iws.publishing.targetByUserArea = data.Data.TargetUsers.TargetUsersByArea;

            athoc.iws.scenario.settings.ReadonlyViewModel.applysettings = data.Data.ScenarioSettings;
            athoc.iws.publishing.content.ReadonlyViewModel.data = data.Data;

            // apply place holder settings
            athoc.iws.alert.placeholder.bind(data.Data.CustomPlaceHolders);
            athoc.iws.publishing.alertOrgin = data.Data.AlertOrigin;
            // to bind  alert schedule settings
            athoc.iws.alert.schedule.bind(data.Data.ScenarioSettings, data.Data.AlertScheduleSettings);

            // Don't comment this, it needs to load the data for report
            //athoc.iws.publishing.targetOrg.load(data.Data.TargetOrg);

            //athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(data.Data.ScenarioSettings.Targeting.EnabledTargetingTypes);
            if (data.Data.rbt == null)
                athoc.iws.scenario.settings.ApplyOrgsettingsOnFingerTabs(data.Data.ScenarioSettings.Organization);

            applyAlertContentSettings(data.Data.ScenarioSettings.Content);

            athoc.iws.scenario.settings.applyCollapseSettingsOnAlert();

            athoc.iws.scenario.settings.isFillCountEnabled = data.Data.ScenarioSettings.Targeting.FillCount;
            //for Scenario always readonly=false
            //fill count summary can be readonly=true only when readonly is set scenario settings  and section is ready  
            //athoc.iws.publishing.fillcount.bind(data.Data, data.Data.Context == 1 ? false : (data.Data.ScenarioSettings.Targeting.Readonly == true && athoc.iws.publishing.targetUsers.isReadyToPublish == true));

            //after loading the data reset the changed flag to not changed
            athoc.iws.publishing.detail.setChanged(false);
            $(document).scrollTop(0);

            //for readonly content
            var readOnlyContentDom = $('#publishing-content-detail');
            var readOnlyContentExpandHeaderDom = $('#bucketTitle', readOnlyContentDom);
            var readOnlyExpandArrow = $('.expand-arrow-closed', readOnlyContentExpandHeaderDom);
            if (readOnlyExpandArrow.css('display') == 'block') {
                readOnlyContentExpandHeaderDom.on('click', function () {
                    /* IWS-20491 creating minimap using widget*/
                    if (!athoc.iws.publishing.view.readOnlyMapOtherCases && data.Data.Content.LocationGeo) {
                        require(["widget/Map"], function (WidgetMap) {
                            var reviewMapHolder = readOnlyContentDom.find(".readOnlyMiniMapHolder");
                            athoc.iws.publishing.view.readOnlyMapOtherCases = new WidgetMap(reviewMapHolder, { i18n: athoc.iws.alert.report.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMapOtherCases, JSON.parse(data.Data.Content.LocationGeo));
                        });
                    }
                    /*if (!athoc.iws.publishing.view.readOnlyMapResized) {
                        setTimeout(function () {
                            athoc.iws.publishing.view.readOnlyMapResized = true;
                            if (athoc.iws.publishing.view.readOnlyMap) {
                                athoc.iws.publishing.view.readOnlyMap.resize();
                                athoc.iws.publishing.view.readOnlyMap.zoomToFit();
                            }
                            if (athoc.iws.publishing.view.readOnlyMapInRP) {
                                athoc.iws.publishing.view.readOnlyMapInRP.resize();
                                athoc.iws.publishing.view.readOnlyMapInRP.zoomToFit();
                            }
                        }, 500);
                    }*/
                });
            }
            else
            {
                /* IWS-20491 creating minimap using widget*/
               
                if (!athoc.iws.publishing.view.readOnlyMapOtherCases && data.Data.Content.LocationGeo) {
                    require(["widget/Map"], function (WidgetMap) {
                        $('#first').show(); // showing parent div
                        var reviewMapHolder = readOnlyContentDom.find(".readOnlyMiniMapHolder");
                        athoc.iws.publishing.view.readOnlyMapOtherCases = new WidgetMap(reviewMapHolder, { i18n: athoc.iws.alert.report.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                        athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMapOtherCases, JSON.parse(data.Data.Content.LocationGeo));
                        $('#first').hide();
                    });
                }
                if (athoc.iws.publishing.view.readOnlyMapOtherCases) {
                    athoc.iws.publishing.view.readOnlyMapOtherCases.bindControllers();
                }
            }

            $("#txtReadOnlySearch").keyup(function (e) {
                $("#btn_readonlyusersearch").removeAttr('disabled');
                if ($.hotkeys.enter(e)) {
                    $('#pillContainer').show();
                    athoc.iws.publishing.iut.createReadOnlyUserList();
                }

            });
            
            $("#btn_readonlyusersearch").click(function () {
                $('#pillContainer').show();
                athoc.iws.publishing.iut.createReadOnlyUserList();
            });
           

            //var model = kendo.observable(data.Data);
            //kendo.bind($(".kendoBound"), model);
        };

        //To Show/Hide Location,Dropbox,Response option depending on settings on Scenarion & Alert page .
        var applyAlertContentSettings = function (content) {
            var targetDIV = "#publishing-content-detail";
            if (content.LocationEnabled && athoc.iws.publishing.view.viewModel.isGeoSelected())
                $(targetDIV).find("#dvContentLocation").css("display", "");
            else
                $(targetDIV).find("#dvContentLocation").css("display", "none");

            if (content.ResponseOptionEnabled) {
                $(targetDIV).find("#dvContentResponseOpt").css("display", "");
                $(targetDIV).find("#dvContentAddResponseOpt").css("display", "");
            } else {
                $(targetDIV).find("#dvContentResponseOpt").css("display", "none");
                $(targetDIV).find("#dvContentAddResponseOpt").css("display", "none");
            }

            if (content.DropboxEnabled) {
                $(targetDIV).find("#dvContentDropBox").css("display", "");
                // $(targetDIV).find("#dvContentMoreInfo").css("display", "");
            } else {
                $(targetDIV).find("#dvContentDropBox").css("display", "none");
                // $(targetDIV).find("#dvContentMoreInfo").css("display", "none");
            }
        };

        var createBarChart = function (items) {
            var barData = $.grep(items, function (v) {
                return v.ID == null && v.RecipientType != "NoResponse" && v.RecipientType != "Ack";
            });

            var max = barData[0] ? barData[0].Value : 0;
            var mapped = barData.map(function (d) {
                return {
                    category: d.Category,
                    value: d.Value,
                    max: max,
                    color: d.RecipientType == "Targeted" ? "#000000" : "#999999",
                    recipientType: d.RecipientType,
                    reverse: d.RecipientType == "NotSent",
                    alertId: _alertId,
                    showRBTlink: dim == 0,
                    userType: dim
                }
            }
            );

            var vm = kendo.observable({
                items: mapped,
                onChange: function(e) {
                    e.sender.progressWrapper.css({ "background-color": e.data.color });
                }
            });
            kendo.bind($("#barChart" + dim), vm);

           
        };

        var createfillCountMsg = function () {

            if (viewModel.get("HasFillCount"))
            {
                viewModel.set("FillCountMsg" , viewModel.get("FillCountMet")
                                   ? kendo.format(" ("+athoc.iws.alert.report.resources.Alert_Report_FillCountMet1+")", viewModel.get("FillCount"), viewModel.get("FillCount"))
                                   : kendo.format(" (" + athoc.iws.alert.report.resources.Alert_Report_FillCountNotMet + ")", viewModel.get("FillCount")));

                var vm = kendo.observable({
                    data: viewModel.get("FillCountMsg")
                });
                kendo.bind($("#fillcountmsg"), vm);
                }
        };

        var createSummaryReport = function (items) {
            createBarChart(items);
            createDonutChart(items);
            createfillCountMsg(items);
            $(".menu").kendoMenu({
                openOnClick: true
            });
            kendo.ui.progress($("#target-contentarea"), false);
            viewModel.set("TimeStamp", kendo.toString(new Date(), $.vpsDateTimeFormat));

            //apply custom button styles
            $(".arrow-box > span.k-link").addClass("btn btn-large btn-info btn-group-float-right dropdown-toggle");
            $(".arrow-box > span.k-link").css("width", "20px");
            $(".k-menu-group").find(".dropdown-div").removeClass("k-item k-state-default").addClass("dropdown-div");

            //apply for In Progress or Failed tooltip popover
            $(function () {
                $('[data-toggle="popover"]').popover({ trigger: "hover" });
            });

        };


        var createDonutChart = function (items) {
            var resp = $.grep(items, function (v) {
                return v.ID != null;
            });

            var data = [];
            if (resp != null && resp.length > 0) //explicit responses
            {
                data = $.grep(items, function (v) {
                    return v.ID != null || v.RecipientType === "NoResponse";
                });

            } else { //implicit responses
                data = $.grep(items, function (v) {
                    return v.RecipientType === "Ack" || v.RecipientType === "NoResponse";
                });
            }

            var fc = data.filter(function (d) {
                return d.FillCount != null;
            });
            if (fc != null && fc.length > 0) {
                viewModel.set("FillCountMet", fc[0].FillCount.FillCount == viewModel.get("FillCount"));
            }

            var chart = $("#donutChart" + dim).kendoChart({
                theme: theme,
                series: [
                    {
                        type: "donut",
                        categoryField: "Category",
                        field: "Value",
                        holeSize: 110,
                        data: data,
                    }
                ],
                legend: {
                    visible: false
                },
                tooltip: {
                    visible: true,
                    template: "#: category  # #: value #"
                },
            }).data("kendoChart");

            var legendItems = [];
            for (var i = 0; i < data.length; i++) {
                legendItems.push({
                    category: data[i].FillCount != null && data[i].FillCount.IsAnyFillCount ? (viewModel.get("FillCountMet")
                        ? kendo.format(athoc.iws.alert.report.resources.Alert_Report_FillCountAnyMet, viewModel.get("FillCount"), viewModel.get("FillCount"))
                        : kendo.format(athoc.iws.alert.report.resources.Alert_Report_FillCountAnyNotMet, viewModel.get("FillCount"))) : data[i].Category,
                    value: data[i].FillCount != null && data[i].FillCount.IsAnyFillCount ? (data[i].FillCount.FillCount + data[i].FillCount.AboveFillCount) : data[i].Value,
                    color: data[i].FillCount != null && data[i].FillCount.IsAnyFillCount ? null : chart.options.seriesColors[i % chart.options.seriesColors.length],
                    id: data[i].ID,
                    alertId: _alertId,
                    recipientType: data[i].RecipientType,
                    fc: data[i].FillCount,
                    bg: data[i].FillCount != null && data[i].FillCount.IsAnyFillCount ? '#ffffcc' : null,
                    isFlag: data[i].FillCount != null && data[i].FillCount.IsAnyFillCount ? true : false,
                    showRBTlink: dim == 0,
                    userType: dim
                });
            };

            var template = kendo.template($("#donutCenterTemplate").html());
            var summary = {
                sent: items.length > 0 ? items[1].Value : 0,
                responded: items.length > 0 ? items[3].Value : 0,
                notResponded: items.length > 0 ? items[items.length - 1].Value : 0 //last one is always not responded
            }
            var result = template(summary);
            $(".inner-content").html(result); //display summary in donut center

            var vm = kendo.observable({
                items: legendItems
            });
            kendo.bind($("#legend" + dim), vm);

            if (items.length > 0 && items[1].Value == 0) {
                //display a light grey chart to indicate 0 sent
                var ds = new kendo.data.DataSource({
                    data: [
                        {
                            "Value": 1,
                            "color": "#eeeeee"
                        }
                    ]
                });
                chart.setDataSource(ds);
                chart.setOptions({ tooltip: { template: athoc.iws.alert.report.resources.Alert_Report_NoAlerts } });
            }

            $(".lrow").hover(function () {
                chart.toggleHighlight(true, { category: $(this).attr("category") });
            }, function () {
                chart.toggleHighlight(false, { category: $(this).attr("category") });
            });
        };

        var loadSummaryReports = function (id) {
            kendo.ui.progress($("#target-contentarea"), true);
            var url = kendo.format("GetAlertTrackingSummaryData?id={0}&type=0&dim={1}", id, dim);
            var ds = new kendo.data.DataSource({
                transport: {
                    read: {
                        url: url,
                        cache: false //setting no cache since IE seems to use cache by default
                    }
                },
                error: function (e) {
                    AjaxUtility().athocKendoGridAjaxErrorHandler(e);//handle session timeout.
                }
            });

            ds.fetch(function () {
                var results = ds.at(0);
                if (results.status == 'Scheduled') {
                    $('#messagePanel2').messagesPanel({ messages: [{ Type: '1', Value: self.parameters.resources.Alert_Report_Not_Available }] });
                    $('#messagePanel2').next().hide();
                } else {
                    $('#messagePanel2').hide();
                    $('#messagePanel2').next().show();
                }

                createSummaryReport(results.items);
                viewModel.set("TimeStamp", results.currentVpsDateTime);               
                viewModel.set("Status", results.status);
                viewModel.set("StatusLocalized", results.statusLocalized);
                

                if (viewModel.get("Status") == "Ended")
                {
                    viewModel.set("StatusTimeStamp", "(" +self.resources.Alert_Report_Event_Ended_At_Text + ": " + results.alertEndAt + ")");
                }
                else
                {
                    viewModel.set("TimeDiff", results.remainingTime);
                    StatusUpdateTimeStamp();
                }

                if (results.restrictedUser) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '1', Value: self.resources.Alert_Report_Restricted_User_Text }] }, null);
                }
            });
        };



        var executeEndAlert = function (context) {
            return function (id, name, showProgressFunction, hideProgressFunction) {

                //check for userbase permission
                if (typeof showProgressFunction == "function") {
                    showProgressFunction();
                } else {
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: self.parameters.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: self.parameters.resources.General_LoadingMessage }).showLoader();
                }
                var myAjaxOptionsForModifyCheck = {
                    url: self.parameters.urls.CheckCanModifyUrl,
                    contentType: 'application/json',
                    dataType: 'json',
                    data: JSON.stringify([id]),
                    type: 'POST',
                };

                var executeOnCanModify = onSuccessForModifyCheck(name, id, hideProgressFunction);

                var onErrorForModifyCheck = function () {
                    $.AjaxLoader.hideLoader();
                };

                var ajaxOptionsForModifyCheck = $.extend({}, AjaxUtility(onErrorForModifyCheck, executeOnCanModify).ajaxPostOptions, myAjaxOptionsForModifyCheck);
                $.ajax(ajaxOptionsForModifyCheck);
            }
        };

        var onSuccessForModifyCheck = function (name, id, hideProgressFunction) {
            return function (data, textStatus, jqXHR) {

                if (typeof hideProgressFunction == "function") {
                    hideProgressFunction();
                } else {
                    $.AjaxLoader.hideLoader();

                }

                if (data.CanModify) {

                    setupAndShowDialog(name, self.parameters.resources.Alert_EndDialog_Title, self.parameters.resources.Alert_EndDialog_Body,
                        self.parameters.resources.Alert_Dialog_EndButton, self.parameters.resources.Alert_Dialog_CancelButton);

                    $(self.parameters.dialogButtonLabelSelector).off('click').on('click', function (e) {

                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: self.parameters.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: self.parameters.resources.General_LoadingMessage }).showLoader();

                        var myAjaxOptions = {
                            url: self.parameters.urls.EndAlertsUrl,
                            contentType: 'application/json',
                            dataType: 'json',
                            data: JSON.stringify([id]),
                            type: 'POST',
                        };

                        var onError = function () {
                            $.AjaxLoader.hideLoader();
                        };

                        var onSuccess = function (data, textStatus, jqXHR) {
                            if (data.Success == false) {
                                $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            }
                            else {
                                $("#btn_end_alert").hide();
                                $("#btn_save_alert").hide();
                                viewModel.set("Status", "Ended");
                                $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: self.parameters.resources.Alert_Ended_Sucess_Message }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());                                
                            }
                            $(self.parameters.dialogSelector).modal('hide');
                            $.AjaxLoader.hideLoader();
                        }

                        var ajaxOptions = $.extend({}, AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                        $.ajax(ajaxOptions);

                    });

                } else {
                    //show dialog                        
                    setupAndShowDialog(name, self.parameters.resources.Alert_CouldntEndDialog_Title, self.parameters.resources.Alert_CouldntEndDialog_Body,
                    "", self.parameters.resources.Alert_Dialog_OkButton, true);
                }
            }
        };

        var setupAndShowDialog = function (name, title, body, buttonLabel, cancelButtonText, hideActionButton) {

            var nameTags = "";
            nameTags += "<div class='mar-left10' title='" + $.htmlEncode(name).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(name) + "</div>";


            $(self.parameters.dialogItemListSelector).html("<div class='mar-top10'>" + nameTags + "</div>");
            $(self.parameters.dialogTitleSelector).html(title);
            $(self.parameters.dialogBodySelector).html(body);
            $(self.parameters.dialogButtonLabelSelector).html(buttonLabel).attr('title', buttonLabel);

            $(self.parameters.dialogCancelButton).html(cancelButtonText).attr('title', cancelButtonText);

            $(self.parameters.dialogButtonLabelSelector).show();

            if (typeof hideActionButton != "undefined") {
                if (hideActionButton) {
                    $(self.parameters.dialogButtonLabelSelector).hide();
                }
            }

            $(self.parameters.dialogSelector).modal('show');

        };
    };

}