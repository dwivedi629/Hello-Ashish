﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.massdevices = function () {
        return {
            isChanged: false,
            IsRightToLeft: false,
            isReadyToPublish: true,
            isInErrorState: false,
            selectedCount: 0,
            DeviceGroupOptions: new Array(),
            massDeviceList: ko.observableArray(),
            isLocationPresent: ko.observable(false),
            Parameters: new Array(),
            readOnlyModel: {
                massDeviceList: ko.observableArray(),
                showCustomText: function () {
                    if (this.CustomText) {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                        $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.resources.Publishing_Custom_Text);
                        var summaryDiv = $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP");
                        summaryDiv.html(this.CustomText());
                    }
                }
            },
            viewModel: {
                keyDict: {},
                context: this,
                massDeviceList: ko.observableArray(),
                IsAffiliate: ko.observable(false),
                launchMassDeviceOptions: function () {
                    if (athoc.iws.publishing.massdevices.isAnyMassDeviceSelected()) {
                        $(athoc.iws.publishing.massdevices.Parameters.dialogDeviceOptions).modal("show");
                        athoc.iws.utilities.resizeModalBasedOnScreen($(athoc.iws.publishing.massdevices.Parameters.dialogDeviceOptions), 600, 770, 20, 170);
                    }
                },
                subscribeLocationChanges: function () {
                    if (athoc.iws.publishing.geo && athoc.iws.publishing.geo.viewModel && athoc.iws.publishing.geo.viewModel.isGeoSelected) {
                        athoc.iws.publishing.geo.viewModel.isGeoSelected.subscribe(function (newvalue) {
                            if (newvalue) {
                                athoc.iws.publishing.massdevices.isLocationPresent(true);
                            } else {
                                athoc.iws.publishing.massdevices.isLocationPresent(false);
                            }
                            athoc.iws.publishing.massdevices.isMassDeviceReady();
                        });
                    }
                },
                subscribeEndPoints : function(massdevices) {
                    _.each(massdevices(), function(massdevice) {
                        _.each(massdevice.DeviceList(), function(device) {
                            device.SelectedUsers.subscribe(function(newValue) {
                                 athoc.iws.publishing.massdevices.isMassDeviceReady();
                            });
                        });
                    });
                }
            },
            init: function (parameters) {
                this.Parameters = parameters;
                var self = this;
                athoc.iws.publishing.massdevices.viewModel.subscribeLocationChanges();
            },
            load: function () {
            },

            loadEndPoints: function (url, data) {
                var deferred = $.Deferred();
                var dlAjaxOption =
               {
                   type: "POST",
                   url: url,
                   data: {
                       devices: data,
                   },
               };
                var ajaxSuccess = function (datawithendpoints) {
                    if (datawithendpoints) {
                        deferred.resolve(datawithendpoints);
                    } else {
                        console.log("EndPoints are invalid");
                        deferred.reject();
                    }
                };
                var ajaxError = function (data) {
                    console.log(data);
                    deferred.reject(data);
                };

                var ajaxOptions = $.extend({}, AjaxUtility(ajaxError, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
                return deferred.promise();
            },


            bind: function (data, IsReadOnly, readOnly, presetDeviceOptions) {

                var self = this;

                if (!data || data.length == 0) {
                    athoc.iws.publishing.massdevices.isMassDeviceReady();
                    return;
                }
             
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsMassDeviceTargetSupported) {
                    athoc.iws.publishing.massdevices.isMassDeviceReady();
                    return;
                }
                var deviceData = [];
                $.grep(data, function (item) {
                    deviceData.push({ DeviceId: item.DeviceId, CommonName: item.CommonName,EndPoints:[]});
                });
                console.log(athoc.iws.publishing.contextName);
                if (athoc.iws.publishing.contextName != "Scenario" && IsReadOnly) {

                    athoc.iws.publishing.massdevices.bindReadOnlyView(data, "#alert-mass-detail");
                } else {

                    var url = self.Parameters.getEndPointsURL;
                    var input = ko.toJS(deviceData);

                    kendo.ui.progress($("#publishing-mass-edit"), true);

                    $.when(athoc.iws.publishing.massdevices.loadEndPoints(url, input)).then(function (datawithendpoints) {
                        var setTargetingAndSelectionProp = function (fromData, toData) {
                            //Assigning End points Data to original Device data
                            var tempToData = fromData;
                            _.each(tempToData, function (fromDevice) {
                                var toDataDevice = _.find(toData, function (toDevice) {
                                    return fromDevice.DeviceId === toDevice.DeviceId;
                                });
                                _.each(fromDevice.EndPoints, function (fromEndPoint) {
                                    var toDataEndPoint = _.find(toDataDevice.EndPoints, function (toEndPoint) {
                                        return fromEndPoint.UserId === toEndPoint.UserId;
                                    })
                                    if (toDataEndPoint)
                                        toDataEndPoint.IsSelected = fromEndPoint.IsSelected;
                                });
                                if (toDataDevice) {
                                    fromDevice.EndPoints = toDataDevice.EndPoints;
                                    fromDevice.Enabled = toDataDevice.Enabled;
                                    fromDevice.ExtractFIPS = toDataDevice.ExtractFIPS;
                                    fromDevice.IsAreaRequired = toDataDevice.IsAreaRequired;
                                    fromDevice.HideMassDeviceUsers = toDataDevice.HideMassDeviceUsers;
                                }});
                            toData = tempToData;
                             
                            var selectedfromData = _.filter(fromData, function (selectedDevice) {
                                return selectedDevice.Selected;
                            });

                          
                           _.each(selectedfromData, function (fromDevice) {
                                var toDataDevice = _.find(toData, function(toDevice) {
                                    return fromDevice.DeviceId === toDevice.DeviceId;
                                });

                                if (toDataDevice) {
                                    _.each(toDataDevice.EndPoints, function(toEndPoint) {
                                       var fromEndPoint =  _.find(fromDevice.EndPoints, function(fromEndPointItem) {
                                           return fromEndPointItem.UserId === toEndPoint.UserId;
                                       });
                                       if (fromEndPoint) {
                                            toEndPoint.IsTargetable = fromEndPoint.IsTargetable;
                                            toEndPoint.IsSelected = fromEndPoint.IsSelected;
                                        }
                                    }); 
                                }
                           });
                            //Assigning back the updated device data
                           datawithendpoints = toData;
                        };
                        
                        setTargetingAndSelectionProp(data,datawithendpoints);
                        
                        athoc.iws.publishing.massdevices.selectedCount = 0;
                        athoc.iws.publishing.massdevices.massDeviceList.removeAll();
                        athoc.iws.publishing.massdevices.removeKeyUser(datawithendpoints,true);

                        ko.cleanNode($("#publishing-mass-edit").get(0));
                        athoc.iws.publishing.massdevices.viewModel.massDeviceList = ko.mapping.fromJS(athoc.iws.publishing.massdevices.formatMassDeviceList(datawithendpoints));
                        $("#massdevicesdisplay").html("");

                        ko.applyBindings(athoc.iws.publishing.massdevices.viewModel, $("#publishing-mass-edit").get(0));
                        athoc.iws.publishing.massdevices.viewModel.subscribeEndPoints(athoc.iws.publishing.massdevices.viewModel.massDeviceList);

                        if (athoc.iws.publishing.massdevices.viewModel.massDeviceList()[0].GroupName() != "")
                            $('#MassDeviceFlatList').show();
                        else
                            $('#MassDeviceFlatList').hide();

                        var onSave = function (selectedOptions) {
                            self.DeviceGroupOptions = selectedOptions;
                        }

                        $(".alert-nav").attr("disabled", true);
                        kendo.ui.progress($("#alert-mass-edit"), true);

                        var onLoadDone = function (selectedOptions) {
                            kendo.ui.progress($("#alert-mass-edit"), false);
                            $(".alert-nav").attr("disabled", false);

                            self.DeviceGroupOptions = selectedOptions;

                        }

                        athoc.iws.publishing.massDeviceOptions.load(datawithendpoints, presetDeviceOptions, onSave, onLoadDone);
                        athoc.iws.publishing.massdevices.collapsePanel();
                        athoc.iws.publishing.massdevices.isMassDeviceReady();

                        kendo.ui.progress($("#publishing-mass-edit"), false);

                    });

                }
            },

            removeKeyUser: function (data, canClear) {
                if (canClear) {
                    athoc.iws.publishing.massdevices.viewModel.keyDict = {};
                }
                _.each(data, function (device) {
                    var keyUser = _.find(device.EndPoints, function (endPoint) {
                        return endPoint.IsKeyUser ;
                    });
                    if (keyUser) {
                        athoc.iws.publishing.massdevices.viewModel.keyDict[device.DeviceId] = keyUser;
                        var index = device.EndPoints.indexOf(keyUser);
                        if (index > -1) {
                            device.EndPoints.splice(index, 1);
                        }
                    }
                });
            },


            //this method will be called when data is required for updating
            getModel: function () {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsMassDeviceTargetSupported)
                    return null;

                var devicedata = ko.observableArray();
                
                //create a deep copy of object
                var massdevices = ko.mapping.fromJS(ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList()));;
                
                _.each(massdevices(), function (massdevice) {
                    var selectedMassdevice = _.filter(massdevice.DeviceList(), function(selectedDevice) {
                        return selectedDevice.Selected();
                    });
                    _.each(selectedMassdevice, function (device) {
                        var endPointLength = device.EndPoints().length;
                        var deviceusers = ko.observableArray();
                        var keyListDict = athoc.iws.publishing.massdevices.viewModel.keyDict;
                        if (keyListDict) {
                            var enduser = keyListDict[device.DeviceId()];
                            if (enduser){
                                if (enduser.IsTargetable) {
                                    deviceusers.push(ko.mapping.fromJS(enduser));
                                }
                                if (endPointLength === 0) {
                                    device.EndPoints = deviceusers;
                                }
                            }
                        }
                        if (endPointLength == 1) {
                            var endPoint = device.EndPoints()[0];
                            if ((endPoint.IsKeyUser() && endPoint.IsTargetable()) ||
                                endPoint.IsSelected()) {
                                deviceusers.push(endPoint);
                            }
                            if (device.HideMassDeviceUsers() && !endPoint.IsSelected()) {
                                deviceusers.push(endPoint);
                            }
                            device.EndPoints = deviceusers;
                        } else if (endPointLength >= 2) {
                            _.each(device.SelectedUsers(), function(selectedendPoint) {
                                var selectedEndPoint = _.find(device.EndPoints(), function(endPointItem) {
                                    return endPointItem.UserId() === selectedendPoint && !endPointItem.IsKeyUser();
                                });
                                if (selectedEndPoint) {
                                    deviceusers.push(selectedEndPoint);
                                }
                            });
                            device.EndPoints = deviceusers;
                        }
                        devicedata.push(device);
                    });
                });
                var targetlist = athoc.iws.publishing.massdevices.viewModel.targetList = ko.mapping.toJS(devicedata);
                return { MassDevices: targetlist, MassDeviceGroupOptions: this.DeviceGroupOptions }
            },

            bindReadOnlyView: function (data, targetDiv) {
                athoc.iws.publishing.massdevices.massDeviceList.removeAll();
                athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList = ko.mapping.fromJS(athoc.iws.publishing.massdevices.formatMassDeviceList(athoc.iws.publishing.massdevices.filterDataforReadOnly(ko.mapping.fromJS(data))));;
                if (targetDiv[0].id !== "dialogReviewAndPublish") {
                    athoc.iws.publishing.massdevices.viewModel.massDeviceList = athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList;
                }
                ko.cleanNode($(targetDiv).find("#publishing-mass-view").get(0));
                ko.applyBindings(athoc.iws.publishing.massdevices.readOnlyModel, $(targetDiv).find("#publishing-mass-view").get(0));

                if (athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList()[0].DeviceList().length > 0)
                    $(targetDiv).find('#MassDeviceFlatList').show();
                else
                    $(targetDiv).find('#MassDeviceFlatList').hide();
            },

            collapsePanel: function () {
                $('.bucket-toggle h2').bind('click', function (e) {
                    if (e.target.id === "massDeviceOptionsLink") {
                        return;
                    }
                   if (!e.isDefaultPrevented()) {
                       $(this).parent().find('.row').slideToggle(500);
                       $(this).parent().find('.expand-arrow-open').toggle();
                       $(this).parent().find('.expand-arrow-closed').toggle();
                       if ($(this).find('#massDevicesStatus').length > 0) {
                           if ($(this).parent().find('.expand-arrow-open').css("display") === "block") {
                               $("#massDeviceOptionsLink").show();
                           } else {
                               $("#massDeviceOptionsLink").hide();
                           }
                       }
                   }
                   e.preventDefault();
                });
               
            },

            refreshMassDevicesList: function (data) {
                var massdevices = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList());
                var url = this.Parameters.getEndPointsURL;
                var deviceColl = [];
                var refreshViewModel = function (datawithendpoints) {
                    athoc.iws.publishing.massdevices.removeKeyUser(datawithendpoints,false);
                    athoc.iws.publishing.massdevices.viewModel.massDeviceList = ko.mapping.fromJS(athoc.iws.publishing.massdevices.formatMassDeviceList(datawithendpoints, true));
                    ko.cleanNode($("#publishing-mass-edit").get(0));
                    ko.applyBindings(athoc.iws.publishing.massdevices.viewModel, $("#publishing-mass-edit").get(0));
                    athoc.iws.publishing.massdevices.viewModel.subscribeEndPoints(athoc.iws.publishing.massdevices.viewModel.massDeviceList);
                    athoc.iws.publishing.massdevices.collapsePanel();
                    athoc.iws.publishing.massdevices.isMassDeviceReady();
                }
                $(data).each(function (item) {
                    var device = null;
                    for (var i = 0; i < massdevices.length; i++) {
                        device = _.find(massdevices[i].DeviceList, function (dev) {
                            return (dev.DeviceId === data[item].DeviceId);
                        });
                        if (device) {
                            data[item].HideMassDeviceUsers = device.HideMassDeviceUsers;
                            data[item].IsAreaRequired = device.IsAreaRequired;
                            athoc.iws.publishing.massdevices.selectedCount++;
                            data[item].Selected = device.Selected;
                            data[item].EndPoints = device.EndPoints;
                            data[item].SelectedUsers = device.SelectedUsers;
                            if (data[item].EndPoints.length == 0) {
                                data[item].Enabled = false;
                            } else {
                                data[item].Enabled = true;
                            }
                            break;
                        }
                    }
                    if (!device) {
                        deviceColl.push(data[item]);
                    }

                });

                if (deviceColl.length > 0) {
                    kendo.ui.progress($("#publishing-mass-edit"), true);

                    $.when(athoc.iws.publishing.massdevices.loadEndPoints(url, deviceColl)).then(function (datawithendpoints) {
                        _.each(datawithendpoints, function (item) {
                            var dev = _.find(data, function (item2) {
                                return item.DeviceId === item2.DeviceId;
                            });
                            dev.Selected = false;
                            dev.EndPoints = item.EndPoints;
                            dev.IsAreaRequired = item.IsAreaRequired;
                            dev.HideMassDeviceUsers = item.HideMassDeviceUsers;
                            if (dev.EndPoints.length == 0) {
                                dev.Enabled = false;
                            } else {
                                dev.Enabled = true;
                            }
                        });
                        refreshViewModel(data);

                        kendo.ui.progress($("#publishing-mass-edit"), true);

                    });
                } else {
                    refreshViewModel(data);
                }
            },

            filterDataforReadOnly: function (data) {
                var filterData = ko.mapping.toJS(data).filter(function (el) {
                    return el.Selected;
                });
                return filterData;
            },

            formatMassDeviceList: function (data, justFormat) {
                var groupList = [];
                var deviceList = [];
                var groupId = 0;
                var groupName = "";
                var filterData = data;
                var skipDevices = false;
                if (justFormat !== undefined) {
                    skipDevices = true;
                }
                $(filterData).each(function (index) {
                   if (groupId != filterData[index].GroupId) {

                        if (deviceList.length > 0) {
                            groupList.push({ GroupId: groupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                            deviceList = [];
                        }

                        deviceList.push(filterData[index]);
                        //if (filterData[index].Selected) {
                        if (!skipDevices) {
                            athoc.iws.publishing.massdevices.massDeviceList.push(filterData[index]);
                        }
                        athoc.iws.publishing.massdevices.selectedCount++;
                        //}
                        groupName = filterData[index].GroupName;
                        groupId = filterData[index].GroupId;

                    } else {
                        //if (filterData[index].Selected) {
                        if (!skipDevices) {
                            athoc.iws.publishing.massdevices.massDeviceList.push(filterData[index]);
                        }
                        athoc.iws.publishing.massdevices.selectedCount++;
                        //}

                        deviceList.push(filterData[index]);
                    }

                });
                groupList.push({ GroupId: groupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                return groupList;
            },

            readonlyMassDeviceList: function (data) {
                var groupList = [];
                var deviceList = [];
                var groupId = 0;
                var groupName = "";
                var filterData = data;

                $(filterData).each(function (index) {
                    if (groupId != filterData[index].GroupId) {
                        groupId = filterData[index].GroupId;

                        if (deviceList.length > 0) {
                            groupList.push({ GroupId: filterData[index].GroupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                            deviceList = [];
                        }

                        deviceList.push(filterData[index]);
                        groupName = filterData[index].GroupName;
                    } else {

                        deviceList.push(filterData[index]);
                    }

                });
                groupList.push({ GroupId: groupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                return groupList;

            },

            endPointSelected:function(device,arg) {
                device.EndPoints()[0].IsSelected(arg.originalEvent.target.checked);
                athoc.iws.publishing.massdevices.isMassDeviceReady();
                return true;
            },

            massDeviceChanged: function (device) {
                athoc.iws.publishing.massdevices.isChanged = true;
                var self = this;
                if (device.Selected()) {
                    athoc.iws.publishing.massdevices.massDeviceList.push(ko.mapping.toJS(device));
                    athoc.iws.publishing.massdevices.selectedCount++;

                    $(".alert-nav").attr("disabled", true);
                    kendo.ui.progress($("#alert-mass-edit"), true);

                    var onLoadDone = function (selectedOptions) {

                        kendo.ui.progress($("#alert-mass-edit"), false);
                        $(".alert-nav").attr("disabled", false);
                        athoc.iws.publishing.massdevices.DeviceGroupOptions = selectedOptions;
                    }


                } else {
                    athoc.iws.publishing.massdevices.massDeviceList.remove(function (item) {
                        return item.DeviceId == device.DeviceId();
                    });
                    athoc.iws.publishing.massdevices.selectedCount--;
                }

                var checkedDevices = new Array();
                var mlist = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList);
                for (var i = 0; i < mlist.length; i++) {
                    for (j = 0; j < mlist[i].DeviceList.length; j++) {
                        var device = mlist[i].DeviceList[j];
                        if (device.Selected) {
                            checkedDevices.push(mlist[i].DeviceList[j]);
                        }
                    }
                }

                athoc.iws.publishing.massDeviceOptions.loadOnlyNewDeviceGroups(checkedDevices, onLoadDone);

                $(athoc.iws.publishing.massdevices.Parameters.massDeviceOptionsLink).toggleClass("link-disabled", (checkedDevices.length == 0));

                athoc.iws.publishing.massdevices.isMassDeviceReady();
                return true;
            },
            isAnyMassDeviceSelected: function () {
                var mlist = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList);
                for (var i = 0; i < mlist.length; i++) {
                    for (j = 0; j < mlist[i].DeviceList.length; j++) {
                        var device = mlist[i].DeviceList[j];
                        if (device.Selected) {
                            return true;
                        }
                    }
                }
                return false;

            },
            isMassDeviceReady: function () {
                var notReady = function () {
                    athoc.iws.publishing.massdevices.isReadyToPublish = false;
                    athoc.iws.publishing.massdevices.isInErrorState = true;
                    athoc.iws.publishing.SetSectionStatus("#massDevicesStatus", "notReady");
                };
                var ready = function () {
                    athoc.iws.publishing.massdevices.isReadyToPublish = true;
                    athoc.iws.publishing.massdevices.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#massDevicesStatus", "ready");
                };
                var open = function () {
                    athoc.iws.publishing.massdevices.isReadyToPublish = false;
                    athoc.iws.publishing.massdevices.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#massDevicesStatus", "open");
                };
                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
                if (massDeviceModel && massDeviceModel.MassDevices && massDeviceModel.MassDevices.length > 0) {
                    var selectedDevices = $.grep(massDeviceModel.MassDevices, function (device) {
                        return device.Selected;
                    });
                    if (selectedDevices.length == 0) {
                        open();
                    } else {
                        ready();
                    }
                    _.each(massDeviceModel.MassDevices, function (device) {
                        if (!device.EndPoints || device.EndPoints.length == 0) {
                            notReady();
                        }
                        if (device.IsAreaRequired)
                            if (!athoc.iws.publishing.massdevices.isLocationPresent()) {
                                notReady();
                            }
                    });
                } else {
                    open();
                }
            },

            handleError: function (e) {
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },
            targetKeyUser: function (groupid, select, elementId) {
                var massdevices = athoc.iws.publishing.massdevices.viewModel.massDeviceList();
                var keyListDict = athoc.iws.publishing.massdevices.viewModel.keyDict;
                var endPointFound = false;
                for (var i = 0; i < massdevices.length; i++) {
                    var massdevice = massdevices[i];
                    for (var j = 0; j < massdevice.DeviceList().length; j++) {
                        var device = massdevice.DeviceList()[j];
                        if (groupid === device.GroupId()) {
                            if (keyListDict) {
                                var keyuser = keyListDict[device.DeviceId()];

                                if (keyuser) {
                                    if (select) {

                                        if (typeof elementId != "undefined") //must apply targeting not allowed changes 
                                        {

                                            var className = $('select[id^="' + $("input:radio[name='" + elementId + "']:checked").attr("id") + '"]').find("option:selected").attr("class");
                                            if (className == "MSG-TARGETING-NOT-ALLOWED") {
                                                //if ($('[name="' + elementId + '"]').find(":selected").attr("class") == "MSG-TARGETING-NOT-ALLOWED") {
                                                //$("input:radio[name='" + elementId + "']:checked")
                                                //unselect all of the non-key users
                                                device.SelectedUsers([]);

                                                //disable dropdown
                                                if ($("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").length !=0)
												{
													$("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").prop("disabled", true);
													device.EndPoints()[0].IsSelected(false); //uncheck checkbox
												}
												

                                                $("[deviceidentifier='" + device.DeviceId() + "']").find(".show-tick").css('pointer-events', 'none');
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").attr("disabled", true);
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").selectpicker('refresh');
                                                $("[deviceidentifier='" + device.DeviceId() + "']").find("button").prop("disabled", true)


                                            } else {
                                                //enble dropdown
                                                
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").attr("disabled", false);
												if ($("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").length !=0)
												{
													$("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").prop("disabled", false);

												}
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").selectpicker('refresh');
                                                $("[deviceidentifier='" + device.DeviceId() + "']").find("button").prop("disabled", false);
                                                $("[deviceidentifier='" + device.DeviceId() + "']").find(".show-tick").css('pointer-events', '');


                                            }
                                        } 

                                        keyuser.IsTargetable = true;
                                    } else {
                                        keyuser.IsTargetable = false;
                                        if (typeof elementId != "undefined") //must apply targeting not allowed changes 
                                        {
                                            //enble dropdown
											if ($("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").length !=0)
											{
												$("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").prop("disabled", false);
											}
                                            //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").attr("disabled", false);
                                            //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").selectpicker('refresh');
                                            $("[deviceidentifier='" + device.DeviceId() + "']").find("button").prop("disabled", false);
                                            $("[deviceidentifier='" + device.DeviceId() + "']").find(".show-tick").css('pointer-events', '');




                                        }
                                    }
                                    endPointFound = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (endPointFound) {
                        athoc.iws.publishing.massdevices.isMassDeviceReady();
                        break;
                    }
                }
            },
            IsThisDeviceGroupTargeted: function (groupid) {
                var massdevices = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList());
                var targeted = false;


                _.each(massdevices, function (group) {

                    _.each(group.DeviceList, function (dev) {
                        if (dev.GroupId == groupid && dev.Selected) {
                            targeted = true;
                        }
                    });

                });
                return targeted;
            }

        };
    }();
}