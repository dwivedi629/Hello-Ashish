﻿/* define javascript namespace for Scenario */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};

if (athoc.iws) {
    athoc.iws.publishing = function () {
        
        return {
                ReachableUserCount: ko.observable(0),

            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //Publisher settings to show/hide features
            settings: {
                IsGroupBlockSupported: false,
                IsAdvancedQuerySuuported: false,
                IsIndividualUserTargetingSupported: false,
                IsTargetByAreaSupported: false,
                IsDropboxSupported: false,
                IsMassDeviceTargetSupported: false,
                IsCallbridgeOptionSupported: false,
                IsSchedulingSupported: false,
                IsTestAlertSupported: false,
                IsPrintAlertSupported: false,
                IsDeviceOptionSupported: false,
                IsAlertTemplateSettingSupported: false,
                IsPlaceholderSupported: false,
                IsDeviceDeliveryOrderSupported: false,
                IsChannelSupported: false,
                IndividualUserTargetSelectionLimit: 500,
            },

            SetSectionStatus: function (statusDivSelector, newStatus) {//newStatus: open/notReady/ready
                var className = "open";
                var tooltip = this.resources.Publishing_Section_Empty_Tooltip;

                switch (newStatus) {
                    case "open":
                        className = "open";
                        tooltip = this.resources.Publishing_Section_Empty_Tooltip;
                        break;
                    case "notReady":
                        className = "not-ready";
                        tooltip = this.resources.Publishing_Section_NotReady_Tooltip;
                        break;
                    case "ready":
                        className = "ready";
                        tooltip = this.resources.Publishing_Section_Ready_Tooltip;
                        break;
                }
                athoc.iws.publishing.detail.checkStatusChange();                
                this.onReadyChange(className == 'ready' ? true : false);
                $(statusDivSelector).removeClass("open").removeClass("not-ready").removeClass("ready").addClass(className).attr("title", tooltip);
            },

            //modified the method and passing targetedUsers, blockedUsers as parameters
            UpdateContactInfo: function (EntityId, Context, selectedTreeNodes, selectedDevices, successCallBack, errorCallBack, queryCriteria, targetedArea, targetedUsers, blockedUsers, rbtCriteria) {
                var self = this;
                if (athoc.iws.publishing.detail.isChanged()) {
                    athoc.iws.publishing.detail.firstLoad = false;
                }

                //IWS-31811: Check for making sure User Search is called only once during initial load
                if (athoc.iws.publishing.detail.firstLoad) {
                    if (athoc.iws.publishing.detail.userSearchOnce) {
                        athoc.iws.publishing.detail.firstLoad = false;

                        //load results from first user search
                        var data = athoc.iws.publishing.detail.userSearchResult;
                        if (data) {
                            if (data.TotalCount > 0) {
                                self.ReachableUserCount(data.ContactInfo.TotalCovered);
                            }
                            successCallBack(data);

                            //return so that search do not run again
                            return;
                        }
                        else {
                            athoc.iws.publishing.detail.firstLoad = false;
                        }
                    }
                    else {
                        athoc.iws.publishing.detail.userSearchOnce = true;
                    }
                }

                var targetingCriteria = queryCriteria;
                if (rbtCriteria != null)
                    if (rbtCriteria.EntityFilterId != "")
                        targetingCriteria = null;

                //turn on now loading
                var criteriaToPass = {
                    SelectedTreeNodes: selectedTreeNodes,
                    SelectedDevices: selectedDevices,
                    EntityId: EntityId,
                    TargetedCriteria: targetingCriteria,
                    PublishingContext: Context,
                    TargetedArea: targetedArea,
                    TargetedUsers: targetedUsers,
                    BlockedUsers: blockedUsers,
                    RbtCriteria: rbtCriteria,
                }

                var contactAjaxOption =
                    {
                        url: athoc.iws.publishing.urls.RefreshContactInfoUrl,
                        contentType: 'application/json',
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(criteriaToPass),
                        cache: false
                    };

                var userInfoSuccess = function (data) {
                    if (data.TotalCount > 0) {
                        self.ReachableUserCount(data.ContactInfo.TotalCovered);
                    }
                    
                    successCallBack(data);

                    console.log(data);
                    if (athoc.iws.publishing.detail.firstLoad && data.SessionId != 0) {
                        athoc.iws.publishing.detail.userSearchResult = data;
                    }
                    else {
                        athoc.iws.publishing.detail.userSearchResult = null;
                    }
                };

                var userInfoError = function (error) {
                    errorCallBack(error);
                };

                var ajaxOptions = $.extend({}, AjaxUtility(userInfoError, userInfoSuccess).ajaxPostOptions, contactAjaxOption);
                $.ajax(ajaxOptions);

            },
            getErrorTitleList: function () {
                var errorTitleStrings = new Array();
                //To fill the Message popup title strings from resource 
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Information);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Warning);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Error);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Success);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Completed);
                return errorTitleStrings;
            },
            getPlaceholderList: function () {
                var patt = /\[\[(.+?)\]\]/g; ///\[\[(\w+\s?\w+)=?(.*?)\]\]/g;

                var nameArray = new Array();

                $(".needs-placeholder").each(function () {

                    //check to see if this item is in device options. 
                    //if so, need to check to make sure corresponding devicegroup/device is targeted. Otherwise, we should ignore this input/textbox.
                    if (typeof $(this).attr("device_group_id") != "undefined")
                        if (!athoc.iws.publishing.massdevices.IsThisDeviceGroupTargeted($(this).attr("device_group_id"))
                            && !athoc.iws.publishing.targetUsers.isThisDeviceGroupTargeted($(this).attr("device_group_id"))) {
                            return true;
                        }

                    var customTxt = $(this).val();
                    var matches = customTxt.match(patt);
                    if (matches != null) {
                        for (var i = 0; i < matches.length; i++) {
                            var m = matches[i].substr(2, matches[i].length - 4);
                            if (m.length > 0 && $.inArray(m, nameArray) == -1) {
                                nameArray.push({ Name: m, ControlId: $(this).attr('id') });
                            }
                        }
                    }
                });

                var idArray = new Array();
                for (var i = 0; i < nameArray.length; i++) {
                    var found = _.find(athoc.iws.publishing.placeHolderItems, function (item) {
                        if (nameArray[i].Name == item.Name)
                            return true;
                    });

                    if (found) {
                        if (idArray.indexOf(found.Id) == -1) {
                            idArray.push(found.Id)
                        }
                    }

                }
                return idArray;


            },
            onReadyChange: function (isReady) { },

            //create post request
            createRequest: function (URL) {               
                var alertForm = document.createElement("form");
                alertForm.method = "POST";
                alertForm.action = URL;
                document.body.appendChild(alertForm);
                alertForm.submit();               
            },
        }
    }();
};