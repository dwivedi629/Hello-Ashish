﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.scenario = athoc.iws.scenario || {};

if (athoc.iws.scenario) {
    athoc.iws.scenario.detail = function () {
        return {
            parameters: null,
            init: function (args) {
                this.parameters = args;
            },
            //edit scenario
            editScenario: function (id) {
                $("#scenarioInfoSection").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.scenario.urls.GetScenarioDetailUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true, id, true);

                //athoc.iws.publishing.targetUsers.load(id);

            },

            //create scenario
            createScenario: function () {
                $("#scenarioInfoSection").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.scenario.urls.CreateScenarioUrl;

                athoc.iws.publishing.detail.loadPublishingModel(loadUrl);

                athoc.iws.publishing.targetUsers.load(0);

            },

            //duplicate sceanrio
            duplicateScenario: function (id) {
                $("#scenarioInfoSection").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.scenario.urls.DuplicateScenarioUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl,undefined,id,true);

                //athoc.iws.publishing.targetUsers.load(id);
            },

            //save scenario
            saveScenario: function () {
                //set the flat to reload
                athoc.iws.scenario.refreshList = true;

                //Check if all sections are valid
                var isValid = athoc.iws.publishing.content.isValid() && athoc.iws.publishing.scenario.isValid()
                    && !athoc.iws.scenario.schedule.isInErrorState;

                if (!isValid) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.scenario.resources.Scenario_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(0);
                    return false;
                }

                athoc.iws.publishing.detail.setChanged(false);

                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
                var scheduleScenarioModel = athoc.iws.scenario.schedule.getModel();
                if (scheduleScenarioModel != undefined && scheduleScenarioModel != null)
                {
                    if (scheduleScenarioModel.ScheduleRecurrenceDailyFrequencyInput == "")
                        scheduleScenarioModel.ScheduleRecurrenceDailyFrequencyInput=0;
                    if (scheduleScenarioModel.ScheduleRecurrenceEndCountInput == "")
                        scheduleScenarioModel.ScheduleRecurrenceEndCountInput=0;
                }

                //Get updated data from each section in viewmodel
                var scenario = {
                    EntityId: athoc.iws.publishing.detail.viewModel.EntityId,
                    IsReadyToPublish: athoc.iws.publishing.detail.isReadyToPublish(),
                    ScenarioSection: athoc.iws.publishing.scenario.getModel(),
                    Content: athoc.iws.publishing.content.getModel(),
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    TargetOrg: athoc.iws.publishing.targetOrg.getModel(),
                    ScenarioSettings: athoc.iws.scenario.settings.getModel(),
                    ScenarioScheduleSettings: scheduleScenarioModel,
                    MassDevices: massDeviceModel == null ? [] : massDeviceModel.MassDevices,
                    MassDeviceGroupOptions: massDeviceModel == null ? [] : massDeviceModel.MassDeviceGroupOptions,
                    AllPlaceHolderIds: athoc.iws.publishing.getPlaceholderList(),
                    FillCount: athoc.iws.publishing.fillcount.getModel(),
                };

                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        url: athoc.iws.scenario.urls.SaveScenarioUrl,
                        contentType: false,
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(scenario)
                    };
                
                var ajaxSuccess = function (data) {
                    if (data.Success) {
                        athoc.iws.publishing.detail.resetLoadedStatus();

                        athoc.iws.publishing.detail.bindModel(data, true);

                       

                        $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.scenario.resources.Scenario_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(0);
                        athoc.iws.publishing.targetUsers.load(data.Data.EntityId);

                    } else {
                        $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(0);
                    }
                    $.AjaxLoader.hideLoader();
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;
            },
        };
    }();
}