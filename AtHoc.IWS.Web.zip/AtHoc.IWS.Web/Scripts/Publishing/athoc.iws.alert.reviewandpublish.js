﻿/// <reference path="athoc.iws.alert.reviewandpublish.js" />
/* define javascript namespace for Test Alert  */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};
if (athoc.iws.alert) {
    athoc.iws.alert.reviewandpublish = function () {
        //
        var extraSpaceAddBlock = 55;
        return {
            //is model changed
            //id for deeplinking
            Sessionid: 0,
            ReachableUsers: ko.observable(0),
            ReachableUsersPercentage: ko.observable(0),
            UnReachableUsers: ko.observable(0),
            UnReachableUsersPercentage: ko.observable(0),
            readOnlyMap: null,
            //called when new data will be available for this section for binding
            load: function () {

            },

            showModalonModal: function (targetDiv) {
                $(targetDiv).css({ display: 'block' });
                //$(targetDiv).addClass('width600');
                $(targetDiv).modal().css(
                   {
                       'z-index': '999999',
                       'margin-top': '-299px',

                   });
                $("#dialogReviewAndStart .overlay-light-grey").show();
                $("#dialogReviewAndPublish").append('<div id="displayShadowRP" class="modal-backdrop fade in"></div>');
                $(targetDiv).on('hidden.bs.modal', function () {
                    $("#dialogReviewAndPublish").find('#displayShadowRP').remove();
                    $("#dialogReviewAndStart .overlay-light-grey").hide();
                })
                this.resizeModalBasedOnScreen($(targetDiv));

                if (targetDiv == "#dialogGeoPublish") {
                    this.loadMap($(targetDiv));
                    $(targetDiv).modal().css(
                   {
                       'z-index': '999999',
                       'margin-left': '-491px',
                       'margin-top': '-204px',

                   });
                }

            },
            loadMap: function (targetDiv) {
                //removed the event listener here. Keep in mind, event listener should always call once.
                //require(["maps/MiniMap"], function (MiniMap) {
                //    $('#dialogGeoPublish').on('shown.bs.modal', function () {
                //        if (!athoc.iws.alert.reviewandpublish.readOnlyMap) {
                //            athoc.iws.alert.reviewandpublish.readOnlyMap = new MiniMap({ width: 980, height: 300 }, "dialogGeoPublishContent");
                //        }
                //        var geoJson = JSON.parse(athoc.iws.publishing.view.viewModel.data.Content.LocationGeo());
                //        athoc.iws.alert.reviewandpublish.readOnlyMap.restore(geoJson);

                //        setTimeout(function () {
                //            athoc.iws.alert.reviewandpublish.readOnlyMap.resize();
                //            athoc.iws.alert.reviewandpublish.readOnlyMap.zoomToFit();
                //        }, 500);
                //    });
                //});

            },
            resizeModalBasedOnScreen: function (modal) {

                if (modal.attr("id") == "ReadOnlyUserList") return;
                modal.css("margin-left", (($(window).width() / 2) - (modal.width() / 2)) - $(window).width() / 2);


                modal.find(".modal-body").css("max-height", 500);

                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 80 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 20 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 120);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);
                }

                if (modal.attr("id") == "recordedMessageModal") {
                    modal.css({ "top": '40%', "margin-top": "0px" });
                    //modal.css("margin-top", (modal.height() + 100) - (windowHeight / 2));
                    modal.find(".modal-body").css({"height":"31px", "overflow-y":"hidden"});
                    //modal.find(".modal-body").css("max-height", 15);
                }

            },

            showTargetedUsersSummary: function () {
                var windowHeight = $("#targetedUsersSummaryRP .modal-body").height();
                var sortState = '';
                var dataTb = [];
                var usersList = athoc.iws.publishing.view.viewModel.TargetedBlockerUsersList;
                $.grep(usersList == undefined ? athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList() : usersList, function (i) {
                    if (!i.IsBlocked)
                        dataTb.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });

                dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 50,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });
                //datasource.read();
                var cntrl = $("#targetedUsersSummaryDetailRP");
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    height: windowHeight,
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTTargetedSummary_Name,
                                     template: '<span title="#=Name#">#=Name#</span>',
                                     width: "95%",
                                     headerAttributes: {
                                         tabindex: "3"
                                     },
                                     headerTemplate: '<span style="color:black;font-weight:bold;font-size:16px">' + athoc.iws.publishing.iut.resources.IUTTargetedSummary_Name + '</span>'
                                 },
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;
                grid.refresh();
                this.OverrideCssPropertyForPopup(cntrl);
            },

            showBlockedUsersSummary: function () {
                var windowHeight = $("#targetedUsersSummaryRP .modal-body").height();
                var dataTb = [];
                var sortState = '';
                var usersList = athoc.iws.publishing.view.viewModel.TargetedBlockerUsersList;
                $.grep(usersList == undefined ? athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList() : usersList, function (i) {
                    if (i.IsBlocked)
                        dataTb.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });
                dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 50,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });

                //datasource.read();
                var cntrl = $("#targetedUsersSummaryDetailRP")
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    height: windowHeight,
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTTargetedSummary_Name,
                                     template: '<span title="#=Name#">#=Name#</span>',
                                     width: "95%",
                                     headerAttributes: {
                                         tabindex: "3"
                                     },
                                     headerTemplate: '<span style="color:black;font-weight:bold;font-size:16px">' + athoc.iws.publishing.iut.resources.IUTTargetedSummary_Name + '</span>'
                                 },
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;
                this.OverrideCssPropertyForPopup(cntrl);
            },


            OverrideCssPropertyForPopup: function (popupDivStr) {
                popupDivStr.find(".k-grid-header").css("margin-left", 0);
                popupDivStr.find(".k-grid-header").css("border", 1);
                popupDivStr.parent().parent().css('overflow-y', 'hidden');
                popupDivStr.find(".k-grid-header-wrap").css("width", 718);
                if (athoc.iws.publishing.source == "h") {
                    popupDivStr.find(".k-grid-header-wrap").css("border-bottom-width", 1);
                }
                else {
                    var existingStyle = popupDivStr.find(".k-grid-content").attr("style");
                    popupDivStr.find(".k-grid-content").attr("style", "overflow-y:auto !important" + ";" + existingStyle);
                }
            },

            TargetedGroupsFormatted: function () {
                var tg = this.TargetedGroups();
                return this._formatGroups(tg);
            },

            TargetedGroups: function () {
                if (athoc.iws.publishing.source == "a" || athoc.iws.publishing.source == "") {
                    var nodes = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes == undefined ? athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.SelectedNodes : athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes);
                    return $.grep(nodes, function (i) {
                        return !i.IsBlocked;
                    });
                }
                else
                    return tg = this.selectedNodes(ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes()));
            },

            BlockedGroups: function () {
                if (athoc.iws.publishing.source == "a" || athoc.iws.publishing.source == "") {
                    var nodes = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes == undefined ? athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.SelectedNodes : athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes);
                    return $.grep(nodes, function (i) {
                        return i.IsBlocked;
                    });
                }
                else
                    return tg = this.blockedNodes(ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes()));
            },

            BlockedGroupsFormatted: function () {
                var bg = this.BlockedGroups();
                return this._formatGroups(bg);
            },

            _formatGroups: function (groups) {
                var x = {};
                var nodes = groups;// this.get("SelectedNodes");
                for (var i = 0; i < nodes.length; ++i) {
                    var n = nodes[i];
                    switch (n.Type) {
                        case 0:
                        case 1:
                        case 3:
                            if (x[n.Name] == undefined)
                                x[n.Name] = [];
                            x[n.Name].push({ Type: n.Type, Item: athoc.iws.publishing.resources.Publishing_TargetUsers_All_Selected });
                            break;
                        case 2:
                            if (x[n.ParentName] == undefined)
                                x[n.ParentName] = [];
                            x[n.ParentName].push({ Type: n.Type, Item: (n.Name != null ? n.Name : "null") });
                            break;
                        case 4:
                        case 5:
                            if (x[n.RootName] == undefined) {
                                x[n.RootName] = [];
                            }
                            if (n.Type == 5) {
                                x[n.RootName].push({ Type: n.Type, Item: (n.Name != null ? n.Name : "null") });
                            } else {
                                if (n.Lineage) {
                                    x[n.RootName].push({ Type: n.Type, Item: kendo.format("{0}{1}/", n.Lineage, (n.Name != null ? n.Name : "null")) });
                                } else {
                                    x[n.RootName].push({ Type: n.Type, Item: kendo.format(n.Type == 4 ? "{0}" : "/{0}/", (n.Name != null ? n.Name : "null")) }); //loading on review/publish
                                }
                            }
                            break;
                    }
                }
                var ret = Object.keys(x).map(function (k) {
                    return { Group: k, Items: x[k], Type: x[k][0] != undefined ? x[k][0].Type : -1 }
                });
                return ret;

            },

            GetReachableUserList: function () {
                this.LaunchContactInfoUserList(1);
            },

            GetUnReachableUserList: function () {
                this.LaunchContactInfoUserList(0);
            },
            LaunchContactInfoUserList: function (covered) {
                var checkedDevices = null;
                checkedDevices = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices()).map(function (item) { return item.DeviceId; });

                //workaround due to pie chart uses following model
                athoc.iws.publishing.targetUsers.ReadonlyviewModel.Devices = ko.mapping.fromJS(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices);

                var attributeIdCSV = checkedDevices.join(",");
                //to show readOnlyUserList
                if (covered == 1)
                    $("#readOnlyUserListTitle").html(athoc.iws.publishing.resources.Publishing_TargetUsers_Reachable_Users + " (" + this.ReachableUsers() + ")");
                else
                    $("#readOnlyUserListTitle").html(athoc.iws.publishing.resources.Publishing_TargetUsers_Unreachable_Users +" (" + this.UnReachableUsers() + ")");

                $("#txtReadOnlySearch").keyup(function (e) {
                    $("#btn_readonlyusersearch").removeAttr('disabled');
                    if ($.hotkeys.enter(e)) {
                        athoc.iws.publishing.iut.createReadOnlyUserList();
                    }
                });

                $("#btn_readonlyusersearch").click(function () {
                    athoc.iws.publishing.iut.createReadOnlyUserList();
                });

                this.ShowUsersList(athoc.iws.alert.reviewandpublish.SessionId, covered, "", covered == 1 ? this.ReachableUsers() : this.UnReachableUsers());
            },

            ShowUsersList: function (sessionId, covered, attributeCSV, totalCount) {
                athoc.iws.publishing.iut.readOnlyInputParameters.sessionId(sessionId);
                athoc.iws.publishing.iut.readOnlyInputParameters.covered(covered);
                athoc.iws.publishing.iut.readOnlyInputParameters.attributeCSV(attributeCSV);
                athoc.iws.publishing.iut.readOnlyInputParameters.totalCount(totalCount);
                $("#txtReadOnlySearch").val('');
                //$("#btn_readonlyusersearch").attr('disabled', true);
                this.showModalonModal("#ReadOnlyUserList");
                this.resizeReadonlyModalBasedOnScreen($('#ReadOnlyUserList'));
                $('#ReadOnlyUserList').removeClass("width600");
                $("#dialogReviewAndPublish").append('<div id="displayShadowRP" class="modal-backdrop fade in" style="background:url(../Images/overlay-light-grey.png) 0 0 repeat;width:100%;height:100%"></div>');
                $('#ReadOnlyUserList').on('hidden.bs.modal', function () {
                    $("#dialogReviewAndPublish").find('#displayShadowRP').remove();
                })
                athoc.iws.publishing.iut.createReadOnlyUserList();
                if (athoc.iws.publishing.source == 'a') {
                    $("#dialogReviewAndPublish").find("#ReadOnlyUserList").html($('#ReadOnlyUserList').get(0));
                }
                //$("#showUserlistInRP").find("#readonlyUserList").attr("style", "top:10px;left:0px");
                $("body").click(function () {
                    athoc.iws.publishing.iut.hideAddColumns();
                    $("#contextDropdown").hide();

                });
                //this.fitHeightReadOnlyList();
            },
            fitHeightReadOnlyList: function () {
                var extraSpace = 118;
                var windowHeight = $(window).height();
                if (windowHeight > 770) {

                    extraSpace = 138;
                    $("#showUserlistInRP").find("#readonlyUserList").css("height", windowHeight - 355 - extraSpace);
                    $("#showUserlistInRP").find("#readonlyUserList .k-grid-content").css("height", windowHeight - 460 - extraSpace);
                }
                else {
                    $("#showUserlistInRP").find("#readonlyUserList").css("height", windowHeight - 228 - extraSpace);
                    $("#showUserlistInRP").find("#readonlyUserList .k-grid-content").css("height", windowHeight - extraSpace - extraSpace);

                }
                var gridStyle = $("#readonlyUserList .k-grid-content")[0];
                var grid = $("#readonlyUserList").data("kendoGrid");
                /*if (gridStyle.scrollHeight > gridStyle.clientHeight)
                    grid.showColumn(grid.columns.length - 1);
                else
                    grid.hideColumn(grid.columns.length - 1);*/

            },
            resizeReadonlyModalBasedOnScreen: function (modal) {

                modal.find(".modal-body").css("max-height", 600);
                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 40 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 40 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 240);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }
            },

            selectedNodes: function (treeNodes) {
                var selectedNodes = [];
                var nodes = treeNodes.length;
                for (var i = 0; i < nodes; i++) {
                    if (treeNodes[i].Selected && !treeNodes[i].IsBlocked) {

                        if (treeNodes[i].Type == 2)
                            selectedNodes.push({
                                Id: treeNodes[i].Id,
                                Name: treeNodes[i].Name,
                                Type: treeNodes[i].Type,
                                Lineage: treeNodes[i].Lineage,
                                SubType: treeNodes[i].SubType,
                                DlType: treeNodes[i].DlType,
                                RootName: treeNodes[i].RootName,
                                ParentName: treeNodes[i].ParentName,

                            });

                        else
                            selectedNodes.push({
                                Id: treeNodes[i].Id,
                                Name: treeNodes[i].Name,
                                Type: treeNodes[i].Type,
                                Lineage: treeNodes[i].Lineage,
                                SubType: treeNodes[i].SubType,
                                DlType: treeNodes[i].DlType,
                                RootName: treeNodes[i].RootName,

                            });
                    }
                    if (treeNodes[i].HasChildren) {
                        for (var j = 0; j < treeNodes[i].Children.length; j++) {
                            if (treeNodes[i].Children[j].Selected && !treeNodes[i].Children[j].IsBlocked) {
                                selectedNodes.push({
                                    Id: treeNodes[i].Children[j].Id,
                                    Name: treeNodes[i].Children[j].Name,
                                    Type: treeNodes[i].Children[j].Type,
                                    RootId: treeNodes[i].Id,
                                    RootName: treeNodes[i].Name,
                                    Lineage: treeNodes[i].Children[j].Lineage,
                                    SubType: treeNodes[i].Children[j].SubType,
                                    DlType: treeNodes[i].Children[j].DlType,
                                });
                            }
                        }
                    }
                }
                return selectedNodes;
            },

            blockedNodes: function (treeNodes) {
                var selectedNodes = [];
                var nodes = treeNodes.length;
                for (var i = 0; i < nodes; i++) {
                    if (treeNodes[i].IsBlocked) {
                        if (treeNodes[i].Type == 2)
                            selectedNodes.push({
                                Id: treeNodes[i].Id,
                                Name: treeNodes[i].Name,
                                Type: treeNodes[i].Type,
                                Lineage: treeNodes[i].Lineage,
                                SubType: treeNodes[i].SubType,
                                DlType: treeNodes[i].DlType,
                                RootName: treeNodes[i].RootName,
                                ParentName: treeNodes[i].ParentName,

                            });

                        else
                            selectedNodes.push({
                                Id: treeNodes[i].Id,
                                Name: treeNodes[i].Name,
                                Type: treeNodes[i].Type,
                                Lineage: treeNodes[i].Lineage,
                                SubType: treeNodes[i].SubType,
                                DlType: treeNodes[i].DlType,
                                RootName: treeNodes[i].RootName,

                            });
                    }
                    if (treeNodes[i].HasChildren) {
                        for (var j = 0; j < treeNodes[i].Children.length; j++) {
                            if (treeNodes[i].Children[j].IsBlocked) {
                                selectedNodes.push({
                                    Id: treeNodes[i].Children[j].Id,
                                    Name: treeNodes[i].Children[j].Name,
                                    Type: treeNodes[i].Children[j].Type,
                                    RootId: treeNodes[i].Id,
                                    RootName: treeNodes[i].Name,
                                    Lineage: treeNodes[i].Children[j].Lineag,
                                    SubType: treeNodes[i].Children[j].SubType,
                                    DlType: treeNodes[i].Children[j].DlType,
                                });
                            }
                        }
                    }
                }
                return selectedNodes;
            },


        };



    }();
}
