﻿///#source 1 1 /Scripts/jquery.fileupload.js
/*
 * jQuery File Upload Plugin 5.40.0
 * https://github.com/blueimp/jQuery-File-Upload
 *
 * Copyright 2010, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 */

/* jshint nomen:false */
/* global define, window, document, location, Blob, FormData */

(function (factory) {
    'use strict';
    if (typeof define === 'function' && define.amd) {
        // Register as an anonymous AMD module:
        define([
            'jquery',
            'jquery.ui.widget'
        ], factory);
    } else {
        // Browser globals:
        factory(window.jQuery);
    }
}(function ($) {
    'use strict';

    // Detect file input support, based on
    // http://viljamis.com/blog/2012/file-upload-support-on-mobile/
    $.support.fileInput = !(new RegExp(
        // Handle devices which give false positives for the feature detection:
        '(Android (1\\.[0156]|2\\.[01]))' +
            '|(Windows Phone (OS 7|8\\.0))|(XBLWP)|(ZuneWP)|(WPDesktop)' +
            '|(w(eb)?OSBrowser)|(webOS)' +
            '|(Kindle/(1\\.0|2\\.[05]|3\\.0))'
    ).test(window.navigator.userAgent) ||
        // Feature detection for all other devices:
        $('<input type="file">').prop('disabled'));

    // The FileReader API is not actually used, but works as feature detection,
    // as some Safari versions (5?) support XHR file uploads via the FormData API,
    // but not non-multipart XHR file uploads.
    // window.XMLHttpRequestUpload is not available on IE10, so we check for
    // window.ProgressEvent instead to detect XHR2 file upload capability:
    $.support.xhrFileUpload = !!(window.ProgressEvent && window.FileReader);
    $.support.xhrFormDataFileUpload = !!window.FormData;

    // Detect support for Blob slicing (required for chunked uploads):
    $.support.blobSlice = window.Blob && (Blob.prototype.slice ||
        Blob.prototype.webkitSlice || Blob.prototype.mozSlice);

    // The fileupload widget listens for change events on file input fields defined
    // via fileInput setting and paste or drop events of the given dropZone.
    // In addition to the default jQuery Widget methods, the fileupload widget
    // exposes the "add" and "send" methods, to add or directly send files using
    // the fileupload API.
    // By default, files added via file input selection, paste, drag & drop or
    // "add" method are uploaded immediately, but it is possible to override
    // the "add" callback option to queue file uploads.
    $.widget('blueimp.fileupload', {

        options: {
            // The drop target element(s), by the default the complete document.
            // Set to null to disable drag & drop support:
            dropZone: $(document),
            // The paste target element(s), by the default the complete document.
            // Set to null to disable paste support:
            pasteZone: $(document),
            // The file input field(s), that are listened to for change events.
            // If undefined, it is set to the file input fields inside
            // of the widget element on plugin initialization.
            // Set to null to disable the change listener.
            fileInput: undefined,
            // By default, the file input field is replaced with a clone after
            // each input field change event. This is required for iframe transport
            // queues and allows change events to be fired for the same file
            // selection, but can be disabled by setting the following option to false:
            replaceFileInput: true,
            // The parameter name for the file form data (the request argument name).
            // If undefined or empty, the name property of the file input field is
            // used, or "files[]" if the file input name property is also empty,
            // can be a string or an array of strings:
            paramName: undefined,
            // By default, each file of a selection is uploaded using an individual
            // request for XHR type uploads. Set to false to upload file
            // selections in one request each:
            singleFileUploads: true,
            // To limit the number of files uploaded with one XHR request,
            // set the following option to an integer greater than 0:
            limitMultiFileUploads: undefined,
            // The following option limits the number of files uploaded with one
            // XHR request to keep the request size under or equal to the defined
            // limit in bytes:
            limitMultiFileUploadSize: undefined,
            // Multipart file uploads add a number of bytes to each uploaded file,
            // therefore the following option adds an overhead for each file used
            // in the limitMultiFileUploadSize configuration:
            limitMultiFileUploadSizeOverhead: 512,
            // Set the following option to true to issue all file upload requests
            // in a sequential order:
            sequentialUploads: false,
            // To limit the number of concurrent uploads,
            // set the following option to an integer greater than 0:
            limitConcurrentUploads: undefined,
            // Set the following option to true to force iframe transport uploads:
            forceIframeTransport: false,
            // Set the following option to the location of a redirect url on the
            // origin server, for cross-domain iframe transport uploads:
            redirect: undefined,
            // The parameter name for the redirect url, sent as part of the form
            // data and set to 'redirect' if this option is empty:
            redirectParamName: undefined,
            // Set the following option to the location of a postMessage window,
            // to enable postMessage transport uploads:
            postMessage: undefined,
            // By default, XHR file uploads are sent as multipart/form-data.
            // The iframe transport is always using multipart/form-data.
            // Set to false to enable non-multipart XHR uploads:
            multipart: true,
            // To upload large files in smaller chunks, set the following option
            // to a preferred maximum chunk size. If set to 0, null or undefined,
            // or the browser does not support the required Blob API, files will
            // be uploaded as a whole.
            maxChunkSize: undefined,
            // When a non-multipart upload or a chunked multipart upload has been
            // aborted, this option can be used to resume the upload by setting
            // it to the size of the already uploaded bytes. This option is most
            // useful when modifying the options object inside of the "add" or
            // "send" callbacks, as the options are cloned for each file upload.
            uploadedBytes: undefined,
            // By default, failed (abort or error) file uploads are removed from the
            // global progress calculation. Set the following option to false to
            // prevent recalculating the global progress data:
            recalculateProgress: true,
            // Interval in milliseconds to calculate and trigger progress events:
            progressInterval: 100,
            // Interval in milliseconds to calculate progress bitrate:
            bitrateInterval: 500,
            // By default, uploads are started automatically when adding files:
            autoUpload: true,

            // Error and info messages:
            messages: {
                uploadedBytes: 'Uploaded bytes exceed file size'
            },

            // Translation function, gets the message key to be translated
            // and an object with context specific data as arguments:
            i18n: function (message, context) {
                message = this.messages[message] || message.toString();
                if (context) {
                    $.each(context, function (key, value) {
                        message = message.replace('{' + key + '}', value);
                    });
                }
                return message;
            },

            // Additional form data to be sent along with the file uploads can be set
            // using this option, which accepts an array of objects with name and
            // value properties, a function returning such an array, a FormData
            // object (for XHR file uploads), or a simple object.
            // The form of the first fileInput is given as parameter to the function:
            formData: function (form) {
                return form.serializeArray();
            },

            // The add callback is invoked as soon as files are added to the fileupload
            // widget (via file input selection, drag & drop, paste or add API call).
            // If the singleFileUploads option is enabled, this callback will be
            // called once for each file in the selection for XHR file uploads, else
            // once for each file selection.
            //
            // The upload starts when the submit method is invoked on the data parameter.
            // The data object contains a files property holding the added files
            // and allows you to override plugin options as well as define ajax settings.
            //
            // Listeners for this callback can also be bound the following way:
            // .bind('fileuploadadd', func);
            //
            // data.submit() returns a Promise object and allows to attach additional
            // handlers using jQuery's Deferred callbacks:
            // data.submit().done(func).fail(func).always(func);
            add: function (e, data) {
                if (e.isDefaultPrevented()) {
                    return false;
                }
                if (data.autoUpload || (data.autoUpload !== false &&
                        $(this).fileupload('option', 'autoUpload'))) {
                    data.process().done(function () {
                        data.submit();
                    });
                }
            },

            // Other callbacks:

            // Callback for the submit event of each file upload:
            // submit: function (e, data) {}, // .bind('fileuploadsubmit', func);

            // Callback for the start of each file upload request:
            // send: function (e, data) {}, // .bind('fileuploadsend', func);

            // Callback for successful uploads:
            // done: function (e, data) {}, // .bind('fileuploaddone', func);

            // Callback for failed (abort or error) uploads:
            // fail: function (e, data) {}, // .bind('fileuploadfail', func);

            // Callback for completed (success, abort or error) requests:
            // always: function (e, data) {}, // .bind('fileuploadalways', func);

            // Callback for upload progress events:
            // progress: function (e, data) {}, // .bind('fileuploadprogress', func);

            // Callback for global upload progress events:
            // progressall: function (e, data) {}, // .bind('fileuploadprogressall', func);

            // Callback for uploads start, equivalent to the global ajaxStart event:
            // start: function (e) {}, // .bind('fileuploadstart', func);

            // Callback for uploads stop, equivalent to the global ajaxStop event:
            // stop: function (e) {}, // .bind('fileuploadstop', func);

            // Callback for change events of the fileInput(s):
            // change: function (e, data) {}, // .bind('fileuploadchange', func);

            // Callback for paste events to the pasteZone(s):
            // paste: function (e, data) {}, // .bind('fileuploadpaste', func);

            // Callback for drop events of the dropZone(s):
            // drop: function (e, data) {}, // .bind('fileuploaddrop', func);

            // Callback for dragover events of the dropZone(s):
            // dragover: function (e) {}, // .bind('fileuploaddragover', func);

            // Callback for the start of each chunk upload request:
            // chunksend: function (e, data) {}, // .bind('fileuploadchunksend', func);

            // Callback for successful chunk uploads:
            // chunkdone: function (e, data) {}, // .bind('fileuploadchunkdone', func);

            // Callback for failed (abort or error) chunk uploads:
            // chunkfail: function (e, data) {}, // .bind('fileuploadchunkfail', func);

            // Callback for completed (success, abort or error) chunk upload requests:
            // chunkalways: function (e, data) {}, // .bind('fileuploadchunkalways', func);

            // The plugin options are used as settings object for the ajax calls.
            // The following are jQuery ajax settings required for the file uploads:
            processData: false,
            contentType: false,
            cache: false
        },

        // A list of options that require reinitializing event listeners and/or
        // special initialization code:
        _specialOptions: [
            'fileInput',
            'dropZone',
            'pasteZone',
            'multipart',
            'forceIframeTransport'
        ],

        _blobSlice: $.support.blobSlice && function () {
            var slice = this.slice || this.webkitSlice || this.mozSlice;
            return slice.apply(this, arguments);
        },

        _BitrateTimer: function () {
            this.timestamp = ((Date.now) ? Date.now() : (new Date()).getTime());
            this.loaded = 0;
            this.bitrate = 0;
            this.getBitrate = function (now, loaded, interval) {
                var timeDiff = now - this.timestamp;
                if (!this.bitrate || !interval || timeDiff > interval) {
                    this.bitrate = (loaded - this.loaded) * (1000 / timeDiff) * 8;
                    this.loaded = loaded;
                    this.timestamp = now;
                }
                return this.bitrate;
            };
        },

        _isXHRUpload: function (options) {
            return !options.forceIframeTransport &&
                ((!options.multipart && $.support.xhrFileUpload) ||
                $.support.xhrFormDataFileUpload);
        },

        _getFormData: function (options) {
            var formData;
            if ($.type(options.formData) === 'function') {
                return options.formData(options.form);
            }
            if ($.isArray(options.formData)) {
                return options.formData;
            }
            if ($.type(options.formData) === 'object') {
                formData = [];
                $.each(options.formData, function (name, value) {
                    formData.push({name: name, value: value});
                });
                return formData;
            }
            return [];
        },

        _getTotal: function (files) {
            var total = 0;
            $.each(files, function (index, file) {
                total += file.size || 1;
            });
            return total;
        },

        _initProgressObject: function (obj) {
            var progress = {
                loaded: 0,
                total: 0,
                bitrate: 0
            };
            if (obj._progress) {
                $.extend(obj._progress, progress);
            } else {
                obj._progress = progress;
            }
        },

        _initResponseObject: function (obj) {
            var prop;
            if (obj._response) {
                for (prop in obj._response) {
                    if (obj._response.hasOwnProperty(prop)) {
                        delete obj._response[prop];
                    }
                }
            } else {
                obj._response = {};
            }
        },

        _onProgress: function (e, data) {
            if (e.lengthComputable) {
                var now = ((Date.now) ? Date.now() : (new Date()).getTime()),
                    loaded;
                if (data._time && data.progressInterval &&
                        (now - data._time < data.progressInterval) &&
                        e.loaded !== e.total) {
                    return;
                }
                data._time = now;
                loaded = Math.floor(
                    e.loaded / e.total * (data.chunkSize || data._progress.total)
                ) + (data.uploadedBytes || 0);
                // Add the difference from the previously loaded state
                // to the global loaded counter:
                this._progress.loaded += (loaded - data._progress.loaded);
                this._progress.bitrate = this._bitrateTimer.getBitrate(
                    now,
                    this._progress.loaded,
                    data.bitrateInterval
                );
                data._progress.loaded = data.loaded = loaded;
                data._progress.bitrate = data.bitrate = data._bitrateTimer.getBitrate(
                    now,
                    loaded,
                    data.bitrateInterval
                );
                // Trigger a custom progress event with a total data property set
                // to the file size(s) of the current upload and a loaded data
                // property calculated accordingly:
                this._trigger(
                    'progress',
                    $.Event('progress', {delegatedEvent: e}),
                    data
                );
                // Trigger a global progress event for all current file uploads,
                // including ajax calls queued for sequential file uploads:
                this._trigger(
                    'progressall',
                    $.Event('progressall', {delegatedEvent: e}),
                    this._progress
                );
            }
        },

        _initProgressListener: function (options) {
            var that = this,
                xhr = options.xhr ? options.xhr() : $.ajaxSettings.xhr();
            // Accesss to the native XHR object is required to add event listeners
            // for the upload progress event:
            if (xhr.upload) {
                $(xhr.upload).bind('progress', function (e) {
                    var oe = e.originalEvent;
                    // Make sure the progress event properties get copied over:
                    e.lengthComputable = oe.lengthComputable;
                    e.loaded = oe.loaded;
                    e.total = oe.total;
                    that._onProgress(e, options);
                });
                options.xhr = function () {
                    return xhr;
                };
            }
        },

        _isInstanceOf: function (type, obj) {
            // Cross-frame instanceof check
            return Object.prototype.toString.call(obj) === '[object ' + type + ']';
        },

        _initXHRData: function (options) {
            var that = this,
                formData,
                file = options.files[0],
                // Ignore non-multipart setting if not supported:
                multipart = options.multipart || !$.support.xhrFileUpload,
                paramName = $.type(options.paramName) === 'array' ?
                    options.paramName[0] : options.paramName;
            options.headers = $.extend({}, options.headers);
            if (options.contentRange) {
                options.headers['Content-Range'] = options.contentRange;
            }
            if (!multipart || options.blob || !this._isInstanceOf('File', file)) {
                options.headers['Content-Disposition'] = 'attachment; filename="' +
                    encodeURI(file.name) + '"';
            }
            if (!multipart) {
                options.contentType = file.type || 'application/octet-stream';
                options.data = options.blob || file;
            } else if ($.support.xhrFormDataFileUpload) {
                if (options.postMessage) {
                    // window.postMessage does not allow sending FormData
                    // objects, so we just add the File/Blob objects to
                    // the formData array and let the postMessage window
                    // create the FormData object out of this array:
                    formData = this._getFormData(options);
                    if (options.blob) {
                        formData.push({
                            name: paramName,
                            value: options.blob
                        });
                    } else {
                        $.each(options.files, function (index, file) {
                            formData.push({
                                name: ($.type(options.paramName) === 'array' &&
                                    options.paramName[index]) || paramName,
                                value: file
                            });
                        });
                    }
                } else {
                    if (that._isInstanceOf('FormData', options.formData)) {
                        formData = options.formData;
                    } else {
                        formData = new FormData();
                        $.each(this._getFormData(options), function (index, field) {
                            formData.append(field.name, field.value);
                        });
                    }
                    if (options.blob) {
                        formData.append(paramName, options.blob, file.name);
                    } else {
                        $.each(options.files, function (index, file) {
                            // This check allows the tests to run with
                            // dummy objects:
                            if (that._isInstanceOf('File', file) ||
                                    that._isInstanceOf('Blob', file)) {
                                formData.append(
                                    ($.type(options.paramName) === 'array' &&
                                        options.paramName[index]) || paramName,
                                    file,
                                    file.uploadName || file.name
                                );
                            }
                        });
                    }
                }
                options.data = formData;
            }
            // Blob reference is not needed anymore, free memory:
            options.blob = null;
        },

        _initIframeSettings: function (options) {
            var targetHost = $('<a></a>').prop('href', options.url).prop('host');
            // Setting the dataType to iframe enables the iframe transport:
            options.dataType = 'iframe ' + (options.dataType || '');
            // The iframe transport accepts a serialized array as form data:
            options.formData = this._getFormData(options);
            // Add redirect url to form data on cross-domain uploads:
            if (options.redirect && targetHost && targetHost !== location.host) {
                options.formData.push({
                    name: options.redirectParamName || 'redirect',
                    value: options.redirect
                });
            }
        },

        _initDataSettings: function (options) {
            if (this._isXHRUpload(options)) {
                if (!this._chunkedUpload(options, true)) {
                    if (!options.data) {
                        this._initXHRData(options);
                    }
                    this._initProgressListener(options);
                }
                if (options.postMessage) {
                    // Setting the dataType to postmessage enables the
                    // postMessage transport:
                    options.dataType = 'postmessage ' + (options.dataType || '');
                }
            } else {
                this._initIframeSettings(options);
            }
        },

        _getParamName: function (options) {
            var fileInput = $(options.fileInput),
                paramName = options.paramName;
            if (!paramName) {
                paramName = [];
                fileInput.each(function () {
                    var input = $(this),
                        name = input.prop('name') || 'files[]',
                        i = (input.prop('files') || [1]).length;
                    while (i) {
                        paramName.push(name);
                        i -= 1;
                    }
                });
                if (!paramName.length) {
                    paramName = [fileInput.prop('name') || 'files[]'];
                }
            } else if (!$.isArray(paramName)) {
                paramName = [paramName];
            }
            return paramName;
        },

        _initFormSettings: function (options) {
            // Retrieve missing options from the input field and the
            // associated form, if available:
            if (!options.form || !options.form.length) {
                options.form = $(options.fileInput.prop('form'));
                // If the given file input doesn't have an associated form,
                // use the default widget file input's form:
                if (!options.form.length) {
                    options.form = $(this.options.fileInput.prop('form'));
                }
            }
            options.paramName = this._getParamName(options);
            if (!options.url) {
                options.url = options.form.prop('action') || location.href;
            }
            // The HTTP request method must be "POST" or "PUT":
            options.type = (options.type ||
                ($.type(options.form.prop('method')) === 'string' &&
                    options.form.prop('method')) || ''
                ).toUpperCase();
            if (options.type !== 'POST' && options.type !== 'PUT' &&
                    options.type !== 'PATCH') {
                options.type = 'POST';
            }
            if (!options.formAcceptCharset) {
                options.formAcceptCharset = options.form.attr('accept-charset');
            }
        },

        _getAJAXSettings: function (data) {
            var options = $.extend({}, this.options, data);
            this._initFormSettings(options);
            this._initDataSettings(options);
            return options;
        },

        // jQuery 1.6 doesn't provide .state(),
        // while jQuery 1.8+ removed .isRejected() and .isResolved():
        _getDeferredState: function (deferred) {
            if (deferred.state) {
                return deferred.state();
            }
            if (deferred.isResolved()) {
                return 'resolved';
            }
            if (deferred.isRejected()) {
                return 'rejected';
            }
            return 'pending';
        },

        // Maps jqXHR callbacks to the equivalent
        // methods of the given Promise object:
        _enhancePromise: function (promise) {
            promise.success = promise.done;
            promise.error = promise.fail;
            promise.complete = promise.always;
            return promise;
        },

        // Creates and returns a Promise object enhanced with
        // the jqXHR methods abort, success, error and complete:
        _getXHRPromise: function (resolveOrReject, context, args) {
            var dfd = $.Deferred(),
                promise = dfd.promise();
            context = context || this.options.context || promise;
            if (resolveOrReject === true) {
                dfd.resolveWith(context, args);
            } else if (resolveOrReject === false) {
                dfd.rejectWith(context, args);
            }
            promise.abort = dfd.promise;
            return this._enhancePromise(promise);
        },

        // Adds convenience methods to the data callback argument:
        _addConvenienceMethods: function (e, data) {
            var that = this,
                getPromise = function (args) {
                    return $.Deferred().resolveWith(that, args).promise();
                };
            data.process = function (resolveFunc, rejectFunc) {
                if (resolveFunc || rejectFunc) {
                    data._processQueue = this._processQueue =
                        (this._processQueue || getPromise([this])).pipe(
                            function () {
                                if (data.errorThrown) {
                                    return $.Deferred()
                                        .rejectWith(that, [data]).promise();
                                }
                                return getPromise(arguments);
                            }
                        ).pipe(resolveFunc, rejectFunc);
                }
                return this._processQueue || getPromise([this]);
            };
            data.submit = function () {
                if (this.state() !== 'pending') {
                    data.jqXHR = this.jqXHR =
                        (that._trigger(
                            'submit',
                            $.Event('submit', {delegatedEvent: e}),
                            this
                        ) !== false) && that._onSend(e, this);
                }
                return this.jqXHR || that._getXHRPromise();
            };
            data.abort = function () {
                if (this.jqXHR) {
                    return this.jqXHR.abort();
                }
                this.errorThrown = 'abort';
                that._trigger('fail', null, this);
                return that._getXHRPromise(false);
            };
            data.state = function () {
                if (this.jqXHR) {
                    return that._getDeferredState(this.jqXHR);
                }
                if (this._processQueue) {
                    return that._getDeferredState(this._processQueue);
                }
            };
            data.processing = function () {
                return !this.jqXHR && this._processQueue && that
                    ._getDeferredState(this._processQueue) === 'pending';
            };
            data.progress = function () {
                return this._progress;
            };
            data.response = function () {
                return this._response;
            };
        },

        // Parses the Range header from the server response
        // and returns the uploaded bytes:
        _getUploadedBytes: function (jqXHR) {
            var range = jqXHR.getResponseHeader('Range'),
                parts = range && range.split('-'),
                upperBytesPos = parts && parts.length > 1 &&
                    parseInt(parts[1], 10);
            return upperBytesPos && upperBytesPos + 1;
        },

        // Uploads a file in multiple, sequential requests
        // by splitting the file up in multiple blob chunks.
        // If the second parameter is true, only tests if the file
        // should be uploaded in chunks, but does not invoke any
        // upload requests:
        _chunkedUpload: function (options, testOnly) {
            options.uploadedBytes = options.uploadedBytes || 0;
            var that = this,
                file = options.files[0],
                fs = file.size,
                ub = options.uploadedBytes,
                mcs = options.maxChunkSize || fs,
                slice = this._blobSlice,
                dfd = $.Deferred(),
                promise = dfd.promise(),
                jqXHR,
                upload;
            if (!(this._isXHRUpload(options) && slice && (ub || mcs < fs)) ||
                    options.data) {
                return false;
            }
            if (testOnly) {
                return true;
            }
            if (ub >= fs) {
                file.error = options.i18n('uploadedBytes');
                return this._getXHRPromise(
                    false,
                    options.context,
                    [null, 'error', file.error]
                );
            }
            // The chunk upload method:
            upload = function () {
                // Clone the options object for each chunk upload:
                var o = $.extend({}, options),
                    currentLoaded = o._progress.loaded;
                o.blob = slice.call(
                    file,
                    ub,
                    ub + mcs,
                    file.type
                );
                // Store the current chunk size, as the blob itself
                // will be dereferenced after data processing:
                o.chunkSize = o.blob.size;
                // Expose the chunk bytes position range:
                o.contentRange = 'bytes ' + ub + '-' +
                    (ub + o.chunkSize - 1) + '/' + fs;
                // Process the upload data (the blob and potential form data):
                that._initXHRData(o);
                // Add progress listeners for this chunk upload:
                that._initProgressListener(o);
                jqXHR = ((that._trigger('chunksend', null, o) !== false && $.ajax(o)) ||
                        that._getXHRPromise(false, o.context))
                    .done(function (result, textStatus, jqXHR) {
                        ub = that._getUploadedBytes(jqXHR) ||
                            (ub + o.chunkSize);
                        // Create a progress event if no final progress event
                        // with loaded equaling total has been triggered
                        // for this chunk:
                        if (currentLoaded + o.chunkSize - o._progress.loaded) {
                            that._onProgress($.Event('progress', {
                                lengthComputable: true,
                                loaded: ub - o.uploadedBytes,
                                total: ub - o.uploadedBytes
                            }), o);
                        }
                        options.uploadedBytes = o.uploadedBytes = ub;
                        o.result = result;
                        o.textStatus = textStatus;
                        o.jqXHR = jqXHR;
                        that._trigger('chunkdone', null, o);
                        that._trigger('chunkalways', null, o);
                        if (ub < fs) {
                            // File upload not yet complete,
                            // continue with the next chunk:
                            upload();
                        } else {
                            dfd.resolveWith(
                                o.context,
                                [result, textStatus, jqXHR]
                            );
                        }
                    })
                    .fail(function (jqXHR, textStatus, errorThrown) {
                        o.jqXHR = jqXHR;
                        o.textStatus = textStatus;
                        o.errorThrown = errorThrown;
                        that._trigger('chunkfail', null, o);
                        that._trigger('chunkalways', null, o);
                        dfd.rejectWith(
                            o.context,
                            [jqXHR, textStatus, errorThrown]
                        );
                    });
            };
            this._enhancePromise(promise);
            promise.abort = function () {
                return jqXHR.abort();
            };
            upload();
            return promise;
        },

        _beforeSend: function (e, data) {
            if (this._active === 0) {
                // the start callback is triggered when an upload starts
                // and no other uploads are currently running,
                // equivalent to the global ajaxStart event:
                this._trigger('start');
                // Set timer for global bitrate progress calculation:
                this._bitrateTimer = new this._BitrateTimer();
                // Reset the global progress values:
                this._progress.loaded = this._progress.total = 0;
                this._progress.bitrate = 0;
            }
            // Make sure the container objects for the .response() and
            // .progress() methods on the data object are available
            // and reset to their initial state:
            this._initResponseObject(data);
            this._initProgressObject(data);
            data._progress.loaded = data.loaded = data.uploadedBytes || 0;
            data._progress.total = data.total = this._getTotal(data.files) || 1;
            data._progress.bitrate = data.bitrate = 0;
            this._active += 1;
            // Initialize the global progress values:
            this._progress.loaded += data.loaded;
            this._progress.total += data.total;
        },

        _onDone: function (result, textStatus, jqXHR, options) {
            var total = options._progress.total,
                response = options._response;
            if (options._progress.loaded < total) {
                // Create a progress event if no final progress event
                // with loaded equaling total has been triggered:
                this._onProgress($.Event('progress', {
                    lengthComputable: true,
                    loaded: total,
                    total: total
                }), options);
            }
            response.result = options.result = result;
            response.textStatus = options.textStatus = textStatus;
            response.jqXHR = options.jqXHR = jqXHR;
            this._trigger('done', null, options);
        },

        _onFail: function (jqXHR, textStatus, errorThrown, options) {
            var response = options._response;
            if (options.recalculateProgress) {
                // Remove the failed (error or abort) file upload from
                // the global progress calculation:
                this._progress.loaded -= options._progress.loaded;
                this._progress.total -= options._progress.total;
            }
            response.jqXHR = options.jqXHR = jqXHR;
            response.textStatus = options.textStatus = textStatus;
            response.errorThrown = options.errorThrown = errorThrown;
            this._trigger('fail', null, options);
        },

        _onAlways: function (jqXHRorResult, textStatus, jqXHRorError, options) {
            // jqXHRorResult, textStatus and jqXHRorError are added to the
            // options object via done and fail callbacks
            this._trigger('always', null, options);
        },

        _onSend: function (e, data) {
            if (!data.submit) {
                this._addConvenienceMethods(e, data);
            }
            var that = this,
                jqXHR,
                aborted,
                slot,
                pipe,
                options = that._getAJAXSettings(data),
                send = function () {
                    that._sending += 1;
                    // Set timer for bitrate progress calculation:
                    options._bitrateTimer = new that._BitrateTimer();
                    jqXHR = jqXHR || (
                        ((aborted || that._trigger(
                            'send',
                            $.Event('send', {delegatedEvent: e}),
                            options
                        ) === false) &&
                        that._getXHRPromise(false, options.context, aborted)) ||
                        that._chunkedUpload(options) || $.ajax(options)
                    ).done(function (result, textStatus, jqXHR) {
                        that._onDone(result, textStatus, jqXHR, options);
                    }).fail(function (jqXHR, textStatus, errorThrown) {
                        that._onFail(jqXHR, textStatus, errorThrown, options);
                    }).always(function (jqXHRorResult, textStatus, jqXHRorError) {
                        that._onAlways(
                            jqXHRorResult,
                            textStatus,
                            jqXHRorError,
                            options
                        );
                        that._sending -= 1;
                        that._active -= 1;
                        if (options.limitConcurrentUploads &&
                                options.limitConcurrentUploads > that._sending) {
                            // Start the next queued upload,
                            // that has not been aborted:
                            var nextSlot = that._slots.shift();
                            while (nextSlot) {
                                if (that._getDeferredState(nextSlot) === 'pending') {
                                    nextSlot.resolve();
                                    break;
                                }
                                nextSlot = that._slots.shift();
                            }
                        }
                        if (that._active === 0) {
                            // The stop callback is triggered when all uploads have
                            // been completed, equivalent to the global ajaxStop event:
                            that._trigger('stop');
                        }
                    });
                    return jqXHR;
                };
            this._beforeSend(e, options);
            if (this.options.sequentialUploads ||
                    (this.options.limitConcurrentUploads &&
                    this.options.limitConcurrentUploads <= this._sending)) {
                if (this.options.limitConcurrentUploads > 1) {
                    slot = $.Deferred();
                    this._slots.push(slot);
                    pipe = slot.pipe(send);
                } else {
                    this._sequence = this._sequence.pipe(send, send);
                    pipe = this._sequence;
                }
                // Return the piped Promise object, enhanced with an abort method,
                // which is delegated to the jqXHR object of the current upload,
                // and jqXHR callbacks mapped to the equivalent Promise methods:
                pipe.abort = function () {
                    aborted = [undefined, 'abort', 'abort'];
                    if (!jqXHR) {
                        if (slot) {
                            slot.rejectWith(options.context, aborted);
                        }
                        return send();
                    }
                    return jqXHR.abort();
                };
                return this._enhancePromise(pipe);
            }
            return send();
        },

        _onAdd: function (e, data) {
            var that = this,
                result = true,
                options = $.extend({}, this.options, data),
                files = data.files,
                filesLength = files.length,
                limit = options.limitMultiFileUploads,
                limitSize = options.limitMultiFileUploadSize,
                overhead = options.limitMultiFileUploadSizeOverhead,
                batchSize = 0,
                paramName = this._getParamName(options),
                paramNameSet,
                paramNameSlice,
                fileSet,
                i,
                j = 0;
            if (limitSize && (!filesLength || files[0].size === undefined)) {
                limitSize = undefined;
            }
            if (!(options.singleFileUploads || limit || limitSize) ||
                    !this._isXHRUpload(options)) {
                fileSet = [files];
                paramNameSet = [paramName];
            } else if (!(options.singleFileUploads || limitSize) && limit) {
                fileSet = [];
                paramNameSet = [];
                for (i = 0; i < filesLength; i += limit) {
                    fileSet.push(files.slice(i, i + limit));
                    paramNameSlice = paramName.slice(i, i + limit);
                    if (!paramNameSlice.length) {
                        paramNameSlice = paramName;
                    }
                    paramNameSet.push(paramNameSlice);
                }
            } else if (!options.singleFileUploads && limitSize) {
                fileSet = [];
                paramNameSet = [];
                for (i = 0; i < filesLength; i = i + 1) {
                    batchSize += files[i].size + overhead;
                    if (i + 1 === filesLength ||
                            ((batchSize + files[i + 1].size + overhead) > limitSize) ||
                            (limit && i + 1 - j >= limit)) {
                        fileSet.push(files.slice(j, i + 1));
                        paramNameSlice = paramName.slice(j, i + 1);
                        if (!paramNameSlice.length) {
                            paramNameSlice = paramName;
                        }
                        paramNameSet.push(paramNameSlice);
                        j = i + 1;
                        batchSize = 0;
                    }
                }
            } else {
                paramNameSet = paramName;
            }
            data.originalFiles = files;
            $.each(fileSet || files, function (index, element) {
                var newData = $.extend({}, data);
                newData.files = fileSet ? element : [element];
                newData.paramName = paramNameSet[index];
                that._initResponseObject(newData);
                that._initProgressObject(newData);
                that._addConvenienceMethods(e, newData);
                result = that._trigger(
                    'add',
                    $.Event('add', {delegatedEvent: e}),
                    newData
                );
                return result;
            });
            return result;
        },

        _replaceFileInput: function (input) {
            var inputClone = input.clone(true);
            $('<form></form>').append(inputClone)[0].reset();
            // Detaching allows to insert the fileInput on another form
            // without loosing the file input value:
            input.after(inputClone).detach();
            // Avoid memory leaks with the detached file input:
            $.cleanData(input.unbind('remove'));
            // Replace the original file input element in the fileInput
            // elements set with the clone, which has been copied including
            // event handlers:
            this.options.fileInput = this.options.fileInput.map(function (i, el) {
                if (el === input[0]) {
                    return inputClone[0];
                }
                return el;
            });
            // If the widget has been initialized on the file input itself,
            // override this.element with the file input clone:
            if (input[0] === this.element[0]) {
                this.element = inputClone;
            }
        },

        _handleFileTreeEntry: function (entry, path) {
            var that = this,
                dfd = $.Deferred(),
                errorHandler = function (e) {
                    if (e && !e.entry) {
                        e.entry = entry;
                    }
                    // Since $.when returns immediately if one
                    // Deferred is rejected, we use resolve instead.
                    // This allows valid files and invalid items
                    // to be returned together in one set:
                    dfd.resolve([e]);
                },
                dirReader;
            path = path || '';
            if (entry.isFile) {
                if (entry._file) {
                    // Workaround for Chrome bug #149735
                    entry._file.relativePath = path;
                    dfd.resolve(entry._file);
                } else {
                    entry.file(function (file) {
                        file.relativePath = path;
                        dfd.resolve(file);
                    }, errorHandler);
                }
            } else if (entry.isDirectory) {
                dirReader = entry.createReader();
                dirReader.readEntries(function (entries) {
                    that._handleFileTreeEntries(
                        entries,
                        path + entry.name + '/'
                    ).done(function (files) {
                        dfd.resolve(files);
                    }).fail(errorHandler);
                }, errorHandler);
            } else {
                // Return an empy list for file system items
                // other than files or directories:
                dfd.resolve([]);
            }
            return dfd.promise();
        },

        _handleFileTreeEntries: function (entries, path) {
            var that = this;
            return $.when.apply(
                $,
                $.map(entries, function (entry) {
                    return that._handleFileTreeEntry(entry, path);
                })
            ).pipe(function () {
                return Array.prototype.concat.apply(
                    [],
                    arguments
                );
            });
        },

        _getDroppedFiles: function (dataTransfer) {
            dataTransfer = dataTransfer || {};
            var items = dataTransfer.items;
            if (items && items.length && (items[0].webkitGetAsEntry ||
                    items[0].getAsEntry)) {
                return this._handleFileTreeEntries(
                    $.map(items, function (item) {
                        var entry;
                        if (item.webkitGetAsEntry) {
                            entry = item.webkitGetAsEntry();
                            if (entry) {
                                // Workaround for Chrome bug #149735:
                                entry._file = item.getAsFile();
                            }
                            return entry;
                        }
                        return item.getAsEntry();
                    })
                );
            }
            return $.Deferred().resolve(
                $.makeArray(dataTransfer.files)
            ).promise();
        },

        _getSingleFileInputFiles: function (fileInput) {
            fileInput = $(fileInput);
            var entries = fileInput.prop('webkitEntries') ||
                    fileInput.prop('entries'),
                files,
                value;
            if (entries && entries.length) {
                return this._handleFileTreeEntries(entries);
            }
            files = $.makeArray(fileInput.prop('files'));
            if (!files.length) {
                value = fileInput.prop('value');
                if (!value) {
                    return $.Deferred().resolve([]).promise();
                }
                // If the files property is not available, the browser does not
                // support the File API and we add a pseudo File object with
                // the input value as name with path information removed:
                files = [{name: value.replace(/^.*\\/, '')}];
            } else if (files[0].name === undefined && files[0].fileName) {
                // File normalization for Safari 4 and Firefox 3:
                $.each(files, function (index, file) {
                    file.name = file.fileName;
                    file.size = file.fileSize;
                });
            }
            return $.Deferred().resolve(files).promise();
        },

        _getFileInputFiles: function (fileInput) {
            if (!(fileInput instanceof $) || fileInput.length === 1) {
                return this._getSingleFileInputFiles(fileInput);
            }
            return $.when.apply(
                $,
                $.map(fileInput, this._getSingleFileInputFiles)
            ).pipe(function () {
                return Array.prototype.concat.apply(
                    [],
                    arguments
                );
            });
        },

        _onChange: function (e) {
            var that = this,
                data = {
                    fileInput: $(e.target),
                    form: $(e.target.form)
                };
            this._getFileInputFiles(data.fileInput).always(function (files) {
                data.files = files;
                if (that.options.replaceFileInput) {
                    that._replaceFileInput(data.fileInput);
                }
                if (that._trigger(
                        'change',
                        $.Event('change', {delegatedEvent: e}),
                        data
                    ) !== false) {
                    that._onAdd(e, data);
                }
            });
        },

        _onPaste: function (e) {
            var items = e.originalEvent && e.originalEvent.clipboardData &&
                    e.originalEvent.clipboardData.items,
                data = {files: []};
            if (items && items.length) {
                $.each(items, function (index, item) {
                    var file = item.getAsFile && item.getAsFile();
                    if (file) {
                        data.files.push(file);
                    }
                });
                if (this._trigger(
                        'paste',
                        $.Event('paste', {delegatedEvent: e}),
                        data
                    ) !== false) {
                    this._onAdd(e, data);
                }
            }
        },

        _onDrop: function (e) {
            e.dataTransfer = e.originalEvent && e.originalEvent.dataTransfer;
            var that = this,
                dataTransfer = e.dataTransfer,
                data = {};
            if (dataTransfer && dataTransfer.files && dataTransfer.files.length) {
                e.preventDefault();
                this._getDroppedFiles(dataTransfer).always(function (files) {
                    data.files = files;
                    if (that._trigger(
                            'drop',
                            $.Event('drop', {delegatedEvent: e}),
                            data
                        ) !== false) {
                        that._onAdd(e, data);
                    }
                });
            }
        },

        _onDragOver: function (e) {
            e.dataTransfer = e.originalEvent && e.originalEvent.dataTransfer;
            var dataTransfer = e.dataTransfer;
            if (dataTransfer && $.inArray('Files', dataTransfer.types) !== -1 &&
                    this._trigger(
                        'dragover',
                        $.Event('dragover', {delegatedEvent: e})
                    ) !== false) {
                e.preventDefault();
                dataTransfer.dropEffect = 'copy';
            }
        },

        _initEventHandlers: function () {
            if (this._isXHRUpload(this.options)) {
                this._on(this.options.dropZone, {
                    dragover: this._onDragOver,
                    drop: this._onDrop
                });
                this._on(this.options.pasteZone, {
                    paste: this._onPaste
                });
            }
            if ($.support.fileInput) {
                this._on(this.options.fileInput, {
                    change: this._onChange
                });
            }
        },

        _destroyEventHandlers: function () {
            this._off(this.options.dropZone, 'dragover drop');
            this._off(this.options.pasteZone, 'paste');
            this._off(this.options.fileInput, 'change');
        },

        _setOption: function (key, value) {
            var reinit = $.inArray(key, this._specialOptions) !== -1;
            if (reinit) {
                this._destroyEventHandlers();
            }
            this._super(key, value);
            if (reinit) {
                this._initSpecialOptions();
                this._initEventHandlers();
            }
        },

        _initSpecialOptions: function () {
            var options = this.options;
            if (options.fileInput === undefined) {
                options.fileInput = this.element.is('input[type="file"]') ?
                        this.element : this.element.find('input[type="file"]');
            } else if (!(options.fileInput instanceof $)) {
                options.fileInput = $(options.fileInput);
            }
            if (!(options.dropZone instanceof $)) {
                options.dropZone = $(options.dropZone);
            }
            if (!(options.pasteZone instanceof $)) {
                options.pasteZone = $(options.pasteZone);
            }
        },

        _getRegExp: function (str) {
            var parts = str.split('/'),
                modifiers = parts.pop();
            parts.shift();
            return new RegExp(parts.join('/'), modifiers);
        },

        _isRegExpOption: function (key, value) {
            return key !== 'url' && $.type(value) === 'string' &&
                /^\/.*\/[igm]{0,3}$/.test(value);
        },

        _initDataAttributes: function () {
            var that = this,
                options = this.options;
            // Initialize options set via HTML5 data-attributes:
            $.each(
                $(this.element[0].cloneNode(false)).data(),
                function (key, value) {
                    if (that._isRegExpOption(key, value)) {
                        value = that._getRegExp(value);
                    }
                    options[key] = value;
                }
            );
        },

        _create: function () {
            this._initDataAttributes();
            this._initSpecialOptions();
            this._slots = [];
            this._sequence = this._getXHRPromise(true);
            this._sending = this._active = 0;
            this._initProgressObject(this);
            this._initEventHandlers();
        },

        // This method is exposed to the widget API and allows to query
        // the number of active uploads:
        active: function () {
            return this._active;
        },

        // This method is exposed to the widget API and allows to query
        // the widget upload progress.
        // It returns an object with loaded, total and bitrate properties
        // for the running uploads:
        progress: function () {
            return this._progress;
        },

        // This method is exposed to the widget API and allows adding files
        // using the fileupload API. The data parameter accepts an object which
        // must have a files property and can contain additional options:
        // .fileupload('add', {files: filesList});
        add: function (data) {
            var that = this;
            if (!data || this.options.disabled) {
                return;
            }
            if (data.fileInput && !data.files) {
                this._getFileInputFiles(data.fileInput).always(function (files) {
                    data.files = files;
                    that._onAdd(null, data);
                });
            } else {
                data.files = $.makeArray(data.files);
                this._onAdd(null, data);
            }
        },

        // This method is exposed to the widget API and allows sending files
        // using the fileupload API. The data parameter accepts an object which
        // must have a files or fileInput property and can contain additional options:
        // .fileupload('send', {files: filesList});
        // The method returns a Promise object for the file upload call.
        send: function (data) {
            if (data && !this.options.disabled) {
                if (data.fileInput && !data.files) {
                    var that = this,
                        dfd = $.Deferred(),
                        promise = dfd.promise(),
                        jqXHR,
                        aborted;
                    promise.abort = function () {
                        aborted = true;
                        if (jqXHR) {
                            return jqXHR.abort();
                        }
                        dfd.reject(null, 'abort', 'abort');
                        return promise;
                    };
                    this._getFileInputFiles(data.fileInput).always(
                        function (files) {
                            if (aborted) {
                                return;
                            }
                            if (!files.length) {
                                dfd.reject();
                                return;
                            }
                            data.files = files;
                            jqXHR = that._onSend(null, data).then(
                                function (result, textStatus, jqXHR) {
                                    dfd.resolve(result, textStatus, jqXHR);
                                },
                                function (jqXHR, textStatus, errorThrown) {
                                    dfd.reject(jqXHR, textStatus, errorThrown);
                                }
                            );
                        }
                    );
                    return this._enhancePromise(promise);
                }
                data.files = $.makeArray(data.files);
                if (data.files.length) {
                    return this._onSend(null, data);
                }
            }
            return this._getXHRPromise(false, data && data.context);
        }

    });

}));

///#source 1 1 /Scripts/jquery.iframe-transport.js
/*
 * jQuery Iframe Transport Plugin 1.8.2
 * https://github.com/blueimp/jQuery-File-Upload
 *
 * Copyright 2011, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 */

/* global define, window, document */

(function (factory) {
    'use strict';
    if (typeof define === 'function' && define.amd) {
        // Register as an anonymous AMD module:
        define(['jquery'], factory);
    } else {
        // Browser globals:
        factory(window.jQuery);
    }
}(function ($) {
    'use strict';

    // Helper variable to create unique names for the transport iframes:
    var counter = 0;

    // The iframe transport accepts four additional options:
    // options.fileInput: a jQuery collection of file input fields
    // options.paramName: the parameter name for the file form data,
    //  overrides the name property of the file input field(s),
    //  can be a string or an array of strings.
    // options.formData: an array of objects with name and value properties,
    //  equivalent to the return data of .serializeArray(), e.g.:
    //  [{name: 'a', value: 1}, {name: 'b', value: 2}]
    // options.initialIframeSrc: the URL of the initial iframe src,
    //  by default set to "javascript:false;"
    $.ajaxTransport('iframe', function (options) {
        if (options.async) {
            // javascript:false as initial iframe src
            // prevents warning popups on HTTPS in IE6:
            /*jshint scripturl: true */
            var initialIframeSrc = options.initialIframeSrc || 'javascript:false;',
            /*jshint scripturl: false */
                form,
                iframe,
                addParamChar;
            return {
                send: function (_, completeCallback) {
                    form = $('<form style="display:none;"></form>');
                    form.attr('accept-charset', options.formAcceptCharset);
                    addParamChar = /\?/.test(options.url) ? '&' : '?';
                    // XDomainRequest only supports GET and POST:
                    if (options.type === 'DELETE') {
                        options.url = options.url + addParamChar + '_method=DELETE';
                        options.type = 'POST';
                    } else if (options.type === 'PUT') {
                        options.url = options.url + addParamChar + '_method=PUT';
                        options.type = 'POST';
                    } else if (options.type === 'PATCH') {
                        options.url = options.url + addParamChar + '_method=PATCH';
                        options.type = 'POST';
                    }
                    // IE versions below IE8 cannot set the name property of
                    // elements that have already been added to the DOM,
                    // so we set the name along with the iframe HTML markup:
                    counter += 1;
                    iframe = $(
                        '<iframe src="' + initialIframeSrc +
                            '" name="iframe-transport-' + counter + '"></iframe>'
                    ).bind('load', function () {
                        var fileInputClones,
                            paramNames = $.isArray(options.paramName) ?
                                    options.paramName : [options.paramName];
                        iframe
                            .unbind('load')
                            .bind('load', function () {
                                var response;
                                // Wrap in a try/catch block to catch exceptions thrown
                                // when trying to access cross-domain iframe contents:
                                try {
                                    response = iframe.contents();
                                    // Google Chrome and Firefox do not throw an
                                    // exception when calling iframe.contents() on
                                    // cross-domain requests, so we unify the response:
                                    if (!response.length || !response[0].firstChild) {
                                        throw new Error();
                                    }
                                } catch (e) {
                                    response = undefined;
                                }
                                // The complete callback returns the
                                // iframe content document as response object:
                                completeCallback(
                                    200,
                                    'success',
                                    {'iframe': response}
                                );
                                // Fix for IE endless progress bar activity bug
                                // (happens on form submits to iframe targets):
                                $('<iframe src="' + initialIframeSrc + '"></iframe>')
                                    .appendTo(form);
                                window.setTimeout(function () {
                                    // Removing the form in a setTimeout call
                                    // allows Chrome's developer tools to display
                                    // the response result
                                    form.remove();
                                }, 0);
                            });
                        form
                            .prop('target', iframe.prop('name'))
                            .prop('action', options.url)
                            .prop('method', options.type);
                        if (options.formData) {
                            $.each(options.formData, function (index, field) {
                                $('<input type="hidden"/>')
                                    .prop('name', field.name)
                                    .val(field.value)
                                    .appendTo(form);
                            });
                        }
                        if (options.fileInput && options.fileInput.length &&
                                options.type === 'POST') {
                            fileInputClones = options.fileInput.clone();
                            // Insert a clone for each file input field:
                            options.fileInput.after(function (index) {
                                return fileInputClones[index];
                            });
                            if (options.paramName) {
                                options.fileInput.each(function (index) {
                                    $(this).prop(
                                        'name',
                                        paramNames[index] || options.paramName
                                    );
                                });
                            }
                            // Appending the file input fields to the hidden form
                            // removes them from their original location:
                            form
                                .append(options.fileInput)
                                .prop('enctype', 'multipart/form-data')
                                // enctype must be set as encoding for IE:
                                .prop('encoding', 'multipart/form-data');
                            // Remove the HTML5 form attribute from the input(s):
                            options.fileInput.removeAttr('form');
                        }
                        form.submit();
                        // Insert the file input fields at their original location
                        // by replacing the clones with the originals:
                        if (fileInputClones && fileInputClones.length) {
                            options.fileInput.each(function (index, input) {
                                var clone = $(fileInputClones[index]);
                                // Restore the original name and form properties:
                                $(input)
                                    .prop('name', clone.prop('name'))
                                    .attr('form', clone.attr('form'));
                                clone.replaceWith(input);
                            });
                        }
                    });
                    form.append(iframe).appendTo(document.body);
                },
                abort: function () {
                    if (iframe) {
                        // javascript:false as iframe src aborts the request
                        // and prevents warning popups on HTTPS in IE6.
                        // concat is used to avoid the "Script URL" JSLint error:
                        iframe
                            .unbind('load')
                            .prop('src', initialIframeSrc);
                    }
                    if (form) {
                        form.remove();
                    }
                }
            };
        }
    });

    // The iframe transport returns the iframe content document as response.
    // The following adds converters from iframe to text, json, html, xml
    // and script.
    // Please note that the Content-Type for JSON responses has to be text/plain
    // or text/html, if the browser doesn't include application/json in the
    // Accept header, else IE will show a download dialog.
    // The Content-Type for XML responses on the other hand has to be always
    // application/xml or text/xml, so IE properly parses the XML response.
    // See also
    // https://github.com/blueimp/jQuery-File-Upload/wiki/Setup#content-type-negotiation
    $.ajaxSetup({
        converters: {
            'iframe text': function (iframe) {
                return iframe && $(iframe[0].body).text();
            },
            'iframe json': function (iframe) {
                return iframe && $.parseJSON($(iframe[0].body).text());
            },
            'iframe html': function (iframe) {
                return iframe && $(iframe[0].body).html();
            },
            'iframe xml': function (iframe) {
                var xmlDoc = iframe && iframe[0];
                return xmlDoc && $.isXMLDoc(xmlDoc) ? xmlDoc :
                        $.parseXML((xmlDoc.XMLDocument && xmlDoc.XMLDocument.xml) ||
                            $(xmlDoc.body).html());
            },
            'iframe script': function (iframe) {
                return iframe && $.globalEval($(iframe[0].body).text());
            }
        }
    });

}));

///#source 1 1 /Scripts/Publishing/athoc.iws.scenario.js
/// <reference path="athoc-knockout-grid.js" />
/* define javascript namespace for Scenario */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};

if (athoc.iws) {
    athoc.iws.scenario = function () {
        return {
            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for scenario list, will be triggered before document load
            init: function (targetUsersParameters, deviceOptionParameters, massDeviceParameters) {
                athoc.iws.scenario.initBreadcrumb();
                navigateToPage('scenarioList', function () { });

                athoc.iws.publishing.targetUsers.init(targetUsersParameters);
                athoc.iws.publishing.personalDeviceOptions.init(deviceOptionParameters);
                athoc.iws.publishing.massdevices.init(massDeviceParameters);


                var orgParameters = {
                    resources: athoc.iws.scenario.resources,
                    context: "Scenario",
                    orgSectionDivs: {
                        noOrganizationDiv: "#noOrganizationDiv",
                        organizationTableDiv: "#organizationTableDiv",
                        targetOrgStatus: "#targetOrgStatus",
                        targetOrgSection: "#targetOrgSection",
                        targetedOrgCount: "#targetedOrgCount"
                    }

                }
                athoc.iws.publishing.targetOrg.init(orgParameters);

            },

            //load method, will be tirggered on document load
            load: function () {
                athoc.iws.scenario.bindBreadcrumb();

                $("#scenario-button").click(function () {
                    var id = $("#scenario-id").val();
                    if ($.isNumeric(id)) {
                        athoc.iws.scenario.viewScenarioDetail(id);
                    }
                });

                $("#btn_new").click(function () { athoc.iws.scenario.createScenario(); });

                $("#btn_duplicate").click(function () { athoc.iws.scenario.duplicateScenario(); });

                $("#btn_cancel_detail").click(function () {
                    athoc.iws.scenario.viewScenarioList();
                });
                $("#deleteCancelScenarioButton").click(function () { $("#deleteScenario").modal('hide'); });              
                $("#btn_save").click(function () { athoc.iws.scenario.detail.saveScenario(); });

                athoc.iws.scenario.list.load();

                window.onbeforeunload = function (event) {
                    var isModified = athoc.iws.publishing.detail.isChanged();

                    if (isModified) {
                        return athoc.iws.publishing.resources.Unsaved_Data_Text;
                    }
                };

            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {
                var sn = athoc.iws.scenario;

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = sn.breadcrumbModel;

                //Sub-level breadcrumb
                var scenarioListBreadCrumb = new Breadcrumb('dlLink', sn.resources.Scenario_Breadcrumb_ScenarioList, '', function () {
                    athoc.iws.scenario.viewScenarioList();
                });

                var scenarioDetailBreadCrumb = new Breadcrumb('dlViewLink', '', '', function () {
                    athoc.iws.scenario.showDetail();
                });

                //Page breadcrumb
                var scenarioListPageBreadcrumb = new PageBreadcrumb('scenarioList', sn.resources.Scenario_Breadcrumb_ScenarioList, [], '');
                var dlViewPageBreadcrumb = new PageBreadcrumb('scenarioDetail', '', [scenarioListBreadCrumb], '');

                breadcrumbsModel.addPage(scenarioListPageBreadcrumb);
                breadcrumbsModel.addPage(dlViewPageBreadcrumb);
            },

            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.scenario.breadcrumbModel;
                breadcrumbsModel.SelectedPage('scenarioList');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            refreshList: false,

            viewScenarioList: function (refresh) {
                var isModified = athoc.iws.publishing.detail.isChanged();

                if (isModified == true) {
                    var confirmLeave = confirm(athoc.iws.scenario.resources.Unsaved_Data_Text);
                    if (!confirmLeave) {
                        return;
                    } else {
                        athoc.iws.publishing.targetUsers.resetTargetingInfo();
                    }
                } else {
                    athoc.iws.publishing.targetUsers.resetTargetingInfo();
                }

                athoc.iws.publishing.detail.setChanged(false);

                navigateToPage('scenarioList', function () { });

                var breadcrumbsModel = athoc.iws.scenario.breadcrumbModel;
                breadcrumbsModel.SelectedPage('scenarioList');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);

                if (refresh || this.refreshList) {
                    athoc.iws.scenario.list.refreshGrid();
                }
                this.refreshList = false;
            },

            viewScenarioDetail: function (id) {
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.scenario.resources.General_LoadingMessage }).showLoader();

                $(".publishing-detail").hide();
                navigateToPage('scenarioDetail', function () { });
                var breadcrumbsModel = athoc.iws.scenario.breadcrumbModel;
                breadcrumbsModel.SelectedPage('scenarioDetail');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);

                $.AjaxLoader.hideLoader();

                athoc.iws.scenario.detail.editScenario(id);
            },

            createScenario: function () {
                $(".publishing-detail").hide();
                navigateToPage('scenarioDetail', function () { });

                var breadcrumbsModel = athoc.iws.scenario.breadcrumbModel;
                breadcrumbsModel.SelectedPage('scenarioDetail');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);
                $.AjaxLoader.hideLoader();

                athoc.iws.scenario.detail.createScenario();
            },

            duplicateScenario: function () {
                var id = athoc.iws.scenario.list.getSingleSelection();

                if (id <= 0)
                    return;

                $(".publishing-detail").hide();
                navigateToPage('scenarioDetail', function () { });

                var breadcrumbsModel = athoc.iws.scenario.breadcrumbModel;
                breadcrumbsModel.SelectedPage('scenarioDetail');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);
                $.AjaxLoader.hideLoader();

                athoc.iws.scenario.detail.duplicateScenario(id);
            },

            deleteScenario: function (ids, names, deleteSuccessCallback) {
                var self = this;

                var nameTags = "";
                names.sort();
                for (var i = 0; i < names.length; i++) {

                    nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(names[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(names[i]) + "</div>";
                }


                $("#itemsToDelete").html("<div class='mar-top10'>" + nameTags + "</div>");
                $('#deleteScenario').modal('show');


                $('#deleteScenarioButton').off('click').on('click', function (e) {
                    $('#deleteScenario').modal('hide');
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 1200, displayText: athoc.iws.scenario.resources.General_LoadingMessage }).showLoader();

                    var myAjaxOptions = {
                        url: athoc.iws.scenario.urls.DeleteScenarioUrl,
                        contentType: 'application/json',
                        dataType: 'json',
                        data: JSON.stringify(ids),
                        type: 'POST',
                    };

                    $.AjaxLoader.hideLoader();

                    var onSuccess = function () {
                        if (typeof deleteSuccessCallback == "function") {
                            deleteSuccessCallback();
                        }
                    }

                    var ajaxOptions = $.extend({}, AjaxUtility(null, onSuccess).ajaxPostOptions, myAjaxOptions);
                    $.ajax(ajaxOptions);

                });


            }
        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.scenario.list.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.scenario = athoc.iws.scenario || {};

if (athoc.iws.scenario) {
    athoc.iws.scenario.list = function () {
        var datasource = null;
        //var filter = {};
        //var getChannels = true;
        var sortState;
        return {
            IsRightToLeft: false,

            ViewModel: {},

            loadViewModel: function () {
                this.ViewModel = kendo.observable(
                 {
                     TotalCount: 0,
                     SelectedCount: 0,
                     QuickOnly: false,
                     RecurrentOnly: false,
                     ChannelId: -1,
                     SearchText: "",
                     DupDisabled: true,
                     DelDisabled: true,
                     FilterDisabled: true,
                     Channels: { Id: -1, Name: athoc.iws.scenario.resources.Scenario_List_ChannelAll },
                     FilterScenarioList: function (e) {
                         //only update when enter key is pressed and when the apply button is clicked
                         if ($.hotkeys.enter(e) || e.target.id == "btn_filter")
                             athoc.iws.scenario.list.refreshGrid();

                         if (e.target.id == "btn_filter")
                             $("#btn_clear").focus();
                     },
                     ClearFilters: function (e) {
                         this.set("QuickOnly", false);
                         this.set("RecurrentOnly", false);
                         this.set("ChannelId", -1);
                         this.set("SearchText", "");
                         this.set("DupDisabled", true);
                         this.set("DelDisabled", true);
                         athoc.iws.scenario.list.refreshGrid();
                         //$("#txtSearch").blur(); fix to 6139 and removing it fixes 6283
                         var sp = $("#channels").data("selectpicker");
                         if (sp) {
                             sp.refresh();
                         }
                         e.preventDefault();
                     },
                 });

                //make a seperate call to load channels since we are using standard <select>
                $.ajax({
                    cache: false,
                    url: athoc.iws.scenario.urls.GetChannelsUrl,
                    success: function (data) {
                        data.splice(0, 0, { Id: -1, Name: athoc.iws.scenario.resources.Scenario_List_ChannelAll });
                        athoc.iws.scenario.list.ViewModel.set("Channels", data);
                        athoc.iws.publishing.scenario.setChannels(data);
                        $("#channels").selectpicker();

                    },
                    error: function (e) {
                        athoc.iws.scenario.list.handleError(e);
                    },
                });
            },

            load: function () {

                this.loadViewModel();
                kendo.bind($(".kendoBound"), this.ViewModel);

                this.createScenarioListGrid();

                var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
                if (gridHeader) {
                    gridHeader.addClass('table-header affix');
                }

                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");

                this.ViewModel.bind("change", function (e) {
                    switch (e.field) {
                        case "QuickOnly":
                        case "RecurrentOnly":
                        case "ChannelId":
                        case "SearchText":
                            //if any filter field is changed, we enable the apply filter button
                            //$("#btn_filter").removeClass("disabled");
                            athoc.iws.scenario.list.ViewModel.set("FilterDisabled", false);
                            break;
                    }
                });
            },

            handleError: function (e) {
                if (e != undefined && e.status == 401 || (e != undefined && e.xhr != undefined && e.xhr.status == 401)) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },

            createScenarioListGrid: function () {
                var ro = athoc.iws.utils.urlHelper.getUrlParameter('ro') == 'true' ? true : false;
                this.ViewModel.set("RecurrentOnly", ro);

                var self = this;
                $("#btn_delete").click(function () { self.deleteScenariosFromList(); }); //moving delete button binding here to contain deletion from list (which is diff from deletion from detail page per se) within this library

                var url = athoc.iws.scenario.urls.GetScenarioListUrl;

                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.scenario.list.ViewModel);
                            //options.getChannels = getChannels;
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                        //commented this out because requestStart gets triggered on client side sorting and paging...no need to display the loader in these events.
                        //if (e.type == 'read') 
                        //    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%' }).showLoader();
                    },
                    requestEnd: function (e) {
                        //if (getChannels) {
                        //    _.each(e.response.Channels, function (item, index) {
                        //        $("#channelSelector").append("<option value='" + item.Id + "'>" + item.Name + "</option>");
                        //    });

                        //}
                        //getChannels = false;
                          $.AjaxLoader.hideLoader();
                        if (e.response) {
                            athoc.iws.scenario.list.ViewModel.set("TotalCount", e.response.length);
                            //clear selected
                            athoc.iws.scenario.list.ViewModel.set("SelectedCount", 0);
                            //reset all buttons
                            athoc.iws.scenario.list.reInitializeButtons();
                        }
                    },
                    //schema: {
                    //    data: "Data",
                    //    total: "TotalCount",
                    //},
                    //serverPaging: true,
                    //serverSorting: true,
                    //serverFiltering:true,
                    sort: { field: "Name", dir: "asc" },
                    pageSize: 50,
                    error: function (e) {
                        athoc.iws.scenario.list.handleError(e);
                    },
                    change: function (e) {
                        athoc.iws.scenario.list.retainSelectAll();
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            //when sort changes, go to first page.
                            this.page(1);
                        }
                        //scrolling to the top when paging and sorting.
                        $("html,body").scrollTop(0);
                    }
                });

                $("#pageInfo").kendoPager({
                    dataSource: datasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.scenario.resources.Scenario_List_PageInfo,
                        empty: athoc.iws.scenario.resources.Scenario_List_PageInfo_NoRecords
                    }
                    //refresh: true,
                    //width: 300,
                });

                var grid = $("#scenarioList").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    //height: 650,
                    //navigatable: true,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.scenario.resources.Scenario_List_PageInfo),
                            empty: $.htmlDecode(athoc.iws.scenario.resources.Scenario_List_PageInfo_NoRecords),
                            itemsPerPage: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Items_Per_Page),
                            first: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                {
                                    field: "ScenarioId",
                                    hidden: true
                                },
                                {
                                    field: "IsChecked",
                                    template: $("#scenario-checkbox-template").html(),
                                    width: 40,
                                    headerTemplate: kendo.format('<div align="center"><input type="checkbox" class="senario-select" id="senario-select-all" title="{0}" /></div>', athoc.iws.scenario.resources.Scenario_List_SelectAll),
                                    sortable: false
                                },
                                {
                                    field: "Name",
                                    title: athoc.iws.scenario.resources.Scenario_List_Name,
                                    width: 300
                                },
                                {
                                    field: "ChannelName",
                                    title: athoc.iws.scenario.resources.Scenario_List_ChannelName,
                                    template: '<span class="cellTooltip" title="#=ChannelName#">#=ChannelName#</span>',
                                    width: 250,
                                    hidden: !(athoc.iws.publishing.settings.IsChannelSupported) //hide "Channel" for affiliate VPS
                                },
                                {
                                    field: "NextRecurrence",
                                    title: athoc.iws.scenario.resources.Scenario_List_NextOccurrence,
                                    template: '<span class="cellTooltip" title="#=NextRecurrenceString#">#=NextRecurrenceString#</span>',
                                    width: 200,
                                    hidden: !(athoc.iws.publishing.settings.IsSchedulingSupported) //hide "NextRecurrence" for affiliate VPS
                                },
                                //{
                                //    field: "IsQuickPublish",
                                //    title: athoc.iws.scenario.resources.Scenario_List_QuickPublish,
                                //    template: $("#scenario-quickpublish-template").html(),
                                //},
                            ],
                    dataBound: athoc.iws.scenario.list.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                    }
                }).data().kendoGrid;

                var $template = kendo.template($("#scenario-tooltip-template").html());
                $("#scenarioList").kendoTooltip({
                    filter: "td:nth-child(3)", //this filter selects the first column cells
                    content: function (e) {
                        var dataItem = $("#scenarioList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    }
                });

                this.refreshGrid();
                athoc.iws.scenario.list.bindSelectAll();
            },

            reInitializeButtons: function () {
                //$("#btn_delete").addClass("disabled");
                //$("#btn_duplicate").addClass("disabled");
                athoc.iws.scenario.list.ViewModel.set("FilterDisabled", true);
                //$("#btn_filter").addClass("disabled");
            },

            refreshGrid: function () {
                //show the loader when we make a request to the server...
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.scenario.resources.General_LoadingMessage }).showLoader();
                //Per telerik, this will set the page only after datasource refreshes.
                datasource.one("change", function () {
                    //pagination needs to be reset after a reload
                    this.page(1);
                });
                datasource.read();
            },
            OnDataBound: function () {
                athoc.iws.scenario.list.bindCheckboxChanged();
                $("#scenarioList tbody").find("tr").attr("tabindex", "0");
                // this.pager.element.hide();

                //if ($("#senario-select-all").is(':checked')) {
                //    $(".senario-select").prop('checked', true);
                //}

                var grid = $("#scenarioList").data("kendoGrid");
                var data = grid.dataSource.data();

                $(grid.tbody).unbind("click");

                $(grid.tbody).on("click", "td", function (e) {

                    var row = $(this).closest("tr");
                    var rowIdx = $("tr", grid.tbody).index(row);
                    var colIdx = $("td", row).index(this);

                    if (colIdx > 1 && colIdx < 5) {
                        var view = grid.dataSource.view();
                        var model = view[rowIdx];
                        athoc.iws.scenario.viewScenarioDetail(model.ScenarioId);
                    }

                    e.stopPropagation();

                });

                $(grid.tbody).on("keypress", "tr", function (e) {

                    var code = e.keyCode || e.which;

                    if (code == 13) {
                        var row = $(this);
                        var rowIdx = $("tr", grid.tbody).index(row);
                        var model = data[rowIdx];
                        athoc.iws.scenario.viewScenarioDetail(model.ScenarioId);
                    }
                });

                if (athoc.iws.scenario.list.IsRightToLeft) {
                    $("#scenarioList").find('.pull-right').addClass('pull-left');
                    $("#scenarioList").find('.pull-right').removeClass('pull-right');
                }
            },

            bindSelectAll: function () {
                $("#senario-select-all").change(function () {
                    //change the underlying observable...
                    var checked = $(this).is(':checked');
                    var grid = $('#scenarioList').data().kendoGrid;
                    //dataSource.view() returns the page not the entire dataset.
                    $.each(grid.dataSource.view(), function (i, item) {
                        if (!(item.IsDefaultforNewAlert || item.IsDefaultforNewScenario || item.IsSystem))
                            item.IsChecked = checked;
                    });
                    grid.refresh();//update the grid...
                    athoc.iws.scenario.list.updateSelectedTotal();
                    //$(".senario-select").prop('checked', $(this).is(':checked'));
                });
            },

            bindCheckboxChanged: function () {
                var grid = $('#scenarioList').data().kendoGrid;
                grid.tbody.on("change", ".senario-select", function (e) {
                    var row = $(e.target).closest("tr");
                    var item = grid.dataItem(row);
                    item.IsChecked = $(e.target).is(":checked");
                    athoc.iws.scenario.list.retainSelectAll();
                    athoc.iws.scenario.list.updateSelectedTotal();
                });
            },

            retainSelectAll: function () {
                var items = datasource.view();
                //get the non selectable items for the current page.
                var nonSelectable = $.grep(items, function (v) {
                    return (v.IsDefaultforNewAlert || v.IsDefaultforNewScenario || v.IsSystem);
                });
                //get the selected items for the current page.
                var selected = $.grep(items, function (v) {
                    return v.IsChecked;
                });
                //if the selected count matches the current page size - the non selectable count
                //then 'select all' should be checked.
                var checked = selected.length > 0 && (items.length - nonSelectable.length) == selected.length;
                $("#senario-select-all").prop('checked', checked);
            },

            updateSelectedTotal: function () {
                var items = datasource.data();
                var r = $.grep(items, function (v) {
                    return v.IsChecked;
                });
                athoc.iws.scenario.list.toggleButtonStates(r.length);
                athoc.iws.scenario.list.ViewModel.set("SelectedCount", r.length);
            },

            getSingleSelection: function () {
                var items = datasource.data();
                var selected = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                if (selected.length == 1) {
                    return selected[0].ScenarioId;
                }

                return -1;
            },
            toggleButtonStates: function (count) {
                if (count < 1) {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", true);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", true);
                }
                else if (count == 1) {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", false);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", false);
                }
                else {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", true);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", false);
                }
            },
            deleteScenariosFromList: function () {
                var items = datasource.data();
                var selected = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                var selectedIds = _.pluck(selected, "ScenarioId");
                var selectedNames = _.pluck(selected, "Name");



                var self = this;
                var deleteSuccessCallback = function () {
                    self.refreshGrid();
                }
                athoc.iws.scenario.deleteScenario(selectedIds, selectedNames, deleteSuccessCallback);
            }
        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.scenario.detail.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.scenario = athoc.iws.scenario || {};

if (athoc.iws.scenario) {
    athoc.iws.scenario.detail = function () {
        return {
            parameters: null,
            init: function (args) {
                this.parameters = args;
            },
            //edit scenario
            editScenario: function (id) {
                $("#scenarioInfoSection").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.scenario.urls.GetScenarioDetailUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true, id, true);

                //athoc.iws.publishing.targetUsers.load(id);

            },

            //create scenario
            createScenario: function () {
                $("#scenarioInfoSection").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.scenario.urls.CreateScenarioUrl;

                athoc.iws.publishing.detail.loadPublishingModel(loadUrl);

                athoc.iws.publishing.targetUsers.load(0);

            },

            //duplicate sceanrio
            duplicateScenario: function (id) {
                $("#scenarioInfoSection").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.scenario.urls.DuplicateScenarioUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl,undefined,id,true);

                //athoc.iws.publishing.targetUsers.load(id);
            },

            //save scenario
            saveScenario: function () {
                //set the flat to reload
                athoc.iws.scenario.refreshList = true;

                //Check if all sections are valid
                var isValid = athoc.iws.publishing.content.isValid() && athoc.iws.publishing.scenario.isValid()
                    && !athoc.iws.scenario.schedule.isInErrorState;

                if (!isValid) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.scenario.resources.Scenario_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(0);
                    return false;
                }

                athoc.iws.publishing.detail.setChanged(false);

                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
                //Get updated data from each section in viewmodel
                var scenario = {
                    EntityId: athoc.iws.publishing.detail.viewModel.EntityId,
                    IsReadyToPublish: athoc.iws.publishing.detail.isReadyToPublish(),
                    ScenarioSection: athoc.iws.publishing.scenario.getModel(),
                    Content: athoc.iws.publishing.content.getModel(),
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    TargetOrg: athoc.iws.publishing.targetOrg.getModel(),
                    ScenarioSettings: athoc.iws.scenario.settings.getModel(),
                    ScenarioScheduleSettings: athoc.iws.scenario.schedule.getModel(),
                    MassDevices: massDeviceModel == null ? [] : massDeviceModel.MassDevices,
                    MassDeviceGroupOptions: massDeviceModel == null ? [] : massDeviceModel.MassDeviceGroupOptions,
                    AllPlaceHolderIds: athoc.iws.publishing.getPlaceholderList(),
                    FillCount: athoc.iws.publishing.fillcount.getModel(),
                };

                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        url: athoc.iws.scenario.urls.SaveScenarioUrl,
                        contentType: false,
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(scenario)
                    };
                
                var ajaxSuccess = function (data) {
                    if (data.Success) {
                        athoc.iws.publishing.detail.resetLoadedStatus();

                        athoc.iws.publishing.detail.bindModel(data, true);

                       

                        $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.scenario.resources.Scenario_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(0);
                        athoc.iws.publishing.targetUsers.load(data.Data.EntityId);

                    } else {
                        $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(0);
                    }
                    $.AjaxLoader.hideLoader();
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;
            },
        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.js
/* define javascript namespace for Scenario */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};

if (athoc.iws) {
    athoc.iws.publishing = function () {
        
        return {
            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //Publisher settings to show/hide features
            settings: {
                IsGroupBlockSupported: false,
                IsAdvancedQuerySuuported: false,
                IsIndividualUserTargetingSupported: false,
                IsTargetByAreaSupported: false,
                IsDropboxSupported: false,
                IsMassDeviceTargetSupported: false,
                IsCallbridgeOptionSupported: false,
                IsSchedulingSupported: false,
                IsTestAlertSupported: false,
                IsPrintAlertSupported: false,
                IsDeviceOptionSupported: false,
                IsAlertTemplateSettingSupported: false,
                IsPlaceholderSupported: false,
                IsDeviceDeliveryOrderSupported: false,
                IsChannelSupported: false,
                IndividualUserTargetSelectionLimit: 500,
            },

            SetSectionStatus: function (statusDivSelector, newStatus) {//newStatus: open/notReady/ready
                var className = "open";
                var tooltip = this.resources.Publishing_Section_Empty_Tooltip;

                switch (newStatus) {
                    case "open":
                        className = "open";
                        tooltip = this.resources.Publishing_Section_Empty_Tooltip;
                        break;
                    case "notReady":
                        className = "not-ready";
                        tooltip = this.resources.Publishing_Section_NotReady_Tooltip;
                        break;
                    case "ready":
                        className = "ready";
                        tooltip = this.resources.Publishing_Section_Ready_Tooltip;
                        break;
                }
                athoc.iws.publishing.detail.checkStatusChange();                
                this.onReadyChange(className == 'ready' ? true : false);
                $(statusDivSelector).removeClass("open").removeClass("not-ready").removeClass("ready").addClass(className).attr("title", tooltip);
            },

            //modified the method and passing targetedUsers, blockedUsers as parameters
            UpdateContactInfo: function (EntityId, Context, selectedTreeNodes, selectedDevices, successCallBack, errorCallBack, queryCriteria, targetedArea, targetedUsers, blockedUsers, rbtCriteria) {
                var self = this;
                var targetingCriteria = queryCriteria;
                if (rbtCriteria != null)
                    if (rbtCriteria.EntityFilterId != "")
                        targetingCriteria = null;

                //turn on now loading
                var criteriaToPass = {
                    SelectedTreeNodes: selectedTreeNodes,
                    SelectedDevices: selectedDevices,
                    EntityId: EntityId,
                    TargetedCriteria: targetingCriteria,
                    PublishingContext: Context,
                    TargetedArea: targetedArea,
                    TargetedUsers: targetedUsers,
                    BlockedUsers: blockedUsers,
                    RbtCriteria: rbtCriteria,
                }

                var contactAjaxOption =
                    {
                        url: athoc.iws.publishing.urls.RefreshContactInfoUrl,
                        contentType: 'application/json',
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(criteriaToPass),
                        cache: false
                    };

                var userInfoSuccess = function (data) {
                    successCallBack(data);
                };

                var userInfoError = function (error) {
                    errorCallBack(error);
                };

                var ajaxOptions = $.extend({}, AjaxUtility(userInfoError, userInfoSuccess).ajaxPostOptions, contactAjaxOption);
                $.ajax(ajaxOptions);

            },
            getErrorTitleList: function () {
                var errorTitleStrings = new Array();
                //To fill the Message popup title strings from resource 
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Information);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Warning);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Error);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Success);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Completed);
                return errorTitleStrings;
            },
            getPlaceholderList: function () {
                var patt = /\[\[(.+?)\]\]/g; ///\[\[(\w+\s?\w+)=?(.*?)\]\]/g;

                var nameArray = new Array();

                $(".needs-placeholder").each(function () {

                    //check to see if this item is in device options. 
                    //if so, need to check to make sure corresponding devicegroup/device is targeted. Otherwise, we should ignore this input/textbox.
                    if (typeof $(this).attr("device_group_id") != "undefined")
                        if (!athoc.iws.publishing.massdevices.IsThisDeviceGroupTargeted($(this).attr("device_group_id"))
                            && !athoc.iws.publishing.targetUsers.isThisDeviceGroupTargeted($(this).attr("device_group_id"))) {
                            return true;
                        }

                    var customTxt = $(this).val();
                    var matches = customTxt.match(patt);
                    if (matches != null) {
                        for (var i = 0; i < matches.length; i++) {
                            var m = matches[i].substr(2, matches[i].length - 4);
                            if (m.length > 0 && $.inArray(m, nameArray) == -1) {
                                nameArray.push({ Name: m, ControlId: $(this).attr('id') });
                            }
                        }
                    }
                });

                var idArray = new Array();
                for (var i = 0; i < nameArray.length; i++) {
                    var found = _.find(athoc.iws.publishing.placeHolderItems, function (item) {
                        if (nameArray[i].Name == item.Name)
                            return true;
                    });

                    if (found) {
                        if (idArray.indexOf(found.Id) == -1) {
                            idArray.push(found.Id)
                        }
                    }

                }
                return idArray;


            },
            onReadyChange: function (isReady) { },
        }
    }();
};
///#source 1 1 /Scripts/Publishing/athoc.iws.scenario.settings.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.scenario = athoc.iws.scenario || {};

if (athoc.iws.scenario) {
    athoc.iws.scenario.settings = function () {
        return {
            isChanged: false,
            IsRightToLeft: false,
            bindflag: true,
            selectedCount: 0,
            enabledDevices: [],
            errorflag: false,
            isFillCountEnabled: false,
            viewModel: {
                scenariosettingstmp: ko.observableArray(),
                scenariosettings: ko.observableArray(),

            },
            ReadonlyViewModel:
                        {
                            applysettings: [],
                        },

            load: function () {
                //To open scenario settings popup
                $("#btn_scenariosettings").click(function () {
                    athoc.iws.scenario.settings.bindflag = false;
                    $("#ScenarioSettings").show();
                    $("#backshade").show();
                    athoc.iws.scenario.settings.resizeModalBasedOnScreen($("#ScenarioSettings"));
                    $('.finger-tab.scenario-content').click();
                });
                //To save scenario setting details
                $("#btn_SettingsSave").click(function () {
                    athoc.iws.scenario.settings.saveUserSettings();
                    if (!athoc.iws.scenario.settings.errorflag)
                        $("#backshade").hide();
                    athoc.iws.scenario.settings.bindflag = true;
                });

                //To redirect to Scenario Page
                $("#btn_SettingsCancel").click(function () {
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp = ko.mapping.fromJS(athoc.iws.scenario.settings.viewModel.scenariosettings);
                    athoc.iws.scenario.settings.bindflag = true;
                    ko.cleanNode($("#ContentSettings").get(0));
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#ContentSettings").get(0));

                    ko.cleanNode($("#UserSettings").get(0));
                    $("#personaldevicesdisplaysettings").html("");
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#UserSettings").get(0));

                    if ($("#DevicesSettings").length > 0) {
                        ko.cleanNode($("#DevicesSettings").get(0));
                        $("#massdevicesdisplaysettings").html("");
                        ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#DevicesSettings").get(0));
                    }
                    if ($("#ScheduleSettings").length > 0) {
                        ko.cleanNode($("#ScheduleSettings").get(0));
                        ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#ScheduleSettings").get(0));
                    }

                    if ($("#OrganizationSettings").length > 0) {
                        ko.cleanNode($("#OrganizationSettings").get(0));
                        ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#OrganizationSettings").get(0));
                    }

                    if (athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization && !(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByAreaEnabled()))
                        ($("#chkEnableTargByArea")[0].checked) = false;

                    $("#ScenarioSettings").hide();
                    $("#backshade").hide();
                });
                /*START finger tabs*/
                $('.finger-tab.scenario-content').click(function () {
                    $('.finger-tab').removeClass('selected');
                    $('.finger-tab.scenario-content').addClass('selected');
                    $('#scenarioUsers,  #scenarioOrganization, #scenarioDevices, #scheduleSettings, #workflow').hide();
                    $('#scenarioContent').show();
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp = ko.mapping.fromJS(athoc.iws.scenario.settings.viewModel.scenariosettings);
                    if (!(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByAreaEnabled()))
                        ($("#chkEnableTargByArea")[0].checked) = false;
                });
                $('.finger-tab.scenario-users').click(function () {
                    $('.finger-tab').removeClass('selected');
                    $('.finger-tab.scenario-users').addClass('selected');
                    $('#scenarioContent,  #scenarioOrganization, #scenarioDevices, #scheduleSettings, #workflow').hide();
                    $('#scenarioUsers').show();
                });
                $('.finger-tab.scenario-organization').click(function () {
                    $('.finger-tab').removeClass('selected');
                    $('.finger-tab.scenario-organization').addClass('selected');
                    $('#scenarioUsers,  #scenarioContent, #scenarioDevices, #scheduleSettings').hide();
                    $('#scenarioOrganization').show();
                });
                $('.finger-tab.scenario-devices').click(function () {
                    $('.finger-tab').removeClass('selected');
                    $('.finger-tab.scenario-devices').addClass('selected');
                    $('#scenarioUsers,  #scenarioOrganization, #scenarioContent, #scheduleSettings').hide();
                    $('#scenarioDevices').show();
                });
                $('.finger-tab.scenario-schedule').click(function () {
                    $('.finger-tab').removeClass('selected');
                    $('.finger-tab.scenario-schedule').addClass('selected');
                    $('#scenarioUsers,  #scenarioOrganization, #scenarioDevices, #scenarioContent').hide();
                    $('#scheduleSettings').show();
                });
                /*END finger tabs*/


            },
            //To set the finger Tab as per the selection in Scenario page
            Modalpopup: function (mode) {
                athoc.iws.scenario.settings.bindflag = false;
                $("#btn_scenariosettings").click();
                switch (mode) {
                    case 0:
                        $('.finger-tab.scenario-content').click();
                        break
                    case 1:
                        $('.finger-tab.scenario-users').click();
                        break;
                    case 2:
                        $('.finger-tab.scenario-organization').click();
                        break;
                    case 3:
                        $('.finger-tab.scenario-devices').click();
                        break;
                    case 4:
                        $('.finger-tab.scenario-schedule').click();
                        break;
                    default:
                        $("#btn_scenariosettings").click();
                        break;
                }
            },
            //To append the Personal device list
            formatPersonalDeviceList: function (data) {
                var groupList = [];
                var deviceList = [];
                var groupId = 0;
                var groupName = "";
                var filterData = data;

                if (filterData.length > 0) {
                    $(filterData).each(function (index) {

                        if (groupId != filterData[index].GroupId) {
                            groupId = filterData[index].GroupId;
                            if (deviceList.length > 0) {

                                groupList.push({ GroupName: groupName, DeviceList: deviceList, GroupId: groupId });
                                deviceList = [];
                            }
                            deviceList.push(filterData[index]);
                            groupName = filterData[index].GroupName;



                        } else {
                            deviceList.push(filterData[index]);

                        }

                    });
                    groupList.push({ GroupName: groupName, DeviceList: deviceList, GroupId: groupId });
                }
                return groupList;
            },
            //To append the mass device list
            formatMassDeviceList: function (data) {
                var groupList = [];
                var deviceList = [];
                var groupId = 0;
                var groupName = "";
                var filterData = data;

                if (filterData.length > 0) {
                    $(filterData).each(function (index) {

                        if (groupId != filterData[index].GroupId) {
                            groupId = filterData[index].GroupId;
                            if (deviceList.length > 0) {

                                groupList.push({ GroupName: groupName, DeviceList: deviceList, GroupId: groupId });
                                deviceList = [];
                            }
                            deviceList.push(filterData[index]);
                            groupName = filterData[index].GroupName;



                        } else {
                            deviceList.push(filterData[index]);

                        }

                    });
                    groupList.push({ GroupName: groupName, DeviceList: deviceList, GroupId: groupId });
                }
                return groupList;
            },
            //To Bind the Settings data
            bind: function (data) {

                athoc.iws.scenario.settings.viewModel.scenariosettingstmp = ko.mapping.fromJS(data);
                ko.cleanNode($("#ContentSettings").get(0));
                ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#ContentSettings").get(0));

                ko.cleanNode($("#UserSettings").get(0));
                $("#personaldevicesdisplaysettings").html("");
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.PersonalDeviceList = ko.mapping.fromJS(athoc.iws.scenario.settings.formatPersonalDeviceList(data.PersonalDeviceList));
                ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#UserSettings").get(0));

                if ($("#DevicesSettings").length > 0) {
                    ko.cleanNode($("#DevicesSettings").get(0));
                    $("#massdevicesdisplaysettings").html("");
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.MassDeviceList = ko.mapping.fromJS(athoc.iws.scenario.settings.formatMassDeviceList(data.MassDeviceList));
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#DevicesSettings").get(0));
                }
                if ($("#ScheduleSettings").length > 0) {
                    ko.cleanNode($("#ScheduleSettings").get(0));
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#ScheduleSettings").get(0));
                }

                if ($("#OrganizationSettings").length > 0) {
                    ko.cleanNode($("#OrganizationSettings").get(0));
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp, $("#OrganizationSettings").get(0));
                }
                //bind account template settings data...
                if ($("#EventWorkflowSettings").length > 0) {
                    ko.cleanNode($("#EventWorkflowSettings").get(0));
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.ShowWorkflowSection = ko.computed({
                        read: function() {
                            return this.IsAccountabilityMessagesVisible().toString();
                        },
                        write: function(newValue) {
                            this.disableWorkflowCollapsed(newValue === "false");
                            this.disableWorkflowReadonly(newValue === "false");
                            var val = newValue === "true";
                            this.IsAccountabilityMessagesCollapsed(val);
                            //for some reason 2 way binding is not working...
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesCollapsed(val);
                            this.IsAccountabilityMessagesVisible(val);
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesVisible(val);
                        },
                        owner: athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow
                    });
                    //for some reason 2 way binding is not working...
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesCollapsed.subscribe(function (newValue) {
                        athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesCollapsed(newValue);
                    });
                    //for some reason 2 way binding is not working...
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesReadonly.subscribe(function (newValue) {
                        athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsAccountabilityMessagesReadonly(newValue);
                    });
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.disableWorkflowCollapsed = ko.observable(false);
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.disableWorkflowReadonly = ko.observable(false);
                    ko.applyBindings(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow, $("#EventWorkflowSettings").get(0));
                }

                athoc.iws.scenario.settings.viewModel.scenariosettings = ko.mapping.toJS(athoc.iws.scenario.settings.viewModel.scenariosettingstmp);


            },
            isMassDeviceChanged: function (device) {
                _.each(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.MassDeviceList(), function (item) {
                    var dev = _.find(item.DeviceList(), function (item2) {
                        return device.DeviceId() === item2.DeviceId();
                    });
                    if (dev) {
                        dev.Selected(device.Selected());
                        return false;

                    }
                });
                return true;
            },

            isPDChanged: function (device) {
                _.each(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.PersonalDeviceList(), function (item) {
                    var dev = _.find(item.DeviceList(), function (item2) {
                        return device.DeviceId() === item2.DeviceId();
                    });
                    if (dev) {
                        dev.Selected(device.Selected());
                        return false;

                    }
                });
                return true;
            },
            ApplyOrgsettingsOnFingerTabs: function (data) {
                $("#targetOrgByName").css("display", "none");
                $("#targetOrgByArea").css("display", "none");
                $("#fingerOrgName").css("display", "none");
                $("#fingerOrgArea").css("display", "none");
                $("#targetOrgNameCount").css("display", "none");
                $("#targetOrgAreaCount").css("display", "none");
                $("#targetOrgCount").css("display", "none");

                //For Target By Area Org
                if (data.TargetByAreaEnabled) {
                    $("#targetOrgByArea").css("display", "");
                    $("#fingerOrgArea").css("display", "");
                    $("#targetOrgAreaCount").css("display", "");
                    $("#targetOrgByArea").show();
                }
                //For Target By NameOrg                
                if (data.TargetByNameEnabled) {
                    $("#targetOrgByName").css("display", "");
                    $("#fingerOrgName").css("display", "");
                    $("#targetOrgNameCount").css("display", "");
                    $("#fingerOrgName").show();
                }

                if ((data.TargetByNameEnabled) && (data.TargetByAreaEnabled)) {
                    $("#targetOrgCount").css("display", "");
                    $("#fingerOrgName").addClass("selected");
                    $("#targetOrgByArea").hide();
                }
                if (!(data.TargetByNameEnabled) && !(data.TargetByAreaEnabled)) {
                    $('#inclAllOrg').prop("disabled", true);
                }
                else
                    $('#inclAllOrg').prop("disabled", false);



            },
            //To apply settings on  finger tabs 
            ApplysettingsOnFingerTabs: function (data) {
                var selectTab = -1;
                $("#targetGroups").css("display", "none");
                $("#targetContentGroups").css("display", "none");
                $("#targetSryGroups").css("display", "none");
                $("#targetUsers").css("display", "none");
                $("#targetContentUsers").css("display", "none");
                $("#targetSryUsers").css("display", "none");
                $("#targetQuery").css("display", "none");
                $("#targetContentQuery").css("display", "none");
                $("#targetSryQuery").css("display", "none");
                $("#targetArea").css("display", "none");
                $("#targetContentArea").css("display", "none");
                $("#targetSryArea").css("display", "none");
                var firstTab = -1;
                $(data).each(function (index) {
                    switch (data[index]) {
                        case 0:
                            $("#targetGroups").css("display", "");
                            $("#targetContentGroups").css("display", "");
                            $("#targetSryGroups").css("display", "");
                            firstTab = 0;
                            if (selectTab == -1 && (athoc.iws.publishing.targetUsers.getModel().TargetingNodes != null && athoc.iws.publishing.targetUsers.getModel().TargetingNodes.length > 0))
                                selectTab = 0;
                            break;
                        case 1:
                            $("#targetUsers").css("display", "");
                            $("#targetContentUsers").css("display", "");
                            $("#targetSryUsers").css("display", "");
                            if (firstTab == -1) firstTab = 1;
                            if (selectTab == -1 && (athoc.iws.publishing.targetUsers.getModel().TargetedBlockedUsers != null && athoc.iws.publishing.targetUsers.getModel().TargetedBlockedUsers.length > 0))
                                selectTab = 1;
                            break;

                        case 5:
                            $("#targetArea").css("display", "");
                            $("#targetContentArea").css("display", "");
                            $("#targetSryArea").css("display", "");
                            if (firstTab == -1 || firstTab == 3) firstTab = 5;
                            if ((selectTab == -1 || selectTab == 3) && ((athoc.iws.publishing.settings.IsTargetByAreaSupported) && (athoc.iws.publishing.geo.viewModel.isGeoSelected()) && (athoc.iws.publishing.geo.viewModel.isUsersTargeted())))
                                selectTab = 5;
                            break;

                        case 3:
                            $("#targetQuery").css("display", "");
                            $("#targetContentQuery").css("display", "");
                            $("#targetSryQuery").css("display", "");
                            if (firstTab == -1) firstTab = 3;
                            if (selectTab == -1 && (athoc.iws.publishing.targetUsers.getModel().TargetedCriteria != null && athoc.iws.publishing.targetUsers.getModel().TargetedCriteria.selections.length > 0))
                                selectTab = 3;
                            break;

                    }
                });
                if (selectTab == -1)
                    selectTab = firstTab;

                switch (selectTab) {
                    case -1:
                        $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                        $('.finger-tab.personal-devices').addClass('selected');
                        $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                        $('.finger-tab.personal-devices').css('margin-top', '0px');
                        $('#targetContentDevices').show();
                        break;

                    case 0:
                        $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                        $('.finger-tab.by-groups').addClass('selected');
                        $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                        $('#targetContentGroups').show();
                        break;
                    case 1:

                        $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                        $('.finger-tab.by-users').addClass('selected');
                        $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                        $('#targetContentUsers').show();
                        break;
                    case 3:
                        $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                        $('.finger-tab.by-query').addClass('selected');
                        $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                        $('#targetContentQuery').show();
                        break;
                    case 5:
                        $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                        $('.finger-tab.by-area').addClass('selected');
                        $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                        $('#targetContentArea').show();
                        break;
                }

            },
            //To Bind User Target Devices Data
            bindTargetdevices: function (Userdevicesdata) {
                var dGroupName = new Array();
                var dGroupId = new Array();

                $(Userdevicesdata()).each(function (index) {
                    if (!(dGroupName.indexOf(Userdevicesdata()[index].GroupName()) > 0)) {
                        dGroupName[index] = Userdevicesdata()[index].GroupName();
                        dGroupId[index] = Userdevicesdata()[index].GroupId();
                    }
                });

                $('#divGroupDevices').html('');
                var html = "<ul>";
                $(dGroupName).each(function (index) {
                    if (dGroupName[index] != undefined) {

                        var chkcount = 0;
                        var itemscount = 0;
                        var subCheckbox = "";
                        $(Userdevicesdata()).each(function (j) {

                            if (dGroupName[index] == Userdevicesdata()[j].GroupName()) {
                                subCheckbox += "<ul>";
                                var checked = athoc.iws.scenario.settings.checkDeviceExists(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.EnabledDevices(), Userdevicesdata()[j].DeviceId()) ? "checked" : "";
                                if (checked == "checked")
                                    chkcount++;
                                subCheckbox += "<li><input  class='checkbox' type='checkbox' id=chk_" + dGroupId[index] + "_" + Userdevicesdata()[j].DeviceId() + "  value=" + Userdevicesdata()[j].DeviceId() + " " + checked + "></input>" + Userdevicesdata()[j].DeviceName() + "</li>";
                                subCheckbox += "</ul>";
                                itemscount++;
                            }
                        });
                        checked = (itemscount == chkcount) ? "checked" : " ";

                        html += "<li class='color-light-grey'>" + dGroupName[index] + "</li>" + subCheckbox;

                    }
                });
                html += "</ul>";
                $(html).appendTo('#divGroupDevices');

            },

            //To check whether the de
            checkDeviceExists: function (data, deviceId) {
                if (athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Id() == -1)
                    return true;
                var item = _.find(data, function (i) {
                    return i == deviceId;
                });
                if (item != null)
                    return true;
                else
                    return false;
            },

            //for User Devices Parent check
            SelectUserDevicesAll: function (chkParent) {
                if (chkParent.checked) {
                    $("#divGroupDevices input[id*='" + chkParent.id + "_']:checkbox").each(function (j) {
                        $("#divGroupDevices input[id*='" + chkParent.id + "_']:checkbox")[j].checked = true;
                    });
                }
                else
                    $("#divGroupDevices input[id*='" + chkParent.id + "_']:checkbox").attr("checked", false);
                //return false;
            },

            //for User Devices Children check
            SelectUserDevicesChild: function (chkChild, ParentId) {

                if (chkChild.checked) {
                    var TotalCheckboxes = $("#divGroupDevices  input[id*='" + ParentId.id + "_']:checkbox").length;
                    var CheckedCount = $("#divGroupDevices  input[id*='" + ParentId.id + "_']:checkbox:checked").length;
                    if (TotalCheckboxes == CheckedCount)
                        $("#divGroupDevices input[id='" + ParentId.id + "']:checkbox")[0].checked = true;
                    else
                        $("#divGroupDevices input[id='" + ParentId.id + "']:checkbox").attr("checked", false);
                }
                else
                    $("#divGroupDevices input[id='" + ParentId.id + "']:checkbox").attr("checked", false);

            },


            //To Bind Mass Devices Data
            bindMassdevices: function (Massdevicesdata) {
                return ko.mapping.fromJS(athoc.iws.publishing.massdevices.formatMassDeviceList(Massdevicesdata));
            },
            //for Mass Devices Parent check
            SelectMassDevicesAll: function (chkParent) {
                if (chkParent.checked) {
                    $("#divMassDevices input[id*='" + chkParent.id + "_']:checkbox").each(function (j) {
                        $("#divMassDevices input[id*='" + chkParent.id + "_']:checkbox")[j].checked = true;
                    });
                }
                else
                    $("#divMassDevices input[id*='" + chkParent.id + "_']:checkbox").attr("checked", false);

            },

            //for Mass Devices Children check
            SelectMassDevicesChild: function (chkChild, ParentId) {

                if (chkChild.checked) {
                    var TotalCheckboxes = $("#divMassDevices  input[id*='" + ParentId.id + "_']:checkbox").length;
                    var CheckedCount = $("#divMassDevices  input[id*='" + ParentId.id + "_']:checkbox:checked").length;
                    if (TotalCheckboxes == CheckedCount)
                        $("#divMassDevices input[id='" + ParentId.id + "']:checkbox")[0].checked = true;
                    else
                        $("#divMassDevices input[id='" + ParentId.id + "']:checkbox").attr("checked", false);
                }
                else
                    $("#divMassDevices input[id='" + ParentId.id + "']:checkbox").attr("checked", false);

            },
            //for selected checkboxes in Targetusers
            EnableDevicesData: function () {
                var selectedCheckBoxArray = new Array();

                $("#divGroupDevices input[type=checkbox]:checked").each(function () {
                    selectedCheckBoxArray.push($(this).val());
                });
                selectedCheckBoxArray = selectedCheckBoxArray.join(',');
            },
            //this method will be called when data is required for updating
            getModel: function () {

                return ko.mapping.toJS(athoc.iws.scenario.settings.viewModel.scenariosettings);
            },
            //To resize setting popup based on screen resolution
            resizeModalBasedOnScreen: function (modal) {
                var extrSpace = 0
                modal.find(".modal-body").css("max-height", 621);
                var windowHeight = $(window).height();
                extrSpace = athoc.iws.publishing.contextName == "AccountTemplate" ? 60 : 40;
                if (windowHeight > 770) {                    
                    modal.css("margin-top", 40 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                    $('#ScenarioSettings .finger-tab-content').css("height", windowHeight - (340 + extrSpace));
                    $('#ScenarioSettings .inner-bucket-grid-wrap').css("height", windowHeight - (440 + extrSpace));
                } else {

                    //extrSpace = 50;
                    modal.css("margin-top", 40 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 240);
                    $('#ScenarioSettings .finger-tab-content').css("max-height", windowHeight - (240));
                    $('#ScenarioSettings .inner-bucket-grid-wrap').css("max-height", windowHeight - (290 + extrSpace));

                    $('#ScenarioSettings .finger-tab-content').css("height", windowHeight - (240));
                    $('#ScenarioSettings .inner-bucket-grid-wrap').css("height", windowHeight - (290 + extrSpace));
                }

                if (athoc.iws.publishing.contextName != "AccountTemplate")
                    $('#ScenarioSettings .inner-bucket-grid-wrap').css("width", 665);

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }


            },
            //Error handling
            handleError: function (e) {
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },
            //w.r.t condition toggle duplicate and delete buttons
            toggleButtonStates: function (count) {
                if (count < 1) {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", true);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", true);
                }
                else if (count == 1) {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", false);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", false);
                }
                else {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", true);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", false);
                }
            },
            //Settings scenario setting values to the model.
            AssigningValues: function (enabledDevices) {

                var arrDevicesSelected = new Array();
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.EnabledDevices(enabledDevices);

                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.Visible = ($("#rdContentShow")[0].checked) ? "Y" : "N";
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.Visible = ($("#rdTargetShow")[0].checked) ? "Y" : "N";
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.Visible = ($("#rdOrgShow")[0].checked) ? "Y" : "N";
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.Visible = ( $("#rdDeviceShow")[0] && $("#rdDeviceShow")[0].checked) ? "Y" : "N";
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Advanced.Visible = ($("#rdScheduleShow")[0] && $("#rdScheduleShow")[0].checked) ? "Y" : "N";

                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.Readonly = ($("#chkContentread")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.Readonly = ($("#chkTUreadonly")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.Readonly = ($("#chkShowReadOnly")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.Readonly = ($("#chkDeliveryReadonly")[0] && $("#chkDeliveryReadonly")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Advanced.Readonly = ($("#chkAdvanceReadonly")[0] && $("#chkAdvanceReadonly")[0].checked) ? true : false;

                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.Collapsed = ($("#chkContentCollapse")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.Collapsed = ($("#chkTUCollapse")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.Collapsed = ($("#chkShowInCollapsed")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.Collapsed = ($("#chkDeliveryCollapse")[0] && $("#chkDeliveryCollapse")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Advanced.Collapsed = ($("#chkAdvanceCollapse")[0] && $("#chkAdvanceCollapse")[0].checked) ? true : false;

                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.LocationEnabled = ($("#chkLocation")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.LocationMandatoryEnabled = ($("#chkLocationMandatory")[0].checked) ? true : false;
                //if (athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.LocationEnabled && athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.LocationMandatoryEnabled)
                //    athoc.iws.publishing.content.checkReadyNotReady();
                if ($("#chkContentResponse").length > 0)
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.ResponseOptionEnabled = ($("#chkContentResponse")[0].checked) ? true : false;
               
              //athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.DropboxEnabled = ($("#chkDropdown")[0].checked) ? true : false;
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.DropboxEnabled = ($("#chkDropdown").is(':checked'));

                if ($("#chkFillCount").length > 0)
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.FillCount = ($("#chkFillCount")[0].checked) ? true : false;

                athoc.iws.scenario.settings.isFillCountEnabled = athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.FillCount;
                if (!athoc.iws.scenario.settings.isFillCountEnabled) {
                    athoc.iws.publishing.fillcount.clearFillCountData(athoc.iws.scenario.settings.isFillCountEnabled, athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                }
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByNameEnabled = ($("#chkEnableTargByName")[0].checked) ? true : false;
                if ($("#chkLocation")[0].checked)
                    athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByAreaEnabled = ($("#chkEnableTargByArea")[0].checked) ? true : false;


                var arrEnableTargetType = new Array();
                if ($("#chkTargettingGroup")[0].checked)
                    arrEnableTargetType.push(parseInt($("#chkTargettingGroup").val()));
                if ($("#chkTargettingName")[0].checked)
                    arrEnableTargetType.push(parseInt($("#chkTargettingName").val()));
                if ($("#chkTargettingQuery")[0].checked)
                    arrEnableTargetType.push(parseInt($("#chkTargettingQuery").val()));
                if ($("#chkTargettingArea")[0].checked)
                    arrEnableTargetType.push(parseInt($("#chkTargettingArea").val()));
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.EnabledTargetingTypes(arrEnableTargetType);

                athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(arrEnableTargetType);
                athoc.iws.scenario.settings.ApplyOrgsettingsOnFingerTabs(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization);


                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.LocationEnabled ? $("#dvContentLocation").css("display", "") : $("#dvContentLocation").css("display", "none");
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.ResponseOptionEnabled ? $("#dvContentResponseOpt").css("display", "") : $("#dvContentResponseOpt").css("display", "none");
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.ResponseOptionEnabled ? $("#dvContentAddResponseOpt").css("display", "") : $("#dvContentAddResponseOpt").css("display", "none");
                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.DropboxEnabled ? $("#dvContentDropBox").css("display", "") : $("#dvContentDropBox").css("display", "none");
                //for Scenario always readonly=false
              
                if (athoc.iws.publishing.contextName != "AccountTemplate")
                    athoc.iws.publishing.fillcount.enableFillCountSummary( athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.FillCount);

            },
            //To get the devices which are selected
            getDeviceList: function (data, isPersonalDevice) {


                var resultdata = [];
                var data = ko.mapping.toJS(data);
                //if (isPersonalDevice)
                //    data.sort(function (l, r) { return l.GroupId < r.GroupId ? -1 : 1 })
                var i = 0;
                $(data).each(function (index) {
                    i = 0;
                    $(data[index].DeviceList).each(function (index2) {

                        if (data[index].DeviceList[index2].Selected) {
                            i++;
                            if (i == 1)
                                data[index].DeviceList[index2].GroupChange = true;
                            resultdata.push(data[index].DeviceList[index2]);
                            athoc.iws.scenario.settings.enabledDevices.push(data[index].DeviceList[index2].DeviceId);
                        }
                    });
                });
                if (resultdata.length > 0)
                    athoc.iws.scenario.settings.selectedCount++;
                return resultdata;
            },
            // to save User Settings in the database
            saveUserSettings: function () {
                athoc.iws.scenario.settings.errorflag = false;
                if (($("#chkTargettingGroup")[0].checked) ||
                    ($("#chkTargettingName")[0].checked) ||
                    ($("#chkTargettingQuery")[0].checked) ||
                    ($("#chkTargettingArea")[0].checked)) {

                    if (!($("#chkLocation")[0].checked) && ($("#chkLocationMandatory")[0].checked))
                    {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_Locationmsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }
                    else if ((athoc.iws.publishing.targetUsers.getModel().TargetingNodes.length > 0) && (!$("#chkTargettingGroup")[0].checked) && ($('#targetGroups').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_Groupsmsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }

                    else if ((athoc.iws.publishing.targetUsers.getModel().TargetedBlockedUsers.length > 0) && (!$("#chkTargettingName")[0].checked) && ($('#targetUsers').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_Usersmsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }

                    else if ((athoc.iws.publishing.geo.viewModel.isUsersTargeted() && athoc.iws.publishing.geo.geoJson != null) && (!$("#chkTargettingArea")[0].checked) && ($('#targetArea').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_Areamsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }
                    else if ((athoc.iws.publishing.targetUsers.viewModelInstance.numberQueryCriteria() > 0) && (!$("#chkTargettingQuery")[0].checked) && ($('#targetQuery').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_Querymsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }
                        //Org Name Data check
                    else if ((athoc.iws.publishing.targetOrg.OrgViewModel && athoc.iws.publishing.targetOrg.OrgViewModel.OrgSelected().length > 0) && (!$("#chkEnableTargByName")[0].checked) && ($('#targetOrgByName').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_OrganizationNamemsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }
                        //Org Area Data check
                    else if ((athoc.iws.publishing.targetOrg.OrgViewModel && athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea()) && (!$("#chkEnableTargByArea")[0].checked) && ($('#targetOrgByArea').is(':visible'))) {
                        alert(athoc.iws.scenario.settings.resources.ScenarioSettings_OrganizationLocmsg);
                        athoc.iws.scenario.settings.errorflag = true;
                    }
                    else {

                        athoc.iws.scenario.settings.enabledDevices = [];
                        var massdata = athoc.iws.scenario.settings.getDeviceList(ko.mapping.toJS(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.MassDeviceList), false);
                        var personaldata = athoc.iws.scenario.settings.getDeviceList(ko.mapping.toJS(athoc.iws.scenario.settings.viewModel.scenariosettingstmp.PersonalDeviceList), true);
                        athoc.iws.scenario.settings.assignIsPhoneAndEnabledProperties(personaldata);
                        if (massdata.length == 0)
                            $('#MassDeviceFlatList').hide();
                        else
                            $('#MassDeviceFlatList').show();

                        if ((massdata.length > 0) || (personaldata.length > 0)) {
                            $('#ScenarioSettings').hide();
                            athoc.iws.scenario.settings.AssigningValues(athoc.iws.scenario.settings.enabledDevices);
                            //perpare mass device list for binding 

                            if (athoc.iws.publishing.contextName != "AccountTemplate") {// don't refresh mass device for event template as it would throw error...
                                athoc.iws.publishing.massdevices.refreshMassDevicesList(massdata);
                            }
                            // bind the details on parent page
                            // hide/show based on the Scenario Settings 
                            athoc.iws.publishing.targetUsers.refreshPersonalDevices(personaldata);
                            // apply settings on main model for save
                            if ((athoc.iws.scenario.settings.viewModel.scenariosettings.Organization.TargetByNameEnabled != athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByNameEnabled) && (athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByNameEnabled) && athoc.iws.publishing.targetOrg.OrgViewModel.TargetAllOrg())
                                athoc.iws.publishing.targetOrg.OrgViewModel.SelectAll();

                            $('#location-mandatory').css("display", "none");
                            athoc.iws.scenario.settings.viewModel.scenariosettings = ko.mapping.toJS(athoc.iws.scenario.settings.viewModel.scenariosettingstmp);
                            if (athoc.iws.scenario.settings.viewModel.scenariosettings.Content.LocationEnabled) {
                                
                                athoc.iws.publishing.content.checkReadyNotReady();
                            }

                        }
                        else {
                            $('.finger-tab').removeClass('selected');
                            $('.finger-tab.scenario-users').addClass('selected');
                            $('#scenarioContent,  #scenarioOrganization, #scenarioDevices, #scenarioSchedule').hide();
                            $('#scenarioUsers').show();

                            alert(athoc.iws.scenario.settings.resources.ScenarioSettings_AtleastOneDevice);
                        }


                      

                    }

                }

                else {
                    alert(athoc.iws.scenario.settings.resources.ScenarioSettings_AtleastOneTargerUserOption);
                    athoc.iws.scenario.settings.errorflag = true;
                }
               // athoc.iws.scenario.settings.RefreshContentSectionReadyStatus();
            },

            //Assign the IsPhone and Enabled Property to setting PersonalData.
            assignIsPhoneAndEnabledProperties: function (settingPersonalDevices) {
                var tagetUserPersonalDevices = ko.mapping.toJS(athoc.iws.publishing.targetUsers.viewModelInstance.Devices);
                _.each(settingPersonalDevices, function (settingsDeviceitem, settingsIndex) {
                    _.each(tagetUserPersonalDevices, function (targetUsersDeviceitem, targetUsersIndex) {
                        if (settingsDeviceitem.DeviceId == targetUsersDeviceitem.DeviceId) {
                            settingsDeviceitem.Enabled = targetUsersDeviceitem.Enabled;
                            settingsDeviceitem.IsPhone = targetUsersDeviceitem.IsPhone;
                        }
                    });
                });

            },

            //To Show/Hide Location,Dropbox,Response option depending on settings on Scenarion & Alert page .
            applyAlertContentSettings: function (content) {
                var targetDIV = ($("#alert-content-edit").is(':visible') ? "#publishing-content-edit" : "#publishing-content-detail");
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Readonly) {
                    if (content.LocationEnabled && (athoc.iws.publishing.view.viewModel.isGeoSelected() || content.LocationMandatoryEnabled))
                        $(targetDIV).find("#dvContentLocation").css("display", "");
                    else
                        $(targetDIV).find("#dvContentLocation").css("display", "none");
                }
                else {
                    if (content.LocationEnabled)
                        $(targetDIV).find("#dvContentLocation").css("display", "");
                    else
                        $(targetDIV).find("#dvContentLocation").css("display", "none");
                }


                if (content.ResponseOptionEnabled) {
                    $(targetDIV).find("#dvContentResponseOpt").css("display", "");
                    $(targetDIV).find("#dvContentAddResponseOpt").css("display", "");
                }
                else {
                    $(targetDIV).find("#dvContentResponseOpt").css("display", "none");
                    $(targetDIV).find("#dvContentAddResponseOpt").css("display", "none");
                }

                if (content.DropboxEnabled) {
                    $(targetDIV).find("#dvContentDropBox").css("display", "");
                    // $(targetDIV).find("#dvContentMoreInfo").css("display", "");
                }
                else {
                    $(targetDIV).find("#dvContentDropBox").css("display", "none");
                    // $(targetDIV).find("#dvContentMoreInfo").css("display", "none");
                }
            },
            //To Show/Hide Location,Dropbox,Response option depending on settings on Scenarion & Alert page .
            applyScenarioContentSettings: function (content) {
                if (content.LocationEnabled)
                    $("#dvContentLocation").css("display", "");
                else
                    $("#dvContentLocation").css("display", "none");


                if (content.ResponseOptionEnabled) {
                    $("#dvContentResponseOpt").css("display", "");
                    $("#dvContentAddResponseOpt").css("display", "");
                }
                else {
                    $("#dvContentResponseOpt").css("display", "none");
                    $("#dvContentAddResponseOpt").css("display", "none");
                }

                if (content.DropboxEnabled) {
                    $("#dvContentDropBox").css("display", "");
                    // $("#dvContentMoreInfo").css("display", "");
                }
                else {
                    $("#dvContentDropBox").css("display", "none");
                    //$("#dvContentMoreInfo").css("display", "none");
                }
            },
            //toogle the view based on the settings
            applySettingsOnAlert: function (settingData, data) {
                athoc.iws.scenario.settings.ReadonlyViewModel.applysettings = settingData;
                athoc.iws.publishing.content.ReadonlyViewModel.data = data;

                // Apply Readonly Settings
                athoc.iws.scenario.settings.applyReadOnlySettingsOnAlert(data);

            },
            //To apply readonly settings for Alert details
            applyReadOnlySettingsOnAlert: function (data) {
                athoc.iws.publishing.view.targetingChanged(data);
                athoc.iws.publishing.view.isMassDeviceReady(data);
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Readonly && athoc.iws.publishing.content.isReadyToPublish() && athoc.iws.publishing.content.isValid()) {
                    if ((athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled && athoc.iws.publishing.view.viewModel.isGeoSelected())
                    || (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled && athoc.iws.publishing.view.viewModel.isGeoSelected())
                        || (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled && !athoc.iws.publishing.view.viewModel.isGeoSelected())) {
                        $("#alert-content-edit").hide();
                        $("#alert-content-detail").show();

                        //Added the below lines of code to display readonly view in edit alert
                        athoc.iws.publishing.view.bindContentSection(data, $("#alert-content-detail"));
                        athoc.iws.publishing.view.bindGeoLocation(data.Content.LocationGeo, $("#alert-content-detail"));
                    }                        
                    else
                        athoc.iws.publishing.content.bind(data.Content, data.Context);
                }
                else
                    athoc.iws.publishing.content.bind(data.Content, data.Context);


                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly && athoc.iws.publishing.targetUsers.isReadyToPublish) {
                    $("#alert-user-edit").hide();
                    $("#alert-user-detail").show();
                    athoc.iws.publishing.source = "readonly";
                    athoc.iws.publishing.iut.bind(data.TargetUsers.TargetedBlockedUsers);

                    //Added the below line of code to display readonly view in edit alert
                    athoc.iws.publishing.view.bindTargetUsers(data, $("#alert-user-detail"));

                }
                else {
                    athoc.iws.publishing.targetUsers.bind(data.TargetUsers, data.PresetDeviceGroupOptions);
                    athoc.iws.publishing.iut.bind(data.TargetUsers.TargetedBlockedUsers);
                }

                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.Readonly) {
                    $("#alert-org-edit").hide();
                    $("#alert-ord-detail").show();
                    athoc.iws.publishing.targetOrg.bindReadOnlyViewModel(data.TargetOrg.TargetedOrganizations, $("#alert-ord-detail"));
                }
                else
                    athoc.iws.publishing.targetOrg.load(data.TargetOrg);


                //do not run following for PA
                if (athoc.iws.publishing.contextName == "Alert") { 
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Delivery.Readonly && athoc.iws.publishing.massdevices.isReadyToPublish) {
                        $("#alert-mass-edit").hide();
                        $("#alert-mass-detail").show();
                        athoc.iws.publishing.massdevices.bindReadOnlyView(data.MassDevices, "#alert-mass-detail");
                    } else
                        athoc.iws.publishing.massdevices.bind(data.MassDevices, data.Context, data.ScenarioSettings.Delivery.Readonly, data.PresetDeviceGroupOptions);

                    //if mass device or target users section is read only, must retrieve custom text via ajax.  
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly || athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Delivery.Readonly) {
                        athoc.iws.publishing.view.getCustomTextViaAjax(data.PresetDeviceGroupOptions);
                    }
                }

                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Advanced.Readonly && athoc.iws.publishing.scenario.isReadyToPublish()) {
                    $("#alert-schedule-edit").hide();
                    $("#alert-schedule-detail").show();
                    athoc.iws.alert.schedule.bindReadOnlyView(data.AlertScheduleSettings, "#alert-schedule-detail");
                }
                athoc.iws.scenario.settings.applyVisibleSettingsOnAlert();
            },
            //To apply collapse settings for Alert details
            applyCollapseSettingsOnAlert: function () {
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Visible == 'Y') {
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Collapsed)
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-content-edit").is(':visible') ? "#publishing-content-edit" : "#publishing-content-detail"), true, $("#alert-content-edit").is(':visible'));
                    else
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-content-edit").is(':visible') ? "#publishing-content-edit" : "#publishing-content-detail"), false, $("#alert-content-edit").is(':visible'));
                }

                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Visible == 'Y') {
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Collapsed)

                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-user-edit").is(':visible') ? "#publishing-user-edit" : "#publishing-user-detail"), true, $("#alert-user-edit").is(':visible'));
                    else
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-user-edit").is(':visible') ? "#publishing-user-edit" : "#publishing-user-detail"), false, $("#alert-user-edit").is(':visible'));
                }
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.Visible == 'Y') {
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.Collapsed)
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-org-edit").is(':visible') ? "#targetOrgSection" : "#targetOrgDetail"), true, $("#alert-org-edit").is(':visible'));
                    else
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-org-edit").is(':visible') ? "#targetOrgSection" : "#targetOrgDetail"), false, $("#alert-org-edit").is(':visible'));
                }
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Delivery.Visible == 'Y') {
                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Delivery.Collapsed) {
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-mass-edit").is(':visible') ? "#publishing-mass-edit" : "#publishing-mass-view"), true, $("#alert-mass-edit").is(':visible'));
                        $("#massDeviceOptionsLink").hide();
                    } else
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-mass-edit").is(':visible') ? "#publishing-mass-edit" : "#publishing-mass-view"), false, $("#alert-mass-edit").is(':visible'));
                }
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Advanced.Visible == 'Y') {

                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Advanced.Collapsed)
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-schedule-edit").is(':visible') ? "#publishing-alert-edit" : "#publishing-alert-view"), true, (athoc.iws.publishing.detail.viewModel.AlertStatus != "Live" ? true : $("#alert-schedule-edit").is(':visible')));
                    else
                        athoc.iws.scenario.settings.toggleAlertSections(($("#alert-schedule-edit").is(':visible') ? "#publishing-alert-edit" : "#publishing-alert-view"), false, (athoc.iws.publishing.detail.viewModel.AlertStatus != "Live" ? true : $("#alert-schedule-edit").is(':visible')));

                }
            },
            //To apply Visible settings for Alert details
            applyVisibleSettingsOnAlert: function () {                
                var data = athoc.iws.scenario.settings.ReadonlyViewModel.applysettings;
				// todo: this check is for PA case where we load only preview mode, and have no settings
				// todo: review with Nishith
                if (data.length == 0) {
                    return;
                }
                if (data.Content.Visible == 'N' && athoc.iws.publishing.content.isReadyToPublish() && athoc.iws.publishing.content.isValid())
                    $("#publishing-content-edit").hide();
                else
                    $("#publishing-content-edit").show();

                if (data.Targeting.Visible == 'N' && (athoc.iws.publishing.targetUsers.isReadyToPublish || (!athoc.iws.publishing.targetUsers.isReadyToPublish && !athoc.iws.publishing.targetUsers.isInErrorState)))
                    $("#publishing-user-edit").hide();
                else
                    $("#publishing-user-edit").show();
                //iws#12702
                if (data.Organization.Visible == 'N' || data.Organization.Readonly)
                    $("#alert-org-edit").hide();
                else
                    $("#alert-org-edit").show();
                if (data.Delivery.Visible == 'N' && (athoc.iws.publishing.massdevices.isReadyToPublish || (!athoc.iws.publishing.massdevices.isReadyToPublish && !athoc.iws.publishing.massdevices.isInErrorState)))
                    $("#publishing-mass-edit").hide();
                else
                    $("#publishing-mass-edit").show();
                if (data.Advanced.Visible == 'N' && athoc.iws.publishing.scenario.isReadyToPublish())
                    $("#publishing-alert-edit").hide();
                else
                    $("#publishing-alert-edit").show();
            },
            //To change readonly state for check boxes on click
            changeReadOnlyState: function (id) {
                if (!athoc.iws.scenario.settings.bindflag) {
                    switch (id) {
                        case "chkContentread":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.Readonly($("#" + id).is(':checked'));
                            break;
                        case "chkContentCollapse":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Content.Collapsed($("#" + id).is(':checked'));
                            break;
                        case "chkTUreadonly":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.Readonly($("#" + id).is(':checked'));
                            break;
                        case "chkTUCollapse":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.Collapsed($("#" + id).is(':checked'));
                            break;
                        case "chkShowReadOnly":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.Readonly($("#" + id).is(':checked'));
                            break;
                        case "chkShowInCollapsed":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.Collapsed($("#" + id).is(':checked'));
                            break;
                        case "chkDeliveryReadonly":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.Readonly($("#" + id).is(':checked'));
                            break;
                        case "chkDeliveryCollapsed":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Delivery.Collapsed($("#" + id).is(':checked'));
                            break;
                        case "chkAdvanceReadonly":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Advanced.Readonly($("#" + id).is(':checked'));
                            break;
                        case "chkAdvanceCollapsed":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Advanced.Collapsed($("#" + id).is(':checked'));
                            break;

                        case "chkLocation":

                            if ($("#chkLocation")[0].checked) {
                                $("#chkTargettingArea")[0].checked = true;
                                $("#chkEnableTargByArea")[0].checked = true;

                                var arrEnableTargetType = new Array();
                                if ($("#chkTargettingGroup")[0].checked)
                                    arrEnableTargetType.push(parseInt($("#chkTargettingGroup").val()));
                                if ($("#chkTargettingName")[0].checked)
                                    arrEnableTargetType.push(parseInt($("#chkTargettingName").val()));
                                if ($("#chkTargettingQuery")[0].checked)
                                    arrEnableTargetType.push(parseInt($("#chkTargettingQuery").val()));
                                if ($("#chkTargettingArea")[0].checked)
                                    arrEnableTargetType.push(parseInt($("#chkTargettingArea").val()));
                                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Targeting.EnabledTargetingTypes(arrEnableTargetType);

                                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByAreaEnabled = true;
                            }
                            else {
                                $("#chkTargettingArea")[0].checked = false;
                                $("#chkEnableTargByArea")[0].checked = false;
                                athoc.iws.scenario.settings.viewModel.scenariosettingstmp.Organization.TargetByAreaEnabled = false;
                            }
                            break;

                        case "chkShowSeverity":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsContentSeverityVisible($("#" + id).is(':checked'));
                            break;

                        case "chkShowType":
                            athoc.iws.scenario.settings.viewModel.scenariosettingstmp.AccountabilityWorkflow.IsContentTypeVisible($("#" + id).is(':checked'));
                            break;

                        case "rbContentVisible":
                            if ($("#rdContentShow")[0].checked)
                                $("#chkContentCollapse")[0].checked = true;
                            break;

                        case "rdContentHide":
                            $("#chkContentCollapse")[0].checked = false;
                            break;


                        case "rdTargetShow":
                            if ($("#rdTargetShow")[0].checked)
                                $("#chkTUCollapse")[0].checked = true;
                            break;

                        case "rdTargetHide":
                            $("#chkTUCollapse")[0].checked = false;
                            break;

                        case "rdOrgShow":
                            if ($("#rdOrgShow")[0].checked)
                                $("#chkShowInCollapsed")[0].checked = true;
                            break;

                        case "rdOrgHide":
                            $("#chkShowInCollapsed")[0].checked = false;
                            break;

                        case "rdDeviceShow":
                            if ($("#rdDeviceShow")[0].checked)
                                $("#chkDeliveryCollapse")[0].checked = true;
                            break;

                        case "rdDeviceHide":
                            $("#chkDeliveryCollapse")[0].checked = false;
                            break;

                        case "rdScheduleShow":
                            if ($("#rdScheduleShow")[0].checked)
                                $("#chkAdvanceCollapse")[0].checked = true;
                            break;

                        case "rdScheduleHide":
                            $("#chkAdvanceCollapse")[0].checked = false;
                            break;


                    }
                }
            },
            //Toggling open & closed for alert section
            toggleAlertSections: function (divId, isCollapse, isEdit) {
                var targetDiv = $(divId);
                if (targetDiv.length == 0)
                    return;
                targetDiv.find('.section-title, .expand-arrow-open, .expand-arrow-closed').unbind("click");
                targetDiv.find('#bucketTitle').unbind("click");
                $('.bucket-toggle h2').unbind("click");
                $('.bucket-toggle h2').bind('click', function (e) {
                    if (!e.isDefaultPrevented()) {
                        $(this).parent().find('.row').slideToggle(500);
                        $(this).parent().find('.expand-arrow-open').toggle();
                        $(this).parent().find('.expand-arrow-closed').toggle();
                    }
                    e.preventDefault();
                });
                //show bucket expanded by default
                if (isCollapse) {
                    targetDiv.find(".bucket-toggle .row").hide();
                    targetDiv.find(".bucket-toggle .expand-arrow-open").hide();
                    targetDiv.find(".bucket-toggle .expand-arrow-closed").show();
                }
                else {
                    targetDiv.find(".bucket-toggle .row").show();
                    targetDiv.find(".bucket-toggle .expand-arrow-open").show();
                    targetDiv.find(".bucket-toggle .expand-arrow-closed").hide();
                }

            },
            //To display settings icon
            displaysettingsIcon: function (display) {

                $("#dvContentIcon").css("display", display);
                $("#dvTargetUsersIcon").css("display", display);
                $("#dvOrgIcon").css("display", display);
                $("#dvMassDevicesIcon").css("display", display);
                $("#dvScheduleSettingsIcon").css("display", display);

            },

            RefreshContentSectionReadyStatus: function () {
                if (athoc.iws.publishing.content.isValid()) {
                    athoc.iws.publishing.content.viewModel.status('ready');
                    athoc.iws.publishing.content.viewModel.statusTooltip(athoc.iws.publishing.resources.Publishing_Section_Ready_Tooltip);
                } else {
                    athoc.iws.publishing.content.viewModel.status('not-ready');
                    athoc.iws.publishing.content.viewModel.statusTooltip(athoc.iws.publishing.resources.Publishing_Section_NotReady_Tooltip);
                }
            },


        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.massDevices.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.massdevices = function () {
        return {
            isChanged: false,
            IsRightToLeft: false,
            isReadyToPublish: true,
            isInErrorState: false,
            selectedCount: 0,
            DeviceGroupOptions: new Array(),
            massDeviceList: ko.observableArray(),
            isLocationPresent: ko.observable(false),
            Parameters: new Array(),
            readOnlyModel: {
                massDeviceList: ko.observableArray(),
                showCustomText: function () {
                    if (this.CustomText) {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                        $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.resources.Publishing_Custom_Text);
                        var summaryDiv = $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP");
                        summaryDiv.html(this.CustomText());
                    }
                }
            },
            viewModel: {
                keyDict: {},
                context: this,
                massDeviceList: ko.observableArray(),
                IsAffiliate: ko.observable(false),
                launchMassDeviceOptions: function () {
                    if (athoc.iws.publishing.massdevices.isAnyMassDeviceSelected()) {
                        $(athoc.iws.publishing.massdevices.Parameters.dialogDeviceOptions).modal("show");
                        athoc.iws.utilities.resizeModalBasedOnScreen($(athoc.iws.publishing.massdevices.Parameters.dialogDeviceOptions), 600, 770, 20, 170);
                    }
                },
                subscribeLocationChanges: function () {
                    if (athoc.iws.publishing.geo && athoc.iws.publishing.geo.viewModel && athoc.iws.publishing.geo.viewModel.isGeoSelected) {
                        athoc.iws.publishing.geo.viewModel.isGeoSelected.subscribe(function (newvalue) {
                            if (newvalue) {
                                athoc.iws.publishing.massdevices.isLocationPresent(true);
                            } else {
                                athoc.iws.publishing.massdevices.isLocationPresent(false);
                            }
                            athoc.iws.publishing.massdevices.isMassDeviceReady();
                        });
                    }
                },
                subscribeEndPoints : function(massdevices) {
                    _.each(massdevices(), function(massdevice) {
                        _.each(massdevice.DeviceList(), function(device) {
                            device.SelectedUsers.subscribe(function(newValue) {
                                 athoc.iws.publishing.massdevices.isMassDeviceReady();
                            });
                        });
                    });
                }
            },
            init: function (parameters) {
                this.Parameters = parameters;
                var self = this;
                athoc.iws.publishing.massdevices.viewModel.subscribeLocationChanges();
            },
            load: function () {
            },

            loadEndPoints: function (url, data) {
                var deferred = $.Deferred();
                var dlAjaxOption =
               {
                   type: "POST",
                   url: url,
                   data: {
                       devices: data,
                   },
               };
                var ajaxSuccess = function (datawithendpoints) {
                    if (datawithendpoints) {
                        deferred.resolve(datawithendpoints);
                    } else {
                        console.log("EndPoints are invalid");
                        deferred.reject();
                    }
                };
                var ajaxError = function (data) {
                    console.log(data);
                    deferred.reject(data);
                };

                var ajaxOptions = $.extend({}, AjaxUtility(ajaxError, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
                return deferred.promise();
            },


            bind: function (data, IsReadOnly, readOnly, presetDeviceOptions) {

                var self = this;

                if (!data || data.length == 0) {
                    athoc.iws.publishing.massdevices.isMassDeviceReady();
                    return;
                }
             
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsMassDeviceTargetSupported) {
                    athoc.iws.publishing.massdevices.isMassDeviceReady();
                    return;
                }

                console.log(athoc.iws.publishing.contextName);
                if (athoc.iws.publishing.contextName != "Scenario" && IsReadOnly) {

                    athoc.iws.publishing.massdevices.bindReadOnlyView(data, "#alert-mass-detail");
                } else {

                    var url = self.Parameters.getEndPointsURL;
                    var input = ko.toJS(data);

                    kendo.ui.progress($("#publishing-mass-edit"), true);

                    $.when(athoc.iws.publishing.massdevices.loadEndPoints(url, input)).then(function (datawithendpoints) {
                        var setTargetingAndSelectionProp = function (fromData, toData) {
                            var selectedfromData = _.filter(fromData, function (selectedDevice) {
                                return selectedDevice.Selected;
                            });
                           _.each(selectedfromData, function (fromDevice) {
                                var toDataDevice = _.find(toData, function(toDevice) {
                                    return fromDevice.DeviceId === toDevice.DeviceId;
                                });
                                if (toDataDevice) {
                                    _.each(toDataDevice.EndPoints, function(toEndPoint) {
                                       var fromEndPoint =  _.find(fromDevice.EndPoints, function(fromEndPointItem) {
                                           return fromEndPointItem.UserId === toEndPoint.UserId;
                                       });
                                        if (fromEndPoint) {
                                            toEndPoint.IsTargetable = fromEndPoint.IsTargetable;
                                            toEndPoint.IsSelected = fromEndPoint.IsSelected;
                                        }
                                    });
                                }
                            });
                        };
                        
                        setTargetingAndSelectionProp(data,datawithendpoints);

                        athoc.iws.publishing.massdevices.selectedCount = 0;
                        athoc.iws.publishing.massdevices.massDeviceList.removeAll();
                        athoc.iws.publishing.massdevices.removeKeyUser(datawithendpoints,true);

                        ko.cleanNode($("#publishing-mass-edit").get(0));
                        athoc.iws.publishing.massdevices.viewModel.massDeviceList = ko.mapping.fromJS(athoc.iws.publishing.massdevices.formatMassDeviceList(datawithendpoints));
                        $("#massdevicesdisplay").html("");

                        ko.applyBindings(athoc.iws.publishing.massdevices.viewModel, $("#publishing-mass-edit").get(0));
                        athoc.iws.publishing.massdevices.viewModel.subscribeEndPoints(athoc.iws.publishing.massdevices.viewModel.massDeviceList);

                        if (athoc.iws.publishing.massdevices.viewModel.massDeviceList()[0].GroupName() != "")
                            $('#MassDeviceFlatList').show();
                        else
                            $('#MassDeviceFlatList').hide();

                        var onSave = function (selectedOptions) {
                            self.DeviceGroupOptions = selectedOptions;
                        }

                        $(".alert-nav").attr("disabled", true);
                        kendo.ui.progress($("#alert-mass-edit"), true);

                        var onLoadDone = function (selectedOptions) {
                            kendo.ui.progress($("#alert-mass-edit"), false);
                            $(".alert-nav").attr("disabled", false);

                            self.DeviceGroupOptions = selectedOptions;

                        }

                        athoc.iws.publishing.massDeviceOptions.load(datawithendpoints, presetDeviceOptions, onSave, onLoadDone);
                        athoc.iws.publishing.massdevices.collapsePanel();
                        athoc.iws.publishing.massdevices.isMassDeviceReady();

                        kendo.ui.progress($("#publishing-mass-edit"), false);

                    });

                }
            },

            removeKeyUser: function (data, canClear) {
                if (canClear) {
                    athoc.iws.publishing.massdevices.viewModel.keyDict = {};
                }
                _.each(data, function (device) {
                    var keyUser = _.find(device.EndPoints, function (endPoint) {
                        return endPoint.IsKeyUser ;
                    });
                    if (keyUser) {
                        athoc.iws.publishing.massdevices.viewModel.keyDict[device.DeviceId] = keyUser;
                        var index = device.EndPoints.indexOf(keyUser);
                        if (index > -1) {
                            device.EndPoints.splice(index, 1);
                        }
                    }
                });
            },


            //this method will be called when data is required for updating
            getModel: function () {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsMassDeviceTargetSupported)
                    return null;

                var devicedata = ko.observableArray();
                
                //create a deep copy of object
                var massdevices = ko.mapping.fromJS(ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList()));;
                
                _.each(massdevices(), function (massdevice) {
                    var selectedMassdevice = _.filter(massdevice.DeviceList(), function(selectedDevice) {
                        return selectedDevice.Selected();
                    });
                    _.each(selectedMassdevice, function (device) {
                        var endPointLength = device.EndPoints().length;
                        var deviceusers = ko.observableArray();
                        var keyListDict = athoc.iws.publishing.massdevices.viewModel.keyDict;
                        if (keyListDict) {
                            var enduser = keyListDict[device.DeviceId()];
                            if (enduser){
                                if (enduser.IsTargetable) {
                                    deviceusers.push(ko.mapping.fromJS(enduser));
                                }
                                if (endPointLength === 0) {
                                    device.EndPoints = deviceusers;
                                }
                            }
                        }
                        if (endPointLength == 1) {
                            var endPoint = device.EndPoints()[0];
                            if ((endPoint.IsKeyUser() && endPoint.IsTargetable()) ||
                                endPoint.IsSelected()) {
                                deviceusers.push(endPoint);
                            }
                            if (device.HideMassDeviceUsers() && !endPoint.IsSelected()) {
                                deviceusers.push(endPoint);
                            }
                            device.EndPoints = deviceusers;
                        } else if (endPointLength >= 2) {
                            _.each(device.SelectedUsers(), function(selectedendPoint) {
                                var selectedEndPoint = _.find(device.EndPoints(), function(endPointItem) {
                                    return endPointItem.UserId() === selectedendPoint && !endPointItem.IsKeyUser();
                                });
                                if (selectedEndPoint) {
                                    deviceusers.push(selectedEndPoint);
                                }
                            });
                            device.EndPoints = deviceusers;
                        }
                        devicedata.push(device);
                    });
                });
                var targetlist = athoc.iws.publishing.massdevices.viewModel.targetList = ko.mapping.toJS(devicedata);
                return { MassDevices: targetlist, MassDeviceGroupOptions: this.DeviceGroupOptions }
            },

            bindReadOnlyView: function (data, targetDiv) {
                athoc.iws.publishing.massdevices.massDeviceList.removeAll();
                athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList = ko.mapping.fromJS(athoc.iws.publishing.massdevices.formatMassDeviceList(athoc.iws.publishing.massdevices.filterDataforReadOnly(ko.mapping.fromJS(data))));;
                if (targetDiv[0].id !== "dialogReviewAndPublish") {
                    athoc.iws.publishing.massdevices.viewModel.massDeviceList = athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList;
                }
                ko.cleanNode($(targetDiv).find("#publishing-mass-view").get(0));
                ko.applyBindings(athoc.iws.publishing.massdevices.readOnlyModel, $(targetDiv).find("#publishing-mass-view").get(0));

                if (athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList()[0].DeviceList().length > 0)
                    $(targetDiv).find('#MassDeviceFlatList').show();
                else
                    $(targetDiv).find('#MassDeviceFlatList').hide();
            },

            collapsePanel: function () {
               $('.bucket-toggle h2').bind('click', function (e) {
                    if (e.target.id === "massDeviceOptionsLink") {
                        return;
                    }
                   if (!e.isDefaultPrevented()) {
                       $(this).parent().find('.row').slideToggle(500);
                       $(this).parent().find('.expand-arrow-open').toggle();
                       $(this).parent().find('.expand-arrow-closed').toggle();
                       if ($(this).parent().find('.expand-arrow-open').css("display") === "block") {
                           $("#massDeviceOptionsLink").show();
                       } else {
                           $("#massDeviceOptionsLink").hide();
                       }
                   }
                   e.preventDefault();
                });
               
            },

            refreshMassDevicesList: function (data) {
                var massdevices = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList());
                var url = this.Parameters.getEndPointsURL;
                var deviceColl = [];
                var refreshViewModel = function (datawithendpoints) {
                    athoc.iws.publishing.massdevices.removeKeyUser(datawithendpoints,false);
                    athoc.iws.publishing.massdevices.viewModel.massDeviceList = ko.mapping.fromJS(athoc.iws.publishing.massdevices.formatMassDeviceList(datawithendpoints, true));
                    ko.cleanNode($("#publishing-mass-edit").get(0));
                    ko.applyBindings(athoc.iws.publishing.massdevices.viewModel, $("#publishing-mass-edit").get(0));
                    athoc.iws.publishing.massdevices.viewModel.subscribeEndPoints(athoc.iws.publishing.massdevices.viewModel.massDeviceList);
                    athoc.iws.publishing.massdevices.collapsePanel();
                    athoc.iws.publishing.massdevices.isMassDeviceReady();
                }
                $(data).each(function (item) {
                    var device = null;
                    for (var i = 0; i < massdevices.length; i++) {
                        device = _.find(massdevices[i].DeviceList, function (dev) {
                            return (dev.DeviceId === data[item].DeviceId);
                        });
                        if (device) {
                            data[item].HideMassDeviceUsers = device.HideMassDeviceUsers;
                            data[item].IsAreaRequired = device.IsAreaRequired;
                            athoc.iws.publishing.massdevices.selectedCount++;
                            data[item].Selected = device.Selected;
                            data[item].EndPoints = device.EndPoints;
                            data[item].SelectedUsers = device.SelectedUsers;
                            if (data[item].EndPoints.length == 0) {
                                data[item].Enabled = false;
                            } else {
                                data[item].Enabled = true;
                            }
                            break;
                        }
                    }
                    if (!device) {
                        deviceColl.push(data[item]);
                    }

                });

                if (deviceColl.length > 0) {
                    kendo.ui.progress($("#publishing-mass-edit"), true);

                    $.when(athoc.iws.publishing.massdevices.loadEndPoints(url, deviceColl)).then(function (datawithendpoints) {
                        _.each(datawithendpoints, function (item) {
                            var dev = _.find(data, function (item2) {
                                return item.DeviceId === item2.DeviceId;
                            });
                            dev.Selected = false;
                            dev.EndPoints = item.EndPoints;
                            dev.IsAreaRequired = item.IsAreaRequired;
                            dev.HideMassDeviceUsers = item.HideMassDeviceUsers;
                            if (dev.EndPoints.length == 0) {
                                dev.Enabled = false;
                            } else {
                                dev.Enabled = true;
                            }
                        });
                        refreshViewModel(data);

                        kendo.ui.progress($("#publishing-mass-edit"), true);

                    });
                } else {
                    refreshViewModel(data);
                }
            },

            filterDataforReadOnly: function (data) {
                var filterData = ko.mapping.toJS(data).filter(function (el) {
                    return el.Selected;
                });
                return filterData;
            },

            formatMassDeviceList: function (data, justFormat) {
                var groupList = [];
                var deviceList = [];
                var groupId = 0;
                var groupName = "";
                var filterData = data;
                var skipDevices = false;
                if (justFormat !== undefined) {
                    skipDevices = true;
                }
                $(filterData).each(function (index) {
                   if (groupId != filterData[index].GroupId) {

                        if (deviceList.length > 0) {
                            groupList.push({ GroupId: groupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                            deviceList = [];
                        }

                        deviceList.push(filterData[index]);
                        //if (filterData[index].Selected) {
                        if (!skipDevices) {
                            athoc.iws.publishing.massdevices.massDeviceList.push(filterData[index]);
                        }
                        athoc.iws.publishing.massdevices.selectedCount++;
                        //}
                        groupName = filterData[index].GroupName;
                        groupId = filterData[index].GroupId;

                    } else {
                        //if (filterData[index].Selected) {
                        if (!skipDevices) {
                            athoc.iws.publishing.massdevices.massDeviceList.push(filterData[index]);
                        }
                        athoc.iws.publishing.massdevices.selectedCount++;
                        //}

                        deviceList.push(filterData[index]);
                    }

                });
                groupList.push({ GroupId: groupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                return groupList;
            },

            readonlyMassDeviceList: function (data) {
                var groupList = [];
                var deviceList = [];
                var groupId = 0;
                var groupName = "";
                var filterData = data;

                $(filterData).each(function (index) {
                    if (groupId != filterData[index].GroupId) {
                        groupId = filterData[index].GroupId;

                        if (deviceList.length > 0) {
                            groupList.push({ GroupId: filterData[index].GroupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                            deviceList = [];
                        }

                        deviceList.push(filterData[index]);
                        groupName = filterData[index].GroupName;
                    } else {

                        deviceList.push(filterData[index]);
                    }

                });
                groupList.push({ GroupId: groupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                return groupList;

            },

            endPointSelected:function(device,arg) {
                device.EndPoints()[0].IsSelected(arg.originalEvent.target.checked);
                athoc.iws.publishing.massdevices.isMassDeviceReady();
                return true;
            },

            massDeviceChanged: function (device) {
                athoc.iws.publishing.massdevices.isChanged = true;
                var self = this;
                if (device.Selected()) {
                    athoc.iws.publishing.massdevices.massDeviceList.push(ko.mapping.toJS(device));
                    athoc.iws.publishing.massdevices.selectedCount++;

                    $(".alert-nav").attr("disabled", true);
                    kendo.ui.progress($("#alert-mass-edit"), true);

                    var onLoadDone = function (selectedOptions) {

                        kendo.ui.progress($("#alert-mass-edit"), false);
                        $(".alert-nav").attr("disabled", false);
                        athoc.iws.publishing.massdevices.DeviceGroupOptions = selectedOptions;
                    }


                } else {
                    athoc.iws.publishing.massdevices.massDeviceList.remove(function (item) {
                        return item.DeviceId == device.DeviceId();
                    });
                    athoc.iws.publishing.massdevices.selectedCount--;
                }

                var checkedDevices = new Array();
                var mlist = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList);
                for (var i = 0; i < mlist.length; i++) {
                    for (j = 0; j < mlist[i].DeviceList.length; j++) {
                        var device = mlist[i].DeviceList[j];
                        if (device.Selected) {
                            checkedDevices.push(mlist[i].DeviceList[j]);
                        }
                    }
                }

                athoc.iws.publishing.massDeviceOptions.loadOnlyNewDeviceGroups(checkedDevices, onLoadDone);

                $(athoc.iws.publishing.massdevices.Parameters.massDeviceOptionsLink).toggleClass("link-disabled", (checkedDevices.length == 0));

                athoc.iws.publishing.massdevices.isMassDeviceReady();
                return true;
            },
            isAnyMassDeviceSelected: function () {
                var mlist = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList);
                for (var i = 0; i < mlist.length; i++) {
                    for (j = 0; j < mlist[i].DeviceList.length; j++) {
                        var device = mlist[i].DeviceList[j];
                        if (device.Selected) {
                            return true;
                        }
                    }
                }
                return false;

            },
            isMassDeviceReady: function () {
                var notReady = function () {
                    athoc.iws.publishing.massdevices.isReadyToPublish = false;
                    athoc.iws.publishing.massdevices.isInErrorState = true;
                    athoc.iws.publishing.SetSectionStatus("#massDevicesStatus", "notReady");
                };
                var ready = function () {
                    athoc.iws.publishing.massdevices.isReadyToPublish = true;
                    athoc.iws.publishing.massdevices.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#massDevicesStatus", "ready");
                };
                var open = function () {
                    athoc.iws.publishing.massdevices.isReadyToPublish = false;
                    athoc.iws.publishing.massdevices.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#massDevicesStatus", "open");
                };
                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
                if (massDeviceModel && massDeviceModel.MassDevices && massDeviceModel.MassDevices.length > 0) {
                    var selectedDevices = $.grep(massDeviceModel.MassDevices, function (device) {
                        return device.Selected;
                    });
                    if (selectedDevices.length == 0) {
                        open();
                    } else {
                        ready();
                    }
                    _.each(massDeviceModel.MassDevices, function (device) {
                        if (!device.EndPoints || device.EndPoints.length == 0) {
                            notReady();
                        }
                        if (device.IsAreaRequired)
                            if (!athoc.iws.publishing.massdevices.isLocationPresent()) {
                                notReady();
                            }
                    });
                } else {
                    open();
                }
            },

            handleError: function (e) {
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },
            targetKeyUser: function (groupid, select, elementId) {
                var massdevices = athoc.iws.publishing.massdevices.viewModel.massDeviceList();
                var keyListDict = athoc.iws.publishing.massdevices.viewModel.keyDict;
                var endPointFound = false;
                for (var i = 0; i < massdevices.length; i++) {
                    var massdevice = massdevices[i];
                    for (var j = 0; j < massdevice.DeviceList().length; j++) {
                        var device = massdevice.DeviceList()[j];
                        if (groupid === device.GroupId()) {
                            if (keyListDict) {
                                var keyuser = keyListDict[device.DeviceId()];

                                if (keyuser) {
                                    if (select) {

                                        if (typeof elementId != "undefined") //must apply targeting not allowed changes 
                                        {

                                            var className = $('select[id^="' + $("input:radio[name='" + elementId + "']:checked").attr("id") + '"]').find("option:selected").attr("class");
                                            if (className == "MSG-TARGETING-NOT-ALLOWED") {
                                                //if ($('[name="' + elementId + '"]').find(":selected").attr("class") == "MSG-TARGETING-NOT-ALLOWED") {
                                                //$("input:radio[name='" + elementId + "']:checked")
                                                //unselect all of the non-key users
                                                device.SelectedUsers([]);

                                                //disable dropdown
                                                if ($("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").length !=0)
												{
													$("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").prop("disabled", true);
													device.EndPoints()[0].IsSelected(false); //uncheck checkbox
												}
												

                                                $("[deviceidentifier='" + device.DeviceId() + "']").find(".show-tick").css('pointer-events', 'none');
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").attr("disabled", true);
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").selectpicker('refresh');
                                                $("[deviceidentifier='" + device.DeviceId() + "']").find("button").prop("disabled", true)


                                            } else {
                                                //enble dropdown
                                                
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").attr("disabled", false);
												if ($("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").length !=0)
												{
													$("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").prop("disabled", false);

												}
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").selectpicker('refresh');
                                                $("[deviceidentifier='" + device.DeviceId() + "']").find("button").prop("disabled", false);
                                                $("[deviceidentifier='" + device.DeviceId() + "']").find(".show-tick").css('pointer-events', '');


                                            }
                                        } 

                                        keyuser.IsTargetable = true;
                                    } else {
                                        keyuser.IsTargetable = false;
                                        if (typeof elementId != "undefined") //must apply targeting not allowed changes 
                                        {
                                            //enble dropdown
											if ($("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").length !=0)
											{
												$("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").prop("disabled", false);
											}
                                            //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").attr("disabled", false);
                                            //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").selectpicker('refresh');
                                            $("[deviceidentifier='" + device.DeviceId() + "']").find("button").prop("disabled", false);
                                            $("[deviceidentifier='" + device.DeviceId() + "']").find(".show-tick").css('pointer-events', '');




                                        }
                                    }
                                    endPointFound = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (endPointFound) {
                        athoc.iws.publishing.massdevices.isMassDeviceReady();
                        break;
                    }
                }
            },
            IsThisDeviceGroupTargeted: function (groupid) {
                var massdevices = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList());
                var targeted = false;


                _.each(massdevices, function (group) {

                    _.each(group.DeviceList, function (dev) {
                        if (dev.GroupId == groupid && dev.Selected) {
                            targeted = true;
                        }
                    });

                });
                return targeted;
            }

        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.scenario.schedule.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.scenario = athoc.iws.scenario || {};

if (athoc.iws.scenario) {
    var FromDateValueForServer;
    ko.validation.init({
        insertMessages: false,
        errorElementClass: 'err-cntrl'
    });
    athoc.iws.scenario.schedule = function () {

        return {
            isInErrorState: false,
            IsActiveRecurrence: false,
            IsActiveError: false,
            tempRecur_StartDate: "",
            scheduleRecurrenceType: "0",
            IsScheduleChanged: false,
            viewModel: {
                starttimehours: ko.observableArray([{ value: 1, text: "01" }, { value: 2, text: "02" }, { value: 3, text: "03" }, { value: 4, text: "04" }, { value: 5, text: "05" }, { value: 6, text: "06" }, { value: 7, text: "07" }, { value: 8, text: "08" }, { value: 9, text: "09" }, { value: 10, text: "10" }, { value: 11, text: "11" }, { value: 12, text: "12" }]),
                starttimeminutes: ko.observableArray([{ value: 0, text: "00" }, { value: 1, text: "01" }, { value: 2, text: "02" }, { value: 03, text: "03" }, { value: 4, text: "04" }, { value: 5, text: "05" }, { value: 6, text: "06" }, { value: 7, text: "07" }, { value: 8, text: "08" }, { value: 9, text: "09" }, { value: 10, text: "10" }, { value: 11, text: "11" }, { value: 12, text: "12" }, { value: 13, text: "13" }, { value: 14, text: "14" }, { value: 15, text: "15" }, { value: 16, text: "16" }, { value: 17, text: "17" }, { value: 18, text: "18" }, { value: 19, text: "19" }, { value: 20, text: "20" }, { value: 21, text: "21" }, { value: 22, text: "22" }, { value: 23, text: "23" }, { value: 24, text: "24" }, { value: 25, text: "25" }, { value: 26, text: "26" }, { value: 27, text: "27" }, { value: 28, text: "28" }, { value: 29, text: "29" }, { value: 30, text: "30" }, { value: 31, text: "31" }, { value: 32, text: "32" }, { value: 33, text: "33" }, { value: 34, text: "34" }, { value: 35, text: "35" }, { value: 36, text: "36" }, { value: 37, text: "37" }, { value: 38, text: "38" }, { value: 39, text: "39" }, { value: 40, text: "40" }, { value: 41, text: "41" }, { value: 42, text: "42" }, { value: 43, text: "43" }, { value: 44, text: "44" }, { value: 45, text: "45" }, { value: 46, text: "46" }, { value: 47, text: "47" }, { value: 48, text: "48" }, { value: 49, text: "49" }, { value: 50, text: "50" }, { value: 51, text: "51" }, { value: 52, text: "52" }, { value: 53, text: "53" }, { value: 54, text: "54" }, { value: 55, text: "55" }, { value: 56, text: "56" }, { value: 57, text: "57" }, { value: 58, text: "58" }, { value: 59, text: "59" }]),
                starttimemeridian: ko.observableArray([{ value: "AM", text: "AM" }, { value: "PM", text: "PM" }]),
                scenarioSchedule: ko.observable(),
                FromDateValue: ko.observable(),
                timeformart: ko.observableArray(),
                recurrencepath: ko.observableArray(),
                days: ko.observableArray([{ value: 1, text: 1 }, { value: 2, text: 2 }, { value: 3, text: 3 }, { value: 4, text: 4 }, { value: 5, text: 5 }, { value: 6, text: 6 }, { value: 7, text: 7 }, { value: 8, text: 8 }, { value: 9, text: 9 }, { value: 10, text: 10 }, { value: 11, text: 11 }, { value: 12, text: 12 }, { value: 13, text: 13 }, { value: 14, text: 14 }, { value: 15, text: 15 }, { value: 16, text: 16 }, { value: 17, text: 17 }, { value: 18, text: 18 }, { value: 19, text: 19 }, { value: 20, text: 20 }, { value: 21, text: 21 }, { value: 22, text: 22 }, { value: 23, text: 23 }, { value: 24, text: 24 }, { value: 25, text: 25 }, { value: 26, text: 26 }, { value: 27, text: 27 }, { value: 28, text: 28 }, { value: 29, text: 29 }, { value: 30, text: 30 }, { value: 31, text: 31 }]),
                daynames: ko.observableArray(),
                numbernames: ko.observableArray(),
                monthnames: ko.observableArray(),
                IsAffiliate: ko.observable(false),
            },

            load: function () {
            },

            //is ready for publish
            isReadyToPublish: function () {
                return (this.isValid);
            },

            initiatePickers: function () {

                var dateformat = athoc.iws.scenario.schedule.getVPSTimeFormat('dateformat');
                var timeformat = athoc.iws.scenario.schedule.getVPSTimeFormat('timeformat');
                var momentdateformat = athoc.iws.scenario.schedule.getVPSTimeFormat('momentdateformat');
                var momenttimeformat = athoc.iws.scenario.schedule.getVPSTimeFormat('momenttimeformat');
                var AMPMformat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? true : false;


                $("#ddlAlertTimeHr").selectpicker();
                $("#ddlAlertTimeFormat").selectpicker();
                $("#ddlRecurrencePattern").selectpicker();

                $("#ddlYearMonthsctr1").selectpicker();
                $("#ddlYearIndexDay").selectpicker();
                $("#ddlYearWeekDays").selectpicker();
                $("#ddlYearMonthsCtr2").selectpicker();

                $("#ddlMonthDays").selectpicker();
                $("#ddlIndexDay").selectpicker();
                $("#ddlWeekDays").selectpicker();

                //Recurrence Time dropdowns
                var Dt = new Date(moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(), "HH:mm A"));
                var hours = Dt.getHours();
                var minutes = Dt.getMinutes();
                var ampm = hours >= 12 ? "PM" : "AM";
                hours = (hours % 12) ? (hours < 10 ? '0' + hours : (hours < 13 ? hours : ((hours - 12) < 10 ? '0' + (hours - 12) : (hours - 12)))) : 12;
                minutes = minutes < 10 ? '0' + minutes : minutes;
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartHourSelect(hours.toString());
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartMinuteSelect(minutes.toString());
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartAmpmSelect(ampm); 
                $("#ddlStartTimeHr").selectpicker();
                $("#ddlStartTimeMin").selectpicker();
                $("#ddlStartTimelMer").selectpicker();
                //End Recurrence Time dropdowns

                $('#iScheduleRecurrenceTime').datetimepicker({
                    pickDate: false,
                    pickTime: true,
                    pick12HourFormat: AMPMformat,
                    pickSeconds: false,
                    language: $.culture,
                    startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toDateString() + " " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(), momenttimeformat)),// "MM/DD/YYYY hh:mm A"
                    format: momenttimeformat.replace(":ss", ""),
                    setValue: new Date(moment($.vpsTimeZone.CurrentVPSDate.toDateString() + " " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(), momenttimeformat)),// "MM/DD/YYYY hh:mm A"
                }).on('changeDate', function (ev) {
                    if (ev.localDate == null)
                        ev.localDate = new Date(moment($.vpsTimeZone.CurrentVPSDate.toDateString() + " " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(), "MM/DD/YYYY hh:mm A"));
                    if (ev.localDate != null) {
                        var newDate = moment(ev.localDate).format(momenttimeformat.replace(":ss", ""));
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(newDate);
                    }
                    else
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(moment($.vpsTimeZone.CurrentVPSDate.toLocaleString(), momenttimeformat.replace(":ss", "")));
                });

                $('#startDateValue').datetimepicker({
                    pickDate: true,
                    pickTime: false,
                    language: $.culture,

                    startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleDateString(), 'MM/DD/YYYY')),
                    format: dateformat
                }).on('changeDate', function (ev) {
                    if (ev.localDate != null) {
                        var newDate = moment(ev.localDate).format(momentdateformat);
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(newDate);
                    }
                });

                $('#endDateValue').datetimepicker({
                    pickDate: true,
                    pickTime: false,
                    language: $.culture, startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleDateString(), 'MM/DD/YYYY')),
                    format: dateformat
                }).on('changeDate', function (ev) {
                    if (ev.localDate != null) {
                        var newDate = moment(ev.localDate).format(momentdateformat);
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput(newDate);
                    }
                });

                $("#ScenarioSchedules .icon-calendar").click(function () {
                    $('html,body').animate({ scrollTop: 9999 }, 'slow');
                    $('.bootstrap-datetimepicker-widget').css("z-index", "6");
                });
            },

            getVPSTimeFormat: function (formatType) {
                var timeFormat;
                var meridianFormat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? " A" : "";
                var secondsIncluded = $.vpsDateTimeFormat.indexOf('ss') > 0 ? ":ss" : "";
                var dateFormat;
                switch (formatType) {

                    case "timeformat":
                        timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP").replace("hh", "HH"));
                        return timeFormat;
                        break;
                    case "dateformat":
                        dateFormat = $.vpsDateFormat;
                        return dateFormat;
                        break;
                    case "momenttimeformat":
                        if (meridianFormat == "")
                            timeFormat = "HH:mm" + secondsIncluded;
                        else
                            timeFormat = "hh:mm" + secondsIncluded + meridianFormat;
                        return timeFormat;

                        break;
                    case "momentdateformat":
                        dateFormat = $.vpsDateFormat.toUpperCase();
                        return dateFormat;
                        break;
                }



            },


            bind: function (data) {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return;
                data.ScheduleRecurrenceType = 0;
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule = ko.mapping.fromJS(data, athoc.iws.scenario.schedule.getValidation());
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck() ? "1" : "0");
                // Dropdown List
                athoc.iws.scenario.schedule.viewModel.timeformart(data.TimeFormat);
                athoc.iws.scenario.schedule.viewModel.recurrencepath(data.TimePeriod);
                athoc.iws.scenario.schedule.viewModel.daynames(data.DayNames);
                athoc.iws.scenario.schedule.viewModel.monthnames(data.MonthNames);
                athoc.iws.scenario.schedule.viewModel.numbernames(data.NumberNames);
                //keep old start date into temp variable to verify
                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck())
                    athoc.iws.scenario.schedule.tempRecur_StartDate = athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput();
                else
                    athoc.iws.scenario.schedule.tempRecur_StartDate = "";

                //View Model binding
                $("#ScenarioSchedules").find(".bootstrap-select").remove();
                ko.cleanNode($("#ScenarioSchedules").get(0));
                ko.applyBindings(athoc.iws.scenario.schedule.viewModel, $("#ScenarioSchedules").get(0));
                // set model parameters
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio(data.ScheduleRecurrenceRadio);
                athoc.iws.scenario.schedule.IsActiveRecurrence = athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck();
                athoc.iws.scenario.schedule.scheduleRecurrenceType = athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck() ? "1" : "0";
                //reset start date to current date if recurrence is not checked.
                if (!athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck())
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(moment($.vpsTimeZone.CurrentVPSDate).format(dateformat));
                // Initiate Bootstrap pickers
                athoc.iws.scenario.schedule.initiatePickers();
                athoc.iws.scenario.schedule.enableRecurrencePeriod(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup());

                athoc.iws.scenario.schedule.enableDailyGroupOptions(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyRadiogroup());

                athoc.iws.scenario.schedule.enableYearlyGroupOptions(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyModeRadiogroup());

                athoc.iws.scenario.schedule.enableMonthlyGroupOptions(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyRadiogroup());

                //Initiate Subscribe Methods
                athoc.iws.scenario.schedule.scenarioSchedulesubscribers();
                //Verify schedule section is ready
                athoc.iws.scenario.schedule.isScheduleReady();
            },
            scenarioSchedulesubscribers: function () {

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartHourSelect.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.IsScheduleChanged = true;
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartHourSelect() + ":" + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartMinuteSelect() + ": " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartAmpmSelect(), "hh:mm A").format(athoc.iws.scenario.schedule.getVPSTimeFormat('momenttimeformat').replace(":ss", "")));
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartMinuteSelect.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.IsScheduleChanged = true;
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartHourSelect() + ":" + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartMinuteSelect() + ": " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartAmpmSelect(), "hh:mm A").format(athoc.iws.scenario.schedule.getVPSTimeFormat('momenttimeformat').replace(":ss", "")));
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartAmpmSelect.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.IsScheduleChanged = true;
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartHourSelect() + ":" + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartMinuteSelect() + ": " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartAmpmSelect(), "hh:mm A").format(athoc.iws.scenario.schedule.getVPSTimeFormat('momenttimeformat').replace(":ss", "")));
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck.subscribe(function (newValue) {
                    if (newValue)
                        athoc.iws.scenario.schedule.IsScheduleChanged = true;
                    else
                        athoc.iws.scenario.schedule.IsScheduleChanged = false;
                    switch (parseInt(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio())) {
                        case 4:
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "");
                            break;
                        case 8:
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceWeekly").css("display", "");
                            break;
                        case 16:
                            $("#ddlMonthDays").selectpicker();
                            $("#ddlIndexDay").selectpicker();
                            $("#ddlWeekDays").selectpicker();
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "");
                            break;
                        case 64:
                            $("#ddlYearMonthsctr1").selectpicker();
                            $("#ddlYearIndexDay").selectpicker();
                            $("#ddlYearWeekDays").selectpicker();
                            $("#ddlYearMonthsCtr2").selectpicker();
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceYearly").css("display", "");
                            break;

                    }

                    if (!athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput.isValid())
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput.valueHasMutated();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio.subscribe(function (newValue) {

                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 64) {
                        $("#ddlYearMonthsctr1").selectpicker();
                        $("#ddlYearIndexDay").selectpicker();
                        $("#ddlYearWeekDays").selectpicker();
                        $("#ddlYearMonthsCtr2").selectpicker();
                    }

                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 16) {
                        $("#ddlMonthDays").selectpicker();
                        $("#ddlIndexDay").selectpicker();
                        $("#ddlWeekDays").selectpicker();
                    }
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });


                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyFrequencyInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyModeRadiogroup.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.enableYearlyGroupOptions(newValue);
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyRadiogroup.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.enableDailyGroupOptions(newValue);
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyRadiogroup.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.enableMonthlyGroupOptions(newValue);
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.enableRecurrencePeriod(newValue);
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteMonthSelect.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeekly.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType.subscribe(function (newValue) {
                    if (newValue == 0)
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck(false);
                    else
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck(true);
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.isScheduleReady();
            },
            enableDailyGroupOptions: function (value) {
                if (value == 2)
                    $("#txtScheduleRecurrenceDailyFrequencyInput").removeAttr("disabled");
                else
                    $("#txtScheduleRecurrenceDailyFrequencyInput").attr("disabled", "disabled");
            },

            enableMonthlyGroupOptions: function (value) {
                if (value == 16) {
                    $('[data-id=ddlMonthDays]').removeAttr("disabled");
                    $('[data-id=ddlIndexDay]').attr("disabled", "disabled");
                    $('[data-id=ddlWeekDays]').attr("disabled", "disabled");
                }
                if (value == 32) {
                    $('[data-id=ddlMonthDays]').attr("disabled", "disabled");
                    $('[data-id=ddlIndexDay]').removeAttr("disabled");
                    $('[data-id=ddlWeekDays]').removeAttr("disabled");
                }


            },
            enableYearlyGroupOptions: function (value) {

                if (value == 64) {
                    $('[data-id=ddlYearMonthsctr1]').removeAttr("disabled");
                    $("#txtDay").removeAttr("disabled");
                    $('[data-id=ddlYearIndexDay]').attr("disabled", "disabled");
                    $('[data-id=ddlYearWeekDays]').attr("disabled", "disabled");
                    $('[data-id=ddlYearMonthsCtr2]').attr("disabled", "disabled");
                }
                if (value == 128) {
                    $('[data-id=ddlYearMonthsctr1]').attr("disabled", "disabled");
                    $("#txtDay").attr("disabled", "disabled");
                    $('[data-id=ddlYearIndexDay]').removeAttr("disabled");
                    $('[data-id=ddlYearWeekDays]').removeAttr("disabled");
                    $('[data-id=ddlYearMonthsCtr2]').removeAttr("disabled");
                }
            },
            enableRecurrencePeriod: function (value) {
                if (value == 1) {
                    $("#txtScheduleRecurrenceEndCountInput").attr("disabled", "disabled");
                    $("#endDateValue").datetimepicker("disable");
                }
                if (value == 2) {
                    $("#txtScheduleRecurrenceEndCountInput").removeAttr("disabled");
                    $("#endDateValue").datetimepicker("disable");
                }
                if (value == 3) {
                    $("#txtScheduleRecurrenceEndCountInput").attr("disabled", "disabled");
                    $("#endDateValue").datetimepicker("disable");
                    $("#endDateValue").datetimepicker("enable");
                }
            },
            isValid: function () {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return true;


                athoc.iws.scenario.schedule.IsActiveError = false;
                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput() == "")
                    return false;
                else {
                    if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput()) == false)
                        return false;
                    else {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput() < 1)
                            return false;
                        switch (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationUnitSelect()) {
                            case 'Minute':
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput() > 5256000)
                                    return false;
                                break;
                            case 'Hour':
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput() > 87600)
                                    return false;
                                break;
                            case 'Day':
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput() > 3650)
                                    return false;
                                break;
                        }
                    }
                }
                //if Activate Recurrence is checked
                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck()) {
                    //Daily group validations
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 4 && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyRadiogroup() == 2) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput() == "") {
                            athoc.iws.scenario.schedule.IsActiveError = true;
                            return false;
                        } else {
                            if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput()) == false)
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput() < 1 || athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput() > 365)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            }
                        }
                    }
                    //Weekly group validations
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 8) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput() == "")
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        else {
                            if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput()) == false)
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput() < 1 || athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput() > 52)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            }
                        }
                        //Week days check boxes
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeekly().length < 1)
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                    }
                    //Monthly group validations
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 16) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyFrequencyInput() == "")
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        else {
                            if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyFrequencyInput()) == false)
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyFrequencyInput() < 1 || athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyFrequencyInput() > 12)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            }
                        }
                    }
                    //Yearly group validations
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 64 && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyModeRadiogroup() == 64) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput() == "")
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        else {
                            if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput()) == false)
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput() < 1)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }

                                //days per months 
                                switch (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteMonthSelect()) {
                                    case 2:
                                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput() > 29)
                                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                        break;
                                    case 1:
                                    case 3:
                                    case 5:
                                    case 7:
                                    case 8:
                                    case 10:
                                    case 12:
                                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput() > 31)
                                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                        break;
                                    case 4:
                                    case 6:
                                    case 9:
                                    case 11:
                                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput() > 30)
                                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                        break;
                                }

                            }
                        }
                    }

                    //Start Date
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput() == "")
                    { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                    else {
                        if (!athoc.iws.scenario.schedule.isValidDate(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput()))
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        //start date should not be older date from today                        
                        if ((moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate().toDateString() != ($.vpsTimeZone.CurrentVPSDate).toDateString()) && moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate().getTime() - (new Date(($.vpsTimeZone.CurrentVPSDate).toDateString()).getTime()) < 0)
                            //iws-12152(issue#1)
                            //ignore, if already saved start date is not changed
                            if (athoc.iws.scenario.schedule.tempRecur_StartDate != athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput())
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        //End Date
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup() == 3) {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput() == "")
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (!athoc.iws.scenario.schedule.isValidDate(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput()))
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                //End Date should be greater than or equal to Start date
                                if (moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput(), $.vpsDateFormat.toUpperCase()).toDate() < moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate())
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                if ((athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput() != athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput()) && (moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput(), $.vpsDateFormat.toUpperCase()).toDate().getTime() - moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate().getTime() / (24 * 60 * 60 * 1000) < 0))
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                //Duration between End Date and Start date shuld be less than 10 years
                                if (Math.abs((moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput(), $.vpsDateFormat.toUpperCase()).toDate().getTime() - moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate().getTime()) / (24 * 60 * 60 * 1000)) > 3650)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            }
                        }
                    }

                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup() == 2) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput() == "")
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        else {
                            if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput()) == false)
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput() < 1 || athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput() > 3650)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            }
                        }
                    }

                }
                return true;

            },

            isValidDate: function (val) {
                var isValid = true;
                try {
                    // jQuery.datepicker.parseDate($.vpsDateFormat, val, null);
                    //isValid = !isNaN(Date.parse(val));
                    isValid = moment(val, $.vpsDateFormat.toUpperCase()).isValid();
                }
                catch (error) {
                    isValid = false;
                }

                return isValid;
            },
            validDayArrange: function (param1, param2, param3) {
                if (param2[1].indexOf('StartDate') < 0 && param2[1].indexOf('EndDate') < 0) {
                    if ($.isNumeric(param1) == false)
                        return false;
                    if (param1 < 1)
                        return false;
                }
                switch (param2[1]) {
                    case 'Duration':
                        {
                            switch (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationUnitSelect()) {
                                case 'Minute':
                                    if (param1 > 5256000)
                                        return false;
                                    break;
                                case 'Hour':
                                    if (param1 > 87600)
                                        return false;
                                    break;
                                case 'Day':
                                    if (param1 > 3650)
                                        return false;
                                    break;
                            }
                            break;
                        }
                    case 'Days':
                        {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyRadiogroup() == 2 && param1 > 365)
                                return false;
                            break;
                        }
                    case 'Weeks':
                        {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 8 && param1 > 52)
                                return false;
                            //Week days check boxes
                            //if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 8 && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeekly().length < 1)
                            //    return false;
                            break;
                        }
                    case 'Months':
                        {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 16 && param1 > 12)
                                return false;
                            break;
                        }
                    case 'Recurrence':
                        {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup() == 2 && param1 > 3650)
                                return false;
                            break;
                        }
                    case 'StartDate':
                        {
                            if (!athoc.iws.scenario.schedule.isValidDate(param1))
                                return false;
                            break;
                        }
                    case 'StartDateIsOlder':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1))
                                //start date should not be older date from today
                                if ((moment(param1, $.vpsDateFormat.toUpperCase()).toDate().toDateString() != ($.vpsTimeZone.CurrentVPSDate).toDateString()) && (moment(param1, $.vpsDateFormat.toUpperCase()).toDate().getTime() - (new Date(($.vpsTimeZone.CurrentVPSDate).toDateString()).getTime()) < 0))
                                    //iws-12152(issue#1)
                                    //ignore, if already saved start date is not changed
                                    if (athoc.iws.scenario.schedule.tempRecur_StartDate != param1)
                                        return false;
                            break;
                        }
                    case 'StartDateVsEndDate':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1) && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup != undefined && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup() == 3
                                && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput != undefined)
                                //Start date should not be grater date from End date
                                if (moment(param1, $.vpsDateFormat.toUpperCase()).toDate() > moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput(), $.vpsDateFormat.toUpperCase()).toDate())
                                    return false;
                            break;
                        }
                    case 'StartDate10Years':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1))
                                //start date should not be 10 years from today
                                if (Math.abs((moment(param1, $.vpsDateFormat.toUpperCase()).toDate().getTime() - new Date(($.vpsTimeZone.CurrentVPSDate).toDateString()).getTime()) / (24 * 60 * 60 * 1000)) > 3650)
                                    return false;
                            break;
                        }
                    case 'EndDate':
                        {
                            if (!athoc.iws.scenario.schedule.isValidDate(param1))
                                return false;
                            break;
                        }
                    case 'EndDateIsOlder':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1))
                                //End date should not be older date from today
                                if ((moment(param1, $.vpsDateFormat.toUpperCase()).toDate().toDateString() != ($.vpsTimeZone.CurrentVPSDate).toDateString()) && (moment(param1, $.vpsDateFormat.toUpperCase()).toDate().getTime() - (new Date(($.vpsTimeZone.CurrentVPSDate).toDateString()).getTime()) < 0))
                                    return false;
                            break;
                        }
                    case 'EndDateVsStartDate':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1) && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput != undefined)
                                //End date should not be older date from start date
                                if (moment(param1, $.vpsDateFormat.toUpperCase()).toDate() < moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate())
                                    return false;
                            break;
                        }
                    case 'EndDate10Years':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1))
                                //End Date should be greater than or equal to Start date
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup != undefined && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup() == 3)
                                    if (moment(param1, $.vpsDateFormat.toUpperCase()).toDate() < moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate())
                                        return false;
                            break;
                        }
                    case 'WeekName':
                        {
                            //Week days check boxes
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 8 && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeekly().length < 1)
                                return false;
                            break;
                        }
                    case 'DaysPerMonth':
                        {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 64 && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyModeRadiogroup() == 64) {
                                switch (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteMonthSelect()) {
                                    case 2:
                                        if (param1 > 29)
                                            return false;
                                        break;
                                    case 1:
                                    case 3:
                                    case 5:
                                    case 7:
                                    case 8:
                                    case 10:
                                    case 12:
                                        if (param1 > 31)
                                            return false;
                                        break;
                                    case 4:
                                    case 6:
                                    case 9:
                                    case 11:
                                        if (param1 > 30)
                                            return false;
                                        break;
                                }
                                break;
                            }

                            break;
                        }

                }
                return true;
            },
            isScheduleReady: function () {
                if (athoc.iws.scenario.schedule.isValid()) {
                    athoc.iws.scenario.schedule.isReadyToPublish = true;
                    athoc.iws.scenario.schedule.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#scheduleStatus", "ready");


                } else {
                    athoc.iws.scenario.schedule.isReadyToPublish = false;
                    athoc.iws.scenario.schedule.isInErrorState = true;
                    athoc.iws.publishing.SetSectionStatus("#scheduleStatus", "notReady");

                }
            },
            isActiveRecurrence: function (isReady, isActiveError, isChanged) {
                isActiveError = athoc.iws.scenario.schedule.IsActiveError == undefined ? false : athoc.iws.scenario.schedule.IsActiveError;
                if (!isActiveError) {
                    if (!isReady) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType != undefined && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType() == "1" && isChanged) {
                            athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType("0");
                        }
                        $("#rdSetAtPublish").prop("disabled", true);
                    } else {

                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType != undefined && athoc.iws.scenario.schedule.scheduleRecurrenceType != undefined && athoc.iws.scenario.schedule.scheduleRecurrenceType == "1" && athoc.iws.scenario.schedule.IsScheduleChanged && isChanged) {
                            athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType("1");
                        }
                        $("#rdSetAtPublish").prop("disabled", false);
                    }
                }

            },
            //setup validation
            getValidation: function () {
                var validationMapping = {
                    ScheduleDurationInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: { message: athoc.iws.scenario.resources.Scenario_Schedule_Err_Duration },
                                maxLength: { params: 7, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('7') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_ValidDuration_Years.format('10'),
                                    params: [this.value, "Duration", 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceDailyFrequencyInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: { params: 3, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('3') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_ValidNumberBetween.format(1, 365),
                                    params: [this.value, "Days", 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceWeeklyFrequencyInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: { params: 3, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('3') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_ValidNumberBetween.format(1, 52),
                                    params: [this.value, "Weeks", 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceRadio: {
                        create: function (options) {
                            return ko.observable("").extend({
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_AtleastOneDay,
                                    params: [3, "WeekName", 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceMonthlyFrequencyInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: { params: 2, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('2') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_ValidNumberBetween.format(1, 12),
                                    params: [this.value, "Months", 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceYearlyAbsoluteDayInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: { params: 2, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('2') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_DayMonth_NotValid,
                                    params: [this.value, 'DaysPerMonth', 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceEndCountInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: { params: 7, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('7') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                min: { params: 1, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NumberLessThanOne },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_RecurrenceDuration_Years.format(10),
                                    params: [this.value, 'Recurrence', 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceStartDateInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                validation: [{
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NotValidDate,
                                    params: [this.value, 'StartDate', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_StartDate_LessThan_CurrDate,
                                    params: [this.value, 'StartDateIsOlder', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_StartDate_MoreThan_EndDate,
                                    params: [this.value, 'StartDateVsEndDate', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_StartDate_Exceed_Years.format(10),
                                    params: [this.value, 'StartDate10Years', 2]
                                }
                                ]
                            });
                        }
                    },

                    ScheduleRecurrenceEnddateInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                validation: [{
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NotValidDate,
                                    params: [this.value, 'EndDate', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_EndDate_LessThan_CurrDate,
                                    params: [this.value, 'EndDateIsOlder', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_EndDate_LessThan_StartDate,
                                    params: [this.value, 'EndDateVsStartDate', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_EndDate_Exceed_Years.format(10),
                                    params: [this.value, 'EndDate10Years', 2]
                                }
                                ]
                            });
                        }
                    },

                };

                return validationMapping;
            },

            //this method will be called when data is required for updating
            getModel: function () {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return null;
                return ko.mapping.toJS(athoc.iws.scenario.schedule.viewModel.scenarioSchedule);
            },

            toggleScheduleSection: function () {
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return;
                if (!athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck()) {
                    $("#RecurrencePattern").css("display", "none");
                    $("#RecurrencePeriod").css("display", "none");

                    $("#RecurrenceDaily").css("display", "none");
                    $("#RecurrenceWeekly").css("display", "none");
                    $("#RecurrenceMonthly").css("display", "none");
                    $("#RecurrenceYearly").css("display", "none");
                    switch (parseInt(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio())) {
                        case 4:
                            $("#RecurrenceDaily").css("display", "");
                            break;
                        case 8:
                            $("#RecurrenceWeekly").css("display", "");
                            break;
                        case 16:
                            $("#RecurrenceMonthly").css("display", "");
                            break;
                        case 64:
                            $("#RecurrenceYearly").css("display", "");
                            break;
                        default:
                            $("#RecurrenceDaily").css("display", "");
                            break;
                    }

                } else {
                    switch (parseInt(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio())) {
                        case 4:
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "");
                            break;
                        case 8:
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceWeekly").css("display", "");
                            break;
                        case 16:
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "");
                            break;
                        case 64:
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceYearly").css("display", "");
                            break;
                        default:
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "");
                            break;
                    }
                }

            },
            isActiveRecurrenceEnabled: function () {
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return false;
                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck != undefined) {
                    athoc.iws.scenario.schedule.IsActiveRecurrence = athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck();
                    return athoc.iws.scenario.schedule.IsActiveRecurrence;
                }
                else
                    return false;
            },
            isTUnMSDevicesReady: function () {
                var bTU = false;
                var bTUEmpty = false;
                var bMD = athoc.iws.publishing.massdevices.isReadyToPublish;
                var bFinalResult = false;

                //Empty status
                bTUEmpty = (!athoc.iws.publishing.targetUsers.isInErrorState && !athoc.iws.publishing.targetUsers.isReadyToPublish);
                //TU Ready to publish or Empty status
                if (!athoc.iws.publishing.targetUsers.isInErrorState && athoc.iws.publishing.targetUsers.isReadyToPublish)
                    bTU = true;

                //TU Ready to publish or Empty status  and MD are ready                
                if ((bTU && bMD) || (bTU && !bMD) || (bTUEmpty && bMD))
                    bFinalResult = true;


                return bFinalResult;
            },
            handleError: function (e) {
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },

        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.detail.js
/// <reference path="athoc.iws.alert.placeholder.js" />
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.detail = function () {
        return {
            parameters: null,
            entityId: 0,
            context: null,
            alertOrgin: null,
            rbtCriteria: null,
            targetByUserArea: false,
            isQueryLoaded: false,
            isIUTLoaded: false,
            isTreeLoaded: false,
            rbt: null,
            init: function (args) {
                this.parameters = args;
                athoc.iws.publishing.content.init();
            },
            //model to hold publishing model for alert/scenario
            //structure is same as AtHoc.IWS.Web.Models.Publishing.PublishingModel C# class
            viewModel: {},
            isEverythingLoaded: function () {
                return ((!athoc.iws.publishing.settings.IsAdvancedQuerySuuported || this.isQueryLoaded)
                    && (!athoc.iws.publishing.settings.IsIndividualUserTargetingSupported || this.isIUTLoaded)
                    && (this.isTreeLoaded));
                //|| (athoc.iws.publishing.rbt != undefined);
            },
            resetLoadedStatus: function () {
                this.isQueryLoaded = false;
                this.isIUTLoaded = false;
                this.isTreeLoaded = false;
            },
            //load publishing model for alert/scenario
            loadPublishingModel: function (loadUrl, isEdit,id,loadTargetUsers) {
                this.resetLoadedStatus();
                if (athoc.iws.scenario != undefined) {
                    athoc.iws.scenario.breadcrumbModel.updateTitle('', undefined, undefined, 'scenarioDetail');
                }
                if (athoc.iws.alert != undefined) {
                    athoc.iws.alert.breadcrumbModel.updateTitle('', undefined, undefined, 'alertDetail');
                }
                athoc.iws.publishing.detail.setChanged(false);

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlSuccess = function (data) {
                    $(".publishing-detail").show();

                    if (data.Success) {
                        athoc.iws.publishing.detail.bindModel(data, isEdit);
                        if (typeof loadTargetUsers != "undefined" && loadTargetUsers) {
                            athoc.iws.publishing.targetUsers.setPresetDeviceOptions(data.Data.PresetDeviceGroupOptions);                            
                        }
                        //target users should be loaded after the binding the viewmodel that is the reason it was moved to here, it must happen only in case of rbt, in other cases it will proceed as usual.
                        if ((athoc.iws.alert && athoc.iws.alert.action && athoc.iws.alert.action == 'rbt')||(typeof loadTargetUsers != "undefined" && loadTargetUsers))
                             athoc.iws.publishing.targetUsers.load(id);
                    } else {
                        $.AjaxLoader.hideLoader();
                        $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    }
                    $("#alertListBreadcrumbs .title-crumb:last").addClass("ellipsis width80");
                };

                var dlAjaxOption =
                {
                    type: "POST",
                    url: loadUrl,
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, dlSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },

            //bind publishing model to ui with knockout
            bindModel: function (data, isEdit) {
                athoc.iws.publishing.detail.bindFingerTabs();

                athoc.iws.publishing.detail.viewModel = data.Data;

                $.AjaxLoader.hideLoader();

                //remove old validation
                $(".warning").each(function () { $(this).parent().remove(); });

                athoc.iws.publishing.rbt = data.Data.rbt;
                athoc.iws.publishing.detail.bindReadonlyView(data.Data);
              
                athoc.iws.publishing.context = data.Data.Context;
                athoc.iws.publishing.contextName = data.Data.ContextName;
                athoc.iws.publishing.entityId = data.Data.EntityId;
               
                athoc.iws.publishing.targetByUserArea = data.Data.TargetUsers.TargetUsersByArea;

                //if scenario bind this section, Context 1 is for scenario
                if (data.Data.Context == 1) {
                    athoc.iws.publishing.scenario.bind(data.Data.ScenarioSection);
                    // to bind scenario settings 
                    athoc.iws.scenario.settings.bind(data.Data.ScenarioSettings);

                    
                    athoc.iws.publishing.content.bind(data.Data.Content, data.Data.Context);
                    athoc.iws.publishing.targetUsers.bind(data.Data.TargetUsers, data.Data.PresetDeviceGroupOptions);
                    athoc.iws.publishing.iut.bind(data.Data.TargetUsers.TargetedBlockedUsers);
                    //
                   // athoc.iws.publishing.targetOrg.load(data.Data.TargetOrg);
                    // to bind mass devices settings
                    athoc.iws.publishing.massdevices.bind(data.Data.MassDevices, data.Data.Context, data.Data.ScenarioSettings.Delivery.Readonly, data.Data.PresetDeviceGroupOptions);
                    // to bind scenario schedule settings 
                    athoc.iws.scenario.schedule.bind(data.Data.ScenarioScheduleSettings);  
                    
                } else {

                    //apply scenario settings on alert 
                    athoc.iws.scenario.settings.applySettingsOnAlert(data.Data.ScenarioSettings, data.Data);
                    //bind test alert device list with addresses
                    athoc.iws.alert.test.bind(data.Data.TestDeviceList);
                    // apply place holder settings
                    athoc.iws.alert.placeholder.bind(data.Data.CustomPlaceHolders);
                    athoc.iws.publishing.alertOrgin = data.Data.AlertOrigin;
                    // to bind  alert schedule settings
                    athoc.iws.alert.schedule.bind(data.Data.ScenarioSettings, data.Data.AlertScheduleSettings); 
                }
                // Commented: Redundant call.
                athoc.iws.publishing.targetOrg.load(data.Data.TargetOrg);

                //if scenario
                if (data.Data.Context == 1) {
                    athoc.iws.scenario.breadcrumbModel.updateTitle(data.Data.ScenarioSection.Name, undefined, undefined, 'scenarioDetail');

                    $("#scenario-name").focus();

                    //show info section
                    if (isEdit) {
                        $("#scenarioCreatedBy").text(data.Data.ScenarioInfo.CreatedBy).attr("title", data.Data.ScenarioInfo.CreatedBy);
                        $("#scenarioCreatedOn").text(data.Data.ScenarioInfo.CreatedOn).attr("title", data.Data.ScenarioInfo.CreatedOn);
                        $("#scenarioUpdatedBy").text(data.Data.ScenarioInfo.UpdatedBy).attr("title", data.Data.ScenarioInfo.UpdatedBy);
                        $("#scenarioUpdatedOn").text(data.Data.ScenarioInfo.UpdatedOn).attr("title", data.Data.ScenarioInfo.UpdatedOn);
                        $("#scenarioCommonName").text(data.Data.ScenarioSection.CommonName).attr("title", data.Data.ScenarioSection.CommonName);
                        $("#templateId").text(data.Data.EntityId).attr("title", data.Data.EntityId);
                        $("#scenarioInfoSection").show();
                    }
                } else {
                    // in case of alert
                    if ((athoc.iws.publishing.settings.IsTestAlertSupported) && (data.Data.AlertStatus.toUpperCase() != "LIVE" || data.Data.AlertStatus.toUpperCase() != "ENDED") && data.Data.IsTestAlertSupportOperator) {
                        $("#btn_test_alert").show();
                    } else {
                        $("#btn_test_alert").hide();
                    }
                    //IWS-14925 - show save button after loading
                    if ((data.Data.AlertStatus.toUpperCase() != "LIVE" || data.Data.AlertStatus.toUpperCase() != "ENDED") && !$("#btn_detail_standby").is(":visible")) {
                        $("#btn_detail_save").show();
                    }
                    
                    if (athoc.iws.alert.action == 'create') {
                        var titlePrefix = '';
                        $(".severity-list").find("button").focus();
                        if (athoc.iws.alert.id == 0) {
                            if (athoc.iws.alert.source != "event") {
                                titlePrefix = "<span class='title-crumb'>"+athoc.iws.publishing.resources.Publishing_NewAlert+"</span><span class='normal-narrow mar-left5 mar-right5'>"+athoc.iws.publishing.resources.Publishing_BasedOn+"</span>";
                                athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.ScenarioSection.Name, undefined, undefined, 'alertCreate', titlePrefix);
                            }
                        } else {
                            titlePrefix = "<span>"+athoc.iws.publishing.resources.Publishing_PublishAlert+"</span><span class='normal-narrow mar-left5 mar-right5'>"+athoc.iws.publishing.resources.Publishing_BasedOn+"</span>";
                            athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.ScenarioSection.Name, undefined, undefined, 'alertCreate', titlePrefix);
                        }
                    }
                    if (athoc.iws.alert.action == 'rbt') {
                        var titlePrefix = '';
                        $(".severity-list").find("button").focus();
                        titlePrefix = "<span>" + athoc.iws.publishing.resources.Publishing_NewAlert + "</span><span class='normal-narrow mar-left5 mar-right5'>" + athoc.iws.publishing.resources.Publishing_BasedOn + "</span>";
                        athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.Content.Title, undefined, undefined, 'alertCreate', titlePrefix);
                    }
                    else {
                        if (athoc.iws.alert.action == 'view') {//enable end button
                            if (data.Data.AlertStatus == "Live") {
                                $("#btn_alert_end").show();
                                if(athoc.iws.publishing.settings.IsSchedulingSupported)
                                $("#btn_alert_save").show();
                            }
                        }

                        $(".severity-list").find("button").focus();
                        setTimeout(function () { $(".severity-list").find("button").focus(); }, 50);
                        athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.Content.Title, undefined, undefined, 'alertDetail');
                    }
                }

                //commented to avoid multiple times collapse and expand when click
                // if($._data($("html").find('.section-title, .expand-arrow-open, .expand-arrow-closed')[0], "events")== undefined)
                //    athoc.iws.publishing.detail.bindBucketExpandCollapse($("html"));

                // apply finger tab settings on on Scenario and Alert
                athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(data.Data.ScenarioSettings.Targeting.EnabledTargetingTypes);
                athoc.iws.scenario.settings.ApplyOrgsettingsOnFingerTabs(data.Data.ScenarioSettings.Organization);
                if (data.Data.Context == 1) {
                    athoc.iws.publishing.detail.bindBucketExpandCollapse($("html"));
                    // toggle schedule section 
                    athoc.iws.scenario.schedule.toggleScheduleSection();
                    // apply content settings such as dropbox , Location, response option  on Scenario
                    athoc.iws.scenario.settings.applyScenarioContentSettings(data.Data.ScenarioSettings.Content);
                } else {
                    // apply content settings such as dropbox , Location, response option  on Alert
                    athoc.iws.scenario.settings.applyAlertContentSettings(data.Data.ScenarioSettings.Content);

                    athoc.iws.scenario.settings.applyCollapseSettingsOnAlert();

                }
                
                athoc.iws.scenario.settings.isFillCountEnabled = data.Data.ScenarioSettings.Targeting.FillCount;
                //for Scenario always readonly=false
                //fill count summary can be readonly=true only when readonly is set scenario settings  and section is ready  
                athoc.iws.publishing.fillcount.bind(data.Data, data.Data.Context == 1 ? false: (data.Data.ScenarioSettings.Targeting.Readonly==true && athoc.iws.publishing.targetUsers.isReadyToPublish==true));

                //after loading the data reset the changed flag to not changed
                athoc.iws.publishing.detail.setChanged(false);
                $(document).scrollTop(0);
                //if the content panel is collapse initially, map doesn't have a chance to adjust ot the size of the container
                //only needs to do it once
                //for editing mode content
                var contentDom = $('#publishing-content-edit');
                var contentExpandHeaderDom = $('#bucketTitle', contentDom);
                var expandArrow = $('.expand-arrow-closed', contentExpandHeaderDom);
                if (expandArrow.css('display') == 'block') {
                    contentExpandHeaderDom.on('click', function () {
                        if (!athoc.iws.publishing.geo.miniMap && athoc.iws.publishing.geo.geoJson) {
                            require(["widget/Map"], function (WidgetMap) {
                                athoc.iws.publishing.geo.miniMap = new WidgetMap("miniMapHolder", {i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                                athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                            });
                        }
                        /*
                        if (!athoc.iws.publishing.geo.miniMapResized) {
                            setTimeout(function () {
                                athoc.iws.publishing.geo.miniMapResized = true;
                                athoc.iws.publishing.geo.miniMap.resize();
                                athoc.iws.publishing.geo.miniMap.zoomToFit();
                            }, 500);
                        }*/
                    });
                }
                //for readonly content
                var readOnlyContentDom = $('#publishing-content-detail');
                var readOnlyContentExpandHeaderDom = $('#bucketTitle', readOnlyContentDom);
                var readOnlyExpandArrow = $('.expand-arrow-closed', readOnlyContentExpandHeaderDom);
                if (readOnlyExpandArrow.css('display') == 'block') {
                    readOnlyContentExpandHeaderDom.on('click', function () {
                        if (!athoc.iws.publishing.view.readOnlyMap && athoc.iws.publishing.view.geoJson) {
                            require(["widget/Map"], function (WidgetMap) {
                                var reviewMapHolder = readOnlyContentDom.find(".readOnlyMiniMapHolder");
                                athoc.iws.publishing.view.readOnlyMap = new WidgetMap(reviewMapHolder, { i18n: athoc.iws.publishing.mapResources,zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                                athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMap, athoc.iws.publishing.view.geoJson);
                            });
                        }
                        /*
                        if (!athoc.iws.publishing.view.readOnlyMapResized) {
                            setTimeout(function () {
                                athoc.iws.publishing.view.readOnlyMapResized = true;
                                if (athoc.iws.publishing.view.readOnlyMap) {
                                    athoc.iws.publishing.view.readOnlyMap.resize();
                                    athoc.iws.publishing.view.readOnlyMap.zoomToFit();
                                }
                                if (athoc.iws.publishing.view.readOnlyMapInRP) {
                                    athoc.iws.publishing.view.readOnlyMapInRP.resize();
                                    athoc.iws.publishing.view.readOnlyMapInRP.zoomToFit();
                                }
                            }, 500);
                        }*/
                    });
                }
            },

            //bind readonly view
            bindReadonlyView: function (data) {
                if ($("#alertView").length > 0) {
                    if (athoc.iws.publishing.view) {
                        athoc.iws.publishing.view.bind(data, $("#alertView"));
                    }
                }
            },

            //has any section got changed
            isChanged: function () {
                var changed = athoc.iws.publishing.content.isChanged || athoc.iws.publishing.scenario.isChanged || athoc.iws.publishing.massdevices.isChanged || athoc.iws.publishing.fillcount.isChanged;
                return changed;
            },

            //is ready to publish
            isReadyToPublish: function () {
                var isReady = false;
                //if alert is ready and either or targeting ready and no errors
                if (athoc.iws.publishing.contextName == "Scenario" ||  athoc.iws.publishing.contextName == "AccountTemplate")
                    isReady = athoc.iws.publishing.content.isReadyToPublish() &&
                       (athoc.iws.publishing.targetUsers.isReadyToPublish || athoc.iws.publishing.targetOrg.isReadyToPublish || athoc.iws.publishing.massdevices.isReadyToPublish) &&
                       (!athoc.iws.publishing.targetUsers.isInErrorState) && (!athoc.iws.publishing.massdevices.isInErrorState) && (!athoc.iws.scenario.schedule.isInErrorState);
                else
                    isReady = athoc.iws.publishing.content.isReadyToPublish() &&
                    (athoc.iws.publishing.targetUsers.isReadyToPublish || athoc.iws.publishing.targetOrg.isReadyToPublish || athoc.iws.publishing.massdevices.isReadyToPublish) &&
                    (!athoc.iws.publishing.targetUsers.isInErrorState) && (!athoc.iws.publishing.massdevices.isInErrorState) && (!athoc.iws.alert.schedule.isInErrorState)
                    && ((athoc.iws.alert.placeholder.placeholderModel && athoc.iws.alert.placeholder.placeholderModel.length > 0 ) ? athoc.iws.alert.placeholder.isValid() : true);

                return isReady;
            },

            //change status
            checkStatusChange: function (enablePublishReview) {
                if (athoc.iws.publishing.detail.isChanged()) {
                    $('#messagePanel').messagesPanel('reset');
                }
                //iws12104
                if (athoc.iws.publishing.detail.viewModel.AlertStatus != undefined && athoc.iws.publishing.detail.viewModel.AlertStatus == "Scheduled" && athoc.iws.publishing.entityId > 0)
                {
                    $("#btn_review_and_publish").hide();
                    if ($("#btn_detail_save").is(":visible")) {
                        $("#btn_detail_save").removeClass('btn-info');
                        $("#btn_detail_save").addClass('btn-primary');
                    }
                    else
                        if ($("#btn_detail_standby").is(":visible")) {
                            $("#btn_detail_save").removeClass('btn-info');
                            $("#btn_detail_standby").addClass('btn-primary');
                        }
                }
                else
                {
                    //IWS12606
                        if (athoc.iws.publishing.detail.viewModel.AlertStatus && athoc.iws.publishing.detail.viewModel.AlertStatus != "Live" && (enablePublishReview != undefined || enablePublishReview == false) )
                          $("#btn_review_and_publish").show();

                    if ($("#btn_detail_save").is(":visible")) {
                        $("#btn_detail_save").removeClass('btn-primary');
                        $("#btn_detail_save").addClass('btn-info'); // IWS12553
                    }
                    else
                        if ($("#btn_detail_standby").is(":visible"))
                            $("#btn_detail_standby").removeClass('btn-primary');
                }

                if ($("#btn_review_and_publish").is(":visible"))
                {
                    var reviewIcon = $("#btn_review_and_publish").find(".ready-indicator");

                    if (athoc.iws.publishing.detail.isReadyToPublish()) {
                        reviewIcon.removeClass('not-ready');
                        reviewIcon.addClass('ready');
                        $("#btn_review_and_publish_tooltip").hide();
                    } else
                    {
                        reviewIcon.removeClass('ready');
                        reviewIcon.addClass('not-ready');

                        var position = reviewIcon.offset();
                        var tooltip = $("#btn_review_and_publish_tooltip");
                        tooltip.css({ top: '30px', right: '5px', 'z-index': '0' });

                        if (!tooltip.parent().hasClass('header-bar')) {
                            tooltip.appendTo(".header-bar");
                        }

                        if ($("#btn_review_and_publish").is(":enabled"))
                            tooltip.show();
                        else {
                            //reviewIcon.removeClass('ready');
                            //reviewIcon.removeClass('not-ready');
                            tooltip.hide();
                        }
                    }
                }
                if (athoc.iws.publishing.detail.viewModel.Context == 1) {
                    athoc.iws.scenario.schedule.isActiveRecurrence(athoc.iws.publishing.detail.isReadyToPublish(), false,athoc.iws.publishing.detail.isChanged());
                }
            },

            //set changed
            setChanged: function (val) {
                athoc.iws.publishing.content.isChanged = val;
                athoc.iws.publishing.scenario.isChanged = val;
                athoc.iws.publishing.massdevices.isChanged = val;
                athoc.iws.publishing.fillcount.isChanged = val;
            },

            //bind bucket section header for collape/expand
            bindBucketExpandCollapse: function (targetDiv) {
                //bind the toggle event
                //iws-12353
                //added condition for basic vps bind the sections toggle event
                if (targetDiv.selector == "#dialogReviewAndPublish" || !athoc.iws.publishing.settings.IsSchedulingSupported) {
                    //bind bucket toggle 
                    targetDiv.find('.section-title, .expand-arrow-open, .expand-arrow-closed').unbind("click");
                    targetDiv.find('#bucketTitle').unbind("click");

                    targetDiv.find('.section-title, .expand-arrow-open, .expand-arrow-closed').click(function () {
                        $(this).parent().parent().find('.row').slideToggle(500);
                        $(this).parent().parent().find('.expand-arrow-open:not(.advanced-arrow-open)').toggle();
                        $(this).parent().parent().find('.expand-arrow-closed:not(.advanced-arrow-closed)').toggle();
                    });
                }
                ////show bucket expanded by default
                targetDiv.find(".bucket-toggle .row").show();
                targetDiv.find(".bucket-toggle .expand-arrow-open").show();
                targetDiv.find(".bucket-toggle .expand-arrow-closed").hide();

            },

            //bind finger tab
            bindFingerTabs: function () {
                /*START finger tabs*/
                $('.finger-tab.by-groups').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-groups').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentGroups').show();
                });
                $('.finger-tab.by-users').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-users').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentUsers').show();
                });
                $('.finger-tab.by-query').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-query').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentQuery').show();
                });
                $('.finger-tab.by-area').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-area').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentArea').show();
                });
                $('.finger-tab.personal-devices').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.personal-devices').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentDevices').show();
                });
                $('.finger-tab.org-by-name').click(function () {
                    $('.finger-tab.org-by-area').removeClass('selected');
                    $('.finger-tab.org-by-name').addClass('selected');
                    $('#targetOrgByArea').hide();
                    $('#targetOrgByName').show();
                });
                $('.finger-tab.org-by-area').click(function () {
                    $('.finger-tab.org-by-name').removeClass('selected');
                    $('.finger-tab.org-by-area').addClass('selected');
                    $('#targetOrgByName').hide();
                    $('#targetOrgByArea').show();
                });
                /*END finger tabs*/
            },

        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.scenario.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.scenario = function() {
        return {
            viewModel: {
                data: ko.observable(),
                status: ko.observable('ready'),
                statusTooltip: ko.observable(athoc.iws.publishing.resources.Publishing_Section_Ready_Tooltip),
                Channels: ko.observable([]),
            },

            setChannels: function(channels) {
                var list = [];
                if (channels) {
                    $.each(channels, function (index, value) {
                        if (value.Id && value.Id > 0) {
                            list.push(value);
                        }
                    });
                }
                athoc.iws.publishing.scenario.viewModel.Channels(list);
            },

            //is model changed
            isChanged: false,

            //is ready for publish
            isReadyToPublish: function() {
                return (this.viewModel.status() == 'ready');
            },

            //this method will be called when new data will be available for this section for binding
            bind: function (data) {
                var model = athoc.iws.publishing.scenario.viewModel;
                var current = athoc.iws.publishing.scenario;

                $("#scenarioDetailsDiv").find(".bootstrap-select").remove();
                if ($("#channelList").length > 0) {
                    $("#channelList").html('');
                }

                model.data = ko.mapping.fromJS(data, athoc.iws.publishing.scenario.getValidation());
                

                //Binding
                if ($("#publishing-scenario-edit").length > 0) {
                    ko.cleanNode($("#publishing-scenario-edit").get(0));
                    ko.applyBindings(model, $("#publishing-scenario-edit").get(0));
                }
                

                if ($("#channelList").length > 0) {
                    $("#channelList").val(data.ChannelId).change();
                }

                //Change events binding
                current.isChanged = false;

                model.data.Name.subscribe(function(newValue) {
                    current.dataChanged();

                    var name = newValue;
                    if (name == "") {
                        name = "Untitled";
                    }

                    athoc.iws.scenario.breadcrumbModel.updateTitle(name, undefined, undefined, 'scenarioDetail');
                });
                model.data.CommonName.subscribe(function (newValue) { current.dataChanged(); });
                model.data.AvailableForQuickPublish.subscribe(function (newValue) { current.dataChanged(); });
                model.data.Description.subscribe(function (newValue) { current.dataChanged(); });

                current.checkReadyNotReady();

            },

            //this method will be called when data is required for updating
            getModel: function () {
                return ko.mapping.toJS(athoc.iws.publishing.scenario.viewModel.data);
            },

            //setup validation
            getValidation: function () {
                var validationMapping = {
                    Name: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {
                                    params: true,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_ScenarioName
                                },
                                maxLength: {
                                    params: 200,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_ScenarioName
                                } 
                            });
                        }
                    },
                    Description: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    params: 200,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_Description
                                }
                            });
                        }
                    },
                    CommonName: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    params: 200,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_CommonName
                                }
                            });
                        }
                    },
                };

                return validationMapping;
            },

            //is model valid
            isValid: function () {
                var result = ko.validation.group(athoc.iws.publishing.scenario.viewModel.data, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages(true);
                    $.AjaxLoader.hideLoader();
                    return false;
                }
                return true;
            },

            //triggered on data changed
            dataChanged: function () {
                var current = athoc.iws.publishing.scenario;
                current.isChanged = true;
                current.checkReadyNotReady();
            },

            //set ready not-ready
            checkReadyNotReady: function() {
                var current = athoc.iws.publishing.scenario;
                if (current.isValid()) {
                    current.viewModel.status('ready');
                    current.viewModel.statusTooltip(athoc.iws.scenario.resources.Publishing_Section_Ready_Tooltip);
                } else {
                    current.viewModel.status('not-ready');
                    current.viewModel.statusTooltip(athoc.iws.scenario.resources.Publishing_Section_NotReady_Tooltip);
                }
                athoc.iws.publishing.detail.checkStatusChange();
            },
        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.content.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) { 
    athoc.iws.publishing.content = function () {
        return {
            viewModel: {
                data: ko.observable(),
                ResponseName: ko.observable(''), // to display selected response in the readonly view.
                status: ko.observable('ready'),
                statusTooltip: ko.observable(athoc.iws.publishing.resources.Publishing_Section_Ready_Tooltip),
                titleLength: ko.observable(0),
                bodyLength: ko.observable(0),
                severityVisible: ko.observable(true),
                typeVisible: ko.observable(true),
                context: 0,
                responseChange: function (index, data) {
                    var isValid = false;
                    var chngText = "";
                    athoc.iws.publishing.content.dataChanged();
                    var options = athoc.iws.publishing.content.viewModel.data.ResponseOptions;
                    for (var i = 0; i < options().length; i++) {
                        isValid = options()[i].ResponseText.isValid();
                        if (i == index) chngText = options()[i].ResponseText();
                    }
                    if (isValid)
                        athoc.iws.publishing.fillcount.responseChange(index, chngText);

                    return isValid; 
                },

                bindContent: function (SeverityId, TypeId, ResponseOptionId) {
                    $("#publishing-content-edit").find("#severityList").val(SeverityId).change();
                    $("#publishing-content-edit").find("#typeList").val(TypeId).change();
                    $("#publishing-content-edit").find("#responseList").val(ResponseOptionId).change();
                },

                selectLanguage: function (data, event) {
                    var position = $(".btn-lang").offset();
                    var selLanguage = $("#lang-dropdown");
                    var correction = 0;


                    var top = 148;
                    if(athoc.iws.publishing.contextName == "AccountEvent")
                        top = 185;
                    else if (athoc.iws.publishing.contextName == "AccountTemplate")
                        top = 350;

                    var topPosition = position.top - (($("#CustomPlaceHolderDetails:visible").length > 0 ? $("#CustomPlaceHolderDetails").height() : 0) + top);

                    if ($("#messagePanel:visible").length > 0 && $("#messagePanel").height() > 20) {
                        correction += $("#messagePanel").height() + 20;
                        topPosition = topPosition - correction;
                    }

                    //if scenario
                    if (athoc.iws.publishing.content.viewModel.context == 1) {
                        correction += 125;
                        if ($("#publishing-scenario-edit").length > 0) {
                            var scenarioSection = $("#publishing-scenario-edit");
                            correction += scenarioSection.height();
                        }
                        topPosition = position.top - correction;
                    }

                    selLanguage.css({ top: topPosition + 'px', right: '-70px' });
                    selLanguage.toggle();
                    event.stopPropagation();
                },

                changeLanguage: function (data, event) {
                    var lang = $(event.target).attr('data-settings-value');
                    athoc.iws.publishing.content.viewModel.data.Local(lang);
                    var selLanguage = $("#lang-dropdown");
                    selLanguage.hide();
                },

                localDisplay: ko.observable('EN (US)'),
                localDisplayTooltip: ko.observable('English (United States)'),

                gotoTargetUrl: function (data, event) {
                    var url = athoc.iws.publishing.content.viewModel.data.TargetUrl;
                    if (!url.isValid() || url().trim().length == 0) {
                        return;
                    }

                    window.open(athoc.iws.publishing.content.viewModel.data.TargetUrl(), '_blank');
                },

                triggerClick: function (data, event) {
                    var keyCode = event.which || event.keyCode;
                    if (keyCode == 13) {
                        $(event.target).trigger("click");
                    }
                },

                addResponseOption: function () {
                    var model = athoc.iws.publishing.content.viewModel;
                    model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                },

                removeResponseOption: function (index) {
                    if (!athoc.iws.scenario.settings.isFillCountEnabled)
                        athoc.iws.publishing.content.viewModel.deleteResponseOption(index);
                    else if (athoc.iws.scenario.settings.isFillCountEnabled && athoc.iws.publishing.fillcount.setFillCountOnResponseDelete(index))
                        athoc.iws.publishing.content.viewModel.deleteResponseOption(index);
                },

                deleteResponseOption: function (index) {
                    var model = athoc.iws.publishing.content.viewModel;
                    model.data.ResponseOptions.splice(index, 1);
                    if (model.data.ResponseOptionId() == 0 && model.data.ResponseOptions().length == 0) {
                        model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                    }
                },

                //geo location
                isGeoSelected: ko.observable(false),

                geoImageUrl: ko.observable(''),

                addLocation: function () {
                    athoc.iws.publishing.geo.add();
                },

                editLocation: function () {
                    athoc.iws.publishing.geo.edit();
                },

                removeLocation: function () {
                    athoc.iws.publishing.geo.remove();
                },

                //Publishing event as alert
                inboxEvent: null,
            },
            responseOptionPreviousId: -1,
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },

            lengthValidation: function (str, minChar, maxChar) {
                if (str.length < minChar[1] || str.length > minChar[2]) {
                    return false;
                }
                return true;
            },

            //Readonly view model
            ReadonlyViewModel:
                        {
                            data: ko.observable(),
                            alertTitle: ko.observable(''),
                            bodyWithLineBreak: ko.observable(''),
                            isGeoSelected: ko.observable(false),
                        },
            //is model changed
            isChanged: false,

            phBody: null,

            init: function () {
                if (athoc.iws.publishing.settings.IsPlaceholderSupported) {
                    //var list = context == 0 ? athoc.iws.publishing.placeHolderItems.filter(function (i) { return i.IsSystem; }) : athoc.iws.publishing.placeHolderItems;
                    require(["publishing/Placeholder/Placeholder"], function (Placeholder) {
                        var txt = $("#content-title")[0];
                        var options = { textField: txt, items: athoc.iws.publishing.placeHolderItems }
                        var ph = new Placeholder(options, $("#divTitlePlaceholder", txt.parentNode)[0]);
                        ph.startup();
                    });

                    require(["publishing/Placeholder/Placeholder"], function (Placeholder) {
                        var txt = $("#content-body")[0];
                        var options = { textField: txt, items: athoc.iws.publishing.placeHolderItems }
                        athoc.iws.publishing.content.phBody = new Placeholder(options, $("#divBodyPlaceholder", txt.parentNode)[0]);
                        athoc.iws.publishing.content.phBody.startup();
                    });
                    ko.bindingHandlers.addPlaceHolder = {
                        init: function (element) {
                            require(["publishing/Placeholder/Placeholder"], function (Placeholder) {
                                var txt = element;
                                var options = { textField: txt, items: athoc.iws.publishing.placeHolderItems, isStatic: true }
                                var ph = new Placeholder(options, $(".roPh", txt.parentNode)[0]);
                                ph.startup();
                            });
                        },
                        update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                            if (bindingContext.$parent.data.ResponseOptionId() > 0) {
                                $(element).nextAll("span:first").hide();
                            }
                            else
                                $(element).nextAll("span:first").show();
                        }
                    };
                }
            },

            //set the tooltip position for title and body input fields.
            _setTooltipPosition: function (inputField) {
                var position = $(inputField).offset();
                var tooltipId = inputField + "-tooltip-template";
                var tooltip = $(tooltipId);
                var tooltipHieght = 160;
                var noOfExtraLine = (tooltip.height() - 44) / 15;
                tooltipHieght = tooltipHieght + (15 * noOfExtraLine);
                var pa = athoc.iws.publishing.contextName == "AccountTemplate" || athoc.iws.publishing.contextName == "AccountEvent";
                if (pa || (navigator.userAgent.toLowerCase().indexOf("MSIE 9.0".toLowerCase()) > -1 && $("#scenarioDetailsDiv [id='publishing-scenario-edit']").length > 0)) {
                    var diff = athoc.iws.publishing.contextName == "AccountTemplate" ? 25 : 45;
                    tooltip.css({ top: position.top - diff - tooltipHieght + 'px', right: '230px' });
                } else {
                    tooltip.css({ top: position.top - tooltipHieght + 'px', right: '230px' });
                }
                setTimeout(function () { tooltip.show(); }, 50);

            },

            //this method will be called when new data will be available for this section for binding
            bind: function (data, context) {

                //IF alert is created from event - Forward Alert
                if (athoc.iws.publishing.content.viewModel.inboxEvent != null && athoc.iws.publishing.content.viewModel.inboxEvent.IsEvent) {
                    var event = athoc.iws.publishing.content.viewModel.inboxEvent;
                    //Decode Inbox Title and Body -
                    data.Title = $.htmlDecode(event.Title);
                    data.Body = $.htmlDecode(event.Body);
                    var targetUrl = '';

                    if (event.Link && event.Link != "null") {
                        targetUrl = event.Link;
                    }
                    data.TargetUrl = targetUrl;
                    data.TypeId = event.TypeId;
                    data.SeverityId = event.SeverityId;
                    data.Type = event.Type;
                    data.Severity = event.Severity;


                    //data.SeverityName = event.SeverityName;

                    if (event.Location == "{}")
                        data.LocationGeo = null;
                    else
                        data.LocationGeo = event.Location;
                }

                var current = athoc.iws.publishing.content;

                if ($("#dbChooser").length > 0) {
                    current.createDropBoxButton(data.TargetUrl);
                }

                current.viewModel.data = ko.mapping.fromJS(data, athoc.iws.publishing.content.getValidation());
                current.viewModel.context = context;
                var model = athoc.iws.publishing.content.viewModel.data;
                current.updateLocal();

                //Rebind response options so validation kicks-off
                current.viewModel.data.ResponseOptions.removeAll();
                $.each(data.ResponseOptions, function (index, value) {
                    current.viewModel.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: value.ResponseText, CallBridgeNumber: $.htmlDecode(value.CallBridgeNumber), ShowCallBridge: $.htmlDecode(value.ShowCallBridge), PassCode: $.htmlDecode(value.PassCode), ConferenceUrl: value.ConferenceUrl }));
                });

                //remove previous dropdown

                $("#publishing-content-edit").find(".lang-list").html("");
                $("#publishing-content-edit").find(".response-list").html("");
                $("#publishing-content-edit").find(".severity-list").html("");
                $("#publishing-content-edit").find(".content-type").html("");


                /*save typeid,severityid and responseoption before ko.applybindings as 
                that is causing to reset the bindings 
                TODO:research why comboxbox bindings with ko is not working
                */
                var typeid = athoc.iws.publishing.content.viewModel.data.TypeId();
                var severityid = athoc.iws.publishing.content.viewModel.data.SeverityId();
                var responseOption = athoc.iws.publishing.content.viewModel.data.ResponseOptionId();

                if (athoc.iws.publishing.contextName == "AccountEvent" && athoc.iws.publishing.detail.viewModel) {
                    current.viewModel.severityVisible(athoc.iws.publishing.detail.viewModel.ScenarioSettings.AccountabilityWorkflow.IsContentSeverityVisible
                    );
                    current.viewModel.typeVisible(athoc.iws.publishing.detail.viewModel.ScenarioSettings.AccountabilityWorkflow.IsContentTypeVisible
                    );
                }

                //Binding
                ko.cleanNode($("#publishing-content-edit").get(0));
                ko.applyBindings(athoc.iws.publishing.content.viewModel, $("#publishing-content-edit").get(0));

                athoc.iws.publishing.content.viewModel.bindContent(severityid, typeid, responseOption);

                //for some reason bootstrap creates another control
                $("#publishing-content-edit").find(".bootstrap-select.response-list").eq(1).remove();
                $("#publishing-content-edit").find(".bootstrap-select.severity-list").eq(1).remove();
                $("#publishing-content-edit").find(".bootstrap-select.content-type").eq(1).remove();


                if (athoc.iws.publishing.contextName == "AccountEvent") {
                    $('#responseList').attr('disabled', true);
                    $('#responseList').selectpicker('refresh');
                }

                if (model.Title() == null) {
                    athoc.iws.publishing.content.viewModel.titleLength(0);
                } else {
                    //athoc.iws.publishing.content.viewModel.titleLength(athoc.iws.publishing.content.getCharCount(model.Title()));
                    athoc.iws.publishing.content.viewModel.titleLength(model.Title().length);
                }

                if (model.Body() == null) {
                    athoc.iws.publishing.content.viewModel.bodyLength(0);
                } else {
                    athoc.iws.publishing.content.viewModel.bodyLength(model.Body().length);
                }

                $("#content-title").focus(function () {
                    athoc.iws.publishing.content._setTooltipPosition("#content-title");
                });

                $("#content-body").focus(function () {
                    athoc.iws.publishing.content._setTooltipPosition("#content-body");
                });

                $(document).click(function () {
                    var selLanguage = $(".lang-filter");
                    selLanguage.hide();
                });

                $("#lang-dropdown").click(function (e) { e.stopPropagation(); });

                $("#content-title").on('change keyup paste', function () {
                    var vm = athoc.iws.publishing.content.viewModel;
                    vm.titleLength($(this).val().length);
                });

                //IE-10 Clear event
                $("#content-title").on("mouseup", function (e) {
                    var $input = $(this),
                        oldValue = $input.val();

                    if (oldValue == "") return;

                    setTimeout(function () {
                        var newValue = $input.val();

                        if (newValue == "") {
                            var vm = athoc.iws.publishing.content.viewModel;
                            vm.titleLength(0);
                        }
                    }, 1);
                });

                $("#content-body").on('change keyup paste', function () {
                    var vm = athoc.iws.publishing.content.viewModel;
                    vm.bodyLength($(this).val().length);
                });

                //IE-10 Clear event
                $("#content-body").on("mouseup", function (e) {
                    var $input = $(this),
                        oldValue = $input.val();

                    if (oldValue == "") return;

                    setTimeout(function () {
                        var newValue = $input.val();

                        if (newValue == "") {
                            var vm = athoc.iws.publishing.content.viewModel;
                            vm.bodyLength(0);
                        }
                    }, 1);
                });

                $("#content-title").focusout(function () {
                    var tooltip = $("#content-title-tooltip-template");
                    var position = $("#content-title").offset();
                    tooltip.css({ top: position.top - 200 + 'px', right: '230px' });
                    tooltip.hide();
                });

                $("#content-body").focusout(function () {
                    var tooltip = $("#content-body-tooltip-template");
                    tooltip.hide();
                });

                //Change events binding
                current.isChanged = false;

                model.Title.subscribe(function (newValue) {
                    current.dataChanged();
                    if (athoc.iws.alert != undefined) {
                        if (newValue == undefined || newValue.trim() == '') {
                            athoc.iws.alert.breadcrumbModel.updateTitle("Untitled", undefined, undefined, 'alertDetail');
                        } else {
                            athoc.iws.alert.breadcrumbModel.updateTitle(newValue, undefined, undefined, 'alertDetail');
                        }
                    }
                });
                model.Body.subscribe(function (newValue) { current.dataChanged(); });
                model.TargetUrl.subscribe(function (newValue) {

                    athoc.iws.publishing.content.createDropBoxButton(newValue);

                    current.dataChanged();

                    var prefix = 'http://';
                    var httpsPrefix = "https://";

                    newValue = newValue.trim();
                    model.TargetUrl(newValue);
                    var url = newValue.toLowerCase().trim();
                    if (url.length == 0 || url.substr(0, httpsPrefix.length).toLowerCase() == httpsPrefix)
                        return;

                    if (url.substr(0, prefix.length) !== prefix) {
                        newValue = prefix + newValue.trim();
                        model.TargetUrl(newValue);
                    } else if (newValue.indexOf(' ') >= 0) {
                        model.TargetUrl(newValue.trim());
                    }

                });
                model.Local.subscribe(function (newValue) {
                    current.dataChanged();
                    current.updateLocal();
                    athoc.iws.publishing.personalDeviceOptions.changeBasedOnLocale(newValue);
                });
                model.SeverityId.subscribe(function (newValue) {
                    current.dataChanged();
                    athoc.iws.publishing.personalDeviceOptions.changeBasedOnSeverity(newValue);
                });
                model.getSeverityNanmeFromId = function (severityId) {
                    var severityName = "";

                    var severities = athoc.iws.publishing.content.viewModel.data.Severities();

                    var found = $.grep(severities, function (severity) {
                        return severity.Id() == severityId;
                    });
                    if (found.length > 0)
                        severityName = found[0].Name();

                    return severityName;
                };
                model.SeverityName = ko.computed(function () {
                    var severityId = athoc.iws.publishing.content.viewModel.data.SeverityId();
                    return athoc.iws.publishing.content.viewModel.data.getSeverityNanmeFromId(severityId);
                    /*var severityName = "";

                    var severityId = athoc.iws.publishing.content.viewModel.data.SeverityId();
                    var severities = athoc.iws.publishing.content.viewModel.data.Severities();

                    var found = $.grep(severities, function (severity) {
                        return severity.Id() == severityId;
                    });
                    if (found.length > 0)
                        severityName = found[0].Name();

                    return severityName;
                    */
                });
                model.TypeId.subscribe(function (newValue) {

                    var found = _.find(model.Types(), function (item) {
                        return (item.Id() == newValue);
                    });

                    if (found) {
                        model.CategoryType = found;
                    }

                });
                model.TypeName = ko.computed(function () {
                    var typeId = athoc.iws.publishing.content.viewModel.data.TypeId();
                    var types = athoc.iws.publishing.content.viewModel.data.Types();
                    try {
                        var typeName = $.grep(types, function (type) {
                            return type.Id() == typeId;
                        })[0].Name();
                        return typeName;

                    } catch (e) {
                        return "";
                    }

                });

                model.ResponseOptionId.subscribe(function (previousValue) {
                    if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1) {
                        athoc.iws.publishing.content.responseOptionPreviousId = previousValue;
                        athoc.iws.publishing.fillcount.reponseTypeChange();
                    }

                }, this, "beforeChange");

                model.ResponseOptionId.subscribe(function (previousValue) {
                    if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() == -1) {
                        current.responseOptionChanged();
                    }
                });

                if (model.ResponseOptionId() == 0 && model.ResponseOptions().length == 0) {
                    model.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                }
                model.ResponseOptions.subscribe(function (newValue) { current.dataChanged(); });

                //bind geo location
                athoc.iws.publishing.geo.bind(model.LocationGeo(), athoc.iws.publishing.targetByUserArea, true);

                current.checkReadyNotReady();

                if (athoc.iws.publishing.content.phBody)
                    athoc.iws.publishing.content.phBody.adjustButton();

                if (model.Languages().length == 1) {
                    $(".btn-lang").attr("disabled", "disabled");
                }

                $("#publishing-content-edit").find(".content-type button").focus();

            },

            createDropBoxButton: function (url) {
                var options = {
                    success: function (files) {
                        athoc.iws.publishing.content.viewModel.data.TargetUrl(files[0].link);
                    }
                };
                try { // If dropbox not selected for current VPS then it'll skip
                    var button = Dropbox.createChooseButton(options);
                    $("#dbChooser").empty().append(button);


                    if ($("#dbChooser").find('.dropbox-dropin-btn').length > 0)
                        $("#dbChooser").find('.dropbox-dropin-btn')[0].innerHTML = '<span class="dropin-btn-status"></span>' + athoc.iws.publishing.resources.Publishing_Content_ChooseFromDropbox;


                }
                catch (e) { }
            },

            //this method will be called when data is required for updating
            getModel: function () {
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Readonly)
                    return ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content)

                //Load geo json as string for geo targeting
				// todo: this check is for PA case where we load only preview mode, and have no LocationGeo
				// todo: review with Nishith
                if(athoc.iws.publishing.content.viewModel.data.LocationGeo) {
                    athoc.iws.publishing.content.viewModel.data.LocationGeo(athoc.iws.publishing.geo.getModel());
                    return ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data);    
                }                
            },


            //setup validation
            getValidation: function () {
                var validationMapping = {
                    Title: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {
                                    params: true,
                                    message: athoc.iws.publishing.resources.Publishing_Validation_Title
                                },
                                validation: {
                                    validator: athoc.iws.publishing.content.lengthValidation,
                                    message: athoc.iws.publishing.resources.Publishing_Validation_Title,
                                    params: [this.value, 3, 100]
                                }
                            });
                        }
                    },
                    Body: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                validation: {
                                    validator: athoc.iws.publishing.content.lengthValidation,
                                    message: athoc.iws.publishing.resources.Publishing_Validation_Body,
                                    params: [this.value, 0, 2000]
                                }
                            });
                        }
                    },
                    //ResponseOptionId: {
                    //    create: function (options) {
                    //        return ko.observable(options.data).extend({
                    //            required: {
                    //                params: true,
                    //            }
                    //        });
                    //    }
                    //},
                    //TargetUrl: {
                    //    create: function (options) {
                    //        return ko.observable(options.data).extend({
                    //            validation: {
                    //                message: athoc.iws.publishing.resources.Publishing_Validation_TargetUrl,
                    //                validator: function (val) {
                    //                    if (val == undefined || val == '')
                    //                        return true;

                    //                    var isValid = true;
                    //                    var urlRegex = /(^|\s)((https?:\/\/)?[\w-]+(\.[\w-]+)+\.?(:\d+)?(\/^\S*)?)/i;
                    //                    var noSpaceRegex = /^[\S]*$/;
                    //                    isValid = val.match(urlRegex) && val.match(noSpaceRegex);
                    //                    return isValid;
                    //                },
                    //                params: [self],

                    //            },
                    //        });
                    //    }
                    //},
                    ResponseOptions: {
                        create: function (options) {
                            return new athoc.iws.publishing.content.ResponseOptionItem(options.data);
                        }
                    }
                };

                return validationMapping;
            },

            ResponseOptionItem: function (data) {
                var self = this;
                ko.mapping.fromJS(data, {}, self);
                self.ResponseText.extend({
                    maxLength: {
                        params: 64,
                        message: athoc.iws.publishing.resources.Publishing_Validation_ResponseOption
                    },
                    validation: {
                        validator: athoc.iws.publishing.content.DuplicateResponseOptionValidation,
                        message: athoc.iws.publishing.resources.Publishing_DuplicateResponseOption_ValidationMessage,
                        params: [athoc.iws.publishing.content.viewModel.data.ResponseOptions, self, 'ResponseText']
                    }
                });

                //self.CallBridgeNumber.extend({
                //    maxLength: {
                //        params: 64,
                //        message: athoc.iws.publishing.resources.Publishing_Validation_ResponseOption
                //    },
                //    //validation: {
                //    //    validator: athoc.iws.publishing.content.DuplicateResponseOptionValidation,
                //    //    message: athoc.iws.publishing.resources.Publishing_DuplicateResponseOption_ValidationMessage,
                //    //    params: [athoc.iws.publishing.content.viewModel.data.ResponseOptions, self, 'ResponseText']
                //    //}
                //});
            },

            DuplicateResponseOptionValidation: function (val, params) {

                var options = athoc.iws.publishing.content.viewModel.data.ResponseOptions;

                if (val == undefined || val == '' || options == undefined)
                    return true;

                //issue with grep switching to old way of looping
                //var numOccurences = $.grep(options(), function (elem) { return elem.Name() == val; }).length;

                var numOccurences = 0;
                for (var i = 0; i < options().length; i++) {
                    if (options()[i].ResponseText() == val)
                        numOccurences++;
                }

                return (numOccurences <= 1);

                //var isValid = true;
                //var responseOptions = athoc.iws.publishing.content.viewModel.data.ResponseOptions;
                //console.log(params);
                //console.log(responseOptions);

                //if (val == undefined || val == '' || responseOptions == undefined || responseOptions.length == 0)
                //    return isValid;

                //ko.utils.arrayFirst(params[0](), function (item) {
                //    if (val === item[params[2]]() && item !== params[1]) {
                //        isValid = false;
                //        return true;
                //    }
                //});
                //return isValid;
            },

            isLocationMandatory: function (forReadyStatus) {
                if (forReadyStatus) {
                    //TODO: Use following after implementing setting form PA
                    //if (athoc.iws.publishing.contextName == "Scenario" || athoc.iws.publishing.contextName == "AccountTemplate") {
                    if (athoc.iws.publishing.contextName == "Scenario") {
                        if (athoc.iws.scenario.settings.viewModel.scenariosettings.Content.LocationMandatoryEnabled
                            && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                            $('#location-mandatory').css("display", "");
                            return false;
                        }
                    }

                    //TODO: Use following after implementing setting form PA
                    //if (athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "AccountEvent") {
                    if (athoc.iws.publishing.contextName == "Alert" ) {
                        if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled
                            && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                            $('#location-mandatory').css("display", "");

                            return false;
                        }
                    }
                }
                else
                    //TODO: Use following after PA setting
                    //if (athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "AccountEvent") {
                    if (athoc.iws.publishing.contextName == "Alert") {
                            if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled
                            && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                            $('#location-mandatory').css("display", "");

                            return false;
                        }
                    }
                //TODO: Use following after PA setting
                //if (athoc.iws.publishing.contextName == "Scenario" || athoc.iws.publishing.contextName == "AccountTemplate") {
                if (athoc.iws.publishing.contextName == "Scenario") {
                    if (athoc.iws.scenario.settings.viewModel.scenariosettings.Content.LocationMandatoryEnabled
                            && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                            $('#location-mandatory').css("display", "");
                            return false;
                        }
                    }
                $('#location-mandatory').css("display", "none");
                return true;
            },

            //is model valid
            isValid: function () {
                var result = ko.validation.group(athoc.iws.publishing.content.viewModel.data, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages(true);
                    $.AjaxLoader.hideLoader();
                    return false;
                }

                return true;
            },

            //is ready for publish
            isReadyToPublish: function () {
                return (this.viewModel.status() == 'ready');
            },


            //triggered on data changed
            dataChanged: function () {
                var current = athoc.iws.publishing.content;
                current.isChanged = true;
                current.checkReadyNotReady();
            },

            //set ready not-ready
            checkReadyNotReady: function () {
                var current = athoc.iws.publishing.content;
                if (current.isValid() && current.isLocationMandatory(true)) {
                    current.viewModel.status('ready');
                    current.viewModel.statusTooltip(athoc.iws.publishing.resources.Publishing_Section_Ready_Tooltip);
                } else {
                    current.viewModel.status('not-ready');
                    current.viewModel.statusTooltip(athoc.iws.publishing.resources.Publishing_Section_NotReady_Tooltip);
                }
                current.onReadyChange(current.viewModel.status() == 'ready' ? true : false);

                if (athoc.iws.publishing.contextName == "Alert" && athoc.iws.alert.test)
                    athoc.iws.alert.test.enableTestAlertButton(athoc.iws.publishing.content.isReadyToPublish());

                athoc.iws.publishing.detail.checkStatusChange();
            },

            //on response option change
            responseOptionChanged: function () {
                var current = athoc.iws.publishing.content;
                current.dataChanged();

                var model = current.viewModel;
                model.data.ResponseOptions.removeAll();

                var option = $.grep(model.data.ResponseOptionList(), function (e) { return e.Id() == model.data.ResponseOptionId(); });
                if (option.length == 1) {

                    $.each(option[0].Values(), function (index, value) {
                        model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: value, CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                    });
                }

                if (model.data.ResponseOptionId() == 0 && model.data.ResponseOptions().length == 0) {
                    model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                }
            },

            //update local
            updateLocal: function () {
                var displayVal = '';
                var model = ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data);
                for (var index = 0; index < model.Languages.length; index++) {
                    if (model.Languages[index].Code === athoc.iws.publishing.content.viewModel.data.Local()) {
                        displayVal = model.Languages[index].Name;
                        break;
                    };
                };
                athoc.iws.publishing.content.viewModel.localDisplay(displayVal);
                athoc.iws.publishing.content.viewModel.localDisplayTooltip(displayVal);

                //athoc.iws.publishing.content.updateLanguageTooltip();
                //if (displayVal == 'en-US') {
                //    displayVal = "EN (US)";
                //} else if (displayVal == 'ar-SA') {
                //    displayVal = "AR (SA)";
                //} else if (displayVal == 'fr-FR') {
                //    displayVal = "FR (FR)";
                //} else if (displayVal == 'ja-JP') {
                //    displayVal = "JA (JP)";
                //}

            },

            updateLanguageTooltip: function () {
                var displayVal = athoc.iws.publishing.content.viewModel.data.Local();
                if (displayVal == 'en-US') {
                    displayVal = "English (United States)";
                } else if (displayVal == 'ar-SA') {
                    displayVal = "Arabic (Saudi Arabia)";
                } else if (displayVal == 'fr-FR') {
                    displayVal = "French (France)";
                } else if (displayVal == 'ja-JP') {
                    displayVal = "Japanese (Japan)";
                }
                athoc.iws.publishing.content.viewModel.localDisplayTooltip(displayVal);
            },
            applyReadonlySettingsOnContent: function (data, targetDiv) {
                //var targetDiv = $("#alert-content-detail");
                if (data.Content != undefined && data.Content.ResponseOptions != undefined && data.Content.ResponseOptions.length > 0) {
                    var reponseOptions = [];
                    for (var i = 0; i < data.Content.ResponseOptions.length; i++) {
                        if (data.Content.ResponseOptions[i].ResponseText.trim() !== '') {
                            reponseOptions.push(data.Content.ResponseOptions[i]);
                        }
                    }
                    data.Content.ResponseOptions = reponseOptions;
                    var responseOptions = $.grep(data.Content.ResponseOptionList, function (e) { return e.Id == data.Content.ResponseOptionId; });
                    if (responseOptions && responseOptions.ResponseText)
                        athoc.iws.publishing.content.viewModel.ResponseName = responseOptions.ResponseText;
                }

                athoc.iws.publishing.content.ReadonlyViewModel.data = ko.mapping.fromJS(data);
                //adding linebreak for alert body
                try {
                    if (data.Content != undefined && data.Content.Body != undefined && data.Content.Body != null) {
                        athoc.iws.publishing.content.ReadonlyViewModel.bodyWithLineBreak($.htmlEncode(data.Content.Body.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />'));
                    } else {
                        athoc.iws.publishing.content.ReadonlyViewModel.bodyWithLineBreak('');
                    }
                    athoc.iws.publishing.content.ReadonlyViewModel.alertTitle(data.Content.Title);
                }
                catch (e) { }
                //ko.cleanNode(targetDiv.get(0));
                // if (data.Content.LocationGeo != "" && data.Content.LocationGeo != undefined)
                //  athoc.iws.publishing.geo.readOnlyBind(data.Content.LocationGeo, true, true);

                //TODO: Readonly view of alert
                //ko.cleanNode(targetDiv.find(".content-section").get(0));
                //ko.applyBindings(athoc.iws.publishing.content.ReadonlyViewModel, targetDiv.find(".content-section").get(0));


            },

            onReadyChange: function (isReady) { },
        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.iut.js
/* define javascript namespace for IUT = Individual User Targeting */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};
if (athoc.iws.publishing) {
    athoc.iws.publishing.iut = function () {
        //
        var extraSpaceAddBlock = 55;
        var userCountType = 0;
        var operatorRoleColumn = "OPERATOR-ROLES";
        return {
            viewModel: {
                targetedBlockerUsersList: ko.observableArray(),
                targetedBlockerUsers: ko.observableArray(),
                allAvailableUser: ko.observableArray(),
                status: ko.observable('ready'),
                targetedCnt: ko.observable(0),
                blockedCnt: ko.observable(0),
            },

            readOnlyInputParameters:
                {
                    sessionId: ko.observable(0),
                    covered: ko.observable(0),
                    attributeCSV: ko.observable(""),
                    totalCount: ko.observable(0),
                },
            //is model changed
            isChanged: false,
            IsRefered: false,
            rowsObject: [],
            reportCols: [],
            readOnlyDatasource: null,
            readOnlyDatasourcetemp: null,
            columnDefs: null,
            gridColumnDefs: null,
            allUsersgrid: null,
            allUserDatasource: null,
            userInfo: null,
            allUserSortColumn: 'DisplayName',
            allUserSortOrder: 'asc',
            allUserSortField: '_DISPLAYNAME',
            readOnlySortColumn: '',
            readOnlySortOrder: '',
            readOnlySortField: '_LOGIN_ID',
            allUsersPageSize: 50,
            targetBlockSort: 'asc',
            targetBlockPageSize: 50,
            searchString: [],
            newlyaddedColumns: [],
            errors: null,
            firstTimeOpenAddUser: 0,
            firstTimeReachableUser: 0,
            //this method will be called when new data will be available for this section for binding

            bind: function (data) {
                if (athoc.iws.publishing && athoc.iws.publishing.iut && athoc.iws.publishing.iut.newlyaddedColumns != null)
                    athoc.iws.publishing.iut.newlyaddedColumns.length = 0;

                //try to bind only if IUT is enabled (affiliate/non-affiliate)
                if ($("#targetBlockingList").length == 0)
                    return;
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(data);
                // dataobject for maniplication
                athoc.iws.publishing.iut.createTargettingUserListGrid(data);

                $('#targetBlockingList .k-grid-header').hide();
                $('#targetBlockingList .k-pager-wrap').hide();
            },

            load: function () {

              
                    require(["widget/UserInfo"], function(UserInfo) {
                        athoc.iws.publishing.iut.userInfo = new UserInfo("alertinguserInfoHolder", "#userInfoModalBody");
                        athoc.iws.publishing.iut.userInfo.startup();
                    });
                
                ko.cleanNode($("#AddBlockUsers").get(0));
                ko.applyBindings(athoc.iws.publishing.iut.viewModel, $("#AddBlockUsers").get(0));


                $("#ddlAlertHr").selectpicker();
                $("#ddlAlertMin").selectpicker();
                $("#ddlAlertMer").selectpicker();
                $("#ddlAlertDurationHours").selectpicker();


                // to remove the column from the available users list
                /*$('#allUserList').on('click', '.remove-column', function (event) {
                    event.preventDefault();
                    athoc.iws.publishing.iut.updateGridColumn(this.parentNode.getAttribute("viewid"), this.parentNode.getAttribute("Id"),
                       "remove",
                       this.parentNode.getAttribute("customviewcolumntype"),
                       this.parentNode.getAttribute("key"),
                       function () {
                           //$.AjaxLoader.hideLoader();
                       });
                });*/
                //
                $("#txtReadOnlySearch").keyup(function (e) {
                    $("#btn_readonlyusersearch").removeAttr('disabled');
                    if ($.hotkeys.enter(e)) {
                        $('#pillContainer').show();
                        athoc.iws.publishing.iut.createReadOnlyUserList();
                    }

                });
                //
                $("#btn_readonlyusersearch").click(function () {
                    $('#pillContainer').show();
                    athoc.iws.publishing.iut.createReadOnlyUserList();
                });
                //
                $("#txtAllUserSearch").keyup(function (e) {

                    var seaString = $.trim($('#txtAllUserSearch').val());
                    if ($.hotkeys.enter(e) && seaString != "") {
                        $('#pillContainer').show();
                        athoc.iws.publishing.iut.createPills(seaString, "SIMPLESEARCH", $('#txtAllUserSearch').val());
                        //athoc.iws.publishing.iut.createAddBlockUsersGrid();
                        $('#txtAllUserSearch').val('');
                    }
                    if (seaString.length > 0) {
                        $("#btn_userSearch").removeAttr('disabled');
                    }
                });
                $("#btn_readonlyclearall").click(function () {
                    $("#txtReadOnlySearch").val("");
                    $('#pillContainer').hide();
                    athoc.iws.publishing.iut.createReadOnlyUserList();
                    $("#btn_readonlyusersearch").attr('disabled', true);
                    athoc.iws.publishing.iut.hideAddColumns();
                });
                //
                $("#btn_userSearch").click(function () {
                    if ($.trim($('#txtAllUserSearch').val()).length > 0) {
                        athoc.iws.publishing.iut.createPills($('#txtAllUserSearch').val(), "SIMPLESEARCH", $('#txtAllUserSearch').val());
                        $('#pillContainer').show();
                    }
                });
                //                
                $("#clearAllBtn").click(function () {
                    athoc.iws.publishing.iut.clearAllTargetedBlockedUsersPopUp();
                    $('#pillContainer').hide();
                });

                $("#btn_Apply").click(function () {
                    athoc.iws.publishing.iut.applyChangesToList();
                });

                $("body").click(function () {
                    athoc.iws.publishing.iut.hideAddColumns();
                    $("#contextDropdown").hide();

                });
            },
            userListRemoveColumn: function (event) {
                event.preventDefault();
                athoc.iws.publishing.iut.updateGridColumn(event.currentTarget.parentNode.getAttribute("viewid"), event.currentTarget.parentNode.getAttribute("Id"),
                   "remove",
                   event.currentTarget.parentNode.getAttribute("customviewcolumntype"),
                   event.currentTarget.parentNode.getAttribute("key"),
                   function () {
                       //$.AjaxLoader.hideLoader();
                   });
            },
            // to remove the column from the read only  userlist
            readonlyUserlistRemoveColumn: function (event) {
                event.preventDefault();
                //this.parentNode.parentNode.getAttribute("viewid")
                name = event.target.getAttribute("Key");
                var cList = ko.mapping.toJS(athoc.iws.publishing.iut.newlyaddedColumns).filter(function (i) {
                    return i.Key != name;
                })
                athoc.iws.publishing.iut.newlyaddedColumns = cList;
                if (athoc.iws.publishing.iut.readOnlySortColumn == name) {
                    athoc.iws.publishing.iut.readOnlySortColumn = "USERNAME";
                    athoc.iws.publishing.iut.readOnlySortOrder = "ASC";
                }
                athoc.iws.publishing.iut.createReadOnlyUserList();

                //athoc.iws.publishing.iut.updateReportViewColumn(this.parentNode.getAttribute("viewid"), this.parentNode.getAttribute("id"),
                //   "remove",
                //   "",
                //    "",
                //   function () {
                //       //$.AjaxLoader.hideLoader();
                //   });
            },

            //
            createTargettingUserListGrid: function (data) {
                var tbData = [];
                tbData = new kendo.data.DataSource({
                    data: data,
                });

                //datasource.read();
                var grid = $("#targetBlockingList").kendoGrid({
                    dataSource: tbData,
                    selectable: false,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [

                                 {
                                     field: "",
                                     title: "",
                                     template: $("#targeting-imgtargeting-template").html(),
                                     headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "Users", ""),
                                     width: 10,
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                                {
                                    field: "Name",
                                    title: "",
                                    template: $("#targeting-name-template").html(),
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "Name", ""),
                                    width: 130,
                                    headerAttributes: {
                                        tabindex: "3"
                                    }
                                },
                                {
                                    field: "",
                                    title: "",
                                    template: $("#targeting-imgremove-template").html(),
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', "", ""),
                                    width: 10,
                                    headerAttributes: {
                                        tabindex: "5"
                                    }
                                },
                            ],
                    dataBound: athoc.iws.publishing.iut.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                        this.select().removeClass("k-state-selected");

                    }
                }).data().kendoGrid;

                grid.dataSource.pageSize(grid.dataSource.total());
                athoc.iws.publishing.iut.updateChangesToSummaryAndChart();
                $("#TargetedUsers").html(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers().length);
            },

            //
            UserToolTip: function (model) {

                $.ajax({
                    url: athoc.iws.publishing.urls.GetUserDetailsUrl,
                    type: 'POST',

                    data: {
                        Id: model.UserId
                    },
                    cache: false,
                    async: true,
                    success: function (result) {
                        athoc.iws.publishing.iut.IsRefered = false;
                        result = result.replace(" alt='Close'", " alt='Close' style='display:none' ");

                        // $("#userInfoModal").html(result);
                        var tooltip = $("#readonlyUserList").kendoTooltip({
                            filter: "closeImg",
                            autoHide: false,
                            content: result,
                            position: "right",

                        }).data("kendoTooltip").show($("#readonlyUserList"));

                    },
                });
            },

            //
            removeUserId: function (userId) {
                var raw = $("#targetBlockingList").data("kendoGrid").dataSource.data();
                var length = raw.length;

                var item, i;
                for (i = length - 1; i >= 0; i--) {
                    if (raw[i].UserId == userId) {
                        item = raw[i];
                        $("#targetBlockingList").data("kendoGrid").dataSource.remove(item);
                        break;
                    }

                }
                if (item != undefined) {
                    $("#targetBlockingList").data("kendoGrid").refresh();
                }
                athoc.iws.publishing.iut.updateChangesToSummaryAndChart();
                var current = athoc.iws.publishing.content;
                current.isChanged = true;
                athoc.iws.publishing.targetUsers.targetingChanged();
            },

            OnBoundEmptyRow: function (data) {
                var colCount = $("#targetBlockingList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#targetBlockingList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:left;height:10px;overflow:auto; cursor:default; background-color:#fff">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "", athoc.iws.publishing.iut.resources.IUTTargeted_Blocked_Emptyrow_Message) +
                            '</td></tr>');
                }
            },

            //
            OnBoundReadonlyEmptyRow: function (data) {
                var colCount = $("#readonlyUserList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#readonlyUserList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:10px;overflow:auto;">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', athoc.iws.publishing.iut.resources.IUTReadOnly_Emptyrow_Message, athoc.iws.publishing.iut.resources.IUTReadOnly_Emptyrow_Message) +
                            '</td></tr>');
                }
            },

            //
            OnDataBound: function () {
                var grid = $("#targetBlockingList").data("kendoGrid");

                var grid = $("#targetBlockingList").data("kendoGrid");
                var data = $("#targetBlockingList").data("kendoGrid").dataSource.view();
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(data);
                athoc.iws.publishing.iut.OnBoundEmptyRow(data);


            },

            //
            refreshGrid: function () {
                grid.setDataSource(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers());
                grid.dataSource.pageSize(grid.dataSource.total());

            },

            //this method will be called when data is required for updating
            getModel: function () {
                if ($("#targetBlockingList").data("kendoGrid") != undefined) {
                    return ko.mapping.toJS($("#targetBlockingList").data("kendoGrid").dataSource.view());
                } else {
                    return null;
                }
            },

            //indicates if the section is ready or not
            isReady: function () {
                //if at least one user is targed then this should be true
                return false;
            },

            //triggered on data changed
            dataChanged: function () {
                var current = athoc.iws.publishing.content;
                current.isChanged = true;
                current.checkReadyNotReady();
            },

            //
            createReadOnlyUserList: function () {
                var self = this;
                var searchString = "";
                var rowsObject = [];
                var attributeIds = "";
                var dIds = "";
                var displayIds = "";
                var cNames = "";

                if ($("#txtReadOnlySearch").val() != "") {
                    searchString = $("#txtReadOnlySearch").val();
                    var rGrid = $("#readonlyUserList").data("kendoGrid");
                    if (rGrid != null && rGrid.columns.length > 0) {
                        _.each(rGrid.columns, function (col, index) {
                            if (col.headerAttributes != null && (col.headerAttributes.key == "LOGIN_ID" || col.headerAttributes.key == "FIRSTNAME" || col.headerAttributes.key == "LASTNAME" || col.headerAttributes.key == "DISPLAYNAME") && col.headerAttributes.id > 0)
                                attributeIds = attributeIds + col.headerAttributes.id + ",";
                        });
                    }
                }

                _.each(athoc.iws.publishing.iut.newlyaddedColumns, function (item, index) {
                    if (item.CustomViewColumnType.toUpperCase() == "DEVICE") {
                        displayIds = displayIds + item.Id + ",";
                        //dNames = dNames + item.Key + ",";
                    }
                    else if (item.CustomViewColumnType.toUpperCase() == "CF") {
                        cNames = cNames + item.Key + ",";
                    }
                });
                cNames = cNames + athoc.iws.publishing.iut.readOnlyInputParameters.attributeCSV();
                //if (dIds == "") {

                var checkedDevices = ko.mapping.toJS(athoc.iws.publishing.targetUsers.SelectedGroupedDevices().Devices).map(function (item) { return item.DeviceId; });
                dIds = checkedDevices.join(",");


                var escalationAttributeId = 0;
                var escalationSortOrder = "";
                escalationSortOrder = athoc.iws.publishing.fillcount.getModel() != null ? athoc.iws.publishing.fillcount.getModel().OrderByAscending : "";
                escalationAttributeId = athoc.iws.publishing.fillcount.getModel() != null ? athoc.iws.publishing.fillcount.getModel().ControlledDeliveryAttributeId : 0;
                var sortBy = athoc.iws.publishing.iut.readOnlySortColumn == "" ? ((escalationAttributeId > 0) ? escalationAttributeId : "") : athoc.iws.publishing.iut.readOnlySortColumn;

                var sortOrder = athoc.iws.publishing.iut.readOnlySortOrder == "" ? (escalationAttributeId > 0 ? (escalationSortOrder ? "ASC" : "DESC") : "") : athoc.iws.publishing.iut.readOnlySortOrder;

                var inparameters = {
                    userCountType: athoc.iws.publishing.iut.readOnlyInputParameters.covered(),
                    sessionId: athoc.iws.publishing.iut.readOnlyInputParameters.sessionId(),
                    attributeCSV: cNames,
                    totalCount: athoc.iws.publishing.iut.readOnlyInputParameters.totalCount(),
                    attributeSearchValue: searchString,
                    sortBy: sortBy,
                    sortOrder: sortOrder,
                    deviceIds: dIds,
                    displayColumnDeviceIds: displayIds,
                    attributeIds: attributeIds,
                    fillCountAttributeId: escalationAttributeId
                };

                readOnlyDatasource = new kendo.data.DataSource({
                    transport:
                    {
                        read: {
                            url: athoc.iws.publishing.urls.GetAlertUserListDataUrl,
                            type: "POST",
                            dataType: "json",
                            data: inparameters,
                            traditional: true,
                        },

                    },

                    requestStart: function (e) {
                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#divReadOnlyProgress'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '150px', left: '60%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                        //$("#readonlyUserList").hide();
                        //$("#readOnlyPageInfo").hide();
                    },
                    requestEnd: function (e) {
                        $.AjaxLoader.hideLoader();
                        if (e.response) {
                            athoc.iws.publishing.iut.createReadOnlyDataSource(e.response);
                            e.response["Rows"] = rowsObject;
                            readOnlyDatasource._total = e.response.TotalCounts;
                            athoc.iws.publishing.iut.createReadOnlyGrid();

                        }

                    },

                    error: function (e) {
                        athoc.iws.publishing.iut.handleError(e);
                    },
                    schema:
                    {
                        data: "Rows",
                        total: "TotalCounts",
                    },
                    serverPaging: true,
                    serverSorting: true,
                    sort: {},
                    pageSize: 50,
                });
                readOnlyDatasource.read();

            },

            createReadOnlyGrid: function () {
                if (athoc.iws.publishing.iut.firstTimeReachableUser == 0) {
                    $("#readonlyUserList").html('');
                    $("#readonlyUserList").hide();
                    athoc.iws.publishing.iut.firstTimeReachableUser = 1;
                }


                $("#readOnlyPageInfo").kendoPager({
                    dataSource: readOnlyDatasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.publishing.iut.resources.IUTReadOnly_PageingInfo,
                        empty: athoc.iws.publishing.iut.resources.IUTReadOnly_Emptyrow_Message
                    }
                });
                $("#readonlyUserList .k-grid-header").html('');

                if (rowsObject.length == 0) {
                    rowsObject = [];
                }
                var grid = $("#readonlyUserList").kendoGrid().data("kendoGrid");
                var options = grid.options;
                grid.destroy();

                kendoGrid = $("#readonlyUserList").kendoGrid({
                    columns: columnDefs,
                    dataSource: rowsObject,
                    autoBind: true,
                    scrollable: true,
                    sortable: false,
                    pageable:
                            {
                                refresh: false,
                                pageSizes: true,
                                pageSizes: [20, 50, 100],
                                buttonCount: 5,
                                messages: {
                                    display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                                    empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                                    itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                                    first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                                    previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                                    next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                                    last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                                }
                            },
                    dataBinding: athoc.iws.publishing.iut.OnReadOnlyDataBinding,
                    dataBound: athoc.iws.publishing.iut.OnReadOnlyDataBound,
                    error: function (e) {
                        var errorCallBack = function (returnedErrorObject) {
                            $('#readonlyMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        };
                        AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);

                    },

                }).data("kendoGrid");

                setTimeout(function () {
                    athoc.iws.publishing.iut.fitHeightReadOnlyList();
                    $("#readonlyUserList").show();
                    $("#readOnlyPageInfo").show();
                    $.AjaxLoader.hideLoader();
                }, 1500);
            },

            fitHeighUserList: function () {
                var windowHeight = $("#AddBlockUsers .modal-content").height();
                if (windowHeight > 600) { // Resolution : 1920 * 1080
                    $("#tbUsersList .k-grid-content").css("height", (windowHeight * 73.2 / 100) - 12);
                }
                else if (windowHeight > 460) { // Resolution : 1280*1024
                    $("#tbUsersList .k-grid-content").css("height", (windowHeight * 73.2 / 100) + 8);
                }
                else {
                    $("#tbUsersList .k-grid-content").css("height", (windowHeight * 63 / 100) - 9);
                }
            },

            fitHeightReadOnlyList: function () {

                var windowHeight = $("#ReadOnlyUserList .modal-content:eq(1)").height() - $("#ReadOnlyUserList .content-current").height();
                if (windowHeight > 500) {
                    $("#readonlyUserList .k-grid-content").css("height", (windowHeight * 79 / 100) - 10);
                }
                else if ((windowHeight <= 500) && (windowHeight > 400)) {
                    $("#readonlyUserList .k-grid-content").css("height", (windowHeight * 79 / 100) - 15);
                }
                else {
                    $("#readonlyUserList .k-grid-content").css("height", (windowHeight * 67 / 100) - 10);
                }
            },

            fitHeightAllUsers: function () {
                var extraSpace = 0;
                if (athoc.iws.publishing.iut.searchString.length > 0)
                    extraSpace = 4;

                var windowHeight = $("#AddBlockUsers .modal-content").height() - $("#allUsersBucket .content-current").height();
                if (windowHeight >= 590) {
                    $("#allUserList .k-grid-content").css("height", (windowHeight * 73.2 / 100) - extraSpace + 22);
                }
                else if (windowHeight > 400) {
                    $("#allUserList .k-grid-content").css("height", (windowHeight * 73.2 / 100) - extraSpace + 5);
                }
                else {
                    $("#allUserList .k-grid-content").css("height", ((windowHeight * 54 / 100) + 20));
                }

                if ($("#pillContainer").children().length == 0)
                    $("#pillContainer").hide();
                else {
                    $("#pillContainer").show();
                    if (windowHeight <= 400)
                        $("#allUserList .k-grid-content").css("height", ((windowHeight * 54 / 100) - 10));
                }

                $('#allUserList').show();
            },

            fitHeightTargetedUsersSummaryList: function () {
                var windowHeight = $("#targetedUsersSummary .modal-body").height();
                if (windowHeight < 450) {
                    $("#targetedUsersList .k-grid-content").css("height", (windowHeight * 82 / 100));
                }
                else if ((windowHeight > 500) && (windowHeight < 600)) {
                    $("#targetedUsersList .k-grid-content").css("height", windowHeight - 70);
                }
                else if (windowHeight >= 600) { // resolution: 1920*1080
                    if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
                        $("#targetedUsersList .k-grid-content").css("height", windowHeight - 110);
                    }
                    else if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
                        $("#targetedUsersList .k-grid-content").css("height", windowHeight - 76);
                    }
                    else
                        $("#targetedUsersList .k-grid-content").css("height", windowHeight - 130);

                }
                else {
                    $("#targetedUsersList .k-grid-content").css("height", windowHeight - 84);

                }
            },

            fitHeightBlockedUsersSummaryList: function () {
                var windowHeight = $("#blockedUsersSummary .modal-body").height();
                if (windowHeight < 450) {
                    $("#blockedUsersList .k-grid-content").css("height", (windowHeight * 82 / 100));
                }
                else if ((windowHeight > 500) && (windowHeight < 600)) {
                    $("#blockedUsersList .k-grid-content").css("height", windowHeight - 70);
                }
                else if (windowHeight >= 600) {// resolution: 1920*1080
                    if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
                        $("#blockedUsersList .k-grid-content").css("height", windowHeight - 110);
                    }
                    else if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
                        $("#blockedUsersList .k-grid-content").css("height", windowHeight - 76);
                    }
                    else
                        $("#blockedUsersList .k-grid-content").css("height", windowHeight - 130);
                }
                else {
                    $("#blockedUsersList .k-grid-content").css("height", windowHeight - 84);

                }
            },

            createReadOnlyDataSource: function (data) {
                columnDefs = [];
                rowsObject = [];
                colObject = [];
                var colWidth = "auto";
                if (data.ReportsColumns.length > 7)
                    colWidth = "120px";
                // Add coumns to column array

                athoc.iws.publishing.iut.reportCols = [];
                var ReportLayoutColumns = data.ReportLayoutColumns;

                _.each(athoc.iws.publishing.iut.newlyaddedColumns, function (item, index) {
                    var existColCount = ko.mapping.toJS(data.ReportLayoutColumns).filter(function (DisplayName) {
                        return DisplayName == item.DisplayName;
                    }).length;

                    if (existColCount == 0)
                        ReportLayoutColumns.push(item.DisplayName);

                });

                _.each(ReportLayoutColumns, function (item, cIndex) {
                    _.find(data.ReportsColumns, function (obj) {
                        if (item == obj.DisplayName) {
                            athoc.iws.publishing.iut.reportCols.push(obj);
                        }
                    });
                });

                _.each(athoc.iws.publishing.iut.reportCols, function (item, cIndex) {
                    var columnName = item.Key;
                    var headerTemplate = "";
                    var field = '_' + columnName.replace(/[-:~!@#$%^&*(){}\[\]<>,.\s'\"?\\\/]/g, "");
                    if (item.Key.toUpperCase() != "USER_ID" || item.Key.toUpperCase() != "LOGIN_ID") {
                        var existColCount = ko.mapping.toJS(athoc.iws.publishing.iut.newlyaddedColumns).filter(function (i) {
                            return i.Key == item.Key;
                        }).length;

                        if (existColCount == 0) {
                            headerTemplate = kendo.format('<span title="' + $.htmlEncode(item.DisplayName) + '" onclick="athoc.iws.publishing.iut.readOnlyGridColumnSort(event);">' + $.htmlEncode(item.DisplayName) + '</span>');
                        }
                        else
                            headerTemplate = kendo.format('<div title="' + athoc.iws.publishing.resources.Publishing_RemoveGridColumn + ' ' + $.htmlEncode(item.DisplayName) + '" class="icon_clear remove-column"  key="' + columnName + '" onclick="athoc.iws.publishing.iut.readonlyUserlistRemoveColumn(event);"></div>' + '<span title="' + $.htmlEncode(item.DisplayName) + '" onclick="athoc.iws.publishing.iut.readOnlyGridColumnSort(event);" >' + $.htmlEncode(item.DisplayName) + '</span>');

                        if (athoc.iws.publishing.iut.readOnlySortColumn.toUpperCase() == item.Key.toUpperCase()) {
                            athoc.iws.publishing.iut.readOnlySortField = field;
                            if (athoc.iws.publishing.iut.readOnlySortOrder.toUpperCase() == "ASC") {
                                if (athoc.iws.publishing.iut.readOnlySortColumn.toUpperCase() == "ORGANIZATIONAL HIERARCHY")
                                    headerTemplate += '<span class="sort-indicator-ascending sort-indicator-margin-userlist"></span>';
                                else
                                    headerTemplate += '<span class="sort-indicator-ascending"></span>';
                            }
                            else if (athoc.iws.publishing.iut.readOnlySortOrder.toUpperCase() == "DESC") {
                                if (athoc.iws.publishing.iut.readOnlySortColumn.toUpperCase() == "ORGANIZATIONAL HIERARCHY")
                                    headerTemplate += '<span class="sort-indicator-descending sort-indicator-margin-userlist"></span>';
                                else
                                    headerTemplate += '<span class="sort-indicator-descending"></span>';
                            }
                        }

                        columnDefs.push({
                            title: columnName,
                            field: field,
                            width: colWidth,
                            headerTemplate: headerTemplate,
                            template: '<span title="#=' + field + '#">#=' + field + '#</span>',
                            headerAttributes: {
                                id: item.Id,
                                customviewcolumntype: item.CustomViewColumnType,
                                key: item.Key
                            }
                        });
                    }
                });

                rowsObject.length = 0;
                rowNumber = 0;
                rowsObject = [];
                // Prepare datasource for kendo grid
                _.each(data.ReportRows, function (row, rIndex) {
                    var colObject = new Object();
                    //colObject["Id"] = row.Id;                    
                    colObject["_LOGIN_ID"] = row.UserName;
                    _.each(data.ReportsColumns, function (column, cIndex) {
                        if (column.Key.toUpperCase() != "USER_ID") {
                            var value = $.customizedHtmlEncoding(athoc.iws.publishing.iut.getReadOnlyColumnValue(column, row));
                            //if (column.DataFormat && column.DataType && (!(column.DataType == 4 || column.DataType == 5)))
                            //    value = $.getFormattedValue(column.DataType, column.DataFormat, value);
                            colObject["_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.\s'\"?\\\/]/g, "")] = value;
                        }
                    });

                    rowsObject.push(colObject);
                })
               

                columnDefs.push({
                    title: athoc.iws.publishing.iut.resources.IUTReadOnly_Add_Reset,
                    field: "",
                    width: "80px",
                    headerTemplate: '<a href="#" class="small-msg block column-select" id="addColumn" onClick="athoc.iws.publishing.iut.addNewReportColumn(this)"  >' + athoc.iws.publishing.iut.resources.IUTReadOnly_Add + '</a><a href="#" class="small-msg block" id="reset"  onClick="athoc.iws.publishing.iut.ResetReportColumns()"  >' + athoc.iws.publishing.iut.resources.IUTReadOnly_Reset + '</a>'
                });

               
            },

            getReadOnlyColumnValue: function (column, row) {

                if (column.Key == "OPERATOR-ROLES") {
                    var roleCount = row.UserAttributes["ROLECOUNT_OTHERORGS"];
                    if (roleCount && roleCount != " ") {
                        return row.UserAttributes[column.Key] + " (" + row.UserAttributes["ROLECOUNT_OTHERORGS"] + ") ";
                    } else {
                        return row.UserAttributes[column.Key];
                    }
                }
                return row.UserAttributes[column.Key] != null
                    ? row.UserAttributes[column.Key]
                    : (row.UserDevice[column.Key] != null ? row.UserDevice[column.Key] : '');
            },

            readOnlyGridColumnSort: function (event) {
                event.preventDefault();
                event.cancelBubble = true;
                var grid = $("#readonlyUserList").data("kendoGrid");
                athoc.iws.publishing.iut.readOnlySortField = grid.columns[event.target.parentNode.cellIndex].field;
                athoc.iws.publishing.iut.readOnlySortColumn = grid.columns[event.target.parentNode.cellIndex].title; //event.target.getAttribute("title");
                if (athoc.iws.publishing.iut.readOnlySortOrder == "desc")
                    athoc.iws.publishing.iut.readOnlySortOrder = "asc";
                else
                    athoc.iws.publishing.iut.readOnlySortOrder = "desc";
                athoc.iws.publishing.iut.createReadOnlyUserList();

            },

            resizeModalBasedOnScreen: function (modal) {

                modal.find(".modal-body").css("max-height", 600);
                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 40 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 40 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 240);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }

            },

            showAddColumns: function (event) {

                var position = $("#ReadOnlyUserList .column-select").offset();

                var selColumn = $("#ReadOnlyUserList .column-filter");
                var windowHeight = $(window).height();
                if (athoc.iws.publishing.source == "p" || athoc.iws.publishing.source == "a" || athoc.iws.publishing.source == "h" || athoc.iws.publishing.source == "readonly" || (athoc.iws.alert != undefined && athoc.iws.alert.source == "publisher"))
                    selColumn.css({ top: "126px" });
                else if (athoc.iws.publishing.source == undefined)
                    selColumn.css({ top: "157px" });
                else
                    selColumn.css({ top: "142px" });

                selColumn.css({ left: "710px" });


                selColumn.show();

            },

            hideAddColumns: function (data, event) {
                var selColumn = $(".column-filter");
                selColumn.hide();
            },

            //
            ResetReportColumns: function () {
                $("#dialogResetReadonlyUsers").find(".modal-body").css("max-height", 50);
                $("#dialogResetReadonlyUsers").show();
                $("#ReadOnlyUserList").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                $("#dialogResetReadonlyUsers").on('click', '.btn-info', function (event) {
                    $("#dialogResetReadonlyUsers").hide();
                    $("#ReadOnlyUserList").find('#displayShadow').remove();
                });
            },

            ResetReadonlyGridListOk: function () {
                $("#dialogResetReadonlyUsers").hide();
                $("#ReadOnlyUserList").find('#displayShadow').remove();
                athoc.iws.publishing.iut.newlyaddedColumns.length = 0;
                athoc.iws.publishing.iut.createReadOnlyUserList();

                /*target = "_blank";
                athoc.iws.publishing.iut.hideAddColumns();
                var parameters = {
                    viewType: "UserReport",
                };
                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.ResetToReportDefaultViewUrl,
                    type: "POST",
                    dataType: "json",
                    data: parameters,
                    success: function (data) {
                        athoc.iws.publishing.iut.createReadOnlyUserList();
                        $.AjaxLoader.hideLoader();
                    }
                };
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);*/
            },

            //
            addNewReportColumn: function () {

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#ReadOnlyUserList .dropdown-div'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '150px', left: '60%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                var self = this;
                var parameters = {
                    viewType: "UserReport",
                };

                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.GetReportCustomViewUrl,
                    type: "POST",
                    dataType: "json",
                    data: parameters,
                    success: function (data) {
                        if (data && data.length > 0) {
                            $("#newColumn").html('');
                            //  self.render(true, function () {
                            var htmlAttributes = '';
                            var deviceOptions = '';
                            var operatorOptions = '';
                            var hierarchyOptions = '';
                            var hierarchyGroup = '', attributeGroup = '', deviceGroup = '', operatorAttributeGroup = '';
                            var html = "";
                            html += '<select style="width: 248px !important; margin-left: 5px !important;" name="addReportColumnDropdown" data-placeholder="" size=10>';

                            _.each(data, function (item, index) {
                                var existColCount = ko.mapping.toJS(athoc.iws.publishing.iut.reportCols).filter(function (i) {
                                    return (i.Key == item.Key);
                                }).length;

                                
                                


                                if (existColCount == 0)
                                    //athoc.iws.publishing.iut.newlyaddedColumns == "" || athoc.iws.publishing.iut.newlyaddedColumns.split(',').indexOf($.htmlEncode(item.DisplayName)) == -1) {
                                {
                                    var optionList = "<option value='" + item.Id + "' data-customviewcolumntype='" + item.CustomViewColumnType + "' data-key='" + item.Key + "'>" + $.htmlEncode(item.DisplayName) + "</option>";

                                    if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false && item.Key == operatorRoleColumn) {
                                        operatorOptions = operatorOptions + optionList;
                                    }
                                    else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false) {
                                        htmlAttributes = htmlAttributes + optionList;
                                    }
                                    else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == true) {
                                        hierarchyOptions = hierarchyOptions + optionList;
                                    }
                                    else if (item.CustomViewColumnType == "Device") {
                                        deviceOptions = deviceOptions + optionList;
                                    }
                                }
                            });

                            if (hierarchyOptions != '') {
                                hierarchyGroup = '<optgroup label="Organization Hierarchy">' + hierarchyOptions + '</optgroup>';
                            }

                            if (htmlAttributes != '')
                                attributeGroup = '<optgroup label="Attributes">' + htmlAttributes + '</optgroup>';

                            if (deviceOptions != '')
                                deviceGroup = '<optgroup label="Devices">' + deviceOptions + '</optgroup>';

                            if (operatorOptions != '')
                                operatorAttributeGroup = '<optgroup label="' + $.htmlDecode(athoc.iws.publishing.iut.resources.operatorAttributesLabel) + '">' + operatorOptions + '</optgroup>';

                            html = html + hierarchyGroup + attributeGroup + operatorAttributeGroup + deviceGroup;
                            html += '</select>';
                            //html += '</div></div>';
                            $("#newColumn").html(html);



                            var selectElm = $("select[name='addReportColumnDropdown']");


                            // selectElm.selectpicker({});

                            selectElm.change(function () {
                                var elm = $(this);
                                var displayName = "";

                                if (elm.find("option:selected").data("customviewcolumntype") == "Device")
                                    displayName = elm.find("option:selected").html().replace(/\(Device\)?$/, "").trim();
                                else
                                    displayName = elm.find("option:selected").html();

                                athoc.iws.publishing.iut.newlyaddedColumns.push({ Id: elm.val(), Key: elm.find("option:selected").data("key"), CustomViewColumnType: elm.find("option:selected").data("customviewcolumntype"), DisplayName: displayName });
                                athoc.iws.publishing.iut.createReadOnlyUserList();
                                /*athoc.iws.publishing.iut.updateReportViewColumn(0, elm.val(),
                                    "add",
                                    elm.find("option:selected").data("customviewcolumntype"),
                                    elm.find("option:selected").data("key"),elm.find("option:selected").html(),
                                    function () {
                                        // $.AjaxLoader.hideLoader();

                                        athoc.iws.publishing.iut.hideAddColumns();

                                    });*/
                            });
                            //  });

                            athoc.iws.publishing.iut.showAddColumns();

                            var existCssValue = $("#newColumn").parent().css("top");
                            existCssValue = existCssValue.replace("px", '');
                            if (parseInt(existCssValue) > 134)
                                $("#newColumn").parent().css("top", (parseInt(existCssValue) - 14) + 'px');


                            existCssValue = $("#newColumn").parent().css("left");
                            existCssValue = existCssValue.replace("px", '');
                            $("#newColumn").parent().css("left", (parseInt(existCssValue) + 4) + 'px');
                        }
                        $.AjaxLoader.hideLoader();
                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
                //}
            },

            //
            updateReportViewColumn: function (viewId, id, action, columnType, columnKey, columnName, onSuccess) {
                var self = this;
                if (viewId == "" || viewId == null || viewId == undefined)
                    viewId = 0;
                if (id) {
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#ReadOnlyUserList .dropdown-div'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '150px', left: '60%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                    if (action == "remove" && athoc.iws.publishing.iut.readOnlySortColumn == columnKey) {
                        athoc.iws.publishing.iut.readOnlySortColumn = "USERNAME";
                        athoc.iws.publishing.iut.readOnlySortOrder = "ASC";
                    }

                    var myAjaxOptions = {
                        url: athoc.iws.publishing.urls.SaveReportCustomViewUrl,
                        type: "POST",
                        dataType: "json",
                        data: { viewId: viewId, id: id, action: action, type: columnType, commonName: columnKey },
                        success: function () {
                            athoc.iws.publishing.iut.newlyaddedColumns = athoc.iws.publishing.iut.newlyaddedColumns + "," + columnName;
                            athoc.iws.publishing.iut.createReadOnlyUserList();
                            $.AjaxLoader.hideLoader();

                        },
                        error: function (e) {
                            athoc.iws.publishing.iut.handleError(e);
                        },

                    };

                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                    $.ajax(ajaxOptions);
                }
            },

            OnReadOnlyDataBound: function (e) {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
                var data = $("#readonlyUserList").data("kendoGrid").dataSource.view();
                var grid = $("#readonlyUserList").data("kendoGrid");
                grid.pager.dataSource = readOnlyDatasource;
                athoc.iws.publishing.iut.OnBoundReadonlyEmptyRow(data);
            },

            OnReadOnlyDataBinding: function () {
                var ds = $("#readonlyUserList").data("kendoGrid").dataSource;
                ds._sort = [{ field: athoc.iws.publishing.iut.readOnlySortField, dir: athoc.iws.publishing.iut.readOnlySortOrder }];
            },

            ShowUsersList: function (sessionId, covered, attributeCSV, totalCount) {
                athoc.iws.publishing.iut.readOnlyInputParameters.sessionId(sessionId);
                athoc.iws.publishing.iut.readOnlyInputParameters.covered(covered);
                athoc.iws.publishing.iut.readOnlyInputParameters.attributeCSV(attributeCSV);
                athoc.iws.publishing.iut.readOnlyInputParameters.totalCount(totalCount);
                $("#txtReadOnlySearch").val('');
                //$("#btn_readonlyusersearch").attr('disabled', true);
                $('#ReadOnlyUserList').modal('show');
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#ReadOnlyUserList'));
                athoc.iws.publishing.iut.createReadOnlyUserList();
                athoc.iws.publishing.iut.firstTimeReachableUser = 0;
            },

            //All Available users and Targeted/Blocked user PopUp

            // Get all users data and bind to kendo grid
            createAddBlockUsersGrid: function (getNextPage, onSuccess, searchParameters, page, showSpinner) {
                var self = this;
                var strSearch = [];
                var gridRowsObject = [];

                $.grep(athoc.iws.publishing.iut.searchString, function (i) {
                    strSearch.push(i.value);
                });
                if (firstTimeOpenAddUser == 0) {
                    $("#allUserList").html('');
                    $('#allUserList').hide();
                    firstTimeOpenAddUser = 1;
                }
                var parameters = {
                    searchStrings: strSearch,
                    staticQueryCriteria: '',
                    sortBy: athoc.iws.publishing.iut.allUserSortColumn,
                    sortOrder: athoc.iws.publishing.iut.allUserSortOrder,
                    pageSize: athoc.iws.publishing.iut.allUsersPageSize,
                    searchFlow: "FromUserManager",
                };
                gridColumnDefs = [];
                allUserDatasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: athoc.iws.publishing.urls.GetUserListUrl,
                            type: "POST",
                            dataType: "json",
                            data: parameters,
                            traditional: true,
                        },

                    },
                    requestStart: function (e) {
                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#divProgress'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '50%', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                        $("#divProgress .blockMsg").css("margin", "-13px");
                        $("#divProgress .blockMsg").css("left", "40px");
                    },
                    requestEnd: function (e) {

                        if (e.response != null) {
                            gridColumnDefs.length = 0;
                            // Add checkbox column to the column array
                            gridColumnDefs.push({
                                title: '',
                                field: '',
                                template: $("#userList-chkTargeted-template").html(),
                                headerTemplate: kendo.format('<input name="chbox" id="allUsersCheckAll" value="0" type="checkbox" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_SelectAll_DeSelect + '" data-type="selectAll" onclick="athoc.iws.publishing.iut.allUsersSelectAll();"/>', ""),
                                width: 34,
                            });

                            // column width based on column count
                            var colWidth = 0;
                            if (e.response.Columns.length < 7)
                                colWidth = "auto";
                            else
                                colWidth = "120px";

                            // Add secondary columns to the column array 
                            _.each(e.response.SecondaryColumns, function (column, cIndex) {
                                var headerSecTemplate = "";
                                var dtemplate = "";
                                var sfield = "_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\/]/g, "");

                                headerSecTemplate = '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '"data-key="' + column.Key + '" onclick="athoc.iws.publishing.iut.allUserGridColumnSort(\'' + sfield + '\',\'' + column.Key + '\');">' + $.htmlEncode(column.DisplayName) + '</span>';

                                if (athoc.iws.publishing.iut.allUserSortColumn.toUpperCase() == column.Key) {
                                    athoc.iws.publishing.iut.allUserSortField = sfield;
                                    if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "ASC") {
                                        headerSecTemplate += '<span class="sort-indicator-ascending"></span>';
                                    }
                                    else if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "DESC") {
                                        headerSecTemplate += '<span class="sort-indicator-descending"></span>';
                                    }
                                }

                                headerSecTemplate = kendo.format(headerSecTemplate);
                                if (gridColumnDefs.length == 1)
                                    dtemplate = $("#userList-link-template").html();
                                else
                                    dtemplate = '<span title="#=' + sfield + '#">#=' + sfield + '#</span>';

                                gridColumnDefs.push({
                                    title: column.DisplayName,
                                    field: sfield,
                                    width: colWidth,
                                    template: dtemplate,
                                    headerTemplate: headerSecTemplate,
                                    headerAttributes: {
                                        viewid: column.ViewId,
                                        id: column.Id,
                                        customviewcolumntype: "",
                                        key: column.Key
                                    }
                                });
                            });
                            // Add coumns to column array
                            _.each(e.response.Columns, function (column, cIndex) {
                                var headerTemplate = "";
                                var field = "_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\\/]/g, "");
                                if (column.IsRequired != true) {
                                    headerTemplate = '<div title="' + athoc.iws.publishing.resources.Publishing_RemoveGridColumn + ' ' +$.htmlEncode(column.DisplayName) + '" class="icon_clear remove-column" onclick="athoc.iws.publishing.iut.userListRemoveColumn(event);"></div>' +
                                        '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '" data-key="' + column.Key + '" onclick="athoc.iws.publishing.iut.allUserGridColumnSort(\'' + field + '\',\'' + column.Key + '\');">' + $.htmlEncode(column.DisplayName) + '</span>';
                                }
                                else
                                    headerTemplate = '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '"data-key="' + column.Key + '"onclick="athoc.iws.publishing.iut.allUserGridColumnSort(\'' + field + '\',\'' + column.Key + '\');" >' + $.htmlEncode(column.DisplayName) + '</span>';

                                if (athoc.iws.publishing.iut.allUserSortColumn.toUpperCase() == column.Key) {
                                    athoc.iws.publishing.iut.allUserSortField = field;
                                    if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "ASC") {
                                        headerTemplate += '<span class="sort-indicator-ascending"></span>';
                                    }
                                    else if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "DESC") {
                                        headerTemplate += '<span class="sort-indicator-descending"></span>';
                                    }
                                }
                                headerTemplate = kendo.format(headerTemplate);
                                gridColumnDefs.push({
                                    title: column.DisplayName,
                                    field: field,
                                    width: colWidth,
                                    template: '<span title="#=' + field + '#">#=' + field + '#</span>',
                                    headerTemplate: headerTemplate,
                                    headerAttributes: {
                                        viewid: column.ViewId,
                                        id: column.Id,
                                        customviewcolumntype: "",
                                        key: column.Key
                                    }
                                });
                            });

                            // Add add/reset column to column array
                            gridColumnDefs.push({
                                title: athoc.iws.publishing.iut.resources.IUTAllUsers_Add_Reset,
                                field: "",
                                width: "80px",
                                template: $("#userList-BlockUnblock-template").html(),
                                headerTemplate: '<a href="#" class="small-msg block column-select" id="addReportColumn" onClick="athoc.iws.publishing.iut.addNewGridColumn()" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_Add + '"  >' + athoc.iws.publishing.iut.resources.IUTAllUsers_Add + '</a><a href="#" class="small-msg block" id="reset"  onClick="athoc.iws.publishing.iut.ResetGridList()" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '" >' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '</a>'
                            });

                            // Prepare datasource for kendo grid
                            gridRowsObject.length = 0;
                            _.each(e.response.Rows, function (row, rIndex) {
                                var colObject = new Object();
                                colObject["Id"] = row.Id;
                                _.each(e.response.SecondaryColumns, function (column, cIndex) {
                                    var value = athoc.iws.publishing.iut.getColumnValue(column, row);
                                    colObject["_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\/]/g, "")] = $.customizedHtmlEncoding(value);
                                });

                                _.each(e.response.Columns, function (column, cIndex) {
                                    var value = athoc.iws.publishing.iut.getColumnValue(column, row);
                                    if (column.DataFormat && column.DataType && (!(column.DataType == 4 || column.DataType == 5)))
                                        value = $.getFormattedValue(column.DataType, column.DataFormat, value);
                                    colObject["_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\/]/g, "")] = $.customizedHtmlEncoding(value);
                                });
                                var tbItem = $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                                    return i.UserId == row.Id;
                                });
                                if (tbItem.length > 0 && !tbItem[0].IsBlocked)
                                    colObject["IsTargeted"] = true;
                                else
                                    colObject["IsTargeted"] = false;

                                if (tbItem.length > 0 && tbItem[0].IsBlocked)
                                    colObject["IsBlocked"] = true;
                                else
                                    colObject["IsBlocked"] = false;

                                gridRowsObject.push(colObject);
                            })
                            allUserDatasource._total = e.response.TotalCounts;
                        }
                        else {
                            gridColumnDefs.length = 0;
                            gridRowsObject.length = 0;
                            gridColumnDefs.push({
                                title: '',
                                field: '',
                                template: $("#userList-chkTargeted-template").html(),
                                headerTemplate: kendo.format('<input name="chbox" id="allUsersCheckAll" value="0" type="checkbox" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_SelectAll_DeSelect + '" data-type="selectAll" onclick="athoc.iws.publishing.iut.allUsersSelectAll();"/>', ""),
                                width: 5,
                            });
                            gridColumnDefs.push({
                                title: 'Username',
                                field: '',
                                width: 80,
                            });
                            gridColumnDefs.push({
                                title: athoc.iws.publishing.iut.resources.IUTAllUsers_Add_Reset,
                                field: "",
                                width: "10px",
                                template: $("#userList-BlockUnblock-template").html(),
                                headerTemplate: '<a href="#" class="small-msg block column-select" id="addReportColumn" onClick="athoc.iws.publishing.iut.addNewGridColumn()" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_Add + '"  >' + athoc.iws.publishing.iut.resources.IUTAllUsers_Add + '</a><a href="#" class="small-msg block" id="reset"  onClick="athoc.iws.publishing.iut.ResetGridList()" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '" >' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '</a>'
                            });
                        }
                        // Page info of kendo grid
                        $("#allUserPageInfo").kendoPager({
                            dataSource: allUserDatasource,
                            autoBind: false,
                            numeric: false,
                            previousNext: false,
                            messages: {
                                display: athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo,
                                empty: athoc.iws.publishing.iut.resources.IUTReadOnly_Emptyrow_Message
                            }
                        });
                        // Allusers kendo grid
                        $("#allUserList .k-grid-header").html('');
                        $("#allUserList").find(".bootstrap-select").remove();
                        ko.cleanNode($("#allUserList").get(0));
                        athoc.iws.publishing.iut.allUsersgrid = $("#allUserList").kendoGrid({
                            columns: gridColumnDefs,
                            dataSource: gridRowsObject,
                            selectable: false,
                            scrollable: true,
                            autoBind: true,
                            sortable: false,
                            pageable: {
                                refresh: false,
                                pageSizes: true,
                                pageSizes: [20, 50, 100],
                                buttonCount: 5,
                                messages: {
                                    display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                                    empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                                    itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                                    first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                                    previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                                    next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                                    last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                                }
                            },
                            dataBinding: athoc.iws.publishing.iut.onAllUserDataBinding,
                            dataBound: athoc.iws.publishing.iut.onAllUserDataBound,
                            change: function (e) {
                                var model = this.dataItem(this.select());
                                this.select().removeClass("k-state-selected");
                                athoc.iws.publishing.iut.userInfo.update({ userId: model.Id, userName: model._LOGIN_ID });
                                $("#userInfoModal", athoc.iws.publishing.iut.userInfo.refDomNode).modal("show");
                                // athoc.iws.publishing.iut.UserKendoToolTip(model.Id);
                            }

                        }).data().kendoGrid;

                        $("#newColumns").html('');
                        athoc.iws.publishing.iut.allUsersPageSize = athoc.iws.publishing.iut.allUsersgrid.pager.dataSource._pageSize;

                        setTimeout(function () {
                            // Fit height for the alluer grid
                            athoc.iws.publishing.iut.fitHeightAllUsers();
                            $.AjaxLoader.hideLoader();
                        }, 100);


                        if (onSuccess)
                            onSuccess();

                    },
                    schema: {
                        data: "Rows",
                        total: "TotalCounts",
                    },
                    serverPaging: true,
                    serverSorting: true,
                    serverFiltering: true,
                    sort: { field: "Username", dir: "desc" },
                    pageSize: 50,
                    error: function (e) {
                        var errorCallBack = function (returnedErrorObject) {
                            $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        };
                        AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);
                        athoc.iws.publishing.iut.handleError(e);
                    },
                    change: function (e) {
                        athoc.iws.publishing.iut.retainSelectAll();
                    }
                });
                allUserDatasource._pageSize = athoc.iws.publishing.iut.allUsersPageSize;
                allUserDatasource.read();
                return 0;
            },

            // Databound event for the allusers grid
            onAllUserDataBound: function (e) {

                var data = $("#allUserList").data("kendoGrid").dataSource.view();
                athoc.iws.publishing.iut.viewModel.allAvailableUser(data);

                var grid = $("#allUserList").data("kendoGrid");
                grid.pager.dataSource = allUserDatasource;

                if (data.length > 0)
                    $("#allUserList .k-grid-header").css("width", "98% !important");
                else
                    $("#allUserList .k-grid-header").css("width", "100% !important");
                athoc.iws.publishing.iut.OnBoundAllUsersEmptyRow(data);

            },

            // Databinding event for the allusers grid
            onAllUserDataBinding: function (e) {
                var ds = $("#allUserList").data("kendoGrid").dataSource;
                ds._sort = [{ field: athoc.iws.publishing.iut.allUserSortField, dir: athoc.iws.publishing.iut.allUserSortOrder }];
            },

            OnBoundAllUsersEmptyRow: function (data) {
                var colCount = $("#allUserList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#allUserList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:10px;overflow:auto;">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', athoc.iws.publishing.iut.resources.IUTAllUsers_Emptyrow_Message, athoc.iws.publishing.iut.resources.IUTAllUsers_Emptyrow_Message) +
                            '</td></tr>');

                }
            },

            // Get user info for the compact popup
            getUserInfo: function (obj) {

                var id = obj.getAttribute('value');
                var name = obj.getAttribute('title');
                athoc.iws.publishing.iut.userInfo.update({ userId: id, userName: name }, $('#userInfoModal').find('#showProgress'));
                $("#userInfoModal", athoc.iws.publishing.iut.userInfo.refDomNode).modal("show");
                $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                $('#userInfoModal').on('hidden.bs.modal', function () {
                    $("#AddBlockUsers").find('#displayShadow').remove();
                })
            },

            // Get user info for the compact popup
            getUserInfoforFlatList: function (obj) {
                var id = obj.getAttribute('value');
                var name = obj.getAttribute('title');
                athoc.iws.publishing.iut.userInfo.update({ userId: id, userName: name });
                $("#userInfoModal", athoc.iws.publishing.iut.userInfo.refDomNode).modal("show");

            },

            // Sorting of columns for allusers grid
            allUserGridColumnSort: function (field, key) {
                athoc.iws.publishing.iut.allUserSortField = field;
                athoc.iws.publishing.iut.allUserSortColumn = key;
                if (athoc.iws.publishing.iut.allUserSortOrder == "desc")
                    athoc.iws.publishing.iut.allUserSortOrder = "asc";
                else
                    athoc.iws.publishing.iut.allUserSortOrder = "desc";
                athoc.iws.publishing.iut.createAddBlockUsersGrid();

            },

            // Select all event for the allusers grid
            allUsersSelectAll: function () {
                var checked = $('#allUsersCheckAll').is(':checked');
                var grid = $('#allUserList').data().kendoGrid;
                $.each(grid.dataSource.view(), function (i, item) {
                    if (checked) {
                        if (!item.IsBlocked && athoc.iws.publishing.iut.viewModel.targetedCnt() < athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit) {
                            item.IsTargeted = checked;
                            athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                        }
                        else if (!item.IsBlocked) {
                            $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                            $("#lblUsersLimit").html(athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit);
                            $('#btn_limitCancel').on('click', function (event) {
                                $("#dialogUsersLimit").hide();

                                $("#AddBlockUsers").find('#displayShadow').remove();
                            });
                            $("#dialogUsersLimit").show();
                            $("#allUsersCheckAll").prop('checked', false);
                            return false;
                        }
                    }
                    else if (!item.IsBlocked && item.IsTargeted) {
                        item.IsTargeted = checked;
                        athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    }
                });
                grid.refresh();//update the grid...

            },

            // Retain check all when the paging is done
            retainSelectAll: function () {

                var grid = $('#allUserList').data().kendoGrid;
                var items = grid.dataSource.view();
                var ttlCnt = 0;
                // Get the selected items for the current page.
                $.grep(items, function (v) {
                    if (v.IsTargeted || v.IsBlocked)
                        ttlCnt++;
                });

                // Check total page count equal to selected count 
                var checked = ttlCnt > 0 && (items.length == ttlCnt);
                $("#allUsersCheckAll").prop('checked', checked);


            },

            // Createing pills when search is done
            createPills: function (value, type, display) {

                var found = _.find(athoc.iws.publishing.iut.searchString, function (item) {
                    return (item.value == value && item.type == type);
                });
                if (!found) {
                    athoc.iws.publishing.iut.searchString.push({ value: value, type: type, display: display });
                    athoc.iws.publishing.iut.renderPills();
                    athoc.iws.publishing.iut.createAddBlockUsersGrid();

                }
            },

            // Rendering the pills when search is done
            renderPills: function (css) {
                var self = this;
                var html = "";
                $("#divSearch .pill-container").html('');
                if (athoc.iws.publishing.iut.searchString && athoc.iws.publishing.iut.searchString.length > 0) {
                    _.each(athoc.iws.publishing.iut.searchString, function (item, index) {
                        var iconCss = "";
                        var prefix = "";
                        //html += '<div class="pill" data-index="' + index + '"><span class="pill-content">' + prefix + item.display + '</span><div class="pill-icon ' + iconCss + '"></div><a class="pill-close" href="javascript://"></a></div>';
                        var pillLabel = prefix + $.htmlEncode(item.display);
                        var pillTooltip = prefix + $.htmlEncode(item.display);
                        var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" href="#"></a>' : '');
                        html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                    });

                    var pillsElm = $("#divSearch .pill-container");
                    pillsElm.html(html);
                    //wire up events
                    $("#divSearch .pill-close").click(function (event) {
                        var parentElm = $(this).parent(".pill");
                        athoc.iws.publishing.iut.deSelect(parentElm.data("index"));
                        event.stopPropagation();
                    });
                }
            },

            // Deleteing the pills
            deSelect: function (index, onSuccess) {
                if (athoc.iws.publishing.iut.searchString && athoc.iws.publishing.iut.searchString.length > index) {
                    athoc.iws.publishing.iut.searchString.splice(index, 1);
                    athoc.iws.publishing.iut.renderPills();
                    athoc.iws.publishing.iut.createAddBlockUsersGrid();
                }
            },

            // For Add/Block Users reset grid 
            ResetGridList: function () {
                $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                $("#dialogResetAllUsers").show();
                $("#dialogResetAllUsers").on('click', '.btn-info', function (event) {
                    $("#dialogResetAllUsers").hide();
                    $("#AddBlockUsers").find('#displayShadow').remove();
                });
            },

            ResetGridListOk: function () {
                $("#dialogResetAllUsers").hide();
                $("#AddBlockUsers").find('#displayShadow').remove();
                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.ResetToDefaultViewUrl,
                    type: "POST",
                    dataType: "json",
                    success: function (data) {
                        athoc.iws.publishing.iut.createAddBlockUsersGrid();
                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
            },

            // common to grids
            getColumnValue: function (column, row) {
                if (column.Key == "OPERATOR-ROLES") {
                    var roleCount = row.UserAttributes["ROLECOUNT_OTHERORGS"];
                    if (roleCount && roleCount != " ") {
                        return row.UserAttributes[column.Key] + " (" + row.UserAttributes["ROLECOUNT_OTHERORGS"] + ") ";
                    } else {
                        return row.UserAttributes[column.Key];
                    }
                }
                return column.CustomViewColumnType === "CF"
                    ? row.UserAttributes[column.Key]
                    : row.UserDevice[column.Key];
            },

            // For Add/Block Users add new GridColumn to grid 
            addNewGridColumn: function () {
                var self = this;

                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.GetCustomViewsUrl,
                    type: "POST",
                    dataType: "json",
                    success: function (data) {
                        if (data && data.length > 0) {
                            $("#newColumns").html('');
                            var htmlAttributes = '';
                            var deviceOptions = '';
                            var operatorOptions = '';
                            var hierarchyOptions = '';
                            var hierarchyGroup = '', attributeGroup = '', deviceGroup = '', operatorAttributeGroup = '';
                            var html = "";
                            html += '<select  name="addColumnDropdown"  data-placeholder="" size=10  style="width:250px !important;margin-left:5px !important">';

                            _.each(data, function (item, index) {
                                var optionList = "<option value='" + item.Id + "' data-customviewcolumntype='" + item.CustomViewColumnType + "' data-key='" + item.Key + "'>" + $.htmlEncode(item.DisplayName) + "</option>";

                                if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false && item.Key == $.htmlDecode(athoc.iws.publishing.iut.resources.operatorRolesCommonName)) {
                                    operatorOptions = operatorOptions + optionList;
                                }
                                else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false) {
                                    htmlAttributes = htmlAttributes + optionList;
                                }
                                else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == true) {
                                    hierarchyOptions = hierarchyOptions + optionList;
                                }
                                else if (item.CustomViewColumnType == "Device") {
                                    deviceOptions = deviceOptions + optionList;
                                }
                            });

                            if (hierarchyOptions != '') {
                                hierarchyGroup = '<optgroup label="Organization Hierarchy">' + hierarchyOptions + '</optgroup>';
                            }

                            if (htmlAttributes != '')
                                attributeGroup = '<optgroup label="Attributes">' + htmlAttributes + '</optgroup>';

                            if (deviceOptions != '')
                                deviceGroup = '<optgroup label="Devices">' + deviceOptions + '</optgroup>';

                            if (operatorOptions != '')
                                operatorAttributeGroup = '<optgroup label="' + $.htmlDecode(athoc.iws.publishing.iut.resources.operatorAttributesLabel) + '">' + operatorOptions + '</optgroup>';

                            html = html + hierarchyGroup + attributeGroup + operatorAttributeGroup + deviceGroup;
                            html += '</select>';
                            $("#newColumns").html(html);

                            var selectElm = $("select[name='addColumnDropdown']");
                            selectElm.change(function () {
                                var elm = $(this);

                                athoc.iws.publishing.iut.updateGridColumn(0, elm.val(),
                                    "add",
                                    elm.find("option:selected").data("customviewcolumntype"),
                                    elm.find("option:selected").data("key"),
                                    function () {
                                        $("#contextDropdown").hide();
                                    });
                            });

                            var position = $("#AddBlockUsers .column-select").offset();
                            var selColumn = $("#AddBlockUsers .column-filter");
                            selColumn.css({ top: '190px' });
                            $("#contextDropdown").show();
                        }

                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
                //}
            },

            // For Add/Block user Update grid columns in a grid
            updateGridColumn: function (viewId, id, action, columnType, columnKey, onSuccess) {
                var self = this;
                if (id) {
                    //$.AjaxLoader.setup({ useBlock: true, idToShow: self._id + '-pageAjaxLoader', elementToBlock: $('.table-header'), imageURL: self.options.cdnUrl + '/Images/ajax-loader.gif' }).showLoader();
                    if (action == "remove" && athoc.iws.publishing.iut.allUserSortColumn == columnKey) {
                        athoc.iws.publishing.iut.allUserSortColumn = "DISPLAYNAME";
                        athoc.iws.publishing.iut.allUserSortOrder = "ASC";
                    }
                    var myAjaxOptions = {
                        url: athoc.iws.publishing.urls.SaveCustomViewUrl,
                        type: "POST",
                        dataType: "json",
                        data: { viewId: viewId, id: id, action: action, type: columnType, commonName: columnKey },
                        success: function (data) {
                            athoc.iws.publishing.iut.createAddBlockUsersGrid(undefined, onSuccess, undefined, undefined, false);
                        }
                    };

                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                    $.ajax(ajaxOptions);
                }
            },

            // Open Add/Blocked users popup
            OpenAddBlockUsers: function () {
                $("#allUsersBucket").show();
                $("#targetBlockBucket").hide();
                $('#AddBlockUsers').modal('show');
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.removeAll();
                if ($("#targetBlockingList").data("kendoGrid") != null) {
                    var data = $("#targetBlockingList").data("kendoGrid").dataSource.view();
                    $.grep(data, function (i) {
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.push({ UserId: i.UserId, IsBlocked: i.IsBlocked, Name: i.Name });
                    });
                }
                firstTimeOpenAddUser = 0;
                athoc.iws.publishing.iut.clearAllTargetedBlockedUsersPopUp();
            },

            // Clear all updated data and reset the grid
            clearAllTargetedBlockedUsersPopUp: function () {
                //athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.removeAll();
                athoc.iws.publishing.iut.viewModel.blockedCnt(0);
                athoc.iws.publishing.iut.viewModel.targetedCnt(0);
                $("#pillContainer").html("");
                $("#txtAllUserSearch").val('');
                athoc.iws.publishing.iut.allUserSortColumn = "DisplayName";
                athoc.iws.publishing.iut.allUserSortField = "_DISPLAYNAME";
                athoc.iws.publishing.iut.allUserSortOrder = "asc";
                athoc.iws.publishing.iut.allUsersPageSize = 50;
                athoc.iws.publishing.iut.searchString.length = 0;
                /*if ($("#targetBlockingList").data("kendoGrid") != null) {
                    var data = $("#targetBlockingList").data("kendoGrid").dataSource.view();
                    $.grep(data, function (i) {
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.push({ UserId: i.UserId, IsBlocked: i.IsBlocked, Name: i.Name });
                    });
                }*/
                athoc.iws.publishing.iut.countTargetedBlocked();
                athoc.iws.publishing.iut.createAddBlockUsersGrid();
                //$("#btn_userSearch").attr('disabled', 'true');
                $("#AddBlockUsers").find(".bootstrap-select").remove();
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#AddBlockUsers'));
            },

            // Show all user tab
            showAllUsers: function () {
                athoc.iws.publishing.iut.createAddBlockUsersGrid();
                athoc.iws.publishing.iut.countTargetedBlocked();
                $("#allUsersBucket").show();
                $("#targetBlockBucket").hide();

            },
            // Show targeted/blocked tab
            showTargetedBlockedUsers: function () {
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#tbUsersList'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                $("#tbUsersList").html('');
                athoc.iws.publishing.iut.targetBlockPageSize = 50;
                athoc.iws.publishing.iut.targetingBlockUsers();
                $("#allUsersBucket").hide();
                $("#targetBlockBucket").show();
                $.AjaxLoader.hideLoader();

            },
            // Check event of checkbox in all user grid
            Targeted: function (obj) {
                var userId = obj.getAttribute("value");
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == userId;
                });
                //athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit = 5;
                if (obj.checked && athoc.iws.publishing.iut.viewModel.targetedCnt() >= athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit) {
                    $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                    $("#lblUsersLimit").html(athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit);
                    $('#btn_limitCancel').on('click', function (event) {
                        $("#dialogUsersLimit").hide();

                        $("#AddBlockUsers").find('#displayShadow').remove();
                    });
                    $("#dialogUsersLimit").show();
                    obj.checked = false;
                    return false;
                }
                if (item != null) {
                    item.IsBlocked = false;
                    item.IsTargeted = obj.checked;
                    athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    athoc.iws.publishing.iut.retainSelectAll();
                }
            },
            //Block event of all users grid
            blockUser: function (obj) {
                var userId = obj;
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == userId;
                });
                if (item != null) {
                    item.IsBlocked = true;
                    item.IsTargeted = false;
                    athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    $("#allUserList").data("kendoGrid").refresh();
                    athoc.iws.publishing.iut.retainSelectAll();
                }
            },
            // UnBlock event of all users grid
            unBlockUser: function (obj) {
                //event.preventDefault();
                var userId = obj;
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == userId;
                });
                if (item != null) {
                    item.IsBlocked = false;
                    item.IsTargeted = false;
                    athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    $("#allUserList").data("kendoGrid").refresh();
                    athoc.iws.publishing.iut.retainSelectAll();
                }
            },
            // Remove event of all users grid
            removeTargBlockUser: function (id) {
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.remove(function (i) { return i.UserId == id; });
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == id;
                });
                if (item != null) {
                    item.IsBlocked = false;
                    item.IsTargeted = false;
                }
                athoc.iws.publishing.iut.countTargetedBlocked();
                //var ds = $("#tbUsersList").data("kendoGrid").dataSource;
                //ds.remove(function (i) { return i.UserId == id; });
                //  $("#tbUsersList").data("kendoGrid").refresh();
            },
            // Adding targeted and blocked user to array
            updateTargetedBlockedUsers: function (obj) {
                var displayName = '';
                var item = _.find(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                    return obj.Id == i.UserId;
                });
                if (item == null && (obj.IsBlocked || athoc.iws.publishing.iut.viewModel.targetedCnt() < athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit)) {
                    if (obj._DISPLAYNAME != null && $.trim(obj._DISPLAYNAME) != '' && $.trim(obj._DISPLAYNAME) != 'N/A')
                        displayName = obj._DISPLAYNAME;
                    else if ((obj._FIRSTNAME != null && $.trim(obj._FIRSTNAME) != '') || (obj._LASTNAME != null && $.trim(obj._LASTNAME) != ''))
                        displayName = $.trim(obj._FIRSTNAME + ' ' + obj._LASTNAME);
                    else
                        displayName = obj._LOGIN_ID;

                    athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.push({ UserId: obj.Id, Name: displayName, IsBlocked: obj.IsBlocked });
                }
                else {
                    if (obj.IsBlocked == false && obj.IsTargeted == false)
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.remove(function (i) { return i.UserId == obj.Id });
                    else {
                        item.IsBlocked = obj.IsBlocked;
                    }
                }
                athoc.iws.publishing.iut.countTargetedBlocked();
            },
            // Updating targeted and blocked user count
            countTargetedBlocked: function () {
                athoc.iws.publishing.iut.viewModel.targetedCnt(
                ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers()).filter(function (i) {
                    return !i.IsBlocked;
                }).length);

                athoc.iws.publishing.iut.viewModel.blockedCnt(
                ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers()).filter(function (i) {
                    return i.IsBlocked;
                }).length);
            },
            // Apply event of popup
            applyChangesToList: function () {
                var data = [];
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                    data.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });
                //athoc.iws.publishing.iut.viewModel.targetedBlockerUsers().length = 0
                //data.sort(function (l, r) { return l.Name.toLowerCase() == r.Name.toLowerCase() ? 0 : (l.Name.toLowerCase() < r.Name.toLowerCase() ? -1 : 1); }).sort(function (l, r) { return l.IsBlocked < r.IsBlocked ? -1 : 1; });
                if (data.length > 0)
                    data.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var tbuList = new kendo.data.DataSource({
                    data: data,
                });

                $("#targetBlockingList").data("kendoGrid").setDataSource(tbuList);
                $('#AddBlockUsers').modal('hide');
                athoc.iws.publishing.iut.updateChangesToSummaryAndChart();
                athoc.iws.publishing.targetUsers.targetingChanged();
                athoc.iws.publishing.iut.dataChanged();

            },
            // Updating the Pie chart data and targeted summary
            updateChangesToSummaryAndChart: function () {
                var targetCount = ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).filter(function (i) {
                    return !i.IsBlocked;
                }).length;

                var blockedCount = ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).filter(function (i) {
                    return i.IsBlocked;
                }).length;

                athoc.iws.publishing.targetUsers.getTargetedUsersCount(targetCount);
                athoc.iws.publishing.targetUsers.getBlockedUsersCount(blockedCount);


                athoc.iws.publishing.detail.isIUTLoaded = true;
                athoc.iws.publishing.targetUsers.updateContactInfo();

            },

            // Bind data to targeted/blocked users grid
            targetingBlockUsers: function () {
                var dataTb = [];
                var sortState = '';
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                    dataTb.push({ IsBlocked: i.IsBlocked, Name: $.htmlDecode(i.Name), UserId: i.UserId });
                });

                if (athoc.iws.publishing.iut.targetBlockSort == "asc")
                    dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 });
                else {
                    var tList = ko.mapping.toJS(dataTb).filter(function (i) {
                        return !i.IsBlocked;
                    }).sort(function (i, j) { return i.Name.toLowerCase() > j.Name.toLowerCase() ? -1 : 1; });

                    var rList = ko.mapping.toJS(dataTb).filter(function (i) {
                        return i.IsBlocked;
                    }).sort(function (i, j) { return i.Name.toLowerCase() > j.Name.toLowerCase() ? -1 : 1; });

                    dataTb.length = 0;
                    dataTb = tList.concat(rList);
                }

                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: athoc.iws.publishing.iut.targetBlockPageSize,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });
                $("#tbUsersList").html('');
                //datasource.read();
                var grid = $("#tbUsersList").kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: false,
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "",
                                     title: "",
                                     template: $("#targblock-imgtargeting-template").html(),
                                     width: "3%",
                                     headerAttributes: {
                                         tabindex: "2"
                                     }
                                 },
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTTBUserList_Name,
                                     // template: '<span title="#=Name#">#=Name#</span>',
                                     template: $("#targblock-name-template").html(),
                                     width: "92%",
                                     headerTemplate: kendo.format('<span title="' + athoc.iws.publishing.iut.resources.IUTTBUserList_Name + '" onclick="athoc.iws.publishing.iut.onTargetBlockedNameSort();">' + athoc.iws.publishing.iut.resources.IUTTBUserList_Name + '</span>{0}', athoc.iws.publishing.iut.targetBlockSort.toUpperCase() == "ASC" ? '<span class="sort-indicator-ascending"></span>' : '<span class="sort-indicator-descending"></span>'),
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                                {
                                    field: "",
                                    title: athoc.iws.publishing.iut.resources.IUTTBUserList_Remove_User,
                                    template: $("#targblock-imgremove-template").html(),
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', "", ""),
                                    width: "5%",
                                    headerAttributes: {
                                        tabindex: "4"
                                    }
                                },

                            ],
                    dataBound: athoc.iws.publishing.iut.onTargetBlockedDataBound,
                    change: function (e) {
                    }
                }).data().kendoGrid;

                athoc.iws.publishing.iut.fitHeighUserList();
            },
            // Databind evnet of targeted/blocked user grid
            onTargetBlockedDataBound: function (e) {
                var data = $("#tbUsersList").data("kendoGrid").dataSource.data();
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(data);
                athoc.iws.publishing.iut.OnBoundTargetedBlockedEmptyRow(data);
                athoc.iws.publishing.iut.targetBlockPageSize = $("#tbUsersList").data("kendoGrid").dataSource._pageSize;
            },

            onTargetBlockeddataBinding: function (e) {
                var ds = $("#tbUsersList").data("kendoGrid").dataSource;
                ds._sort = [{ field: 'Name', dir: athoc.iws.publishing.iut.targetBlockSort }];
            },

            onTargetBlockedNameSort: function (e) {
                if (athoc.iws.publishing.iut.targetBlockSort == "asc")
                    athoc.iws.publishing.iut.targetBlockSort = "desc";
                else
                    athoc.iws.publishing.iut.targetBlockSort = "asc"

                athoc.iws.publishing.iut.targetingBlockUsers();
            },

            OnBoundTargetedBlockedEmptyRow: function (data) {
                var colCount = $("#tbUsersList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#tbUsersList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:10px;overflow:auto;">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', athoc.iws.publishing.iut.resources.IUTTBUserList_Emptyrow_Message, athoc.iws.publishing.iut.resources.IUTTBUserList_Emptyrow_Message) +
                            '</td></tr>');

                }
            },

            showTargetedUsersSummary: function (isReadonly) {
                var sortState = '';
                var dataTb = [];
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(), function (i) {
                    if (!i.IsBlocked)
                        dataTb.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });

                dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 50,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });
                //datasource.read();
                var cntrl = isReadonly ? $("#targetedUsersListDetail") : $("#targetedUsersList");
                cntrl.html('');
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTTargetedSummary_Name,
                                     template: '<span title="#=Name#">#=Name#</span>',
                                     width: "95%",
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;
                grid.refresh();
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#targetedUsersSummary'));
                athoc.iws.publishing.iut.fitHeightTargetedUsersSummaryList();
            },

            showBlockedUsersSummary: function (isReadonly) {
                var dataTb = [];
                var sortState = '';
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(), function (i) {
                    if (i.IsBlocked)
                        dataTb.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });

                dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 50,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });

                //datasource.read();
                var cntrl = isReadonly ? $("#blockedUsersListDetail") : $("#blockedUsersList");
                cntrl.html('');
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTBlockedSummary_Name,
                                     template: '<span title="#=Name#">#=Name#</span>',
                                     width: "95%",
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#blockedUsersSummary'));
                athoc.iws.publishing.iut.fitHeightBlockedUsersSummaryList();

            },
            //Method to handle erro and session time out, this is boud with Ajax calls
            handleError: function (e) {

                if (e != undefined && e.status == 401 || (e != undefined && e.xhr != undefined && e.xhr.status == 401)) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else if (e.errorThrown != "") {
                    if (athoc.iws.publishing.iut.errors === null) {
                        athoc.iws.publishing.iut.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.publishing.iut.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#listMessagePanel').messagesPanel({ messages: this.errors }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },
            getTargetedUsers: function () {

                var targetdata = [];

                if (athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList().length > 0) {
                    $(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).each(function (index, item) {
                        if (!item.IsBlocked)
                            targetdata.push(item.UserId);
                    });
                }
                return targetdata;
            },

            getBlockedUsers: function () {
                var blockeddata = [];
                if (athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList().length > 0) {
                    $(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).each(function (index, item) {
                        if (item.IsBlocked)
                            blockeddata.push(item.UserId);
                    });
                }
                return blockeddata;
            },
            Rebind: function (data) {
                $(data).each(function (index, item) {
                    athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.remove(function (i) { return i.UserId == item; });
                });

                athoc.iws.publishing.iut.firsttimneLoad = false;

                // dataobject for maniplication
                athoc.iws.publishing.iut.createTargettingUserListGrid(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers());
                $('#targetBlockingList .k-grid-header').hide();
                $('#targetBlockingList .k-pager-wrap').hide();
                athoc.iws.publishing.targetUsers.targetingChanged();
            },
           
        };
    }();
}

///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.fillcount.js
/* define javascript namespace for fill count  */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};
if (athoc.iws.publishing) {
    $.fn.setCursorPosition = function (pos) {
        this.each(function (index, elem) {
            if (elem.setSelectionRange) {
                elem.setSelectionRange(pos, pos);
            } else if (elem.createTextRange) {
                var range = elem.createTextRange();
                range.collapse(true);
                range.moveEnd('character', pos);
                range.moveStart('character', pos);
                range.select();
            }
        });
        return this;
    };
    athoc.iws.publishing.fillcount = function () {
        //
        return {
            //is model changed
            isChanged: false,
            responseChangedText: '',
            deleteResponseIndex: -1,
            confirmationDailogType: 0,
            isTUSectionReadonly: false,
            // fill count summary 
            fillCountSummary: ko.observable(),
            defaultFillCountSummary: {
                ResponseText: "",
                FillCount: 0,
                AttributeName: "",
                ControlDeliveryTypeText: "",
                WaitTimeTitle: "",
                WaitTime: "",
                ControlDeliveryType: 0,
            },
            defaultFillCount: {
                ResponseOptionId: -1,
                EntityId: 0,
                AnyResponseOption: true,
                FillCount: 1,
                EscalationAttributeId: 0,
                PhoneAttributeId: 0,
                WaitTime: 15,
                WaitTimeUnit: "Minutes",
                GroupByAscending: true,
                OrderByAscending: true,
                ControlledDeliveryType: 0,
                EnableControlledDelivery: false,
                EnableEscalation: false,
            },

            // viewmodel
            viewModel: {
                initialFocus: ko.observable(true),
                fillCountModel: ko.observable(),
                responseOptions: ko.observableArray(),
                escalationAttributes: ko.observableArray(),
                phonesequencingAttributes: ko.observableArray(),
                waitTimeUnits: ko.observableArray(),
                editFillCountModel: {},
            },
            //This method is used to resize the popup when window is resizing
            attachResizePopupWindowEvent: function () {
                var resizeFunction = function () {
                    if ($(window).height() > 1024)
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#FillCount'), 600, 770, 20, 170);
                    else
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#FillCount'), 560, 710, 15, 145);

                    athoc.iws.publishing.fillcount.fcDivScrollEventActions();

                }
                var updateLayout = _.debounce(resizeFunction, 500); // Maximum run of once per 500 milliseconds
                window.addEventListener("resize", updateLayout, false);
            },
            fcDivScrollEventActions: function () {
                if ($('#FillCount .modal-body').get(0).scrollHeight > $('#FillCount .modal-body').innerHeight())
                    $("#secondBucket").removeClass("mar-bot0");
                else
                    $("#secondBucket").addClass("mar-bot0");

            },
            //This is method when new data is loaded from publishing model
            load: function () {
                athoc.iws.publishing.fillcount.viewModel.waitTimeUnits.push({ text: athoc.iws.publishing.fillcount.resources.FillCount_Minutes, value: "Minutes" });
                athoc.iws.publishing.fillcount.viewModel.waitTimeUnits.push({ text: athoc.iws.publishing.fillcount.resources.FillCount_Hours, value: "Hours" });

                // Edit Link to show Fill Count UI
                $("#EditFillCount").click(function () {
                    $('#FillCount').modal('show');
                    athoc.iws.publishing.fillcount.attachResizePopupWindowEvent();
                    // athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                    athoc.iws.publishing.fillcount.viewModel.editFillCountModel = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                    athoc.iws.publishing.fillcount.showFillCount();
                });

                // Open Fill Count Popup
                $("#FillCountLink").click(function () {
                    if (!athoc.iws.publishing.fillcount.isResponsesAvailable()) {
                        /// TODO move text to resource file
                        athoc.iws.publishing.fillcount.showConfirmationDialog(3, $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_AtleastOneResponse));
                    } else {
                        $('#FillCount').modal('show');
                        athoc.iws.publishing.fillcount.attachResizePopupWindowEvent();
                        //athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                        athoc.iws.publishing.fillcount.viewModel.editFillCountModel = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                        athoc.iws.publishing.fillcount.showFillCount();

                    }
                });

                //Apply Fill Count on Target User Section
                $("#ApplyFillCount").click(function () {
                    if (!athoc.iws.publishing.fillcount.isValid()) {
                        $("#FillCountSummary").show();
                        $("#EditFillCountDetails").show();
                        $("#FillCountLink").hide();
                        $('#FillCount').modal('hide');
                        athoc.iws.publishing.fillcount.setFillCountSummary(null);
                        var targetDiv = $("#publishing-user-edit");
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, targetDiv);

                        athoc.iws.publishing.fillcount.isChanged = true;
                    }
                });

                //Cancel Fill Count 
                $("#CancelFillCount").click(function () {
                    $('#FillCount').modal('hide');
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.ResponseOptionId);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.AnyResponseOption(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.AnyResponseOption);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.FillCount);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.ControlledDeliveryType);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.EscalationAttributeId);
                    $('#escalationAttribute').selectpicker('refresh');

                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.WaitTime);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.WaitTimeUnit);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.GroupByAscending);
                    // athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.PhoneAttributeId);
                    // $('#phoneAttribute').selectpicker('refresh');
                    // athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.OrderByAscending);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.ControlledDeliveryType.EntityId);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.EnableEscalation);
                });

                //Clear Fill Count
                $("#ClearFillCount").click(function () {
                    athoc.iws.publishing.fillcount.confirmationDailogType = 1;
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.showConfirmationDialog(1, athoc.iws.publishing.fillcount.resources.FillCount_Removemsg);
                });
            },

            // Modal resizing
            resizeModalBasedOnScreen: function (modal) {
                modal.find(".modal-body").css("max-height", 460);
                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 60 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 60 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 240);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }

            },

            // to show escalation breadcrum
            showEscalationBreadCrum: function (flag) {
                if (!flag) {
                    $("#showEscalationBreadCrumLess").show();
                    $("#showEscalationBreadCrumMore").hide();
                } else {
                    $("#showEscalationBreadCrumLess").hide();
                    $("#showEscalationBreadCrumMore").show();
                }
                athoc.iws.publishing.fillcount.fcDivScrollEventActions();
                return false;
            },

            EditFillcount: function () {

                $('#FillCount').modal('show');
                athoc.iws.publishing.fillcount.attachResizePopupWindowEvent();
                //athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                athoc.iws.publishing.fillcount.viewModel.editFillCountModel = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                athoc.iws.publishing.fillcount.showFillCount();
            },
            /// TODO : we can delete this method
            CancelDailog: function () {
                if (athoc.iws.publishing.fillcount.confirmationDailogType == 1 || athoc.iws.publishing.fillcount.confirmationDailogType == 0)
                    $("#dialogResponseDeleteConfirm").modal("hide");
                else if (athoc.iws.publishing.fillcount.confirmationDailogType == 2) {
                    athoc.iws.publishing.fillcount.fillCountSummary.ResponseText(athoc.iws.publishing.fillcount.responseChangedText);
                    athoc.iws.publishing.fillcount.responseChangedText = '';
                    $("#dialogResponseChangeConfirm").modal("hide");
                } else if (athoc.iws.publishing.fillcount.confirmationDailogType == 3) {
                    athoc.iws.publishing.content.viewModel.data.ResponseOptionId(athoc.iws.publishing.content.responseOptionPreviousId);
                    $('#responseList').selectpicker('refresh');
                    $("#dialogResponseDeleteConfirm").modal("hide");
                }
                athoc.iws.publishing.fillcount.confirmationDailogType = 0;
            },

            localizeTimeUnit: function (unit) {
                if ((unit.toLowerCase() == "hour") || (unit.toLowerCase() == "hours"))
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Hours);
                if ((unit.toLowerCase() == "minute") || (unit.toLowerCase() == "minutes"))
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Minutes);
            },

            // set Fill count summary data
            setFillCountSummary: function (existingSummary) {
                var self = athoc.iws.publishing.fillcount.fillCountSummary;
                if (existingSummary == null) {
                    self.ResponseText($("#fillCountResponses option:selected").text());
                    self.FillCount($("#fillcount").val() + ' ' + $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Summary_ResponseText));



                    switch (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType()) {
                        case 0:
                            self.ControlDeliveryType(0);
                            self.ControlDeliveryTypeText("");
                            self.AttributeName("");
                            self.WaitTimeTitle("");
                            self.WaitTime("");

                            break;
                        case 1:
                            self.ControlDeliveryType(1);
                            self.ControlDeliveryTypeText( $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                            self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + $("#escalationAttribute option:selected").text() + ' ' + (athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending() ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                            self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_WaitTime));
                            self.WaitTime(athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() > 1 ? athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase() : athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase().substring(0, athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().length - 1))));
                            break;
                        case 2:
                            self.ControlDeliveryType(2);
                            self.ControlDeliveryTypeText($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                            self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + $("#escalationAttribute option:selected").text() + ' ' + (athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending() ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                            self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_WaitTime));
                            self.WaitTime(athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() > 1 ? athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase() : athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase().substring(0, athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().length - 1))));
                            break;
                            /*    case 2:
                                    self.ControlDeliveryType(2);
                                    self.ControlDeliveryTypeText(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Sequencing);
                                    self.WaitTimeTitle("");
                                    self.WaitTime("");
                                    self.AttributeName(athoc.iws.publishing.fillcount.resources.FillCount_Sortby + ' ' + $("#phoneAttribute option:selected").text() + ' ' + (athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending() ? athoc.iws.publishing.fillcount.resources.FillCount_Asc : athoc.iws.publishing.fillcount.resources.FillCount_Desc));
                                    break;*/
                    }
                } else {
                    // set Default Fill Count Summary Model

                    self.ResponseText(athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.ResponseOptionId, 0));
                    self.FillCount(existingSummary.FillCount + ' ' + $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Summary_ResponseText));
                    athoc.iws.publishing.fillcount.setNoneFillCountSummary(self);
                    var attributeName;
                    switch (existingSummary.ControlledDeliveryType) {
                        case 1:
                            attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.EscalationAttributeId, 1);
                            if (attributeName != $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute)) {
                                self.ControlDeliveryType(1);
                                self.ControlDeliveryTypeText($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                                self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + attributeName + ' ' + (existingSummary.OrderByAscending == true ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                                self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_WaitTime));
                                self.WaitTime(existingSummary.WaitTime + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((existingSummary.WaitTime > 1 ? existingSummary.WaitTimeUnit.toLowerCase() : existingSummary.WaitTimeUnit.toLowerCase().substring(0, existingSummary.WaitTimeUnit.length - 1))));
                            }
                            break;
                        case 2:
                            attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.EscalationAttributeId, 1);
                            if (attributeName != $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute)) {
                                self.ControlDeliveryType(2);
                                self.ControlDeliveryTypeText($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                                self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + attributeName + ' ' + (existingSummary.OrderByAscending == true ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                                self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_WaitTime));
                                self.WaitTime(existingSummary.WaitTime + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((existingSummary.WaitTime > 1 ? existingSummary.WaitTimeUnit.toLowerCase() : existingSummary.WaitTimeUnit.toLowerCase().substring(0, existingSummary.WaitTimeUnit.length - 1))));

                            }
                            break;
                            /*  case 2:
                                  attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.PhoneAttributeId, 2);
                                  if (attributeName != athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute) {
                                      self.ControlDeliveryType(2);
                                      self.ControlDeliveryTypeText(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Sequencing);
                                      self.AttributeName(athoc.iws.publishing.fillcount.resources.FillCount_Sortby + ' ' + athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.PhoneAttributeId, 2) + ' ' + (existingSummary.OrderByAscending == true ? athoc.iws.publishing.fillcount.resources.FillCount_Asc : athoc.iws.publishing.fillcount.resources.FillCount_Desc));
                                      self.WaitTimeTitle("");
                                      self.WaitTime("");
                                  }
                                  break;*/
                    }
                }
            },

            // reset fill count summary on selecting none of delivery control type
            setNoneFillCountSummary: function (objModel) {

                // set fillcount summary attributes to default before assigning the db values
                objModel.ControlDeliveryType(0);
                objModel.ControlDeliveryTypeText("");
                objModel.AttributeName("");
                objModel.WaitTimeTitle("");
                objModel.WaitTime("");


            },

            // Attribute value from ID
            getControlDeliveryAttributeValue: function (Id, srctype) {
                var data;
                var iResponses = -1;
                var self = athoc.iws.publishing.fillcount.viewModel;
                if (srctype == 0 && Id == 0)
                    /// TODO move text to resource file
                    return athoc.iws.publishing.fillcount.resources.FillCount_Any;
                switch (srctype) {
                    case 0:
                        data = ko.mapping.toJS(self.responseOptions);
                        break;
                    case 1:
                        data = ko.mapping.toJS(self.escalationAttributes);
                        break;
                    case 2:
                        data = ko.mapping.toJS(self.phonesequencingAttributes);
                        break;
                }

                var attributeData = _.find(data, function (item) {
                    iResponses++;
                    return (srctype == 0) ? iResponses == Id : Id === item.Id;

                });
                if (attributeData == undefined)
                    switch (srctype) {
                        case 0:
                            /// TODO move text to resource file
                            return athoc.iws.publishing.fillcount.resources.FillCount_SelectaResponseOption;
                        case 1:
                        case 2:
                            /// TODO move text to resource file
                            if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType != undefined) {
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(0);
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime("15");
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId(0);
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit("Minutes");
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending(true);
                            }

                            return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute);
                            /*case 2:
                                /// TODO move text to resource file
                                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType != undefined) {
                                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(0);
                                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId(0);
                                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending(true);
                                
                                return athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute;
                                }*/
                    }

                return attributeData.Name;
            },

            // to fill summary section0
            ShowFillCountSummary: function (fillcountsummary, targetDiv) {
                ko.cleanNode(targetDiv.find("#FillCountDetails").get(0));
                ko.applyBindings(fillcountsummary, targetDiv.find("#FillCountDetails").get(0));
            },

            // to show fill count modal
            showFillCount: function () {


                var escalationDiv = $("#EscalationAttributeBreadCrum");
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType() == 0)
                    escalationDiv.hide();
                else
                    athoc.iws.publishing.fillcount.escalationBreadCrum(athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId());


                athoc.iws.publishing.fillcount.viewModel.responseOptions(athoc.iws.publishing.fillcount.fillResponses(ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data.ResponseOptions || athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions)));
                $("#responseOption").find(".bootstrap-select").remove();
                ko.cleanNode($("#responseOption").get(0));
                ko.applyBindings(athoc.iws.publishing.fillcount.viewModel, $("#responseOption").get(0));
                $("#fillCountResponses").selectpicker('refresh');
                $("#waitTimeDuration").selectpicker('refresh');

                //athoc.iws.publishing.fillcount.enableControlDeliveryAttributes(athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType());
                $('#FillCount').modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        $("#fillcount").trigger('focus').setCursorPosition($("#fillcount").val().length);
                        //    $('[data-id=fillCountResponses]').trigger('focus');
                    }, 1000);
                });

            },

            // to enable the control delivery attributes based on delivery control  type attribute selection
            enableControlDeliveryAttributes: function (newValue) {
                switch (newValue) {
                    case 0:
                        $("#ErrorMsg_EscalationAttributeId").css('display', "none");
                        $("#ErrorMsg_PhoneAttributeId").css('display', "none");
                        $("#EscalationAttributeBreadCrum").hide();
                        $('[data-id=escalationAttribute]').attr("disabled", "disabled");
                        $('[data-id=phoneAttribute]').attr("disabled", "disabled");
                        $('[data-id=waitTimeDuration]').attr("disabled", "disabled");
                        break;
                    case 1:
                        $("#ErrorMsg_PhoneAttributeId").css('display', "none");
                        $("#EscalationAttributeBreadCrum").show();
                        $('[data-id=escalationAttribute]').removeAttr("disabled");
                        $('[data-id=phoneAttribute]').attr("disabled", "disabled");
                        $('[data-id=waitTimeDuration]').removeAttr("disabled");
                        break;
                    case 2:
                        $("#ErrorMsg_EscalationAttributeId").css('display', "none");
                        $("#EscalationAttributeBreadCrum").hide();
                        $('[data-id=phoneAttribute]').removeAttr("disabled");
                        $('[data-id=escalationAttribute]').attr("disabled", "disabled");
                        $('[data-id=waitTimeDuration]').attr("disabled", "disabled");
                        break;

                }
            },

            // to generate escalation breadcrum based on escalation attribute selection
            escalationBreadCrum: function (Id) {

                var toData = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.escalationAttributes);
                var data = _.find(toData, function (toItem) {
                    return Id === toItem.Id;
                });
                var escalationDiv = $("#divEscalationAttributeBreadCrum");
                var template = kendo.template($("#fillCountEscalate-template").html());
                var lessdata = '';
                var moredata = '';
                var noitems = 0;
                var txtStyle = "font-size:11px; white-space:nowrap;display:none";
                data = data.Values;
                if (data == null || Id == 0) {
                    escalationDiv.hide();
                    return;
                } else
                    escalationDiv.show();
                if (!athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending())
                    data = data.reverse();

                for (var i = 0; i < data.length; i++) {                         
                    if ((lessdata == moredata) && this.fnCalcTextWidth("", txtStyle, ((lessdata + (lessdata != "" ? " > " : "") + data[i]) + " and more...")) < 385) { 
                        lessdata = lessdata + (lessdata != "" ? " > " : "") + data[i];
                        noitems++;
                    }
                    if (data.length > 1)
                        moredata = moredata + (moredata != "" ? " > " : "") + data[i];
                }
                if (lessdata == moredata)
                    moredata = "";
                noitems = ((data.length) - noitems);
                var data = { more: moredata, less: lessdata, items: noitems };
                var result = template(data);
                $("#escalationAttributeBreadCrum").html(result);
                
                if (moredata != "")
                    $("#morelinkfillcount").show();
                else
                    $("#morelinkfillcount").hide();
            },
            fnCalcTextWidth: function (Class,Style,text) {
                var tmpSpan = $('<span id="escalationAttributeBreadCrumTmp" ' + (Class != '' ? ' class="' + Class + '" ' : '') + '  ' + (Style != '' ? ' style="' + Style + '" ' : '') + ' >' + text + '</span>')
                      .appendTo($('body'));
                columnWidth = tmpSpan.width();
                tmpSpan.remove();
                return columnWidth;
            },
            // Subcribe Methods to capture changed state
            fillCountSubscribeMethods: function () {
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableControlledDelivery.subscribe(function (newValue) {
                    if (!newValue)
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(1);
                    else
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(2);
                });
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation.subscribe(function (newValue) {
                    ///IWS-15930
                    //athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                    if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() == "" || isNaN(athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime()))
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime('15');
                    if (!newValue) {
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(0);
                    } else
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableControlledDelivery() ? 2 : 1);
                    athoc.iws.publishing.fillcount.fcDivScrollEventActions();
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount.subscribe(function (newValue) {
                    ///IWS-15930
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount($.trim(newValue));
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId.subscribe(function (newValue) {

                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending.subscribe(function (newValue) {
                    athoc.iws.publishing.iut.readOnlySortColumn = "";
                    athoc.iws.publishing.iut.readOnlySortOrder = "";
                    athoc.iws.publishing.fillcount.escalationBreadCrum(athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId());
                });



                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime.subscribe(function (newValue) {
                    ///IWS-15930
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime($.trim(newValue));
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit.subscribe(function (newValue) {
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId.subscribe(function (newValue) {

                    // if (athoc.iws.publishing.iut.readOnlySortColumn != null || athoc.iws.publishing.iut.readOnlySortColumn!=undefined)

                    athoc.iws.publishing.iut.readOnlySortColumn = "";
                    athoc.iws.publishing.iut.readOnlySortOrder = "";

                    athoc.iws.publishing.fillcount.escalationBreadCrum(newValue);


                });

                /*      athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId.subscribe(function (newValue) {
                          if (newValue == 0) {
                              $("#ErrorMsg_EscalationAttributeId").css('display', "none");
                              /// TODO move text to resource file
                              $("#ErrorMsg_PhoneAttributeId").html(athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired);
                              $("#ErrorMsg_PhoneAttributeId").css('display', "inline-block");
                          }
                      });*/
            },

            // data from server side
            bind: function (data, isReadOnly) {

                athoc.iws.publishing.fillcount.isTUSectionReadonly = isReadOnly;

                //reset fill count model  based on fill count settings
                if (athoc.iws.publishing.fillcount.clearFillCountData(data.ScenarioSettings.Targeting.FillCount, data.FillCount))
                    return;

                // initilize data model
                athoc.iws.publishing.fillcount.initializeFillCountModel(data);
                // make sure to verify scenario setting before loading the data               

                if (!isReadOnly) {
                    athoc.iws.publishing.fillcount.enableFillCountSummary(data.ScenarioSettings.Targeting.FillCount);
                    $("#fillCountContent").find(".bootstrap-select").remove();
                    ko.cleanNode($("#fillCountContent").get(0));
                    ko.applyBindings(athoc.iws.publishing.fillcount.viewModel, $("#fillCountContent").get(0));
                    athoc.iws.publishing.fillcount.fillCountSubscribeMethods();
                    athoc.iws.publishing.fillcount.initiatePickers();
                } else {
                    athoc.iws.publishing.fillcount.readOnlyFillCountSummary(null, $("#publishing-user-detail"), false, data.ScenarioSettings.Targeting.FillCount);
                }
            },

            // to clear the fill count on removing  the fill count settings
            clearFillCountData: function (isFillCountEnabled, fillCountData) {
                if (!isFillCountEnabled && fillCountData != null && athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId != undefined) {
                    var entityId = athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId();
                    // default model values to fill count model
                    athoc.iws.publishing.fillcount.setDefaultFillCountModel();
                    return true;
                }
                return false;
            },

            // to enable or disable the fill count summary based on scenario settings and readonly mode
            enableFillCountSummary: function (isFillCountEnabled) {
                if (!isFillCountEnabled) {
                    $("#publishing-user-edit").find("#FillCountLink").hide();
                    $("#publishing-user-edit").find("#EditFillCountDetails").hide();
                    $("#publishing-user-edit").find("#FillCountSummary").hide();
                    return;
                }
                var showflag = athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1;
                // check if fill count data exists
                athoc.iws.publishing.fillcount.toggleFillCountSummary(showflag, $("#publishing-user-edit"));
            },

            // Show or Hide Fill Count Summary
            toggleFillCountSummary: function (ishowflag, targetDiv) {
                if (ishowflag) {
                    targetDiv.find("#FillCountSummary").show();
                    targetDiv.find("#EditFillCountDetails").show();
                    targetDiv.find("#FillCountLink").hide();
                    athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, targetDiv);
                } else {
                    targetDiv.find("#FillCountLink").show();
                    targetDiv.find("#EditFillCountDetails").hide();
                    targetDiv.find("#FillCountSummary").hide();
                }
            },

            // to show readOnly view of Fill Count Summary
            readOnlyFillCountSummary: function (data, targetDiv, isPublishing, isFillCountEnabled) {

                if (data == null || (athoc.iws.publishing.fillcount.clearFillCountData(isFillCountEnabled, data.FillCount)) || (!isFillCountEnabled)) return;
                targetDiv.find("#EditFillCountDetails").hide();
                targetDiv.find("#FillCountLink").hide();

                if (data != null)
                    athoc.iws.publishing.fillcount.initializeReadOnlyFillCountModel(data);
                var showflag = data == null ? athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1 : data.FillCount != null && data.FillCount.ResponseOptionId > -1;
                if (showflag) {
                    targetDiv.find("#FillCountDetails").show();
                    targetDiv.find("#FillCountSummary").show();
                    if (athoc.iws.publishing.fillcount.fillCountSummary != null)
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, targetDiv);
                } else {
                    targetDiv.find("#FillCountDetails").hide();
                    targetDiv.find("#FillCountSummary").hide();
                }
            },
            //  // initialize view model for Scenario or Alert Edit
            initializeFillCountModel: function (data) {
                data.EscalationAttributes.unshift({ Id: 0, Name: $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute), Values: [] });
                athoc.iws.publishing.fillcount.viewModel.escalationAttributes = ko.mapping.fromJS(data.EscalationAttributes);
                //data.SequencingAttributes.unshift({ Id: 0, Name: "Select an Attribute", Values: [] });
                //athoc.iws.publishing.fillcount.viewModel.phonesequencingAttributes = ko.mapping.fromJS(data.SequencingAttributes);
                athoc.iws.publishing.fillcount.viewModel.responseOptions = ko.mapping.fromJS(athoc.iws.publishing.fillcount.fillResponses(data.Content.ResponseOptions));
                athoc.iws.publishing.fillcount.fillCountSummary = ko.mapping.fromJS(athoc.iws.publishing.fillcount.defaultFillCountSummary);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel = ko.mapping.fromJS(athoc.iws.publishing.fillcount.setFillCountCustModel(data), athoc.iws.publishing.fillcount.getValidation());

                if (data.FillCount != null) {
                    /// TODO  Remove below attributes if they are not being used

                    data.FillCount.EscalationAttributeId = data.FillCount.ControlledDeliveryType != 0 ? data.FillCount.ControlledDeliveryAttributeId : 0;

                    //data.FillCount.PhoneAttributeId = data.FillCount.ControlledDeliveryType == 2 ? data.FillCount.ControlledDeliveryAttributeId : 0;
                    athoc.iws.publishing.fillcount.setFillCountSummary(data.FillCount, athoc.iws.publishing.fillcount.defaultFillCountSummary);
                }


            },

            // set Fill Count Cust Model for UI binding
            setFillCountCustModel: function (data) {
                var model = {};
                if (data.FillCount != null) {
                    model.ResponseOptionId = data.FillCount.ResponseOptionId;
                    model.AnyResponseOption = data.FillCount.AnyResponseOption;
                    model.FillCount = data.FillCount.FillCount;
                    model.ControlledDeliveryType = data.FillCount.ControlledDeliveryType;
                    // model.PhoneAttributeId = data.FillCount.ControlledDeliveryType == 2 ? data.FillCount.ControlledDeliveryAttributeId : 0;
                    // model.OrderByAscending = data.FillCount.ControlledDeliveryType == 2 ? data.FillCount.OrderByAscending : true;

                    var attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(data.FillCount.ControlledDeliveryAttributeId, 1);
                    if (attributeName == $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute)) {
                        model.EscalationAttributeId = 0;
                        model.EnableEscalation = false;
                        model.ControlledDeliveryType = 0;
                        model.EnableControlledDelivery = data.FillCount.ControlledDeliveryType == 2 ? true : false;
                    } else {
                        model.EnableEscalation = data.FillCount.ControlledDeliveryType != 0 ? true : false;
                        model.EnableControlledDelivery = data.FillCount.ControlledDeliveryType == 2 ? true : false;
                        model.EscalationAttributeId = data.FillCount.ControlledDeliveryType != 0 ? data.FillCount.ControlledDeliveryAttributeId : 0;
                    }
                    model.WaitTime = data.FillCount.ControlledDeliveryAttributeId != 0 ? data.FillCount.WaitTime : athoc.iws.publishing.fillcount.defaultFillCount.WaitTime;
                    model.WaitTimeUnit = data.FillCount.ControlledDeliveryAttributeId != 0 ? data.FillCount.WaitTimeUnit : athoc.iws.publishing.fillcount.defaultFillCount.WaitTimeUnit;
                    model.GroupByAscending = data.FillCount.ControlledDeliveryAttributeId != 0 ? data.FillCount.OrderByAscending : true;
                    model.EntityId = data.FillCount.EntityId;
                }
                else
                    model = athoc.iws.publishing.fillcount.defaultFillCount;

                return model;
            },

            // initialize readonly fill Count model for Scenario or Alert or Publishing
            initializeReadOnlyFillCountModel: function (data) {
                athoc.iws.publishing.fillcount.viewModel.escalationAttributes = ko.mapping.fromJS(data.EscalationAttributes);
                //athoc.iws.publishing.fillcount.viewModel.phonesequencingAttributes = ko.mapping.fromJS(data.SequencingAttributes);
                athoc.iws.publishing.fillcount.viewModel.responseOptions = ko.mapping.fromJS(athoc.iws.publishing.fillcount.fillResponses(data.Content.ResponseOptions));
                athoc.iws.publishing.fillcount.fillCountSummary = ko.mapping.fromJS(athoc.iws.publishing.fillcount.defaultFillCountSummary);
                if (data.FillCount != null) {

                    data.FillCount.EscalationAttributeId = data.FillCount.ControlledDeliveryType != 0 ? data.FillCount.ControlledDeliveryAttributeId : 0;

                }
                if (data.FillCount != null && data.FillCount.ResponseOptionId > -1) {
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel = ko.mapping.fromJS(athoc.iws.publishing.fillcount.setFillCountCustModel(data));
                    athoc.iws.publishing.fillcount.setFillCountSummary(data.FillCount, athoc.iws.publishing.fillcount.defaultFillCountSummary);
                }
            },

            // fill Response Options from the content model
            fillResponses: function (responseList) {
                var i = 0;

                /// TODO move text to resource file
                var responseOptions = [{
                    Id: -1, Name: $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectaResponseOption)
                }];
                if (responseList.length >= 1) {
                    _.each(responseList, function (item) {
                        i++;
                        if ($.trim(item.ResponseText) != "") {
                            responseOptions.push({ Id: i, Name: $.htmlDecode(item.ResponseText) });
                        }
                    });
                    responseOptions.push({ Id: 0, Name: $.htmlDecode( athoc.iws.publishing.fillcount.resources.FillCount_Any) });
                }

                return responseOptions;
            },

            // Refresh all select pickers , this is required when you enable and disable the dropdowns
            refreshPickers: function () {

                $("#fillCountResponses").selectpicker('refresh');
                $('#escalationAttribute').selectpicker('refresh');
                $('#waitTimeDuration').selectpicker('refresh');
                // $('#phoneAttribute').selectpicker('refresh');
            },

            // initiate all select pickers
            initiatePickers: function () {
                $("#fillCountResponses").selectpicker();
                $("#escalationAttribute").selectpicker();
                // $("#phoneAttribute").selectpicker();
                $("#waitTimeDuration").selectpicker();
            },

            // get model returns Fill Data Model  , same function works for new ,modify and delete
            getModel: function () {

                var data = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                if (data == null || data == undefined || (data.ResponseOptionId == -1 && (data.EntityId == 0 || athoc.iws.publishing.entityId == 0)))
                    return null;
                // Re-calculate the responseId since some are empty.
                if (athoc.iws.publishing.content.viewModel.data.ResponseOptions != null || athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions != null) {
                    var res = ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data.ResponseOptions || athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions);
                    var selectedRes = 0;
                    _.each(res, function (item, index) {
                        if (item.ResponseText != "")
                            selectedRes++;
                        if (data.ResponseOptionId == (index + 1)) {
                            data.ResponseOptionId = selectedRes;
                            return;
                        }
                    });
                }

                var fillcountdata = {
                    ID: 0,
                    ResponseOptionId: data.ResponseOptionId,
                    EntityId: data.EntityId,
                    AnyResponseOption: data.ResponseOptionId == 0 ? true : false,
                    FillCount: data.ResponseOptionId == -1 ? 0 : data.FillCount,
                    ControlledDeliveryAttributeId: data.ControlledDeliveryType != 0 ? data.EscalationAttributeId : 0,
                    WaitTime: data.ControlledDeliveryType != 0 ? data.WaitTime : 0,
                    WaitTimeUnit: data.ControlledDeliveryType != 0 ? data.WaitTimeUnit : null,
                    OrderByAscending: data.ControlledDeliveryType != 0 ? data.GroupByAscending : true,
                    ControlledDeliveryType: data.ControlledDeliveryType
                };
                return fillcountdata;
            },

            // return phone sequencing flag whether it is enabled or not
            isPhoneSequencingEnabled: function () {
                /* if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() == -1)
                     return false;
                 var data = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                 return data.ControlledDeliveryType == 2 ? true : false;*/
                return false;
            },
            // to verify whether
            isResponsesAvailable: function () {
                var data = athoc.iws.publishing.content.viewModel.data.ResponseOptions == undefined ? athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions() : athoc.iws.publishing.content.viewModel.data.ResponseOptions();
                if (data.length >= 1) {
                    var flag = false;
                    _.each(data, function (item) {

                        if ($.trim(item.ResponseText()) != "") {
                            flag = true;
                            return;
                        }
                    });
                    return flag;
                }
                return false;
            },
            // Validation
            isValid: function () {
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() < 0) {
                    /// TODO move text to resource file
                    $("#ErrorMsg_ResponseOptionId").html(athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired);
                    $("#ErrorMsg_ResponseOptionId").css('display', "inline-block");
                }

                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation() && (athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId() == undefined || athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId() == 0)) {
                    /// TODO move text to resource file
                    $("#ErrorMsg_EscalationAttributeId").html(athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired);
                    $("#ErrorMsg_EscalationAttributeId").css('display', "inline-block");
                }

                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation() && athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() <= 0)
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime.valueHasMutated();

                athoc.iws.publishing.fillcount.fcDivScrollEventActions();

                //verify any error message is displayed
                var bValid = $("#FillCount").find(".warning-msg").is(':visible');
                return bValid;
            },
            // TODO : Bring entire show dailog logic here
            showConfirmationDialog: function (dialogType, itext) {
                itext = $.htmlDecode(itext);
                switch (dialogType) {

                    case 0:
                        //show dialog for delete response
                        $("#fillCountText").text(itext);
                        $("#btnResDeleteCancel").show();
                        $("#btnResDeleteConfirm").show();
                        $("#btnResDeleteConfirm").text(athoc.iws.publishing.fillcount.resources.Action_Button_Delete);
                        $("#btnInfo").hide();
                        $("#dialogResponseDeleteConfirm").modal("show");
                        break;
                    case 1:
                        // show dialog for clear
                        $("#fillCountText").text(itext);
                        $("#btnResDeleteCancel").show();
                        $("#btnResDeleteConfirm").show();
                        $("#btnResDeleteConfirm").text(athoc.iws.publishing.fillcount.resources.FillCount_Summary_ClearTitle);
                        $("#btnInfo").hide();
                        $("#dialogResponseDeleteConfirm").modal("show");
                        break;

                    case 2:
                        // show dialog for response change
                        $("#respnseChangeText").text(itext);
                        $("#dialogResponseChangeConfirm").modal("show");
                        break;
                    case 3:
                        //show  dialog for no response
                        $("#fillCountText").text(itext);
                        $("#btnResDeleteCancel").hide();
                        $("#btnResDeleteConfirm").hide();
                        $("#btnInfo").show();
                        $("#dialogResponseDeleteConfirm").modal('show');
                        break;
                    case -1:
                        if (athoc.iws.publishing.fillcount.confirmationDailogType == 1 || athoc.iws.publishing.fillcount.confirmationDailogType == 0 || athoc.iws.publishing.fillcount.confirmationDailogType == 3)
                            $("#dialogResponseDeleteConfirm").modal("hide");
                        else if (athoc.iws.publishing.fillcount.confirmationDailogType == 2) {
                            $("#dialogResponseChangeConfirm").modal("hide");
                        }
                        athoc.iws.publishing.fillcount.confirmationDailogType = 0;
                        break;

                }
            },

            // On response delete  this method is invoke
            setFillCountOnResponseDelete: function (index) {
                athoc.iws.publishing.fillcount.deleteResponseIndex = index;
                var responseCount = athoc.iws.publishing.content.viewModel.data.ResponseOptions().length;
                var data = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                if (data.ResponseOptionId == 0 && responseCount == 1) {
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.showConfirmationDialog(0, athoc.iws.publishing.fillcount.resources.FillCount_DeleteAnymsg);
                    return false;
                } else if ((index + 1) == data.ResponseOptionId) {
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.showConfirmationDialog(0, athoc.iws.publishing.fillcount.resources.FillCount_Deletemsg);

                    return false;
                }

                if (data.ResponseOptionId > index)
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId(data.ResponseOptionId - 1);
                return true;
            },

            /// TODO move  fill count default settings to here
            setDefaultFillCountModel: function () {
                var entityId = athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId();
                // default model values to fill count model
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId(athoc.iws.publishing.fillcount.defaultFillCount.ResponseOptionId);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.AnyResponseOption(athoc.iws.publishing.fillcount.defaultFillCount.AnyResponseOption);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount(athoc.iws.publishing.fillcount.defaultFillCount.FillCount);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId(entityId);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId(athoc.iws.publishing.fillcount.defaultFillCount.EscalationAttributeId);
                $('#escalationAttribute').selectpicker('refresh');
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime(athoc.iws.publishing.fillcount.defaultFillCount.WaitTime);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit(athoc.iws.publishing.fillcount.defaultFillCount.WaitTimeUnit);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending(athoc.iws.publishing.fillcount.defaultFillCount.GroupByAscending);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation(athoc.iws.publishing.fillcount.defaultFillCount.EnableEscalation);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableControlledDelivery(athoc.iws.publishing.fillcount.defaultFillCount.EnableControlledDelivery);
                //athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId(athoc.iws.publishing.fillcount.defaultFillCount.PhoneAttributeId);
                //athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending(athoc.iws.publishing.fillcount.defaultFillCount.OrderByAscending);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(athoc.iws.publishing.fillcount.defaultFillCount.ControlledDeliveryType);
                athoc.iws.publishing.fillcount.isChanged = true;

                if (!athoc.iws.publishing.fillcount.isTUSectionReadonly) {
                    $("#publishing-user-edit").find("#FillCountLink").show();
                    $("#publishing-user-edit").find("#FillCountSummary").hide();
                } else {
                    $("#publishing-user-detail").find("#FillCountSummary").hide();
                }
            },

            // to set  fill count model to default in case of delete or clear function is invoked
            responseChangeAction: function () {
                var cdType = athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType();
                athoc.iws.publishing.fillcount.setDefaultFillCountModel();
                switch (cdType) {
                    case 1:
                        $('#escalationAttribute').selectpicker('refresh');
                        var escalationDiv = $("#EscalationAttributeBreadCrum");
                        escalationDiv.hide();
                        escalationDiv.html("");
                        break;
                    case 2:
                        $('#phoneAttribute').selectpicker('refresh');
                        break;
                }
                if (athoc.iws.publishing.fillcount.confirmationDailogType == 0)
                    athoc.iws.publishing.content.viewModel.deleteResponseOption(athoc.iws.publishing.fillcount.deleteResponseIndex);
                else if (athoc.iws.publishing.fillcount.confirmationDailogType == 3)
                    athoc.iws.publishing.content.responseOptionChanged();
                athoc.iws.publishing.fillcount.showConfirmationDialog(-1, "");
            },

            // On response change this method is invoked
            responseChange: function (index, chngText) {
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId != null && athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() - 1 == index) {
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.confirmationDailogType = 2;
                    athoc.iws.publishing.fillcount.responseChangedText = chngText;
                    //athoc.iws.publishing.fillcount.fillCountSummary.ResponseText(chngText);
                    if (!athoc.iws.publishing.fillcount.isTUSectionReadonly)
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, $("#publishing-user-edit"));
                    else
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, $("#publishing-user-detail"));

                    if ($.trim(chngText) == "") {
                        athoc.iws.publishing.fillcount.showConfirmationDialog(3, athoc.iws.publishing.fillcount.resources.FillCount_ResponseConfirm_Msg);
                        athoc.iws.publishing.fillcount.responseChangeAction();
                    } else if (athoc.iws.publishing.fillcount.fillCountSummary.ResponseText() != $.trim(chngText))
                        athoc.iws.publishing.fillcount.showConfirmationDialog(2, athoc.iws.publishing.fillcount.resources.FillCount_ModResponsemsg);
                }
            },

            reponseTypeChange: function () {
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId != null && athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1) {
                    athoc.iws.publishing.fillcount.confirmationDailogType = 3;
                    athoc.iws.publishing.fillcount.showConfirmationDialog(1, athoc.iws.publishing.fillcount.resources.FillCount_ModResponseConf);
                }
            },

            // Fill Count UI validation
            getValidation: function () {
                athoc.iws.publishing.fillcount.fcDivScrollEventActions();
                var validationMapping = {
                    FillCount: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {params:true, message:athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired},
                                min: { params: 1, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NumberLessThanOne },
                                /// TODO move text to resource file
                                maxLength: { params: 7, message: athoc.iws.publishing.fillcount.resources.FillCount_ExceedMaxLength },
                                pattern: {
                                    message: athoc.iws.publishing.fillcount.resources.FillCount_OnlyNummsg,
                                    params: "^[0-9]+$"
                                }
                            });
                        }
                    },
                    WaitTime: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                /// TODO move text to resource file
                                maxLength: { params: 7, message: athoc.iws.publishing.fillcount.resources.FillCount_ExceedMaxLength },
                                min: { params: 1, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NumberLessThanOne },
                                required: { params: true, message: athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired },
                                pattern: {
                                    /// TODO move text to resource file
                                    message: athoc.iws.publishing.fillcount.resources.FillCount_OnlyNummsg,
                                    params: "^[0-9]+$"
                                },
                            });
                        }
                    },
                };
                return validationMapping;
            },


        };

    }();
}

///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.geo.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.geo = function () {
        return {
            viewModel: {
                geoTargetingEnabled: ko.observable(true),

                //geo location
                isGeoSelected: ko.observable(false),

                geoImageUrl: ko.observable(''),

                shapes: ko.observable([]),

                isUsersTargeted: ko.observable(false),

                isOrganizationsTargeted: ko.observable(false),

                usersCount: ko.observable(0),

                organizationsCount: ko.observable(0),

                onTargetUserByAreaChange: function () {
                    if (!athoc.iws.publishing.geo.viewModel.isUsersTargeted())
                        athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria(0);
                    else
                        athoc.iws.publishing.geo.updateTargetingSummary();
                    athoc.iws.publishing.geo.updateContactPieChart();
                    return true;
                }
            },

            geoJson: null, //stores geoJson for currently loaded alert/scenario
            geoTargetMap: null, //map component
            miniMap: null,

            //triggered onload, function can have any load logic
            load: function () {
                //athoc.iws.publishing.geo.loadMap();
            },

            //load map component
            loadMap: function () {

                /*IWS-19267 
                1) removed esri minimap reference. 
                2) commented minimap creation using esri
                3) commented restoring geo coordinates for minimap
                4) called new method called bindAlertMiniMap
                5) impelemted GeoTargetingSummary maps  using leaflet on screen and r&p window 
                
                */
                //require(["maps/GeoTargetMap", "maps/MiniMap"], function (GeoTargetMap, MiniMap) {
                require(["maps/GeoTargetMap"], function (GeoTargetMap) {
                    athoc.iws.publishing.geo.geoTargetMap = new GeoTargetMap({ i18n: athoc.iws.publishing.mapResources, culture: languageParams.currentCulture }, "geoTargetMapHolder");

                    /* IWS-19267 - commnted out min map code implementation using esri. */

                    //athoc.iws.publishing.geo.miniMap = new MiniMap(null, "miniMapHolder");

                    athoc.iws.publishing.geo.geoTargetMap.startup();
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.on("orgTargetComplete", function (e) {
                        if (athoc.iws.publishing.targetOrg.OrgViewMod) {
                            //e.orgIds
                            athoc.iws.publishing.targetOrg.OrgViewModel.OrgCountByArea(e.selectedOrgs);
                            athoc.iws.publishing.targetOrg.OrgViewModel.SelectedOrgsByArea(e.orgIds);
                        }
                    });

                    athoc.iws.publishing.geo.geoTargetMap.on("close", function () {
                        athoc.iws.publishing.geo.geoJson = athoc.iws.publishing.geo.geoTargetMap.toGeoJson();
                        if (!athoc.iws.publishing.geo.geoJson || !athoc.iws.publishing.geo.geoJson.features || athoc.iws.publishing.geo.geoJson.features.length === 0) {
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                            athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                            athoc.iws.publishing.geo.updateTargetingSummary();
                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(false);
                            athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(false);
                            if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                                athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(false);
                            }
                        } else {
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                            athoc.iws.publishing.content.viewModel.isGeoSelected(true);

                            /*IWS-19267 - commented out restoring selected shape coordinates using esri mini map*/

                            //athoc.iws.publishing.geo.miniMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                            //athoc.iws.publishing.geo.miniMap.restore(athoc.iws.publishing.geo.geoJson);

                            /*IWS-19267 - calling new method to bind selected shape coordinates in leaflet map*/
                            athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);

                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(athoc.iws.publishing.geo.geoTargetMap.isTargetingUser);
                            athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg);
                            if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                                athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg);
                            }
                            athoc.iws.publishing.geo.updateTargetingSummary();
                        }
                        athoc.iws.publishing.geo.updateContactPieChart();
                        athoc.iws.publishing.content.checkReadyNotReady();
                    });

                    $('#dialogGeoTargetingSummary').on('shown.bs.modal', function () {
                        /*IWS-19267 - removed olde code and impelemted using leaflet */

                        //if (!athoc.iws.publishing.geo.summaryMap) {
                        //    athoc.iws.publishing.geo.summaryMap = new MiniMap({ width: 980, height: 300 }, "dialogGeoTargetingSummaryContent");
                        //}
                        //athoc.iws.publishing.geo.summaryMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                        //athoc.iws.publishing.geo.summaryMap.restore(athoc.iws.publishing.geo.geoJson);
                        //setTimeout(function () {
                        //    athoc.iws.publishing.geo.summaryMap.resize();
                        //    athoc.iws.publishing.geo.summaryMap.zoomToFit();
                        //}, 500);


                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.geo.summaryMap) {
                                athoc.iws.publishing.geo.summaryMap = new Map("dialogGeoTargetingSummaryContent", { i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                            }
                            athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.summaryMap, athoc.iws.publishing.geo.geoJson);
                        });
                    });

                    /*IWS-19267 - removed olde code and impelemted using leaflet in R&P publish window binding to display in all places like home and alerts screen*/
                    //the second popup modal in review and publish page
                   
                    $('#dialogGeoPublish').on('shown.bs.modal', function () {
                        /* if (!athoc.iws.publishing.geo.summaryMapOnRP) {
                            athoc.iws.publishing.geo.summaryMapOnRP = new MiniMap({ width: 980, height: 300 }, "dialogGeoPublishContent");
                        }
                        athoc.iws.publishing.geo.summaryMapOnRP.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                        athoc.iws.publishing.geo.summaryMapOnRP.restore(athoc.iws.publishing.geo.geoJson);
                        setTimeout(function () {
                            athoc.iws.publishing.geo.summaryMapOnRP.resize();
                            athoc.iws.publishing.geo.summaryMapOnRP.zoomToFit();
                        }, 500); */

                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.view.summaryMapReadOnly) {
                                athoc.iws.publishing.view.summaryMapReadOnly = new Map("dialogGeoPublishContent", {
                                    i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.summaryMapReadOnly, athoc.iws.publishing.geo.geoJson);
                        });

                    });
                   


                });
            },


            /* IWS-19267 - Written new method to removing old ge coordinates then adding new geo coordinates*/
            bindAlertMiniMap: function (miniMap,geoLocationsJson) {
                if (miniMap != null || miniMap) {
                    miniMap.removeGeoJson();
                    miniMap.addGeoJson(geoLocationsJson);
                    miniMap.centerAt([0, 0]);
                    miniMap.zoomToFit();
                }
            },

            //called when geo targeting model gets binded
            bind: function (data, isUsersTargeted, isOrganizationsTargeted) {
                athoc.iws.publishing.geo.viewModel.isUsersTargeted(isUsersTargeted);
                athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(isOrganizationsTargeted);
                var geoJson = data != "" ? JSON.parse(data) : null;
                //if (data == null || data == '') {
                if (geoJson == null || geoJson.features.length == 0) {// condition to stop loading generic map.

                    athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                    athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                    athoc.iws.publishing.geo.viewModel.geoImageUrl('');
                } else {
                    if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                        athoc.iws.publishing.geo.loadMap();
                    }

                    athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                    athoc.iws.publishing.content.viewModel.isGeoSelected(true);
                    athoc.iws.publishing.geo.geoJson = JSON.parse(data);

                    athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();

                   
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.restore(athoc.iws.publishing.geo.geoJson);


                    /*IWS-19267- commented out restoring selected shape coordinates using esri mini map*/

                    //athoc.iws.publishing.geo.miniMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                    //athoc.iws.publishing.geo.miniMap.restore(athoc.iws.publishing.geo.geoJson);

                    /*IWS-19267 - written code to create mini map using leaflet and binding geo coordinates. this section will call while editing drafted alert*/
                    if (athoc.iws.publishing.geo.geoJson != "" || athoc.iws.publishing.geo.geoJson != null) {

                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.geo.miniMap) {
                                if (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content || !athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Collapsed) {
                                    athoc.iws.publishing.geo.miniMap = new Map("miniMapHolder", {i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                                    athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                                }
                            }
                            else {
                                athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                            }

                        });
                    }
                }

                //Binding
                if ($("#targetContentArea").length > 0) {
                    ko.cleanNode($("#targetContentArea").get(0));
                    ko.applyBindings(athoc.iws.publishing.geo.viewModel, $("#targetContentArea").get(0));
                }

                athoc.iws.publishing.geo.updateTargetingSummary();
            },

            //called to get model for persisting
            getModel: function () {
                //return shape data for persisting
                if (athoc.iws.publishing.geo.geoJson != null) {
                    return JSON.stringify(athoc.iws.publishing.geo.geoJson);
                } else {
                    return null;
                }
            },

            //add geo location, entry point when alert/scenario does not have any existing location
            add: function () {
                var params = {};
                params.isNewMap = false;
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap==null) {
                    athoc.iws.publishing.geo.loadMap();
                    params.isNewMap = true;
                }
                var isTargetByUserEnabled = (($("#targetArea").length > 0) && ($('#targetArea').css('display') != 'none'));
                if (isTargetByUserEnabled) {
                    isTargetByUserEnabled = (($("#publishing-user-edit").length > 0) && ($('#publishing-user-edit').css('display') != 'none'));
                }

                var isTargetOrganizationEnabled = (($(".org-by-area").length > 0) && ($('.org-by-area').css('display') != 'none'));
                if (isTargetOrganizationEnabled && ($("#alert-org-edit").length > 0)) {
                    isTargetOrganizationEnabled = ($('#alert-org-edit').css('display') != 'none');
                } else  if (isTargetOrganizationEnabled &&  ($("#targetOrgSection").length > 0)) {
                    isTargetOrganizationEnabled = ($('#targetOrgSection').css('display') != 'none');
                }

                if (isTargetByUserEnabled || isTargetOrganizationEnabled) {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(true);
                } else {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(false);
                }

                athoc.iws.publishing.geo.geoTargetMap.setUserTargetable(isTargetByUserEnabled);
                athoc.iws.publishing.geo.geoTargetMap.setOrgTargetable(isTargetOrganizationEnabled);

                athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();

                athoc.iws.publishing.geo.geoTargetMap.isTargetingUser = isTargetByUserEnabled;
                athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg = isTargetOrganizationEnabled;


                athoc.iws.publishing.geo.geoTargetMap.show(params);

                /*IWS-19267 - Creating mini map instance using leaflet*/
                require(["widget/Map"], function (Map) {

                    if (!athoc.iws.publishing.geo.miniMap) {
                        // updating map div visible
                        athoc.iws.publishing.content.viewModel.isGeoSelected(true);
                        athoc.iws.publishing.geo.miniMap = new Map("miniMapHolder", { i18n: athoc.iws.publishing.mapResources,zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                    }
                });
            },

            //remove/clear shapes
            remove: function () {
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                    athoc.iws.publishing.geo.loadMap();
                }
                athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                athoc.iws.publishing.geo.viewModel.geoImageUrl('');
                athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();
                athoc.iws.publishing.geo.geoJson = null;
                athoc.iws.publishing.geo.updateTargetingSummary();
                athoc.iws.publishing.geo.viewModel.isUsersTargeted(false);
                athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(false);
                if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                    athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(false);
                    athoc.iws.publishing.targetOrg.OrgViewModel.OrgCountByArea(0);
                    athoc.iws.publishing.targetOrg.OrgViewModel.SelectedOrgsByArea([]);
                }
                athoc.iws.publishing.geo.updateContactPieChart();
                athoc.iws.publishing.content.checkReadyNotReady();
            },

            //edit alert/scenario location
            edit: function () {
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                    athoc.iws.publishing.geo.loadMap();
                }
                var isTargetByUserEnabled = (($("#targetArea").length > 0) && ($('#targetArea').css('display') != 'none'));
                if (isTargetByUserEnabled) {
                    isTargetByUserEnabled = (($("#publishing-user-edit").length > 0) && ($('#publishing-user-edit').css('display') != 'none'));
                }

                var isTargetOrganizationEnabled = (($(".org-by-area").length > 0) && ($('.org-by-area').css('display') != 'none'));
                if (isTargetOrganizationEnabled && ($("#alert-org-edit").length > 0)) {
                    isTargetOrganizationEnabled = ($('#alert-org-edit').css('display') != 'none');
                } else if (isTargetOrganizationEnabled && ($("#targetOrgSection").length > 0)) {
                    isTargetOrganizationEnabled = ($('#targetOrgSection').css('display') != 'none');
                }

                if (isTargetByUserEnabled || isTargetOrganizationEnabled) {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(true);
                } else {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(false);
                }

                athoc.iws.publishing.geo.geoTargetMap.setUserTargetable(isTargetByUserEnabled);
                athoc.iws.publishing.geo.geoTargetMap.setOrgTargetable(isTargetOrganizationEnabled);

                /*athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();
                if (athoc.iws.publishing.geo.geoJson != null) {
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.restore(athoc.iws.publishing.geo.geoJson);
                } */

                athoc.iws.publishing.geo.geoTargetMap.isTargetingUser = athoc.iws.publishing.geo.viewModel.isUsersTargeted() && isTargetByUserEnabled;                
                athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg = athoc.iws.publishing.targetOrg.OrgViewModel && athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea() && isTargetOrganizationEnabled;

                athoc.iws.publishing.geo.geoTargetMap.show();
            },

            //reflect map selection in targeting summary
            updateTargetingSummary: function () {
                var objectCount = 0, nonPoint;
                if (athoc.iws.publishing.geo.geoJson
                    && athoc.iws.publishing.geo.geoJson.features
                    && athoc.iws.publishing.geo.viewModel.isUsersTargeted()) {
                    nonPoint = $.grep(athoc.iws.publishing.geo.geoJson.features, function (item, idx) {
                        return item.geometry.type.toLowerCase() !== 'point';
                    });
                    objectCount = nonPoint.length;
                }

                if(athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria)
                athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria(objectCount);
            },

            //update contact pie chart based on geo-location
            updateContactPieChart: function () {
                athoc.iws.publishing.targetUsers.updateContactInfo();
                athoc.iws.publishing.targetUsers.targetingChanged();
            },

            //apply map changes from add/edit dialog 
            applyMapChanges: function () {
                //TODO: apply map changes may be recalculate users (not sure yet)
            },

            //make a json call to get users and organizations based on selected area
            getUsersAndOrgsForSelectedArea: function () {
                //TODO: send shape information in ajax request and get user and organization
            },

        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.targetUsers.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.targetUsers = function () {
        return {
            Parameters: {},
            viewModelInstance: {},
            //Viewmodel for the Target section in readonly
            ReadonlyviewModel: {},
            SelectedGroupedDevices: function () {
                var selectedDevices = [];
                var lastGroup = '';
                if ((athoc.iws.publishing.source == null || athoc.iws.publishing.source == '') && (this.viewModelInstance.Devices!== undefined)) {
                    _.each(this.viewModelInstance.Devices(), function (item, index) {
                        if (item.Selected()) {
                            var groupChanged = false;
                            if (lastGroup != item.GroupName()) {
                                groupChanged = true;
                                lastGroup = item.GroupName();
                            }
                            var device = { DeviceId: item.DeviceId, DeviceName: item.DeviceName, GroupChange: groupChanged, GroupId: item.GroupId, GroupName: item.GroupName, HideInReadOnlyView: item.HideInReadOnlyView, Reach: item.Reach, Selected: true, CustomText: ko.observable(null) };
                            selectedDevices.push(device);
                        }
                    });
                } else {
                    if (athoc.iws.publishing.view !== undefined) {
                        _.each(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices(), function (item, index) {
                            var groupChanged = false;
                            //if (lastGroup != item.GroupName) {
                            groupChanged = true;
                            lastGroup = item.GroupName;
                            var device = { DeviceId: item.DeviceId, DeviceName: item.DeviceName, GroupChange: groupChanged, GroupId: item.GroupId, GroupName: item.GroupName, HideInReadOnlyView: item.HideInReadOnlyView, Reach: item.Reach, Selected: true, CustomText: ko.observable(null) };
                            selectedDevices.push(device);
                            //}
                        });
                    }

                }

                return { Devices: selectedDevices };
            },

            SessionId: {},
            TreeIsSelected: false,
            PieDataSource: null,
            PieChartObject: null,
            //is section ready to publish
            isReadyToPublish: false,

            //is in error state
            isInErrorState: true,
            summaryDivTrmplate: "<div class=\"summary-row ellipsis\" title='{1}'>{0}</div>",
            DeviceGroupOptions: new Array(),
            presetDeviceOptions: new Array(),

            advancedQueryCriteria: null,
            treeIsLoaded: false,
            deviceOptionIsLoaded: false,
            clearingAllCriteria: false,

            setPresetDeviceOptions: function (presetDeviceGroupOptions) {
                this.presetDeviceOptions = presetDeviceGroupOptions;
            },
            bind: function (data, presetDeviceGroupOptions) {
                var self = this;
                self.advancedQueryCriteria = null;

                this.targetGroupInstance.LoadViewModel(data);

                /*
                var deliveryOrders = [1];
                if (data.MaxDelivery) {
                    for (var i = 2; i <= data.MaxDelivery; i++) {
                        deliveryOrders.push(i);
                    }
                }
                self.viewModelInstance.DeliveryOrderList = ko.observable(deliveryOrders);
                */

                if (typeof data.TargetedUserCountForLiveEndedAlert != "undefined") {
                    this.targetGroupInstance.ViewModel.set("TargetedUserCountForLiveEndedAlert", data.TargetedUserCountForLiveEndedAlert);
                }

                this.presetDeviceOptions = presetDeviceGroupOptions;
                //load query builder  

                /*$(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder({
                    options: this.Parameters.queryBuilderParameters
                });
                */

                var onShown = function (queryDivSelector) {
                    return function () {
                        self.viewModelInstance.numberQueryCriteria($(queryDivSelector).athocQueryBuilder("getCurrentSelections").selections.length);

                        //update contact pie chart
                        var tempCriteria = $(queryDivSelector).athocQueryBuilder("getCurrentSelections");
                        athoc.iws.publishing.detail.isQueryLoaded = true;

                        athoc.iws.publishing.targetUsers.updateContactInfo();
                        self.advancedQueryCriteria = tempCriteria;
                        if (athoc.iws.publishing.detail.viewModel.ScenarioSettings && athoc.iws.scenario) {                        
                            athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(athoc.iws.publishing.detail.viewModel.ScenarioSettings.Targeting.EnabledTargetingTypes);
                        }

                        self.targetingChanged();
                    };
                }(this.Parameters.queryBuilderParameters.queryBuilderDiv);

                $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setOnShownFunction", onShown);

                var onChanged = function (queryDivSelector) {
                    return function () {
                        self.viewModelInstance.numberQueryCriteria($(queryDivSelector).athocQueryBuilder("getCurrentSelections").selections.length);

                        //update contact pie chart
                        var tempCriteria = $(queryDivSelector).athocQueryBuilder("getCurrentSelections");

                        athoc.iws.publishing.detail.isQueryLoaded = true;
                        if (!self.isQueryCriteriaEqual(tempCriteria, self.advancedQueryCriteria) && !self.clearingAllCriteria) {

                            athoc.iws.publishing.targetUsers.updateContactInfo();
                        }
                        self.advancedQueryCriteria = tempCriteria;

                        athoc.iws.publishing.scenario.isChanged = true;
                        athoc.iws.publishing.targetUsers.targetingChanged();
                    };
                }(this.Parameters.queryBuilderParameters.queryBuilderDiv);

                $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setOnChangedFunction", onChanged);


                if (data.TargetedCriteria && data.TargetedCriteria.selections) {
                    $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setPreselections", data.TargetedCriteria.selections);
                } else {
                    $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setPreselections", null);
                }
                $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("show");
            },

            //helper function to compare query criteria
            isQueryCriteriaEqual: function (criteriaOne, criteriaTwo) {
                try {
                    return criteriaOne.display.join() == criteriaTwo.display.join();
                } catch (e) {
                    return true;
                }
            },

            getModel: function () {
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly && athoc.iws.publishing.targetUsers.isReadyToPublish && !$("#alert-user-edit").is(':visible')) {
                    var targetusersByArea = false;
                    if (athoc.iws.publishing.geo.viewModel.isGeoSelected() && athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetUsersByArea()) {
                        targetusersByArea = true;
                    }
                    return {
                        Devices: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices),
                        TargetingNodes: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes),
                        TargetedCriteria: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetedCriteria),
                        DeviceGroupOptions: this.DeviceGroupOptions, //IWS-14434: send device options in this case as well they are already set properly by client script
                        TargetedBlockedUsers: athoc.iws.publishing.view.viewModel.TargetedBlockerUsersList,
                        TargetUsersByArea: targetusersByArea
                    };

                }
                else {
                    //convert viewmodel to the format that will be set to server side with all of other sections. 
                    //this.TargetUsersViewModel.Devices([1034]);
                    var checkedDevices = ko.mapping.toJS(this.viewModelInstance.Devices()).filter(function (el) {
                        return el.Selected;
                    });
                    var targetusersByArea = false;
                    if (athoc.iws.publishing.geo.viewModel.isUsersTargeted() && athoc.iws.publishing.geo.geoJson != null) {
                        targetusersByArea = true;
                    }
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria(0);
                    var advanceCriteriaModel = null;
                    var advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (this.viewModelInstance.numberQueryCriteria() > 0);
                    if (advancedCriteriaSelected) {
                        advanceCriteriaModel = $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("getCurrentSelections");
                    }
                    return {
                        Devices: checkedDevices,
                        TargetingNodes: this.targetGroupInstance.ViewModel.get("SelectedNodes"),
                        TargetedCriteria: advanceCriteriaModel,
                        DeviceGroupOptions: this.DeviceGroupOptions,
                        TargetedBlockedUsers: athoc.iws.publishing.iut.getModel(),
                        TargetUsersByArea: targetusersByArea
                    };
                }
            },

            refresh: function (entityId) {
                this.treeIsLoaded = false;
                this.deviceOptionIsLoaded = false;

                //refresh will re-initialize the view model as well as rebinding the controls
                //re-create view model
                this.targetGroupInstance.LoadViewModel();

                kendo.ui.progress($("#publishing-user-edit"), true);
                $(".alert-nav").attr("disabled", true);
                $(".severity-list").find("button").prop("disabled", true);


                athoc.iws.publishing.detail.checkStatusChange();

                //making a single ajax call to get targeting tree and device data
                var ajaxSuccessWrapper = function (context) {

                    $(".severity-list").find("button").prop("disabled", false);
                    $(".severity-list").find("button").focus();

                    return function (data) {
                        //kendo.ui.progress($("#divDevices, #divTgTree"), false); //must show now loading until device option is done loading, to meet desktop popup requirement
                        $("#treeview").show();

                        var deliveryOrders = [1];
                        if (data.PhoneCount) {
                            for (var i = 2; i <= data.PhoneCount; i++) {
                                deliveryOrders.push(i);
                            }
                        }
                        //self.viewModelInstance.DeliveryOrderList = ko.observable(deliveryOrders);
                        ko.mapping.fromJS(deliveryOrders, {}, context.viewModelInstance.DeliveryOrderList);


                        ko.mapping.fromJS(data.Devices, {}, context.viewModelInstance.Devices);
                        ko.mapping.fromJS(data.DeviceGroups, {}, context.viewModelInstance.DeviceGroups);

                        athoc.iws.publishing.targetUsers.targetGroupInstance.RefreshTreeView(data);

                        var onSave = function (selectedOptions) {
                            context.DeviceGroupOptions = selectedOptions;
                        }

                        var onLoadDone = function (selectedOptions) {
                            context.deviceOptionIsLoaded = true;
                            if (context.treeIsLoaded) { //must check to make sure both tree and device option  is loaded. 
                                $(".alert-nav").attr("disabled", false);
                            }
                            context.DeviceGroupOptions = selectedOptions;
                            kendo.ui.progress($("#publishing-user-edit"), false);

                            $(".alert-nav").attr("disabled", false);

                            
                            
                        }

                        athoc.iws.publishing.personalDeviceOptions.load(ko.mapping.toJS(context.viewModelInstance.Devices()), context.presetDeviceOptions, onSave, onLoadDone);                        
                        if (athoc.iws.publishing.detail.viewModel.ScenarioSettings && athoc.iws.scenario) {
                            athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(athoc.iws.publishing.detail.viewModel.ScenarioSettings.Targeting.EnabledTargetingTypes);
                        }



                    }
                }(this);

                var targetingInfoSuccess = function (data) {
                    ajaxSuccessWrapper(data);
                    athoc.iws.publishing.detail.checkStatusChange(true);
                };

                var targetingInfoError = function (e) {
                    kendo.ui.progress($("#publishing-user-edit"), false);
                    var errorCallBack = function (returnedErrorObject) {
                        $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    };
                }
                var param1;
                var param2;
                var param3;
                if (athoc.iws.alert == undefined) {
                    param1 = entityId;
                    param2 = "";
                    param3 = "";

                } else if (athoc.iws.alert.action == 'rbt') {
                    param1 = athoc.iws.publishing.rbt.AlertId;
                    param2 = "rbt";
                    param3 = athoc.iws.publishing.rbt.IncludeDevices == true ? 0 : athoc.iws.publishing.rbt.DeviceId;
                } else {
                    param1 = entityId;
                    param2 = "";
                    param3 = "";
                }

                var ajaxOptions = {
                    cache: false,
                    url: athoc.iws.publishing.urls.GetDeviceListUrl,
                    data: { context: this.Parameters.context, id: param1, recipientType: param2, deviceId: param3 },
                    type: "POST"
                };

                var ajaxOptions = $.extend({}, AjaxUtility(targetingInfoError, targetingInfoSuccess).ajaxPostOptions, ajaxOptions);
                $.ajax(ajaxOptions);
            },

            loadTargetUsersViewModel: function () {
                var targetVM = function (context) {
                    var self = this;
                    self.Devices = ko.observableArray();
                    self.DeviceGroups = ko.observableArray();

                    self.UsersCount = ko.observable(0);

                    self.ShowUsers = ko.observable(true);

                    self.ReachableUsers = ko.observable(0);
                    self.ReachableUsersPercentage = ko.observable(0);

                    self.UnReachableUsers = ko.observable(0);
                    self.UnReachableUsersPercentage = ko.observable(0);
                    self.numberQueryCriteria = ko.observable(0);
                    self.numberAreaCriteria = ko.observable(0);

                    self.numberOfDevices = ko.observable(0);

                    self.DeliveryOrderList = ko.observable([]);

                    self.AnyDeviceSelected = function () {
                        var checkedDevices = ko.mapping.toJS(self.Devices()).filter(function (el) {
                            return el.Selected;
                        });

                        return checkedDevices.length > 0;
                    };
                    self.toggleDeviceOptionLink = function () {
                        if (!self.AnyDeviceSelected()) {
                            $(context.Parameters.personalDeviceOptionsLink).toggleClass("link-disabled", true);
                            $("#personalDeviceOptionsLink").attr("disabled", true);
                        } else {
                            $(context.Parameters.personalDeviceOptionsLink).toggleClass("link-disabled", false);
                            $("#personalDeviceOptionsLink").attr("disabled", false);
                        }

                    };
                    self.deviceChanged = function (device) {
                        kendo.ui.progress($("#publishing-user-edit"), true);

                        var checkedDevices = ko.mapping.toJS(context.viewModelInstance.Devices()).filter(function (el) {
                            return el.Selected;
                        });
                        $(".alert-nav").attr("disabled", true);
                        $(".severity-list").find("button").prop("disabled", true)

                        context.viewModelInstance.numberOfDevices(checkedDevices.length);

                        var onLoadDone = function (selectedOptions) {
                            kendo.ui.progress($("#publishing-user-edit"), false);
                            $(".alert-nav").attr("disabled", false);
                            $(".severity-list").find("button").prop("disabled", false);
                            context.DeviceGroupOptions = selectedOptions;
                        }

                        athoc.iws.publishing.personalDeviceOptions.loadOnlyNewDeviceGroups(checkedDevices, onLoadDone);
                        context.updateContactInfo();
                        context.targetingChanged();
                        self.toggleDeviceOptionLink();
                        athoc.iws.publishing.scenario.isChanged = true;
                        return true;
                    }

                    self.DisplayUserList = function () {
                        //alert("You have to pass sessionId to the user list  popup, which is " + context.SessionId + " For info on how to pass session Id and also get columns, pls talk to tarun.");
                        //to show readOnlyUserList
                        if (self.UsersCount() > 0) {
                            $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.readOnlyUserCountTitle);
                            //Condition is added to ShowUsersList in readonly mode
                            athoc.iws.publishing.iut.ShowUsersList(athoc.iws.publishing.source == "readonly" ? athoc.iws.publishing.view.viewModel.data.SessionId : context.SessionId, -1, "", self.UsersCount());
                        }
                    }

                    self.GetReachableUserList = function () {
                        if (self.ReachableUsers() > 0) {
                            self.LaunchContactInfoUserList(1);
                        }
                    }

                    self.GetUnReachableUserList = function () {
                        if (self.UnReachableUsers() > 0) {
                            self.LaunchContactInfoUserList(0);
                        }
                    }

                    self.LaunchContactInfoUserList = function (covered) {
                        var checkedDevices = null;
                        if (athoc.iws.publishing.source == 'p' || athoc.iws.publishing.source == 'h') {
                            checkedDevices = ko.mapping.toJS(this.ReadonlyviewModel.Devices()).filter(function (el) {
                                return el.Selected;
                            }).map(function (item) { return item.DeviceId; });
                        }
                        else {
                            var checkedDevices = ko.mapping.toJS(self.Devices()).filter(function (el) {
                                return el.Selected;
                            }).map(function (item) { return item.DeviceId; });
                        }

                        var attributeIdCSV = checkedDevices.join(",");
                        //to show readOnlyUserList
                        if (covered == 1)
                            $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.readOnlyReacheableCountTitle + "(" + self.ReachableUsers() + ")");
                        else
                            $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.readOnlyNotReacheableCountTitle + "(" + self.UnReachableUsers() + ")");
                        //Condition is added to display User list in readonly mode
                        var param = (athoc.iws.publishing.source == "p" || athoc.iws.publishing.source == "h") ? athoc.iws.publishing.view.viewModel.data.SessionId : context.SessionId;
                        athoc.iws.publishing.iut.ShowUsersList(param, covered, "", covered == 1 ? self.ReachableUsers() : self.UnReachableUsers());
                    }


                    self.showQuerySummary = function () {
                        if (self.numberQueryCriteria() > 0) {
                            $(context.Parameters.dialogTargetingSummary).find("#spanTitle").text(athoc.iws.publishing.iut.resources.TargetUsers_Advanced_Query);
                            var summaryDiv = $(context.Parameters.dialogTargetingSummary).find(context.Parameters.targetingSummaryContentDiv);
                            summaryDiv.html("");
                            var selections = $(context.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("getCurrentSelections");

                            var seletionTextArray = selections.display;

                            _.each(seletionTextArray, function (item, index) {
                                if (index != 0) {
                                    summaryDiv.append("<div class=\"summary-row summary-operator-row\">" + athoc.iws.publishing.resources.Publishing_TargetUsers_Advanced_Query_Summary_And + "</div>");
                                }

                                summaryDiv.append(context.summaryDivTrmplate.format(item, selections.displayNoStyle[index]));
                                index += 1;
                            });
                            $(context.Parameters.dialogTargetingSummary).modal("show");
                        }
                    };

                    //on number of map area clicked
                    self.showAreaSummary = function () {
                        if (self.numberAreaCriteria() > 0) {
                            //Show map with objects in model window
                            $("#dialogGeoTargetingSummary").modal("show");
                        }
                    };

                    //show selected devices list
                    self.showDeviceSummary = function () {
                        if (self.numberOfDevices() > 0) {
                            //show device summary
                            $("#personalDeviceSummaryDiv").html('');
                            ko.cleanNode($("#dialogPersonalDevicesSummary").get(0));
                            var groupedDevices = athoc.iws.publishing.targetUsers.SelectedGroupedDevices();
                            ko.applyBindings(groupedDevices, $("#dialogPersonalDevicesSummary").get(0));
                            $("#dialogPersonalDevicesSummary").modal("show");
                        }
                    };

                    self.numGroupsTargeted = ko.observable(0);
                    self.numGroupsBlocked = ko.observable(0);

                    self.showTargetedGroupSummary = function () {
                        if (self.numGroupsTargeted() > 0) {
                            $(context.Parameters.dialogTargetingSummary).find("#spanTitle").text(athoc.iws.publishing.iut.resources.ByGroups);
                            var summaryDiv = $(context.Parameters.dialogTargetingSummary).find(context.Parameters.targetingSummaryContentDiv);
                            var template = kendo.template($("#groupsummary-template").html());
                            var result = template(athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.TargetedGroupsFormatted());
                            summaryDiv.html(result);
                            $(context.Parameters.dialogTargetingSummary).modal("show");
                        }
                    };

                    self.showBlockedGroupSummary = function () {
                        if (self.numGroupsBlocked() > 0) {
                            $(context.Parameters.dialogTargetingSummary).find("#spanTitle").text(athoc.iws.publishing.iut.resources.ByGroupsBlocked);
                            var summaryDiv = $(context.Parameters.dialogTargetingSummary).find(context.Parameters.targetingSummaryContentDiv);
                            var template = kendo.template($("#groupsummary-template").html());
                            var result = template(athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.BlockedGroupsFormatted());
                            summaryDiv.html(result);
                            $(context.Parameters.dialogTargetingSummary).modal("show");
                        }
                    };

                    self.numTargetedUsers = ko.observable(0);

                    self.showTargetedUsersSummary = function () {
                        if (self.numTargetedUsers() > 0) {
                            athoc.iws.publishing.iut.showTargetedUsersSummary(false);
                            $("#targetedUsersSummary").find("h2").html(athoc.iws.publishing.iut.resources.ByUsers + '(' + self.numTargetedUsers() + ')');
                            $("#targetedUsersSummary").modal("show");
                        }
                    };
                    self.numBlockedUsers = ko.observable(0);

                    self.showBlockedUsersSummary = function () {
                        if (self.numBlockedUsers() > 0) {
                            athoc.iws.publishing.iut.showBlockedUsersSummary(false);
                            $("#blockedUsersSummary").find("h2").html(athoc.iws.publishing.iut.resources.ByUsersBlocked + '(' + self.numBlockedUsers() + ')');
                            $("#blockedUsersSummary").modal("show");
                        }
                    };
                };

                this.viewModelInstance = new targetVM(this);

                ko.cleanNode($("#devicesListDiv").get(0));

                ko.applyBindings(this.viewModelInstance, $("#devicesListDiv").get(0));
                ko.applyBindings(this.viewModelInstance, $("#targetUsersHeaderDiv").get(0));
                ko.applyBindings(this.viewModelInstance, $("#contactInfoSummary").get(0));
                ko.applyBindings(this.viewModelInstance, $("#targetUsersSummary").get(0));
            },

            init: function (parameters) {
                self = this;
                //init is called once when the page loads for the first time.
                //all controls are created here.
                this.Parameters = parameters;
                //this.createTargetingTree();
                this.targetGroupInstance = new athoc.iws.publishing.TargetGroup('#treeview');
                this.targetGroupInstance.TreeView.bind("check", function (e) {
                    athoc.iws.publishing.scenario.isChanged = true;
                    var targetedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.TargetedGroups();
                    var blockedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.BlockedGroups();
                    athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsTargeted(targetedNodes.length);
                    athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsBlocked(blockedNodes.length);
                    athoc.iws.publishing.targetUsers.treeSelectionChanged();
                });
                this.targetGroupInstance.TreeView.bind("dataBound", function (e) {
                    if (!e.node) {
                        var targetedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.TargetedGroups();
                        var blockedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.BlockedGroups();
                        athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsTargeted(targetedNodes.length);
                        athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsBlocked(blockedNodes.length);
                        athoc.iws.publishing.targetUsers.treeSelectionChanged();

                        self.treeIsLoaded = true;
                        if (self.deviceOptionIsLoaded) { //must check to make sure both tree and device option  is loaded. 
                            $(".alert-nav").attr("disabled", false);
                        }
                    }
                });

                this.loadTargetUsersViewModel();
                this.createPieChart();

                var self = this;

                $(this.Parameters.clearAllCriteriaLink).on("click", function () {
                    self.clearingAllCriteria = true;
                    $(self.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("clearAll");
                    self.clearingAllCriteria = false;
                    athoc.iws.publishing.targetUsers.updateContactInfo();

                });

                $(this.Parameters.personalDeviceOptionsLink).on("click", function () {

                    if (self.viewModelInstance.AnyDeviceSelected()) {

                        $(self.Parameters.dialogDeviceOptions).modal("show");
                        athoc.iws.utilities.resizeModalBasedOnScreen($(self.Parameters.dialogDeviceOptions), 600, 770, 20, 170);
                    }
                });
            },

            load: function (entityId) {
                var self = this;

                //reset all of the parameters
                this.TreeIsSelected = false;
                this.DeviceIsSelected = false;
                this.viewModelInstance.UsersCount(0);
                this.viewModelInstance.Devices([]);
                athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "open");
                athoc.iws.publishing.targetUsers.isReadyToPublish = false;

                //load will be called when the detail view is visible again. 
                this.refresh(entityId);
            },

            createPieChart: function () {

                require(['publishing/athoc.iws.publishing.contactInfoPieChart'], function (ContactInfoPieChart) {
                    PieChartObject = new ContactInfoPieChart({
                        domPointer: "#contactInfo",
                        Publishing_Contact_Info_No_users_found: athoc.iws.publishing.resources.Publishing_Contact_Info_No_users_found,
                        Publishing_Contact_Info_Reachable_Tooltip: athoc.iws.publishing.resources.Publishing_Contact_Info_Reachable_Tooltip,
                        Publishing_Contact_Info_Not_Reachable_Tooltip: athoc.iws.publishing.resources.Publishing_Contact_Info_Not_Reachable_Tooltip,
                    });
                });

            },

            //Update contact chart
            updateContactInfo: function () {

                if (!athoc.iws.publishing.detail.isEverythingLoaded()) {
                    return;
                }

                var self = this;

                //turn on now loading
                self.viewModelInstance.ShowUsers(false);
                kendo.ui.progress($("#contactInfo"), true);
                //$.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $("#scenarioDetailsDiv"), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', left: '50%' }).showLoader();

                var checkedDevices = ko.mapping.toJS(this.viewModelInstance.Devices()).filter(function (el) {
                    return el.Selected;
                });

                var devices = checkedDevices.map(function (item) { return item.DeviceId; });
                this.viewModelInstance.numberOfDevices(devices.length);

                var treeNodes = this.targetGroupInstance.ViewModel.SelectedNodes;

                var advancedCriteria = null;
                //if advanced targeting is enabled get criteria
                if ($(this.Parameters.queryBuilderParameters.queryBuilderDiv).length > 0) {
                    $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder();
                    advancedCriteria = $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("getCurrentSelections");
                }

                var targetedArea = "";
                //send targeted area
                if (athoc.iws.publishing.geo.viewModel.isUsersTargeted() && athoc.iws.publishing.geo.geoJson != null) {
                    targetedArea = JSON.stringify(athoc.iws.publishing.geo.geoJson);
                }
                //send targeted users and blocked users
                var targetdUsers = athoc.iws.publishing.iut.getTargetedUsers();
                var blockedUsers = athoc.iws.publishing.iut.getBlockedUsers();

                //condition to checked whether readonly or not.
                if (athoc.iws.publishing.source != 'readonly') {
                    var userInfoSuccess = function (data) {

                        self.viewModelInstance.UsersCount(data.TotalCount);
                        self.viewModelInstance.ShowUsers(true);

                        self.SessionId = data.SessionId;

                        if (data.TotalCount == 0) {
                            self.resetReach();
                        } else {
                            _.each(data.ContactInfo.ContactInfo, function (item, index) {
                                var found = _.find(self.viewModelInstance.Devices(), function (itemVM) {
                                    return (itemVM.DeviceId() == item.DeviceId);
                                });

                                if (found) {
                                    found.Reach(item.Percentage);
                                }
                            });

                            //set up summary
                            self.viewModelInstance.ReachableUsers(data.ContactInfo.TotalCovered);
                            self.viewModelInstance.ReachableUsersPercentage(data.ContactInfo.TotalCoveredPercentage);

                            self.viewModelInstance.UnReachableUsers(data.ContactInfo.TotalNotCovered);
                            self.viewModelInstance.UnReachableUsersPercentage(data.ContactInfo.TotalNotCoveredPercentage);


                            //draw pie
                            var contactInfo = [{
                                "type": "covered",
                                "number": data.ContactInfo.TotalCovered,
                                "color": "#7CB500",
                                "customPercentage": data.ContactInfo.TotalCoveredPercentage
                            }, {
                                "type": "notcovered",
                                "number": data.ContactInfo.TotalNotCovered,
                                "color": "#AE004B",
                                "customPercentage": data.ContactInfo.TotalNotCoveredPercentage
                            }];
                            PieChartObject.update(contactInfo);

                        }
                        if (data.ContactInfo.TotalCovered > 0 || data.ContactInfo.TotalNotCovered > 0)
                            $("#contactInfo").css("cursor", "pointer");
                        else
                            $("#contactInfo").css("cursor", "default");
                        //$.AjaxLoader.hideLoader();
                        kendo.ui.progress($("#contactInfo"), false);


                        if (athoc.iws.publishing.contextName == "Alert") {
                            athoc.iws.scenario.settings.applyVisibleSettingsOnAlert();
                        }

                        if ($("#personalDeviceOptionsLink"))
                            if (athoc.iws.publishing.targetUsers.viewModelInstance.AnyDeviceSelected()) {
                                $("#personalDeviceOptionsLink").toggleClass("link-disabled", false);
                            } else {
                                $("#personalDeviceOptionsLink").toggleClass("link-disabled", true);
                            }

                    };

                    var userInfoError = function (error) {
                        self.viewModelInstance.UsersCount(0);
                        self.viewModelInstance.ShowUsers(true);

                        //$.AjaxLoader.hideLoader();
                        kendo.ui.progress($("#contactInfo"), false);
                    };
                    athoc.iws.publishing.UpdateContactInfo(0, "", treeNodes, devices, userInfoSuccess, userInfoError, advancedCriteria, targetedArea, targetdUsers, blockedUsers, athoc.iws.publishing.rbt);
                }
            },

            resetReach: function () {
                _.each(this.viewModelInstance.Devices(), function (itemVM) {
                    itemVM.Reach(0);
                });

                this.viewModelInstance.ReachableUsers(0);
                this.viewModelInstance.ReachableUsersPercentage(0);

                this.viewModelInstance.UnReachableUsers(0);
                this.viewModelInstance.UnReachableUsersPercentage(0);

                //draw pie
                var contactInfo = [{
                    "type": "none",
                    "number": 100,
                    "color": "#ccc"
                }];

                PieChartObject.update(contactInfo);
                //$("#contactInfo").data("kendoChart").dataSource.data(contactInfo);

            },

            treeSelectionChanged: function () {

                this.TreeIsSelected = (this.targetGroupInstance.ViewModel.SelectedNodes.length != 0);

                this.targetingChanged();

                athoc.iws.publishing.detail.isTreeLoaded = true;

                if (this.TreeIsSelected) {
                    this.updateContactInfo();
                } else {
                    this.viewModelInstance.UsersCount(0);
                    this.updateContactInfo();
                }
            },

            targetingChanged: function () {
                //if advanced targeting is enabled get criteria
                // var advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (this.viewModelInstance.numberQueryCriteria() > 0);
                var advancedCriteriaSelected = 0;
                if ((athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "AccountEvent")
                    && athoc.iws.scenario.settings.ReadonlyViewModel != null && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly) {
                    advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (athoc.iws.publishing.view.viewModel.QueryCriteriaCount() > 0);
                } else {
                    advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (this.viewModelInstance.numberQueryCriteria() > 0);
                }

                //is target by area selected
                var targetByAreaSelected = (athoc.iws.publishing.settings.IsTargetByAreaSupported)
                    && (athoc.iws.publishing.geo.viewModel.isGeoSelected())
                    && (athoc.iws.publishing.geo.viewModel.isUsersTargeted());

                //is IUT selected
                var iutTargeted = (athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList().length > 0);

                //check if any of targeting is selected
                var anyTargetingSelected = (this.TreeIsSelected
                    || iutTargeted
                    || advancedCriteriaSelected
                    || targetByAreaSelected || (athoc.iws.publishing.rbt != null));

                if (anyTargetingSelected && this.viewModelInstance.AnyDeviceSelected()) {
                    athoc.iws.publishing.targetUsers.isReadyToPublish = true;
                    athoc.iws.publishing.targetUsers.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "ready");
                } else if (anyTargetingSelected || this.viewModelInstance.AnyDeviceSelected()) {
                    athoc.iws.publishing.targetUsers.isReadyToPublish = false;
                    athoc.iws.publishing.targetUsers.isInErrorState = true;
                    athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "notReady");
                } else {
                    athoc.iws.publishing.targetUsers.isReadyToPublish = false;
                    athoc.iws.publishing.targetUsers.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "open");

                }


                if (athoc.iws.publishing.contextName == "Scenario")
                    athoc.iws.scenario.schedule.isActiveRecurrenceEnabled();


            },

            resetTargetingInfo: function () {
                $("#treeview").hide();
                this.resetReach();
            },

            getTargetedUsersCount: function (cnt) {
                athoc.iws.publishing.targetUsers.viewModelInstance.numTargetedUsers(cnt);
            },

            getBlockedUsersCount: function (cnt) {
                athoc.iws.publishing.targetUsers.viewModelInstance.numBlockedUsers(cnt);
            },

            pieChartClick: function (e) {
                if (e.category == "covered") {
                    if (athoc.iws.publishing.source == 'p' || athoc.iws.publishing.source == 'h' || athoc.iws.publishing.source == 'a' || athoc.iws.publishing.source == 'readonly') {
                        athoc.iws.alert.reviewandpublish.GetReachableUserList(1);
                    }
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.GetReachableUserList(1);
                }
                else if (e.category == "notcovered") {
                    if (athoc.iws.publishing.source == 'p' || athoc.iws.publishing.source == 'h' || athoc.iws.publishing.source == 'a' || athoc.iws.publishing.source == 'readonly') {
                        athoc.iws.alert.reviewandpublish.GetUnReachableUserList(0);
                    }
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.GetUnReachableUserList(0);
                }
            },

            //bind contact data to target section in readonly
            applyReadonlySettingsOnTargetUsers: function (data, targetDiv) {

                var targetVM = function (context) {
                    var self = this;
                    //Contact info
                    self.targetedBlockerUsersList = data.TargetUsers.TargetedBlockedUsers;
                    self.ContactinfoTotalCoveredNumber = ko.observable(0);
                    self.ContactinfoTotalCoveredPercentage = ko.observable(0);
                    self.ContactinfoNotCoveredNumber = ko.observable(0);
                    self.ContactinfoNotCoveredPercentage = ko.observable(0);
                    self.TotalUsers = ko.observable(0);
                    if (athoc.iws.publishing.iut != undefined && athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList() == null && data.TargetUsers.TargetedBlockedUsers != null)
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(data.TargetUsers.TargetedBlockedUsers);
                    self.Devices = ko.observableArray();
                    self.TargetingTree = ko.observableArray();
                    self.groupedDevices = ko.observableArray();
                    self.numberQueryCriteria = ko.observable(0);
                    self.numberAreaCriteria = ko.observable(0);

                    self.numberOfDevices = ko.observable(0);
                    self.DeliveryOrderList = ko.observableArray();
                    self.numGroupsTargeted = ko.observable(0);
                    self.numGroupsBlocked = ko.observable(0);
                    self.numTargetedUsers = ko.observable(0);
                    self.numBlockedUsers = ko.observable(0);
                    self.targetedUsers = ko.observableArray();
                    self.getTargetedUsers = function () {
                        var targetdata = [];
                        _.each(data.TargetUsers.TargetedBlockedUsers, function (item, index) {
                            if (!item.IsBlocked) {
                                targetdata.push(item.UserId);
                            }

                        });
                        return targetdata;
                    };
                    self.targetedBlockedUsers = ko.observableArray();
                    self.getBlockedUsers = function () {
                        var targetdata = [];
                        _.each(data.TargetUsers.TargetedBlockedUsers, function (item, index) {
                            if (item.IsBlocked) {
                                targetdata.push(item.UserId);
                            }

                        });
                        return targetdata;
                    };

                    self.showQuerySummary = function () {
                        if (self.numberQueryCriteria() > 0) {
                            $("#dialogTargetingSummary").find("#spanTitle").text(athoc.iws.publishing.iut.resources.TargetUsers_Advanced_Query);
                            var summaryDiv = $("#dialogTargetingSummary").find("#targetingSummaryContentDiv");
                            summaryDiv.html("");
                            var selections = $("#queryBuilderDiv").athocQueryBuilder("getCurrentSelections");

                            var seletionTextArray = selections.display;

                            _.each(seletionTextArray, function (item, index) {
                                if (index != 0) {
                                    summaryDiv.append("<div class=\"summary-row summary-operator-row\">" + athoc.iws.publishing.resources.Publishing_TargetUsers_Advanced_Query_Summary_And + "</div>");
                                }

                                summaryDiv.append(context.summaryDivTrmplate.format(item, selections.displayNoStyle[index]));
                                index += 1;
                            });
                            $("#dialogTargetingSummary").modal("show");
                        }
                    };

                    //on number of map area clicked
                    self.showAreaSummary = function () {
                        if (self.numberAreaCriteria() > 0) {
                            //Show map with objects in model window
                            $("#dialogGeoTargetingSummary").modal("show");
                        }
                    };

                    //show selected devices list
                    self.showDeviceSummary = function () {
                        if (self.numberOfDevices() > 0) {
                            //show device summary
                            $("#personalDeviceSummaryDiv").html('');
                            ko.cleanNode($("#dialogPersonalDevicesSummary").get(0));
                            var groupedDevices = athoc.iws.publishing.targetUsers.SelectedGroupedDevices();
                            ko.applyBindings(groupedDevices, $("#dialogPersonalDevicesSummary").get(0));
                            $("#dialogPersonalDevicesSummary").modal("show");
                        }
                    };

                    self.showTargetedGroupSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numGroupsTargeted() > 0) {
                            var result = "";
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.ByGroups);
                            var summaryDiv = $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP");
                            var template = kendo.template($("#groupsummary-template-RP").html());
                            result = template(athoc.iws.alert.reviewandpublish.TargetedGroupsFormatted());
                            summaryDiv.html(result);
                        }
                    };

                    self.showBlockedGroupSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numGroupsBlocked() > 0) {
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.ByGroupsBlocked);
                            var summaryDiv = $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP");
                            var template = kendo.template($("#groupsummary-template-RP").html());
                            var result = "";
                            result = template(athoc.iws.alert.reviewandpublish.BlockedGroupsFormatted());
                            summaryDiv.html(result);
                        }
                    };

                    self.showTargetedUsersSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numTargetedUsers() > 0) {
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            athoc.iws.alert.reviewandpublish.showTargetedUsersSummary();
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.ByUsers + '(' + self.numTargetedUsers() + ')');
                        }
                    };

                    self.showBlockedUsersSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numBlockedUsers() > 0) {
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            athoc.iws.alert.reviewandpublish.showBlockedUsersSummary();
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.ByUsersBlocked + '(' + self.numBlockedUsers() + ')');
                        }
                    };

                    self.SelectedGroupedDevices = function () {
                        var selectedDevices = [];
                        var lastGroup = '';
                        _.each(this.ReadonlyviewModel.Devices(), function (item, index) {
                            if (item.Selected()) {
                                var groupChanged = false;
                                if (lastGroup != item.GroupName()) {
                                    groupChanged = true;
                                    lastGroup = item.GroupName();
                                }
                                var device = { DeviceId: item.DeviceId, DeviceName: item.DeviceName, GroupChange: groupChanged, GroupId: item.GroupId, GroupName: item.GroupName, HideInReadOnlyView: item.HideInReadOnlyView, Reach: item.Reach, Selected: true };
                                selectedDevices.push(device);
                            }
                        });

                        return { Devices: selectedDevices };
                    };

                    self.GetReachableUserList = function () {
                        athoc.iws.alert.reviewandpublish.LaunchContactInfoUserList(1);
                    };

                    self.GetUnReachableUserList = function () {
                        athoc.iws.alert.reviewandpublish.LaunchContactInfoUserList(0);
                    };
                    self.DisplayUserList = function () {
                        $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.readOnlyUserCountTitle);
                        athoc.iws.alert.reviewandpublish.ShowUsersList(athoc.iws.alert.reviewandpublish.SessionId, -1, "", athoc.iws.publishing.targetUsers.ReadonlyviewModel.TotalUsers());
                    };
                };

                this.ReadonlyviewModel = new targetVM(this);

                //do knockout binding using viewModel
                ko.cleanNode(targetDiv.find(".contact-info-section").get(0));
                ko.cleanNode(targetDiv.find(".contact-info-section").get(1));
                ko.cleanNode(targetDiv.find("#targetSummaryDetail").get(0));
                ko.cleanNode(targetDiv.find("#PersonalDeviceListDetail").get(0));

                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find(".contact-info-section").get(0));
                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find(".contact-info-section").get(1));
                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find("#targetSummaryDetail").get(0));


                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find("#targetSummaryDetail").get(0));
                //Skip ajax call : in Edit Mode
                //if (athoc.iws.publishing.source == "a" && (athoc.iws.scenario.settings != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting != undefined && !athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly)) {
                if (athoc.iws.publishing.source == "a" && (athoc.iws.publishing.source != "readonly")) {
                    ko.mapping.fromJS(data.TargetUsers.Devices, {}, this.ReadonlyviewModel.Devices);
                    ko.mapping.fromJS(data.TargetUsers.TargetingTree, {}, this.ReadonlyviewModel.TargetingTree);
                    athoc.iws.publishing.view.showContactInfo();
                }
                else {

                    //making a single ajax call to get targeting tree and device data
                    var ajaxSuccessWrapper = function (context) {
                        return function (data) {
                            ko.mapping.fromJS(data.Devices, {}, context.ReadonlyviewModel.Devices);
                            ko.mapping.fromJS(data.TargetingTree, {}, context.ReadonlyviewModel.TargetingTree);
                        }
                    }(this);

                    var targetingInfoSuccess = function (data) {
                        ajaxSuccessWrapper(data);

                        athoc.iws.publishing.view.showContactInfo();


                    };

                    var targetingInfoError = function (e) {
                        kendo.ui.progress($("#publishing-user-detail"), false);
                        var errorCallBack = function (returnedErrorObject) {
                            $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        };
                    }
                    //need to check context
                    var paramcontext = 'Scenario';

                    if (athoc.iws.alert.action == 'rbt') {
                        param1 = athoc.iws.alert.rbt.AlertId;
                        param2 = athoc.iws.alert.rbt.EntityFilterId;
                        paramcontext = 'Alert';

                    } else if (athoc.iws.alert.action == "v") {
                        param1 = athoc.iws.alert.id;
                        paramcontext = 'Alert';
                        param2 = "";
                    } else {
                        param1 = data.EntityId == 0 ? data.ParentId : data.EntityId;
                        param2 = "";
                    }

                    var ajaxOptions = {
                        cache: false,
                        url: athoc.iws.publishing.urls.GetDeviceListUrl,
                        data: { context: paramcontext, id: param1, recipientType: param2 },
                        type: "POST"
                    };

                    var ajaxOptions = $.extend({}, AjaxUtility(targetingInfoError, targetingInfoSuccess).ajaxPostOptions, ajaxOptions);
                    $.ajax(ajaxOptions);

                    //End
                }
            },

            refreshPersonalDevices: function (data) {
                /* var deletedItems = [];
                 _.each(athoc.iws.publishing.targetUsers.viewModelInstance.Devices(), function (item, index) {
                     var flag = _.find(data, function (device) {
                         return (device.DeviceId == item.DeviceId());
                     });
                     if (flag == null) {
                         deletedItems.push(item.DeviceId());
                     }
                 });
                 _.each(data, function (obj, index) {
                     var newDevice = _.find(athoc.iws.publishing.targetUsers.viewModelInstance.Devices(), function (device) {
                         return device.DeviceId() == obj.DeviceId;
                     });
                     if (newDevice == null) {
                         //obj.GroupChange = true;
                         obj.Selected = false;
                         athoc.iws.publishing.targetUsers.viewModelInstance.Devices.push(ko.mapping.fromJS(obj));
                     }
                 });
                 if (deletedItems.length > 0) {
                     athoc.iws.publishing.targetUsers.viewModelInstance.Devices.remove(function (i) {
                         return deletedItems.indexOf(i.DeviceId()) > -1;
                     });
                 }*/
                var selectedList = $.grep(athoc.iws.publishing.targetUsers.viewModelInstance.Devices(), function (d) {
                    return d.Selected() == true;
                });
                _.each(data, function (obj, index) {
                    var selected = _.find(selectedList, function (s) {
                        return s.DeviceId() == obj.DeviceId;
                    });
                    if (selected == null)
                        obj.Selected = false;
                });
                ko.mapping.fromJS(data, {}, athoc.iws.publishing.targetUsers.viewModelInstance.Devices);
                //athoc.iws.publishing.targetUsers.updateContactInfo();
                //athoc.iws.publishing.targetUsers.viewModelInstance.Devices().sort(function (l, r) { return [l.GroupId() < r.GroupId()] ? -1 : 1 })
                //ko.cleanNode($("#devicesListDiv").get(0));
                //ko.applyBindings(this.viewModelInstance, $("#devicesListDiv").get(0));


            },

            isThisDeviceGroupTargeted: function (groupid) {

                var checkedDevices = ko.mapping.toJS(this.viewModelInstance.Devices()).filter(function (el) {
                    return el.Selected;
                });

                for (i = 0; i < checkedDevices.length; i++) {
                    if (checkedDevices[i].GroupId == groupid) {
                        return true;
                    }
                }
                return false;
            }
        };
    }();
}


///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.targetGroup.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

athoc.iws.publishing.TargetGroup = function (treeContainer) {
    var self = this;
    this.ViewModel = kendo.observable(
                  {
                      Devices: [],
                      SelectedNodes: [],
                      TargetedUserCountForLiveEndedAlert: "0",

                      TargetedGroups: function () {
                          var nodes = this.get("SelectedNodes");
                          return $.grep(nodes, function (i) {
                              return !i.IsBlocked;
                          });
                      },

                      TargetedGroupsFormatted: function () {
                          var tg = this.TargetedGroups();
                          return self._formatGroups(tg);
                      },

                      BlockedGroups: function () {
                          var nodes = this.get("SelectedNodes");
                          return $.grep(nodes, function (i) {
                              return i.IsBlocked;
                          });
                      },

                      BlockedGroupsFormatted: function () {
                          var bg = this.BlockedGroups();
                          return self._formatGroups(bg);
                      },

                      ExpandAll: function (e) {
                          self.TreeView.expand(".k-item");
                      },
                      CollapseAll: function (e) {
                          self.TreeView.collapse(".k-item:not(li:first)");
                      },
                      Visible: function () {
                          return this.get("Devices").length > 0 && this.get("SelectedNodes").length > 0;
                      },
                  });

    this._formatGroups = function (groups) {
        var x = {};
        var nodes = groups;// this.get("SelectedNodes");
        for (var i = 0; i < nodes.length; ++i) {
            var n = nodes[i];
            switch (n.Type) {
                case 0:
                case 1:
                case 3:
                    if (x[n.Name] == undefined)
                        x[n.Name] = [];
                    x[n.Name].push({ Type: n.Type, Item: athoc.iws.publishing.resources.Publishing_TargetUsers_All_Selected });
                    break;
                case 2:
                    if (x[n.ParentName] == undefined)
                        x[n.ParentName] = [];
                    x[n.ParentName].push({ Type: n.Type, Item: n.Name });
                    break;
                case 4:
                case 5:
                    if (x[n.RootName] == undefined) {
                        x[n.RootName] = [];
                    }
                    if (n.Type == 5) {
                        x[n.RootName].push({ Type: n.Type, Item: n.Name });
                    } else {
                        if (n.Lineage) {
                            x[n.RootName].push({ Type: n.Type, Item: kendo.format("{0}{1}/", n.Lineage, n.Name) });
                        } else {
                            x[n.RootName].push({ Type: n.Type, Item: kendo.format(n.Type == 4 ? "{0}" : "/{0}/", n.Name) }); //loading on review/publish
                        }
                    }
                    break;
            }
        }
        var ret = Object.keys(x).map(function (k) {
            return { Group: k, Items: x[k], Type: x[k][0] != undefined ? x[k][0].Type : -1 }
        });
        return ret;

    };

    this.LoadViewModel = function (data) {
        if (arguments.length > 0) {
            self.ViewModel.set("SelectedNodes", data.TargetingNodes);
            self.ViewModel.set("Devices", data.Devices);
        }
        kendo.bind($(".kTGBound"), self.ViewModel);
    };

    this.toggleBlock = function (a) {
        var item = $(a).closest("li");
        //if (item.hasClass("k-state-disabled"))
        //    return;

        var node = self.TreeView.dataItem(item);
        var val = !node.get("IsBlocked");
        self._toggleBlockStateForNode(item, val);
        if (node.hasChildren)
            self._toggleBlockChildren(node.Children, val);

        //need to wait till all block state is reset and then fire check
        var checkbox = item.find(":checkbox").first();
        checkbox.trigger("click");
    };

    this.showCheckBox = function (node) {
        var ret = true;
        if (node.Type == 3 && !node.HasChildren)//if a root has no chilren, don't show checkbox
        {
            node.Name += node.SubType == 0 ? athoc.iws.publishing.resources.Publishing_TargetUsers_EmptyHierarchy : athoc.iws.publishing.resources.Publishing_TargetUsers_EmptyFolder;
            node.Type = 6; //go ahead and hide the node, treat it as a dummy node. IWS-11867
            ret = false;
        }
        else if (!node.IsTargetable) {
            ret = false;
        }
        return ret;
    };

    this._selectionChanged = function (node) {
        var targetedNodes = [];
        var blockedNodes = [];
        //due to target and block being mixed in one tree and to accomadate all scenarios, 
        //we need to traverse the tree seperately for getting targeted and blocked nodes
        self._getTargetedNodes(node, self.TreeView.dataSource.view(), targetedNodes);
        self._getBlockedNodes(node, self.TreeView.dataSource.view(), blockedNodes);
        var selectedNodes = targetedNodes.concat(blockedNodes);
        self.ViewModel.set("SelectedNodes", selectedNodes);
    };

    //check to see if the given node is a child of the parent node
    this._checkIfChildExists = function (node, nodes) {
        var childFound;
        var found = [];
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].Name == node.Name && nodes[i].Id == node.Id)
                found.push(nodes[i]);
            else if (nodes[i].hasChildren) {
                childFound = self._checkIfChildExists(node, nodes[i].Children);
                if (childFound.length > 0) {
                    //var treeNode = self.TreeView.findByUid(nodes[i].uid);
                    //var chk = treeNode.find('input:checkbox').first();
                    //var img = treeNode.find('div.targeting-sprite').first();
                    //var item = nodes[i];
                    //item.set("CommandText", "Block");
                    //item.set("IsBlocked", false);
                    //item.set("checked", false);
                    //img.hide();
                    //chk.show();
                    found = found.concat(childFound);
                }
            }
        }
        return found;
    };

    this._hideFakeNodes = function (nodes) {
        if (nodes) {
            for (var i = 0; i < nodes.length; i++) {
                var treeNode = self.TreeView.findByUid(nodes[i].uid);
                if (nodes[i].Type == 6) {
                    treeNode.hide();
                }
                if (nodes[i].hasChildren) {
                    self._hideFakeNodes(nodes[i].Children);
                }
            }
        }
    };

    //_getTargetedNodes gets the targeted nodes as well as setting the correct state of all nodes
    this._getTargetedNodes = function (node, nodes, targetedNodes, parent, root) {

        for (var i = 0; i < nodes.length; i++) {
            var treeNode = self.TreeView.findByUid(nodes[i].uid);
            var chk = treeNode.find('input:checkbox').first();
            var img = treeNode.find('div.targeting-sprite').first();
            //the below logic is to retain the block/unblock state for the parent nodes
            var found = node && nodes[i].hasChildren ? self._checkIfChildExists(node, nodes[i].Children) : [];
            if (nodes[i].IsBlocked && found.length > 0) {
                var item = nodes[i];
                item.set("CommandText", athoc.iws.scenario.resources.Publishing_TargetUsers_Block ? athoc.iws.scenario.resources.Publishing_TargetUsers_Block : athoc.iws.publishing.resources.Publishing_TargetUsers_Block);
                item.set("IsBlocked", false);//unblocking child should unblock parent
                //item.set("checked", false);
                img.hide();
                chk.show();
            }

            //Mohit: if any child is unchecked, also uncheck the fake node.
            if (node && parent && nodes[i].Type == 6 && !node.checked)
                nodes[i].set("checked", false);

            var r = !root && nodes[i].Type == 3 ? nodes[i] : root;
            //this is where we save the targeted nodes and we need to check to see if it's not blocked
            //otherwise, we need to keep traversing the tree to set the correct blocked state for each node
            if (nodes[i].checked && !nodes[i].IsBlocked && nodes[i].Type != 6 && nodes[i].IsTargetable) {
                var parentId = 0;
                var parentName = "";
                try {
                    parentId = parent.Id;
                    parentName = parent.Name;
                } catch (e) {

                }

                //creating a flat list here for save()
                targetedNodes.push({
                    Id: nodes[i].Id,
                    Name: nodes[i].Name,
                    Type: nodes[i].Type,
                    Lineage: nodes[i].Lineage,
                    ParentId: parentId,
                    ParentName: parentName,
                    SubType: nodes[i].SubType,
                    RootId: root != null ? root.Id : 0,
                    RootName: root != null ? root.Name : "",
                    DlType: nodes[i].DlType,
                    //IsBlocked: nodes[i].IsBlocked
                    //todo: add IsBlocked
                });
            }
            else if (nodes[i].hasChildren) {
                self._getTargetedNodes(node, nodes[i].children.view(), targetedNodes, nodes[i], r);
            }
        }
    };

    //_getBlockedNodes gets the blocked nodes only
    this._getBlockedNodes = function (node, nodes, blockedNodes, parent, root) {

        for (var i = 0; i < nodes.length; i++) {
            var r = !root && nodes[i].Type == 3 ? nodes[i] : root;
            //this is where we save the targeted nodes and we need to check to see if it's not blocked
            //otherwise, we need to keep traversing the tree to set the correct blocked state for each node
            if (nodes[i].IsBlocked && nodes[i].Type != 6) {
                var parentId = 0;
                var parentName = "";
                try {
                    parentId = parent.Id;
                    parentName = parent.Name;
                } catch (e) {

                }

                //creating a flat list here for save()
                blockedNodes.push({
                    Id: nodes[i].Id,
                    Name: nodes[i].Name,
                    Type: nodes[i].Type,
                    Lineage: nodes[i].Lineage,
                    ParentId: parentId,
                    ParentName: parentName,
                    SubType: nodes[i].SubType,
                    RootId: root != null ? root.Id : 0,
                    RootName: root != null ? root.Name : "",
                    DlType: nodes[i].DlType,
                    IsBlocked: nodes[i].IsBlocked
                    //todo: add IsBlocked
                });
            }
            else if (nodes[i].hasChildren) {
                self._getBlockedNodes(node, nodes[i].children.view(), blockedNodes, nodes[i], r);
            }
        }
    };

    this._initializeTreeView = function () {
        self.TreeView.updateIndeterminate();
        var lastElement = self.TreeView.wrapper.find("li:last");
        var node = self.TreeView.dataItem(lastElement);
        if (node != null && node.Type == 3)
            self.TreeView.expand(lastElement);
        self._setSort(self.TreeView.dataSource.view());
    };

    this._setSort = function (items) {
        for (var i = 0; i < items.length; i++) {

            // Only perform sorting on Distribution List Node
            if (items[i].SubType && items[i].SubType == 1) {
                if (items[i].hasChildren) {
                    items[i].children.sort({ field: "Name", dir: "asc", field: "SortOrder", dir: "asc" });
                    self._setSort(items[i].children.view());
                }
            }
        }
    };

    this._toggleBlockChildren = function (children, blocked) {
        for (var i = 0; i < children.length; i++) {
            var item = self.TreeView.findByUid(children[i].uid);
            //item.toggleClass('k-state-disabled', blocked);
            self._toggleBlockStateForNode(item, blocked);
            if (children[i].hasChildren) {
                self._toggleBlockChildren(children[i].Children, blocked);
            }
        }
    };

    this._toggleBlockStateForNode = function (treeNode, val) {
        var item = self.TreeView.dataItem(treeNode);
        item.set("CommandText", val ? (athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock ? athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock : athoc.iws.publishing.resources.Publishing_TargetUsers_Unblock) : (athoc.iws.scenario.resources.Publishing_TargetUsers_Block ? athoc.iws.scenario.resources.Publishing_TargetUsers_Block : athoc.iws.publishing.resources.Publishing_TargetUsers_Block));
        item.set("IsBlocked", val);
        item.set("checked", !val); //Mohit: block will check/uncheck nodes
        //todo: store blocked nodes...
        var chk = treeNode.find('input:checkbox').first();
        var img = treeNode.find('div.targeting-sprite').first();
        if (val) {
            chk.hide();
            img.show();
        } else {
            img.hide();
            chk.show();
        }
    };

    this.showBlockBtn = function (node) {
        var ret = athoc.iws.publishing.settings.IsGroupBlockSupported && node.Type > 0;
        if (ret && node.Type == 3 && !node.HasChildren) {
            ret = false;
        }
        return ret;
    };


    this.TreeView = $(treeContainer).kendoTreeView({
        autoBind: false,
        loadOnDemand: false,//setting this to false will cause the tree to load all child initially
        checkboxes: {
            checkChildren: true,
            template: "# if(athoc.iws.publishing.targetUsers.targetGroupInstance.showCheckBox(item)){# <div class='targeting-sprite blocked' #=item.IsBlocked ? '' : 'style=\"display:none\"' #></div><input type='checkbox' #=item.checked ? 'checked' : '' # #=item.IsBlocked ? 'style=\"display:none\"' : '' # /> #} #"
        },
        template: "<div class=\"tree-block\"># if(athoc.iws.publishing.targetUsers.targetGroupInstance.showBlockBtn(item)){# <a onclick=\"athoc.iws.publishing.targetUsers.targetGroupInstance.toggleBlock(this)\">#=item.IsBlocked? (athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock ? athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock : athoc.iws.publishing.resources.Publishing_TargetUsers_Unblock)  : (athoc.iws.scenario.resources.Publishing_TargetUsers_Block ? athoc.iws.scenario.resources.Publishing_TargetUsers_Block : athoc.iws.publishing.resources.Publishing_TargetUsers_Block)#</a>#} #</div><div class=\"ellipsis\" style=\"width:400px\" title=\"#=$.customizedHtmlEncoding(item.Name)# \">#=$.htmlEncode(item.Name)#</div>",
        check: function (e) {//check fires once when all the checked states have changed
            var item = self.TreeView.dataItem(e.node);
            self._selectionChanged(item);
        },
        dataBound: function (e) {
            if (!e.node) {//dataBound is fired for each node but not the last one
                self._initializeTreeView();
                self._hideFakeNodes(this.dataSource.view());
                self._selectionChanged();//walk through the tree and get the selection in case user press 'Save' right away w/o changing the tree selection
            }
        },
        dataTextField: "CommandText",
    }).data("kendoTreeView");

    this.RefreshTreeView = function (data) {
        self.TreeView.setDataSource(new kendo.data.HierarchicalDataSource({
            data: data.TargetingTree,
            schema: {
                model: {
                    children: "Children",//the child nodes property in the data model
                    fields: {
                        checked: {
                            from: "Selected", type: "boolean"
                        },
                    },
                },
            }
        }));
    };


}

///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.targetOrg.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.targetOrg = function () {
        return {
            Parameters: {},
            //AtHoc.IWS.Web.Controllers.OrganizationController.OrganizatioSearchParameters
            //OrgSearchParameters:{},
            //DataSource: null,
            //ViewModel: {},
            //Message: "",
            OrgViewModel: null,
            OrgInfoHolder: null,
            //is section ready to publish
            isReadyToPublish: false,
            getOrgConnectedStatus: true,
            showOrganizations: true,
            load: function (orgSelection) {
                var self = this;

                if (!self.OrgViewModel) {
                    return;
                }                

                self.OrgViewModel.Reset();

                kendo.ui.progress($(self.Parameters.orgSectionDivs.targetOrgSection), true);

                ko.mapping.fromJS(orgSelection.TargetAllOrganizations, {}, self.OrgViewModel.TargetAllOrg);
                ko.mapping.fromJS(orgSelection.TargetOrganizationsByArea, {}, self.OrgViewModel.TargetOrgByArea);

                //making a single ajax call to get targeting tree and device data
                var orgInfoSuccess = function (data) {

                    if (self.getOrgConnectedStatus) {
                        self.showOrganizations = data.ShowOrgs; //reset this flag only first time
                    }

                    if (self.showOrganizations) {
                        if (data.Organizations.length == 0) {
                            $(self.Parameters.orgSectionDivs.noOrganizationDiv).show();
                            $(self.Parameters.orgSectionDivs.organizationTableDiv).hide();
                        } else {
                            $(self.Parameters.orgSectionDivs.noOrganizationDiv).hide();
                            $(self.Parameters.orgSectionDivs.organizationTableDiv).show();

                            var ids = $.map(orgSelection.TargetedOrganizations.filter(function (to) { return !to.GeoSelected; }), function (org) {
                                return org.UserId;
                            });
                            _.each(data.Organizations, function (org) {
                                if ($.inArray(org.UserId, ids) != -1) {
                                    org.Selected = true;
                                }
                            });
                            var userIds = $.map(orgSelection.TargetedOrganizations.filter(function (to) { return to.GeoSelected; }), function (org) {
                                return org.UserId;
                            });
                            var toByArea = $.map(data.Organizations.filter(function (o) { return $.inArray(o.UserId, userIds) != -1; }), function (org) {
                                return org.Id;
                            });
                            self.OrgViewModel.SelectedOrgsByArea(toByArea);
                            self.OrgViewModel.OrgCountByArea(toByArea.length);
                        }
                    } else {
                        $(self.Parameters.orgSectionDivs.noOrganizationDiv).show();
                        $(self.Parameters.orgSectionDivs.organizationTableDiv).hide();
                    }

                    ko.mapping.fromJS(data.Organizations, {}, self.OrgViewModel.Organizations);
                    if (self.OrgViewModel.TargetAllOrg()) {
                        if ((athoc.iws.scenario.settings.viewModel.scenariosettings.Organization && athoc.iws.scenario.settings.viewModel.scenariosettings.Organization.TargetByNameEnabled) || (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.TargetByNameEnabled))
                            self.OrgViewModel.SelectAll();
                        else
                            self.OrgViewModel.ClearAll();
                        self.OrgViewModel.TargetOrgByArea(true);
                    }

                    self.OrgViewModel.UpdateTargetedOrgStatus();

                    self.getOrgConnectedStatus = false;

                    kendo.ui.progress($(self.Parameters.orgSectionDivs.targetOrgSection), false);

                };

                var ajaxOptions = {
                    cache: false,
                    url: athoc.iws.publishing.urls.GetTargetableOrganizationsUrl,
                    data: { getVPSConnectedStatus: self.getOrgConnectedStatus },
                    type: "POST"
                };


                var ajaxOptions = $.extend({}, AjaxUtility(null, orgInfoSuccess).ajaxPostOptions, ajaxOptions);
                $.ajax(ajaxOptions);

            },
            init: function (parameters) {
                var context = this;
                this.Parameters = parameters;


                var orgVM = function (context) {
                    var self = this;

                    self.TargetAllOrg = ko.observable(false);

                    self.TargetAllOrg.subscribe(function (newValue) {
                        var overlay = '<div class="overlay-light-grey" style="display:block"></div>';
                        athoc.iws.publishing.scenario.isChanged = true;
                        if (newValue) {
                            if ((athoc.iws.scenario.settings.viewModel.scenariosettings.Organization && athoc.iws.scenario.settings.viewModel.scenariosettings.Organization.TargetByNameEnabled)
                                ||(athoc.iws.scenario.settings.ReadonlyViewModel.applysettings && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.TargetByNameEnabled))
                                self.SelectAll();
                            self.TargetOrgByArea(self.TargetOrgByAreaVisible());
                                $("#organizationList").scrollTop(0);
                                $("#organizationList").css("overflowY", "hidden");
                                $("#organizationList").append(overlay);
                                $("#divTargetOrgByArea").append(overlay);
                                $("#targetOrgByName").find("button").prop("disabled", true);
                            
                           

                        } else {
                            self.ClearAll();
                            $("#organizationList").css("overflowY", "auto");
                            $("#organizationList").find(".overlay-light-grey").remove();
                            $("#divTargetOrgByArea").find(".overlay-light-grey").remove();
                            $("#targetOrgByName").find("button").prop("disabled", false);
                        }
                    });

                    self.TargetOrgByArea = ko.observable(false);

                    self.TargetOrgByArea.subscribe(function (newValue) {
                        
                        athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(newValue);
                        self.UpdateTargetedOrgStatus();

                    });

                    self.TargetOrgByAreaVisible = function () {
                        return athoc.iws.publishing.geo.viewModel.isGeoSelected();
                    };

                    self.Organizations = ko.observableArray();

                    self.OrgSelected = ko.pureComputed(function () {

                        var ret = self.Organizations().filter(function (el) {
                            return el.Selected();
                        });

                        return ko.toJS(ret).map(function (o) { return o.Id; });
                    });

                    self.TargetedOrgCountByArea = ko.pureComputed(function () {
                        return self.TargetOrgByArea() && athoc.iws.publishing.settings.IsTargetByAreaSupported ? self.OrgCountByArea() : 0;
                    });

                    self.SelectedOrgsByArea = ko.observableArray([]);
                    self.SelectedOrgsByArea.subscribe(function (newValue) {
                        self.UpdateTargetedOrgStatus();
                    });

                    self.OrgCountByArea = ko.observable(0);
                    self.OrgCountByArea.subscribe(function (newValue) {
                        self.UpdateTargetedOrgStatus();
                    });

                    self.OrgCountTotal = ko.pureComputed(function () {
                        var ret = self.OrgSelected();
                        if (self.TargetOrgByArea() && athoc.iws.publishing.settings.IsTargetByAreaSupported) {
                            ret = ret.concat(self.SelectedOrgsByArea());
                            var existingIDs = [];
                            ret = $.grep(ret, function (id) {
                                if ($.inArray(id, existingIDs) !== -1) {
                                    return false;
                                }
                                else {
                                    existingIDs.push(id);
                                    return true;
                                }
                            });
                        }
                        return ret.length;
                    });

                    self.OrgChanged = function () {

                        // athoc.iws.publishing.scenario.isChanged = true;                       
                        self.UpdateTargetedOrgStatus();

                        return true;
                    };

                    self.SelectAll = function () {
                        _.each(self.Organizations(), function (org) {
                            org.Selected(true);
                        });
                        self.OrgChanged();
                    };

                    self.ClearAll = function () {
                        _.each(self.Organizations(), function (org) {
                            org.Selected(false);
                        });
                        self.OrgChanged();
                    };


                    self.ShowDetails = function (selectedOrg) {

                        require(['widget/OrgInfo'], function (OrgInfo) {
                            if (context.OrgInfoHolder == null) {
                                $('<div id="orgInfoHolder"></div>').appendTo("body");
                                context.OrgInfoHolder = new OrgInfo("orgInfoHolder");
                                context.OrgInfoHolder.startup();
                            }

                            context.OrgInfoHolder.update({ orgId: selectedOrg.Id(), orgName: selectedOrg.Name() });
                        });


                        return true;
                    }


                    self.UpdateTargetedOrgStatus = function () {
                        if (self.OrgSelected().length > 0 || (self.TargetOrgByArea() && self.SelectedOrgsByArea() && self.SelectedOrgsByArea().length > 0)) {
                            athoc.iws.publishing.SetSectionStatus(parameters.orgSectionDivs.targetOrgStatus, "ready");
                            athoc.iws.publishing.targetOrg.isReadyToPublish = true;
                        } else {
                            athoc.iws.publishing.SetSectionStatus(parameters.orgSectionDivs.targetOrgStatus, "open");
                            athoc.iws.publishing.targetOrg.isReadyToPublish = false;
                        }
                        athoc.iws.publishing.detail.checkStatusChange();
                    }

                    self.Reset = function () {
                        self.Organizations([]);
                    };

                };

                this.OrgViewModel = new orgVM(this);

                ko.cleanNode($(this.Parameters.orgSectionDivs.targetOrgSection).get(0));
                ko.applyBindings(this.OrgViewModel, $(this.Parameters.orgSectionDivs.targetOrgSection).get(0));

              
               

            },
            getModel: function () {
                //convert viewmodel to the format that will be set to server side with all of other sections. 
                var checkedOrganizations = new Array();
                if (this.showOrganizations) {
                    checkedOrganizations = ko.mapping.toJS(this.OrgViewModel.Organizations).filter(function (el) {
                        return el.Selected;
                    });

                    if (this.OrgViewModel.TargetOrgByArea()) {
                        var allOrgs = ko.mapping.toJS(this.OrgViewModel.Organizations);
                        _.each(this.OrgViewModel.SelectedOrgsByArea(), function (itemId) {
                            var foundOrg = _.find(allOrgs, function (orgItem) {
                                return orgItem.Id === itemId;
                            });
                            if (foundOrg) {
                                //foundOrg.Selected(true);
                                foundOrg.GeoSelected = true;
                                checkedOrganizations.push(ko.mapping.toJS(foundOrg));
                            }

                            //var orgAlreadyExist = _.find(checkedOrganizations, function(item) {
                            //    return itemId === item.Id;
                            //});
                            //if (!orgAlreadyExist) {
                            //    var foundOrg = _.find(allOrgs, function(orgItem) {
                            //        return orgItem.Id() === itemId;
                            //    });
                            //    if (foundOrg) {
                            //        foundOrg.Selected(true);
                            //        foundOrg.GeoSelected(true);
                            //        checkedOrganizations.push(ko.mapping.toJS(foundOrg));
                            //    }
                            //}
                        });
                    }
                }
                return {
                    TargetedOrganizations: checkedOrganizations,
                    TargetAllOrganizations: this.OrgViewModel.TargetAllOrg(),
                    TargetOrganizationsByArea: this.OrgViewModel.TargetOrgByArea()
                };
            },

            bindReadOnlyViewModel: function (data, targetDiv) {
                var vm = kendo.observable(
                  {
                      Organizations: [],
                      CombinedOrgs: function () {
                          var ret = this.get("Organizations");
                          var existingIDs = [];
                          ret = $.grep(ret, function (o) {
                              if ($.inArray(o.UserId, existingIDs) !== -1) {
                                  return false;
                              } else {
                                  existingIDs.push(o.UserId);
                                  return true;
                              }
                          });
                          return ret;
                      },
                      OrgCountText: function () {
                          var orgs = this.CombinedOrgs();
                          return kendo.format(athoc.iws.publishing.resources.Publishing_TargetOrg_TargetOrganizations, orgs.length);
                      },
                      Visible: function () {
                          return this.get("Organizations").length > 0;
                      }
                  });
                vm.set("Organizations", data);
                //targetDiv.find("#targetOrgDetail")
                kendo.bind(targetDiv.find(".kOrgBound"), vm);
            },
        };
    }();
}

///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.deviceOptions.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.deviceOptions = function () {
        return {
            Parameters: {},
            CONST_TAB_TEMPLATE: "<div class=\"finger-tab device-option-tab\" id=\"deviceGroupOptionTab{0}\" groupId=\"{0}\" index=\"{2}\">" +
                            "<span class=\"block ellipsis\" title=\"{1}\">{1}</span><span class=\"finger-tab-extended\"></span>" +
                            "<span style=\"display:none\" id=\"deviceoption_{0}_trigger\"></span></div>",
            CONST_TAB_BODY_CONTAINER: "<div class=\"span8a finger-tab-content device-option-content \" id=\"deviceGroupOptionTab{0}Body\" style=\"display:none;\"></div>",
            CONST_TAB_BODY_TEMPLATE: "<div class=\"inner-bucket white-bg\"><div class=\"inner-bucket-header mar-bot0\"><h4>&nbsp;</h4></div>{0}</div>",
            CONST_INFO_TAG_SELECTOR: "#deviceoption_{0}_trigger",
            CONST_BODY_UNAVAILABLE_TEMPLATE: "<div class=\"inner-bucket-grid-wrap\"><div class=\"mar-top10 mar-left15\">{0}</div></div>",
            CurrentlySelectedGroup: -1,
            OnSaveCallBack: null,
            AllDeviceGroups: new Array(),
            AudioComponents: new Array(),
            audioControlIsLoaded: false,
            audioControlIsRequired: false,
            bind: function (data) {
                var self = this;




            },
            deviceGroupOption: function (selected, label, html) {
                this.Selected = ko.observable(selected);
                this.Name = ko.observable(label);
                this.HTML = ko.observable(html);
            },
            loadViewModel: function () {

            },
            init: function (parameters) {
                var self = this;

                //init is called once when the page loads for the first time.
                //all controls are created here.
                this.Parameters = parameters;
                //this.loadViewModel();

                $(self.Parameters.dialogDeviceOptions + " " + this.Parameters.btnDialogDeviceOptionsSave).on("click", function () {
                    if ($("#RecordWarning") != null && $("#RecordWarning") != undefined)
                        $("#RecordWarning").html("");
                    if (self.CurrentlySelectedGroup != -1) {
                        self.Parameters.submitEventWrapperObj.ExecuteAll();

                        if ($(self.CONST_INFO_TAG_SELECTOR.format(self.CurrentlySelectedGroup)).data("ValidationError").length != 0) //validation error, stay on the page
                        {
                            return;
                        }
                    }

                    //verify validity of audio components
                    if (!self.validateAudio()) return;

                    if (typeof self.OnSaveCallBack == "function") {
                        self.OnSaveCallBack(self.serialize());
                    }
                    $(self.Parameters.dialogDeviceOptions).modal('hide');

                });

                $(self.Parameters.dialogDeviceOptions + " " + this.Parameters.btnDialogDeviceOptionsCancel).on("click", function () {


                    _.each(self.AllDeviceGroups, function (item) {
                        if (item.DeviceOptionLoaded && item.Selected && item.Selected && item.HasExtension) {
                            _.each(item.CurrentSavedSelection, function (element) {
                                var obj = $('[name="' + element.Name + '"]');
                                if (obj.length != 0) {
                                    if (obj.prop("type") == "radio") {
                                        $('[name="' + element.Name + '"][value="' + element.Value + '"]').click();
                                    } else if (obj.prop("tagName").toLowerCase() == "textarea") {
                                        $('[name="' + element.Name + '"]').val(element.Value);
                                    } else if (obj.prop("tagName").toLowerCase() == "select") {
                                        if (obj.attr("multiple") == "multiple") {
                                            if (element.Value != "") {
                                                $('[name="' + element.Name + '"]').val(element.Value.split(","));
                                            }

                                        } else {
                                            $('[name="' + element.Name + '"]').val(element.Value);
                                            if (element.Value == "") { //if nothing was originally selected in the dropdown, select the first item
                                                $('[name="' + element.Name + '"]').find("option").each(function () {
                                                    if ($(this).css("display") != "none") {
                                                        $('[name="' + element.Name + '"]').val($(this).val());
                                                        return false;
                                                    }
                                                });
                                            }
                                        }

                                        $('[name="' + element.Name + '"]').selectpicker('render');
                                    } else if (obj.prop("type") == "checkbox") {
                                        obj.prop('checked', element.Value == "on");
                                    } else if (obj.prop("type") == "hidden") {
                                        //we need to reset all of the audio properties in one shot. 
                                        if (obj.hasClass("AudioId")) {
                                            var component = self.findAudioComponent(self.getAudioComponentId(element.Name));
                                            if (component) {
                                                var audioId = element.Value;

                                                //now must retrieve filename and stream
                                                var fileName = _.find(this, function (item) { return item.Name == element.Name.replace(/(?=.)[a-zA-Z]*$/, "Name") }).Value;
                                                var fileStream = _.find(this, function (item) { return item.Name == element.Name.replace(/(?=.)[a-zA-Z]*$/, "Stream") }).Value;
                                                //stop the audio if its playing                                                 
                                                component.Component.stopAudio();
                                                component.Component.setAudioProperties(audioId, fileName, fileStream);
                                            }
                                        }
                                    }
                                } else { //special handling for audio component

                                }
                            }, item.CurrentSavedSelection);
                        }

                    });

                    self.Parameters.submitEventWrapperObj.ExecuteAll();

                    //need to manually refresh selectpicker component after applying UI changes due to cancel. 
                    _.each(self.AllDeviceGroups, function (item) {
                        if (item.DeviceOptionLoaded && item.Selected && item.Selected && item.HasExtension) {
                            _.each(item.CurrentSavedSelection, function (element) {
                                var obj = $('[name="' + element.Name + '"]');
                                if (obj.length != 0) {
                                    if (obj.prop("tagName").toLowerCase() == "select") {
                                        $('[name="' + element.Name + '"]').selectpicker('render');
                                    }
                                }
                            }, item.CurrentSavedSelection);
                        }

                    });

                    $(self.Parameters.dialogDeviceOptions).modal('hide');

                });

            },
            serialize: function () {
                var self = this;
                var optionsArray = new Array();
                _.each(this.AllDeviceGroups, function (item) {
                    if (item.DeviceOptionLoaded && item.Selected && item.Selected && item.HasExtension) {
                        var options = self.serializeForDeviceGroup(item);
                        item.CurrentSavedSelection = options;

                        optionsArray.push({
                            GroupId: item.Id,
                            Options: options
                        });
                    }

                });

                return optionsArray;

            },
            serializeForDeviceGroup: function (item) {
                var self = this;

                var options = new Array();
                _.each(item.ElementList, function (element) {
                    var value = "";
                    var obj = $('[name="' + element + '"]');

                    if (obj.length != 0) {
                        if (obj.prop("type") == "checkbox") {
                            if (!obj.prop("disabled")) {
                                value = obj.is(":checked") ? obj.val() : "";
                            } else {
                                value = "";
                            }
                        } else if (obj.length > 1) { //select
                            var allDisabled = true;
                            for (var i = 0; i < obj.length; i++) {
                                if (!obj[i].disabled) {
                                    allDisabled = false;
                                }
                            }
                            if (!allDisabled) {
                                value = $('[name="' + element + '"]:checked').val();
                            } else {
                                value = "";
                            }
                        } else if (obj.prop("type") == "hidden") { //audio Id, audio name

                            var component = self.findAudioComponent(self.getAudioComponentId(element));

                            if (typeof component != "undefined") {
                                if (component.Required) {
                                    if (obj.hasClass("AudioId")) {
                                        //get  audio Id property from component
                                        value = component.Component.getAudioProperties().audioId;
                                    } else if (obj.hasClass("AudioName")) {
                                        //get audio name prop from component
                                        value = component.Component.getAudioProperties().fileName;
                                    }
                                }
                            } else { //is not audio control, it's simple hidden input
                                value = $('[name="' + element + '"]').val();
                            }
                        } else if (obj.attr("multiple") == "multiple") { //multi select pick list
                            if (typeof $('[name="' + element + '"]').val() == "undefined" || $('[name="' + element + '"]').val() == null) {
                                value = "";
                            } else {
                                value = $('[name="' + element + '"]').val().join(",");
                            }
                        } else { //radio button, textbox, textarea
                            if (!obj.prop("disabled")) {
                                value = $('[name="' + element + '"]').val();
                            } else {
                                value = "";
                            }
                        }
                    } else {
                        //recording component needs to be handled in a special way. 
                        var obj = $('[id="' + element + '"]');
                        if (obj.length != 0) {
                            if (obj.hasClass("recording")) { //is a recording
                                var component = self.findAudioComponent(self.getAudioComponentId(element));

                                //now extract info from it. 
                                if (component.Required) { //retrieve audio only if required
                                    value = component.Component.getAudioProperties().fileStream;
                                }

                            }
                        }
                    }

                    options.push({
                        Name: element,
                        Value: value
                    });
                });
                return options;
            },
            load: function (devices, presetDeviceOptions, onSaveCallback, onLoadDoneCallback) {

                this.CurrentlySelectedGroup = -1;

                this.OnSaveCallBack = onSaveCallback;

                //delete all of the audio components prev created. 
                _.each(this.AudioComponents, function (audio) {
                    audio.Component.destroy();
                });
                //reset audio components array

                this.AudioComponents = new Array();

                //reset all of the flag required for synced loading
                this.audioControlIsLoaded = false;
                this.audioControlIsRequired = false;
                this.intervalSerialize = null;
                var self = this;
                $(self.Parameters.dialogDeviceOptions + " " + self.Parameters.deviceOptionTabs).html("");
                $(self.Parameters.dialogDeviceOptions + " " + self.Parameters.deviceOptionTabBody).html("");

                //var encodedPresets = {};
                //for (var key in presetDeviceOptions) {
                //    encodedPresets[key] = $.htmlEncode(presetDeviceOptions[key]);
                //}

                var dlAjaxOption =
                {
                    type: "POST",
                    url: self.Parameters.deviceOptionURL,
                    data: {
                        devices: devices,
                        presetOptions: presetDeviceOptions,
                        type: this.Parameters.deviceType
                    },
                };

                kendo.ui.progress($(self.Parameters.dialogDeviceOptions), true);

                var dlSuccess = function (data) {
                    //$("#deviceOptionPanel").html(data);
                    //this.viewModelInstance.deviceGroups().push(new deviceGroup(true, "hello", "bleh"))
                    //ko.mapping.fromJS(data.DeviceOptions, {}, self.viewModelInstance.deviceGroups);
                    var firstTab = null;

                    self.AllDeviceGroups = data.DeviceOptions;

                    _.each(self.AllDeviceGroups, function (item, index) {

                        var tab = $(self.CONST_TAB_TEMPLATE.format(item.Id, item.Name));

                        /*had to resort to native DOM instead of knockout for a device option specific reason*/
                        $(self.Parameters.dialogDeviceOptions + " " + self.Parameters.deviceOptionTabs).append(tab);

                        //$(self.CONST_INFO_TAG_SELECTOR.format(item.Id)).data("ElementList", item.ElementList);
                        $(self.CONST_INFO_TAG_SELECTOR.format(item.Id)).data("ValidationError", new Array());

                        var tabBody = $(self.CONST_TAB_BODY_CONTAINER.format(item.Id));
                        $(self.Parameters.dialogDeviceOptions + " " + self.Parameters.deviceOptionTabBody).append(tabBody);
                        if (item.Selected) {
                            if (!item.HasExtension) {
                                tabBody.append(self.CONST_TAB_BODY_TEMPLATE.format(self.CONST_BODY_UNAVAILABLE_TEMPLATE.format(self.Parameters.resources.Publishing_Devices_Device_Options_Unavailable)));
                            } else {
                                var content = (item.HTML == null) ? "" : item.HTML;
                                tabBody.append(self.CONST_TAB_BODY_TEMPLATE.format(content)).promise().done(function () {
                                    if (item.HTML != null) {
                                        //eval(tabBody.find("script").text());
                                        try {
                                            eval("device_option_load_" + item.Id + "()");//<xsl:value-of select="$DeviceGroupID" />() {

                                            $("#deviceGroupOptionTab" + item.Id + "Body select").each(function (i) {

                                                if ($(this).find("option").length != 0) {
                                                    $(this).selectpicker({
                                                        noneSelectedText: self.Parameters.resources.Publishing_Devices_Select_None,
                                                        selectedTextFormat: "count>2",
                                                        includeSelectAllOption: true
                                                    });
                                                }

                                            });

                                            //eval(tabBody.find("script").text());
                                            $("#deviceGroupOptionTab" + item.Id + "Body .device-option-placeholder").each(function (i) {
                                                var currentItem = $(this);
                                                self.showPlaceholder(currentItem);
                                            });

                                            $("#deviceGroupOptionTab" + item.Id + "Body .recording").each(function (i) {

                                                self.audioControlIsRequired = true;
                                                audioUploader.isAudioFileChanged = false;

                                                self.showAudioRecorder("#deviceGroupOptionTab" + item.Id + "Body .recording");

                                            });

                                        } catch (e) {

                                        }

                                        if (!self.audioControlIsRequired || self.audioControlIsLoaded)  //must wait til audio component is loaded. 
                                        {
                                            item.CurrentSavedSelection = self.serializeForDeviceGroup(item);


                                            if ($("#deviceGroupOptionTab" + item.Id + "Body .default-template-severity-label").length != 0) {

                                                var severity = self.getSeverityInfo();

                                                self.setSeverityText(severity.id,
                                                                        "#deviceGroupOptionTab" + item.Id + "Body ",
                                                                        self,
                                                                        severity.name);
                                                self.setSeverityBasedInfo("#deviceGroupOptionTab" + item.Id + "Body ",
                                                                            severity.id);
                                            }

                                            self.localeChange(item, self);


                                        } else {

                                            //must delay serialize until audiocomponent is loaded
                                            var intervalSerialize = null;
                                            function checkAudioComponent() {
                                                //console.log(self.audioControlIsLoaded);
                                                if (self.audioControlIsLoaded) {
                                                    clearInterval(intervalSerialize);
                                                    item.CurrentSavedSelection = self.serializeForDeviceGroup(item);

                                                }
                                            }
                                            intervalSerialize = window.setInterval(checkAudioComponent, 200);

                                        }
                                    }


                                });

                            }
                        }

                        if (!item.Selected) { //if device/devicegroup is not selected hide tab. 
                            $("#deviceGroupOptionTab" + item.Id).hide();
                            $("#" + item.Id + "Body").hide();
                        }
                        tab.on("click", function () {
                            self.clickTab(self, $(this), true);

                            /*
                                        if ($("#RecordWarning") != null && $("#RecordWarning") != undefined)
                                            $("#RecordWarning").html("");
            
                                        if (self.CurrentlySelectedGroup != -1) {
                                            self.Parameters.submitEventWrapperObj.ExecuteAll();
                                            
                                            if ($(self.CONST_INFO_TAG_SELECTOR.format(self.CurrentlySelectedGroup)).data("ValidationError").length != 0) //validation error, stay on the page
                                            {
                                                return;
                                            }
                                        }                
                                        //verify validity of audio components
                                        if (!self.validateAudio()) return;
            
                                        self.CurrentlySelectedGroup = $(this).attr("groupId");
                                        $(self.Parameters.dialogDeviceOptions + " " + ".device-option-content").hide();
                                        $("#" + $(this).attr("id") + "Body").show();
                                        $(self.Parameters.dialogDeviceOptions + " " + '.device-option-tab').removeClass('selected');
            
                                        $(this).addClass('selected');
                                        */
                        });



                        if (firstTab == null) {
                            if (item.Selected)
                                firstTab = tab;
                        }


                        //self.viewModelInstance.deviceGroups.push(new self.deviceGroupOption(item.Selected,item.Name,item.HTML));
                    });
                    if (firstTab != null) {
                        self.clickTab(self, firstTab, false);
                        //firstTab.click();
                    }
                    if (typeof onLoadDoneCallback == "function") {

                        if (!self.audioControlIsRequired || self.audioControlIsLoaded)  //must wait til audio component is loaded. 
                        {
                            onLoadDoneCallback(self.serialize());

                        } else {

                            //must delay serialize until audiocomponent is loaded
                            var intervalSerialize = null;
                            function checkAudioComponent() {
                                //console.log(self.audioControlIsLoaded);
                                if (self.audioControlIsLoaded) {
                                    clearInterval(intervalSerialize);
                                    onLoadDoneCallback(self.serialize());
                                }
                            }
                            intervalSerialize = window.setInterval(checkAudioComponent, 200);
                        }
                    }
                    kendo.ui.progress($(self.Parameters.dialogDeviceOptions), false);


                }
                var dlError = function (data) {

                }

                var ajaxOptions = $.extend({}, AjaxUtility(dlError, dlSuccess).ajaxPostOptions, dlAjaxOption);
                setTimeout(function () {
                    $.ajax(ajaxOptions);
                }, 1000);
            },
            loadOnlyNewDeviceGroups: function (selectedDevices, callback) {
                var groupIdsToGetOptions = new Array();
                var self = this;
                _.each(self.AllDeviceGroups, function (itemGroup) {
                    var found = _.find(selectedDevices, function (item) {
                        return (item.GroupId == itemGroup.Id);
                    });

                    if (found) {
                        if (!itemGroup.DeviceOptionLoaded) {
                            groupIdsToGetOptions.push(itemGroup.Id);
                        }
                        $("#deviceGroupOptionTab" + itemGroup.Id).show();
                        $("#deviceGroupOptionTab" + itemGroup.Id + "Body").show();
                        itemGroup.Selected = true;
                    } else { //unselected device group
                        itemGroup.Selected = false;
                        //hide tab
                        $("#deviceGroupOptionTab" + itemGroup.Id).hide();
                        $("#deviceGroupOptionTab" + itemGroup.Id + "Body").hide();
                    }

                });

                //make ajax call if there are device options not yet loaded.
                if (groupIdsToGetOptions.length != 0) {
                    kendo.ui.progress($(self.Parameters.dialogDeviceOptions), true);

                    var dlAjaxOption =
                    {
                        type: "POST",
                        url: self.Parameters.moreDeviceOptionURL,
                        data: { deviceGroupIds: groupIdsToGetOptions, type: self.Parameters.deviceType },
                    };

                    var dlSuccess = function (data) {
                        _.each(data.deviceGroupOptions, function (itemFromServer) {
                            var found = _.find(self.AllDeviceGroups, function (item) {
                                return (itemFromServer.Id == item.Id);
                            });

                            if (found) {
                                found.DeviceOptionLoaded = true;
                                found.ElementList = itemFromServer.ElementList;

                                found.HasExtension = itemFromServer.HasExtension;

                                found.Selected = true;
                                if (!itemFromServer.HasExtension) {
                                    $("#deviceGroupOptionTab" + itemFromServer.Id + "Body").append(self.CONST_TAB_BODY_TEMPLATE.format(self.CONST_BODY_UNAVAILABLE_TEMPLATE.format(self.Parameters.resources.Publishing_Devices_Device_Options_Unavailable)));
                                    //$("#deviceGroupOptionTab" + itemFromServer.Id + "Body").find(":nth-child(1)").find(":nth-child(1)").after(itemFromServer.HTML);
                                } else {
                                    $("#deviceGroupOptionTab" + itemFromServer.Id + "Body").append(self.CONST_TAB_BODY_TEMPLATE.format(itemFromServer.HTML)).promise().done(function () {
                                        if (itemFromServer.HTML != null) {
                                            var tabBody = $(self.CONST_TAB_BODY_CONTAINER.format(itemFromServer.Id));

                                            try {
                                                eval("device_option_load_" + itemFromServer.Id + "()");//<xsl:value-of select="$DeviceGroupID" />() {
                                                //eval(tabBody.find("script").text());

                                            } catch (e) {
                                            }

                                            $("#deviceGroupOptionTab" + itemFromServer.Id + "Body select").each(function (i) {

                                                if ($(this).find("option").length != 0) {

                                                    $(this).selectpicker({
                                                        noneSelectedText: self.Parameters.resources.Publishing_Devices_Select_None,
                                                        selectedTextFormat: "count>2",
                                                        includeSelectAllOption: true
                                                    });

                                                }
                                            });


                                            //eval(tabBody.find("script").text());
                                            $("#deviceGroupOptionTab" + itemFromServer.Id + "Body .device-option-placeholder").each(function (i) {
                                                var currentItem = $(this);
                                                self.showPlaceholder(currentItem);
                                            });

                                            $("#deviceGroupOptionTab" + itemFromServer.Id + "Body .recording").each(function (i) {
                                                self.audioControlIsRequired = true;
                                                audioUploader.isAudioFileChanged = false;
                                                self.showAudioRecorder("#deviceGroupOptionTab" + itemFromServer.Id + "Body .recording");
                                            });


                                            if (!self.audioControlIsRequired || self.audioControlIsLoaded)  //must wait til audio component is loaded. 
                                            {
                                                /*found.CurrentSavedSelection = self.serializeForDeviceGroup(itemFromServer);
                                                if ($("#deviceGroupOptionTab" + itemFromServer.Id + "Body .severityAffected").length != 0 || 
                                                        $("#deviceGroupOptionTab" + itemFromServer.Id + "Body .default-template-severity-label").length != 0) {

                                                    var severity = self.getSeverityInfo();
                                                    self.changeBasedOnSeverity(severity.id,
																			"#deviceGroupOptionTab" + itemFromServer.Id + "Body ",
																			self,
                                                                            severity.name);

                                                }*/
                                                self.runAfterLoad(found, self, itemFromServer)

                                            } else {

                                                //must delay serialize until audiocomponent is loaded
                                                var intervalSerialize = null;
                                                function checkAudioComponent() {
                                                    if (self.audioControlIsLoaded) {
                                                        clearInterval(intervalSerialize);

                                                        self.runAfterLoad(found, self, itemFromServer);

                                                        /*
                                                        found.CurrentSavedSelection = self.serializeForDeviceGroup(itemFromServer);

                                                        if ($("#deviceGroupOptionTab" + itemFromServer.Id + "Body .severityAffected").length != 0 ||
                                                            $("#deviceGroupOptionTab" + itemFromServer.Id + "Body .default-template-severity-label").length != 0)
                                                             {

                                                                var severity = self.getSeverityInfo();

                                                                self.changeBasedOnSeverity(severity.id,
																						"#deviceGroupOptionTab" + itemFromServer.Id + "Body ",
																						self,
                                                                                        severity.name);
                                                            }
                                                            */
                                                    }
                                                }
                                                intervalSerialize = window.setInterval(checkAudioComponent, 200);
                                            }


                                        }
                                    });

                                    //$("#deviceGroupOptionTab" + itemFromServer.Id + "Body").first().first().after(self.CONST_BODY_UNAVAILABLE_TEMPLATE.format(self.Parameters.resources.Publishing_Devices_Device_Options_Unavailable));
                                }
                                $(self.Parameters.dialogDeviceOptions + " .device-option-content").hide();
                                $("#deviceGroupOptionTab" + itemFromServer.Id).show();

                            }

                        });

                        self.showFirstVisibleTab();
                        kendo.ui.progress($(self.Parameters.dialogDeviceOptions), false);

                        if (typeof callback == "function") {

                            if (!self.audioControlIsRequired || self.audioControlIsLoaded)  //must wait til audio component is loaded. 
                            {
                                callback(self.serialize());
                            } else {

                                //must delay serialize until audiocomponent is loaded
                                var intervalSerialize = null;
                                function checkAudioComponent() {
                                    if (self.audioControlIsLoaded) {
                                        clearInterval(intervalSerialize);
                                        callback(self.serialize());
                                    }
                                }
                                intervalSerialize = window.setInterval(checkAudioComponent, 200);
                            }

                        }


                    }

                    var dlError = function (data) {
                    }

                    var ajaxOptions = $.extend({}, AjaxUtility(dlError, dlSuccess).ajaxPostOptions, dlAjaxOption);
                    $.ajax(ajaxOptions);
                } else {
                    self.showFirstVisibleTab();
                    if (typeof callback == "function") {
                        callback(self.serialize());
                    }
                }


            },
            runAfterLoad: function (found, self, itemFromServer) {
                found.CurrentSavedSelection = self.serializeForDeviceGroup(itemFromServer);
                if ($("#deviceGroupOptionTab" + itemFromServer.Id + "Body .severityAffected").length != 0 ||
                        $("#deviceGroupOptionTab" + itemFromServer.Id + "Body .default-template-severity-label").length != 0) {

                    var severity = self.getSeverityInfo();
                    self.changeBasedOnSeverity(severity.id,
                                            "#deviceGroupOptionTab" + itemFromServer.Id + "Body ",
                                            self,
                                            severity.name);

                }

                //apply changes based on locale
                self.localeChange(itemFromServer, self);

                /*if ($("#deviceGroupOptionTab" + itemFromServer.Id + "Body .filter-by-alert-locale").length != 0) {

                    self.changeBasedOnLocale(self.getLocale(),
                                            "#deviceGroupOptionTab" + itemFromServer.Id + "Body ",
                                            self);
                }*/

            },
            localeChange: function (itemFromServer, self) {
                if ($("#deviceGroupOptionTab" + itemFromServer.Id + "Body .filter-by-alert-locale").length != 0) {

                    self.changeBasedOnLocale(self.getLocale(),
                                            "#deviceGroupOptionTab" + itemFromServer.Id + "Body ",
                                            self);
                }
            },
            showPlaceholder: function (currentItem) {

                require(["publishing/Placeholder/Placeholder", "dijit/registry"], function (Placeholder, registry) {


                    var ph = registry.byId(currentItem.attr("id"));
                    if (ph) {
                        ph.destroy();
                    }

                    var txt = $($('[name="' + currentItem.attr("textbox") + '"]'))[0];
                    var options = { textField: txt, items: athoc.iws.publishing.placeHolderItems, showOnLeft: true, isStatic: false }

                    ph = new Placeholder(options, currentItem[0]);

                    //var ph = new Placeholder(options, $("#" + currentItem.attr('id'), txt.parentNode)[0]);

                    ph.startup();
                });
            },
            showAudioRecorder: function (currentItem) {

                var self = this;

                //try to retrieve audio Id and Name by searching in other fields. 
                var controlId = $(currentItem).attr("id");

                //text manipulation to get element name
                var splitted = controlId.split(".");
                splitted.pop();
                splitted = splitted.join(".");

                var audioId = $("*[name='" + splitted + ".Id']").val();
                var audioName = $("*[name='" + splitted + ".Name']").val();

                //pass audio Id and audio Name if already selected

                var ph;
                var safari = false;
                if (navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1) {
                    safari = true;
                }

                require(["publishing/AudioUploader/AudioUploader"], function (AudioUploader) {
                    var options = {
                        fileName: audioName,
                        audioId: audioId,
                        fileStream: "",
                        isReadOnly: false,
                        isBrowseSpecific: navigator.userAgent.toLowerCase().indexOf('trident') != -1 || safari ? true : false,
                        operator: audioUploader.operatorName,
                    }
                    ph = new AudioUploader(options, $(currentItem)[0], audioUploader);

                    ph.on("ready", function () {
                        self.audioControlIsLoaded = true;
                        //save component instance so it can be referenced during serialize
                        self.AudioComponents.push({ Id: splitted, Component: ph, Required: (audioId != "") });
                        self.AudioComponents[0].Component.viewModel.isChanged(audioUploader.isAudioFileChanged);
                    });
                    ph.startup();

                });


                //hide audio if not supported
                if (!athoc.iws.publishing.settings.IsRecordedAudioSupported) {
                    $("[id*='.Recorded-Container']").css("display", "none");
                }
            },
            showFirstVisibleTab: function () {
                var self = this;

                _.each(this.AllDeviceGroups, function (item) {
                    if (item.Selected) {
                        self.clickTab(self, $("#deviceGroupOptionTab" + item.Id), false);
                        //$("#deviceGroupOptionTab" + item.Id).click();
                        return;
                    }
                });
            },
            setDeviceValidation: function (groupId, control, isValid, errMsg) {

                var varlidationArray = $(this.CONST_INFO_TAG_SELECTOR.format(groupId)).data("ValidationError");
                if (isValid) { //remove from validation array
                    varlidationArray = _.filter(varlidationArray, function (item) { return item.controlName !== control });
                } else {
                    var found = _.find(varlidationArray, function (item) {
                        return (item.controlName == control);
                    });

                    if (!found) {
                        varlidationArray.push({
                            controlName: control,
                            error: errMsg
                        });
                    }
                }
                $(this.CONST_INFO_TAG_SELECTOR.format(groupId)).data("ValidationError", varlidationArray);

                //if (isValid == false) {
                //    setValidationError(SHELLSECTIONID_DEVICES, "../../images/inlinehelp.gif", control, errMsg);
                //}
                //else {
                //    removeValidationError(SHELLSECTIONID_DEVICES, control);
                //}

                //testSelectedDevice();
            },
            isDeviceGroupSelected: function (groupId) {
                var self = this;
                var found = _.find(self.AllDeviceGroups, function (item) {
                    return (item.Id == groupId && item.Selected);
                });
                return found;
            },
            requireUnrequireAudioControl: function (elementId, required) { // set required status of audio control

                //go through list of audio components and see if corresponding audio component can be found. 
                _.each(this.AudioComponents, function (audio) {
                    if (audio.Id.indexOf(elementId) == 0) { //audio Id starts with elementId 
                        audio.Required = required;
                    }
                });
            },
            validateAudio: function () {
                var self = this;
                var optionsArray = new Array();
                var isValid = true;
                _.each(this.AllDeviceGroups, function (item) {
                    if (item.DeviceOptionLoaded && item.Selected && item.Selected && item.HasExtension) {
                        _.each(item.ElementList, function (element) {
                            var obj = $('[id="' + element + '"]');
                            if (obj.length != 0) {

                                if (obj.hasClass("recording")) { //is a recording

                                    value = "some value";

                                    //find audio component
                                    var found = self.findAudioComponent(self.getAudioComponentId(element));

                                    if (found) {
                                        //stop the audio if its playing 
                                        found.Component.stopAudio();
                                        audioUploader.isAudioFileChanged = found.Component.viewModel.isChanged();
                                        //check to see if it is required, and also check to see if it is valid. 
                                        if (found.Required) {
                                            if (!found.Component.audioProperties.isValid) { //if component is invalid return false
                                                found.Component.showValidation();
                                                isValid = false;
                                            }
                                        }
                                    }

                                }
                            }

                        });

                    }

                });
                return isValid;
            },
            getAudioComponentId: function (eid) {
                //text manipulation to get element name
                var splitted = eid.split(".");
                splitted.pop();
                splitted = splitted.join(".");
                return splitted;
            },
            findAudioComponent: function (id) {
                var self = this;
                var found = _.find(self.AudioComponents, function (item) {
                    return (id == item.Id);
                });
                return found;
            },
            changeBasedOnSeverity: function (severity, parentDiv, self, severityName) {

                if (typeof self == "undefined") {
                    self = this;
                }

                //if parentDiv has value, only modify within specified div
                if (typeof parentDiv === "undefined") {
                    parentDiv = "";
                }

                $(parentDiv + ".severityAffected").each(function () {
                    if ($(this).hasClass(severity)) {
                        $(this).click();
                    }
                });
                self.setSeverityText(severity, parentDiv, self, severityName);

                self.setSeverityBasedInfo(parentDiv, severity);

                //disable all radios if required etc.
                self.Parameters.submitEventWrapperObj.ExecuteAll();

                //save the changes
                if (typeof self.OnSaveCallBack == "function") {
                    self.OnSaveCallBack(self.serialize());
                }
            },
            setSeverityText: function (severity, parentDiv, self, severityName) {
                if (typeof severityName == "undefined") {
                    severityName = athoc.iws.publishing.content.viewModel.data.getSeverityNanmeFromId(severity);
                }
                $(parentDiv + ".default-template-severity-label").text(severityName);
            },
            setSeverityBasedInfo: function (parentDiv, severity) {
                //set any hidden value affected by severity (for mpn)
                $(parentDiv + ".change-value-by-severity").each(function () {
                    $(this).val($(this).attr("severity" + severity));
                });

                $(parentDiv + ".change-text-by-severity").each(function () {
                    $(this).text($(this).attr("severity" + severity));
                });

            },
            changeBasedOnLocale: function (newLocale, parentDiv, self) {

                if (typeof self == "undefined") {
                    self = this;
                }

                var selectSelector = "select";

                //if parentDiv has value, only modify within specified div
                if (typeof parentDiv === "undefined") {
                    parentDiv = "";
                } else {
                    selectSelector = parentDiv + " select";
                }

                //for each item that should be filtered by locale (audio and template)
                $(selectSelector).each(function (index, selectObj) {



                    if ($(selectObj).hasClass("filter-by-alert-locale")) {

                        var selected = $(selectObj).find("option:selected");

                        var selectionNeedsToBeModified = (selected.length == 0) ? true : (selected.attr("class").toLowerCase() != newLocale.toLowerCase() && selected.attr("class").toLowerCase() != "any"); //selected template does not match current alert locale 

                        //show hide based on locale. 
                        $(selectObj).find("option").each(function (indexOption, optionObj) {

                            if ($(optionObj).attr("class").toLowerCase() != newLocale.toLowerCase() && $(optionObj).attr("class").toLowerCase() != "any") {
                                $(optionObj).hide();
                            } else {
                                $(optionObj).show();
                            }
                        });

                        $(this).selectpicker("refresh");


                        // see if selected option no longer matches the locale
                        if (selectionNeedsToBeModified) //selected template does not match current alert locale 
                        {
                            //select "default" option
                            $(parentDiv + " ." + $(this).attr("defaultradiobuttonselector")).click();

                            var visibleFound = false;

                            var selectObj = $(this);
                            $(selectObj).find("option").each(function (indexOption, optionObj) {
                                if ($(optionObj).attr("class").toLowerCase() == newLocale.toLowerCase() || $(optionObj).attr("class").toLowerCase() == "any") { //this option is visible.                                    
                                    selectObj.selectpicker('val', $(optionObj).val());
                                    visibleFound = true;
                                    return false;
                                }
                            });

                            var previewButtonObj = $("a[id^='" + $(selectObj).prop("id").replace(/\.\w*$/, "") + "']");

                            if (!visibleFound) { //no audio/template is there for selected locale
                                $(selectObj).selectpicker('val', '');

                                previewButtonObj.addClass("disabled");

                                //remove event - for IEs
                                if (typeof previewButtonObj.data("click") == "undefined") //store events
                                {
                                    previewButtonObj.data("click_event", $._data(previewButtonObj[0], "events").click[0].handler)
                                }
                                previewButtonObj.off("click");
                                //put return false so click here doesn't scroll the page. 
                                previewButtonObj.on("click", function () {
                                    return false;
                                });


                            } else {
                                previewButtonObj.removeClass("disabled");

                              
                                // if data("click") is not empty then add the click
                                if (typeof previewButtonObj.data("click_event") != "undefined") {
                                    previewButtonObj.off("click");
                                    previewButtonObj.on("click", previewButtonObj.data("click_event"));
                                }
                            }
                        }



                    }

                })

                //disable all radios if required etc.
                self.Parameters.submitEventWrapperObj.ExecuteAll();

                //save the changes
                if (typeof self.OnSaveCallBack == "function") {
                    self.OnSaveCallBack(self.serialize());
                }
            },
            clickTab: function (self, element, fromUserAction) {

                if ($("#RecordWarning") != null && $("#RecordWarning") != undefined) {
                    $("#RecordWarning").html("");
                }

                if (self.CurrentlySelectedGroup != -1) {
                    self.Parameters.submitEventWrapperObj.ExecuteAll();

                    if (fromUserAction) { //apply this only when there is a validation error
                        if ($(self.CONST_INFO_TAG_SELECTOR.format(self.CurrentlySelectedGroup)).data("ValidationError").length != 0) //validation error, stay on the page
                        {
                            return;
                        }
                    }
                }


                //verify validity of audio components
                if (!self.validateAudio()) return;

                self.CurrentlySelectedGroup = element.attr("groupId");
                $(self.Parameters.dialogDeviceOptions + " " + ".device-option-content").hide();
                $("#" + element.attr("id") + "Body").show();
                $(self.Parameters.dialogDeviceOptions + " " + '.device-option-tab').removeClass('selected');

                element.addClass('selected');

            },
            getSeverityInfo: function () {
                var severityId;
                var severityName;
                try {
                    severityId =  athoc.iws.publishing.content.viewModel.data.SeverityId();
                    severityName = undefined;
                } catch (e) {
                    severityId = athoc.iws.publishing.detail.viewModel.Content.SeverityId;
                    severityName = athoc.iws.publishing.detail.viewModel.Content.SeverityName;
                }
                
                return {
                    id: severityId,
                    name: severityName
                };

            },
            getLocale: function () {
                try {
                    return athoc.iws.publishing.content.viewModel.data.Local();
                    severityName = undefined;
                } catch (e) { // if content section is read only come here
                    return athoc.iws.publishing.detail.viewModel.Content.Local;
                }
            }
        };
    }
}


///#source 1 1 /Scripts/jquery.filedownload.js
/*
* jQuery File Download Plugin v1.4.2 
*
* http://www.johnculviner.com
*
* Copyright (c) 2013 - John Culviner
*
* Licensed under the MIT license:
*   http://www.opensource.org/licenses/mit-license.php
*
* !!!!NOTE!!!!
* You must also write a cookie in conjunction with using this plugin as mentioned in the orignal post:
* http://johnculviner.com/jquery-file-download-plugin-for-ajax-like-feature-rich-file-downloads/
* !!!!NOTE!!!!
*/

(function ($, window) {
    // i'll just put them here to get evaluated on script load
    var htmlSpecialCharsRegEx = /[<>&\r\n"']/gm;
    var htmlSpecialCharsPlaceHolders = {
        '<': 'lt;',
        '>': 'gt;',
        '&': 'amp;',
        '\r': "#13;",
        '\n': "#10;",
        '"': 'quot;',
        "'": 'apos;' /*single quotes just to be safe*/
    };

    $.extend({
        //
        //$.fileDownload('/path/to/url/', options)
        //  see directly below for possible 'options'
        fileDownload: function (fileUrl, options) {
            //provide some reasonable defaults to any unspecified options below
            var settings = $.extend({

                //
                //Requires jQuery UI: provide a message to display to the user when the file download is being prepared before the browser's dialog appears
                //
                preparingMessageHtml: null,

                //
                //Requires jQuery UI: provide a message to display to the user when a file download fails
                //
                failMessageHtml: null,

                //
                //the stock android browser straight up doesn't support file downloads initiated by a non GET: http://code.google.com/p/android/issues/detail?id=1780
                //specify a message here to display if a user tries with an android browser
                //if jQuery UI is installed this will be a dialog, otherwise it will be an alert
                //
                androidPostUnsupportedMessageHtml: "Unfortunately your Android browser doesn't support this type of file download. Please try again with a different browser.",

                //
                //Requires jQuery UI: options to pass into jQuery UI Dialog
                //
                dialogOptions: { modal: true },

                //
                //a function to call while the dowload is being prepared before the browser's dialog appears
                //Args:
                //  url - the original url attempted
                //
                prepareCallback: function (url) { },

                //
                //a function to call after a file download dialog/ribbon has appeared
                //Args:
                //  url - the original url attempted
                //
                successCallback: function (url) { },

                //
                //a function to call after a file download dialog/ribbon has appeared
                //Args:
                //  responseHtml    - the html that came back in response to the file download. this won't necessarily come back depending on the browser.
                //                      in less than IE9 a cross domain error occurs because 500+ errors cause a cross domain issue due to IE subbing out the
                //                      server's error message with a "helpful" IE built in message
                //  url             - the original url attempted
                //
                failCallback: function (responseHtml, url) { },

                //
                // the HTTP method to use. Defaults to "GET".
                //
                httpMethod: "GET",

                //
                // if specified will perform a "httpMethod" request to the specified 'fileUrl' using the specified data.
                // data must be an object (which will be $.param serialized) or already a key=value param string
                //
                data: null,

                //
                //a period in milliseconds to poll to determine if a successful file download has occured or not
                //
                checkInterval: 100,

                //
                //the cookie name to indicate if a file download has occured
                //
                cookieName: "fileDownload",

                //
                //the cookie value for the above name to indicate that a file download has occured
                //
                cookieValue: "true",

                //
                //the cookie path for above name value pair
                //
                cookiePath: "/",

                //
                //the title for the popup second window as a download is processing in the case of a mobile browser
                //
                popupWindowTitle: "Initiating file download...",

                //
                //Functionality to encode HTML entities for a POST, need this if data is an object with properties whose values contains strings with quotation marks.
                //HTML entity encoding is done by replacing all &,<,>,',",\r,\n characters.
                //Note that some browsers will POST the string htmlentity-encoded whilst others will decode it before POSTing.
                //It is recommended that on the server, htmlentity decoding is done irrespective.
                //
                encodeHTMLEntities: true

            }, options);

            var deferred = new $.Deferred();

            //Setup mobile browser detection: Partial credit: http://detectmobilebrowser.com/
            var userAgent = (navigator.userAgent || navigator.vendor || window.opera).toLowerCase();

            var isIos;                  //has full support of features in iOS 4.0+, uses a new window to accomplish this.
            var isAndroid;              //has full support of GET features in 4.0+ by using a new window. Non-GET is completely unsupported by the browser. See above for specifying a message.
            var isOtherMobileBrowser;   //there is no way to reliably guess here so all other mobile devices will GET and POST to the current window.

            if (/ip(ad|hone|od)/.test(userAgent)) {

                isIos = true;

            } else if (userAgent.indexOf('android') !== -1) {

                isAndroid = true;

            } else {

                isOtherMobileBrowser = /avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|playbook|silk|iemobile|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(userAgent) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i.test(userAgent.substr(0, 4));

            }

            var httpMethodUpper = settings.httpMethod.toUpperCase();

            if (isAndroid && httpMethodUpper !== "GET") {
                //the stock android browser straight up doesn't support file downloads initiated by non GET requests: http://code.google.com/p/android/issues/detail?id=1780

                if ($().dialog) {
                    $("<div>").html(settings.androidPostUnsupportedMessageHtml).dialog(settings.dialogOptions);
                } else {
                    alert(settings.androidPostUnsupportedMessageHtml);
                }

                return deferred.reject();
            }

            var $preparingDialog = null;

            var internalCallbacks = {

                onPrepare: function (url) {

                    //wire up a jquery dialog to display the preparing message if specified
                    if (settings.preparingMessageHtml) {

                        $preparingDialog = $("<div>").html(settings.preparingMessageHtml).dialog(settings.dialogOptions);

                    } else if (settings.prepareCallback) {

                        settings.prepareCallback(url);

                    }

                },

                onSuccess: function (url) {

                    //remove the perparing message if it was specified
                    if ($preparingDialog) {
                        $preparingDialog.dialog('close');
                    };

                    settings.successCallback(url);

                    deferred.resolve(url);
                },

                onFail: function (responseHtml, url) {

                    //remove the perparing message if it was specified
                    if ($preparingDialog) {
                        $preparingDialog.dialog('close');
                    };

                    //wire up a jquery dialog to display the fail message if specified
                    if (settings.failMessageHtml) {
                        $("<div>").html(settings.failMessageHtml).dialog(settings.dialogOptions);
                    }

                    settings.failCallback(responseHtml, url);

                    deferred.reject(responseHtml, url);
                }
            };

            internalCallbacks.onPrepare(fileUrl);

            //make settings.data a param string if it exists and isn't already
            if (settings.data !== null && typeof settings.data !== "string") {
                settings.data = $.param(settings.data);
            }


            var $iframe,
                downloadWindow,
                formDoc,
                $form;

            if (httpMethodUpper === "GET") {

                if (settings.data !== null) {
                    //need to merge any fileUrl params with the data object

                    var qsStart = fileUrl.indexOf('?');

                    if (qsStart !== -1) {
                        //we have a querystring in the url

                        if (fileUrl.substring(fileUrl.length - 1) !== "&") {
                            fileUrl = fileUrl + "&";
                        }
                    } else {

                        fileUrl = fileUrl + "?";
                    }

                    fileUrl = fileUrl + settings.data;
                }

                if (isIos || isAndroid) {

                    downloadWindow = window.open(fileUrl);
                    downloadWindow.document.title = settings.popupWindowTitle;
                    window.focus();

                } else if (isOtherMobileBrowser) {

                    window.location(fileUrl);

                } else {

                    //create a temporary iframe that is used to request the fileUrl as a GET request
                    $iframe = $("<iframe>")
                        .hide()
                        .prop("src", fileUrl)
                        .appendTo("body");
                }

            } else {

                var formInnerHtml = "";

                if (settings.data !== null) {

                    $.each(settings.data.replace(/\+/g, ' ').split("&"), function () {

                        var kvp = this.split("=");

                        var key = settings.encodeHTMLEntities ? htmlSpecialCharsEntityEncode(decodeURIComponent(kvp[0])) : decodeURIComponent(kvp[0]);
                        if (key) {
                            var value = settings.encodeHTMLEntities ? htmlSpecialCharsEntityEncode(decodeURIComponent(kvp[1])) : decodeURIComponent(kvp[1]);
                            formInnerHtml += '<input type="hidden" name="' + key + '" value="' + value + '" />';
                        }
                    });
                }

                if (isOtherMobileBrowser) {

                    $form = $("<form>").appendTo("body");
                    $form.hide()
                        .prop('method', settings.httpMethod)
                        .prop('action', fileUrl)
                        .html(formInnerHtml);

                } else {

                    if (isIos) {

                        downloadWindow = window.open("about:blank");
                        downloadWindow.document.title = settings.popupWindowTitle;
                        formDoc = downloadWindow.document;
                        window.focus();

                    } else {

                        $iframe = $("<iframe style='display: none' src='about:blank'></iframe>").appendTo("body");
                        formDoc = getiframeDocument($iframe);
                    }

                    formDoc.write("<html><head></head><body><form method='" + settings.httpMethod + "' action='" + fileUrl + "'>" + formInnerHtml + "</form>" + settings.popupWindowTitle + "</body></html>");
                    $form = $(formDoc).find('form');
                }

                $form.submit();
            }


            //check if the file download has completed every checkInterval ms
            setTimeout(checkFileDownloadComplete, settings.checkInterval);


            function checkFileDownloadComplete() {

                //has the cookie been written due to a file download occuring?
                if (document.cookie.indexOf(settings.cookieName + "=" + settings.cookieValue) != -1) {

                    //execute specified callback
                    internalCallbacks.onSuccess(fileUrl);

                    //remove the cookie and iframe
                    document.cookie = settings.cookieName + "=; expires=" + new Date(1000).toUTCString() + "; path=" + settings.cookiePath;

                    cleanUp(false);

                    return;
                }

                //has an error occured?
                //if neither containers exist below then the file download is occuring on the current window
                if (downloadWindow || $iframe) {

                    //has an error occured?
                    try {

                        var formDoc = downloadWindow ? downloadWindow.document : getiframeDocument($iframe);

                        if (formDoc && formDoc.body != null && formDoc.body.innerHTML.length) {

                            var isFailure = true;

                            if ($form && $form.length) {
                                var $contents = $(formDoc.body).contents().first();

                                if ($contents.length && $contents[0] === $form[0]) {
                                    isFailure = false;
                                }
                            }

                            if (isFailure) {
                                internalCallbacks.onFail(formDoc.body.innerHTML, fileUrl);

                                cleanUp(true);

                                return;
                            }
                        }
                    }
                    catch (err) {

                        //500 error less than IE9
                        internalCallbacks.onFail('', fileUrl);

                        cleanUp(true);

                        return;
                    }
                }


                //keep checking...
                setTimeout(checkFileDownloadComplete, settings.checkInterval);
            }

            //gets an iframes document in a cross browser compatible manner
            function getiframeDocument($iframe) {
                var iframeDoc = $iframe[0].contentWindow || $iframe[0].contentDocument;
                if (iframeDoc.document) {
                    iframeDoc = iframeDoc.document;
                }
                return iframeDoc;
            }

            function cleanUp(isFailure) {

                setTimeout(function () {

                    if (downloadWindow) {

                        if (isAndroid) {
                            downloadWindow.close();
                        }

                        if (isIos) {
                            downloadWindow.focus(); //ios safari bug doesn't allow a window to be closed unless it is focused
                            if (isFailure) {
                                downloadWindow.close();
                            }
                        }
                    }

                    //iframe cleanup appears to randomly cause the download to fail
                    //not doing it seems better than failure...
                    //if ($iframe) {
                    //    $iframe.remove();
                    //}

                }, 0);
            }


            function htmlSpecialCharsEntityEncode(str) {
                return str.replace(htmlSpecialCharsRegEx, function (match) {
                    return '&' + htmlSpecialCharsPlaceHolders[match];
                });
            }

            return deferred.promise();
        }
    });

})(jQuery, this);

