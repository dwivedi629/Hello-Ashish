﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.switchLanguage = athoc.iws.switchLanguage || {};

if (athoc.iws) {

    if (athoc.iws.switchLanguage) {

        athoc.iws.switchLanguage = function () {
            return {
                urls: {},
                defaultLanguage: 'en-US',
                viewModel: {
                    langsupports: ko.observableArray(),
                    selectedLanguage: ko.observable(""),
                    closePopup: function () { return athoc.iws.switchLanguage.closePopup(); },
                    cancelPopup: function () { return athoc.iws.switchLanguage.cancelPopup(); },
                },

                showLanguagesSupported: function() {
                    var languageDiv = '#switchLanguageUI';
                    $(languageDiv).modal('show');
                    $(languageDiv).find(".modal-body").css("min-height", 100);
                    $("#selectLanguage").val(languageParams.currentCulture);
                    $("#selectLanguage").selectpicker('refresh');
                },

                closePopup: function() {

                    if (this.viewModel.langsupports()!=null) {
                        //cookie path is case sensitive so, we need to write cookie for each path
                        document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/;';
                        document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/client;';
                        document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/Client;';
                        document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/athoc-iws;';
                        document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/AtHoc-IWS;';
                        document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/athoc-iws/settings;';
                        document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/AtHoc-IWS/Settings;';
                        document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/SelfService/Account;';
                        document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/selfService/account;';
                       

                        $('#selectLanguageModal').css({ display: 'none' });
                        this.setSelectedLanguage();
                        window.location.reload(true);
                    }
                },

                cancelPopup: function() {
                    $('#switchLanguageUI').css({ display: 'none' });
                },

                setSelectedLanguage: function () {
                    var toData = ko.mapping.toJS(athoc.iws.switchLanguage.viewModel.langsupports);
                    var data = _.find(toData, function (toItem) {
                        return athoc.iws.switchLanguage.viewModel.selectedLanguage() === toItem.Code;
                    });
                    $(".switchLanguager").html(data.Name);
            },
           
                getSupportedLanguages: function () {
                    var self = this;
                    var url = languageParams.GetLanguagesUrl;
                    var languageDiv = '#switchLanguageUI';
                    var myAjaxOptions = {
                        url: url,
                        cache: false,
                        type: "POST",
                    };
                    var successFunction = function (data) {
                        self.viewModel.langsupports = ko.mapping.fromJS(data.Data);
                        self.viewModel.selectedLanguage(languageParams.currentCulture);
                        self.setSelectedLanguage();
                        $(languageDiv).find(".bootstrap-select").remove();
                        ko.cleanNode($(languageDiv).get(0));
                        ko.applyBindings(athoc.iws.switchLanguage.viewModel, $(languageDiv).get(0));
                        $("#selectLanguage").selectpicker();
                    }
                    var ajaxOptions = $.extend({}, AjaxUtility(null, successFunction).ajaxPostOptions, myAjaxOptions);
                    $.ajax(ajaxOptions);
                },

                load: function () {
                    athoc.iws.switchLanguage.getSupportedLanguages();
                 }
            };
        }();
    }
}

