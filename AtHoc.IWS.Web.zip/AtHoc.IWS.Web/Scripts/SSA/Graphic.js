﻿define([
    "vendors/leaflet/leaflet"
],
function (leaflet) {
    var Graphic = function (params) {
        if (!params.symbol) {
            //default symbol
            params.symbol = "/athoc-cdn/Scripts/lib-vendor/leaflet/images/marker-icon.png";
            params.symbolSize = [24, 40];
        }
            var icon = leaflet.icon({
                iconUrl: params.symbol,
                iconSize: params.symbolSize || [24, 24], // size of the icon
                //shadowSize: [50, 64], // size of the shadow
                iconAnchor: params.anchor || [12, 24], // point of the icon which will correspond to marker's location
                //shadowAnchor: [4, 62],  // the same for the shadow
                popupAnchor: [0, -25] // point from which the popup should open relative to the iconAnchor
            });
        this.marker = leaflet.marker(params.geometry,
        { icon: icon });
        this.marker.id = params.id;
        if (params.popup) {
            this.popup = this.marker.bindPopup(params.popup);
        }
        this.geometry = params.geometry;
        this.symbol = params.symbol;
        this.size = params.symbolSize || [24, 24];
        this.id = params.id;
        this.popup = params.popup;
    };
   
    return Graphic;
});