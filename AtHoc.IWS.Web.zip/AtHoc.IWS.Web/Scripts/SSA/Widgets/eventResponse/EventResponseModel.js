﻿define([requireModuleNames.knockout, "ssa/eventManagerUtil"], function (ko, eventManagerUtil) {
    function Model() {
        this.eventId = ko.observable();
        this.replyStart = ko.observable();
        this.replyComplete = ko.observable();
        this.responseOptions = ko.observableArray();
        this.responseId = ko.observable();
        this.deliveryContext = ko.observable();
        this.reply = function (model, item) {
            $("#responseModal").modal('hide');
            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: '/athoc-cdn/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000 }).showLoader();
            var url = "/athoc-iws/eventManager/UpdateReplyStatus",
                data = {};
            data.responseOptionId = this.responseId();
            $.each(this.responseOptions(), function(idx, option) {
                if (option.OptionId === data.responseOptionId) {
                    data.replyMsg = $.htmlEncode(option.ResponseText);
                    return;
                }
            });
            data.eventId = this.eventId();
            data.messagecontext = this.deliveryContext();
            var self = this;
            $.ajax({
                type: "POST",
                url: url,
                tranditional: true,
                data: data,
                success: function (response) {
                    self.replyComplete(response);
                    $.AjaxLoader.hideLoader();
                    if (!response.IsSuccess) {
                        eventManagerUtil.showMsgModal("Reply to this event failed.");
                    }
                },
                error: function (xhr, textStatus, error) {
                    $.AjaxLoader.hideLoader();
                    AjaxUtility().ajaxPostOptions.error(xhr, textStatus, error);
                    eventManagerUtil.showMsgModal("An error occurred.");
                }
            });
        };
    }

    return Model;
});