﻿define([requireModuleNames.knockout], function (ko) {   
    function Model() {        
        var self = this;
        self.sourceName = ko.observable();
        self.updatedOn = ko.observable();
        self.fields = ko.observableArray([]);
        self.sectionTitleText = ko.observable();        
    }    

    return Model;
});