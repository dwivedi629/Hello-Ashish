define([requireModuleNames.knockout, "ssa/eventManagerUtil"], function (ko, eventManagerUtil) {
    function Model(i18n) {
        var self = this;
        this.alertUrl = ko.observable();
        this.id = ko.observable();
        this.showReview = ko.observable(false);//to show/hide Review
        this.showPublish = ko.observable(false);//to show/hide Publish
        this.showReply = ko.observable(false);//to show/hide Reply
        this.showModify = ko.observable(false);//to show/hide Edit/New
        this.showAcceptDecline=ko.observable(false);//to show/hide Accept/Decline
        this.showTitle = ko.observable(true);
        this.showEventType = ko.observable(true);
        this.showSeverity = ko.observable(true);
        this.showUpdatedOn = ko.observable(false);//to show/hide Updated On
        this.linkToAlert = ko.observable();
        this.isPermitPublish =ko.observable(false);
        this.isPermitModify = ko.observable(false);
        this.isPermitReview = ko.observable(false);
        this.isPermitAcceptDecline = ko.observable(false);
        this.title = ko.observable();
        this.body = ko.observable();
        this.originalTitle = ko.observable();
        this.originalBody = ko.observable();
        this.originalEventCategoryId = ko.observable();
        this.eventCategoryId = ko.observable();
        this.endTime = ko.observable();
        this.expired = ko.observable();
        this.descriptions = ko.observableArray();
        this.description = ko.observable();
        this.getUserInfo = ko.observable();
        this.latitude = ko.observable();
        this.longitude = ko.observable();
        this.hasGeo = ko.observable();
        this.hasMedia = ko.observable();
        this.sourceId = ko.observable();
        this.sourceName = ko.observable();
        this.sourceType = ko.observable();
        this.reviewedByLabel = ko.observable();
        this.sourceCss = ko.computed({
            read: function () {
                if (this.sourceType()) {
                    var className = "event-mgr-sprite-";
                    className += this.sourceType().toLowerCase();
                    return className;
                }
            },
            owner: this
        });
        this.sourceNameCss = ko.computed({
            read: function () {
                if (this.sourceName()) {
                    if (this.sourceName().trim().length==0)
                    return "pad-top20";
                }
            },
            owner: this
        });
        this.responded = ko.observable();
        this.respondedOn = ko.observable();
        this.respondedByDisplayName = ko.observable();
        this.response = ko.observable();
        this.connectInvitationId = ko.observable();
        this.canReply = ko.observable();//to enable/disable Reply
        this.canAcceptDecline = ko.observable();//to enable/disable Accept/Decline
        this.canReviewed = ko.observable();//to enable/disable Review
        this.severity = ko.observable();
        this.severityText = ko.observable();
        this.severityId = ko.observable();
        
        this.type = ko.observable();
        this.typeIcon = ko.observable();
        this.createdOn = ko.observable();
        this.updatedOn = ko.observable();
        this.graphic = ko.observable();
        this.medias = ko.observableArray();
        this.reviewed = ko.observable();
        this.reviewedByDisplayName = ko.observable();
        this.reviewedOn = ko.observable();
        this.geoJson = ko.observable();
        this.change = ko.observable(false);
        this.connectActionValue = ko.observable();
        this.severityCss = ko.computed({
            read: function () {
                if (this.severity()) {
                    var className = "event-mgr-sprite-";
                    className += this.severity().toLowerCase();
                    return className;
                }
            },
            owner: this
        });

        this.forwardBtnText = ko.observable();
        this.sentLabel = ko.observable();

        this.reply = function () {
        };
        this.markReviewed = function (data, evt) {
            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: '/athoc-cdn/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000,displayText: i18n.Event_General_LoadingMessage  }).showLoader();
            var reviewed = !data.reviewed(),
                eventId = data.id;
            $.ajax({
                type: "POST",
                url: "/athoc-iws/eventManager/updateEventReviewStatus",
                dataType: "json",
                data: {
                    eventId: [eventId],
                    reviewed: reviewed
                },

                success: $.proxy(function (e) {
                    if (e.Success) {
                        this.change(true);
                    } else {
                        eventManagerUtil.showMsgModal("The operation failed.");
                    }
                }, this),
                error: function (xhr, textStatus, error) {
                    $.AjaxLoader.hideLoader();
                    AjaxUtility().ajaxPostOptions.error(xhr, textStatus, error);
                    eventManagerUtil.showMsgModal("The operation failed.");
                },
                traditional: true
            });
        };
        this.downloadMedia = function (data) {
            var mediaGuid;
            if (data.ContentType.indexOf("image/") > -1) {
                mediaGuid = data.OriginalImage;
            } else if (data.ContentType.indexOf("video/") > -1) {
                mediaGuid = data.VideoMpeg || data.VideoMP4 || data.VideoQT || data.VideoWM;
            }
            var timestamp = (new Date()).getTime();
            if ((navigator.userAgent.match(/iPad/i) != null) || (navigator.userAgent.match(/Android/i) != null)) {
                window.open(mediaGuid + "?download=true&ts=" + timestamp);
            } else {
                window.location = mediaGuid + "?ts=" + timestamp;
            }
        };
        this.displayMedia = function (data) {
            var mediaGuid, isVideo, isConverted;
            if (data.ContentType.indexOf("image/") > -1) {
                mediaGuid = data.OriginalImage || data.MediumImage;
                isVideo = false;
            } else if (data.ContentType.indexOf("video/") > -1) {
                mediaGuid = data.VideoQT || data.VideoMpeg || data.VideoMP4 || data.VideoWM;
                if (mediaGuid) {
                    isConverted = true;
                }
                isVideo = true;
            }
            var origHeight = data.OriginalHeight,
                origWidth = data.OriginalWidth,
                rotation = data.Rotation,
                createdOn = data.CreatedOn;


            var displayMediaFunc = function (origHeight, origWidth, createdOn) {
                var _timestamp = (new Date()).getTime();
                var maxHeight = 400;
                var maxWidth = 600;
                var minHeight = 250;
                var minWidth = 300;

                origHeight = origHeight || 150;
                origWidth = origWidth || 150;

                origHeight = Math.max(origHeight, minHeight);
                origWidth = Math.max(origWidth, minWidth);

                var height = origHeight;
                var width = origWidth;

                var html = "";

                if (origWidth > maxWidth) {
                    width = maxWidth;
                }

                height = origHeight * width / origWidth;
                if (height > maxHeight) {
                    width = origWidth * maxHeight / origHeight;
                    height = maxHeight;
                }

                if (isVideo) {
                    if (isConverted) {
                        if ((navigator.userAgent.match(/Firefox/)) || (navigator.userAgent.match(/Chrome/))) {
                        //if (Modernizr.video) {
                            html += '<video id="MediaPlayer" width="' + width + 'px" height="' + height + 'px" controls>';
                            //html += '<source src="' + mediaGuid + '?mediaType=3&ts=' + _timestamp + '" />';this causes the progress bar not draggable
                            html += '<source src="' + mediaGuid + '?mediaType=2&ts=' + _timestamp + '" />';
                            html += '</video>';
                        } else if (navigator.userAgent.match(/Safari/)) {
                            html += '<video id="MediaPlayer" width="' + width + 'px" height="' + height + 'px" controls>';
                            html += '<source src="' + mediaGuid + '?mediaType=2&ts=' + _timestamp + '" />';
                            html += '</video>';

                        }
                            //For IE 11 on windows 10 - video does not play using OBJECT embed. However, it support VIDEO tag.
                        else if (navigator.userAgent.match(/rv:11.0/)) {
                            html += '<video id="MediaPlayer" width="' + width + 'px" height="' + height + 'px" controls>';
                            html += '<source src="' + mediaGuid + '?ts=' + _timestamp + '" type="video/mp4"/>';
                            html += '</video>';

                        }
                        else {
                            html += '<OBJECT ID="MediaPlayer" CLASSID="CLSID:22D6F312-B0F6-11D0-94AB-0080C74C7E95" STANDBY="Loading Windows Media Player components..." TYPE="video/mpeg">';
                            html += '    <PARAM NAME="FileName" VALUE="' + mediaGuid + '?mediaType=1&ts=' + _timestamp + '">';
                            html += '    <PARAM name="autostart" VALUE="true">';
                            html += '    <PARAM name="ShowControls" VALUE="true">';
                            html += '    <param name="ShowStatusBar" value="false">';
                            html += '    <PARAM name="allowfullscreen" VALUE="true">';
                            html += '    <PARAM name="ShowDisplay" VALUE="false">';
                            html += '    <EMBED TYPE="application/x-mplayer2" SRC="' + mediaGuid + '?mediaType=1&ts=' + _timestamp + '" NAME="MediaPlayer" id="MediaPlayer" WIDTH="' + width + 'px" HEIGHT="' + height + 'px"></EMBED>';
                            html += '</OBJECT>';
                        }
                    } else {
                        html = "Unable to play media because it has not been processed yet.";
                    }
                } else {
                    var transposeNum = rotation / 90;
                    if (transposeNum == 1 || transposeNum == 3) {
                        var tmpHeight = height;
                        height = width;
                        width = tmpHeight;
                    }

                    html = "<img src='" + mediaGuid + "?ts=" + _timestamp + "' style='height:" + height + "px;width:" + width + "px;' />";
                }

                $("#mediaModal").find(".modal-body").empty();
                $("#mediaModal").css("width", width + 30 + "px");
                $("#mediaModal").css("margin-left", (-width/2) + "px");
                $("#mediaModal").find(".modal-body").append($(html));
                $("#mediaModal").find(".modal-header").empty();
                $("#mediaModal").find(".modal-header").append($("<h3>Uploaded on: " + createdOn + "</h3>"));
                $("#mediaModal").modal();

               
            };

            if (isVideo && isConverted) {
                //get media info
                this._videoTs = createdOn;
                this._videoWidth = origWidth;
                this._videoHeight = origHeight;
                //$.get(mediaGuid + "?mediaType=1", $.proxy(function (data) {
                    //if (data) {
                        displayMediaFunc(this._videoHeight, this._videoWidth, this._videoTs);
                    //}
                //}, this));
            } else {
                displayMediaFunc(origHeight, origWidth, createdOn);
            }
        };
        this.events = {};
        this.events.publishAlert = function () { };
        this.performConnectAction = function (data, evt) { };
    }

    return Model;
});