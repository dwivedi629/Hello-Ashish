﻿define([requireModuleNames.knockout, requireModuleNames.komapping, requireModuleNames.kovalidation, requireModuleNames.iwsHelper], function (ko, mapping, kovalidation, helper) {
    // note: we must define the kovalidation here, so it loads it into teh ko
    function Model() {
        var self = this;
        var data = { id: 0, isNew: false, eventBody: '', eventTitle: '', eventUrl: '', categoryId: 0, severities: [], severityId: 0, }
        self.getValidation = function () {
            var validationMapping = {
                eventTitle: {
                    create: function (options) {
                        return ko.observable(options.data).extend({
                            required: {
                                params: true,
                                message: athoc.iws.event.resources.Publishing.Publishing_Validation_Title
                            },      
                            minLength: {
                                params: 3,
                                message: athoc.iws.event.resources.Publishing.Publishing_Validation_Title
                            },
                            maxLength: {
                                params: 100,
                                message: athoc.iws.event.resources.Publishing.Publishing_Validation_Title
                            },
                        });
                    }
                },
                eventBody: {
                    create: function (options) {
                        return ko.observable(options.data).extend({
                            maxLength: {
                                params: 4000,
                                message: athoc.iws.event.resources.Publishing.Publishing_Validation_Body
                            },
                        });
                    }
                },
            };

            return validationMapping;
        };

        var subModel = ko.mapping.fromJS(data, self.getValidation());
        $.extend(self, subModel);

        self.saveComplete = ko.observable();
        self.updateComplete = ko.observable();

        self.submitText = ko.computed({
            read: function () {
                return (self.isNew() ? athoc.iws.event.resources.organization.Organization_Create_Log_Btn : athoc.iws.event.resources.organization.Organization_Update_Log_Btn);
            },
            owner: self
        });

        self.titleText = ko.computed({
            read: function () {
                return (self.isNew() ? athoc.iws.event.resources.organization.Organization_Title_Add_Log_Entry : athoc.iws.event.resources.organization.Organization_Title_Update_Log_Entry);
            },
            owner: self
        });

        self.clearValidation = function () {
            ko.validation.group(self, { deep: true }).showAllMessages(false);
        }

        self.onSavePublishClick = function () {
            var result = ko.validation.group(self, { deep: true });
            if (result().length > 0) {
                result.showAllMessages(true);
                return false;
            }
            return self.save(true);
        }

        self.onSaveClick = function () {
            var result = ko.validation.group(self, { deep: true });
            if (result().length > 0) {
                result.showAllMessages(true);
                return false;
            }

            return self.save(false);
        }

        self.save = function (publish) { };

        self.eventUrl.subscribe(function(newValue) {
            if (!newValue) {
                return;
            }
            var prefix = "http://";
            var httpsPrefix = "https://";
             newValue = (newValue.toLowerCase().replace(/ /g, ""));
            if (newValue != "") {
              var prefixIndex = newValue.indexOf(prefix);
            if (prefixIndex === -1) {
                prefixIndex = newValue.indexOf(httpsPrefix);
            }
            if (prefixIndex === -1 || prefixIndex > 0)
                newValue = prefix + newValue;
            }
            self.eventUrl(newValue);

        });

        self.showCreateAndForward = ko.observable(false);
    }

    return Model;
});