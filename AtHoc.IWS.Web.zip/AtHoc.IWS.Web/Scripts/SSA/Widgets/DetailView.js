define([
	requireModuleNames.knockout,
    "widget/BaseWidget",
    "widget/Map",
    "widget/AlertPublisher",
    "widget/UserInfo",
    "widget/OrgInfo",
    "widget/HistoryInfo",
    "widget/EventResponse",
    "ssa/Graphic",
    "widget/detailView/Model",
    "vendors/text!widget/detailView/template.html",
    "ssa/eventManagerUtil"
], function (ko, BaseWidget, Map, AlertPublisher, UserInfo, OrgInfo, HistoryInfo, EventResponse, Graphic, Model, template, util) {

    //constructor
    var DetailView = function (refDomNode, params) {
        BaseWidget.call(this, refDomNode, template, Model, []);
        var self = this;
        this.model.isPermitReview(params && params.isPermitReview);
        this.model.isPermitPublish(params && params.isPermitPublish);
        this.model.isPermitModify(params && params.isPermitModify);
        this.model.isPermitAcceptDecline(params && params.isPermitAcceptDecline);
        ko.bindingHandlers.createMap = {
            init: $.proxy(function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                this.map = new Map("mapHolder", { zoomControl: false, zoomToFitControl: true, i18n: this.model.i18n, culture: params.culture });
            }, this),
            update: $.proxy(function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                this.map.removeGeoJson();
                this.geoJson = viewModel.geoJson();
                if (this.geoJson && this.geoJson.features && this.geoJson.features.length > 0) {
                    this.map.addGeoJson(this.geoJson);
                    this.map.zoomToFit();
                }
            }, this)
        };

        //dynamically change the height of the widget
        $(window).resize($.proxy(function () {
            this.fitHeight();
        }, this));

        //append modal for big map
        //it cannot be in the template, which make it behind other component of the page
        $('<div id="mapModal" data-backdrop="static" class="form-horizontal modal hide fade in width720" style="height:500px;margin-left:-360px;" aria-hidden="false">' +
            '<div class="modal-header"><h2></h2></div>' +
            '<div id="bigMapHolder" style="width:100%;height:408px;"></div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn" data-dismiss="modal" aria-hidden="true">' + this.model.i18n.Event_Close_Button + '</button></div>' +
            '</div>').appendTo("body");
        this.bigMap = new Map("bigMapHolder", { zoomToFitControl: true, bingMapToggleControl: true,i18n: this.model.i18n, culture: params.culture });
        $('#mapModal').on('shown.bs.modal', $.proxy(function () {
            this.bigMap.removeGeoJson();
            var title = $("<div id='escapeDiv'></div>").text(this.model.title()).html();
            if (this.geoJson && this.geoJson.features && this.geoJson.features.length > 0) {
                this.bigMap.addGeoJson(this.geoJson);
                this.bigMap.zoomToFit();
            }
            $('#mapModal').find("h2").text(title);
        }, this));

        //append modal for media display
        $('<div id="mediaModal" class="modal hide fade" tabindex="-1" role="dialog" aria-hidden="true">' +
            '<div class="modal-header" style="margin-top:0px;"></div>' +
            '<div class="modal-body">' +
            '</div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn" data-dismiss="modal" aria-hidden="true" onclick="$(\'#mediaModal\').hide();$(\'#mediaModal\').find(\'.modal-body\').empty();">' + this.model.i18n.Event_Close_Button + '</button></div>' +
            '</div>').appendTo("body");

        //instantiate user info widget
        $('<div id="userInfoHolder"></div>').appendTo("body");
        var userInfo = new UserInfo("userInfoHolder");
        userInfo.startup();
        //instantiate org info widget
        $('<div id="orgInfoHolder"></div>').appendTo("body");
        var orgInfo = new OrgInfo("orgInfoHolder");
        orgInfo.startup();
        //instantiate history info widget
        $('<div id="historyInfoHolder"></div>').appendTo("body");
        self.historyInfo = new HistoryInfo("historyInfoHolder");
        self.historyInfo.startup();

        //events
        this._firstTimeBigMapShow = true;
        $("#expandMap", this.refDomNode).on("click", $.proxy(function (evt) {
            $("#mapModal").modal("show");
            if (this._firstTimeBigMapShow) {
                setTimeout($.proxy(function () {
                    this.bigMap.removeGeoJson();
                    this.bigMap.reCalculateSize();
                    var title = $("<div id='escapeDiv'></div>").text(this.model.title()).html();
                    if (this.geoJson && this.geoJson.features && this.geoJson.features.length > 0) {
                        this.bigMap.addGeoJson(this.geoJson);
                        this.bigMap.zoomToFit();
                    }
                    $('#mapModal').find("h2").text(title);
                }, this), 500);
                this._firstTimeBigMapShow = false;
            }
        }, this));
        //this.model.change controls anything changes, such as mark reviewed/notreviewed, reply and so on.
        this.model.change.extend({ notify: "always" });
        //when anything changes
        this.model.change.subscribe($.proxy(function () {
            this.change();
        }, this));

        //get user info
        $("#userInfoLink", this.refDomNode).on("click", $.proxy(function () {
            if (this.model.sourceType() === "USER") {
                userInfo.update({ userId: this.model.sourceId(), userName: this.model.sourceName() });
            }
            else if (this.model.sourceType() === "ORGANIZATION") {
                orgInfo.update({ orgId: this.model.sourceId(), orgName: this.model.sourceName() });
            }
        }, this));

        this.fitHeight();

        $('<div id="alertHolder"></div>').appendTo("body");
        //instantiate an alert publisher widget
        this.alertPublisher = new AlertPublisher("alertHolder");
        this.alertPublisher.startup();

        //because map won't be able to get the div size unless the div is visible when the modal opens
        this._firstTimeMapDisplay = true;

        //create event response widget
        $("<div id='eventResponseHolder'></div>").appendTo("body");
        var eventResponse = new EventResponse("eventResponseHolder");
        eventResponse.startup();
        eventResponse.on("replyComplete", function (e) {
            self.change();
        });
        
        util.getSeverityList(function (severities) {
            self.model.severityList = ko.observable(severities);
        });

        this.model.reply = function (data) {
            $("#responseModal").modal();
            eventResponse.update({ eventId: data.id() });
        };
        this.model.edit = function () {
            createEvent.showEditEventDlg(self.model);
        };

        this.model.showHistory = function () {
            self.historyInfo.showDlg();
        };
        
        this.publishAlert = function () {
            this.model.originalTitle('');
            this.model.originalBody('');
            this.model.events.publishAlert();
        };

        this.model.events.publishAlert = function () {
            //starting from 87, it uses full publisher
            /*
            self.alertPublisher.updateContent(self.model);
            $("#sendAlertModal").modal();
            */
            var alertForm = document.createElement("form");
            //alertForm.target = "AlertPublisher";
            alertForm.method = "POST";
            alertForm.action = "/athoc-iws/alertmanager?nav=c&source=e";
            var alertTitle = document.createElement("input");
            alertTitle.type = "hidden";
            alertTitle.name = "Title";
            if (self.model.originalTitle() != undefined && self.model.originalTitle() != '') {
                alertTitle.value = $("<div id='decodeDiv'></div>").html(self.model.originalTitle()).text();
            } else {
                alertTitle.value = $("<div id='decodeDiv'></div>").html(self.model.title()).text();
            }
            alertForm.appendChild(alertTitle);

            var alertDesc = document.createElement("input");
            alertDesc.type = "hidden";
            alertDesc.name = "Description";
            if (self.model.originalBody() != undefined && self.model.originalBody()!='') {
                alertDesc.value = $("<div id='decodeDiv'></div>").html(self.model.originalBody()).text();
            } else {
                alertDesc.value = $("<div id='decodeDiv'></div>").html(self.model.description()).text();
            }
           
            alertForm.appendChild(alertDesc);

            var alertEventCategoryId = document.createElement("input");
            alertEventCategoryId.type = "hidden";
            alertEventCategoryId.name = "EventCategoryId";
            if (self.model.originalEventCategoryId() != undefined) {
                alertEventCategoryId.value = self.model.originalEventCategoryId();
            } else {
                alertEventCategoryId.value = self.model.eventCategoryId();
            }
            alertForm.appendChild(alertEventCategoryId);

            var alertType = document.createElement("input");
            alertType.type = "hidden";
            alertType.name = "Type";
            alertType.value = self.model.type();
            alertForm.appendChild(alertType);

            var alertSeverity = document.createElement("input");
            alertSeverity.type = "hidden";
            alertSeverity.name = "Severity";
            alertSeverity.value = self.model.severity();
            alertForm.appendChild(alertSeverity);

            var alertUrl = document.createElement("input");
            alertUrl.type = "hidden";
            alertUrl.name = "Url";
            alertUrl.value = self.model.alertUrl();
            alertForm.appendChild(alertUrl);

            var geoJson = { type: "FeatureCollection", features: [] };
            if (self.model.geoJson()) {
                geoJson = self.model.geoJson();
            }
            if (geoJson.features.length > 0) {
                var geoJsonStr = JSON.stringify(geoJson);
                var alertGeoJson = document.createElement("input");
                alertGeoJson.type = "hidden";
                alertGeoJson.name = "GeoJson";
                alertGeoJson.value = geoJsonStr;
                alertForm.appendChild(alertGeoJson);
            }

            document.body.appendChild(alertForm);
            alertForm.submit();
        };
       
        $('#genericConfirmationOk').off('click').on('click', function (e) {
            e.preventDefault();
            self.model.actionConnect();
            $('#dlgGenericConfirmation').modal('hide'); //Once reset is done, then close modal window
        });
        this.model.actionConnect = function (action) {
            var model = this;
            var data = {
                "invitationId": model.connectInvitationId,
                "alertId": model.id,
                "action": model.connectActionValue,
                "sourceOrgGuid":model.sourceId
            }; //where 1 => Accept
            var url = "/athoc-iws/eventmanager/SetConnectAction";
            $.ajax({
                type: "POST",
                url: url,
                data: data,
                success: function (response) {
                    //If error
                    if (!response || !response.Success) {
                        //modal shows msg as "no response options"
                        util.showMsgModal(response.Message);
                    }
                    //Refresh the view.
                    model.change(true);
                },
                error: function (xhr, textStatus, error) {
                    AjaxUtility().ajaxPostOptions.error(xhr, textStatus, error);
                }
            });
            
        };
        this.model.acceptConnect = function () {
            var model = this;
            this.connectActionValue(1); //1 Accept
            $('#dlgGenericConfirmation .genericHeaderMesage').html(athoc.iws.event.resources.accept.Organization_accept_confirm_title); //set Header Title
            $('#dlgGenericConfirmation .genericBodyContent').html('<h3 class="line-height16">' + kendo.format(athoc.iws.event.resources.accept.Organization_accept_confirm_body, model.sourceName()) + '</h3>'); //Set Confirmation Message
            $('#dlgGenericConfirmation .genericBodyContent_SubSection').html(athoc.iws.event.resources.accept.Organization_accept_confirm_footer);

            $("#dlgGenericConfirmation").modal();
           
        };
        this.model.declineConnect = function () {
            var model = this;
            this.connectActionValue(3); // 3 Decline
            $('#dlgGenericConfirmation .genericHeaderMesage').html(athoc.iws.event.resources.decline.Organization_decline_confirm_title); //set Header Title
            $('#dlgGenericConfirmation .genericBodyContent').html('<h3 class="line-height16">' + kendo.format(athoc.iws.event.resources.decline.Organization_decline_confirm_body, model.sourceName()) + '</h3>'); //Set Confirmation Message
            $('#dlgGenericConfirmation .genericBodyContent_SubSection').html(athoc.iws.event.resources.decline.Organization_decline_confirm_footer);
            $("#dlgGenericConfirmation").modal();
            

        };
    };


    $.extend(DetailView.prototype, {
        offset: 0,
        fitHeight: function () {
            var extraSpace = this.offset;
            var footerHeight = $('#pageFooter').height();
            $(".bucket", this.refDomNode).css("height", $(window).height() - (footerHeight + 245) - extraSpace);
            $(".msg-detail", this.refDomNode).css("height", $(window).height() - 263 - 150 - extraSpace);
            $(".msg-detail-container").css("height", 100000);
        },
        update: function (content) {
            if (this.refreshDeferred) {
                //when updating the content, it should cancel the previous update request if there is any
                this.refreshDeferred.abort();
            }
            
            this.model.id(content.Id);
            this.model.expired(content.IsExpired);
            this.model.title(content.Title);
            this.model.body(content.Body);
            this.model.eventCategoryId(content.EventCategoryId);
            this.model.originalEventCategoryId(null);//make sure to reset the value. While forwarding, it retain the old value.
            if (content.AdditionalInfo != null) {
                this.model.originalTitle(content.AdditionalInfo['OriginalTitle']);
                this.model.originalBody(content.AdditionalInfo['OriginalBody']);
                this.model.originalEventCategoryId(content.AdditionalInfo['OriginalEventCategoryId']);
            } else {
                this.model.originalTitle('');
                this.model.originalBody('');
            }
            

            this.model.severity(content.severityType);
            this.model.severityId(content.severityId);
            var i18NEventCateProp = Object.getOwnPropertyDescriptor(this.model.i18n, 'Event_Severity_' + content.severityType);
            //set default as category type from db.
            var i18NEventCateValue = content.severityType;

            //Making sure fall back work for i18n
            if (i18NEventCateProp) {
                i18NEventCateValue = i18NEventCateProp.value;
            }
            this.model.severityText(i18NEventCateValue);
            this.model.type(content.EventCategoryName);
            this.model.typeIcon(content.typeIcon);
            this.model.sourceId(content.UserId || content.SourceId);
            this.model.sourceName(content.SourceName);
            this.model.sourceType(content.SourceType);
            this.model.descriptions(content.Description.split("\n"));
            this.model.description(content.Description);
            if (content.AlertUrl && content.AlertUrl.toLowerCase().indexOf("http") !== 0) {
                content.AlertUrl = "http://" + content.AlertUrl;
            }
            this.model.alertUrl(content.AlertUrl);
            this.model.createdOn(content.CreatedOn);
            this.model.updatedOn(content.UpdatedOn);
            this.model.responded(content.Responded);
            this.model.response(content.Response);
            this.model.respondedOn(content.RespondedOn);
            this.model.respondedByDisplayName(content.RespondedByDisplayName);
            this.model.reviewed(content.Reviewed);
            this.model.reviewedByDisplayName(content.ReviewedByDisplayName);
            this.model.reviewedOn(content.ReviewedOn);
            this.model.endTime(content.EndTime);
            this.model.medias(content.Medias);
            this.model.canReply(content.CanReply);
            this.model.canAcceptDecline(content.CanAcceptDecline);
            this.model.canReviewed(content.CanReviewed);
            this.model.connectInvitationId(content.ConnectInvitationId);
            this.model.showPublish(content.ShowPublish);
            this.model.showReply(content.ShowReply);
            this.model.showAcceptDecline(content.ShowAcceptDecline);
            this.model.showModify(content.ShowModify);
            this.model.showReview(content.ShowReview);
            if (content.LocalAlertId) {
                this.model.linkToAlert("/athoc-iws/AlertManager/ReportView?id=" + content.LocalAlertId);
            } else {
                this.model.linkToAlert("");
            }
            this.model.reviewedByLabel(this.model.i18n.Inbox_Reviewed_by);
            
            this.model.forwardBtnText(content.Type.toLowerCase() == "log" ? this.model.i18n.Event_Forward_As : this.model.i18n.Event_Forward);
            this.model.sentLabel(content.Type.toLowerCase() == "log" ? this.model.i18n.Inbox_DetailView_Created : this.model.i18n.Inbox_DetailView_Sent);
            
            if (content.Medias && content.Medias.length > 0) {
                this.model.hasMedia(true);
            } else {
                this.model.hasMedia(false);
            }
            var geoJson;
            if (content.Latitude || content.Longitude || content.GeoJson) {
                if (content.GeoJson) {
                    geoJson = $.parseJSON(content.GeoJson);
                    if (geoJson && geoJson.features && geoJson.features.length > 0) {
                        $.each(geoJson.features, function (idx, feature) {
                            //add properties
                            if (!feature.properties) {
                                feature.properties = {};
                            }
                            feature.properties.isInbound = true;
                            feature.properties.editable = false;
                            //truncate decimal digits
                            if (feature.geometry) {
                                switch (feature.geometry.type.toLowerCase()) {
                                    case "polygon":
                                        $.each(feature.geometry.coordinates, function (idx, coordinate) {
                                            $.each(coordinate, function (idx, values) {
                                                values[0] = parseInt(values[0] * 1000000) / 1000000;
                                                values[1] = parseInt(values[1] * 1000000) / 1000000;
                                            });
                                        });
                                        break;
                                    case "multipolygon":
                                        $.each(feature.geometry.coordinates, function (idx, coordinate) {
                                            $.each(coordinate, function (idx, values) {
                                                $.each(values, function (idx, valuePair) {
                                                    valuePair[0] = parseInt(valuePair[0] * 1000000) / 1000000;
                                                    valuePair[1] = parseInt(valuePair[1] * 1000000) / 1000000;
                                                });
                                            });
                                        });
                                        break;
                                }
                            }
                        });
                    }
                }
                if (content.Latitude || content.Longitude) {
                    if (!geoJson || !geoJson.features) {
                        geoJson = { type: "FeatureCollection", features: [] };
                    }
                    geoJson.features.push({
                        "type": "Feature",
                        "properties": {
                            "name": this.model.title(),
                            "description": this.model.description(),
                            "editable": false,
                            "isInbound": true,
                            "symbol": {
                                type: "esriPMS",
                                //url: this.model.typeIcon(),
                                url: "/athoc-cdn/images/icon-alert-incoming.png",
                                width: 32,
                                height: 32
                            }
                        },
                        "geometry": {
                            "type": "Point",
                            "coordinates": [content.Longitude, content.Latitude] //geojson coordinates order reversely as leaflet point coordinate array
                        }
                    });
                    this.model.latitude(content.Latitude.toFixed(4));
                    this.model.longitude(content.Longitude.toFixed(4));
                }
                this.model.hasGeo(true);
                this.model.geoJson(geoJson);
            } else {
                this.model.hasGeo(false);
                this.model.geoJson(null);
            }

            //adjust the detail description width if there is no map or media
            if ((!this.model.hasGeo()) && (!this.model.hasMedia())) {
                $(".msg-detail-text", this.refDomNode).css("width", "auto");
            } else {
                $(".msg-detail-text", this.refDomNode).css("width", "200px");
            }

            var self = this;
            if (self._firstTimeMapDisplay && self.model.hasGeo()) {
                setTimeout(function () {
                    self.map.reCalculateSize();
                    self.map.zoomToFit();
                }, 300);
                self._firstTimeMapDisplay = false;
            }
            if (content.HistoryInfo.length > 0)
                this.model.showUpdatedOn(true);
            else
                this.model.showUpdatedOn(false);
            this.historyInfo.update(content.HistoryInfo);
            

            //for some reason, the mark as reviewed button doesn't show the title with ko binding.
            //$("#markReviewedBtn", this.refDomNode).prop('title', content.Reviewed ? 'Mark as Reviewed' : 'Mark as Not Reviewed');
        },
        refresh: function () {
            var currentId = this.model.id();
            this.refreshDeferred = util.getEventById(currentId, $.proxy(function (data)
            {
                try {
                    $.AjaxLoader.hideLoader();
                } catch (err) {
                    //the loader has not been shown yet.
                    //console.log(err);
                }
                //while waiting for the update, the current selected item for the detail view may change (user clicks on another row)
                //if it's still the same one, then apply the change.
                //this.refreshDeferred.abort() should take care of this. Here is just for safe reason.
                if (currentId === data.id) {
                    this.update(data);
                }
            }, this));
        },
        closeDetailView: function () {
            //console.log("from the widget, close");
            this.close();
        },
        //convenient way to connect to UI events and handlers
        //events
        change: function () { }
    });
    return DetailView;
});