﻿define([
	requireModuleNames.knockout,
    "widget/BaseWidget",
    "widget/historyInfo/Model",
    "vendors/text!widget/historyInfo/template.html",
    "ssa/eventManagerUtil"
], function (ko, BaseWidget, Model, template, eventManagerUtil) {
    //constructor
    var HistoryInfo = function (refDomNode) {
        BaseWidget.call(this, refDomNode, template, Model, []);        
    };
    var self = this;
    self.changes = ko.observableArray([]);
    $.extend(HistoryInfo.prototype,
    {
        update: function(evengInfo) {           
            self.changes.removeAll();
            for (var i = 0 ; i < evengInfo.length; i++) {
                var model = new Model();
                model.sourceName(evengInfo[i].SourceName);
                model.updatedOn(evengInfo[i].UpdatedOn); 
                model.sectionTitleText(kendo.format(this.model.i18n.Event_History_Section_Title, evengInfo[i].UpdatedOn, evengInfo[i].SourceName));
                model.fields.removeAll();
                for (var j = 0; j < evengInfo[i].FieldEntries.length; j++) {
                    var fieldName = evengInfo[i].FieldEntries[j].FieldName;
                    var newValue = evengInfo[i].FieldEntries[j].NewValue;
                    var oldValue = evengInfo[i].FieldEntries[j].OldValue;
                    model.fields.push({ fieldName: fieldName, oldValue: oldValue, newValue: newValue });
                }
                self.changes.push(model);
            }
        },
        showDlg: function() {
            var self = this;
            var model = this.model;
            $('#dlgHistoryInfo').modal();
        }
        

    });
  //  self.model.changes.push();
    return HistoryInfo;
});