﻿define([requireModuleNames.knockout, "ssa/eventManagerUtil"], function (ko, eventManagerUtil) {
    function Model() {
        var self = this;
        this.title = ko.observable("");
        this.msg = ko.observable("");
        this.url = ko.observable("");
        this.newResponse = ko.observable();
        this.newResponse.subscribe(function() {
            if (self.newResponse() && self.newResponse().length > 64) {
                self.canValidationMsg(true);
                self.validationMsg("Response Option must be less than 64 characters.");
            } else {
                self.canValidationMsg(false);
                self.validationMsg("");
            }
        });
        this.canValidationMsg = ko.observable(false);
        this.responseOptions = ko.observableArray([]);
        this.addResponse = function () {
            if (!self.newResponse() || self.newResponse() === "") {
                return;
            }
            if (self.responseOptions().indexOf(self.newResponse().trim()) > -1) {
                //the same response option exists already
                self.canValidationMsg(true);
                self.validationMsg("The same option already exists in this alert.");
                return;
            }
            if (self.newResponse() && self.newResponse().length > 64) {
                self.canValidationMsg(true);
                self.validationMsg("Response Option must be less than 64 characters.");
                return;
            }
            self.canValidationMsg(false);
            self.responseOptions.push(self.newResponse().trim());
            self.newResponse("");
        };
        this.removeResponse = function (response) {
            /*if (!self.responseOptions() || self.responseOptions().length === 1) {
                self.canValidationMsg(true);
                self.validationMsg("It must have at least one response option.");
                return;
            }*/
            self.canValidationMsg(false);
            self.responseOptions.remove(response);
        };
        this.eventTitle = ko.observable();
        this.eventTime = ko.observable();
        this.eventSourceName = ko.observable();
        this.eventSourceType = ko.observable();
        this.eventType = ko.observable();
        this.eventSeverity = ko.observable();
        this.groups = ko.observable();
        this.groupCount = ko.observable(0);
        this.dlRecipients = ko.observable();
        this.orgRecipients = ko.observable();
        this.attachmentId = ko.observable();
        this.validationMsg = ko.observable();
        this.publish = function () {
            var ts = (new Date()).getTime();
            var allResponseOptions = [];
            if (this.newResponse() && this.responseOptions().indexOf(this.newResponse().trim()) === -1 && this.newResponse().length <= 64) {
                allResponseOptions.push(this.newResponse());
                allResponseOptions = this.responseOptions().concat(allResponseOptions);
            } else {
                allResponseOptions = this.responseOptions();
            }
            //the url has to include a protocol, otherwise browser will add http://domain as prefix to the url
            if (this.url() && this.url().toLowerCase().indexOf("http") !== 0) {
                this.url("http://" + this.url());
            }
            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: '/athoc-cdn/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000 }).showLoader();
            $.ajax({
                type: "POST",
                url: "/client/map/PublishAlerts?ts=" + ts,
                dataType: "json",
                data: {
                    alertHeader: encodeURI(this.title()),
                    alertContent: encodeURI(this.msg()),
                    responseOptions: encodeURI(JSON.stringify(allResponseOptions)), //"%5B'Acknowledge','helloworld'%5D",
                    teamRecipients: "",
                    dlRecipients: encodeURI(this.dlRecipients()),
                    orgRecipients: encodeURI(this.orgRecipients()),
                    attachmentIds: encodeURI(this.attachmentId()),
                    attachmentTypes: "%5B2%5D", //for events, the type value is [2]
                    alertUrl: this.url() ? encodeURI(this.url()) : ""
                },

                success: $.proxy(function (e) {
                    $.AjaxLoader.hideLoader();
                    if (e.AlertId !== "-1") {
                        eventManagerUtil.showMsgModal("Alert published successfully. " + "<a href='/client/alertmanager/summary/" + e.AlertId + "' target='_blank'>See report.</a>");
                    } else {
                        eventManagerUtil.showMsgModal("An error occurred while publishing the event.");
                    }
                }, this),

                error: function (xhr, textStatus, error) {
                    $.AjaxLoader.hideLoader();
                    AjaxUtility().ajaxPostOptions.error(xhr, textStatus, error);
                    eventManagerUtil.showMsgModal("An error occurred while publishing the event.");
                },

                traditional: true
            });
            $("#sendAlertModal").modal('hide');
        };
        this.groupSelectionHidden = ko.observable(true);
        this.canSend = ko.computed(function () {
            var titleValid = (self.title().trim().length >= 3 && self.title().trim().length <= 100) ? true : false;
            var recepientValid = (self.dlRecipients() && self.dlRecipients().length > 0) || (self.orgRecipients() && self.orgRecipients().length > 0) ? true : false;
            var msgValid = self.msg().trim().length <= 2000 ? true : false;
            return titleValid && recepientValid && msgValid && self.groupSelectionHidden();
        });
        
        this.openGroupMp = function () {
            self.groupSelectionHidden(false);
            $("#groupSelectModal").modal();
        };

        this.canCancel = ko.computed(function() {
            return self.groupSelectionHidden();
        });
        this.canSelectGroups = ko.observable(true);
    }

    return Model;
});