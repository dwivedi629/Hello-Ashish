﻿define([requireModuleNames.knockout], function (ko) {
   
    function Model(i18n) {
        var self = this;
        this.isCustomRange = ko.observable(false);
        var today = new Date();
        self.customDateFrom = ko.observable();
        self.customDateTo = ko.observable();
        self.exportLimit = ko.observable();
        self.customRangeRecordCount = ko.observable();
        self.last24hrsRecordCount = ko.observable();
        self.lastWeekRecordCount = ko.observable();
        self.lastMonthRecordCount = ko.observable();
        self.allRecordCount = ko.observable();
        self.currentNumberOfRecords = ko.observable();
        self.filterText = ko.observable();
        self.exportLimitMessage = ko.computed(function () {
            return i18n.Event_Export_limit_message.format(self.currentNumberOfRecords(), self.exportLimit());
        });
        
        self.showExportLimitMessage = ko.computed(function () {
            return self.currentNumberOfRecords() > self.exportLimit();
        });
        
    }

    return Model;
});