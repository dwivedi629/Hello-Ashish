﻿define([
	requireModuleNames.knockout,
    "widget/BaseWidget",
    "widget/createEvent/Model",
    "vendors/text!widget/createEvent/template.html",
    "ssa/eventManagerUtil",
], function (ko, BaseWidget, Model, template, eventManagerUtil) {
    //constructor
    var CreateEvent = function (refDomNode, categoryId) {
        BaseWidget.call(this, refDomNode, template, Model, []);

        this.model.categoryId(categoryId);

        var self = this;
        eventManagerUtil.getSeverityList(function (severities) {
            self.model.severities(severities);
            self.startup();
        });

        this.model.save = function (publish) {
            self.save(publish);
        };

        //this code should be in base widget, will refactor
        this.model.saveComplete.extend({ notify: "always" });

        //when anything changes
        /*this.model.saveComplete.subscribe($.proxy(function () {
            this.saveComplete(this.model.saveComplete());
        }, this));*/
    };

    $.extend(CreateEvent.prototype, {
        showNewEventDlg: function () {
            var self = this;
            var model = this.model;
            model.clearValidation();
            model.eventBody('');
            model.eventTitle('');
            model.eventUrl('');
            model.isNew(true);

            //$('#createActivityLogOk').unbind("click").click($.proxy(function () { self.onSubmit(); }));
            //$('#createActivityLogOk').text("Create");
            //$('#createActivityLogTitle').text("New Log Entry");
            model.clearValidation();
            $('#dlgCreateActivityLog').modal();

            // set severity value default informational
            $("#dlgCreateActivityLog").find("#severityList").val(4).change();
            setTimeout(function () {
                $("#dlgCreateActivityLog").find("[name=eventTitle]").focus();
            }, 500);
        },

        showEditEventDlg: function (eventModel) {
            var self = this;
            var model = this.model;            
            model.isNew(false);
            model.id(eventModel.id());
            model.severityId(eventModel.severityId());
            model.eventBody(eventModel.body());
            model.eventTitle(eventModel.title());
            model.eventUrl(eventModel.alertUrl());            

            model.clearValidation();
            $('#dlgCreateActivityLog').modal();

            // set severity value default informational            
            $("#dlgCreateActivityLog").find("#severityList").val(model.severityId()).change();
            setTimeout(function () {
                $("#dlgCreateActivityLog").find("[name=eventTitle]").focus();
            }, 500);
        },

        save: function (publish) {
            var self = this;
            var model = this.model;
            //get event
            var event = {};
            if (!model.isNew()) {
                event.Id = model.id;
            }
//            event.Body = $.htmlEncode(model.eventBody());
            event.Body = model.eventBody();
//            event.Title = $.htmlEncode(model.eventTitle());
            event.Title = model.eventTitle();

            // AlertUrl is a bad name. it is just Url attribute
            event.AlertUrl = model.eventUrl();
            event.EventCategoryType = model.categoryId();
            event.Priority = model.severityId();

            $('#dlgCreateActivityLog').modal("hide");
            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: '/athoc-cdn/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000 }).showLoader();
            var ts = (new Date()).getTime();
            var xhr = $.ajax({
                url: "/athoc-iws/eventManager/" + (model.isNew() ? "CreateEvent" : "UpdateEvent"),
                dataType: "json",
                type: "POST",
                data: { eventModel: event, ts: ts },
                success: $.proxy(function (response) {
                    $.AjaxLoader.hideLoader();
                    var timeOut = eventManagerUtil.sessionTimeOut(response);
                    if (timeOut) {
                        return;
                    }

                    if (!response || !response.Success) {
                        return;
                    }
                    var data = response.Data;
                    eventManagerUtil.processEventData(data);
                    self.saveComplete(data, publish);
                }, this),
                error: $.proxy(function (response) {
                    $.AjaxLoader.hideLoader();
                    var timeOut = eventManagerUtil.sessionTimeOut(response);
                    if (timeOut) {
                        return;
                    }
                    eventManagerUtil.showMsgModal(athoc.iws.event.resources.organization.Organization_Generix_Error_message);
                }, this)
            });
            return xhr;
        },

        getValidation: function () {
            var validationMapping = {
                Title: {
                    create: function (options) {
                        return ko.observable(options.data).extend({
                            required: {
                                params: true,
                                message: athoc.iws.event.resources.organization.Organization_Invite_Org_Dlg_Name_Validation
                            },
                        });
                    }
                },
            };

            return validationMapping;
        },

        saveComplete: function (event, publish) { },
    });
    return CreateEvent;
});