define([requireModuleNames.knockout, "vendors/text!eventManager/getResource"], function (ko, i18n) {
    var i18n = $.parseJSON(i18n).Resources;
    if (!i18n) {
        //internationalization resource is not loaded
        return;
    }

    ko.bindingHandlers.selectPicker = {
        init: function (element, valueAccessor, allBindingsAccessor) {
            if ($(element).is('select')) {
                if (ko.isObservable(valueAccessor())) {
                    if ($(element).prop('multiple') && $.isArray(ko.utils.unwrapObservable(valueAccessor()))) {
                        // in the case of a multiple select where the valueAccessor() is an observableArray, call the default Knockout selectedOptions binding
                        ko.bindingHandlers.selectedOptions.init(element, valueAccessor, allBindingsAccessor);
                    } else {
                        // regular select and observable so call the default value binding
                        ko.bindingHandlers.value.init(element, valueAccessor, allBindingsAccessor);
                    }
                }
                var selectPickerOptions = allBindingsAccessor().selectPickerOptions;
                //var liveSearch = false;
                //var includeSelectAll = false;
                //var selectAllText = 'Select all';
                //var selectAllValue = "-1";
                var _options = {};

                if (typeof selectPickerOptions !== 'undefined' && selectPickerOptions !== null) {

                    if (typeof (selectPickerOptions.liveSearch) !== 'undefined') {
                        _options.liveSearch = selectPickerOptions.liveSearch;
                    }
                    else {
                        if (typeof (selectPickerOptions.optionsArray) === 'function') {
                            _options.liveSearch = selectPickerOptions.optionsArray().length > 7;
                        }
                        else {
                            _options.liveSearch = valueAccessor().length > 7;
                        }
                    }
                    if (typeof (selectPickerOptions.selectAll) !== 'undefined') {
                        _options.includeSelectAllOption = selectPickerOptions.selectAll;
                    }

                    if (typeof (selectPickerOptions.selectAllText) !== 'undefined') {
                        _options.selectAllText = selectPickerOptions.selectAllText;
                    }
                    if (typeof (selectPickerOptions.selectAllValue) !== 'undefined') {
                        _options.selectAllValue = selectPickerOptions.selectAllValue;
                    }
                    if (typeof (selectPickerOptions.placeHolderText) !== 'undefined') {
                        _options.placeHolderText = selectPickerOptions.placeHolderText;
                    }
                    if (typeof (selectPickerOptions.container) !== 'undefined') {
                        _options.container = selectPickerOptions.container;
                    }
                    if (typeof (selectPickerOptions.noListItemMessage) !== 'undefined' && selectPickerOptions.noListItemMessage.trim() != '') {
                        _options.noListItemMessage = selectPickerOptions.noListItemMessage;
                    }
                    if (typeof (selectPickerOptions.customStyle) !== 'undefined') {
                        _options.customStyle = selectPickerOptions.customStyle;
                    }

                    if (typeof (selectPickerOptions.noneSelectedText) !== 'undefined') {
                        _options.noneSelectedText = selectPickerOptions.noneSelectedText;
                    }

                    if (typeof (selectPickerOptions.countSelectedText) !== 'undefined') {
                        _options.countSelectedText = selectPickerOptions.countSelectedText;
                    }
                }
                $(element).addClass('selectpicker').selectpicker(_options);

            }
        },
        update: function (element, valueAccessor, allBindingsAccessor) {
            if ($(element).is('select')) {
                var selectPickerOptions = allBindingsAccessor().selectPickerOptions;
                if (typeof selectPickerOptions !== 'undefined' && selectPickerOptions !== null && typeof (selectPickerOptions.optionsArray) === 'function') {
                    var options = selectPickerOptions.optionsArray,
                        optionsText = selectPickerOptions.optionsText,
                        optionsValue = selectPickerOptions.optionsValue,
                        optionsCaption = selectPickerOptions.optionsCaption,
                        isDisabled = selectPickerOptions.disabledCondition || false,
                        resetOnDisabled = selectPickerOptions.resetOnDisabled || false;
                    if (ko.utils.unwrapObservable(options).length > 0) {
                        // call the default Knockout options binding
                        ko.bindingHandlers.options.update(element, options, allBindingsAccessor);
                    }
                    if (isDisabled && resetOnDisabled) {
                        // the dropdown is disabled and we need to reset it to its first option
                        $(element).selectpicker('val', $(element).children('option:first').val());
                    }
                    $(element).prop('disabled', isDisabled);
                }
                else {
                    ko.bindingHandlers.options.update(element, valueAccessor, allBindingsAccessor);
                }
                if (ko.isObservable(valueAccessor())) {
                    if ($(element).prop('multiple') && $.isArray(ko.utils.unwrapObservable(valueAccessor()))) {
                        // in the case of a multiple select where the valueAccessor() is an observableArray, call the default Knockout selectedOptions binding
                        ko.bindingHandlers.selectedOptions.update(element, valueAccessor);
                    } else {
                        // call the default Knockout value binding
                        ko.bindingHandlers.value.update(element, valueAccessor);
                    }
                }

                $(element).selectpicker('refresh');
            }
        }
    };
var BaseWidget = function(refDomNode, template, Model, csses){

  if (csses.length > 0) {
    $.each(csses, function(idx, css){
	  $("head").append($("<style>"+css+"</style>"));
	});
  }

    if (template) {
        this.templateDom = $.parseHTML(template);
    }
    if ($.type(refDomNode) === "string") {
        refDomNode = $("#" + refDomNode);
    }
    this.refDomNode = refDomNode;
    this.refDomNode.append(this.templateDom);
    if (Model) {
        this.model = new Model(i18n);
        this.model.i18n = i18n;
    }


    this.startup = function() {

        ko.applyBindings(this.model, this.refDomNode[0]);
        //kocustom.applyBinding(this.model, this.refDomnode[0]);
        /*
      $.each(this.events, $.proxy(function(idx, event){
        $(event.id, this.refDomNode)[event.name]($.proxy(event.handler, this));
      }, this));
      if (this.afterStartup) {
        this.afterStartup();
      }*/
    };
    this.on = function(evtName, callback) {
        this[evtName] = callback;
    };
    this.hide = function() {
        this.refDomNode.hide();
    };
    this.show = function() {
        this.refDomNode.show();
    };
    this.destroy = function() {
        this.refDomNode.empty();
    };
    //make the expandable work, specific for bootstrap expandable
    $('.bucket-toggle h2', this.refDomNode).click(function () {
        $(this).parent().find('.row').slideToggle(500);
        $(this).parent().find('.expand-arrow-open').toggle();
        $(this).parent().find('.expand-arrow-closed').toggle();
    });
};
return BaseWidget;
});