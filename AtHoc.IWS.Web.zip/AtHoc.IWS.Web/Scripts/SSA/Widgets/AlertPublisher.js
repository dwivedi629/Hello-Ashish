﻿define([
	requireModuleNames.knockout,
    "widget/BaseWidget",
    "widget/MillerPanel",
    "ssa/eventManagerUtil",
    "widget/alertPublisher/AlertPublisherModel",
    "vendors/text!widget/alertPublisher/alertPublisherTemplate.html"
], function (ko, BaseWidget, MillerPanel, util, Model, template) {

    //constructor
    var AlertPublisher = function (refDomNode) {
        BaseWidget.call(this, refDomNode, template, Model, []);
        //this.getLists();
    };

    $.extend(AlertPublisher.prototype, {
        getLists: function () {
            //get dl and org list
            var ts = (new Date()).getTime();
            $.when($.ajax("/athoc-iws/eventmanager/getDistributionLists?ts=" + ts), $.ajax("/athoc-iws/eventmanager/getOrganizationLists?ts=" + ts)).done(
                $.proxy(function (dlResponse, orgResponse) {
                    var dls = dlResponse[0].DistributionLists,
                        orgs = orgResponse[0].organizationList; //organizationList start with lower case, which is on purpose and correct
                    //process data to work with kendo treeview
                    var groupTreeViewData = util.processGroupTreeViewData(dls, orgs);
                    if (!groupTreeViewData || groupTreeViewData.length === 0) {
                        //hide the "click to select groups" link and show a msg
                        this.model.canSelectGroups(false);
                        return;
                    }
                    this.model.canSelectGroups(true);
                    //create miller panel
                    if ($("#groupSelectModal").length === 0) {
                        //first time when creating the alertpublisher widget
                        $('<div id="groupSelectModal" class="modal hide fade" style="width:350px;margin-left:-300px;height:328px;" tabindex="-1" role="dialog" aria-hidden="true"></div>').appendTo("body");
                        this.groupSelectMp = new MillerPanel("groupSelectModal", {
                            data: groupTreeViewData,
                            title: "Select Recipients"
                        });
                        this.groupSelectMp.startup();
                        //the modal over another modal case would cause two modals has the same left position.
                        var groupSelectModal = $("#groupSelectModal");
                        //var left = groupSelectModal.position().left;
                        groupSelectModal.css("left", "60%");
                        this.groupSelectMp.on("change", $.proxy(function (selections) {
                            var dlRecipients = "{'",
                                orgRecipients = "{'";
                            $.each(selections, function (idx, selection) {
                                if (selection.type === "dl") {
                                    dlRecipients += selection.id + "' : '" + selection.id + "','";
                                } else if (selection.type === "org") {
                                    orgRecipients += selection.id + "' : '" + selection.id + "','";
                                }
                            });
                            //remove the last ",{'"
                            dlRecipients = dlRecipients.substring(0, dlRecipients.length - 2);
                            if (dlRecipients.length > 0) {
                                //the dl is not empty
                                dlRecipients += "}";
                            }
                            this.model.dlRecipients(dlRecipients);
                            orgRecipients = orgRecipients.substring(0, orgRecipients.length - 2);
                            if (orgRecipients.length > 0) {
                                orgRecipients += "}";
                            }
                            this.model.orgRecipients(orgRecipients);
                            this.model.groupCount(selections.length);
                        }, this));
                        this.groupSelectMp.on("close", $.proxy(function () {
                            this.model.groupSelectionHidden(true);
                        }, this));
                    } else {
                        //update the miller panel
                        this.groupSelectMp.update(groupTreeViewData);
                    }
                }, this)).fail(function (xhr, textStatus, error) {
                    AjaxUtility().ajaxPostOptions.error(xhr, textStatus, error);
            });
        },
        updateContent: function (data) {
            this.getLists();
            var model = this.model;
            model.title(data.title());
            if (data.description() && data.description().length > 0) {
                model.msg("Event received from " + data.sourceName() + " at " + data.createdOn() + "\n\n" + data.description());
            } else {
                model.msg("");
            }
            model.url(data.alertUrl());
            model.newResponse("");
            model.canValidationMsg(false);
            model.eventTitle(data.title());
            model.eventTime(data.createdOn());
            model.eventType(data.type());
            model.eventSourceName(data.sourceName());
            model.eventSourceType(data.sourceType().toLowerCase());
            model.eventSeverity(data.severity().toLowerCase());
            model.attachmentId("[" + data.id() + "]");
            model.responseOptions([]);
            model.dlRecipients(null);
            model.orgRecipients(null);
            if (this.groupSelectMp) {
                //the very first time when calling updateContent, the groupSlection miller panel is not there yet.
                this.groupSelectMp.uncheckAll();
            }
        },
        publish: function () { },
        //events
        change: function () { }
    });
    return AlertPublisher;
});