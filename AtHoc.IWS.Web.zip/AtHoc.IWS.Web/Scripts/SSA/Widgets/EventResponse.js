﻿define([
	requireModuleNames.knockout,
    "widget/BaseWidget",
    "widget/eventResponse/EventResponseModel",
    "vendors/text!widget/eventResponse/eventResponseTemplate.html",
    "ssa/eventManagerUtil"
], function (ko, BaseWidget, Model, template, eventManagerUtil) {
    //constructor
    var EventResponse = function (refDomNode) {
        BaseWidget.call(this, refDomNode, template, Model, []);
        //this code should be in base widget, will refactor
        this.model.replyComplete.extend({ notify: "always" });
        //when anything changes
        this.model.replyComplete.subscribe($.proxy(function () {
            this.replyComplete(this.model.replyComplete());
        }, this));
    };

    $.extend(EventResponse.prototype, {
        update: function (params) {
            var model = this.model;
            model.eventId(params.eventId);
            var url = "/athoc-iws/eventmanager/GetResponseOptions?eventId=" + params.eventId;
            $.ajax({
                type: "GET",
                url: url,
                success: function (response) {
                  
                    if (!response || !response.Success) {
                        //modal shows msg as "no response options"
                        return;
                    }
                    if (!response.ResponseOptions || response.ResponseOptions.length === 0) {
                        response.ResponseOptions = [
                        {
                            OptionId: -1,
                            ResponseText: "Acknowledge"
                        }];
                    }
                    var responseOptions = response.ResponseOptions;
                    model.responseOptions(responseOptions);
                    model.responseId(responseOptions[0].OptionId);
                    model.deliveryContext(response.DeliveryContext);
                    $("#responseModal", this.refDomNode).modal();
                },
                error: function (xhr, textStatus, error) {
                    $("#responseModal", this.refDomNode).hide();
                    AjaxUtility().ajaxPostOptions.error(xhr, textStatus, error);
                }
            });
        },
        replyStart: function () {},
        replyComplete: function () {}
    });
    return EventResponse;
});