﻿define([requireModuleNames.knockout,
       "widget/BaseWidget",
       "widget/exportEvents/Model",
       "vendors/text!widget/exportEvents/template.html"
    ],
    function (ko, BaseWidget,Model, template) {
        var ExportEvents = function (refDomNode) {
            BaseWidget.call(this, refDomNode, template, Model, []);
        var self = this;
        var today = new Date(new Date().toISOString());
        var df = $("#customDateFrom").datetimepicker();
        var dt = $("#customDateTo").datetimepicker();
        dt.data("datetimepicker").setEndDate(today);
     
        df.on("changeDate", function (e) {
            if (e.date) {
                self.model.customDateFrom($("#customDateFrom").data().date);
                dt.data("datetimepicker").setStartDate(e.date);
              
            } else {
                self.model.customDateFrom(null);
            }
            self.getCustomRangeEventsCount();
        });
        dt.on("changeDate", function (e) {
            if (e.date) {
                self.model.customDateTo($("#customDateTo").data().date);
                df.data("datetimepicker").setEndDate(e.date);
            
            } else {
                self.model.customDateTo(null);
            }
            self.getCustomRangeEventsCount();
        });
        self.filterArray = ko.observableArray([]);

        self.model.customDateFrom.subscribe(function(newValue) {
            if (new Date(newValue) > new Date(self.model.customDateTo()))
                self.model.customDateTo(moment(newValue).format("MM/DD/YYYY"));
        });
        self.model.customDateTo.subscribe(function(newValue) {
            if (new Date(newValue) < new Date(self.model.customDateFrom()))
                self.model.customDateFrom(moment(newValue).format("MM/DD/YYYY"));
        });

        self.downloadEvents = function (actionUrl) {//function to download the PDF/CSV.
            var query = search.searchFilter();
           
            if (self.model.customDateFrom() !== '')
                query = query + "&dateRangeFrom=" + new Date(self.model.customDateFrom()).toISOString();
            if (self.model.customDateTo() !== '')
                query = query + "&dateRangeTo=" + new Date(self.model.customDateTo()).toISOString();
            var url = actionUrl+ query + "&Page=1" + "&PageSize=" + self.model.exportLimit();
            $.fileDownload(url, {
                httpMethod: "POST",
                contentType: "application/json",
                encodeHTMLEntities: true,
                successCallback: function () {
                    $.AjaxLoader.hideLoader();
                },
                failureCallback: function () {
                    $.AjaxLoader.hideLoader();
                }
            });
        };

        self.getEventsCountForAllRange = function () {
           var  query = search.searchFilter();
           var url = "/athoc-iws/eventmanager/GetEventCountForAllTimeRange?" + query;
            $.ajax({
                type: "POST",
                url: url,
                success: function (response) {
                    if (!response || !response.Success) {
                        self.model.currentNumberOfRecords(response.last24);
                        self.model.last24hrsRecordCount(athoc.iws.event.resources.Export.Event_Export_Current_Number_Of_Records_Message.format(response.last24));
                        self.model.lastWeekRecordCount(athoc.iws.event.resources.Export.Event_Export_Current_Number_Of_Records_Message.format(response.lastweek));
                        self.model.lastMonthRecordCount(athoc.iws.event.resources.Export.Event_Export_Current_Number_Of_Records_Message.format(response.lastmonth));
                        self.model.allRecordCount(athoc.iws.event.resources.Export.Event_Export_Current_Number_Of_Records_Message.format(response.all));
                    }
                },
                error: function (xhr, textStatus, error) {
                    AjaxUtility().ajaxPostOptions.error(xhr, textStatus, error);
                }
               
            });
        };
        self.getCustomRangeEventsCount= function () {
            var query = search.searchFilter();
            var currentTime = new Date();
            if (query.indexOf('&eventCategoryId=') == -1)
                query= query.replace(query.substring(query.indexOf('&dateRangeFrom='), query.length), "");
            else
                query= query.replace(query.substring(query.indexOf('&dateRangeFrom='), query.indexOf('&eventCategoryId=')), "");
            if (self.model.customDateFrom() !== '') {
                var fromDate = new Date(self.model.customDateFrom()).toISOString();
                query = query + "&dateRangeFrom=" + fromDate;
            }
            if (self.model.customDateTo() !== '') {
                var toDate = new Date(self.model.customDateTo()).toISOString();
                query = query + "&dateRangeTo=" + toDate;
            }
            var url = "/athoc-iws/eventmanager/GetEventCount?" + query;
            $.ajax({
                type: "POST",
                url: url,
                success: function (response) {
                    if (!response || !response.Success) {
                        self.model.customRangeRecordCount(athoc.iws.event.resources.Export.Event_Export_Current_Number_Of_Records_Message.format(response));
                        self.model.currentNumberOfRecords(response);
                    }
                },
                error: function (xhr, textStatus, error) {
                    AjaxUtility().ajaxPostOptions.error(xhr, textStatus, error);
                }

            });
        };

        self.exportToPdf = function () { // On Click for Export PDF Button
            if (self.model.customDateFrom() !== "" || self.model.customDateTo() !== "") {
                var fieldValue = new Array();
                if (self.model.customDateFrom() !== "" && self.model.customDateTo() !== "") {
                    if (self.model.isCustomRange()) {
                        fieldValue.push(self.model.customDateFrom());
                        fieldValue.push(self.model.customDateTo());
                    } else {
                        fieldValue.push(new Date(self.model.customDateFrom()).toISOString());
                        fieldValue.push(new Date(self.model.customDateTo()).toISOString());
                    }
                    self.filterArray.push({
                        field: "dateRange",
                        fieldText: athoc.iws.event.resources.Event.Event_Export_Filter_Text_Time,
                        fieldValue: fieldValue
                    });
                } else if (self.model.customDateFrom() !== "") {
                    fieldValue.push(new Date(self.model.customDateFrom()).toISOString());
                    self.filterArray.push({
                        field: "dateRange",
                        fieldText: athoc.iws.event.resources.Event.Event_Sent_after_Text,
                        fieldValue: fieldValue
                    });
                }
               else if (self.model.customDateTo() !== "") {
                   fieldValue.push(new Date(self.model.customDateTo()).toISOString());
                    self.filterArray.push({
                        field: "dateRange",
                        fieldText: athoc.iws.event.resources.Event.Event_Sent_before_Text,
                        fieldValue: fieldValue
                    });
                }
            }
            var url = "/athoc-iws/eventmanager/ExportToPdf?" + "&filterStructure=" + JSON.stringify(self.filterArray());
            self.downloadEvents(url);
        };

        self.exportToCsv = function () { //on Click for Export CSV button
            var url = "/athoc-iws/eventmanager/ExportToCsv?";
            self.downloadEvents(url);
        };
        self.setDateRange = function (option) {
            today = new Date(new Date().toISOString());
            switch (option) {
            case 'last24':
                self.model.customDateFrom(new Date(today).setHours(today.getHours()-24));
                self.model.customDateTo(today);
                if (self.model.last24hrsRecordCount())
                self.model.currentNumberOfRecords(self.model.last24hrsRecordCount().substring(1, self.model.last24hrsRecordCount().length-1));
                break;
            case 'lastweek':
                self.model.customDateFrom(new Date(today).setDate(today.getDate() - 7));
                self.model.customDateTo(today);
                self.model.currentNumberOfRecords(self.model.lastWeekRecordCount().substring(1, self.model.lastWeekRecordCount().length - 1));

                break;
            case 'lastmonth':
                self.model.customDateFrom(new Date(today).setMonth(today.getMonth() - 1));
                self.model.customDateTo(today);
                self.model.currentNumberOfRecords(self.model.lastMonthRecordCount().substring(1, self.model.lastMonthRecordCount().length - 1));

                break;
            case 'all':
                self.model.customDateFrom("");
                self.model.customDateTo("");
                self.model.currentNumberOfRecords(self.model.allRecordCount().substring(1, self.model.allRecordCount().length - 1));

                break;
            case 'customrange':
                self.model.isCustomRange(true);
                self.model.customDateFrom(search.model.dateFrom() !== "" ? moment(search.model.dateFrom()).format("MM/DD/YYYY") : "");
                self.model.customDateTo(search.model.dateTo() !== "" ? moment(search.model.dateTo()).format("MM/DD/YYYY") : "");
                break;
            }

        };
        var setDefault = function() {
            if (search.model.dateTo() !== "" && search.model.dateFrom() !== "") {
                jQuery("#customrange").prop('checked', true); // default radio selected 
                self.setDateRange('customrange');
                self.getCustomRangeEventsCount();
                self.model.isCustomRange(true);

            } else {
                jQuery("#last24").prop('checked', true); // default radio selected 
                self.setDateRange('last24');
                self.model.isCustomRange(false);
            }

        }
        self.generateFilterText= function() {
            var filterText = "";
            var orText = (athoc.iws.event.resources.Export.Event_Export_Or_Text).italics();
            for (var i = 0; i < self.filterArray().length; i++) {
                filterText = filterText + self.filterArray()[i].fieldText + " ";
                for (var j = 0; j < self.filterArray()[i].fieldValue.length; j++) {
                    if (j === self.filterArray()[i].fieldValue.length-1) {
                        filterText = filterText + self.filterArray()[i].fieldValue[j].bold()+", ";
                    }
                    else
                        filterText = filterText + self.filterArray()[i].fieldValue[j].bold() + " " + orText + " ";
                }
            }
            self.model.filterText(filterText.slice(0, -2));
        }
        self.generateFilterStructure = function()
        {
            var fieldValue = Array();
            self.filterArray.removeAll();
            if (search.model.quickSearchPill()) {
                fieldValue = [];
                fieldValue.push(search.model.quickSearchPillText() );
                self.filterArray.push({ field: "quickSearch",fieldText: athoc.iws.event.resources.Event.Event_Search_Keyword_Is, fieldValue: fieldValue });
                
            }
            if (search.model.sourceNamePill()) {
                fieldValue = [];
                fieldValue.push(search.model.sourceName());
                self.filterArray.push({ field: "sourceName", fieldText: athoc.iws.event.resources.Event.Event_CreatedBy, fieldValue: fieldValue });
            }
            if (search.model.severityPill() &&
                !(search.model.severityModerate() &&
                    search.model.severityExtreme() &&
                    search.model.severityMinor() &&
                    search.model.severityInformational() &&
                    search.model.severityUnknown())) {
                fieldValue = [];
                if (search.model.severityExtreme()) {
                    fieldValue.push(athoc.iws.event.resources.Event.Event_Severity_High);
                }
                if (search.model.severityModerate()) {
                    fieldValue.push(athoc.iws.event.resources.Event.Event_Severity_Moderate);
                }
                if (search.model.severityMinor()) {
                    fieldValue.push(athoc.iws.event.resources.Event.Event_Severity_Low);
                }
                if (search.model.severityInformational()) {
                    fieldValue.push(athoc.iws.event.resources.Event.Event_Severity_Informational);
                }
                if (search.model.severityUnknown()) {
                    fieldValue.push(athoc.iws.event.resources.Event.Event_Severity_Unknown);
                }
                self.filterArray.push({field: "severity", fieldText: athoc.iws.event.resources.Event.Event_Export_Filter_Text_Severity, fieldValue: fieldValue });
            }
            if (search.model.eventTypesText() !== undefined &&
                search.model.eventTypesText().length > 0 &&
                search.model.eventTypesText().length < 2) {
                fieldValue = [];
                fieldValue.push(search.model.eventTypesText()[0]);
                self.filterArray.push({field: "customRange", fieldText: athoc.iws.event.resources.Event.Event_Export_Category_Text, fieldValue: fieldValue });
            }

            
           

               // self.model.filterText(filterText.slice(0, -1));
           
                
        }
          self.showFilterDialog = function () {
              self.generateFilterStructure();
              self.generateFilterText();
              self.getEventsCountForAllRange();
            setDefault();
            $('#dlgSelectFilterRange').modal();
        };
          $('#SelectPdf').off('click').on('click', function (e) {
            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: '/athoc-cdn/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.event.resources.Event.Event_General_LoadingMessage }).showLoader();
            e.preventDefault();
            $('#dlgSelectFilterRange').modal('hide'); //Once reset is done close the modal window
            self.exportToPdf();

        });
        $('#SelectCsv').off('click').on('click', function (e) {
            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: '/athoc-cdn/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.event.resources.Event.Event_General_LoadingMessage }).showLoader();
            e.preventDefault();
            $('#dlgSelectFilterRange').modal('hide'); //Once reset is done close the modal window
            self.exportToCsv();

        });
        $("input[name='eventtimerange']").on('click', function (e) {//radio buttons on click
            self.setDateRange(e.currentTarget.value);
            self.model.isCustomRange(false);
            if (e.currentTarget.value === 'customrange') {
                self.model.isCustomRange(true);
                self.getCustomRangeEventsCount();
            }
        });

        //This is the work around to set the datetimepicker, which hides behind the event dialog. 
        $(".add-on", this.refDomNode).click(function () {
            $(".bootstrap-datetimepicker-widget", this.refDomNode).css("z-index", "10000");
        });
        };
        return ExportEvents;
    });