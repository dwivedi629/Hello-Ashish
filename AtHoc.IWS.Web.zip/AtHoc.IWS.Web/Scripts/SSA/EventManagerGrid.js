﻿define([
    "ssa/eventManagerUtil",
    "vendors/text!eventManager/getResource",
    "kendo/kendo.grid.min",
    "kendo/kendo.data.min"
],
    function (util, i18n) {
        var i18n = $.parseJSON(i18n).Resources;
        if (!i18n) {
            //internationalization resource is not loaded
            return;
        }
        var EventManagerGrid = function (holderId, viewType) {
            this.viewType = viewType;
            if (!this.viewType) {
                this.viewType = athoc.iws.event.EventViewTypes.Inbox; // set default
            }
            this.orderBy = "CreatedOn";
            this.orderAsc = false;

            var changeHandler = function (evt) {
                var data = this.grid.dataItem(this.grid.select());
                this.dataSelect(data);
                this.currentSelectedId = data.id;
            };
            var totalCount = 0;
            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: '/athoc-cdn/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: i18n.Event_General_LoadingMessage }).showLoader();
            this.grid = $("#" + holderId).kendoGrid({
                //dataSource: data,
                dataSource: {
                    transport: {
                        read: {
                            url: "/athoc-iws/eventmanager/getevents",
                            dataType: "json",
                            type: "GET"
                        }
                    },
                    error: function (e) {
                        AjaxUtility().athocKendoGridAjaxErrorHandler(e);
                        if (e.xhr.status === 500) {
                            if (e.xhr.responseText.indexOf("A potentially dangerous Request.QueryString value was detected from the client") > -1) {
                                util.showMsgModal("A potentially dangerous request value was detected from the client. It might include HTML markup or script.");
                            }
                        }
                    },
                    requestEnd: $.proxy(function (e) {
                        $(".k-grid-content").find("#noData").remove();
                        try {
                            $.AjaxLoader.hideLoader();
                        } catch (err) {
                            //the loader has not been shown yet.
                            //console.log(err);
                        }
                        if (!e.response) {
                            return;
                        }
                        this.fitHeight();
                        this.data = e.response.Data;
                        this.lastUpdatedTime = e.response.LastUpdatedTime;
                        this.totalCount = e.response.TotalCount;

                        if (!this.data || this.data.length === 0) {
                            $(".k-grid-content").append("<span id='noData' style='position:absolute;top:10px;left:200px;'>" + i18n.Event_Grid_NoRecords + "</span>");
                        }
                        $.each(this.data, function(idx, item) {
                            util.processEventData(item);
                        });
                        this.dataReady(this.data);
                    }, this),
                    schema: {
                        data: "Data", // records are returned in the "data" field of the response
                        total: "TotalCount" // total number of records is in the "total" field of the response
                    },
                    pageSize: 20,
                    serverPaging: true
                },
                dataBound: $.proxy(function() {
                    //highlight the last time selected row to give users the experience that this is not refreshed.
                    $.each(this.data, $.proxy(function (idx, data) {
                        if (data.id === this.currentSelectedId) {
                            //because header is a tr, so it has to add 1 to the index to get the previous selected row
                            $($("tr", $("#grid"))[idx+1]).addClass("k-state-selected");
                            return;
                        }
                        util.ellipsis($(".ellipsis.multiline"));
                    }, this));
                }, this),
                height: 500,
                width: 450,
                change: $.proxy(changeHandler, this),
                groupable: false,
                sortable: true,
                selectable: "single",
                pageable: {
                    pageSizes: true,
                    buttonCount: 3,
                    messages: {
                        display: i18n.Event_List_PageInfo,
                        empty: i18n.Event_List_PageInfo_NoRecords,
                        itemsPerPage: i18n.Event_ItemsPerPage,
                        first: i18n.Event_Pager_Message_Go_To_The_First_Page,
                        previous: i18n.Event_Pager_Message_Go_To_The_Previous_Page,
                        next: i18n.Event_Pager_Message_Go_To_The_Next_Page,
                        last: i18n.Event_Pager_Message_Go_To_The_Last_Page
                    }
                },
                columns: [
                    /*{
                        field: "IsChecked",
                        template: '<input type="checkbox" name="selected" checked="checked" />',
                        width: 25,
                        headerTemplate: kendo.format('<input type="checkbox" class="senario-select" id="alert-select-all" title="{0}" />', "Please select"),
                        sortable: false,
                        headerAttributes: {
                            style: "cursor: default"
                        }
                    },*/
                    {
                        field: "severityIcon",
                        title: " ",
                        sortable: false,
                        width: 50,
                        encoded: false,
                        headerAttributes: {
                            style: "cursor: default; border-width:0 0 0 0;"
                        },
                        hidden: (this.viewType == athoc.iws.event.EventViewTypes.LOG)
                    }, {
                        field: "titleAndName",
                        title: " ",
                        width: 180,
                        sortable: false,
                        encoded: false,
                        headerAttributes: {
                            style: "cursor: default; border-width:0 0 0 0;"
                        },
                        hidden: (this.viewType == athoc.iws.event.EventViewTypes.LOG)
                    }, {
                        field: "timeAndCategory",
                        width: 150,
                        sortable: false,
                        encoded: false,
                        format: "{0:HH:mm:ss MM-dd-yyyy}",
                        title: " ",
                        headerAttributes: {
                            style: "cursor: default; border-width:0 0 0 0;"
                        },
                        hidden: (this.viewType == athoc.iws.event.EventViewTypes.LOG)
                    },{
                        field: "mainArea",
                        //width: 500,
                        //width: 330,
                        sortable: false,
                        encoded: false,
                        format: "{0:HH:mm:ss MM-dd-yyyy}",
                        title: " ",
                        headerAttributes: {
                            style: "cursor: default; border-width:0 0 0 0;"
                        },
                        hidden: (this.viewType != athoc.iws.event.EventViewTypes.LOG)
                    }, {
                        field: "extraData",
                        sortable: false,
                        encoded: false,
                        title: " ",
                        headerAttributes: {
                            style: "cursor: default; border-width:0 0 0 0;"
                        },
                        width: 50,                        
                        hidden: (this.viewType == athoc.iws.event.EventViewTypes.LOG)
                    }
                ]
            }).data("kendoGrid");

            var eventTimeText = (this.viewType == athoc.iws.event.EventViewTypes.LOG) ? i18n.Event_Create_Time : i18n.Event_Time;
            // Removes default text near page size.
            $('.k-pager-sizes').remove();
            $('.k-pager-refresh').remove(); 
            $(".k-grid-header-wrap").css("width", 478);
            $(".k-grid-header").css("width", 478);
            //add content to the header
            $(".k-grid-header-wrap").append("<div title='" + i18n.Event_Sort_By + "' class='k-sort-wrap'>" + i18n.Event_Sort_By +
                ": <select id='sortSelect' class='selectpicker' style='width:110px;height:20px;'>" +
                "<option value='CreatedOn'>" + eventTimeText + "</option>" +
                "<option value='Priority'>" + i18n.Event_Severity + "</option>"+
                "<option value='EventCategoryName'>" + i18n.Event_Type + "</option>" +                
                "<option value='SourceName'>" + i18n.Event_Source + "</option>" +
                "<option value='MsgTitle'>" + i18n.Event_Title + "</option>" +
                "</select>" +
                "<a id='orderToggle' style='margin-left:20px;' class='k-link' href='#'>" +
                "<span id='orderText' title='" + i18n.Inbox_Sort_Order + "'>" + i18n.Event_Descending + "</span><span id='orderIcon' class='k-icon k-i-arrow-s'></span></a>" +
                "</div>");
            //apply bootstrap select
            //$(".selectpicker").selectpicker();
            $($("table[role='grid']")[0]).css("display", "none");

            $("#sortSelect").on("change", $.proxy(function (e) {
                var value = e.target.value;
                this.orderBy = value;
                this.orderByChange(this.orderBy);
                this.refresh();
            }, this));
            $("#orderToggle").on("click", $.proxy(function (e) {
                this.orderAsc = !this.orderAsc;
                $("#orderText").html(this.orderAsc ?  i18n.Event_Ascending  :   i18n.Event_Descending  );
                $("#orderIcon").removeClass(this.orderAsc ? "k-i-arrow-s" : "k-i-arrow-n").addClass(this.orderAsc ? "k-i-arrow-n" : "k-i-arrow-s");
                this.orderAscChange(this.orderAsc);
                this.refresh();
            }, this));

            $(window).resize($.proxy(function () {
               // alert("resize");
                this.fitHeight();
            }, this));
        };

        $.extend(EventManagerGrid.prototype, {
            //data: this.grid.dataSource.data()
            on: function (evtName, callback) {
                this[evtName] = callback;
            },
            offset: 0,
            fitHeight: function () {
                var footerHeight = $('#pageFooter').height();
                var extraSpace = this.offset;
                $("#grid").css("height", $(window).height() - (footerHeight + 243) - extraSpace);
                $(".k-grid-content").css("height", $(window).height() - (footerHeight + 319) - extraSpace);
            },
            refresh: function (keepCurrentPage) {
                if (keepCurrentPage) {
                    this.grid.dataSource.page(this.grid.dataSource.page());
                } else {
                    this.grid.dataSource.page(1);
                }
            },
            // events
            dataReady: function () { },
            dataSelect: function () { },
            orderByChange: function () { },
            orderAscChange: function () { }
        });

        return EventManagerGrid;
    });