﻿
define(["vendors/text!eventManager/getResource"], function (parami18n) {
    var i18n = $.parseJSON(parami18n).Resources;
   // var i18nevtcat = i18n._map(i18n,"Event_Category_Type_");
    var util = {
        
        getEventById: function (id, callback) {
            var ts = (new Date()).getTime();
            var xhr = $.ajax({
                url: "/athoc-iws/eventManager/getEventById",
                dataType: "json",
                type: "GET",
                data: { eventId: id, ts:  ts },
                success: $.proxy(function(response) {
                    var data = response.Data;
                    this.processEventData(data);
                    callback(data);
                }, this),
                error: function (xhr, textStatus, error) {
                     $.AjaxLoader.hideLoader();
                     AjaxUtility().ajaxPostOptions.error(xhr, textStatus, error);
                }
             });
            return xhr;
        },
        
        getSeverityList: function (callback) {
            var ts = (new Date()).getTime();
            var xhr = $.ajax({
                url: "/athoc-iws/eventManager/GetSeverityList",
                dataType: "json",
                type: "GET",
                data: {ts: ts },
                success: $.proxy(function (response) {                                     
                    callback(response);
                }, this)
            });
            return xhr;
        },

        

        processEventData: function (item) {
            
            
            
            var severities = [i18n.Event_Severity_High, i18n.Event_Severity, i18n.Event_Severity_Moderate, i18n.Event_Severity_Low, i18n.Event_Severity_Informational, i18n.Event_Severity_Unknown];
            var severitiesType = ["High", "Severe", "Moderate", "Low", "Informational", "Unknown"]; //For CSS applying
             var  title,
                type,
                sourceName,
                hasGeo,
                hasMedia;
            //var severities =this.getSeverityList();
            
            item.severityId = item.Priority;
            item.severity = severities[item.Priority]; //0 means high, 5 means unknown
            item.severityType = severitiesType[item.Priority];
            
            item.id = item.Id;
            title = item.Title.length > 20 ? item.Title.slice(0, 20) + "..." : item.Title;            
            if (!item.SourceName) {
                item.SourceName = "source name";
            }
            sourceName = item.SourceName.length > 20 ? item.SourceName.slice(0, 20) + "..." : item.SourceName;
            sourceName = $("<div id='escapeDiv'></div>").text(sourceName).html();

            //event type is event category name indeed
            var eventcategorytype = item.Type;
            type = item.EventCategoryName.length > 15 ? item.EventCategoryName.slice(0, 15) + "..." : item.EventCategoryName;
            type = $("<div id='escapeDiv'></div>").text(type).html();

            var smallIcon = '';
            var severityDiv;
            if (athoc.iws.event.currentViewType == athoc.iws.event.EventViewTypes.LOG) {
                // set teh small icon view in case it is Activity Log
                if (eventcategorytype === 'HubComm') {
                    severityDiv = "<div title='" + item.severity + "' class='icon16 log-grid-icon event-mgr-sprite-" + 'invite-info' + "'></div>";
                    smallIcon = "<div title='" + item.severity + "' class='icon16 event-mgr-sprite-" + 'invite-info' + "'  style=\"margin: 2px 5px 0 0;\"></div>";
                } else {
                    severityDiv = "<div title='" + item.severity + "' class='icon16 log-grid-icon event-mgr-sprite-" + item.severityType.toLowerCase() + "'></div>";
                    smallIcon = "<div title='" + item.severity + "' class='icon16 event-mgr-sprite-" + item.severityType.toLowerCase() + "'  style=\"margin: 2px 5px 0 0;\"></div>";
                }
            }            

            
            if (!title) {
               
                title = i18n.Event_Title_Alert;
            }            
            title = $("<div id='escapeDiv'></div>").text(title).html();//escape html and script tags            
            title = "<span title='" + item.Title.replace(/'/g, '&apos;').replace(/"/g, '&quot;') + "' class='" + (!item.Reviewed ? 'bold' : '') + "'>" + smallIcon + title + "</span>";


            var body = item.Body;
            if (!body) {
                body = "";
            }
            body = $("<div id='escapeDiv'></div>").text(body).html();//escape html and script tags

           
            item.titleAndName = title + "<span title='"+item.SourceName+"' class='block k-secondary'><div class='icon16 event-mgr-sprite-" + item.SourceType.toLowerCase() + "'></div>" + sourceName + "</span>";
            item.timeAndCategory = "<span class='k-secondary' title='" + item.CreatedOn + "'>" + item.CreatedOn + "<span title='" + item.EventCategoryName + "' class='block'>" + type + "</span></span>";
            if (item.Priority < 0) {
                //if for any reason, the priority value is -1, then it should be considered as unknown. Need to talk to DBA why -1 would be here.
                item.Priority = 5;
            }
            //if (athoc.iws.event.currentViewType == athoc.iws.event.EventViewTypes.LOG) {
            //    item.activityInfo = "<span class='k-secondary' title='" + item.CreatedOn + "'>" + item.CreatedOn + "</span><span title='" + item.SourceName + "' class='float-right k-secondary'><div class='icon16 event-mgr-sprite-" + item.SourceType.toLowerCase() + "'></div>" + sourceName + "</span><span class='bold block'>" + desc + "</span>";
            //}
            
            //item.typeIcon = "<img style='width:16px;height:16px;' src=" + item.TypeIcon + ">";
            item.typeIcon = item.TypeIcon;
            if (eventcategorytype === 'HubComm') {
                item.severityIcon = "<div title='" + item.severity + "' class='icon32 event-mgr-sprite-" + 'invite-info' + "'></div>";
            } else {
                item.severityIcon = "<div title='" + item.severity + "' class='icon32 event-mgr-sprite-" + item.severityType.toLowerCase() + "'></div>";
            }
            hasGeo = (item.Latitude && item.Longitude) || item.GeoJson;
            hasMedia = item.Medias.length > 0;
            item.extraData = "<div class='icon10-wrap'>";
            item.extraData += hasGeo ? "<div class='icon10 event-mgr-sprite-location'></div>" : "";
            item.extraData += hasMedia ? "<div class='icon10 event-mgr-sprite-attachment'></div>" : "";

            //if it's been responded, or expired, or came from other source than org
            //improved, logic has been handled on web tier
            //var canReply = (item.Responded || item.IsExpired || item.SourceType !== "ORGANIZATION") ? false : true;

            //86R3, it decides to remove the reply/replied indicator in order to avoid confusing users to think it's a clickable button
            /*
            var canReply = item.CanReply;
            var reply;
            if (canReply) {
                reply = "reply";
            }
            if (item.Responded) {
                reply = "replied";
            }
            
            item.extraData += "</div><div class='event-status event-"+reply+"'>"+reply+"</div>";
            */
            
            item.mainArea = "<div class=\"display-inline-block width450\">" +
                "<div class=\"log-grid-title ellipsis \">" +
                "<span class=\"bold\" title=\"" + item.Title.replace(/'/g, '&apos;').replace(/"/g, '&quot;') + "\">" + severityDiv + $.htmlEncode(item.Title) + "</span>" +
                "</div>" +                
                "<div class=\"log-grid-time ellipsis \"><span class=\"k-secondary\" title=\"" + item.CreatedOn + "\">" + item.CreatedOn + "</span></div>" +                
                "<div class=\"log-grid-sub ellipsis \"><span class=\"k-secondary\" title=\"" + type + "\"><div class='icon16 background-none'><img  src='"+item.TypeIcon+"'></div>"  + "</span></div>" +

                "</div>" +
                "<div class=\"width450\"><span style=\"max-height: 45px;\" class=\"block ellipsis multiline\">" + body + "</span></div>";
                                  
        },

        processCategoryDataToMpData: function (data, doFlatList, param18n) {

            //make it work with kendo UI treeview
            var uniqueId = 0,
                firstLevel = [],
                firstLevelItem;

            var firstNodeTitle = param18n.Inbox_Search_AdvancedSearch_AlertType;
            //Making sure fall back work for i18n
            if (!firstNodeTitle) {
                firstNodeTitle = "Alert Types";
            }
            var flatViewData = [];
            var treeViewData = [
                {
                    id: uniqueId--, text: firstNodeTitle, expanded: true, items: firstLevel
                }];
            $.each(data, function(idx, flItem) {
               
                if (flItem.CategoryType === "Mass") {
                    return;
                }
                firstLevelItem = {};
                firstLevelItem.id = uniqueId--;
                //Build the Resource Key name i.e. Event_Category_Type_Checkin
                var i18NEventCateProp = Object.getOwnPropertyDescriptor(param18n, 'Event_Category_Type_' + flItem.CategoryType);
                //set default as category type from db.
                var i18NEventCateValue = flItem.CategoryType;

                //Making sure fall back work for i18n
                if (i18NEventCateProp) {
                    i18NEventCateValue = i18NEventCateProp.value;
                }
                firstLevelItem.text = i18NEventCateValue;//flItem.CategoryType;
                firstLevelItem.items = [];
                var secondLevelItem;
                
                if (!doFlatList) {                                
                    firstLevel.push(firstLevelItem);
                }
                

                $.each(flItem.Items, function (idx, slItem) {
                    var i18NEventCatNameProp = Object.getOwnPropertyDescriptor(param18n, 'Event_Category_Type_' + slItem.Name);
                    var i18NEventCatNameValue = slItem.Name;
                    if (i18NEventCatNameProp) {
                        i18NEventCatNameValue = i18NEventCatNameProp.value;
                    }

                    secondLevelItem = {};
                    secondLevelItem.id = slItem.EventCategoryId;
                    secondLevelItem.text = i18NEventCatNameValue;// slItem.Name;
                    secondLevelItem.imageUrl = slItem.ImageId;
                    if (doFlatList) {
                        flatViewData.push(secondLevelItem);
                    } else {
                        firstLevelItem.items.push(secondLevelItem);
                    }                    
                });                 
            });
            return doFlatList ? flatViewData : treeViewData;
        },

        processGroupTreeViewData: function (dls, orgs) {
            if ((!dls || dls.length === 0) && (!orgs || orgs.length === 0)) {
                //no data;
                return;
            }
            var uniqueId = 0,
                
                firstLevel = [{ id: uniqueId--, text: i18n.Event_Groups, items: [] }, { id: uniqueId--, text: i18n.Event_Organizations, items: [] }];
            var treeViewData = [
                {
                    
                    id: uniqueId--, text: i18n.Event_Recipients, expanded: true, items: firstLevel
                }];

            var noDl = false, noOrg = false;
            if (!dls || dls.length === 0) {
                noDl = true;
            } else {
                $.each(dls, function(idx, item) {
                    firstLevel[0].items.push({ id: item.Id, text: item.Name, type: "dl" });
                });
                firstLevel[0].items.sort(function(a, b) {
                    var aName = a.text.toLowerCase();
                    var bName = b.text.toLowerCase();
                    return ((aName < bName) ? -1 : ((aName > bName) ? 1 : 0));
                });
            }
            //orgs is not an array
            //this is how orgs looks like: {2051674: "Pentagon Force Protection Agency", 2051685: "Naval Base San Diego", 2051690: "Santa Clara Fire Department", 2051694: "Federal Emergency Managment Agency", 2051695: "Athoc"}
            if (!orgs || $.isEmptyObject(orgs)) {
                noOrg = true;
            } else {
                var p;
                for (p in orgs) {
                    if (orgs.hasOwnProperty(p)) {
                        firstLevel[1].items.push({ id: p, text: orgs[p], type: "org" });
                    }
                }
                firstLevel[1].items.sort(function (a, b) {
                    var aName = a.text.toLowerCase();
                    var bName = b.text.toLowerCase();
                    return ((aName < bName) ? -1 : ((aName > bName) ? 1 : 0));
                });
            }

            if (noOrg) {
                firstLevel.pop();
            }
            if (noDl) {
                firstLevel.shift();
            }

            return treeViewData;
        },

        sessionTimeOut: function (response) {
            var timeOut = false;
            
            if (response.indexOf && (response.indexOf(i18n.Event_SessionTimeOut_Condition1) > -1 || response.indexOf(i18n.Event_SessionTimeOut_Condition2) > -1)) {
                //this.showMsgModal("The session timed out. Will redirect to login page.");
                //setTimeout(function () {
                    window.location.href = "/client/auth/login?iwslogin=false";
                //}, 5000);
                timeOut = true;
            }
            return timeOut;
        },

        showMsgModal: function(msg) {
            $("#errMsgModal").find(".modal-body").empty();
            $("#errMsgModal").find(".modal-body").append($("<span>" + msg + "</span>"));
            $("#errMsgModal").modal();
        },

        ellipsis: function(elements)
        {
            return elements.each(function()
            {
                var el = $(this);

                if(el.css("overflow") == "hidden")
                {
                    var text = el.html();
                    var maxHeight = parseFloat(el.css('max-height'));

                    var multiline = el.hasClass('multiline');
                    var t = $(this.cloneNode(true))
                        .hide()
                        .css('position', 'absolute')
                        .css('overflow', 'visible')
                        .width(multiline ? el.width() : 'auto')
                        .height(multiline ? 'auto' : el.height())
                        .css('max-height', '1000px');

                    el.after(t);

                    function height() {                        
                        return t.height() > maxHeight;
                        //return t.height() > el.height();
                    };
                    function width() { return t.width() > el.width(); };

                    var func = multiline ? height : width;

                    while (text.length > 0 && func())
                    {
                        text = text.substr(0, text.length - 1);
                        t.html(text + "...");
                    }

                    el.html(t.html());
                    t.remove();
                }
            });
        }
    };

    return util;
});