﻿define([], function () {
    function Model() {
        var self = this;

        self.Name = ko.observable();

        self.enabledYN = ko.observable();

        self.onInit = function () {
        };

        self.onChange = function () {
        };
    }
    return Model;

});