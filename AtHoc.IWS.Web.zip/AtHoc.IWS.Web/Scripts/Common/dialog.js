﻿define([
    "common/baseView",
    "common/dialog/Model",
    "dojo/text!common/dialog/template.html",
    "common/navigation"
], function (BaseView, Model, template, NavigationView) {
    //constructor
    /*
        * title - title of the dialog box
        * body - body content for the dialog box
        * footer - footer for the dialog box
        * (optional) navigationModel - this is an object for creation navigation buttons in the dialog box
        * options - JSON object which will contains extra properties to be set to the component
            schema - {
                        dialogCloseButtonText: "Close", // close button text i18n.PA_Dialog_Close_Button_Text
                        dlgClass: "width650" //css cass for the dialog box
                      }

        */
    var dialog = function (navigationModel, title, body, footer, options) {
        var self = this;        
        this.navigationModel = navigationModel;

        this.dialogCloseButtonText = (options != null && options.dialogCloseButtonText != undefined) ? options.dialogCloseButtonText : "";
        
        var refDomNode = $("<div>");
        $("body").append(refDomNode);        
        
        BaseView.call(this, refDomNode, template, Model, []);        
        
        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();            
        };

        this.setDialogSetting(options);

        this.update(title, body, footer);


        this.init = function() {
            var self = this;
            // add close button
            var addCloseBtn = false;
            if (this.navigationModel == null) {
                this.navigationModel = {};
                addCloseBtn = true;
            };
            if (this.navigationModel.sections == null) {
                this.navigationModel.sections =
                [{ dataPage: "", actions: []}];
                addCloseBtn = true;
            };
            if (addCloseBtn) {
                var actions = this.navigationModel.sections[0].actions;
                actions.push({ id: "close", text: this.dialogCloseButtonText, primary: false, click: function () { self.hideDialog(); } });
            }
            // create a node on the dom                 
            this.navigationView = new NavigationView(this.refDomNode.find(".modal-footer"), this.navigationModel);
            this.navigationView.startup();

            this.isInit = true;
        };

        this.center = function() {
            var dlgElement = this.refDomNode.find('.modal');
            //this.css("position", "absolute");
            //dlgElement.css("top", Math.max(0, (($(window).height() - dlgElement.outerHeight()) / 2) +
            //                                            $(window).scrollTop()) + "px");
            dlgElement.css("left", Math.max(0, (($(window).width() - dlgElement.outerWidth()) / 2) +
                                                        $(window).scrollLeft()) + "px");
            return this;            
        }
    };

    $.extend(dialog.prototype, {
        update: function (title, body, footer) {
            if (title) {
                this.model.title(title);
            }            
            if (body) {
                this.model.body(body);
            }
            if (footer) {
                this.model.footer(footer);
            }            
        },

        setDialogSetting: function (options) {            
            if (!options) {
                options = {};
            }
            this.model.computeDialogClass(options.dlgClass ? options.dlgClass : 'width650');                        
        },

        setTitle: function (title) {            
            this.model.title(title);
        },

        setHeader: function (header) {
            this.model.header(header);
        },

        showDialog: function () {
            if (!this.isInit) {
                this.init();
            }
            
            this.refDomNode.find('.modal').modal('show');
            this.refDomNode.find('.modal').show();
            this.center();
        },

        hideDialog: function () {
            this.refDomNode.find('.modal').modal('hide');
            this.refDomNode.find('.modal').hide();
            this.onClose();
        },

        getBodyNode: function () {
            var refDomNode = $("<div>");
            this.refDomNode.find(".modal-body").html('').append(refDomNode);
            return refDomNode;
        },

        getBodyNode2: function () {
            return this.refDomNode.find(".modal-body");
        },

        setBodyNode: function (node) {            
            this.refDomNode.find(".modal-body").html('').append(node);            
        },

        setTitleNode: function (node) {
            this.refDomNode.find(".modal-title").html('').append(node);
        },
        
        //events
        onClose: function(){}
    });

    return dialog;
});