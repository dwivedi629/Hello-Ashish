﻿define([
    "common/baseView",
    "dojo/text!common/multiSelectDropDown/template.html",
    "common/multiSelectDropDown/Model"

], function (BaseView, template, Model) {

    var multiSelectDropdown = function (refDomNode, options) {
        var self = this;
        self.Options = options;
       // self.DropDownModel = dropDownModel;
        BaseView.call(self, refDomNode, template, Model, []);

        //Setting Model Level Properties data
        self.model.optionText(self.Options.optionTextValue);
        self.model.optionValue(self.Options.optionIDValue);
        self.model.cssClass(self.Options.cssClass);
        self.model.TabIndex(self.Options.tabIndex);
        self.model.No_List_Item_String(self.Options.no_List_Item_String);
        self.model.none_Selected_Text(self.Options.noneString);
        self.model.count_Selected_Text(self.Options.countSelectedText);
        self.model.select_All_Text(self.Options.selectAllText);
        self.model.selectWidth(self.Options.width);
        self.model.controlId(self.Options.controlID);
        self.model.HasValidation(self.Options.hasValidation);

        self.baseStartup = self.startup;

        self.startup = function () {
           
            self.baseStartup.call(self);
            self.init();
            //self.bindDropdown(dropDownModel)
        };
    };
    $.extend(multiSelectDropdown.prototype, {
        init: function () {
            var self = this;
            self.model.controlId();
            self.refDomNode.find(".selectpicker").selectpicker();
            self.model.onChange = function () {
                self.onChange();
            };

        },
        bindDropdown: function (data) {
            var self = this;
            self.model.ItemDataSource([]);
            //self.model.ItemDataSource = data;
            self.model.ItemDataSource(data);
            //$.each(data, function (index, item) {
            //    self.model.ItemDataSource.push(item);
            //});
            
            self.refDomNode.find(".selectpicker").selectpicker('refresh');

        },
        getSelectedItem: function () {
            var self = this;
            return self.model.SelectedItems();
        },

        setSelectedItem: function (items) {
            var self = this;
            return self.model.SelectedItems(items);
        },
        onChange: function () { }
    });

    return multiSelectDropdown;
});