﻿define([    
    "common/dialog"
], function (Dialog) {
    //constructor
        /*
        * options - JSON object which will contains extra properties to be set to the component
            schema - {
                        confirmButtonText: "Confirm", //resources.PA_Confirm_Button_Text;
                        cancelButtonText: "Cancel", //resources.PA_Event_Cancel_Button
                        dialogCloseButtonText: "Close", // close button text
                        dlgClass: "width650" (optional) //css cass for the dialog box
                      }
        */
    var confirmationDialog = function (options) {
        var self = this;
        var confirmCommand = "";
        var cancelButtonText = "";

        if (options != null){
            if (typeof (options.confirmButtonText) != "undefined") {
                confirmCommand = options.confirmButtonText;
            }
            if (typeof (options.cancelButtonText) != "undefined") {
                cancelButtonText = options.cancelButtonText;
            }
        }

        // butttons
        var navigationModel = {
            sections: [
                {
                    dataPage: "",
                    actions: [
                        { id: "close", text: cancelButtonText, primary: false, click: function () { self.dialog.hideDialog(); } },
                        { id: "confirm", text: confirmCommand, primary: true, click: function () {
                            if (self.confirmAction) {
                                self.confirmAction();
                            }
                        } }
                    ]
                }
            ]
        };

        this.dialog = new Dialog(navigationModel, "", "", "", options);
        this.dialog.startup();
    };

    $.extend(confirmationDialog.prototype, {
        showConfirmationMessage: function (title, body, footer, confirmAction) {
            this.confirmAction = confirmAction;
            this.dialog.update(title, body, footer);
            this.dialog.showDialog();
        },

        hideConfirmationMessage: function () {
            this.dialog.hideDialog();
        }
    });

    return confirmationDialog;
});