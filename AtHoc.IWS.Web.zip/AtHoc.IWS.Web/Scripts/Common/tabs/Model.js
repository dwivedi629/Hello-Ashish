﻿define([], function () {
    function Model() {
        var self = this;
        //
        self.tabs = ko.observableArray([]);        
    }

    return Model;
});