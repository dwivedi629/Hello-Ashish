﻿define([
    "common/baseView",
    "common/tabs/Model",
    "dojo/text!common/tabs/template.html"
], function (BaseView, Model, template) {
    //constructor
    var tabs = function (refDomNode, tabsModel) {
        var self = this;
        BaseView.call(this, refDomNode, template, Model, []);
        this.selectedTab = null;
       
        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
            this.update(tabsModel);
        };  
    };

    $.extend(tabs.prototype, {
        init: function() {            
        },

        getTab: function (name) {
            return $(this.refDomNode.find("[name='" + name + "-tab']"));
        },

        update: function (model) {
            var self = this;
            self.model.tabs.removeAll();
            this.tabs = [];
            model.forEach(function(tab) {
                self.model.tabs.push(tab);
                self.tabs[tab.id] = tab;
            });

            // init tabs:
            this.tabControl = this.refDomNode.find(".tabs").kendoTabStrip({
                /*animation: {
                    close: {
                        duration: 200,
                        effects: "fadeOut"
                    }
                },*/
                animation: false,
                select: function (e) {
                    var previousSelectedTab = self.selectedTab;
                    var tabName = $(e.item).attr("name");
                    // convert is back to Id
                    tabName = tabName.slice(0, -4);
                    self.selectedTab = tabName;
                    if (previousSelectedTab !== self.selectedTab) {
                        self.onSelect(previousSelectedTab, self.selectedTab, {});
                    }                    
                },
                show: function (e) {
                    var previousSelectedTab = self.selectedTab;
                    self.onShow(previousSelectedTab, self.selectedTab, {});
                }
            });

            // move divs to right place
            this.refDomNode.find(".tab-content").each(function (index) {
                $(this).hide();
                $(this).appendTo(self.refDomNode.find(".tabs-content"));                
            });            
        },

        //by code, there is no event from the control
        select: function (tabName,filter) {
            var previousSelectedTab = this.selectedTab;
            this.selectedTab = tabName;
            this.tabControl.data("kendoTabStrip").activateTab($(this.refDomNode.find("[name='" + this.selectedTab + "-tab']")));
            
            // send event onChange            
            if (previousSelectedTab !== self.selectedTab) {
                this.onSelect(previousSelectedTab, this.selectedTab, {},filter);
            }
        },

        getSelectedTab: function() {
            return this.selectedTab;
        },

        getTabContentElement: function (name) {
            var contentDiv = $(this.refDomNode.find("[name='" + name + "-content']"));
            contentDiv.append("<div>");
            return contentDiv.find(":first-child");
        },

        //events
        onSelect: function (tab) { }        
    });

    return tabs;
});