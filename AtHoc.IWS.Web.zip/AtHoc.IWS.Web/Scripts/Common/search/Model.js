define([], function () {
    function Model() {
        var self = this;
        this.quickSearchText = ko.observable();
        this.canSearch = ko.observable(false);
        this.htmlPillContent = ko.observable('');
        this.searchBoxText = ko.observable(''); //$root.i18n.PA_Event_Manager_SearchBox
        this.searchTitle = ko.observable(''); //i18n.Event_Search
        this.clearAllText = ko.observable(''); //i18n.Event_Clear_All
        this.search = function () {
        };
    }

    return Model;
});