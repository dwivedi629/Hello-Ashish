﻿define([], function () {
    function Model() {
        var self = this;
        self.ItemDataSource = ko.observableArray();

        self.SelectedItems = ko.observableArray();

        self.controlId = ko.observable()

        self.cssClass = ko.observable();

        self.TabIndex = ko.observable(20);

        self.No_List_Item_String = ko.observable();

        self.none_Selected_Text = ko.observable();

        self.count_Selected_Text = ko.observable();

        self.select_All_Text = ko.observable();

        self.HasValidation = ko.observable(false);

        self.selectWidth = ko.observable();

        self.selectWidthStyle = ko.computed(function () {
            return "width:" + self.selectWidth() + "px";
        });

        self.optionText = ko.observable();

        self.optionValue = ko.observable();

        self.optionCaption = ko.observable();

        self.SelectedItems.subscribe(function (newValue) {
            self.onChange();
        });

        self.onInit = function () {
        };

        self.onChange = function () {
        };
    }
    return Model;

});