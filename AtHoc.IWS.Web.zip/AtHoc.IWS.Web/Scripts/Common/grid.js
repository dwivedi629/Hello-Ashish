﻿﻿define([
], function() {
﻿    //constructor
﻿    /*
        * refDomNode - this will be the container dom element on the page in which we will render the component
        * gridDataProvider is JSON object which has all properties/events handlers/methods which will need by component functionality
        * showPagerFlag - true/false
        * bindLocalDataSource - true/false
        * noScrollTopFlag - true/false
    */
﻿    var grid = function(refDomNode, gridDataProvider, showEmptyRowMessage, showPagerFlag, bindLocalDataSource, noScrollTopFlag) {
         var self = this;
         if (gridDataProvider.defaultPageCount == undefined) {
             gridDataProvider.defaultPageCount = 50;
         }
         self.gridDataProvider = gridDataProvider;
         self.showEmptyRowMessage = showEmptyRowMessage;
         self.showPager = showPagerFlag;
         self.noScrollTop = false;
         self.resources = gridDataProvider.localResources;

         if (typeof (gridDataProvider.showAjaxLoader) !== "undefined")
             self.showAjaxLoader = gridDataProvider.showAjaxLoader;
         if (typeof (gridDataProvider.hideAjaxLoader) !== "undefined")
             self.hideAjaxLoader = gridDataProvider.hideAjaxLoader;
    
         if (typeof (noScrollTopFlag) !== "undefined" && noScrollTopFlag) {
             self.noScrollTop = true;
         }
         
         if (typeof (bindLocalDataSource) == "undefined") {
             self.bindLocalDataSource = false;
         } else {
             self.bindLocalDataSource = bindLocalDataSource;
         }

         if ($.type(refDomNode) === "string") {
             self.gridNode = $("#" + refDomNode);
         } else {
             self.gridNode = refDomNode;
         }

         self.kendoGrid = null;

         self.itemById = {};
         self.itemIdPropertyName = self.gridDataProvider.itemIdPropertyName;

         self.selectAllCheckbox = function() {
             if (self.gridDataProvider.selectAllCheckboxClass) {
                 return self.gridNode.find(' .' + self.gridDataProvider.selectAllCheckboxClass);
             }
             return $();
         };

         // Triggered, when 'Select All' check box is checked
         this.selectAll = function() {
                 //change the underlying observable...
                 var checked = self.selectAllCheckbox().is(':checked');
                 $.each(self.kendoGrid.dataSource.view(), function(i, item) {
                     item.IsChecked = checked;
                 });

                 self.kendoGrid.refresh(); //update the grid...
                 //athoc.iws.rule.retainSelectAll();// update view count to enable/disable action items
                 self.updateSelectedTotal(); // Update selected count
             },
             this.clearSelection = function() {
                 //change the underlying observable...
                 self.selectAllCheckbox().prop('checked', false);
                 $.each(self.kendoGrid.dataSource.view(), function(i, item) {
                     item.IsChecked = false;
                 });
                 self.kendoGrid.refresh();
                 //self.kendoGrid.refresh();//update the grid...
                 self.updateSelectedTotal(); // Update selected count
             };

         this.bindCheckboxChanged = function() {
                 self.kendoGrid.tbody.on("change", "." + self.gridDataProvider.selectionCheckboxClass, function(e) {
                     var row = $(e.target).closest("tr");
                     var item = self.kendoGrid.dataItem(row);
                     item.IsChecked = $(e.target).is(":checked");
                     self.checkAndSelectAll();
                     self.updateSelectedTotal();
                 });
             },
             this.checkAndSelectAll = function() {
                 var checkboxes = self.kendoGrid.tbody.find("[type='checkbox']");
                 if (checkboxes.length != 0) //if list is empty don't checkall
                 {
                     var checkedCheckboxes = self.kendoGrid.tbody.find("input:checked");
                     if (checkedCheckboxes.length == checkboxes.length) {
                         self.selectAllCheckbox().prop('checked', true);
                     } else {
                         self.selectAllCheckbox().prop('checked', false);
                     }
                 }
             },
             this.bindClickHandlers = function() {
                 if (self.gridDataProvider.getClickClassHandlers) {
                     self.gridDataProvider.getClickClassHandlers().forEach(function(clickHandlerItem) {
                         self.kendoGrid.tbody.off("click", "." + clickHandlerItem.cssClass);
                         self.kendoGrid.tbody.on("click", "." + clickHandlerItem.cssClass, function(e) {
                             var row = $(e.target).closest("tr");
                             var item = self.kendoGrid.dataItem(row);
                             clickHandlerItem.handler(item, $(e.target));
                         });
                     });
                 }
             },
             this.getSelectedItems = function() {
                 // Get the selected items for the current page.
                 var selected = $.grep(self.kendoGrid.dataSource.view(), function(v) {
                     return v.IsChecked;
                 });
                 return selected;
             },
             this.updateSelectedTotal = function() {
                 self.selectionChanged(self.getSelectedItems().length);
                 /*if (self.navControl) {
                self.navControl.onSelectionChanged();
            }            */
             },
             this.OnDataBound = function() {
                 self.displayIndex = 0;
                 if (self.bindLocalDataSource && self.kendoGrid.dataSource.view().length == 0) {
                     var colCount = self.gridNode.find('.k-grid-header colgroup > col').length;
                     var element = $('<tr class="kendo-data-row"><td colspan="' +
                         colCount +
                         '" style="text-align:center;height:150px"><b> ' +
                         kendo.format("{0}", self.resources.noRecordsMessage) +
                         '</b></td></tr>');

                     self.gridNode.find('.k-grid-content tbody')
                         .append(element);
                 }

                 if (self.kendoGrid.dataSource.total() <= self.gridDataProvider.defaultPageCount && !self.showPager) {
                     self.kendoGrid.pager.element.hide();
                 } else {
                     self.kendoGrid.pager.element.show();
                 }

                 self.bindCheckboxChanged();
                 self.checkAndSelectAll();
                 self.bindClickHandlers();
                 self.updateSelectedTotal();

                 if (self.gridDataProvider.onDataBound) {
                     self.gridDataProvider.onDataBound();
                 }

             };

         this.createGrid = function() {
             var url = self.gridDataProvider.url;
             var datasource = new kendo.data.DataSource({
                     transport: {
                         read: {
                             url: url,
                             cache: false,
                             dataType: "json",
                             contentType: "application/json; charset=utf-8",
                             type: "POST",
                             complete: function() {
                                 // show empty list message                  
                                 var colCount = self.gridNode.find('.k-grid-header colgroup > col').length;
                                 if (self.kendoGrid.dataSource.view().length == 0) {
                                     var element;
                                     if (self.showEmptyRowMessage) {
                                         element = $('<tr class="kendo-data-row"><td colspan="' +
                                             colCount +
                                             '" style="text-align:center;height:150px"><b> ' +
                                             kendo.format(
                                                 "{0} <a href='#'>{1} {2} </a>",
                                                 self.resources.noRecordsMessage,
                                                 self.resources.noRecordsMessage_2,
                                                 self.strings.entityNameSingle) +
                                             '</b></td></tr>');

                                         self.gridNode.find('.k-grid-content tbody')
                                             .append(element);
                                         $('a', element).click(function() { self.showItem(0, "add"); });
                                     } else {
                                         element = $('<tr class="kendo-data-row"><td colspan="' +
                                             colCount +
                                             '" style="text-align:center;height:150px"><b> ' +
                                             kendo.format("{0}", self.resources.noRecordsMessage) +
                                             '</b></td></tr>');

                                         self.gridNode.find('.k-grid-content tbody')
                                             .append(element);
                                     }
                                 }
                             }
                         },
                         parameterMap: function(options) {
                             $.extend(options, self.gridDataProvider.urlOptions);

                             if (typeof (options.sort) !== "undefined" && options.sort.length > 0) {
                                 var orderBy = options.sort[0].field;
                                 var orderAsc = false;
                                 if (options.sort[0].dir == "asc") {
                                     orderAsc = true;
                                 }

                                 $.extend(options, { "orderBy": orderBy });
                                 $.extend(options, { "orderAsc": orderAsc });
                             }

                             self.updateOptions(options);

                             return kendo.stringify(options);
                         }
                     },
                     schema: self.gridDataProvider.schema,
                     sort: self.gridDataProvider.sort,
                     requestStart: function(e) {
                         self.showAjaxLoader();
                     },
                     requestEnd: function (e) {
                         if (e.response && e.response.Success) {
                             if (e.response.Success) {
                                 if (self.gridDataProvider.onLoadData) {
                                     self.gridDataProvider.onLoadData(e.response);

                                 }

                                 if (Array.isArray(e.response[self.gridDataProvider.schema.data])) {
                                     self.itemById = [];
                                     e.response[self.gridDataProvider.schema.data].forEach(function(item) {
                                         self.itemById[item.Id] = item;
                                         if (self.gridDataProvider.processData) {
                                             self.gridDataProvider.processData(item);
                                         }
                                     });
                                 }

                             } else {
                                 //need to change
                                 //self.showErrorMessage(self.resources.errorMessage);
                                 //utils.handleError(e);
                             }
                         }
                         
                         try {
                             self.hideAjaxLoader();
                         } catch (err) {

                         }
                     },
                     error: function(e) {
                         //need to change
                         //self.showErrorMessage(self.resources.errorMessage);
                         //utils.handleError(e);
                     },
                     serverSorting: self.gridDataProvider.serverSideSort,
                     serverPaging: self.gridDataProvider.serverSidePagination,
                     pageSize: self.gridDataProvider.defaultPageCount,
                     change: function(e) {
                         if (self.noScrollTop) {
                             //scrolling to the top when paging and sorting.
                             $("html,body").scrollTop(0);
                             // Added the below line to make the grid scroll on top in case of paging and sorting
                             self.gridNode.find("div.k-grid-content").scrollTop(0);
                         }
                     }
                 }
             );
             
             var template = this.getRowTemplate();

             self.kendoGrid = self.gridNode.kendoGrid({
                 dataSource: datasource,
                 groupable: false,
                 columns: self.gridDataProvider.columns(),
                 change: function(e) {

                 },
                 sortable: {
                     allowUnsort: false
                 },
                 pageable: {
                     refresh: false,
                     pageSizes: [10, 20, 50, 100],
                     buttonCount: 5,
                     messages: {
                         display: $.htmlDecode(self.resources.pager.messageSummary),
                         empty: $.htmlDecode(self.resources.pager.messageEmpty),
                         itemsPerPage: $.htmlDecode(self.resources.pager.messageItemsPerPage),
                         first: $.htmlDecode(self.resources.pager.messageGoToFirstPage),
                         previous: $.htmlDecode(self.resources.pager.messageGoToPreviousPage),
                         next: $.htmlDecode(self.resources.pager.messageGoToNextpage),
                         last: $.htmlDecode(self.resources.pager.messageGoToLastPage)
                     }
                 },
                 rowTemplate: template,
                 altRowTemplate: template,
                 dataBound: self.OnDataBound
             }).data("kendoGrid");

             self.kendoGrid.table.kendoSortable({
                 filter: ">tbody >tr",
                 handler: ".icon-drag-row",
                 cursor: "move",
                 //hint: $.noop,
                 hint: function(element) {
                     var root = $('<div style="width:500px"></div>');
                     element.clone().addClass("hint").appendTo(root);
                     return root;
                 },
                 /*placeholder: function (element) {
                    return $('<tr><td colspan="6"><div style="width:500px">' + athoc.iws.account.resources.EventRule_Manager_Drop_Here + '</div></td></tr>').addClass("placeholder");
                },*/
                 cursorOffset: {
                     top: -10,
                     left: -230
                 }
                 //container: "#" + self.gridDataProvider.elementId + " tbody",                   
             });

             $(".kendo-mini-pager").removeClass("k-pager-wrap");
             $(".kendo-mini-pager").removeClass("k-widget");
             $(".kendo-mini-pager").removeClass("k-floatwrap");

             var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
             if (gridHeader) {
                 gridHeader.addClass('table-header affix');
             }

             if (self.gridDataProvider.removeFixWidth) {
                 self.gridNode.find(".k-grid-header").css("width", "100%");
             }

             self.selectAllCheckbox().click(function() { self.selectAll(); });
             //need to change
             athoc.kendoGrid.utils.setStickyHeader();

             //need to change
             // confirmation dialog
             //this.confirmationDialog = new ConfirmationDialog(resources.PA_Event_Manager_Delete);
             //this.confirmationDialog.startup();

         };

         this.createLocalGrid = function() {
             var template = this.getRowTemplate();

             self.kendoGrid = self.gridNode.kendoGrid({
                 groupable: false,
                 columns: self.gridDataProvider.columns(),
                 change: function(e) {
                 },
                 sortable: {
                     allowUnsort: false
                 },
                 pageable: {
                     refresh: false,
                     pageSizes: [10, 20, 50, 100],
                     buttonCount: 5,
                     messages: {
                         display: $.htmlDecode(self.resources.pager.messageSummary),
                         empty: $.htmlDecode(self.resources.pager.messageEmpty),
                         itemsPerPage: $.htmlDecode(self.resources.pager.messageItemsPerPage),
                         first: $.htmlDecode(self.resources.pager.messageGoToFirstPage),
                         previous: $.htmlDecode(self.resources.pager.messageGoToPreviousPage),
                         next: $.htmlDecode(self.resources.pager.messageGoToNextpage),
                         last: $.htmlDecode(self.resources.pager.messageGoToLastPage)
                     }
                 },
                 rowTemplate: template,
                 altRowTemplate: template,
                 dataBound: self.OnDataBound,
                 autoBind: false
             }).data("kendoGrid");

             self.kendoGrid.table.kendoSortable({
                 filter: ">tbody >tr",
                 handler: ".icon-drag-row",
                 cursor: "move",
                 //hint: $.noop,
                 hint: function(element) {
                     var root = $('<div style="width:500px"></div>');
                     element.clone().addClass("hint").appendTo(root);
                     return root;
                 },
                 /*placeholder: function (element) {
                    return $('<tr><td colspan="6"><div style="width:500px">' + athoc.iws.account.resources.EventRule_Manager_Drop_Here + '</div></td></tr>').addClass("placeholder");
                },*/
                 cursorOffset: {
                     top: -10,
                     left: -230
                 }
                 //container: "#" + self.gridDataProvider.elementId + " tbody",                   
             });

             $(".kendo-mini-pager").removeClass("k-pager-wrap");
             $(".kendo-mini-pager").removeClass("k-widget");
             $(".kendo-mini-pager").removeClass("k-floatwrap");

             var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
             if (gridHeader) {
                 gridHeader.addClass('table-header affix');
             }

             if (self.gridDataProvider.removeFixWidth) {
                 self.gridNode.find(".k-grid-header").css("width", "100%");
             }

             self.selectAllCheckbox().on("click", function() { self.selectAll(); });
             //Need to change
             athoc.kendoGrid.utils.setStickyHeader();

             // confirmation dialog
             //Need to change
             //this.confirmationDialog = new ConfirmationDialog(resources.PA_Event_Manager_Delete);
             //this.confirmationDialog.startup();
         };

         this.getRowTemplate = function() {
             var template = null;
             try {
                 if (self.gridDataProvider.schema.model.id != undefined && self.gridDataProvider.schema.model.id != "")
                     template = kendo.template("<tr data-uid='#= " + self.gridDataProvider.schema.model.id + " #'>" + $("#" + self.gridDataProvider.rowTemplateId).html() + "</tr>");
                 else
                     template = kendo.template("<tr>" + $("#" + self.gridDataProvider.rowTemplateId).html() + "</tr>");
             } catch (ex) {
                 template = kendo.template("<tr>" + $("#" + self.gridDataProvider.rowTemplateId).html() + "</tr>");
             }
             return template;
         };

         // end of controller actions
         this.on = function(evtName, callback) {
             this[evtName] = callback;
         };
     };

﻿    $.extend(grid.prototype, {
         getItemById: function(id) {
             return this.itemById[id];
         },

         startup: function() {
             var self = this;

             //Need to change
             /*require(["ssa/eventManagerUtil"], function (eventMgrUtil) {
                self.eventUtil = eventMgrUtil;
            });

            this.errorTitleStrings.push(resources.PA_Message_Popup_Title_Information);
            this.errorTitleStrings.push(resources.PA_Message_Popup_Title_Warning);
            this.errorTitleStrings.push(resources.PA_Message_Popup_Title_Error);
            this.errorTitleStrings.push(resources.PA_Message_Popup_Title_Success);
            this.errorTitleStrings.push(resources.PA_Message_Popup_Title_Completed);

            
            this.bindBreadcrumb();
            */

             if (self.bindLocalDataSource) {
                 this.createLocalGrid();
             } else {
                 this.createGrid();
             }

             //Need to change
             //this.showList();

             this.initialPosition = {
                 tableCrownWrapTp: parseInt($(".table-crown-wrap").css("top"), 10),
                 kGridFixHeaderTp: parseInt($(".kgrid-fix-header").css("top"), 10),
                 kGridHeaderTp: parseInt($(".k-grid-header").css("top"), 10),
                 whiteOutHgt: parseInt($(".whiteout").css("height"), 10)
             };
         },

         refreshGrid: function(successCallback) {
             var self = this;

             //Need to change
             if (self.bindLocalDataSource == false) {
                 //show the loader when we make a request to the server...
                 //$.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: athoc.iws.rule.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: self.resources.loadingMessage }).showLoader();
                 self.showAjaxLoader();
                 //Per telerik, this will set the page only after datasource refreshes.
             }

             self.kendoGrid.dataSource.one("change", function() {
                 //pagination needs to be reset after a reload
                 this.page(1);
                 if (self.OnRefreshGridSuccessCallback) {
                     self.OnRefreshGridSuccessCallback();
                     self.OnRefreshGridSuccessCallback = null;
                 }
                 if (self.noScrollTop) {
                     //scrolling to the top when paging and sorting.
                     $("html,body").scrollTop(0);
                     //so Added the below line to make the grid scroll on top in case of paging and sorting
                     self.gridNode.find("div.k-grid-content").scrollTop(0);
                 }
             });

             self.kendoGrid.dataSource.read();
             //
             self.OnRefreshGridSuccessCallback = successCallback;
         },

         setLocalDataSource: function(data) {
             var self = this;
             var field = self.gridDataProvider.schema.data;
             if (data[field] && data[field].length >= 0) {
                 self.itemById = [];
                 data[field].forEach(function(item) {
                     self.itemById[item.Id] = item;
                     if (self.gridDataProvider.processData) {
                         self.gridDataProvider.processData(item);
                     }
                 });

                 var localDataSource = new kendo.data.DataSource({
                     data: data,
                     schema: self.gridDataProvider.schema,
                     sort: self.gridDataProvider.sort,
                     serverSorting: self.gridDataProvider.serverSideSort,
                     serverPaging: self.gridDataProvider.serverSidePagination,
                     pageSize: self.gridDataProvider.defaultPageCount,
                     change: function(e) {
                         if (self.noScrollTop) {
                             //scrolling to the top when paging and sorting.
                             $("html,body").scrollTop(0);
                             //so Added the below line to make the grid scroll on top in case of paging and sorting
                             self.gridNode.find("div.k-grid-content").scrollTop(0);
                         }
                     }
                 });
                 self.kendoGrid.setDataSource(localDataSource);

             }
         },

         initialTopPosition: {},

         adjustGridPositionAfterPillChange: function() {

             var pillContainerHeight = $('.event-filter .pill-section').height();
             if (pillContainerHeight && (pillContainerHeight > 0)) {
                 //pillContainerHeight = pillContainerHeight - 10;
                 $(".k-grid-header").css("top", this.initialPosition.kGridHeaderTp + (pillContainerHeight));
                 $(".kgrid-fix-header").css("top", this.initialPosition.kGridFixHeaderTp + (pillContainerHeight));
                 $(".whiteout").css("height", this.initialPosition.whiteOutHgt + (pillContainerHeight));

             } else {
                 $(".kgrid-fix-header").css("top", this.initialPosition.kGridFixHeaderTp);
                 $(".k-grid-header").css("top", this.initialPosition.kGridHeaderTp);
                 $(".whiteout").css("height", this.initialPosition.whiteOutHgt);
             }
         },

         // events
         remove: function(seletedIds, successCallback, failCallback) {},
         selectionChanged: function(count) {},
         updateOptions: function(option) {},
         showAjaxLoader: function () { },
         hideAjaxLoader: function() {}
     });

﻿    return grid;
﻿});