﻿define([
    "common/baseView",
    "dojo/text!common/search/template.html",
    "common/search/Model"
], function (BaseView, template, Model) {
    //constructor
    /*
        * refDomNode - this will be the container dom element on the page in which we will render the component
        * options - JSON object which will contains extra properties to be set to the component
            schema - {
                        generalLoadingMessage: "",
                        searchBoxText = "",
                        searchTitle = "",
                        clearAllText = ""
                      }
        */
    var Search = function (refDomNode, options) {

        BaseView.call(this, refDomNode, template, Model, []);

        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
        };

        this.generalLoadingMessage = "";

        if (options != null) {
            this.generalLoadingMessage = options.generalLoadingMessage; //this.model.i18n.Event_General_LoadingMessage

            if (options.searchBoxText != undefined)
                this.model.searchBoxText(options.searchBoxText);

            if (options.searchTitle != undefined)
                this.model.searchTitle(options.searchTitle);

            if (options.clearAllText != undefined)
                this.model.clearAllText(options.clearAllText);
        }
        var self = this;
        self.searchStrings = [];

        $("#searchBtn", this.refDomNode).on("click", $.proxy(function (evt) {
            if (this.model.quickSearchText().trim() != "") {
                this.search();
            }
            else {
                this.model.quickSearchText('');
            }
        },
        this));

        $("#searchGlass", this.refDomNode).on("click", $.proxy(function (evt) {
            if (this.model.quickSearchText().trim() != "") {
                this.search();
            }
            else {
                this.model.quickSearchText('');
            }
        },
        this));

        //clear all button click
        $("#clearAllBtn", this.refDomNode).on("click", $.proxy(function () {
            this.searchChange("");
            this.renderPills();
            this.model.canSearch(false);
            this.sizeChangeTrigger();
        },
        this));

        //when enter keys up in the simpleSearchText box, do search
        $("#simpleSearchText").keyup($.proxy(function (e) {
            this.model.canSearch(true);
            if (e.keyCode == 13) {
                if (this.model.quickSearchText().trim() != "") {
                    this.search();
                }
                else {
                    this.model.quickSearchText('');
                }
            }
        },
        this));
    };

    $.extend(Search.prototype, {
        search: function () {
            /*$.AjaxLoader.setup({
                useBlock: true, idToShow: undefined, elementToBlock: $(window),
                imageURL: '/athoc-cdn/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000,
                displayText: self.generalLoadingMessage
            }).showLoader();*/
            this.searchChange(this.model.quickSearchText());
            this.renderPills();
            this.model.quickSearchText("");
            this.model.canSearch(false);
            this.sizeChangeTrigger();
            this.selectrow(0);
        },

        sizeChangeTrigger: function () {
            if (this.refDomNode.height() > 100 && this.refDomNode.height() < 280) {
                this.sizeChange("fat");
            } else if (this.refDomNode.height() > 75) {
                this.sizeChange("slim");
            } else {
                this.sizeChange("compact");
            }
        },

        //events
        searchChange: function (value) {
            if (value == "") {
                this.searchStrings = [];
            } else {
                if ($.inArray(value, this.searchStrings) == -1) {
                    this.searchStrings.push(value);
                }
            }

            this.onSearchChange();
        },

        renderPills: function () {
            var self = this;
            var html = "";
            this.model.htmlPillContent('');
            if (this.searchStrings && this.searchStrings.length > 0) {
                _.each(this.searchStrings, function (item, index) {
                    var prefix = "";
                    var pillLabel = prefix + $.htmlEncode(item);
                    var pillTooltip = prefix + $.htmlEncode(item);
                    var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" href="#"></a>' : '');
                    html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                });

                if (html != "") {
                    $(".push").attr("style", 'margin-bottom:0px');
                };

                this.model.htmlPillContent(html);

                $(".pill-container .pill-close", this.refDomNode).on("click", function (event) {
                    var parentElm = $(this).parent(".pill");
                    var index = (parentElm.data("index"));
                    if (self.searchStrings && self.searchStrings.length > index) {
                        self.searchStrings.splice(index, 1);
                        self.onSearchChange();
                        self.renderPills();
                    }
                    if (self.searchStrings && self.searchStrings.length == 0) {
                        self.model.htmlPillContent('');
                    }
                    event.stopPropagation();
                });
            }
        },
        getFilters: function () {
            var filters = {};
            filters["searchStrings"] = this.searchStrings;
            return filters;
        },

        viewChange: function () { },
        sizeChange: function () { },
        selectrow: function () { },
        onSearchChange: function () { }
    });

    return Search;
});