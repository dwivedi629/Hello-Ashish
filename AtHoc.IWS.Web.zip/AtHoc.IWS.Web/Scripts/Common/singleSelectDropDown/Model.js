﻿define([], function () {
    function Model(i18n) {
        var self = this;
        self.ItemDataSource = ko.observableArray();
        self.isTemplateValidate = ko.observable(false);
        self.requiredMessage = ko.observable(i18n.WAMRule_Action_Template_Required_Message);
        self.SelectedItem = ko.observable().extend({
            required: {
                params: true,
                message: self.requiredMessage(),
                onlyIf: function () {
                    return self.isTemplateValidate() === true;
                }
            }
        });

        self.controlId = ko.observable();

        self.cssClass = ko.observable();

        self.TabIndex = ko.observable();

        self.No_List_Item_String = ko.observable();

        self.HasValidation = ko.observable(false);

        self.selectWidth = ko.observable();

        self.selectWidthStyle = ko.computed(function () {
            return "width:" + self.selectWidth() + "px";
        });

        self.optionText = ko.observable();

        self.optionValue = ko.observable();

        self.optionCaption = ko.observable();

        self.SelectedItem.subscribe(function (newValue) {
            self.onChange();
        });

        self.onInit = function () {
        };

        self.onChange = function () {
        };
    }
    return Model;

});