﻿define([
    "common/baseView",
    "common/WAMGeneral/Model",
    "vendors/text!common/WAMGeneral/template.html",

], function (BaseView, Model, template) {
    var wamGeneral = function (refDomNode, options) {
        var self = this; eturn
        self.options = options;
        BaseView.call(self, refDomNode, template, Model, []);
        self.baseStartup = self.startup;
        self.startup = function () {
            self.baseStartup.call(self);
            self.init();
        };
    };
    $.extend(wamGeneral.prototype, {

        init: function () {
            var self = this;


        },
    });

    return wamGeneral;

});