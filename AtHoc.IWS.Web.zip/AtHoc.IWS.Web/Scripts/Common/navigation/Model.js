﻿define([], function () {
    function Model() {
        var self = this;
        self.maxUngrouped = ko.observable(3);
        self.navigationModel = ko.observableArray([]);
        self.moreActionsLinkText = ko.observable('');
        self.isAnyInfoButtonVisible = function(infoButtons) {};
    }

    return Model;
});