﻿define([
    "common/baseView",
    "common/navigation/Model",
    "dojo/text!common/navigation/template.html"
], function (BaseView, Model, template) {
    //constructor
        /*
        * refDomNode - this will be the container dom element on the page in which we will render the component
        * navigationModel is JSON object which has sections array and each section contains actions array. And action has some JSON properties to configure the action button.
                    {
                      sections: [
	                    {
	                      id: "",
	                      visible: true, (optional)
	                      enable: true, (optional)
	                      primary = true,  (optional)
	                      click = function(){},
	                      readyStatus: '',      (optional) //Light indicator status
	                      readyStatusTitle: ''  (optional) //indicator message
                          btntooltip:''
	  
	                    }
		
                       ]
                    }
        * options - JSON object which will contains extra properties to be set to the component
            schema - {
                        moreActionsLinkText: "More Action"
                      }
        */
    var nav = function (refDomNode, navigationModel, options) {
        var self = this;
        BaseView.call(this, refDomNode, template, Model, []);
        self.navigationModel = navigationModel;
        if (options != null && options.moreActionsLinkText != undefined) {
            self.model.moreActionsLinkText(options.moreActionsLinkText);
        }

        self.actionById = [];
        self.sectionById = [];
        self.navigationModel.sections.forEach(function (section) {
            self.model.navigationModel.push(section);

            self.sectionById[section.dataPage] = section;
            if (typeof section.visible === 'undefined') {
                section.visible = true;
            }
            section.visible = ko.observable(section.visible);
            var ungroupedButtons = 0;
            //section.primaryButtons = [];
            //section.infoButtons = [];
            //section.sections.dropdownButtons = [];

            section.actions.forEach(function (action) {
                if (action.id) {
                    self.actionById[action.id] = action;
                }

                if (typeof action.visible === 'undefined') {
                    action.visible = true;
                }

                if (typeof action.enable === 'undefined') {
                    action.enable = true;
                }

                if (!action.primary) {
                    action.primary = false;
                } else {
                    ungroupedButtons += 1;
                }

                if (action.promoted) {
                    ungroupedButtons += 1;
                }

                // define the control event handlers for click by id...
                if (action.actionId) {
                    self[action.actionId] = function () {
                    }

                    self.model[action.actionId] = function () {
                        self[action.actionId]();
                    }
                }

                action.clickFn = function () {
                    action.click();
                };

                //if (typeof action.enable === "boolean") {
                action.enable = ko.observable(action.enable);
                /*} else {
                    action.enable = action.enable;
                }*/

                action.readyStatus = ko.observable(action.readyStatus);
                action.readyStatusTitle = ko.observable(action.readyStatusTitle);

                //if (typeof action.visible === "boolean") {
                action.visible = ko.observable(action.visible);
                /*} else {
                    action.visible = action.visible;
                }*/

                var defaultValue = typeof action.btnToolTip === 'undefined' ? action.text : action.btnToolTip;
                action.toolTip = ko.observable(defaultValue);

            });
            var maxUngrouped = (options && options.maxUngrouped ? options.maxUngrouped : 3);
            self.model.maxUngrouped(maxUngrouped - ungroupedButtons);
        }, this);

        self.updateClusters();
        self.model.isAnyInfoButtonVisible = self.isAnyInfoOptionVisible;
    };

    $.extend(nav.prototype, {
        updateClusters: function () {
            var self = this;
            self.navigationModel.sections.forEach(function (section) {
                //self.model.navigationModel.push(section);
                section.primaryWithIndicatorButtons = [];
                section.primaryButtons = [];
                section.infoButtons = [];
                section.promotedButtons = [];
                var countInfos = 0;
                section.actions.forEach(function (action) {
                    //if (action.visible()) {
                    if (action.primaryWithIndicator) {
                        section.primaryWithIndicatorButtons.push(action);
                    } else if (action.primary) {
                        section.primaryButtons.push(action);
                    } else if (action.promoted) {
                        section.promotedButtons.push(action);
                    } else {
                        section.infoButtons.push(action);
                    }
                    //}                    
                });
            }, this);
        },
        setClickHandler: function (actionId, func) {
            var action = this.actionById[actionId];
            if (action) {
                action.click = func;
            }
        },

        getAction: function (actionId) {
            return this.actionById[actionId];
        },

        getSection: function (sectionId) {
            return this.sectionById[sectionId];
        },

        //returns false if all options are not visible else returns true
        isAnyInfoOptionVisible: function (infoButtons) {
            var isVisible = false;
            for (var i = 0, len = infoButtons.length; i < len; i++) {
                if (infoButtons[i].visible()) {
                    isVisible = true;
                    break;
                }
            }
            return isVisible;
        }
    });

    return nav;
});