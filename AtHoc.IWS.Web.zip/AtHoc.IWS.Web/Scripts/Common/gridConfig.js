﻿define([], function () {
    function model() {
    var self = this;
    self.showEmptyRowMessage = false;
    self.showPager = false;
    self.bindLocalDataSource = false;
    self.noScrollTop = false;
    }
    return model;
});