﻿define([
    "common/baseView",
    "dojo/text!common/advancedSearch/searchPill/template.html",
    "common/advancedSearch/searchPill/Model"
], function (BaseView, template, Model) {
    //constructor
    var SearchPill = function (refDomNode, control) {
        var self = this;
        BaseView.call(this, refDomNode, template, Model, []);

        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
                     
        this.model.onClose = function (data, event) {                        
            if (control) {
                control.resetFilter();
            }
            self.onClose(data);
        };
    };

    $.extend(SearchPill.prototype, {
        init: function () {

        },
        update: function (model) {            
            this.model.pillTextLabel(model.label);
            this.model.pillTextValue(model.value);            
        },
        setValue: function (value) {
            this.model.pillTextValue(value);
        },

        getValue: function (value) {
            return this.model.pillTextValue();
        },
        onClose: function (data) { }
    });

    return SearchPill;
});