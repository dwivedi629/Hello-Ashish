﻿define([], function () {
    function Model() {
        var self = this;

        this.SearchDisabled = ko.observable(false);

        this.quickSearchText = ko.observable();
        this.quickFilterValue = ko.observable(-1);
        this.searchStrings = ko.observableArray();

        this.SelectedCount = ko.observable(0);

        this.visibleClearAll = ko.observable(false);

        this.isAdvanced = ko.observable(false);
        this.isQuickFilterEnabled= ko.observable(false);

        this.searchByTitle = ko.observable('');
        this.criteriaBuilderSelectedText = ko.observable('');
        this.listAdvancedTitle = ko.observable('');
        this.buttonClearAllText = ko.observable('');
        
        this.pillsClassName = ko.observable('width860');

        this.searchClick = function () {
            if (self.quickSearchText().trim() != "") {
                self.executeSearch();
            }
            else {
                self.quickSearchText('');
            }
        };
        this.clearAllClick = function () {
            self.onClearAll();
        };
        this.onKeySearch = function (data, event) {
            if (event.keyCode == 13) {
                if (self.quickSearchText().trim() != "") {
                    self.executeSearch();
                } else {
                    self.quickSearchText('');
                }
            } else {
                return true;
            }
        };

        this.clickAdvancedSearch = function () {
            self.onClickAdvanceSearch();
        };
        this.onClickAdvanceSearch = function () {
        };

        this.executeSearch = function () {
        };

        this.onClearAll = function () {
        };

        this.OrgType = ko.observable('All Accountability Events');

        this.quickFilter = function (event) {
            self.onQuickFilter(event);
        };

        this.filterClick = function (orgType, selectedText) {
            self.onFilterClick(orgType, selectedText);
        };
    }

    return Model;
});