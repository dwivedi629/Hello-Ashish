﻿define([
    "common/baseView",
    "dojo/text!common/advancedSearch/dropdownSearch/template.html",
    "common/advancedSearch/dropdownSearch/Model"
], function (BaseView, template, Model) {
    //constructor
    var DropdownSearch = function (refDomNode, options) {
        var self = this;
        this.options = options;
        BaseView.call(this, refDomNode, template, Model, []);
        this.baseStartup = this.startup;
        this.startup = function () {
            self.baseStartup.call(this);
            this.init();
        };
        this.model.labelText(this.options.labelText);
    };

    $.extend(DropdownSearch.prototype, {
        init: function () {
            var self = this;
            this.model.controlId(this.options.filterPropertyName);
            this.refDomNode.find(".selectpicker").selectpicker();
            this.model.onChange = function () {
                self.onChange();
            };

        },
        fillDropdown: function (data) {
            var self = this;
            self.model.allItemsArray([]);
            _.each(data, function (item) {
                self.model.allItemsArray.push(item);
            });
            self.refDomNode.find(".selectpicker").selectpicker('refresh');

        },
        _getSelectedName: function (allElementArray, selectedId) {
            var selectedName = "";
            for (var j = 0; j < allElementArray.length; j++) {
                if (selectedId === allElementArray[j].Id) {
                    selectedName = allElementArray[j].Name;
                    break;
                }
            }
            return selectedName;
        },
        isChanged: function () {
            return this.model.initialSelectedItem !== this.model.selectedItem();
        },
        getPillInfo: function () {
            var valueString = "";
            if (this.model.selectedItem !== "" && this.isChanged()) {
                valueString = this._getSelectedName(this.model.allItemsArray(), this.model.selectedItem());
            }

            return {
                label: this.model.labelText(),
                value: valueString
            };
        },
        getFilterInfo: function () {
            var filter = {};
            var valueId = "";
            if (this.model.selectedItem !== "" && this.isChanged()) {
                valueId = this.model.selectedItem();
            }
            filter[this.options.filterPropertyName] = valueId;
            return filter;
        },
        getSelectedValue: function () {
            var valueId = "";
            if (this.model.selectedItem !== "" && this.isChanged()) {
                valueId = this.model.selectedItem();
            }
            return valueId;
        },
        setInitialSelectedValue: function (selectedId) {
            this.model.initialSelectedItem = selectedId;
            this.model.selectedItem(selectedId);
        },
        resetFilter: function () {
            this.model.selectedItem(this.model.initialSelectedItem);
            this.refDomNode.find(".selectpicker").selectpicker('refresh');
        },
        onChange: function () { }
    });

    return DropdownSearch;
});