﻿define([], function () {
    function Model() {
        var self = this;
        this.searchText = ko.observable();        
        this.htmlPillContent = ko.observable('');
        this.searchByTitle = ko.observable('');

        this.searchText.subscribe(function (newValue) {
            self.onChange();
        });

        this.onChange = function () {
        };
    }

    return Model;
});