﻿define([], function () {
    function Model() {
        var self = this;
        this.labelFrom = ko.observable();
        this.labelTo = ko.observable();

        this.fromDateInput = ko.observable();//i18n.PA_Event_List_Search_Datepicker_Please_Enter_Date_In_Format
        this.toDateInput = ko.observable();//i18n.PA_Event_List_Search_Datepicker_Please_Enter_Date_In_Format
        this.txtDateRange = ko.observable(); //i18n.PA_Event_List_Search_Date_Range
        this.txtDateAfter = ko.observable(); //i18n.PA_Event_List_Search_Date_after
        this.txtDateBefore = ko.observable(); //i18n.PA_Event_List_Search_Date_before

        this.FromDateValueForServer = "";
        this.PreviousFromDateValue = "";
        this.FromDateValue = ko.observable();
        this.FromDateValue.subscribe(function (newValue) {            
            self.onFromDateChange(newValue);
        });

        this.onFromDateChange = function (newValue) { };

        this.ToDateValueForServer = "";
        this.PreviousToDateValue = "";
        this.ToDateValue = ko.observable();
        this.ToDateValue.subscribe(function (newValue) {            
            self.onToDateChange(newValue);
        });

        this.onToDateChange = function (newValue) { };


        this.DateRange = ko.computed(function () {
            var dateRangeText = "";
            if (self.FromDateValue() && self.ToDateValue()) {
                dateRangeText = moment(self.FromDateValue()).format(DateFormatUpper) + " - " +
                    moment(self.ToDateValue()).format(DateFormatUpper);
            }
            return dateRangeText;
        });

    }

    return Model;
});