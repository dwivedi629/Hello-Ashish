﻿define([
    "common/baseView",
    "dojo/text!common/advancedSearch/dateRangeSearch/template.html",
    "common/advancedSearch/dateRangeSearch/Model"
], function (BaseView, template, Model) {
    //constructor
    var DateRangeSearch = function (refDomNode, options) {
        var self = this;
        this.options = options;
        BaseView.call(this, refDomNode, template, Model, []);
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };

        this.model.labelFrom(this.options.labelStartDate);
        this.model.labelTo(this.options.labelToDate);

        // Data comes through Options
        this.model.fromDateInput =this.options.FromDate;
        this.model.toDateInput = this.options.ToDate;
        this.model.txtDateRange = this.options.DateRange;
        this.model.txtDateAfter = this.options.DateAfter;
        this.model.txtDateBefore = this.options.DateBefore;
    };

    $.extend(DateRangeSearch.prototype, {
        init: function () {

            this.model.onFromDateChange = function (newValue) {
                var toDateRefNode = $("#toDatePicker", this.refDomNode);
                if (newValue == null || newValue.length == 0) {
                    toDateRefNode.data("datetimepicker").setStartDate(-Infinity);
                    this.FromDateValueForServer = "";
                } else if (typeof newValue == "string") { //ingore if not dateTime object
                    return;
                } else {
                    var newDate = moment(newValue);
                    if (newDate.isValid()) {
                        var newDate = moment(newValue).format("M/D/YYYY");
                        this.FromDateValueForServer = newDate;
                        toDateRefNode.data("datetimepicker").setStartDate(newValue);

                        //need to convert to datetime object for accurate comparison.
                        var todate = new Date(this.ToDateValue());
                        //when input is typed in and is invalid (from is after to date and vice versa), copy that value. 
                        if (todate < newValue) {
                            this.ToDateValue(newValue);
                            toDateRefNode.data("datetimepicker").setDate(newValue);
                        }
                    } else {
                        toDateRefNode.data("datetimepicker").setStartDate(-Infinity);
                        this.FromDateValueForServer = "";
                    }
                }
            };

            this.model.onToDateChange = function (newValue) {
                var fromDateRefNode = $("#fromDatePicker", this.refDomNode);
                if (newValue == null || newValue.length == 0) {
                    fromDateRefNode.data("datetimepicker").setEndDate(Infinity);
                    this.ToDateValueForServer = "";
                } else if (typeof newValue == "string") { //ingore if not dateTime object
                    return;
                } else {
                    var newDate = moment(newValue);
                    if (newDate.isValid()) {

                        var newDate = moment(newValue).format("M/D/YYYY");

                        this.ToDateValueForServer = newDate;
                        fromDateRefNode.data("datetimepicker").setEndDate(newValue);

                        //need to convert to datetime object for accurate comparison.
                        var fromdate = new Date(this.FromDateValue());
                        //when input is typed in and is invalid (from is after to date and vice versa), copy that value. 
                        if (fromdate > newValue) {
                            this.FromDateValue(newValue);
                            fromDateRefNode.data("datetimepicker").setDate(newValue);
                        }
                    } else {
                        fromDateRefNode.data("datetimepicker").setEndDate(Infinity);
                        this.ToDateValueForServer = "";
                    }
                }
            };

        },
        getPillInfo: function () {
            var labelText = "";
            var valueText = "";
            if (this.model.ToDateValueForServer !== "" && this.model.FromDateValueForServer !== "") {
                labelText = this.model.txtDateRange;//i18n.PA_Event_List_Search_Date_Range;
                valueText = this.model.DateRange();
            } else {
                if (this.model.FromDateValueForServer !== "") {
                    labelText = this.model.txtDateAfter;//i18n.PA_Event_List_Search_Date_after;
                    valueText = this.model.FromDateValue() && moment(this.model.FromDateValue()).format(DateFormatUpper);
                }

                if (this.model.ToDateValueForServer !== "") {
                    labelText = this.model.txtDateBefore;//i18n.PA_Event_List_Search_Date_before;
                    valueText = this.model.ToDateValue() && moment(this.model.ToDateValue()).format(DateFormatUpper);
                }                
            }

            return {
                label: labelText,
                value: valueText
            };
        },

        getFilterInfo: function () {
            var filter = {};
            filter[this.options.filterPropertyName_FromDate] = this.model.FromDateValueForServer;
            filter[this.options.filterPropertyName_ToDate] = this.model.ToDateValueForServer;
            return filter;
        },
        resetFilter: function () {
            this.model.FromDateValueForServer="";
            this.model.ToDateValueForServer = "";
            this.model.FromDateValue("");
            this.model.ToDateValue("");
        },
        onChange: function () { }

    });

    return DateRangeSearch;
});