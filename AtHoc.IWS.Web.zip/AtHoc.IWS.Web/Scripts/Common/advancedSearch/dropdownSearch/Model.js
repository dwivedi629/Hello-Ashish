﻿define([], function () {
    function Model() {
        var self = this;
        this.controlId = ko.observable();
        this.labelText = ko.observable();
        this.dropdownSearchId = ko.observable();
        this.allItemsArray = ko.observableArray();

        this.selectedItem = ko.observable();

        this.initialSelectedItem = "";

        this.selectedItem.subscribe(function (newValue) {
            self.onChange();            
        });
        
        this.onChange = function () {
        };
    }

    return Model;
});