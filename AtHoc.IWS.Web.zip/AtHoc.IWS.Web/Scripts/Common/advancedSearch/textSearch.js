﻿define([
    "common/baseView",
    "dojo/text!common/advancedSearch/textSearch/template.html",
    "common/advancedSearch/textSearch/Model"
], function (BaseView, template, Model) {
    //constructor
    var TextSearch = function (refDomNode, options) {

        BaseView.call(this, refDomNode, template, Model, []);
        this.options = options == null ? {} : options;

        if (this.options.searchByTitle != undefined) {
            this.model.searchByTitle(this.options.searchByTitle);
        }

        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
    };

    $.extend(TextSearch.prototype, {
        init: function() {
            
        },


        onChange: function () { }
    });

    return TextSearch;
});