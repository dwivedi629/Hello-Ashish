﻿define([
    "common/baseView",
    "dojo/text!common/advancedSearch/quickFilter/template.html",
    "common/advancedSearch/quickFilter/Model"
], function (BaseView, template, Model) {
    //constructor
    var quickFilter = function (refDomNode, quickFilterOption) {
        var self = this;

        this.filterModel = [];

        this.setDefaultValue = function () {
            $.each(this.filterModel, function (count, model) {
                model.setDefaultValue();
            });
        };

        $.each(quickFilterOption, function (count, options) {
            var innerSelf = this;
            innerSelf.createNewDomNode = function () {
                var div = $("<div></div>");// .addClass('pa-float-div');
                var newNode = $(refDomNode).append(div)
                return div;
            };

            var newNode = innerSelf.createNewDomNode();
            BaseView.call(this, newNode, template, Model, []);

            innerSelf.options = options == null ? {} : options;

            innerSelf.model.quickFilterText(this.options.quickFilterText);
            innerSelf.model.quickFilterTooltip(this.options.quickFilterTooltip);
            innerSelf.model.filterPropertyName = this.options.filterPropertyName;

            this.updateValues = function (quicFilterValues) {
                var self = this;
                $.each(quicFilterValues, function (count, filterValue) {
                    var data = {
                        value: filterValue.value,
                        text: filterValue.text
                    };

                    if (filterValue.IsDefault != undefined && filterValue.IsDefault) {
                        defaultValue = filterValue;
                    }

                    self.model.quickFilterValues.push(data)
                });
            };

            innerSelf.updateValues(this.options.quickFilterValues);

            innerSelf.baseStartup = this.startup;
            innerSelf.startup = function () {
                innerSelf.baseStartup.call(this);
            };

            innerSelf.startup();
            self.filterModel.push(innerSelf.model);
        });

        this.getSelectedValue = function () {
            var selectedValues = [];
            $.each(this.filterModel, function (count, model) {
                var data = {
                    value: model.quickFilterValue,
                    filterPropertyName: model.filterPropertyName
                };

                selectedValues.push(data);
            });

            return selectedValues;
        };

        this.registerEvent = function (newFunction) {
            $.each(this.filterModel, function (count, model) {
                model.filterValueChnaged = newFunction;
            });
        };
    };

    $.extend(quickFilter.prototype, {
        init: function () {
            this.model.showDropDown(false);
        },

        onChange: function () { }
    });

    return quickFilter;
});