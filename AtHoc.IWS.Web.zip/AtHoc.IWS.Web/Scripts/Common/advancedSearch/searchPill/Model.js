﻿define([], function () {
    function Model() {
        var self = this;
        
        this.pillCloseId = ko.observable();
        //this.pillVisible = ko.observable();
        this.pillTextLabel = ko.observable();
        this.pillTextValue = ko.observable();
        this.pillTooltipText = ko.computed(function () {
            return (self.pillTextLabel() != "") ? self.pillTextLabel() + ":" + self.pillTextValue() : self.pillTextValue();
        },this);

        this.pillClose = function (data, event) {            
            self.onClose(data, event);
        };

        this.onClose = function (data, event) { };

    }

    return Model;
});