﻿define([], function () {
    function Model() {
        var self = this;
        this.controlId = ko.observable();
        this.labelText = ko.observable();
        this.selectedItemsArray = ko.observableArray();
        this.allItemsArray = ko.observableArray();

        this.listSelectAllText = "";//ko.observable(''); //i18n.PA_Event_List_Select_All
        this.noListItemText = "";//ko.observable(''); //i18n.PA_Event_List_NoList
        this.selectedCountText = "";//ko.observable(''); //i18n.PA_Event_List_Selected
        this.noneItemSelectedText = "";//ko.observable(''); //i18n.PA_Event_List_None

        this.initialItemsArray = [];

        this.selectedItemsArray.subscribe(function (newValue) {
            self.onChange();            
        });
        
        this.onChange = function () {
        };
    }

    return Model;
});