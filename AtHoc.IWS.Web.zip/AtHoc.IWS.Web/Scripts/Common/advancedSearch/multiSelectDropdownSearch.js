﻿define([
    "common/baseView",
    "dojo/text!common/advancedSearch/multiSelectDropdownSearch/template.html",
    "common/advancedSearch/multiSelectDropdownSearch/Model"
], function (BaseView, template, Model) {
    //constructor
    /*
        * refDomNode - this will be the container dom element on the page in which we will render the component
        * options - JSON object which will contains extra properties to be set to the component
            schema - {
                        labelText:"",


                        noListItemText: "",
                        listSelectAllText = "",
                        selectedCountText = "",
                        noneItemSelectedText = ""
                      }
        */
    var MultiSelectDropdownSearch = function (refDomNode, options) {
        var self = this;
        this.options = options;
        BaseView.call(this, refDomNode, template, Model, []);

        this.model.listSelectAllText = this.options.listSelectAllText;
        this.model.noListItemText = this.options.noListItemText;
        this.model.selectedCountText = this.options.selectedCountText;
        this.model.noneItemSelectedText = this.options.noneItemSelectedText;

        this.baseStartup = this.startup;
        this.startup = function () {
            self.baseStartup.call(this);
            this.init();
        };
        this.model.labelText(this.options.labelText);
        /*if (this.options.listSelectAllText != undefined) {
            this.model.listSelectAllText(this.options.listSelectAllText);
        }
        if (this.options.noListItemText != undefined) {
            this.model.noListItemText(this.options.noListItemText);
        }
        if (this.options.selectedCountText != undefined) {
            this.model.selectedCountText(this.options.selectedCountText);
        }
        if (this.options.noneItemSelectedText != undefined) {
            this.model.noneItemSelectedText(this.options.noneItemSelectedText);
        }*/
    };

    $.extend(MultiSelectDropdownSearch.prototype, {
        init: function () {
            this.model.controlId(this.options.filterPropertyName);
            this.refDomNode.find(".selectpicker").selectpicker();
        },
        fillDropdown: function (data) {
            var self = this;
            self.refDomNode.find(".selectpicker").find('option').remove();
            self.model.allItemsArray([]);
            //self.model.selectedItemsArray([]);
            $.each(data, function (index,item) {                
                self.model.allItemsArray.push(item);
            });            
            self.refDomNode.find(".selectpicker").selectpicker('refresh');
        },
        _getSelectedNames: function (allElementArray, selectedArray) {

            var selectedNames = [];
            for (var i = 0; i < selectedArray.length; i++) {
                for (var j = 0; j < allElementArray.length; j++) {
                    if (selectedArray[i] === allElementArray[j].Id) {
                        selectedNames.push(allElementArray[j].Name);
                        break;
                    }
                }
            }
            return selectedNames;
        },
        isChanged: function () {
            var initialArrary = this.model.initialItemsArray.sort();
            var selectedArray = this.model.selectedItemsArray().sort();
            var isUpdated = false;

            if (initialArrary.length != selectedArray.length) {
                isUpdated = true;
            } else {
                for (var i =0;i < initialArrary.length; i++) {
                    if (initialArrary[i]!=selectedArray[i]) {
                        isUpdated = true;
                    }
                }
            }

            return isUpdated;
        },
        getPillInfo: function () {
            var valueString = "";            
            if (this.model.selectedItemsArray().length > 0 && this.isChanged()) {
                valueString = this._getSelectedNames(this.model.allItemsArray(), this.model.selectedItemsArray()).join(", ");
            }            
            return {
                label: this.model.labelText(),
                value: valueString
            };
        },
        getFilterInfo: function () {
            var filter = {};
            var empyArray = [];
            //return empty value if Select All is selected.
            if (this.model.selectedItemsArray().length > 0 && this.isChanged()) {
                filter[this.options.filterPropertyName] = this.model.selectedItemsArray();
            } else {
                filter[this.options.filterPropertyName] = empyArray;
            }
            return filter;
        },
        //getSelectedValues: function () {
        //    this.model.selectedItemsArray();
        //},
        setInitialSelectedValues: function (selectedIds) {
            this.model.initialItemsArray = selectedIds;
            this.model.selectedItemsArray(selectedIds);            
        },
        resetFilter: function () {
            this.model.selectedItemsArray(this.model.initialItemsArray);
        },
        onChange: function () { }
    });

    return MultiSelectDropdownSearch;
});