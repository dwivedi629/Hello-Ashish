﻿define([], function () {
    function Model() {
        var self = this;

        this.quickFilterText = ko.observable();
        this.quickFilterValue;
        this.defaultValue;
        this.filterPropertyName;

        this.quickFilterTooltip = ko.observable();
        this.showDropDown = ko.observable(false);
        
        this.filterClick = function (value, text) {
            this.quickFilterText(text);
            this.quickFilterValue = value;
            this.showDropDown(false);

            if (this.filterValueChnaged != undefined) {
                this.filterValueChnaged();
            }
        };

        this.setDefaultValue = function () {
            this.filterClick(defaultValue.value, defaultValue.text);
        };

        this.quickFilterValues = ko.observableArray();

        this.showQuickFilter = function (model, event) {
            self.showDropDown(!self.showDropDown());
            if (event)
                event.stopPropagation();
        };

        $("body").on("click", function () {
            self.showDropDown(false);
        });
    }

    return Model;
});