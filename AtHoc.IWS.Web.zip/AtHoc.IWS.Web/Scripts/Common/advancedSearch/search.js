﻿define([
    "common/baseView",
    "dojo/text!common/advancedSearch/search/template.html",
    "common/advancedSearch/search/Model",
    "common/advancedSearch/searchPill",
    "common/dialog"
], function (BaseView, template, Model, PillSearch, Dialog) {
    //constructor
    /*
    * refDomNode - this will be the container dom element on the page in which we will render the component
    * options - JSON object which will contains extra properties to be set to the component
        schema - {
                    messages: {
                            display: "",
                            empty: ""
                        },
                    pageInfoText: "",   //i18n.PA_Event_List_PageInfo
                    pageInfoNoRecordsText: "",  // i18n.PA_Event_List_PageInfo_NoRecords
                    isAdvancedFilter: false/true,
                    colNumber: 0,
                    filterPropertyName: "",

                    searchByTitle: "",  //i18n.PA_Event_List_Search_By_Title
                    criteriaBuilderSelectedText: "",    //i18n.PA_Event_Criteria_Builder_selected
                    listAdvancedTitle: "",  //i18n.PA_Event_List_Advanced
                    buttonClearAllText: "",  //i18n.PA_Event_Button_ClearAll
                    cancelButtonText: "",    //i18n.PA_Template_Details_Cancel_Button_Text
                    applyButtonText: "",    //i18n.PA_Template_Details_Apply_Button_Text
                    advancedFilterPopupTitle: "",   //i18n.PA_Event_List_AdvancedFilter_Popup_Title
                    searchKeywordText: ""   //i18n.PA_Event_Search_Keyword

                    quickFilter_Events: i18n.PA_Event_List_Search_QuickFilter_AllAccountabilityEvents,
                    quickFilter_EventsFromThisOrg: i18n.PA_Event_List_Search_QuickFilter_AccountabilityEventsFromThisOrg,
                    quickFilter_EventsFromOtherOrg: i18n.PA_Event_List_Search_QuickFilter_AccountabilityEventsFromOtherOrg,
                  }
    */
    var Search = function (refDomNode, options) {

        var self = this;
        this.options = options == null ? {} : options;
        this.isAdvanced = (this.options.isAdvancedFilter && this.options.isAdvancedFilter == 'undefined') ? false : this.options.isAdvancedFilter;
        this.isQuickFilterEnabled = (this.options.isQuickFilterEnabled && this.options.isQuickFilterEnabled == 'undefined') ? false : this.options.isQuickFilterEnabled;
        
        BaseView.call(this, refDomNode, template, Model, []);

        this.messages = (this.options.messages == undefined) ? {
            display: (this.options.pageInfoText != undefined) ? this.options.pageInfoText : "",
            empty: (this.options.pageInfoNoRecordsText != undefined) ? this.options.pageInfoNoRecordsText : ""
        } : this.options.messages;


        if (this.options.searchByTitle != undefined) {
            this.model.searchByTitle(this.options.searchByTitle);
        }
        if (this.options.criteriaBuilderSelectedText != undefined) {
            this.model.criteriaBuilderSelectedText(this.options.criteriaBuilderSelectedText);
        }
        if (this.options.listAdvancedTitle != undefined) {
            this.model.listAdvancedTitle(this.options.listAdvancedTitle);
        }
        if (this.options.buttonClearAllText != undefined) {
            this.model.buttonClearAllText(this.options.buttonClearAllText);
        }

        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };

        this.columnsRefNodes = [];
        this.advancedFilters = [];
    };

    $.extend(Search.prototype, {
        init: function () {
            var self = this;

            this.model.isAdvanced(this.isAdvanced);
            this.model.isQuickFilterEnabled(this.isQuickFilterEnabled);

            if (this.isAdvanced) {
                var advSearchNavigationModel = {
                    sections: [
                        {
                            dataPage: "",
                            actions: [
                                { id: "cancel", text: self.options.cancelButtonText, primary: false, click: function () { self.hideSearchDialog(); } },
                                { id: "apply", text: self.options.applyButtonText, primary: true, click: function () { self.applySearch(); } }
                            ]
                        }
                    ]
                };


                this.advSearchDialog = new Dialog(advSearchNavigationModel, this.options.advancedFilterPopupTitle, null, null, { dlgClass: 'width940' });
                this.advSearchDialog.startup();

                var advancedSearchContainer = $("<div>").addClass("table-crown-filter advanced1 acct-event-filters");
                this.advSearchDialog.getBodyNode().append(advancedSearchContainer);


                if (self.options.colNumber) {
                    for (var i = 0; i < self.options.colNumber; i++) {
                        var rowRefNode;
                        if (self.options.colNumber - 1 == i) {
                            //rowRefNode = $("<div>").addClass("filter-col filter-col-last");
                            rowRefNode = $("<div>").addClass("filter-col");
                        } else {
                            rowRefNode = $("<div>").addClass("filter-col");
                        }

                        advancedSearchContainer.append(rowRefNode);
                        self.columnsRefNodes.push(rowRefNode);
                    }
                }

                self.model.onClickAdvanceSearch = function () {
                    self.advSearchDialog.showDialog();
                };
            }
            

            self.model.executeSearch = function() {
                if (self.model.quickSearchText() != null && self.model.quickSearchText() !== "") {
                    self.model.searchStrings.push(self.model.quickSearchText());
                }
                self.model.quickSearchText("");
                self.executeSearch();
            };

            self.model.onClearAll = function() {
                self.model.searchStrings.removeAll();
                $.each(self.advancedFilters, function(i, control) {
                    control.resetFilter();
                });
                self.executeSearch();
            };

            //self.model.onQuickFilter = function (event) {
            //    $("#contextDropdown").show();
            //    event.cancelBubble = true;
            //}

            //self.model.onFilterClick = function (type, selectedText) {
            //    self.model.OrgType(selectedText);
            //    self.model.quickFilterValue(type);               
            //    self.executeSearch();
            //}

            
        },
        executeSearch: function () {            
            this.setPills();
            this.onSearchChange();
        },
        setPills: function () {
            var self = this;
            var pillContainer = this.refDomNode.find(".pill-container");
            pillContainer.empty();
            self.model.visibleClearAll(false);

            if (this.model.searchStrings() != null && this.model.searchStrings().length > 0) {
                var searchStrings = this.model.searchStrings();
                for (var i = 0; i < searchStrings.length; i++) {
                    self.model.visibleClearAll(true);
                    var simplePillRefNode = $("<div>").addClass("pill");
                    pillContainer.append(simplePillRefNode);
                    var simplepill = new PillSearch(simplePillRefNode);
                    simplepill.startup();
                    simplepill.update({ label: this.options.searchKeywordText, value: searchStrings[i] });
                    simplepill.onClose = function (data) {
                        self.model.searchStrings.remove(data.pillTextValue());
                        self.executeSearch();
                    }
                }
            }

            $.each(this.advancedFilters, function (i, control) {
                var pillModel = control.getPillInfo();
                if (pillModel.value != "") {
                    self.model.visibleClearAll(true);
                    var pillRefNode = $("<div>").addClass("pill");
                    pillContainer.append(pillRefNode);
                    var pill = new PillSearch(pillRefNode, control);
                    pill.startup();
                    pill.update(pillModel);
                    pill.onClose = function () {
                        self.executeSearch();
                    }
                }
            });

        },
        setAdvancedFilters: function (advFilters) {
            this.advancedFilters = advFilters;
        },

        setQuickFilter: function (quickFilters) {
            var self = this;
            this.quickFilters = quickFilters;
            this.quickFilters.registerEvent(function () {
                self.executeSearch();
            });

            quickFilters.setDefaultValue();
        },

        getFilters: function () {
            var textSearch = this.options.filterPropertyName;
            var filters = {};
            filters[textSearch] = this.model.searchStrings();                      

            $.each(this.advancedFilters, function (i, control) {
                var filterInfo = control.getFilterInfo();
                $.extend(filters, filterInfo);
            });

            if (this.quickFilters) {
                var getQuickFilterValues = this.quickFilters.getSelectedValue();
                $.each(getQuickFilterValues, function (i, value) {
                    filters[value.filterPropertyName] = value.value;
                });
            }

            return filters;            
        },
        createContextRow: function (colNumber) {
            if (colNumber <= this.options.colNumber) {
                var rowRefNode = $("<div>");//.addClass("filter-element");
                this.columnsRefNodes[colNumber - 1].append(rowRefNode);
                return rowRefNode;
            } else {
                return null;
            }
        },
        setSearchPageInfo: function (datasource) {
            $("#pageInfo", this.refDomNode).kendoPager({
                dataSource: datasource,
                autoBind: false,
                numeric: false,
                previousNext: false,
                messages: {
                    display: this.messages.display,
                    empty: this.messages.empty
                }
            });

            this.refDomNode.find(".kendo-mini-pager").removeClass("k-pager-wrap");
            this.refDomNode.find(".kendo-mini-pager").removeClass("k-widget");
            this.refDomNode.find(".kendo-mini-pager").removeClass("k-floatwrap");

        },
        hideSearchDialog: function () {
            this.advSearchDialog.hideDialog();
        },

        applySearch: function () {
            this.executeSearch();
            this.advSearchDialog.hideDialog();
        },

        setSelectedCount: function (count) {
            this.model.SelectedCount(count);
        },
        onSearchChange: function () { },

        fillFilterValues: function () { }

    });

    return Search;
});