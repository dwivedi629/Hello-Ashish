﻿define([
    "common/baseView",
    "dojo/text!common/singleSelectDropDown/template.html",
    "common/singleSelectDropDown/Model"
    
], function (BaseView, template, Model) {

    var singleSelectDropdown= function (refDomNode, options) {
        var self = this;
        self.Options = options;
        BaseView.call(self, refDomNode, template, Model, []);

       //Setting Model Level Properties data
        self.model.optionText(self.Options.optionTextValue);
        self.model.optionValue(self.Options.optionIDValue);
        self.model.cssClass(self.Options.cssClass);
        self.model.TabIndex(self.Options.tabIndex);
        self.model.No_List_Item_String(self.Options.no_List_Item_String);
        self.model.selectWidth(self.Options.width);
        self.model.controlId(self.Options.controlID);
        self.model.HasValidation(self.Options.hasValidation);
        self.model.optionCaption(self.Options.optionCaption);
        self.baseStartup = self.startup;

        self.startup = function () {
            self.baseStartup.call(self);
            self.init();
            self.bindDropdown()
        };
    };
    $.extend(singleSelectDropdown.prototype, {
        init: function () {
            var self = this;
            self.model.controlId();
            self.refDomNode.find(".selectpicker").selectpicker();
            self.model.onChange = function () {
                self.isDataChanged = true;
                self.onChange();
            };

        },
        bindDropdown: function (data) {
            var self = this;
            self.model.ItemDataSource([]);
            self.model.ItemDataSource(data);
            self.refDomNode.find(".selectpicker").selectpicker('refresh');
            self.refDomNode.find(".selectallcontainer").remove();

        },
        getSelectedItem: function () {
            var self = this;
            return self.model.SelectedItem();
        },

        setSelectedItem: function (item) {
            var self = this;
            return self.model.SelectedItem(item);
        },
        onChange: function () { }
    });

    return singleSelectDropdown;
});