﻿define([], function () {
    function Model() {
        var self = this;
        //        
        self.title = ko.observable('');
        self.header = ko.observable('');
        self.body = ko.observable('');
        self.footer = ko.observable('');

        self.computeDialogClass = ko.observable();

    }

    return Model;
});