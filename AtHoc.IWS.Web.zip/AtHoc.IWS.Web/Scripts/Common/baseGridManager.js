﻿define([
    "account/utils",
    "common/confirmationDialog"
], function (utils, ConfirmationDialog) {
    /* expected strings:
        { 
            entityNameSingle:account Template,
            entityNameePlural:account Templates, 
        }
    */
    var newTemplate = false;
    var baseManager = function (gridDataProvider, searchControl, detailControl, breadcrumbModel, navControl, strings,gridConfig) {
        var self = this;
        self.gridDataProvider = gridDataProvider;
        self.searchControl = searchControl;
        self.detailControl = detailControl;
        self.breadcrumbModel = breadcrumbModel;
        self.navControl = navControl;
        self.strings = strings;
        self.gridNode = self.gridDataProvider.gridNode;
       // self.showEmptyRowMessage = showEmptyRowMessage;
      //  self.showPager = showPager;
      //  self.noScrollTop = false;
        self.gridConfig = gridConfig;

        //if (typeof (noScrollTop) !== "undefined" || noScrollTop) {
        //    self.noScrollTop = true;
        //}
        if (typeof (bindLocalDataSource) == "undefined") {
            self.bindLocalDataSource = false;
        } else {
            self.gridConfig.bindLocalDataSource = bindLocalDataSource;
        }

        if ($.type(self.gridNode) === "string") {
            self.gridNode = $("#" + self.gridNode);
        }

        self.kendoGrid = null;

        self.errorTitleStrings = new Array();
        self.itemById = {};

        if (searchControl != null) {
            searchControl.on("onSearchChange", function () {
                self.onMessagePanelHide();
                self.refreshGrid();
                // TODO : IncludeSubVps are controlled through Quick filter so below code no more required and also it is not relevant keep this code here which is specific event manager functionality          
                /*if (self.searchControl != null) {
                    if (typeof (self.gridDataProvider.model.IncludeSubVps) !== "undefined") {
                        if (self.searchControl.getFilters().VpsIds != "")
                            self.gridDataProvider.model.IncludeSubVps(false)
                        else
                            self.gridDataProvider.model.IncludeSubVps(true)
                    }
                }*/
                self.adjustGridPositionAfterPillChange();
                if (searchControl.setSearchPageInfo != null)
                    searchControl.setSearchPageInfo(self.kendoGrid.dataSource);
            });
        }

        self.selectAllCheckbox = function () {
            if (self.gridDataProvider.selectAllCheckboxClass) {
                return self.gridNode.find(' .' + self.gridDataProvider.selectAllCheckboxClass);
            }
            return $();
        };

        this.navigateToPage = function (pageName, onShow, onHide) {
            $("div[data-group='pages'] div:not([data-page='" + pageName + "'])").each(function () {
                var element = $(this);
                if (typeof (element.data("page")) !== 'undefined') {
                    element.hide(); //.css('opacity', 0);
                    if (onHide && typeof (onHide) === 'function') {
                        onHide.call(element);
                    }
                }
            });
            $("div[data-group='pages'] div[data-page='" + pageName + "']").each(function () {
                var element = $(this);
                if (typeof (element.data("page")) !== 'undefined') {
                    if (pageName == element.data("page")) {
                        element.show(); //.css('opacity', 1);
                        if (onShow && typeof (onShow) === 'function') {
                            onShow.call(element);
                        }
                    }
                }
            });
        };

        this.bindBreadcrumb = function () {
            if (this.breadcrumbModel) {
                this.breadcrumbModel.SelectedPage('listPage');
                ko.applyBindings(this.breadcrumbModel, $("#pageBreadcrumbs").get(0));
                $.titleCrumb("pageBreadcrumbs");
            }
        },
        this.createGrid = function () {
            var url = self.gridDataProvider.url;
            var datasource = new kendo.data.DataSource({
                transport: {
                    read: {
                        url: url,
                        cache: false,
                        dataType: "json",
                        contentType: "application/json; charset=utf-8",
                        type: "POST",
                        complete: function () {
                            // show empty list message                  
                            var colCount = self.gridNode.find('.k-grid-header colgroup > col').length;
                            if (self.kendoGrid.dataSource.view().length == 0) {
                                var element;
                                if (self.gridConfig.showEmptyRowMessage) {
                                    element = $('<tr class="kendo-data-row"><td colspan="' +
                                        colCount +
                                        '" style="text-align:center;height:200px"><b> ' +
                                        kendo.format(
                                        "{0} <a href='#'>{1} {2} </a>",
                                        resources.PA_Event_Manager_NoRecords_Message,
                                        resources.PA_Event_Manager_NoRecords_Message_2,
                                        self.strings.entityNameSingle) +
                                        '</b></td></tr>');

                                    self.gridNode.find('.k-grid-content tbody')
                                        .append(element);
                                    $('a', element).click(function () { self.showItem(0, "add"); });
                                } else {
                                    element = $('<tr class="kendo-data-row"><td colspan="' +
                                        colCount +
                                        '" style="text-align:center;height:200px"><b> ' +
                                        kendo.format("{0}", resources.PA_Event_Manager_NoRecords_Message) +
                                        '</b></td></tr>');

                                    self.gridNode.find('.k-grid-content tbody')
                                        .append(element);
                                }
                            }
                        }
                    },
                    parameterMap: function (options) {
                        $.extend(options, self.gridDataProvider.urlOptions);

                        if (typeof (options.sort) !== "undefined" && options.sort.length > 0) {
                            var orderBy = options.sort[0].field;
                            var orderAsc = false;
                            if (options.sort[0].dir == "asc") {
                                orderAsc = true;
                            }

                            $.extend(options, { "orderBy": orderBy });
                            $.extend(options, { "orderAsc": orderAsc });
                        }

                        if (self.searchControl != null) {
                            $.extend(options, self.searchControl.getFilters());
                        }

                        return kendo.stringify(options);
                    }
                },
                schema: self.gridDataProvider.schema,
                sort: self.gridDataProvider.sort,
                requestEnd: function (e) {
                    if (e.response && e.response.Success) {
                        if (e.response.Success) {
                            if (self.gridDataProvider.onLoadData) {
                                self.gridDataProvider.onLoadData(e.response);

                            }

                            if (e.response.Items) {
                                self.itemById = [];
                                e.response.Items.forEach(function (item) {
                                    self.itemById[item.Id] = item;
                                    if (self.gridDataProvider.processData) {
                                        self.gridDataProvider.processData(item);
                                    }
                                });
                            }

                        } else {
                            self.showErrorMessage(resources.PA_Event_Manager_ErrorMessage);
                            utils.handleError(e);
                        }
                    }
                    try {
                        $.AjaxLoader.hideLoader();
                        $(".title-bar .blockUI").hide();
                    } catch (err) {

                    }
                },
                error: function (e) {
                    self.showErrorMessage(resources.PA_Event_Manager_ErrorMessage);
                    utils.handleError(e);
                },
                serverSorting: self.gridDataProvider.serverSideSort,
                serverPaging: self.gridDataProvider.serverSidePagination,
                pageSize: 50,
                change: function (e) {
                    if (self.gridConfig.noScrollTop) {
                        //scrolling to the top when paging and sorting.
                        $("html,body").scrollTop(0);

                        // Added the below line to make the grid scroll on top in case of paging and sorting as the above line is not working correctly
                        self.gridNode.parentsUntil("div.modal-content").scrollTop(0);
                    }
                }
            }
            );

            self.kendoGrid = self.gridNode.kendoGrid({
                dataSource: datasource,
                groupable: false,
                columns: self.gridDataProvider.columns(),
                change: function (e) {

                },
                sortable: {
                    allowUnsort: false
                },
                pageable: {
                    refresh: false,
                    pageSizes: [20, 50, 100],
                    buttonCount: 5,
                    messages: {
                        display: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Summary),
                        empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                        itemsPerPage: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Items_Per_Page),
                        first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                        previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                        next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                        last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                    }
                },
                rowTemplate: kendo.template("<tr>" + $("#" + self.gridDataProvider.rowTemplateId).html() + "</tr>"),
                altRowTemplate: kendo.template("<tr>" + $("#" + self.gridDataProvider.rowTemplateId).html() + "</tr>"),
                dataBound: self.OnDataBound
            }).data("kendoGrid");

            self.kendoGrid.table.kendoSortable({
                filter: ">tbody >tr",
                handler: ".icon-drag-row",
                cursor: "move",
                //hint: $.noop,
                hint: function (element) {
                    var root = $('<div style="width:500px"></div>');
                    element.clone().addClass("hint").appendTo(root);
                    return root;
                },
                /*placeholder: function (element) {
                    return $('<tr><td colspan="6"><div style="width:500px">' + athoc.iws.account.resources.EventRule_Manager_Drop_Here + '</div></td></tr>').addClass("placeholder");
                },*/
                cursorOffset: {
                    top: -10,
                    left: -230
                }
                //container: "#" + self.gridDataProvider.elementId + " tbody",                   
            });

            $(".kendo-mini-pager").removeClass("k-pager-wrap");
            $(".kendo-mini-pager").removeClass("k-widget");
            $(".kendo-mini-pager").removeClass("k-floatwrap");

            var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
            if (gridHeader) {
                gridHeader.addClass('table-header affix');
            }

            if (self.gridDataProvider.removeFixWidth) {
                self.gridNode.find(".k-grid-header").css("width", "100%");
            }

            self.selectAllCheckbox().click(function () { self.selectAll() });
            athoc.kendoGrid.utils.setStickyHeader();

            // confirmation dialog
            //this.confirmationDialog = new ConfirmationDialog(resources.PA_Event_Manager_Delete);
            this.confirmationDialog = new ConfirmationDialog({ confirmButtonText: resources.PA_Event_Manager_Delete, cancelButtonText: resources.PA_Event_Cancel_Button });

            //this.confirmationDialog.startup();

        },

        this.createLocalGrid = function () {
            self.kendoGrid = self.gridNode.kendoGrid({
                groupable: false,
                columns: self.gridDataProvider.columns(),
                change: function (e) {
                },
                sortable: {
                    allowUnsort: false
                },
                pageable: {
                    refresh: false,
                    pageSizes: [20, 50, 100],
                    buttonCount: 5,
                    messages: {
                        display: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Summary),
                        empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                        itemsPerPage: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Items_Per_Page),
                        first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                        previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                        next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                        last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                    }
                },
                rowTemplate: kendo.template("<tr>" + $("#" + self.gridDataProvider.rowTemplateId).html() + "</tr>"),
                altRowTemplate: kendo.template("<tr>" + $("#" + self.gridDataProvider.rowTemplateId).html() + "</tr>"),
                dataBound: self.OnDataBound,
                autoBind: false
            }).data("kendoGrid");

            self.kendoGrid.table.kendoSortable({
                filter: ">tbody >tr",
                handler: ".icon-drag-row",
                cursor: "move",
                //hint: $.noop,
                hint: function (element) {
                    var root = $('<div style="width:500px"></div>');
                    element.clone().addClass("hint").appendTo(root);
                    return root;
                },
                /*placeholder: function (element) {
                    return $('<tr><td colspan="6"><div style="width:500px">' + athoc.iws.account.resources.EventRule_Manager_Drop_Here + '</div></td></tr>').addClass("placeholder");
                },*/
                cursorOffset: {
                    top: -10,
                    left: -230
                }
                //container: "#" + self.gridDataProvider.elementId + " tbody",                   
            });

            $(".kendo-mini-pager").removeClass("k-pager-wrap");
            $(".kendo-mini-pager").removeClass("k-widget");
            $(".kendo-mini-pager").removeClass("k-floatwrap");

            var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
            if (gridHeader) {
                gridHeader.addClass('table-header affix');
            }

            if (self.gridDataProvider.removeFixWidth) {
                self.gridNode.find(".k-grid-header").css("width", "100%");
            }

            self.selectAllCheckbox().click(function () { self.selectAll() });
            athoc.kendoGrid.utils.setStickyHeader();

            // confirmation dialog
            //this.confirmationDialog = new ConfirmationDialog(resources.PA_Event_Manager_Delete);
            this.confirmationDialog = new ConfirmationDialog({ confirmButtonText: resources.PA_Event_Manager_Delete, cancelButtonText: resources.PA_Event_Cancel_Button });

            //this.confirmationDialog.startup();
        },

        // Triggered, when 'Select All' check box is checked
        this.selectAll = function () {
            //change the underlying observable...
            var checked = self.selectAllCheckbox().is(':checked');
            $.each(self.kendoGrid.dataSource.view(), function (i, item) {
                item.IsChecked = checked;
            });

            self.kendoGrid.refresh();//update the grid...
            //athoc.iws.rule.retainSelectAll();// update view count to enable/disable action items
            self.updateSelectedTotal();// Update selected count
        },

        this.clearSelection = function () {
            //change the underlying observable...
            self.selectAllCheckbox().prop('checked', false);
            $.each(self.kendoGrid.dataSource.view(), function (i, item) {
                item.IsChecked = false;
            });
            self.kendoGrid.refresh();
            //self.kendoGrid.refresh();//update the grid...
            self.updateSelectedTotal();// Update selected count
        };

        this.bindCheckboxChanged = function () {
            self.kendoGrid.tbody.on("change", "." + self.gridDataProvider.selectionCheckboxClass, function (e) {
                var row = $(e.target).closest("tr");
                var item = self.kendoGrid.dataItem(row);
                item.IsChecked = $(e.target).is(":checked");
                self.checkAndSelectAll();
                self.updateSelectedTotal();
            });
        },

        this.checkAndSelectAll = function () {
            var checkboxes = self.kendoGrid.tbody.find("[type='checkbox']");
            if (checkboxes.length != 0) //if list is empty don't checkall
            {
                var checkedCheckboxes = self.kendoGrid.tbody.find("input:checked");
                if (checkedCheckboxes.length == checkboxes.length) {
                    self.selectAllCheckbox().prop('checked', true);
                } else {
                    self.selectAllCheckbox().prop('checked', false);
                }
            }
        },

        this.bindClickHandlers = function () {
            if (self.gridDataProvider.getClickClassHandlers) {
                self.gridDataProvider.getClickClassHandlers().forEach(function (clickHandlerItem) {
                    self.kendoGrid.tbody.off("click", "." + clickHandlerItem.cssClass);
                    self.kendoGrid.tbody.on("click", "." + clickHandlerItem.cssClass, function (e) {
                        var row = $(e.target).closest("tr");
                        var item = self.kendoGrid.dataItem(row);
                        clickHandlerItem.handler(item, $(e.target));
                    });
                });
            }
        },

        this.getSelectedItems = function () {
            // Get the selected items for the current page.
            var selected = $.grep(self.kendoGrid.dataSource.view(), function (v) {
                return v.IsChecked;
            });
            return selected;
        },

        this.updateSelectedTotal = function () {
            self.selectionChanged(self.getSelectedItems().length);
            /*if (self.navControl) {
                self.navControl.onSelectionChanged();
            }            */
        },

        this.OnDataBound = function () {
            self.displayIndex = 0;
            if (self.gridConfig.bindLocalDataSource && self.kendoGrid.dataSource.view().length == 0) {
                var colCount = self.gridNode.find('.k-grid-header colgroup > col').length;
                var element = $('<tr class="kendo-data-row"><td colspan="' +
                    colCount +
                    '" style="text-align:center;height:200px"><b> ' +
                    kendo.format("{0}", resources.PA_Event_Manager_NoRecords_Message) +
                    '</b></td></tr>');

                self.gridNode.find('.k-grid-content tbody')
                    .append(element);
            }

            if (self.kendoGrid.dataSource.total() <= 20 && !self.gridConfig.showPager) {
                self.kendoGrid.pager.element.hide();
            } else {
                self.kendoGrid.pager.element.show();
            }

            self.bindCheckboxChanged();
            self.checkAndSelectAll();
            self.bindClickHandlers();
            self.updateSelectedTotal();

            if (self.gridDataProvider.onDataBound) {
                self.gridDataProvider.onDataBound();
            }

        };

        this.onMessagePanelShow = function () {
            var self = this;
            if (typeof self.messagePanelViewAdjusted !== 'undefined' && self.messagePanelViewAdjusted) {
                return;
            }
            var stsPanel = $("html").find(".kgrid-status-panel");
            if (stsPanel) {
                var pnlHgt = parseInt($(".kgrid-status-panel").css("height"), 10);

                var tcwTp = parseInt($(".table-crown-wrap").css("top"), 10);
                var kgrdFxHdrTp = parseInt($(".kgrid-fix-header").css("top"), 10);
                var kgrdHdrTp = parseInt($(".k-grid-header").css("top"), 10);
                var whtoutHgt = parseInt($(".whiteout").css("height"), 10);

                $(".table-crown-wrap").css("top", tcwTp + pnlHgt);
                $(".k-grid-header").css("top", kgrdHdrTp + pnlHgt);
                //$(".kgrid-fix-header").css("top", "305px");

                $(".kgrid-fix-header").css("top", kgrdFxHdrTp + pnlHgt);
                $(".whiteout").css("height", whtoutHgt + pnlHgt);
                if (self.gridConfig.noScrollTop) {
                    $("html,body").scrollTop(0);
                }
                self.messagePanelViewAdjusted = true;
            }
        };

        this.onMessagePanelHide = function () {
            var self = this;
            if (!self.messagePanelViewAdjusted) {
                // already adjusted
                return;
            }
            var stsPanel = $("html").find(".kgrid-status-panel");
            if (stsPanel) {
                var pnlHgt = parseInt($(".kgrid-status-panel").css("height"), 10);
                var tcwTp = parseInt($(".table-crown-wrap").css("top"), 10);
                var kgrdFxHdrTp = parseInt($(".kgrid-fix-header").css("top"), 10);
                var kgrdHdrTp = parseInt($(".k-grid-header").css("top"), 10);
                var whtoutHgt = parseInt($(".whiteout").css("height"), 10);
                $(".table-crown-wrap").css("top", tcwTp - pnlHgt);
                //$(".kgrid-fix-header").css("top", "235px");
                //$(".kgrid-fix-header").css("top", "235px");
                $(".kgrid-fix-header").css("top", "235px");
                $(".kgrid-fix-header").css("top", kgrdFxHdrTp - pnlHgt);
                $(".k-grid-header").css("top", kgrdHdrTp - pnlHgt);
                $(".whiteout").css("height", whtoutHgt - pnlHgt);
                $(".kgrid-status-panel").hide();
                self.messagePanelViewAdjusted = false;
            }
        };

        this.showItemImpl = function (id, item, mode) {
            var self = this;
            // show it
            $("#detailMessagePanel").hide();
            if (this.breadcrumbModel) {
                self.breadcrumbModel.SelectedPage('detailPage');
                $.titleCrumb("pageBreadcrumbs");
                self.onMessagePanelHide();
                navigateToPage('detailPage', function () { });

                // update the detail page title                
                if (id > 0) {
                    self.breadcrumbModel.updateTitle(item.Name, null, null, 'detailPage'); // .Name convension, probably should customize it                 
                } else {
                    self.breadcrumbModel.updateTitle("New " + self.strings.entityNameSingle);
                }
            }
            if (self.gridConfig.noScrollTop) {
                $(document).scrollTop(0);
            }
            // last update theview info. it is important to update after the UI is visible (mainly for publisher;(            
            self.detailControl.update(id, item, mode);
        };

        ///// start controller actions
        if (self.navControl) {
            self.navControl.setClickHandler("save", function (e) {
                self.detailControl.save();
            });

            self.navControl.setClickHandler("add", function (e) {
                self.showItem(0, "add");
            });

            self.navControl.setClickHandler("remove", function (e) {
                var selectedItems = self.getSelectedItems();
                var seletedIds = [];
                selectedItems.forEach(function (selecteditem) {
                    seletedIds.push(selecteditem.Id);
                });

                var entityName = seletedIds.length > 1 ? self.strings.entityNamePlural : self.strings.entityNameSingle;
                var names = selectedItems.map(function (item) { return item.Name; });
                var nameTags = "";
                for (var i = 0; i < names.length; i++) {
                    nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(names[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(names[i]) + "</div>";
                }

                self.confirmationDialog.showConfirmationMessage(
                    kendo.format("{0} {1}", resources.PA_Event_Manager_Confirmation_Delete, entityName),
                    kendo.format("{0} {1} {2}", resources.PA_Event_Manager_Confirmation_Delete_Message, entityName, resources.PA_Event_Manager_Confirmation_Delete_Message_2),
                    kendo.format("{0}", nameTags),

                    function () {
                        var successCallback = function (data) {
                            self.confirmationDialog.hideConfirmationMessage();
                            self.showSuccessMessage(kendo.format("{0} {1}", name, resources.PA_Event_Manager_Confirmation_Delete_Success));
                            self.refreshGrid();
                        };

                        var failCallback = function (data) {
                            self.confirmationDialog.hideConfirmationMessage();
                            self.showErrorMessage(kendo.format("{0} {1}", resources.PA_Event_Manager_Confirmation_Delete_Failure, name));
                        };

                        self.gridDataProvider.removeSelectedEntities(seletedIds, successCallback, failCallback);
                    }
                );
            });

            self.navControl.setClickHandler("cancel", function (e) {
                var isModified = self.detailControl.isDirty();
                self.clearSelection();
                //isModified=false;
                if (isModified == true) {

                    var confirmLeave = confirm(resources.PA_General_Page_data_not_Saved_Message);
                    if (!confirmLeave) {
                        return;
                    } else {
                        self.detailControl.resetDirty(false);
                        self.showList();
                    }
                }
                else {
                    //self.detailControl.resetDirty(false);
                    self.showList();
                }
            });

            self.navControl.setClickHandler("duplicate", function (e) {
                var selectedItems = self.getSelectedItems();
                if (selectedItems.length != 1) {
                    return;
                }
                self.showItem(selectedItems[0].Id, "duplicate");
            });
        }

        if (self.detailControl) {
            self.detailControl.on("saveComplete", function (data) {
                newTemplate = true;
                self.showItem(data.Data, resources.PA_Event_Details_Summary_View_Link_Text, true);
            });
        }

        if (self.detailControl) {
            self.detailControl.on("saveFailed", function (e) {
                self.showErrorMessage(resources.PA_Template_Create_Failed_Message, true);
            });
        }

        self.gridDataProvider.on("select", function (id) {
            self.showItem(id, resources.PA_Event_Details_Summary_View_Link_Text);
        });

        // end of controller actions
        this.on = function (evtName, callback) {
            this[evtName] = callback;
        };

    };

    baseManager.prototype = {
        getItemById: function (id) {
            return this.itemById[id];
        },

        startup: function () {
            var self = this;
            require(["ssa/eventManagerUtil"], function (eventMgrUtil) {
                self.eventUtil = eventMgrUtil;
            });

            this.errorTitleStrings.push(resources.PA_Message_Popup_Title_Information);
            this.errorTitleStrings.push(resources.PA_Message_Popup_Title_Warning);
            this.errorTitleStrings.push(resources.PA_Message_Popup_Title_Error);
            this.errorTitleStrings.push(resources.PA_Message_Popup_Title_Success);
            this.errorTitleStrings.push(resources.PA_Message_Popup_Title_Completed);

            //kendo.bind($(".kendoBoundEventContext"), this.ViewModel);
            this.bindBreadcrumb();
            //ko.applyBindings(this.listButtonModel, $('#listActionButton')[0]);  

            if (self.gridConfig.bindLocalDataSource) {
                this.createLocalGrid();
            } else {
                this.createGrid();
            }

            this.showList();

            this.initialPosition = {
                tableCrownWrapTp: parseInt($(".table-crown-wrap").css("top"), 10),
                kGridFixHeaderTp: parseInt($(".kgrid-fix-header").css("top"), 10),
                kGridHeaderTp: parseInt($(".k-grid-header").css("top"), 10),
                whiteOutHgt: parseInt($(".whiteout").css("height"), 10)
            };
        },

        refreshGrid: function (successCallback) {
            var self = this;

            if (!self.gridConfig.bindLocalDataSource) {
                //show the loader when we make a request to the server...
                var elementToBlock = (typeof elementToBlock === 'undefined') ? '.title-bar' : elementToBlock;
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(elementToBlock), imageURL: athoc.iws.account.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                //Per telerik, this will set the page only after datasource refreshes.
            }

            self.kendoGrid.dataSource.one("change", function () {
                //pagination needs to be reset after a reload
                this.page(1);
                if (self.OnRefreshGridSuccessCallback) {
                    self.OnRefreshGridSuccessCallback();
                    self.OnRefreshGridSuccessCallback = null;
                }
                if (self.gridConfig.noScrollTop) {
                    //scrolling to the top when paging and sorting.
                    $("html,body").scrollTop(0);
                }
            });

            self.kendoGrid.dataSource.read();
            //
            self.OnRefreshGridSuccessCallback = successCallback;
        },

        showList: function () {
            var self = this;
            if (this.breadcrumbModel) {
                self.breadcrumbModel.SelectedPage('listPage');
                $.titleCrumb("pageBreadcrumbs");
                navigateToPage('listPage', function () { });
            }
            if (self.gridConfig.noScrollTop) {
                $(document).scrollTop(0);
            }
            self.clearSelection();
            self.onMessagePanelHide();
            $(".help-icon").attr('onClick', 'FMCOpenHelp(1004, null, null, null );');

            if (newTemplate) {
                self.refreshGrid();
                newTemplate = false;
            }
        },

        // action is: view/edit/duplicate
        showItem: function (id, action, showMessage) {
            var self = this;
            if (!self.detailControl) {
                return;
            }

            // first update theview info
            var item = null;
            if (id) {
                item = self.getItemById(id);
            }
            if (self.detailControl.loadAsync) {
                self.detailControl.loadAsync(id, action,
                    function (data) {
                        self.showItemImpl(id, data, action);
                        if (typeof (showMessage) !== "undefined" && showMessage) {
                            self.showSuccessMessage(resources.PA_Template_Saved_message, true);
                        }
                    },
                    function (error) {
                        self.showErrorMessage(error);
                    });
            } else {
                self.showItemImpl(id, item, action);
            }
        },

        //params: should include: Title, Body, Footer, ConfirmAction
        showConfirmationDialog: function (params) {
            var self = this;
            athoc.iws.account.CancelDlgData = ko.observable(params);
            //Binding
            ko.cleanNode($("#genericConfirmDialog").get(0));
            ko.applyBindings(athoc.iws.account.CancelDlgData, $("#genericConfirmDialog").get(0));

            $('#genericConfirmDialog .btn-confirm').off("click").click(function () {
                if (params.ConfirmAction) {
                    params.ConfirmAction();
                }
                return false;
            });
            $('#genericConfirmDialog .btn-cancel').off("click").click(function () {
                self.hideConfirmationDialog();
                return false;
            });
            $('#genericConfirmDialog').show();
            $('.modal-backdrop').show();
        },

        hideConfirmationDialog: function (params) {
            var self = this;
            $('.modal-backdrop').hide();
            $('#genericConfirmDialog').hide();
        },

        showErrorMessage: function (msg, isDetailView) {
            var self = this;
            if (isDetailView) {
                $('#detailMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: msg }] }, null, null, null, self.errorTitleStrings);
                $('html,body').scrollTop(0);
                self.messagePanelViewAdjusted = true;
                self.detailControl.resetDirty(false);
            } else {
                $('#messagePanel').messagesPanel(
                    { messages: [{ Type: '4', Value: msg }] },
                    null,
                    $.proxy(function () { self.onMessagePanelShow(); }),
                    $.proxy(function () { self.onMessagePanelHide(); }),
                    self.errorTitleStrings
                );
            }
        },

        showSuccessMessage: function (msg, isDetailView) {
            var self = this;
            if (isDetailView) {
                $('#detailMessagePanel').messagesPanel({ messages: [{ Type: '8', Value: msg }] }, null, null, null, self.errorTitleStrings);
                $('html,body').scrollTop(0);
                self.messagePanelViewAdjusted = true;
                self.detailControl.resetDirty(false);
            } else {
                $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: msg }] }, null, $.proxy(function () { self.onMessagePanelShow(); }), $.proxy(function () { self.onMessagePanelHide(); }), self.errorTitleStrings);
            }
        },

        setLocalDataSource: function (data) {
            var self = this;
            if (data.Items && data.Items.length > 0) {
                self.itemById = [];
                data.Items.forEach(function (item) {
                    self.itemById[item.Id] = item;
                    if (self.gridDataProvider.processData) {
                        self.gridDataProvider.processData(item);
                    }
                });

                var localDataSource = new kendo.data.DataSource({
                    data: data,
                    schema: self.gridDataProvider.schema,
                    sort: self.gridDataProvider.sort,
                    serverSorting: self.gridDataProvider.serverSideSort,
                    serverPaging: self.gridDataProvider.serverSidePagination,
                    pageSize: 50,
                    change: function (e) {
                        if (self.gridConfig.noScrollTop) {
                            //scrolling to the top when paging and sorting.
                            $("html,body").scrollTop(0);
                        }
                    }
                });
                self.kendoGrid.setDataSource(localDataSource);

            }
        },

        initialTopPosition: {},

        adjustGridPositionAfterPillChange: function () {

            var pillContainerHeight = $('.event-filter .pill-section').height();
            if (pillContainerHeight && (pillContainerHeight > 0)) {
                //pillContainerHeight = pillContainerHeight - 10;
                $(".k-grid-header").css("top", this.initialPosition.kGridHeaderTp + (pillContainerHeight));
                $(".kgrid-fix-header").css("top", this.initialPosition.kGridFixHeaderTp + (pillContainerHeight));
                $(".whiteout").css("height", this.initialPosition.whiteOutHgt + (pillContainerHeight));

            } else {
                $(".kgrid-fix-header").css("top", this.initialPosition.kGridFixHeaderTp);
                $(".k-grid-header").css("top", this.initialPosition.kGridHeaderTp);
                $(".whiteout").css("height", this.initialPosition.whiteOutHgt);
            }
        },

        // events
        remove: function (seletedIds, successCallback, failCallback) { },
        selectionChanged: function (count) { }
    };

    return baseManager;
});



