﻿define([], function () {
    function Model(refDomNode) {
        var self = this;

        self.gridNode = refDomNode;
        self.itemIdPropertyName = ""; //This will mentioned Id property field name from the item of the data source
        self.selectAllCheckboxClass = ""; //Select All checkbox class name
        self.selectionCheckboxClass = ""; //Selection checkbox class
        self.url = ""; //URL for fetching data for grid

        self.urlOptions = {
            //url options which should be pass from grid to server side to fetch the data
        
        };
        self.schema = {
            /*data: "",
            total: "",
            model: {
                fields: {
                    //add all the fields
                }
            }*/
        
        };
        self.sort = {
//Sorting configuration
            /*field: "",
            dir: "desc"*/
        
        };

        self.serverSideSort = true; //This will decide whether sorting will be client side or server side
        self.serverSidePagination = true; //This will decide pagination will perform client side ot server side
        self.rowTemplateId = ""; //Row template id for grid rows
        self.removeFixWidth = true; //whether to Remove fixed width for headers or not

        self.columns = function() {}; //This will returns all the configured columns for the grid
        self.getClickClassHandlers = [
//Click handlers array
            /*{
                cssClass: "",
                handler: function(item, targetNode) {}
            }*/
        ];


        //events
        self.select = function(id) {};
        self.onDataBound = function() {}; //dataBound event handler - function which will be used while binding data to grid row by row
        self.onLoadData = function(data) {}; //onLoadData function which will be called from requestEnd method
        self.processData = function(item) {}; //Process each of records from server response

        self.localResources = {
            noRecordsMessage: "", //PA_Event_Manager_NoRecords_Message
            noRecordsMessage_2: "", //PA_Event_Manager_NoRecords_Message_2

            pager: {
                messageSummary: "", //AtHoc_Pager_Message_Summary
                messageEmpty: "", //AtHoc_Pager_Message_Empty
                messageItemsPerPage: "", //AtHoc_Pager_Message_Items_Per_Page
                messageGoToFirstPage: "", //AtHoc_Pager_Message_Go_To_The_First_Page
                messageGoToPreviousPage: "", //AtHoc_Pager_Message_Go_To_The_Previous_Page
                messageGoToNextpage: "", //AtHoc_Pager_Message_Go_To_The_Next_Page
                messageGoToLastPage: "" //AtHoc_Pager_Message_Go_To_The_Last_Page
            },

            loadingMessage: "", //General_LoadingMessage
            errorMessage: "" //PA_Event_Manager_ErrorMessage
        };
    }

    return Model;
});