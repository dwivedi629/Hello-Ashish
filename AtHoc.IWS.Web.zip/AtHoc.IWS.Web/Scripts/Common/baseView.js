//define(["vendors/text!eventManager/getResource"], function (i18n) {
define([], function () {
    /*var i18n = $.parseJSON(i18n).Resources;
    if (!i18n) {
        //internationalization resource is not loaded
        return;
    }*/

    var i18n = {};

    var BaseView = function(refDomNode, template, Model) {
        
        if (template) {
            this.templateDom = $.parseHTML(template);
        }
        if ($.type(refDomNode) === "string") {
            refDomNode = $("#" + refDomNode);
        }
        this.refDomNode = refDomNode;

        if (this.templateDom) {
            this.refDomNode.append(this.templateDom);
        }
        if (Model) {
            this.model = new Model(i18n);
            this.model.i18n = i18n;
        }

        this.startup = function () {
            if (this.model && this.refDomNode[0]) {
                ko.applyBindings(this.model, this.refDomNode[0]);
            }
        };

        this.on = function(evtName, callback) {
            this[evtName] = callback;
        };
        this.hide = function() {
            this.refDomNode.hide();
        };
        this.show = function() {
            this.refDomNode.show();
        };
        this.destroy = function() {
            this.refDomNode.empty();
        };

        //make the expandable work, specific for bootstrap expandable
        this.setToggle = function () {
            //$('.bucket-toggle h2', this.refDomNode).click(function () {
            //    $(this).parent().find('.row').slideToggle(500);
            //    $(this).parent().find('.expand-arrow-open').toggle();
            //    $(this).parent().find('.expand-arrow-closed').toggle();
            //});
        };

        this.AppnedResources = function (resourcesToAppned) {
            i18n = $.extend(i18n, resourcesToAppned);
        };
        
    };
    return BaseView;
});