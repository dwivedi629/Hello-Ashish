﻿/// <reference path="C:\Source\svn.athoc.com\athoc\eng\trunk\Platform\DotNet\AtHoc.Pegasus\AtHoc.IWS.Web\Views/Home/_InfoAndLinks.cshtml" />
/* define javascript namespace for home page */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};

if (athoc.iws) {
    athoc.iws.home = function () {
        var windowHeight = $(window).height();
        var lastMouseX;
        $(document).on("mousemove", function (e) {
            lastMouseX = e.pageX;
            $(".home-page-tooltip").parent().css({
                left: lastMouseX + 60
            });
        });
        return {
            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for home page, will be triggered before document load
            init: function() {},

            //View model for home page data (all data except grids, charts)
            ViewModel: kendo.observable(
            {
                MaxUserCount: null,
                TotalMessages: null,
                VpsLogoGuid: null,
                WelcomeMessage: null,
                UpdatedOn: null,
                ActiveUsers: null,
                OnlineUsers: null,
                MobileUsers: -1,
                NoDeviceUsers: null,
                HealthStatus: null,
                IsAffiliate: false,
                HasAccessToAlerts: false,
                HasAccessToScenarios: false,
                HasAccessToEvents: false,
                CanStartAccountabilityEvent: false,
                HasAccessToPA: false,
                LivePAEventsCount: 0,
                CanPublishAlert: false,
                CanManagerUsers: false,
                CanConnectToOrg: false,
                LastLoginTime: null,
                ShowLoginInfo: function () {
                    return !(this.get("LastLoginTime") == null || this.get("LastLoginTime") == "");
                },
                ShowScheduled: function () {
                    return (this.HasAccessToAlerts && !(this.IsAffiliate));
                },
                LoginFailedAttempts: null,
                PasswordUpdatedOn: null,
                IsOrganizationConnected: false,
                OrganizationCount: null,
                OrganizationInviteCount: null,
                InviteVisible: function () { return (this.get("OrganizationInviteCount") > 0); },
                IsFailedAttemptVisible: function () { return (this.get("LoginFailedAttempts") > 0); },
                VpsLogoUrl: function () {
                    var defaultUrl = athoc.iws.home.urls.cdnUrl + "/images/default-logo.png";
                    if (this.get("VpsLogoGuid") === null || this.get("VpsLogoGuid").match(/^ *$/) !== null) {
                        // return defaultUrl;
                        $("#home-header-logo").hide();
                        return '';
                    } else {
                        $("#home-header-logo").show ();
                        return "/athoc-iws/Media/Get/" + this.get("VpsLogoGuid");
                    }
                },
                GetWelcomeMessage: function () {
                    var defaultMessage = athoc.iws.home.resources.Home_WelcomeMessage_Default;
                    if (this.get("WelcomeMessage") === null) {
                        return '';
                    } else if (this.get("WelcomeMessage").match(/^ *$/) !== null) {
                        return defaultMessage;
                    } else {
                        return this.get("WelcomeMessage");
                    }

                },
                FormatedActiveUsers: function (withK) { return (athoc.iws.home.formatNumberToString(this.get("ActiveUsers"), withK)); },
                FormatedOnlineUsers: function (withK) { return (athoc.iws.home.formatNumberToString(this.get("OnlineUsers"), withK)); },
                FormatedMobileUsers: function (withK) { return (athoc.iws.home.formatNumberToString(this.get("MobileUsers"), withK)); },
                FormatedNoDeviceUsers: function (withK) { return (athoc.iws.home.formatNumberToString(this.get("NoDeviceUsers"), withK)); },
                OnlineUserCountVisible: function () { return ((this.get("OnlineUsers") > -1) && !(this.get("IsAffiliate"))); },
                MobileUserCountVisible: function () { return this.get("MobileUsers") > -1; },
            }),

            formatNumberToString: function (val, withK) {
                if (val == null)
                    return val;

                if (withK && val >= 100000) {
                    var kval = val / 1000;
                    return kendo.toString(kval, "n0") + "K";
                }
                return kendo.toString(val, "n0");
            },

            //load method, will be tirggered on document load
            load: function () {
                athoc.iws.home.errors = null;

                this.loadSplitter();

                kendo.bind($("#athoc-homepage"), this.ViewModel);

                this.loadHeaderData();

                $(".icon-refresh, .section-refresh").click(athoc.iws.home.refresh);

                if (this.ViewModel.HasAccessToScenarios && $("#quick-publisher-grid").length > 0) {
                    this.loadQuickPublisherGrid();
                }

                if (("#latest-alert-grid").length > 0) {
                    this.loadLiveAlertsGrid();
                }

                if (this.ViewModel.HasAccessToEvents && $("#latest-events-grid").length > 0) {
                    this.loadEvents();
                }

                if (this.ViewModel.HasAccessToPA && $("#live-events-grid").length > 0) {
                    this.loadLiveAcctEventsGrid();
                }

                this.loadOnlineUsersLast24hrs();
                this.loadMsgSentLast24hrs();

                this.loadData();

                this.resizeAllGridBasedOnSplitterSize();

                athoc.iws.home.updateMoreLess();

                
            },

            //edit alert
            editAlert: function (id) {              
                athoc.iws.publishing.createRequest("/athoc-iws/alertmanager?nav=c&source=h&id=" + id);
            },

            //publish alert
            publishAlert: function (id) {

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlSuccess = function (data) {
                    if (data.Success) {
                        if (!data.Status) {
                            athoc.iws.publishing.view.PublishScenario(id, "home");
                            athoc.iws.publishing.view.OnCloseAfterPublish = function(id) {
                                //refresh live alerts after successfully publishing
                                if ($("#latest-alert-grid").length > 0) {
                                    $('#latest-alert-grid').data('kendoGrid').dataSource.read();
                                }

                                $('#dialogReviewAndPublish').modal('hide');
                            }
                        } else
                            athoc.iws.home.editAlert(id);

                    };


                };
                var dlAjaxOption =
               {
                   type: "POST",
                   url: "/athoc-iws/Publishing/GetScenarioPlaceholdersStatus?id=" + id
               }
                var ajaxOptions = $.extend({}, AjaxUtility(null, dlSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

            },

            //initialize health info tooltip
            initializeHealthInfo: function () {
                var $template = kendo.template($("#healthinfo-tooltip-template").html());
                $(".section-health").kendoTooltip({
                    filter: "a",
                    autoHide: false,
                    showOn: "click",
                    height: 200,
                    width: 200,
                    content: function (e) {
                        var dataItem = athoc.iws.home.ViewModel.HealthStatus;
                        return $template(dataItem);
                    }
                });
            },

            //Method to call Ajax to get home page data, this will load data in ViewModel
            loadHeaderData: function () {

                kendo.ui.progress($("#home-header"), true);

                var dlAjaxOption =
                {
                    url: athoc.iws.home.urls.GetHeaderJson,
                    contentType: 'application/json',
                    dataType: 'json',
                    type: 'POST',
                    success: function (data) {
                        if (data.Success) {
                            athoc.iws.home.ViewModel.set("VpsLogoGuid", data.Data.VpsLogoGuid);
                            athoc.iws.home.ViewModel.set("WelcomeMessage", data.Data.WelcomeMessage);
                            athoc.iws.home.updateMoreLess();
                        }
                        kendo.ui.progress($("#home-header"), false);

                    },
                    error: function (e) {
                        athoc.iws.home.handleError(e);
                        kendo.ui.progress($("#home-header"), false);
                    },
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },

            //Method to call Ajax to get home page data, this will load data in ViewModel
            loadData: function () {
                athoc.iws.home.toggleSplitterBasedOnSections();

                kendo.ui.progress($("#home-right-info"), true);
                kendo.ui.progress($("#home-login-info"), true);

                var dlAjaxOption =
                {
                    url: athoc.iws.home.urls.GetHomeJson,
                    contentType: 'application/json',
                    dataType: 'json',
                    type: 'POST',
                    success: function (data) {
                        if (data.Success) {
                            athoc.iws.home.ViewModel.set("UpdatedOn", data.Data.UpdatedOn);
                            athoc.iws.home.ViewModel.set("ActiveUsers", data.Data.ActiveUsers);
                            athoc.iws.home.ViewModel.set("OnlineUsers", data.Data.OnlineUsers);
                            athoc.iws.home.ViewModel.set("MobileUsers", data.Data.MobileUsers);
                            athoc.iws.home.ViewModel.set("NoDeviceUsers", data.Data.NoDeviceUsers);
                            athoc.iws.home.ViewModel.set("HealthStatus", data.Data.HealthStatus);
                            var template = kendo.template($("#healthinfo-template").html());
                            if (data.Data.HealthStatus) {
                            var result = template(data.Data.HealthStatus); //Execute the template
                            $("#healthInfo").html(result); //Append the result
                            } else {
                                $("#healthInfo").html(''); 
                            }
                            athoc.iws.home.ViewModel.set("IsAffiliate", data.Data.IsAffiliate);
                            athoc.iws.home.ViewModel.set("HasAccessToAlerts", data.Data.HasAccessToAlerts);
                            athoc.iws.home.ViewModel.set("HasAccessToScenarios", data.Data.HasAccessToScenarios);
                            athoc.iws.home.ViewModel.set("HasAccessToEvents", data.Data.HasAccessToEvents);
                            athoc.iws.home.ViewModel.set("HasAccessToPA", data.Data.HasAccessToAccountability);
                            athoc.iws.home.ViewModel.set("CanStartAccountabilityEvent", data.Data.CanStartAccountabilityEvent);
                            athoc.iws.home.ViewModel.set("CanPublishAlert", data.Data.CanPublishAlert);
                            athoc.iws.home.ViewModel.set("CanConnectToOrg", data.Data.CanConnectToOrg);
                            athoc.iws.home.ViewModel.set("CanManagerUsers", data.Data.CanManagerUsers);
                            athoc.iws.home.ViewModel.set("IsOrganizationConnected", data.Data.IsOrganizationConnected);
                            athoc.iws.home.ViewModel.set("OrganizationCount", data.Data.OrganizationCount);
                            athoc.iws.home.ViewModel.set("OrganizationInviteCount", data.Data.OrganizationInviteCount);
                            athoc.iws.home.ViewModel.set("LastLoginTime", data.Data.LastLoginTime);
                            athoc.iws.home.ViewModel.set("LoginFailedAttempts", data.Data.LoginFailedAttempts);
                            athoc.iws.home.ViewModel.set("PasswordUpdatedOn", data.Data.PasswordUpdatedOn);

                            athoc.iws.home.initializeHealthInfo();
                            athoc.iws.home.showOrHideAlertLinks();

                            if (data.Errors.length > 0) {
                                $.each(data.Errors, function (index, value) {
                                    if (athoc.iws.home.errors === null) {
                                        athoc.iws.home.errors = [{ Type: '4', Value: value }];
                                    } else {
                                        athoc.iws.home.errors.push({ Type: '4', Value: value });
                                    }
                                });
                                $('#homeMessagePanel').messagesPanel({ messages: athoc.iws.home.errors }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            }
                        }
                        kendo.ui.progress($("#home-right-info"), false);
                        kendo.ui.progress($("#home-login-info"), false);

                        athoc.iws.home.toggleSplitterBasedOnSections();
                        athoc.iws.home.resizeAllGridBasedOnSplitterSize();
                    },
                    error: function (e) {
                        athoc.iws.home.handleError(e);
                        kendo.ui.progress($("#home-right-info"), false);
                        kendo.ui.progress($("#home-login-info"), false);
                    },
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },

            //This will contain arrray of error, if any error occurred on home page
            errors: null,

            //Method to handle erro and session time out, this is boud with Ajax calls
            handleError: function (e) {
                var errorCallBack = function (returnedErrorObject) {
                    var message = returnedErrorObject.statusText;
                    if (message != undefined && message != "error") {
                        if (athoc.iws.home.errors === null) {
                            athoc.iws.home.errors = [{ Type: '4', Value: message }];
                        } else {
                            athoc.iws.home.errors.push({ Type: '4', Value: message });
                        }
                    }
                    if (athoc.iws.home.errors != null && athoc.iws.home.errors.length > 0) {
                        $('#homeMessagePanel').messagesPanel({ messages: athoc.iws.home.errors }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    }
                };

                AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);
            },

            //bound with refresh button of home page, reload page data
            refresh: function () {
                athoc.iws.home.errors = null;
                $('#homeMessagePanel').messagesPanel('reset');

                athoc.iws.home.loadHeaderData();

                if (athoc.iws.home.ViewModel.HasAccessToScenarios && $("#quick-publisher-grid").length > 0) {
                    $('#quick-publisher-grid').data('kendoGrid').dataSource.read();
                }

                if ($("#latest-alert-grid").length > 0) {
                    $('#latest-alert-grid').data('kendoGrid').dataSource.read();
                }

                if (athoc.iws.home.ViewModel.HasAccessToEvents && $("#latest-events-grid").length > 0) {
                    $('#latest-events-grid').data('kendoGrid').dataSource.read();
                }

                if (athoc.iws.home.ViewModel.HasAccessToPA && $("#live-events-grid").length > 0) {
                    $('#live-events-grid').data('kendoGrid').dataSource.read();
                }

                athoc.iws.home.refreshOnlineUsersLast24hrs();
                athoc.iws.home.refreshMsgSentLast24hrs();

                athoc.iws.home.loadData();
            },

            //refreshes online users in last 24 hours chart
            refreshOnlineUsersLast24hrs: function () {
                kendo.ui.progress($("#prgOnlineUsers"), true);
                $("#slOnlineUsersLast24hr").data("kendoSparkline").dataSource.read();

            },

            //refreshes messages sent in last 24 hours chart
            refreshMsgSentLast24hrs: function () {
                kendo.ui.progress($("#prgMsgSent"), true);
                $("#slMsgSentLast24hr").data("kendoSparkline").dataSource.read();
            },

            //initial load for online users chart
            loadOnlineUsersLast24hrs: function () {
                $("#slOnlineUsersLast24hr").kendoSparkline({
                    theme: "uniform",
                    series: [
                        {
                            type: "area",
                            field: "Value",
                        }
                    ],
                    chartArea: {
                        background: "transparent",
                        height: 50,
                        width: 165
                    },
                    valueAxis: {
                        minorGridLines: { visible: true }
                    },
                    autoBind: false,
                    dataSource: {
                        transport: {
                            read: {
                                url: athoc.iws.home.urls.GetOnlineUserCountsUrl,
                                cache: false
                            }
                        },
                        requestEnd: function (e) {
                            var max = !(e == undefined || e.response == undefined) ? athoc.iws.home.formatNumberToString(e.response.max, true) : 0;
                            athoc.iws.home.ViewModel.set("MaxUserCount", kendo.format(athoc.iws.home.resources.Home_OnlineUsersChart_Label, max));
                            kendo.ui.progress($("#prgOnlineUsers"), false);
                        },
                        schema: {
                            data: "data",
                        },
                        error: function (e) {
                            athoc.iws.home.handleError(e);
                            kendo.ui.progress($("#prgOnlineUsers"), false);
                        },
                        //sort: { field: "TimeStamp", dir: "asc" },
                    },
                    tooltip: {
                        template: athoc.iws.home.resources.Home_Chart_Count + ": #=athoc.iws.home.formatNumberToString(dataItem.Value, true)#<br>" + athoc.iws.home.resources.Home_Chart_Time + ": #=dataItem.TimeStampFormatted#",
                        background: "white"
                    }
                });
                athoc.iws.home.refreshOnlineUsersLast24hrs();
            },

            //initial load for messages sent chart
            loadMsgSentLast24hrs: function () {
                $("#slMsgSentLast24hr").kendoSparkline({
                    theme: "uniform",
                    series: [
                        {
                            type: "area",
                            field: "Value",
                        }
                    ],
                    chartArea: {
                        background: "transparent",
                        height: 50,
                        width: 165
                    },
                    valueAxis: {
                        minorGridLines: { visible: true },
                    },
                    autoBind: false,
                    dataSource: {
                        transport: {
                            read: {
                                url: athoc.iws.home.urls.GetMessagesSentUrl,
                                cache: false
                            }
                        },
                        requestEnd: function (e) {
                            var total = !(e == undefined || e.response == undefined) ? athoc.iws.home.formatNumberToString(e.response.total, true) : 0;
                            athoc.iws.home.ViewModel.set("TotalMessages", kendo.format(athoc.iws.home.resources.Home_MessagesChart_Label, total));
                            kendo.ui.progress($("#prgMsgSent"), false);
                        },
                        schema: {
                            data: "data",
                        },
                        error: function (e) {
                            athoc.iws.home.handleError(e);
                            kendo.ui.progress($("#prgMsgSent"), false);
                        },
                        //sort: { field: "TimeStamp", dir: "asc" },
                    },
                    tooltip: {
                        template: athoc.iws.home.resources.Home_Chart_Count + ": #=athoc.iws.home.formatNumberToString(dataItem.Value, true)#<br>" + athoc.iws.home.resources.Home_Chart_Time +": #=dataItem.TimeStampFormatted#",
                        background: "white"
                    }
                });
                athoc.iws.home.refreshMsgSentLast24hrs();
            },

            //initial load quick publisher grid
            loadQuickPublisherGrid: function () {
                $("#quick-publisher-grid").kendoGrid({
                    dataSource: {
                        type: "json",
                        transport: {
                            read: {
                                url: athoc.iws.home.urls.GetQuickPublishUrl,
                                cache: false,
                                dataType: "json",
                                contentType: "application/json; charset=utf-8",
                                type: "POST"
                            },
                        },
                        sort: { field: "Name", dir: "asc" },
                        error: function (e) { athoc.iws.home.handleError(e); },
                    },
                    height: 200,
                    sortable: { allowUnsort: false },
                    resizable:true,
                    columns: [
                        {
                            field: "IsReadyForPublish",
                            title: athoc.iws.home.resources.Home_QuickPublish_ReadyToPublish_ColumnTitle,
                            template: $("#publish-template").html(),
                            width: 80
                        }, {
                            field: "Name",
                            title: athoc.iws.home.resources.Home_QuickPublish_ScenarioName_ColumnTitle,
                            headerAttributes: { "colspan": "2" },
                            width: 210,
                        }, {
                            template: $("#edit-alert").html(),
                            width: 60,
                            headerAttributes: { "style": "display:none" }
                        }
                    ],
                    columnResize: function (e) {
                        $("#quick-publisher-grid .k-grid-header table").css("width", "100%");
                        $("#quick-publisher-grid .k-grid-content table").css("width", "100%");
                    }
                    ,
                    dataBound: function (e) {
                        //athoc.iws.home.resizeGridBasedOnSplitterSize("third-panel");
                        var grid = $("#quick-publisher-grid").data("kendoGrid");
                        $("#quick-publisher-grid").find(".k-grid-content").scrollTop(0);

                        if (grid.dataSource.view().length == 0) {
                            $("#quick-publisher-grid").find('.k-grid-content tbody')
                                .append('<tr class="kendo-data-row home-empty-row"><td class="home-empty-row" colspan="3" style="text-align:center;padding:20px; border:none;"><b>' +
                                    athoc.iws.home.resources.Home_QuickPublish_EmptyDataMessage + '</b></td></tr>');
                        }
                    }
                });

                var oldQuickPublishTooltipTop;
                var $template = kendo.template($("#scenario-tooltip-template").html());
                var quickPublishTooltip = $("#quick-publisher-grid").kendoTooltip({
                    filter: "td:nth-child(2)", //this filter selects the first column cells
                    position: "right",
                    show: function () {
                        $(this.popup.wrapper).css({
                            left: lastMouseX + 60
                        });
                        var currTooltip = $(this.popup.wrapper).find('.k-tooltip');                     
                        if (currTooltip.width() >= 500) {                           
                            currTooltip.addClass("tooltipWrap");                          
                        }
                        oldQuickPublishTooltipTop = currTooltip.offset().top;
                        var tooltipTopFromWindow = oldQuickPublishTooltipTop - $(window).scrollTop();
                        var tooltipHeight = currTooltip.outerHeight();                       
                        var tooltipTopAndHeight = tooltipTopFromWindow + tooltipHeight;
                        if (tooltipTopAndHeight >= windowHeight) {
                            var newTooltipTop = oldQuickPublishTooltipTop - (tooltipTopAndHeight - windowHeight) - 5;
                            currTooltip.offset({ top: newTooltipTop });
                        }

                    },
                    hide: function () {
                        var currTooltip = $(this.popup.wrapper).find('.k-tooltip');
                        if (currTooltip.hasClass("tooltipWrap")) {
                            currTooltip.removeClass("tooltipWrap");                           
                        }
                        currTooltip.offset({ top: oldQuickPublishTooltipTop });
                    },
                    content: function (e) {
                        e.sender.content.parent().addClass('home-page-tooltip');                      
                        var dataItem = $("#quick-publisher-grid").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },
                    animation: false
                }).on('mouseout', function (e) {
                    quickPublishTooltip.data('kendoTooltip').hide();
                });

            },

            //initial load for live alert grid
            loadLiveAlertsGrid: function () {
                $("#latest-alert-grid").kendoGrid({
                    dataSource: {
                        type: "json",
                        transport: {
                            read: {
                                url: athoc.iws.home.urls.GetLiveAlertsUrl,
                                cache: false,
                                dataType: "json",
                                contentType: "application/json; charset=utf-8",
                                type: "POST"
                            },
                        },
                        sort: { field: "PublishedTime", dir: "desc" },
                        error: function (e) { athoc.iws.home.handleError(e); },
                    },
                    height: 200,
                    sortable: { allowUnsort: false },
                    columns: [
                        {
                            field: "AlertTitle",
                            title: athoc.iws.home.resources.Home_LiveAlerts_AlertTitle_ColumnTitle,
                            template: $("#live-alert-title-template").html(),
                        }, {
                            field: "PublishedTime",
                            title: athoc.iws.home.resources.Home_LiveAlerts_PublishedTime_ColumnTitle,
                            template: '<span class="cellTooltip" title="#=PublishedTimeString#">#=PublishedTimeString#</span>',
                            width: 167,
                        }, {
                            field: "Targeted",
                            title: athoc.iws.home.resources.Home_LiveAlerts_Targeted_ColumnTitle,
                            template: $("#alert-targeted-column-template").html(),
                            width: 74,
                            sortable: false,
                            attributes: { "class": "align-right" },
                            headerAttributes: { style: "cursor: default" }
                        }, {
                            field: "Sent",
                            title: athoc.iws.home.resources.Home_LiveAlerts_Sent_ColumnTitle,
                            template: $("#alert-sent-column-template").html(),
                            width: 74,
                            sortable: false,
                            attributes: { "class": "align-right" },
                            headerAttributes: { style: "cursor: default" }
                        }, {
                            field: "Responded",
                            title: athoc.iws.home.resources.Home_LiveAlerts_Responded_ColumnTitle,
                            template: $("#alert-responded-column-template").html(),
                            width: 85,
                            sortable: false,
                            attributes: { "class": "align-right" },
                            headerAttributes: { style: "cursor: default" }
                        }, {
                            field: "AlertId",
                            hidden: true
                        }
                    ],
                    dataBound: function (e) {
                        athoc.iws.home.showOrHideAlertLinks();
                        var grid = $("#latest-alert-grid").data("kendoGrid");
                        $("#latest-alert-grid").find(".k-grid-content").scrollTop(0);

                        $("#alert-count").html("(" + grid.dataSource.view().length + ")");

                        if (grid.dataSource.view().length == 0) {
                            $("#latest-alert-grid").find('.k-grid-content tbody')
                                .append('<tr class="kendo-data-row home-empty-row"><td class="home-empty-row" colspan="6" style="text-align:center;padding:20px; border:none;"><b>' +
                                    athoc.iws.home.resources.Home_LiveAlert_EmptyDataMessage + '</b></td></tr>');
                        }
                        var alertIds = [];
                        $.each(grid.dataSource.data(), function (key, val) {
                            alertIds.push(val.AlertId);
                        });

                        $.ajax({
                            type: "POST",
                            url: athoc.iws.home.urls.GetLiveMapCountUrl,
                            cache: false,
                            dataType: "json",
                            data: { ids: alertIds, isEvent: false },
                            success: function (response) {
                                $("#divEventMapBtn .liveAlertCount").html("(" + response.count + ")");
                            }
                        });
                    }
                });

                var oldLiveAlertsTooltipTop;
                var $template = kendo.template($("#liveAlert-tooltip-template").html());
                var liveAlertsTooltip = $("#latest-alert-grid").kendoTooltip({
                    filter: ".liveAlertTitle",
                    position: "right",
                    show: function () {
                        $(this.popup.wrapper).css({
                            left: lastMouseX + 60
                        });
                        var currTooltip = $(this.popup.wrapper).find('.k-tooltip');                        
                        if (currTooltip.width() >= 500) {                          
                             currTooltip.addClass("tooltipWrap");                            
                        }
                         oldLiveAlertsTooltipTop = currTooltip.offset().top;
                         var tooltipTopFromWindow = oldLiveAlertsTooltipTop - $(window).scrollTop();
                         var tooltipHeight = currTooltip.outerHeight();                         
                         var tooltipTopAndHeight = tooltipTopFromWindow + tooltipHeight;
                         if (tooltipTopAndHeight >= windowHeight && tooltipHeight < windowHeight) {
                             var newTooltipTop = oldLiveAlertsTooltipTop - (tooltipTopAndHeight - windowHeight) - 5;
                             currTooltip.offset({ top: newTooltipTop });
                         }
                    },
                    hide: function () {
                        var currTooltip = $(this.popup.wrapper).find('.k-tooltip');
                        if (currTooltip.hasClass("tooltipWrap")) {
                            currTooltip.removeClass("tooltipWrap");                            
                        }
                        currTooltip.offset({ top: oldLiveAlertsTooltipTop });
                    },
                    content: function (e) {
                        e.sender.content.parent().addClass('home-page-tooltip');                       
                        var dataItem = $("#latest-alert-grid").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },
                    animation: false
                }).on('mouseout', function (e) {
                    liveAlertsTooltip.data('kendoTooltip').hide();
                });
            },

            //show or hide alert links
            showOrHideAlertLinks: function () {
                if (athoc.iws.home.ViewModel.HasAccessToAlerts) {
                    $(".homeAlertLink").show();
                    $(".homeAlertText").hide();
                } else {
                    $(".homeAlertLink").hide();
                    $(".homeAlertText").show();
                }

            },

            //initial load for live alert grid
            loadLiveAcctEventsGrid: function() {
                $("#live-events-grid").kendoGrid({
                    dataSource: {
                        type: "json",
                        transport: {
                            read: {
                                url: athoc.iws.home.urls.GetLiveEventsUrl,
                                cache: false,
                                dataType: "json",
                                contentType: "application/json; charset=utf-8",
                            },
                        },
                        sort: { field: "StartTime", dir: "desc" },
                        error: function(e) { athoc.iws.home.handleError(e); },
                    },
                    height: 200,
                    sortable: { allowUnsort: false },
                    columns: [
                        {
                            field: "Title",
                            title: athoc.iws.home.resources.Account_EventTitle,
                            template: '<a class="liveEventTitle" href="' + athoc.iws.home.urls.EventDetailUrl + '?id=#:EventId#" title="#=Title#">#:Title#</a>'
                        }, {
                            field: "StartTime",
                            title: athoc.iws.home.resources.Account_StartTime,
                            template: '<span class="cellTooltip" title="#=StartTimeDisplay#">#=StartTimeDisplay#</span>',
                            width: 160,
                        }, {
                            field: "Affected",
                            title: athoc.iws.home.resources.Account_AffectedUsers,                            
                            attributes: { "class": "align-right" },
                            width: 130,
                        }, {
                            width: 137,
                            title: athoc.iws.home.resources.Account_HaveStatus,
                            template: $("#event-status-column-template").html(),
                            sortable: false,
                            attributes: { "class": "align-center" },
                            headerAttributes: { style: "cursor: default" }
                        }, {
                            field: "AlertBaseId",
                            hidden: true
                        }
                    ],
                    dataBound: function(e) {
                        var grid = this;
                        $("#live-events-grid").find(".k-grid-content").scrollTop(0);

                        athoc.iws.home.ViewModel.set("LivePAEventsCount", grid.dataSource.view().length);

                        $("#live-events-grid").find(".chart").each(function () {
                            var chartContainer = $(this);
                            var tr = chartContainer.closest('tr');
                            var model = grid.dataItem(tr);
                            chartContainer.kendoChart({
                                chartArea: {
                                    width: 50,
                                    height: 50,
                                    background: "",
                                },
                                theme: "flat",
                                series: [
                                    {
                                        type: "donut",
                                        startAngle: 270,
                                        holeSize: 18,
                                        data: [
                                            {
                                                category: "Users Responded",
                                                value: model.UsersResponded,
                                                color: "#00cc03"
                                            },
                                            {
                                                category: "Users Not Responded",
                                                value: model.UsersNotResponded,
                                                color: "#eeeeee"
                                            }
                                        ]
                                    }
                                ],
                                legend: {
                                    visible: false
                                },
                                tooltip: {
                                    visible: true,
                                    template: "#: category  #: #: value #"
                                },
                            });
                            $(tr).find(".inner-content").html(kendo.format("{0:n0}%", model.Affected > 0 ? (model.UsersResponded / model.Affected) * 100 : 0));
                        });

                        if (grid.dataSource.view().length == 0) {
                            $("#live-events-grid").find('.k-grid-content tbody')
                                .append('<tr class="kendo-data-row home-empty-row"><td class="home-empty-row" colspan="6" style="text-align:center;padding:20px; border:none;"><b>' +
                                    athoc.iws.home.resources.Account_LiveEvents_EmptyDataMessage + '</b></td></tr>');
                        }

                        var eventIds = [];
                        $.each(grid.dataSource.data(), function(key, val) {
                            eventIds.push(val.AlertBaseId);
                        });

                        $.ajax({
                            type: "POST",
                            url: athoc.iws.home.urls.GetLiveMapCountUrl,
                            cache: false,
                            dataType: "json",
                            data: { ids: eventIds, isEvent: true },
                            success: function (response) {
                                $("#divEventMapBtn .liveEventCount").html("(" + response.count + ")");
                            }
                        });
                    },
                });

                var oldLiveEventsTooltipTop;
                var $template = kendo.template($("#liveEvent-tooltip-template").html());
                var liveEventsTooltip = $("#live-events-grid").kendoTooltip({
                    filter: ".liveEventTitle",
                    position: "right",
                    show: function () {
                        $(this.popup.wrapper).css({
                            left: lastMouseX + 60
                        });
                        var currTooltip = $(this.popup.wrapper).find('.k-tooltip');
                        if (currTooltip.width() >= 500) {                          
                            currTooltip.addClass("tooltipWrap");                          
                        }
                        oldLiveEventsTooltipTop = currTooltip.offset().top;
                        var tooltipTopFromWindow = oldLiveEventsTooltipTop - $(window).scrollTop();
                        var tooltipHeight = currTooltip.outerHeight();                       
                        var tooltipTopAndHeight = tooltipTopFromWindow + tooltipHeight;
                        if (tooltipTopAndHeight >= windowHeight && tooltipHeight < windowHeight) {
                            var newTooltipTop = oldLiveEventsTooltipTop - (tooltipTopAndHeight - windowHeight) - 5;
                            currTooltip.offset({ top: newTooltipTop });
                        }
                    },
                    hide: function () {
                        var currTooltip = $(this.popup.wrapper).find('.k-tooltip');
                        if (currTooltip.hasClass("tooltipWrap")) {
                            currTooltip.removeClass("tooltipWrap");                           
                        }
                        currTooltip.offset({ top: oldLiveEventsTooltipTop });
                    },
                    content: function (e) {
                        e.sender.content.parent().addClass('home-page-tooltip');                       
                        var dataItem = $("#live-events-grid").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },
                    animation: false
                }).on('mouseout', function (e) {
                    liveEventsTooltip.data('kendoTooltip').hide();
                });
            },

            //map component, will be holding Map
            eventMap: null,

            //load events grid and map control
            loadEvents: function () {

                $("#latest-events-grid").kendoGrid({
                    height: 200,
                    sortable: false,
                    //selectable: "row",
                    columns: [
                        {
                            field: "severityIcon",
                            title: " ",
                            sortable: false,
                            width: 50,
                            encoded: false,
                            headerAttributes: {
                                style: "cursor: default; border-width:0 0 0 0;"
                            }
                        }, {
                            field: "titleAndName",
                            title: " ",
                            width: 130,
                            sortable: false,
                            encoded: false,
                            headerAttributes: {
                                style: "cursor: default; border-width:0 0 0 0;"
                            }
                        }, {
                            field: "timeAndCategory",
                            width: 120,
                            sortable: false,
                            encoded: false,
                            title: " ",
                            headerAttributes: {
                                style: "cursor: default; border-width:0 0 0 0;"
                            }
                        }
                    ],
                    dataSource: {
                        type: "json",
                        transport:
                        {
                            read: {
                                url: athoc.iws.home.urls.GetEventsUrl,
                                cache: false,
                                dataType: "json",
                                contentType: "application/json; charset=utf-8",
                                type: "POST"
                            },
                        },
                        requestEnd: function (e) {
                            kendo.ui.progress($("#events-map"), false);

                            if (e.response == undefined || e.response.Data == undefined) {
                                return;
                            }

                            var data = e.response.Data;
                            $.each(data, function (idx, item) {
                                athoc.iws.home.processEventData(item);
                            });
                            e.response.Data = data;
                        },
                        requestStart: function (e) {
                            kendo.ui.progress($("#events-map"), true);
                        },
                        schema: { data: "Data", model: { id: "Id" } },
                        error: function (e) { athoc.iws.home.handleError(e); },
                    },

                    dataBound: function (e) {
                        var grid = $("#latest-events-grid").data("kendoGrid");

                        if (grid.dataSource.view().length == 0) {
                            $("#latest-events-grid").find('.k-grid-content tbody')
                                .append('<tr class="kendo-data-row home-empty-row"><td class="home-empty-row" colspan="3" style="text-align:center;padding:20px; border:none;"><b>' +
                                    athoc.iws.home.resources.Home_Events_EmptyDataMessage + '</b></td></tr>');
                        }

                        require(["widget/Map", "ssa/Graphic"], function (Map, Graphic) {
                            var firstrun = false;

                            if (athoc.iws.home.eventMap == null) {
                                athoc.iws.home.eventMap = new Map("events-map", { i18n:athoc.iws.home.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                                firstrun = true;
                                $("#events-map").append("<div class='map-expand z-index1' title='" + athoc.iws.home.resources.Home_Events_ExpandMap_Tooltip + "'></div>");
                                $("#events-map").find(".map-expand").click(athoc.iws.home.showMapInModel);
                                $.ajax({
                                    type: "GET",
                                    url: "/athoc-iws/maplayers/GetLiveIncomingAlerts?IsEnded=false",
                                    cache:false,
                                    dataType: "json",
                                    success: function (response) {
                                        if(response.features!=null && response.features.length > 0)
                                        {
                                            athoc.iws.home.eventMap.addGeoJson(response);
                                            setTimeout(function () {
                                                athoc.iws.home.eventMap.centerAt([0, 0]);
                                                athoc.iws.home.eventMap.zoomToFit();
                                            }, 1000);
                                        }

                                    }
                                });
                            }
                            /* show all live alerts, instead of the last 10
                            var graphic, graphics;
                            graphics = [];

                            $.each(grid.dataSource.view(), function (idx, dataItem) {
                                if (dataItem.Latitude !== 0 && dataItem.Longitude !== 0) {
                                    graphic = new Graphic({
                                        geometry: [dataItem.Latitude, dataItem.Longitude],
                                        popup: $("<div id='escapeDiv'></div>").text(dataItem.Title).html(),
                                        symbol: dataItem.TypeIcon,
                                        id: dataItem.Id
                                    });
                                    graphics.push(graphic);
                                }
                                if (dataItem.GeoJson) {
                                    var geoJson = $.parseJSON(dataItem.GeoJson);
                                    if (geoJson.features && geoJson.features.length > 0) {
                                        athoc.iws.home.eventMap.addGeoJson(geoJson);
                                    }
                                }
                            });

                            if (grid.dataSource.view().length > 0) {
                                athoc.iws.home.eventMap.clearGraphics();
                                athoc.iws.home.eventMap.addGraphics(graphics);
                                if (graphics && graphics.length > 0) {
                                    athoc.iws.home.eventMap.zoomToFit();
                                } else {
                                    athoc.iws.home.eventMap.centerAt([38, -122]);
                                    athoc.iws.home.eventMap.zoomToLevel(1);
                                }
                                athoc.iws.home.eventMap.on("popupShow", athoc.iws.home.onMapSelect);

                                if (firstrun) {
                                    setTimeout(function () {
                                        athoc.iws.home.eventMap.centerAt([0, 0]);
                                        athoc.iws.home.eventMap.zoomToFit();
                                    }, 500);
                                }
                            }*/
                        });

                    },
                    //change: function (e) {
                    //    athoc.iws.home.gridFirst = false;
                    //    var model = this.dataItem(this.select());

                    //    if (model == undefined) {
                    //        return;
                    //    }

                    //    if (model.Latitude !== 0 && model.Longitude !== 0) {
                    //        athoc.iws.home.eventMap.showPopup(model.Id);
                    //    } else {
                    //        athoc.iws.home.eventMap.hidePopup();
                    //    }
                    //}

                });
            },

            //flat to hold if grid should be scrolled or not on map selection
            //require for avoiding circular call between map and event grid
            gridFirst: true,

            //boud with icon click of map
            onMapSelect: function (e) {
                var grid = $("#latest-events-grid").data("kendoGrid");
                var item = grid.dataSource.get(e.id);
                if (athoc.iws.home.gridFirst) {
                    var tr = $("[data-uid='" + item.uid + "']", grid.tbody);
                    grid.select(tr);

                    var rowIndex = $("#latest-events-grid").find("tr").index(tr);
                    rowIndex = rowIndex - 1;
                    $("#latest-events-grid").find(".k-grid-content").scrollTop(rowIndex * 45);
                } else {
                    athoc.iws.home.eventMap.centerAt([item.Latitude, item.Longitude]);
                }
                athoc.iws.home.gridFirst = true;
            },

            //map component for model window
            modelMap: null,

            //shows map in model window
            showMapInModel: function () {
                //load bigger map 
                if (!athoc.iws.home.viewMap) { 
                    //Check if already loaded file or not
                    require(["maps/GeoTargetMap"], function(GeoTargetMap) {
                        athoc.iws.home.viewMap = new GeoTargetMap({
                            viewMode: true,
                            i18n: athoc.iws.home.mapResources,
                            culture: languageParams.currentCulture,
                        }, "big-map-home-page");
                        athoc.iws.home.viewMap.startup();
                    });
                }
                athoc.iws.home.viewMap.show();
            },

            //Load splitter for sections on home page
            loadSplitter: function () {

                $("#vertical").kendoSplitter({
                    orientation: "vertical",
                    panes: [
                        { size: this.getSplitterSize('splitter-one'), min: "32px" },
                        { size: this.getSplitterSize('splitter-placeholder') }
                    ],
                    resize: this.onSplitterResize,
                });

                $(".expand-arrow-open").click(athoc.iws.home.maximizeOrMinimizeSection);
                $(".expand-arrow-closed").click(athoc.iws.home.maximizeOrMinimizeSection);
                $(".home-section-title").click(athoc.iws.home.maximizeOrMinimizeSection);

                athoc.iws.home.toggleSplitterBasedOnSections();
            },

            //toggle visibility of splitter based on role
            toggleSplitterBasedOnSections: function () {
                //{ size: this.getSplitterSize('splitter-two'), min: "32px" },
                //{ size: this.getSplitterSize('splitter-three'), min: "32px" },

                var splitter = $("#vertical").data("kendoSplitter");

                if (this.ViewModel.HasAccessToEvents) {
                    if ($("#vertical").find("#splitter-two").length == 0) {
                        //var splitterTwo = splitter.insertAfter({ size: this.getSplitterSize('splitter-two'), min: "32px" }, "#splitter-one");
                        var splitterTwo = splitter.insertBefore({ size: this.getSplitterSize('splitter-two'), min: "32px" }, "#splitter-placeholder");
                        splitterTwo.append($("#event-content"));
                        splitterTwo.attr("id", "splitter-two");
                    }
                } else {
                    if ($("#vertical").find("#splitter-two").length > 0) {
                        $("#home-optional-section").append($("#event-content"));
                        splitter.remove("#splitter-two");
                    }
                }
                if (this.ViewModel.HasAccessToScenarios) {
                    if ($("#vertical").find("#splitter-three").length == 0) {
                        //var splitterThree = splitter.insertBefore({ size: this.getSplitterSize('splitter-three'), min: "32px" }, "#splitter-placeholder");
                        var splitterThree = splitter.insertAfter({ size: this.getSplitterSize('splitter-three'), min: "32px" }, "#splitter-one");
                        splitterThree.append($("#publisher-content"));
                        splitterThree.attr("id", "splitter-three");
                    }
                } else {
                    if ($("#vertical").find("#splitter-three").length > 0) {
                        $("#home-optional-section").append($("#publisher-content"));
                        splitter.remove("#splitter-three");
                    }
                }

                if (this.ViewModel.HasAccessToPA) {
                    if ($("#vertical").find("#splitter4").length == 0) {
                        var splitter4 = splitter.insertAfter({ size: this.getSplitterSize('splitter4'), min: "32px" }, this.ViewModel.HasAccessToScenarios ? "#splitter-three" : "#splitter-one");//add it after quick publish otherwise after live alerts.
                        splitter4.append($("#livePAEvents-content"));
                        splitter4.attr("id", "splitter4");
                    }
                } else {
                    if ($("#vertical").find("#splitter4").length > 0) {
                        $("#home-optional-section").append($("#livePAEvents-content"));
                        splitter.remove("#splitter4");
                    }
                }
                //TODO: If required to remove last splitter uncomment following line
                //$("#vertical").find(".k-splitbar:last").hide();
            },

            //bound with section collapse/expand and section title
            maximizeOrMinimizeSection: function () {
                var splitter = $("#vertical").data("kendoSplitter");

                if ($(this).hasClass("expand-arrow-open")) {
                    splitter.size($(this).closest(".k-pane"), "32px");
                    $(this).closest(".k-pane").find(".expand-arrow-closed").show();
                    $(this).hide();
                    $(this).closest(".k-pane").find(".row").hide();

                } else if ($(this).hasClass("expand-arrow-closed")) {
                    splitter.size($(this).closest(".k-pane"), "250px");
                    $(this).closest(".k-pane").find(".expand-arrow-open").show();
                    $(this).hide();
                    $(this).closest(".k-pane").find(".row").show();
                    athoc.iws.home.resizeAllGridBasedOnSplitterSize();
                }
                else if ($(this).hasClass("home-section-title")) {
                    if ($(this).parent().find(".expand-arrow-open").is(':visible')) {
                        $(this).parent().find(".expand-arrow-open").trigger('click');
                    } else {
                        $(this).parent().find(".expand-arrow-closed").trigger('click');
                    }
                }
            },

            //Iterate through all grids to set correct size of grid based on any size change in splitter
            resizeAllGridBasedOnSplitterSize: function () {
                $(".k-pane").each(function () {
                    athoc.iws.home.resizeGridBasedOnSplitterSize($(this).attr("id"));
                });
            },

            //Set correct size (height) of grid based on parent splitter re-size
            resizeGridBasedOnSplitterSize: function (id) {
                var parent = $("#" + id);
                var height = parent.height() - 65;
                if (parent.find(".auto-height").length > 0) {
                    height = height + 20;
                    parent.find(".auto-height").height(height);
                    parent.find(".k-grid").height(height);
                    height = height - 1;
                    parent.find(".k-grid-content").height(height);
                } else {
                    if (parent.find("#alertlink:hidden").length > 0) {
                        height = height + 20;
                    }

                    parent.find(".k-grid").height(height);
                    height = height - 31;
                    parent.find(".k-grid-content").height(height);
                }

                if (parent.height() <= 40) {
                    parent.find(".expand-arrow-closed").show();
                    parent.find(".expand-arrow-open").hide();
                    parent.find(".row").hide();
                } else {
                    parent.find(".expand-arrow-open").show();
                    parent.find(".expand-arrow-closed").hide();
                    parent.find(".row").show();
                }

                if (id == "splitter-two" && athoc.iws.home.eventMap != null) {
                    athoc.iws.home.eventMap.reCalculateSize();
                }
            },

            //Unique identifier for user and vps for persisiting settings
            identifier: '',

            //On Splitter Resize event, persiste any size changes in splitter
            onSplitterResize: function (e) {
                e.sender.element.find(".k-pane").each(function () {
                    var kendoPane = $(this).data("pane");
                    var kendoPaneId = $(this).attr("id");
                    try {
                        localStorage.setItem(kendoPaneId + '-' + athoc.iws.home.identifier + '-size', kendoPane.size);
                    } catch (e) {
                        //try-catch to handle private mode of browser, when local storage is not uspported
                    }

                    athoc.iws.home.resizeGridBasedOnSplitterSize(kendoPaneId);
                });
            },

            //Default size of splitter sections
            defaultSplitterSize: {
                "splitter-oneSize": "250px",
                "splitter-twoSize": "250px",
                "splitter-threeSize": "250px",
            },

            //Get splitter size with previously persisted size or default
            getSplitterSize: function (id) {
                var tempPaneSize = null;

                try {
                    tempPaneSize = localStorage.getItem(id + '-' + athoc.iws.home.identifier + '-size');
                } catch (e) {
                    //try-catch to handle private mode of browser, when local storage is not uspported
                }

                if (tempPaneSize === null || tempPaneSize === "undefined") {
                    tempPaneSize = "250px";
                }

                return tempPaneSize;
            },

            //helper method to convert event data into UX friendly data
            processEventData: function (item) {
                var severities = ["High", "Severe", "Moderate", "Low", "Informational", "Unknown"],
                    title,
                    type,
                    sourceName,
                    hasGeo,
                    hasMedia;
                item.id = item.Id;
                title = item.Title.length > 20 ? item.Title.slice(0, 20) + "..." : item.Title;
                if (!item.SourceName) {
                    item.SourceName = "source name";
                }
                sourceName = item.SourceName.length > 15 ? item.SourceName.slice(0, 15) + "..." : item.SourceName;
                sourceName = $("<div id='escapeDiv'></div>").text(sourceName).html();

                if (!title) {
                    title = "This is an event";
                }
                title = $("<div id='escapeDiv'></div>").text(title).html();//escape html and script tags
                if (!item.Reviewed) {
                    title = "<span title='" + item.Title.replace(/'/g, '&apos;').replace(/"/g, '&quot;') + "' class='bold'>" + title + "</span>";
                } else {
                    title = "<span title='" + item.Title.replace(/'/g, '&apos;').replace(/"/g, '&quot;') + "'>" + title + "</span>";
                }
                //event type is event category name indeed
                var eventcategorytype = item.Type;
                type = item.EventCategoryName.length > 15 ? item.EventCategoryName.slice(0, 15) + "..." : item.EventCategoryName;
                type = $("<div id='escapeDiv'></div>").text(type).html();

               
                item.titleAndName = title + "<span title='" + item.SourceName + "' class='block k-secondary'><div class='icon16 event-mgr-sprite-" + item.SourceType.toLowerCase() + "'></div>" + sourceName + "</span>";
                item.timeAndCategory = "<span class='k-secondary' title='" + item.CreatedOn + "'>" + item.CreatedOn + "</span><span title='" + item.EventCategoryName + "' class='block k-secondary'>" + type + "</span>";
                if (item.Priority < 0) {
                    //if for any reason, the priority value is -1, then it should be considered as unknown. Need to talk to DBA why -1 would be here.
                    item.Priority = 5;
                }
                item.severity = severities[item.Priority]; //0 means high, 5 means unknown
                //item.typeIcon = "<img style='width:16px;height:16px;' src=" + item.TypeIcon + ">";
                item.typeIcon = item.TypeIcon;
                if (eventcategorytype === 'HubComm') {
                    item.severityIcon = "<div title='" + item.severity + "' class='icon32 event-mgr-sprite-invite-info'></div>";
                } else {
                    item.severityIcon = "<div title='" + item.severity + "' class='icon32 event-mgr-sprite-" + item.severity.toLowerCase() + "'></div>";
                }
                hasGeo = item.Latitude && item.Longitude;
                hasMedia = item.Medias.length > 0;
                item.extraData = "<div class='icon10-wrap'>";
                item.extraData += hasGeo ? "<div class='icon10 event-mgr-sprite-location'></div>" : "";
                item.extraData += hasMedia ? "<div class='icon10 event-mgr-sprite-attachment'></div>" : "";

                //if it's been responded, or expired, or came from other source than org
                var canReply = (item.Responded || item.IsExpired || item.SourceType !== "ORGANIZATION") ? false : true;

                var reply;
                if (canReply) {
                    reply = "reply";
                }
                if (item.Responded) {
                    reply = "replied";
                }

                item.extraData += "</div><div class='event-status event-" + reply + "'>" + reply + "</div>";
            },

            //show more less for header
            updateMoreLess: function () {
                $('.moretext').each(function () {
                    if ($(this).find(".morecontent").length == 0) {
                        var showChar = 300;
                        var ellipsestext = "...";
                        var moretext = athoc.iws.home.resources.Home_More_Link;
                        var content = $(this).html();

                        if (content.length > showChar) {

                            var c = content.substr(0, showChar);
                            var h = content.substr(showChar, content.length - showChar);

                            var html = c + '<span class="moreelipses">' + ellipsestext + '</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';

                            $(this).html(html);
                        }
                    }
                });

                $('.morelink').unbind('click');

                $(".morelink").click(function () {
                    var moretext = athoc.iws.home.resources.Home_More_Link;;
                    var lesstext = athoc.iws.home.resources.Home_Less_Link;
                    if ($(this).hasClass("less")) {
                        $(this).removeClass("less");
                        $(this).html(moretext);
                    } else {
                        $(this).addClass("less");
                        $(this).html(lesstext);
                    }
                    $(this).parent().prev().toggle();
                    $(this).prev().toggle();
                    return false;
                });
            }
        };
    }();
}