﻿
define([
    "common/baseView",
    "dojo/text!wam/WAMgrid/template.html",
    "wam/WAMgrid/Model",
    "rule/utils",
     "common/confirmationDialog"

], function (baseView, template, model, utils, confirmDialog) {
    var weatherGrid = function (refDomNode, urls, options) {
        var self = this;
        self.modelOptions = options;
        baseView.call(this, refDomNode, template, model, []);
        //Setting Model Level Properties data
        self.model.Name(this.modelOptions.Name);
        self.model.Counties(this.modelOptions.Counties);
        self.model.Action(this.modelOptions.Action);
        self.model.Enabled(this.modelOptions.Enabled);
        self.model.SelectAll(this.modelOptions.SelectAll);
        self.baseStartup = this.startup;
        self.url = urls;
        self.gridNode = refDomNode;
        self.localResources = utils.createGridOptions();
    };
    $.extend(weatherGrid.prototype, {

        gridNode: this.gridNode,
        rowTemplateId: "rowEvent",
        selectAllCheckboxClass: "grid-select-all",
        selectionCheckboxClass: "grid-item-select",
        columns: function () {
            var columns = new Array();
            columns.push({
                field: "Id",
                hidden: true
            });

            columns.push({
                width: 24,
                headerTemplate: kendo.format('<div align="center" style="padding-left:1px;"><input type="checkbox" class="grid-select-all" title="{0}"/></div>', this.modelOptions.SelectAll),
                sortable: false,
                headerAttributes: { "class": "no-pointer" }
            });

            columns.push({
                field: "Name",
                headerTemplate: this.modelOptions.Name,
                headerAttributes: { "class": "no-pointer", "title": this.modelOptions.Name },
                sortable: true,
                width: 160
            });

            columns.push({
                field: "WeatherCounty",
                headerTemplate: this.modelOptions.Counties,
                headerAttributes: { "class": "no-pointer", "title": this.modelOptions.Counties },
                sortable: true,
                width: 160
            });

            columns.push({
                field: "ScenarioName",
                headerTemplate: this.modelOptions.Action,
                headerAttributes: { "class": "no-pointer", "title": this.modelOptions.Action },
                sortable: true,
                width: 140
            });
            columns.push({
                field: "isEnable",
                headerTemplate: this.modelOptions.Enabled,
                sortable: true,
                headerAttributes: { "class": "no-pointer", "title": this.modelOptions.Enabled },
                width: 60
            });


            return columns;
        },
        schema: {
            data: "response",
            total:"TotalCount",
            model: {
                fields: {
                    Id: { type: "int" },
                    Name: { type: "string" },
                    WeatherCounty: { type: "string" },
                    ScenarioName: { type: "string" },
                    isEnable: { type: "string" }
                }
            }
        },

        sort: {
            field: "Name",
            dir: "asc"
        },

        processData: function (item) {
            item.NoData = athoc.iws.rule.resources.General_NoButton;
        },

        url: this.Urls,


        getClickClassHandlers: function () {
            var self = this;
            return [
                {
                    cssClass: "event-selectable",
                    handler: $.proxy(function (item) {
                        utils.loadRuleDetailPage(item.Id, item.Name, athoc.iws.rule.resources.WAMRule_TabWeather);
                    })

                },
                {
                    cssClass: "grid-select-all",
                    handler: $("#weather-list .grid-select-all").click(function () {
                        self.selectAll();
                    })
                },
                {
                    cssClass: "not-ready-text",
                    handler: $.proxy(function (item) {
                        utils.loadRuleDetailPage(item.Id, item.Name, athoc.iws.rule.resources.WAMRule_TabWeather);
                    })

                }
                

            ];
        },
        onLoadData: function (data) {
            return data;
        },

        // Paging/Sorting flags
        serverSideSort: false,
        serverSidePagination: false,

        //dataBound event handler
        onDataBound: function (e) {
            this.gridNode.data("kendoGrid");
            this.bindCheckboxChanged();
        },
        bindCheckboxChanged: function () {
            var grid = $('#weather-list').data().kendoGrid;
            var self = this;
            grid.tbody.on("change", ".grid-item-select", function (e) {
                var row = $(e.target).closest("tr");
                var item = grid.dataItem(row);
                item.IsChecked = $(e.target).is(":checked");
                self.getSelectedRules();
                self.onSelectionChanged(self.getSelectedRules().length);
            });
        },

        getSelectedRules: function () {
            var grid = $('#weather-list').data().kendoGrid;
            var items = grid.dataSource.view();

            // Get the selected items for the current page.
            var selected = $.grep(items, function (v) {
                return v.IsChecked;
            });
            return selected;
        },

        selectAll: function () {
            var grid = $('#weather-list').data().kendoGrid;
            var checked = $('.grid-select-all').is(':checked');
            $.each(grid.dataSource.view(), function (i, item) {
                item.IsChecked = checked;
            });
            this.getSelectedRules();
            this.onSelectionChanged(this.getSelectedRules().length);
        },
        deleteWeathers: function () {
            var selectedItems = this.getSelectedRules();
            var ids = [];
            selectedItems.forEach(function (selectedWeather) {
                ids.push(selectedWeather.Id);
            });
            var self = this;
            //To open delete confirmation dialog
            var confirmOptions = utils.createConfirmOption();            
            self.confirmationDialog = new confirmDialog(confirmOptions);
            self.confirmationDialog.showConfirmationMessage(
                                kendo.format(confirmOptions.title),
                                kendo.format(confirmOptions.body),
                                kendo.format("{0}", ""),

                                    function () {
                                        var successCallback = function () {
                                            self.confirmationDialog.hideConfirmationMessage();                                           
                                            self.refreshWAMGrid();
                                        };

                                        var failCallback = function () {
                                            self.confirmationDialog.hideConfirmationMessage();
                                            baseGridManager.showErrorMessage(kendo.format("{0} {1}", "Error message", "name"));
                                        };

                                        utils.deleteWeather(ids, successCallback, failCallback);
                                    }
                                );


        },
        refreshWAMGrid: function () {
        },
        onSelectionChanged: function (count) { } // overriding this event in alert.rules.manager.js file
        

    });


    return weatherGrid;
});
