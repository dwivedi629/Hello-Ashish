﻿define([
    "common/baseView",
    "rule/utils"
], function(BaseView,  utils) {

    //constructor
    /*
        options: {
            gridType: "" //seleccted grid type
        }
    */
    var gridDS = function(refDomNode, Urls, options) {

        BaseView.call(this, refDomNode);
        this.baseStartup = this.startup;
        this.url = Urls;
        this.gridNode = refDomNode;
        this.options = options;
        this.localResources = utils.createGridOptions();
    };

    $.extend(gridDS.prototype, {
        gridNode: this.gridNode,
        rowTemplateId: "rowCountiesEvent",
        selectAllCheckboxClass: "grid-select-all",
        selectionCheckboxClass: "grid-item-select",
        columns: function() {
            var columns = new Array();

            if (this.options.gridType == "all_counties_grid") {
                columns.push({
                    width: "55px",
                    headerTemplate: kendo.format('<div align="center"><input type="checkbox" class="grid-select-all" title="{0}"/></div>', this.localResources.selectAllText),
                    sortable: false,
                    headerAttributes: { "class": "no-pointer" }
                });
            }

            columns.push({
                field: "CountryName",
                headerTemplate: this.options.ColCounty,
                headerAttributes: { "class": "no-pointer", "title": this.options.ColCounty },
                width: (this.options.gridType == "selected_conditions_counties") ? "230px" : "209px"
            });

            columns.push({
                field: "StateName",
                headerTemplate: this.options.colState,
                headerAttributes: { "class": "no-pointer", "title": this.options.colState },
                width: (this.options.gridType == "selected_conditions_counties") ? "230px" : "209px"
            });


            columns.push({
                field: "GeoCode",
                headerTemplate: this.options.ColGeoCode,
                sortable: false,
                headerAttributes: { "class": "no-pointer", "title": this.options.ColGeoCode },
                hidden: (this.options.gridType == "selected_conditions_counties") ? true : false,
                width: (this.options.gridType == "selected_conditions_counties") ? "0px" : ((this.options.gridType == "all_counties_grid") ? "" : "209px")
            });


            if (this.options.gridType != "all_counties_grid") {
                columns.push({
                    sortable: false,
                    headerAttributes: { "class": "no-pointer"}
                });
            }


            return columns;
        },
        schema: {
            data: "Data",
            total: "TotalCount",
            model: {
                id: "GeoCode",
                fields: {
                    IsChecked: { type: "bool" },
                    CountryName: { type: "string" },
                    StateName: { type: "string" },
                    GeoCode: { type: "string" }
                }
            }
        },

        sort: {
            field: "CountryName",
            dir: "asc"
        },

        processData: function(item) {

        },

        url: this.Urls,
        //urlOptions: {
        //    NameString: "",
        //    Severity: "",
        //    Status: "",
        //    OperatorId: "",
        //    AttributeId: "",
        //    VpsId: 0,
        //    IncludeSubVps: false,
        //    StartDate: "",
        //    EndDate: "",
        //    DebugFlag: onLoadData 
        //},

        getClickClassHandlers: function() {
            var self = this;
            return [
                {
                    cssClass: "targeting-sprite",
                    handler: $.proxy(function(item) {
                    })
                }
            ];
        },
        onLoadData: function(data) {
            return data;
        },
        // events
        select: function(id) {},

        // Paging/Sorting flags
        serverSideSort: false,
        serverSidePagination: false,

        //dataBound event handler
        onDataBound: function(e) {
            //var id = "#" + this.gridNode;
            //var grid = this.gridNode.data("kendoGrid");
        },

        showAjaxLoader: function () {
            utils.showAjaxLoader();
        },
        hideAjaxLoader: function () {
            utils.hideAjaxLoader();
        },
        removeFixWidth: true
    });


    return gridDS;
});