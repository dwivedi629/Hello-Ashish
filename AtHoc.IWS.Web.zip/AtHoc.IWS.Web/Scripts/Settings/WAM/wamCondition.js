﻿define([
    "common/baseView",
    "wam/Condition/Model",
    "dojo/text!wam/Condition/template.html",
    "common/multiSelectDropdown",
     "rule/utils",
    "common/grid",
    "wam/grid.ds.counties",
    "common/dialog",
    "common/tabs",
    "common/advancedSearch/search",
    "common/advancedSearch/quickFilterSearch"
], function (BaseView, Model, template, multiSelectDropdown, utils, baseGrid, countiesGridData, dialogView, tabView, searchView, quickFilterSearch) {
    //var statesData = $.parseJSON(statesList);
    var statesData = null;

    var wamCondition = function (refDomNode, options) {
        //debugger;
        var self = this;
        this.modelOptions = options;
        this.URLs = options.Urls;
        BaseView.call(self, refDomNode, template, Model, []);
        this.resources = utils.resources;

        //Setting Model Level Properties data
        self.model.controlId(self.modelOptions.controlID);
        self.model.condition_Title_Resource_Text(self.modelOptions.titleText);
        self.model.condition_Description_Resource_Text(self.modelOptions.sectionWatermark);
        self.model.condition_Description_bottom_Resource(self.modelOptions.descWatermark);
        self.model.countiesLabelCaption(self.modelOptions.labelCaption1);
        self.model.severityLabelCaption(self.modelOptions.labelCaption2);
        self.model.countiesLinkCaption(self.modelOptions.linkLabelCaption);
        self.model.eventTypeLabelCaption(self.modelOptions.labelCaption3);
        self.model.keyWordLableCaption(self.modelOptions.labelCaption4);
        self.model.cssClass(self.modelOptions.cssClass);
        self.model.TabIndex(self.modelOptions.tabIndex);
        self.model.placeHolder(self.modelOptions.placeHolder);
        self.model.requiredCounties(self.modelOptions.required);
        self.model.countiesLinkModifyCaption(self.modelOptions.linkLabelModifyCaption);

        //IWS-32561
        self.model.messageTypeLabelCaption(self.modelOptions.labelMessageTypeCaption);

        self.baseStartup = self.startup;
        self.startup = function () {
            self.baseStartup.call(self);
            self.init();
        };
        self.model.onChange = function (isReady) {
            if (self.selectedCounties.length > 0)
                isReady = true;

            self.isDataChanged = isReady;
            self.onReadyChange(isReady);
        };
        self.controlById = [];

        self.tabs = {
            AllCounties: "AllCounties",
            CountySelected: "SelectedCounties"
        };

        self.gridType = {
            AllCounties: "all_counties_grid",
            CountySelected: "selected_counties_grid",
            ConditionCounties: "selected_conditions_counties"
        };

        self.tabsModel = [
            { id: self.tabs.AllCounties, Name: self.modelOptions.tabTextCounty },
            { id: self.tabs.CountySelected, Name: self.modelOptions.tabTextSelectCounty }
        ];
        self.selectedCounties = [];
        self.countiesSelected = [];
    };
    $.extend(wamCondition.prototype, {


        init: function () {
            var self = this;
            self.isDataChanged = false;
            self.model.onClick = function () {
                self.onClick();
            };

            //Severity DropDown
            var multiSeverityDropdownOptions = utils.createmultiSeverityDropdownOption();
            self.multiSeverityDropdown = new multiSelectDropdown(self.refDomNode.find("#conditionSeveritySpan"), multiSeverityDropdownOptions);
            self.multiSeverityDropdown.startup();
            self.multiSeverityDropdown.onChange = function () {
                self.isDataChanged = true;
            };

            //Event Type DropDown 
            var multiEventTypeDropdownOptions = utils.createmultiEventTypeDropdownOption();
            self.multiEventTypeDropdown = new multiSelectDropdown(self.refDomNode.find("#conditionEventTypeSpan"), multiEventTypeDropdownOptions);
            self.multiEventTypeDropdown.startup();
            self.multiEventTypeDropdown.onChange = function () {
                self.isDataChanged = true;
            };
            //IWS-32561
            //Message Type DropDown 
            var multiMessageTypeDropdownOptions = utils.createmultiMessageTypeDropdownOption();
            self.multiMessageTypeDropdown = new multiSelectDropdown(self.refDomNode.find("#conditionMessageTypeSpan"), multiMessageTypeDropdownOptions);
            self.multiMessageTypeDropdown.startup();
            self.multiMessageTypeDropdown.onChange = function () {
                self.isDataChanged = true;
            };

            //Get All States
            self.getAllStates();
        },
        getAllStates: function () {
            var self = this;
            var successFunction = function (statesList) {
                statesData = statesList;
                //Create County Grids
                self.createCountyGrids();
            }
            var onerror = function () {
                utils.hideAjaxLoader('.title-bar');
            };
            utils.getAllStates(successFunction, onerror);
        },
        fillSeverityDropDown: function (data) {
            var self = this;
            self.multiSeverityDropdown.bindDropdown(data);
        },
        getSelectedSeverity: function () {
            var self = this;
            return self.multiSeverityDropdown.getSelectedItem();
        },

        setSelectedSeverity: function (item) {
            var self = this;
            return self.multiSeverityDropdown.setSelectedItem(item);
        },

        fillEventTypeDropDown: function (data) {
            var self = this;
            self.multiEventTypeDropdown.bindDropdown(data);
        },
        getSelectedEventType: function () {
            var self = this;
            return self.multiEventTypeDropdown.getSelectedItem();
        },

        setSelectedEventType: function (item) {
            var self = this;
            return self.multiEventTypeDropdown.setSelectedItem(item);
        },
        //IWS-32561
        fillMessageTypeDropDown: function (data) {
            var self = this;
            self.multiMessageTypeDropdown.bindDropdown(data);
        },
        getSelectedMessageType: function () {
            var self = this;
            return self.multiMessageTypeDropdown.getSelectedItem();
        },

        setSelectedMessageType: function (item) {
            var self = this;
            return self.multiMessageTypeDropdown.setSelectedItem(item);
        },
        //
        setOtherFormsValue: function (data) {
            var self = this;
            self.model.conditionKeyWords(data != undefined ? data[0] : "");
        },
        getOtherFormsValue: function (data) {
            var self = this;
            return self.model.conditionKeyWords();
        },
        validateCounties: function (newValue) {
            var self = this;
            self.model.isCountiesValidate(true);
            self.model.isRuleEnabled(newValue == "Y" ? true : false);
            if (self.selectedCounties.length == 0 && newValue == "Y")
                return self.model.isCountiesValidate(false);
            else if (self.selectedCounties.length > 0 && newValue == "Y")
                return self.model.isCountiesValidate(true);
            else if (self.selectedCounties.length > 0 && newValue == "N") {
                return self.model.isCountiesValidate(false);
            }
        },

        getCounties: function () {
            var list = [];
            $.each(this.countiesSelected, function (i, item) {
                list.push(item.StateCode + "-" + item.CountryName + "-" + item.GeoCode);
            });
            return list;
        },

        setCounties: function (values) {

            var self = this;
            self.refDomNode.find("#conditionCountiesDiv #dvLink").removeClass("hide");

            self.countiesSelected = [];
            if(self.dialog!=undefined)
            self.dialog.navigationView.getAction("save").enable(false);

            if (values.length > 0 && values[0] != null) {
                var arrCountiesValue = values[0].split(',');
                $.each(arrCountiesValue, function (e, item) {
                    var data = item.split("-");
                    var stateName = "";
                    for (var i = 0; i < statesData.Data.length; i++) {

                        if (statesData.Data[i].value == data[0]) {
                            stateName = statesData.Data[i].text;
                            break;
                        }
                    }
                    self.countiesSelected.push({
                        StateCode: data[0],
                        CountryName: self.toTitleCase(data[1].toLowerCase()),
                        GeoCode: data[2],
                        StateName: stateName
                    });
                });
                self.selectedCounties = self.countiesSelected.slice();

                // Setting the caption on the grid
                self.UpdateGridSelectedCaption(self.countiesSelected);

                self.refreshGrid(self.conditionCountiesGrid, self.countiesSelected);
                self.refreshGrid(self.selectedCountiesGrid, self.selectedCounties);
                if (self.selectedCounties.length == 0) {
                    self.dialog.navigationView.getAction("save").enable(false);
                } else {
                    self.dialog.navigationView.getAction("save").enable(true);
                }
            }
        },

        toTitleCase: function (countryName) {
            return countryName.replace(/\w\S*/g, function (txt) { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); });
        },

        createCountyGrids: function () {
            var self = this;
           
            var navigationModel = {
                sections: [
                    {
                        dataPage: "detailPage",
                        actions: [
                            {
                                id: "save",
                                text: $.htmlDecode(self.resources.Action_Button_Apply),
                                primary: true,
                                click: function () {
                                    self.countiesSelected = self.selectedCounties.slice();

                                    // Setting the caption on the grid
                                    self.UpdateGridSelectedCaption(self.countiesSelected);

                                    self.refreshGrid(self.conditionCountiesGrid, self.countiesSelected);
                                    self.dialog.hideDialog();
                                },
                                enable: false
                            },
                            {
                                id: "cancel", text: $.htmlDecode(self.resources.Action_Button_Cancel), primary: false,
                                click: function () {
                                    $.each(self.countiesGrid.kendoGrid.dataSource.view(), function (i, item) {
                                        var isAvailable = false;
                                        for (var countyCount = 0; countyCount < self.countiesSelected.length; countyCount++) {
                                            if (item.GeoCode == self.countiesSelected[countyCount].GeoCode) {
                                                isAvailable = true;
                                            }
                                        }
                                        self.updateCountyCheckbox(item, isAvailable);
                                    });
                                    self.selectedCounties = self.countiesSelected.slice();
                                    // Setting the caption on the grid
                                    self.UpdateGridSelectedCaption(self.countiesSelected);

                                    self.countiesGrid.checkAndSelectAll();
                                    self.dialog.hideDialog();
                                    self.refreshGrid(self.selectedCountiesGrid, self.selectedCounties);
                                }
                            }
                        ]
                    }
                ]
            };



            var options = utils.createDialogOption();
            options.dlgClass = "width750";

            this.dialog = new dialogView(navigationModel, self.resources.WAMRule_Grid_SelectCounties_Headertext, "", "", options);
            this.dialog.startup();
            this.dialog.getBodyNode2().addClass('counties-modal-body');



            this.tabView = new tabView(this.dialog.getBodyNode(), this.tabsModel);
            this.tabView.startup();
            this.tabView.on("onShow", function (prevSelecededTabName, selectedTabName, params) {
                /*if (selectedTabName == self.tabNames.setting) {
                    var tab = self.controlById[selectedTabName];
                    tab.onVisible();
                }*/
            });
            this.tabView.on("onSelect", function (prevSelecededTabName, selectedTabName, params, filter) {

            });
            this.tabView.select(this.tabs.AllCounties);



            var searchContainer = $("<div>").addClass("table-crown-center searchContainer");
            var gridContainer = $("<div>").addClass("table-crown-center gridContainer");
            var mainContainer = $("<div>");

            var searchOption = utils.createAdvancedSearchOption();
            searchOption.isAdvancedFilter = false;
            searchOption.isQuickFilterEnabled = true;
            this.search = new searchView(searchContainer, searchOption);
            this.search.startup();
            this.search.refDomNode.find('.table-crown-caption').hide();
            this.search.model.pillsClassName("");

            var quickFilterOption = {
                filterPropertyName: "QuickFilterValue",
                //quickFilterTooltip: 'tooltip',

                quickFilterValues: [{ value: "", text: "All States", IsDefault: true }]
            };

            if (statesData.Data.length > 0) {
                quickFilterOption.quickFilterValues = statesData.Data;
                quickFilterOption.quickFilterValues.splice(0, 0, { value: "", text: self.modelOptions.labelAllState, IsDefault: true });
            }

            this.quickFilter = new quickFilterSearch(this.search.refDomNode.find('.quickFilter'), [quickFilterOption]);
            this.search.setQuickFilter(this.quickFilter);


            mainContainer.append(searchContainer);
            mainContainer.append(gridContainer);
            this.tabView.getTabContentElement(this.tabs.AllCounties).append(mainContainer);


            //Grid 1
            var countiesProvider = new countiesGridData(gridContainer, this.URLs.GetAllZipGeoCodeUrl,
            {
                gridType: this.gridType.AllCounties,
                colState: this.modelOptions.labelState,
                ColCounty: this.modelOptions.labelCounty,
                ColGeoCode: this.modelOptions.labelGeoCode
            });

            countiesProvider.processData = function (item) {
                item.IsChecked = false;
                for (var county = 0; county < self.selectedCounties.length; county++) {
                    if (item.GeoCode == self.selectedCounties[county].GeoCode) {
                        item.IsChecked = true;
                        break;
                    }
                }
            };

            countiesProvider.serverSideSort = true;
            countiesProvider.serverSidePagination = true;
            this.countiesGrid = new baseGrid(countiesProvider.gridNode, countiesProvider, false, true, false, true);
            this.countiesGrid.startup();
            this.search.on("onSearchChange", function () {
                self.countiesGrid.refreshGrid();
                self.countiesGrid.gridNode.find('.k-grid-content').css("height", "175px");
                self.search.refDomNode.find('.search-setting-panel').css("height", "250px");
                var countiesGridHeight = self.countiesGrid.gridNode.find('.k-grid-content').height();
                var searchStatesDpDownHeight = self.search.refDomNode.find('.search-setting-panel').height();
                var eventFilterHeight = self.search.refDomNode.find('.event-filter').height();
                var searchPillHeight = self.search.refDomNode.find('.pill-section').height();
                if (eventFilterHeight > 55) {
                    countiesGridHeight -= searchPillHeight;
                    searchStatesDpDownHeight -= searchPillHeight;
                }
                self.countiesGrid.gridNode.find('.k-grid-content').css("height", countiesGridHeight);
                self.search.refDomNode.find('.search-setting-panel').css("height", searchStatesDpDownHeight);
            });
            this.countiesGrid.on("updateOptions", function (filterOptions) {
                if (self.search != null) {
                    var filter = self.search.getFilters();
                    var opt = {
                        zipCode: filter.SearchStrings.toString(),
                        stateCode: filter.QuickFilterValue
                    };
                    $.extend(filterOptions, opt);
                }
            });

            //bind click event to the checkbox
            this.countiesGrid.selectAllCheckbox().on("click", function () {
                if (self.countiesGrid.selectAllCheckbox().is(':checked')) {
                    $.each(self.countiesGrid.kendoGrid.dataSource.view(), function (i, item) {
                        var isItemAvailable = false;
                        for (var county = 0; county < self.selectedCounties.length; county++) {
                            if (self.selectedCounties[county].GeoCode == item.GeoCode) {
                                isItemAvailable = true;
                                break;
                            }
                        }
                        if (!isItemAvailable) {
                            self.addCounty(item);
                        }
                    });
                } else {
                    $.each(self.countiesGrid.kendoGrid.dataSource.view(), function (i, item) {
                        self.removeCounty(item);
                    });
                }
                self.refreshGrid(self.selectedCountiesGrid, self.selectedCounties);
            });
            this.countiesGrid.kendoGrid.table.on("click", ".grid-item-select", function () {
                var checked = this.checked,
                row = $(this).closest("tr"),
                dataItem = self.countiesGrid.kendoGrid.dataItem(row);
                if (checked) {
                    self.addCounty(dataItem);
                } else {
                    self.removeCounty(dataItem);
                }
                self.refreshGrid(self.selectedCountiesGrid, self.selectedCounties);
            });



            //Grid 2
            var selectedCountiesProvider = new countiesGridData(this.tabView.getTabContentElement(this.tabs.CountySelected), "",
            {
                gridType: this.gridType.CountySelected,
                colState: this.modelOptions.labelState,
                ColCounty: this.modelOptions.labelCounty,
                ColGeoCode: this.modelOptions.labelGeoCode
            });
            selectedCountiesProvider.rowTemplateId = "rowSelectedCountiesEvent";
            selectedCountiesProvider.getClickClassHandlers = function () {
                var selfGrid = this;
                return [
                    {
                        cssClass: "targeting-sprite",
                        handler: $.proxy(function (item) {
                            self.removeCounty(item);
                            self.refreshGrid(self.selectedCountiesGrid, self.selectedCounties);
                            self.updateCountyCheckbox(item, false);
                            self.countiesGrid.checkAndSelectAll();
                        })
                    }
                ];
            };
            this.selectedCountiesGrid = new baseGrid(selectedCountiesProvider.gridNode, selectedCountiesProvider, false, true, true, true);
            this.selectedCountiesGrid.startup();
            this.refreshGrid(this.selectedCountiesGrid, this.selectedCounties);


            //Grid 3
            var conditionCountiesProvider = new countiesGridData("conditionCountiesGrid", "",
            {
                gridType: this.gridType.ConditionCounties,
                colState: this.modelOptions.labelState,
                ColCounty: this.modelOptions.labelCounty,
                ColGeoCode: this.modelOptions.labelGeoCode
            });
            conditionCountiesProvider.rowTemplateId = "rowConditionCountiesEvent";
            conditionCountiesProvider.getClickClassHandlers = function () {
                var selfGrid = this;
                return [
                    {
                        cssClass: "targeting-sprite",
                        handler: $.proxy(function (item) {
                            for (var county = 0; county < self.countiesSelected.length; county++) {
                                if (self.countiesSelected[county].GeoCode == item.GeoCode) {
                                    self.countiesSelected.splice(county, 1);
                                    break;
                                }
                            }
                            self.removeCounty(item);
                            self.refreshGrid(self.conditionCountiesGrid, self.countiesSelected);
                            self.refreshGrid(self.selectedCountiesGrid, self.selectedCounties);

                            self.updateCountyCheckbox(item, false);
                            self.countiesGrid.checkAndSelectAll();

                        })
                    }
                ];
            };
            this.conditionCountiesGrid = new baseGrid(conditionCountiesProvider.gridNode, conditionCountiesProvider,
                false, false, true, true);
            this.conditionCountiesGrid.startup();
            this.refreshGrid(this.conditionCountiesGrid, this.countiesSelected);
        },

        updateCountyCheckbox: function (item, flag) {

            var gridRow = this.countiesGrid.kendoGrid.tbody.find("tr[data-uid='" + item.GeoCode + "']");
            if (gridRow.length > 0) {
                var gridItem = this.countiesGrid.kendoGrid.dataItem(gridRow);
                gridItem.IsChecked = flag;
                var checkBox = gridRow.find("td > div > input");
                if (checkBox.length > 0)
                    checkBox[0].checked = flag;
            }
        },

        addCounty: function (dataItem) {
            this.selectedCounties.push({
                CountryName: dataItem.CountryName,
                GeoCode: dataItem.GeoCode,
                StateCode: dataItem.StateCode,
                StateName: dataItem.StateName,
                IsChecked: false
            });
            if (this.selectedCounties.length > 0) {
                this.dialog.navigationView.getAction("save").enable(true);
            }
        },
        removeCounty: function (item) {
            for (var county = 0; county < this.selectedCounties.length; county++) {
                if (this.selectedCounties[county].GeoCode == item.GeoCode) {
                    this.selectedCounties.splice(county, 1);
                    this.UpdateGridSelectedCaption(this.selectedCounties);
                    break;
                }
            }
            if (this.selectedCounties.length == 0) {
                this.dialog.navigationView.getAction("save").enable(false);
            }
        },

        // Setting the caption on the grid
        UpdateGridSelectedCaption:function(selectedCountiesItem)
        {
            var self = this;
            self.model.countiesSelectedCount(parseInt(selectedCountiesItem.length));
            if (parseInt(selectedCountiesItem.length) == 1) {
                self.model.countiesLinkSelectedCaption(self.modelOptions.linkLabelCountySelectdCaption.replace('{0}', parseInt(selectedCountiesItem.length)));
            }
            else
            {
                self.model.countiesLinkSelectedCaption(self.modelOptions.linkLabelCountiesSelectdCaption.replace('{0}', parseInt(selectedCountiesItem.length)));
            }
        },

        refreshGrid: function (grid, arrayData) {
            grid.setLocalDataSource({ Data: arrayData, TotalCount: arrayData.length });
            grid.refreshGrid();

            if (grid == this.conditionCountiesGrid) {
                if (arrayData.length == 0) {
                    this.conditionCountiesGrid.gridNode.hide();
                    var self = this
                    self.model.isCountiesValidate(self.model.isRuleEnabled() ? false : true);
                }
                else {
                    this.conditionCountiesGrid.gridNode.show();
                    var self = this;
                    self.model.isCountiesValidate(true);
                }
            }
            $(this.tabView.refDomNode.find("[name='" + this.tabs.CountySelected + "-tab'] > .k-link")).html(this.modelOptions.tabTextSelectCounty + "(" + this.selectedCounties.length + ")");
        },

        onClick: function () {
            this.dialog.showDialog();
        },
        onChange: function (isReady) { },
        onReadyChange: function (isReady) { }
    });

    return wamCondition;

});
