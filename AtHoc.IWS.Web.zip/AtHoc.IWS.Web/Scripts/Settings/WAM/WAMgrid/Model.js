﻿define([], function () {
    function Model() {
        var self = this;
        self.SelectAll = ko.observable();
        self.Name = ko.observable();
        self.Counties = ko.observable();
        self.Action = ko.observable();
        self.Enabled = ko.observable();
        self.no = ko.observable();
        self.onLoadData = function (data) { }; //onLoadData function which will be called from requestEnd method
    }

    return Model;
});