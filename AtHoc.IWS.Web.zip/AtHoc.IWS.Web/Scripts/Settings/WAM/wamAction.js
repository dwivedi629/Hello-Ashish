﻿define([
    "common/baseView",
    "wam/Action/Model",
    "dojo/text!wam/Action/template.html",
     "common/singleSelectDropdown",
     "rule/utils"
   
], function (BaseView, Model, template, singleSelectDropdown, utils) {
   var wamAction= function (refDomNode, options) {
        var self = this; 
        self.modelOptions = options;
        BaseView.call(self, refDomNode, template, Model, []);

       //Setting Model Level Properties data
        self.model.controlId(self.modelOptions.controlID);
        self.model.action_Title_Resource_Text(self.modelOptions.titleText);
        self.model.action_Description_Resource_Text(self.modelOptions.descText);
        self.model.cssClass(self.modelOptions.cssClass);
        self.model.TabIndex(self.modelOptions.tabIndex);
        self.model.labelCaption(self.modelOptions.labelCaption);
        self.model.GeoLabelCaption(self.modelOptions.GeoLabelCaption);
        self.model.GeoSubTitle(self.modelOptions.GeoSubTitle);
        self.model.GeoEnabledCaption(self.modelOptions.GeoEnabledCaption);
        self.baseStartup = self.startup;
        self.startup = function () {
            self.baseStartup.call(self);
            self.init();
        };
      
    };
   $.extend(wamAction.prototype, {

       
       init: function () {
           var self = this;
           self.isDataChanged = false;
           var actionDropDownOptions = utils.createActionDropDownTemplateOption();
           self.snglSelectDropdown = new singleSelectDropdown(self.refDomNode.find("#ruleScenarioSelectSpan"), actionDropDownOptions);
           self.snglSelectDropdown.startup();
           self.snglSelectDropdown.onChange = function () {
               self.model.isActionSectionReady(false);
               if (self.snglSelectDropdown.getSelectedItem() != undefined && self.snglSelectDropdown.getSelectedItem() != "" && self.snglSelectDropdown.getSelectedItem() != true) {
                   self.model.isActionSectionReady(true);
                   self.isDataChanged = true;
               }
               self.onTemplateChange();
           };
       },
       fillAlertTemplateDropDown: function (data) {
           var self = this;
           self.snglSelectDropdown.bindDropdown(data);
       },
       getSelectedScenarioID: function () {
           var self = this;
           return self.snglSelectDropdown.getSelectedItem();
       },

       setSelectedScenarioID: function (data) {
           var self = this;
           return self.snglSelectDropdown.setSelectedItem(data!=undefined?String(data.Scenario):"");
       },
       setGeoEnabled: function (data) {
           var self = this;
           return self.model.GeoEnabled(data != undefined ? (data.GeoEnabled == "Y" ? true : false) : false);
       },
       validateTemplate: function (newValue) {
           var self = this;
           if (newValue == "Y")
               self.snglSelectDropdown.model.SelectedItem(true);
           self.snglSelectDropdown.model.requiredMessage(self.modelOptions.requiredMessage);
           return self.snglSelectDropdown.model.isTemplateValidate(newValue == "Y" ? true : false);
       },
       onTemplateChange: function () { }
       
   });

   return wamAction;

});
   