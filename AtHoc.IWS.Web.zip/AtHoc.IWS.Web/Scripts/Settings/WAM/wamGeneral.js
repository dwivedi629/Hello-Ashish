﻿define([
    "common/baseView",
    "wam/General/Model",
    "dojo/text!wam/General/template.html",
     "rule/utils"
], function (BaseView, Model, template) {
    var wamGeneral = function (refDomNode, dataModel, options, utils) {
        var self = this;
        self.options = options;
        self.modelOptions = options;
        BaseView.call(self, refDomNode, template, Model, []);

        //Setting Model Level Properties data
        self.model.controlId(self.modelOptions.controlID);
        self.model.general_Title_Resource_Text(self.modelOptions.titleText);
        self.model.cssClass(self.modelOptions.cssClass);
        self.model.TabIndex(self.modelOptions.tabIndex);
        self.model.NameCaption(self.modelOptions.labelCaption1);
        self.model.EnabledCaption(self.modelOptions.labelCaption2);
        self.model.placeHolder(self.modelOptions.placeHolder1);
        self.model.LengthRequired(self.modelOptions.lenghtValidation);
        self.model.NameRequired(self.modelOptions.required1 );
        self.model.Name("");
        self.baseStartup = self.startup;
        self.startup = function () {
            self.baseStartup.call(self);
            self.init();
        };
        self.model.onChange = function (isReady) {
            self.isDataChanged = isReady;
            self.onReadyChange(isReady);
        };
        self.model.onEnabledChange = function (newValue) {
            self.isDataChanged = true;
            self.onEnabledChange(newValue);
        };
    };
    $.extend(wamGeneral.prototype, {

        init: function () {
            var self = this;
        },

        fillGeneralDetail: function (data) {
            var self = this;
            self.model.Name(data != undefined ? data.Name : "");
            self.model.EnabledYN(data != undefined ? data.isEnable =="Yes" ? "Y" : "N" : "");
            if (!data.isReady) // If template is not ready then rule should be disabled.
                self.model.EnabledYN("N");

        },
        getEnableDisableValue: function () {
            var self = this;
            return self.model.EnabledYN();
        },
        getScenarioName: function () {
            var self = this;
            return self.model.Name();
        },
        onReadyChange: function (isReady) { },
        onEnabledChange: function (newValue) { }
    });

    return wamGeneral;

});