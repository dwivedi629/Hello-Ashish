﻿define([], function () {
    function Model(i18n) {
        var self = this;
        self.general_Title_Resource_Text = ko.observable();
        self.cssClass = ko.observable();
        self.TabIndex = ko.observable();
        self.controlId = ko.observable("");
        self.EnabledYN = ko.observable("N");
        self.placeHolder = ko.observable();
        self.NameCaption = ko.observable();
        self.yes = ko.observable(i18n.General_YesButton);
        self.no = ko.observable(i18n.General_NoButton);
        self.EnabledCaption = ko.observable();
        self.Name = ko.observable();
        self.isGeneralValidate = ko.observable("N");
        self.NameRequired = ko.observable(i18n.WAMRule_General_Name_Validation_Message);
        self.LengthRequired = ko.observable(i18n.WAMRule_General_Name_Length_Valiadation_Message);
        self.isLengthValid = ko.observable(false);
        self.isGeneralSectionReady = ko.observable(false);
        var lengthValidation = function (str, minChar, maxChar) {
            if (str) {
                if (str.length < minChar[1] || str.length > minChar[2]) {
                    self.isLengthValid(false);
                    return false;
                }
            }
            self.isLengthValid(true);
            return true;
        };
        self.onInit = function () {
        };
        self.getMessage = function () {
            return self.NameRequired();
        };
        self.Name = ko.observable().extend({
            required: {
                params: true,
                message: self.NameRequired(),
                onlyIf: function () {
                    return self.isGeneralValidate() === "Y";
                }
            },
            validation: {
                validator: lengthValidation,
                message: self.LengthRequired(),
                params: [self.value, 3, 100]
            }
        });
        self.checkReadyOrNotReady = function () {
            if (self.Name.isValid())
                self.onChange(true);
            else
                self.onChange(false);
        };
        self.Name.subscribe(function (newValue) {
            self.isGeneralSectionReady(false);
            if ($.trim(newValue) != "" && self.isLengthValid())
                self.isGeneralSectionReady(true);
            self.onNameChanged(newValue);
            self.checkReadyOrNotReady();
        });
        self.EnabledYN.subscribe(function (newValue) {
            self.isGeneralValidate(newValue)
            self.onEnabledChange(newValue);
        });
        self.onNameChanged = function (newValue) {
        };
        self.onEnabledChange = function (newValue) {
        };
        self.onChange = function (isReady) {
        };

    }
    return Model;

});
