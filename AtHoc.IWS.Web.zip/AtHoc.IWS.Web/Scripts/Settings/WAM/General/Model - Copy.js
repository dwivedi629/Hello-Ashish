﻿define([], function () {
    function Model() {
        var self = this;
        self.general_Title_Resource_Text = ko.observable();
        self.cssClass = ko.observable();
        self.TabIndex = ko.observable();
        self.controlId = ko.observable("");
        self.EnabledYN = ko.observable("");
        self.placeHolder = ko.observable();
        self.NameCaption = ko.observable();
        self.EnabledCaption = ko.observable();
        //self.Name = ko.observable();
        self.isGeneralValidate = ko.observable(false);
        self.readyStatus = ko.observable();
        self.readyStatusTitle = ko.observable();
        self.NameRequired = ko.observable();
        self.LengthRequired = ko.observable();
        var lengthValidation = function (str, minChar, maxChar) {
            if (str) {
                if (str.length < minChar[1] || str.length > minChar[2]) {
                    return false;
                }
            }
            return true;
        };
        var nameMaxValueValidation = function (str, params) {
            if (str == "" || (parseInt(str) > params[0])) {
                return false;
            }
            return true;
        };

        var nameValueValidation = function (str, params) {
            if (str == "" || !(parseInt(str) > 0)) {
                return false;
            }
            return true;
        };
        self.onInit = function () {
        };
        ko.validation.rules['validateNameLength'] = {
            validator: nameMaxValueValidation,
            message: ''
        };
        ko.validation.rules['validateName'] = {
            validator: nameValueValidation,
            message: 'Madhu'
        };
        ko.validation.registerExtenders();

        //this.Name = ko.observable().extend({
        //    validateName: {
        //        message: self.NameRequired(),
        //        onlyIf: function () {
        //            return self.isGeneralValidate() === "Y";
        //        }
        //    },
        //    validateNameLength:
        //    {
        //        message: self.LengthRequired(),
        //        params: [100]
        //    }
        //});
        self.Name = ko.observable().extend({
            validateName: {
                params: true,
                onlyIf: function () {
                    return self.isGeneralValidate() === "Y";
                }
            },
            //validation: {
            //    validator: lengthValidation,
            //    message: self.LengthRequired,
            //    params: [self.value, 0, 100]
            //}
        });
        self.checkReadyOrNotReady = function () {
            if (self.Name.isValid()) {
                self.readyStatus('ready');
            }
            else {
                self.readyStatus('not-ready');
            }
            self.onChange(self.readyStatus() == 'ready' ? true : false);
        };
        self.Name.subscribe(function (newValue) {
            self.onNameChanged(newValue);
            self.checkReadyOrNotReady();
        });
        self.EnabledYN.subscribe(function (newValue) {
            self.onEnabledChange(newValue);
            self.isGeneralValidate(newValue)
        });
        self.onNameChanged = function (newValue) {
        };
        self.onEnabledChange = function (newValue) {
        };
        self.onChange = function (isReady) {
        };

    }
    return Model;

});
