﻿define([], function () {
    function Model() {
        var self = this;

        self.condition_Title_Resource_Text = ko.observable();

        self.condition_Description_Resource_Text = ko.observable();

        self.condition_Description_bottom_Resource = ko.observable();

        self.cssClass = ko.observable();

        self.TabIndex = ko.observable();

        self.countiesLabelCaption = ko.observable();

        self.countiesLinkModifyCaption = ko.observable();

        self.countiesLinkSelectedCaption = ko.observable();

        self.controlId = ko.observable();

        self.countiesLinkCaption = ko.observable();

        self.severityLabelCaption = ko.observable();

        self.eventTypeLabelCaption = ko.observable();

        self.keyWordLableCaption = ko.observable();

        self.conditionKeyWords = ko.observable();

        self.linkCountiesVisible = ko.observable(true);

        self.countiesSelectedCount = ko.observable(0);

        self.selectWidth = ko.observable();

        self.placeHolder = ko.observable();

        self.isRuleEnabled = ko.observable(false);

        self.isCountiesValidate = ko.observable(false);

        //IWS-32561
        self.messageTypeLabelCaption = ko.observable();

        self.isConditionSectionReady = ko.observable();

        self.isCountiesValidate.subscribe(function (newValue) {
            self.isConditionSectionReady(newValue);
            self.onChange(newValue);
        });
        self.requiredCounties = ko.observable();

        self.selectWidthStyle = ko.computed(function () {
            return "width:" + self.selectWidth() + "px";
        });

        self.showcountiesModel = function () {
            self.onClick();
        };

        self.onClick = function () {
        };

        self.onCheckChanged = function () {
            //alert("hi");
            //console.log(args);
        };
        self.onChange = function (isReady) {
        };
    }
    return Model;

});