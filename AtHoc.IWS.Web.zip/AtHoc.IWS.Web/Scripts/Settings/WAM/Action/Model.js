﻿define([], function () {
    function Model() {
        var self = this;

        self.controlId = ko.observable();

        self.action_Title_Resource_Text = ko.observable();

        self.action_Description_Resource_Text = ko.observable();

        self.labelCaption = ko.observable();

        self.cssClass = ko.observable();

        self.TabIndex = ko.observable();

        self.isActionSectionReady = ko.observable(false);

        self.GeoEnabled = ko.observable(false);

        self.GeoLabelCaption = ko.observable();

        self.GeoSubTitle= ko.observable();

        self.GeoEnabledCaption = ko.observable();

    }
    return Model;

});