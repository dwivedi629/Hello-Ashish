﻿
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.integrationmanager = athoc.iws.integrationmanager || {};

if (athoc.iws.integrationmanager) {

    athoc.iws.integrationmanager = function () {
        var AgentIds = new Array();
        var sortState;
        return {
            IsRightToLeft: false,
            IsRefered: false,
            searchMaxLength: 100,
            isChanged: false,
            IsEnterprises: false,
            IsSysAdmin: false,
            IsVirtualSysAdmin: false,
            ContextProvider: 0,
            SystemVPS: 3,
            defaultPageSize: 50,
            currentPaging: 1,
            editModel: {
                agentmanagermodel: ko.observable(),
                checkedtemplatecount: ko.observable(0),
                SearchDisabled: ko.observable(true),
                EditMode: ko.observable(false),
                IsNew: ko.observable(false),
                isSaveBtnClicked: ko.observable(false),
            },
            //popAgentIdNotToBeDeleted: [],
            ViewModel: { agentmanagermodel: ko.observable(), },
            AgentManagerCriteria: { SearchString: [], AgentIds: [] },
            ListModel: kendo.observable(
                {
                    TotalCount: 0,
                    SelectedCount: 0,
                }),

            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for scenario list, will be triggered before document load
            init: function () {
                athoc.iws.integrationmanager.initBreadcrumb();
                //init sorting for grid
                localStorage.setItem("sortInfo_a", JSON.stringify({ colName: "agentName", order: "asc" }));
                navigateToPage('listAgentManager', function () { });
            },

            //load method, will be tirggered on document load
            load: function () {
                // bind Breadcrumb            
                athoc.iws.integrationmanager.bindBreadcrumb();
                //bind control events
                athoc.iws.integrationmanager.bindControlEvents();

                var sortInfo = JSON.parse(localStorage.getItem("sortInfo_a"));
                if (sortInfo == undefined || sortInfo == "")
                    localStorage.setItem("sortInfo_a", JSON.stringify({ colName: "agentName", order: "asc" }));

                athoc.iws.integrationmanager.createagentmanagerListGrid();
                kendo.bind($(".kendoBound"), this.ListModel);
                //Fix the grid header
                var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
                if (gridHeader) {
                    gridHeader.addClass('table-header affix');
                }
                //filterContent
                athoc.iws.integrationmanager.listLoad();
                // Getsearch data w.r.t Search option 
                var inputElm = $("#txtSearch");
                // Set max length property for Search option 
                inputElm.maxLength({
                    maxLength: athoc.iws.integrationmanager.searchMaxLength,
                    onMaxReached: function () {
                        $('#saveMessagePanel').modal("show");
                    }
                });
                // Execute search options when press search button
                inputElm.keyup(function (e) {
                    athoc.iws.integrationmanager.editModel.SearchDisabled(false);
                    if ($.hotkeys.enter(e)) {
                        athoc.iws.integrationmanager.search();
                    }
                });
                inputElm.blur(function (e) {
                    if (inputElm.val().trim() == '')
                        athoc.iws.integrationmanager.editModel.SearchDisabled(true);
                    else
                        athoc.iws.integrationmanager.editModel.SearchDisabled(false);
                });

                $("#AgentManagerList .k-pager-numbers").click(function () {
                    localStorage.setItem("cancelClicked_a", false);
                    localStorage.setItem("cPage_a", 1);
                });

            },

            bindControlEvents: function () {
                // Bind all events to the controls
                $("#btn-search").click(function () {
                    athoc.iws.integrationmanager.search();
                });
                $("#btn_new").click(function () { athoc.iws.integrationmanager.CreateAgentDetails(); });
                $("#btn_delete").click(function () {
                    athoc.iws.integrationmanager.showdeleteConfirmation();
                });

                $("#btnDeleteCancel").click(function () { $("#dialogAgentDeleteConfirm").modal('hide'); });
                $("#btnDeleteConfirm").click(function () {
                    athoc.iws.integrationmanager.deleteAgentManagerDetails();
                });
                $("#btn_clear").click(function () { athoc.iws.integrationmanager.clearFilters(); });
                $("#btn_save").click(function () {
                    return athoc.iws.integrationmanager.saveAgentdata();

                });
                $("#btn_ecancel").click(function () { return athoc.iws.integrationmanager.cancelEditAgentdata(); }
                    );
                $("#btn_vcancel").click(function () {
                    localStorage.setItem("cancelClicked_a", true);
                    athoc.iws.integrationmanager.IsRefered = false;
                    navigateToPage('listAgentManager', function () { });
                    var breadcrumbsModel = athoc.iws.integrationmanager.breadcrumbModel;
                    breadcrumbsModel.SelectedPage('listAgentManager');
                    $.titleCrumb("pageBreadcrumbs");
                    $(document).scrollTop(0);
                    athoc.iws.integrationmanager.resetSearchCriteria();
                    athoc.iws.integrationmanager.refreshGrid();
                    athoc.iws.integrationmanager.listLoad();
                    athoc.iws.integrationmanager.clearFilters();
                });
                $("#okButton").click(function () {

                    if (athoc.iws.integrationmanager.validateXML($("#txtDialogConfigURL").val())) {
                        athoc.iws.integrationmanager.editModel.agentmanagermodel.metastore($("#txtDialogConfigURL").val());
                        $('#dsaveMessagePanel').html('');
                        $('#dialogConfigURL').modal('hide');
                        $('#dsaveMessagePanel').hide();
                    }
                    else {

                        $('#dsaveMessagePanel').html('');
                        $('#dsaveMessagePanel').css({ display: 'block' });
                        var reqError = new Array();
                        reqError.push({ Type: '4', Value: "Invalid XML Format." });//Not in used now
                        $('#dsaveMessagePanel').messagesPanel({ messages: reqError });
                    }
                });
                $("#btn_ConfigURL").click(function () {
                    $('#dsaveMessagePanel').html('');
                    $("#dialogConfigURL").show();
                });
            },

            listLoad: function () {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
            },

            //build grid
            createagentmanagerListGrid: function () {
                var self = this;
                var url = athoc.iws.integrationmanager.urls.GetAgentsUrl;
                var sortInfo = JSON.parse(localStorage.getItem("sortInfo_a"));
                var jsonData = JSON.stringify(athoc.iws.integrationmanager.AgentManagerCriteria);
                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            data: JSON.stringify(jsonData),
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.integrationmanager.AgentManagerCriteria);
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                    },
                    requestEnd: function (e) {

                        if (e.response) {
                            athoc.iws.integrationmanager.ListModel.set("TotalCount", e.response.TotalCount);
                            //clear selected
                            athoc.iws.integrationmanager.ListModel.set("SelectedCount", 0);

                            athoc.iws.integrationmanager.IsEnterprises = e.response.IsEnterprises;
                            athoc.iws.integrationmanager.IsSysAdmin = e.response.IsSysAdmin;
                            athoc.iws.integrationmanager.IsVirtualSysAdmin = e.response.IsVirtualSysAdmin;

                            athoc.iws.integrationmanager.ContextProvider = e.response.ContextProvider;


                            $('#chkAgentSelectAll').attr("checked", false);
                            $.AjaxLoader.hideLoader();
                        }

                        var isClicked = localStorage.getItem("cancelClicked_a");
                        var getCPSize = localStorage.getItem("pageSize_a");
                        var getCPPage = localStorage.getItem("cPage_a");
                        if (getCPSize == undefined) {
                            localStorage.setItem("pageSize_a", datasource.pageSize());
                            localStorage.setItem("cPage_a", datasource.page());
                            athoc.iws.integrationmanager.defaultPageSize = datasource.pageSize();
                            athoc.iws.integrationmanager.currentPaging = datasource.page();
                        }
                        else if (getCPSize != undefined && ((getCPSize != datasource.pageSize()) || (getCPPage != datasource.page()))) {

                            if (isClicked == "true") {
                                localStorage.setItem("pageSize_a", getCPSize);
                                localStorage.setItem("cPage_a", getCPPage);
                                athoc.iws.integrationmanager.defaultPageSize = getCPSize;
                                athoc.iws.integrationmanager.currentPaging = getCPPage;

                            } else {
                                localStorage.setItem("pageSize_a", datasource.pageSize());
                                localStorage.setItem("cPage_a", datasource.page());
                                athoc.iws.integrationmanager.defaultPageSize = datasource.pageSize();
                                athoc.iws.integrationmanager.currentPaging = datasource.page();
                            }
                        }
                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                    },
                    sort: { field: sortInfo.colName, dir: sortInfo.order },
                    pageSize: 50,


                    error: function (e) {
                        $.AjaxLoader.hideLoader();
                        athoc.iws.integrationmanager.handleError(e);
                    },
                    change: function (e) {
                        athoc.iws.integrationmanager.enableSelectAll();
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            //when sort changes, go to first page.
                            this.page(1);
                        }
                        //scrolling to the top when paging and sorting.
                        $("html,body").scrollTop(0);
                    }

                });

                $("#pageInfo").kendoPager({
                    dataSource: datasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.integrationmanager.resources.Settings_AgentManager_DisplayFolder,
                        empty: athoc.iws.integrationmanager.resources.IWS_Common_NoRecordsFound,
                    }
                });

                //grid columns
                var grid = $("#AgentManagerList").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    top: 130,
                    selectable: false,
                    sortable: {
                        allowUnsort: false
                    },


                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5, messages: {

                            display: athoc.iws.integrationmanager.resources.IWS_Common_NoRecordsFound,
                            itemsPerPage: athoc.iws.integrationmanager.resources.AtHoc_Pager_Message_Items_Per_Page,
                            empty: athoc.iws.integrationmanager.resources.IWS_Common_NoRecordsFound,

                            first: $.htmlDecode(athoc.iws.integrationmanager.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.integrationmanager.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.integrationmanager.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.integrationmanager.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                {

                                    field: "IsChecked",
                                    template: $("#agentmanager-chkDelete-template").html(),
                                    width: 20,
                                    title: "",
                                    headerTemplate: kendo.format('<input type="checkbox" class="senario-select" id="chkAgentSelectAll" title="{0}" onclick="athoc.iws.integrationmanager.agentSelectAll();" />', athoc.iws.integrationmanager.resources.Settings_AgentManager_Select_Current_Page),
                                    sortable: false,
                                    headerAttributes: {
                                        style: "cursor: default;",
                                    }
                                },
                                 {
                                     field: "agentName",
                                     title: "",
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}">{1}</span>', athoc.iws.integrationmanager.resources.Settings_AgentManager_GridColumnTitle_Prefix + ' ' + athoc.iws.integrationmanager.resources.AtHoc_Common_Name, athoc.iws.integrationmanager.resources.AtHoc_Common_Name),
                                     width: 350,
                                     headerAttributes: {
                                         tabindex: "240"
                                     }
                                 },
                                 {
                                     field: "agentowner",
                                     title: "",
                                     template: '<span  title="#=agentowner#">#=agentowner#</span>',
                                     headerTemplate: kendo.format('<span title="{0}">{1}</span>', athoc.iws.integrationmanager.resources.Settings_AgentManager_GridColumnTitle_Prefix + ' ' + athoc.iws.integrationmanager.resources.Settings_AgentManager_Type, athoc.iws.integrationmanager.resources.Settings_AgentManager_Type),
                                     width: 100,
                                     headerAttributes: {
                                         tabindex: "240"
                                     }
                                 },
                                  {
                                      field: "agentUpdatedOn",
                                      width: 100,
                                      format: $.vpsDateTimeFormat,
                                      type: "date",
                                      headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.integrationmanager.resources.Settings_AgentManager_GridColumnTitle_Prefix + ' ' + athoc.iws.integrationmanager.resources.Settings_AgentManager_UpdatedOn, athoc.iws.integrationmanager.resources.Settings_AgentManager_UpdatedOn),
                                      template: "#= kendo.toString(kendo.parseDate(agentUpdatedOn, 'yyyy-MM-dd hh:mm tt'), $.vpsDateTimeFormat) #",
                                  },



                            ],
                    dataBound: athoc.iws.integrationmanager.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());



                    }
                }).data().kendoGrid;


                var $template = kendo.template($("#agentmanager-tooltip-template").html());
                tooltip = $("#AgentManagerList").kendoTooltip({
                    filter: "td:nth-child(2)", //this filter selects the first column cells                   
                    content: function (e) {
                        var dataItem = $("#AgentManagerList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    }
                }).data("kendoTooltip");


                $("#AgentManagerList").kendoTooltip({
                    filter: ".cellTooltip",
                });


                ko.applyBindings(athoc.iws.integrationmanager.editModel, $("#dvAgentSearch").get(0));

                this.refreshGrid();

            },

            refreshGrid: function () {
                //show the loader when we make a request to the server..
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.wrap-all'), imageURL: athoc.iws.integrationmanager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: this.resources.General_LoadingMessage }).showLoader();
                //Per telerik, this will set the page only after datasource refreshes.
                datasource.one("change", function () {
                    //pagination needs to be reset after a reload
                    this.pageSize(athoc.iws.integrationmanager.defaultPageSize);
                    this.page(athoc.iws.integrationmanager.currentPaging);
                });
                datasource.read();


            },

            //show model pou-up 
            showModalPopup: function (IdOfdiv) {

                $('#' + IdOfdiv).modal().promise().done(function () {
                    setTimeout(function () {
                        if ($("#txtAgentName").is(":visible"))
                            $("#txtAgentName").focus();
                    }, 1000);
                });

            },

            //close model pop-up
            closeModalPopup: function (IdOfdiv) {
                $('#' + IdOfdiv).modal('hide');
                $('#' + IdOfdiv).hide();
                $(".modal-backdrop").each(function () {
                    $(this).remove();
                })
            },
            errors: null,

            //Method to handle erro and session time out, this is boud with Ajax calls
            handleError: function (e) {

                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else if (e.errorThrown != "") {
                    if (athoc.iws.integrationmanager.errors === null) {
                        athoc.iws.integrationmanager.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.integrationmanager.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#saveMessagePanel').messagesPanel({ messages: this.errors });
                }
            },

            //On Grid databound navigate to Edit page or View page w.r.t device Type
            OnDataBound: function () {

                $("#AgentManagerList tbody").find("tr").attr("tabindex", "0");
                var grid = $("#AgentManagerList").data("kendoGrid");
                var data = grid.dataSource.data();

                $(grid.tbody).on("click", "td", function (e) {
                    var isFirstRowCheck = $(this).closest("td").find('#chkAgentId');
                    if (isFirstRowCheck.length == 0) {
                        var row = $(this).closest("tr");
                        var rowIdx = $("tr", grid.tbody).index(row);
                        var colIdx = $("td", row).index(this);

                        if (athoc.iws.integrationmanager.IsRefered == false && colIdx >= 0) {

                            if ((colIdx == 0 && e.target.className == "") || colIdx > 0) {
                                data = grid.dataSource.view();
                                var model = data[rowIdx];
                                //verify model
                                if (model) {
                                    athoc.iws.integrationmanager.IsRefered = true;
                                    tooltip.hide();
                                    if ((athoc.iws.integrationmanager.ContextProvider == model.providerId) && ((athoc.iws.integrationmanager.IsSysAdmin || athoc.iws.integrationmanager.IsEnterprises || athoc.iws.integrationmanager.IsVirtualSysAdmin || model.IsOwner)))
                                        athoc.iws.integrationmanager.editAgentManagerDetail(model, true);
                                    else
                                        athoc.iws.integrationmanager.editAgentManagerDetail(model, false);
                                }

                            }
                        }
                    }
                });

                //On Grid row key press navigate to Edit page or View page w.r.t device Type
                $(grid.tbody).on("keypress", "tr", function (e) {

                    var code = e.keyCode || e.which;

                    if (code == 13 && athoc.iws.integrationmanager.IsRefered == false) {
                        athoc.iws.integrationmanager.IsRefered = true;
                        var row = $(this);
                        var rowIdx = $("tr", grid.tbody).index(row);
                        data = grid.dataSource.data();
                        var model = data[rowIdx];
                        tooltip.hide();
                    }
                });

                grid.tbody.on("change", ".agentmanager-select", function (e) {
                    var row = $(e.target).closest("tr");
                    var item = grid.dataItem(row);
                    item.IsChecked = $(e.target).is(":checked");
                    athoc.iws.integrationmanager.enableSelectAll();
                    athoc.iws.integrationmanager.updateSelectedTotal();
                });

                if (athoc.iws.integrationmanager.IsRightToLeft) {
                    $("#AgentManagerList").find('.pull-right').addClass('pull-left');
                    $("#AgentManagerList").find('.pull-right').removeClass('pull-right');
                }

                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(grid.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px;cursor:text;">' + athoc.iws.integrationmanager.resources.IWS_Common_NoRecordsFound + '</td></tr>');
                }
            },

            getSelectedItems: function () {
                AgentIds = new Array();
                var grid = $("#AgentManagerList").data("kendoGrid");

                $.each(grid.dataSource.view(), function (i, item) {

                    if (item.IsChecked)
                        AgentIds.push(item);
                });

            },

            agentSelectAll: function (obj) {

                var checked = $('#chkAgentSelectAll').is(':checked');
                var grid = $('#AgentManagerList').data().kendoGrid;
                if (!checked)
                    AgentIds = new Array();

                $.each(grid.dataSource.view(), function (i, item) {
                    item.IsChecked = checked;
                });
                athoc.iws.integrationmanager.enableSelectAll();
                $('#AgentManagerList').data().kendoGrid.refresh();
                athoc.iws.integrationmanager.updateSelectedTotal();

            },

            showdeleteConfirmation: function () {
                var items = datasource.data();
                var selectedIds = new Array();
                var selectedNames = new Array();
                var selectedStandardCnt = 0;
                var nameTags = "";
                $("#privateFiles").hide();
                $("#globalFiles").hide();
                $("#itemsToDelete").hide();
                $("#itemsToDelete").html('');
                $("#btnDeleteConfirm").attr("disabled", true);
                $.grep(items, function (v) {

                    if (v.IsChecked) {


                        if (athoc.iws.integrationmanager.ContextProvider == v.providerId) {
                            if ((athoc.iws.integrationmanager.IsSysAdmin || athoc.iws.integrationmanager.IsEnterprises || athoc.iws.integrationmanager.IsVirtualSysAdmin || v.IsOwner)) {
                                selectedIds.push(v.agentId);
                                selectedNames.push(v.agentName);
                            }
                            else
                                selectedStandardCnt++;
                        }
                        else
                            selectedStandardCnt++;
                    }
                });

                if (selectedIds.length > 0) {
                    $("#privateFiles").show();
                    $("#itemsToDelete").show();
                    $("#btnDeleteConfirm").removeAttr("disabled");
                    $("#privateFiles").text(athoc.iws.integrationmanager.resources.Settings_AgentManager_agentDeleted.format(selectedIds.length));
                    if (selectedStandardCnt > 0) {
                        $("#privateFiles").text(athoc.iws.integrationmanager.resources.Settings_AgentManager_agentDeleted.format(selectedIds.length) + ', ' + athoc.iws.integrationmanager.resources.Settings_AgentManager_DeleteSystem.format(selectedStandardCnt));

                    }
                    selectedNames.sort();
                    for (var i = 0; i < selectedNames.length; i++) {
                        nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(selectedNames[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(selectedNames[i]) + "</div>";
                    }
                    $("#itemsToDelete").html("<div class='mar-top10'>" + nameTags + "</div>");
                }
                else if (selectedStandardCnt > 0) {
                    selectedNames.sort();
                    for (var i = 0; i < selectedNames.length; i++) {
                        nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(selectedNames[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(selectedNames[i]) + "</div>";
                    }
                    $("#itemsToDelete").html("<div class='mar-top10'>" + nameTags + "</div>");
                    $("#itemsToDelete").show();
                    $("#globalFiles").show();
                    $("#globalFiles").text(athoc.iws.integrationmanager.resources.Settings_AgentManager_DeleteSystem.format(selectedStandardCnt), selectedStandardCnt);
                }

                $('#dialogAgentDeleteConfirm').modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        $("#btnDeleteCancel").attr("tabindex", 15).focus();
                    }, 1000);
                });
            },


            // to update selected totals
            updateSelectedTotal: function () {
                var items = datasource.data();
                var r = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                athoc.iws.integrationmanager.editModel.checkedtemplatecount(r.length);

                if (r.length > 0) {
                    $("#btn_delete").removeAttr('disabled');
                }
                else {
                    $("#btn_delete").attr('disabled', 'disabled');
                }
            },

            enableSelectAll: function () {
                var items = datasource.view();
                //get the selected items for the current page.
                var r = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                $("#chkAgentSelectAll").prop('checked', false);
                if (r.length > 0 && (items.length == r.length))
                    $("#chkAgentSelectAll").prop('checked', true);
            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.integrationmanager.breadcrumbModel;
                var isModified = athoc.iws.integrationmanager.isChanged;


                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.integrationmanager.resources.Action_Button_Settings, '', function () {
                    window.location.href = "/client/setup/settings";
                });

                var AgentManagerLink = new Breadcrumb('AgentManagerLink', athoc.iws.integrationmanager.resources.Settings_AgentManager_Agents, '', function () {
                    if (isModified) {
                        var confirmLeave = confirm(athoc.iws.integrationmanager.resources.Settings_AgentManager_pageLeaveConfirm);
                        if (confirmLeave == true) {
                            athoc.iws.integrationmanager.isChanged = false;
                            athoc.iws.integrationmanager.viewAgentList();
                        }
                    }
                    else {
                        athoc.iws.integrationmanager.viewAgentList();
                    }

                });
                //Page breadcrumb
                var listPageBreadcrumb = new PageBreadcrumb('listAgentManager', athoc.iws.integrationmanager.resources.Settings_AgentManager_Agents, [settingLink], '');
                //To View Delivery template data
                var viewPageBreadcrumb = new PageBreadcrumb('viewAgentManager', '', [settingLink, AgentManagerLink], '');
                //To Edit Delivery template data
                var editPageBreadcrumb = new PageBreadcrumb('editAgentManager', '', [settingLink, AgentManagerLink], '');

                breadcrumbsModel.addPage(listPageBreadcrumb);
                breadcrumbsModel.addPage(viewPageBreadcrumb);
                breadcrumbsModel.addPage(editPageBreadcrumb);
            },

            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.integrationmanager.breadcrumbModel;
                breadcrumbsModel.SelectedPage('listAgentManager');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');

                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            // Triggered, when clear all link is clicked, it clear the searchCriteria and reload the grid
            clearFilters: function () {
                $("#txtSearch").val("");
                $("#dvAgentSearch .pill-container").html('');
                $("#dvAgentSearch").find("#pillContainer").hide();
                $("#AgentManagerList .k-grid-header").css("margin-top", "0px");
                $("#AgentManagerList").css("margin-top", "0px");
                $(".table-crown-center").css("height", "50px");
                athoc.iws.integrationmanager.AgentManagerCriteria.SearchString = [];
                athoc.iws.integrationmanager.editModel.checkedtemplatecount(0);
                athoc.iws.integrationmanager.refreshGrid();
                athoc.iws.integrationmanager.listLoad();
                $("#btn_delete").attr('disabled', 'true');
                athoc.iws.integrationmanager.editModel.SearchDisabled(true);
                $("#AgentManagerList .k-grid-header").css("z-index", "10");
            },
            // Triggered, when search button or hit enter in search textbox
            search: function () {
                if ($("#txtSearch").length <= athoc.iws.integrationmanager.searchMaxLength) {
                    if ($("#txtSearch").val() != "")
                        athoc.iws.integrationmanager.createPills($("#txtSearch").val());
                }
                else
                    $('#saveMessagePanel').modal("show");
                $("#txtSearch").focus();
            },

            // todisplay the template settings in edit mode
            editAgentManagerDetail: function (model, editMode) {
                $('#divEditAgentManager').show();
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.integrationmanager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                $('#saveMessagePanel').html('');
                $('#errorMessagePanel').html('');
                $("#btn_agnsave").addClass('hide');
                var dataPost = { AgentId: model.agentId };
                var dlAjaxOption =
                    {
                        url: athoc.iws.integrationmanager.urls.GetAgentManagerDetailsUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(dataPost),
                        success: function (data) {
                            if (data.Success) {

                                localStorage.setItem("sortInfo_a", JSON.stringify({ colName: datasource.sort()[0].field, order: datasource.sort()[0].dir }));

                                athoc.iws.integrationmanager.IsRefered = false;
                                athoc.iws.integrationmanager.editModel.agentmanagermodel = ko.mapping.fromJS(data.Data, athoc.iws.integrationmanager.getValidation());
                                athoc.iws.integrationmanager.editModel.EditMode(editMode);
                                athoc.iws.integrationmanager.editModel.IsNew(false);

                                ko.cleanNode($("#editAgentManager").get(0));
                                ko.applyBindings(athoc.iws.integrationmanager.editModel, $("#editAgentManager").get(0));
                                ko.cleanNode($("#editActionButton").get(0));
                                ko.applyBindings(athoc.iws.integrationmanager.editModel, $("#editActionButton").get(0));
                                mode = 1;

                                //set popup max and min heights
                                if (athoc.iws.integrationmanager.editModel.IsNew()) {
                                    $("#editAgentManagerModal .modal-body").css('max-height', '174px');
                                    $("#editAgentManagerModal .modal-body").css('min-height', '174px');
                                }
                                else {
                                    $("#editAgentManagerModal .modal-body").css('max-height', '283px');
                                    $("#editAgentManagerModal .modal-body").css('min-height', '283px');
                                }

                                athoc.iws.integrationmanager.showModalPopup('editAgentManagerModal');
                                if (editMode)
                                    $("#btn_agnsave").removeClass('hide');
                                athoc.iws.integrationmanager.editSubscribeMethods();

                            }
                            else {

                                if (data.HasErrors) {
                                    $('#errorMessagePanel').messagesPanel({ messages: data.Messages });
                                    if (data.ReturnType == 1) {
                                        $("html,body").scrollTop(0);
                                    }
                                }
                            }
                            athoc.iws.integrationmanager.IsRefered = false;
                            $.AjaxLoader.hideLoader();
                            $("html,body").scrollTop(0);
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.integrationmanager.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
                return true;
            },

            //To New Agent data 
            CreateAgentDetails: function () {
                $('#divEditAgentManager').show();
                $("#btn_agnsave").removeClass('hide');
                $('#saveMessagePanel').html('');
                $('#errorMessagePanel').html('');

                var dataPost = { AgentId: 0 };
                var dlAjaxOption =
                    {
                        url: athoc.iws.integrationmanager.urls.GetAgentManagerDetailsUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(dataPost),
                        success: function (data) {
                            if (data.Success) {
                                athoc.iws.integrationmanager.IsRefered = false;
                                athoc.iws.integrationmanager.editModel.agentmanagermodel = ko.mapping.fromJS(data.Data, athoc.iws.integrationmanager.getValidation());
                                athoc.iws.integrationmanager.editModel.EditMode(false);
                                athoc.iws.integrationmanager.editModel.IsNew(true);
                                ko.cleanNode($("#editAgentManager").get(0));
                                ko.applyBindings(athoc.iws.integrationmanager.editModel, $("#editAgentManager").get(0));
                                ko.cleanNode($("#editActionButton").get(0));
                                ko.applyBindings(athoc.iws.integrationmanager.editModel, $("#editActionButton").get(0));

                                athoc.iws.integrationmanager.editSubscribeMethods();
                            }
                            else {
                                if (data.HasErrors) {
                                    $('#errorMessagePanel').messagesPanel({ messages: data.Messages });
                                    if (data.ReturnType == 1) {
                                        $("html,body").scrollTop(0);
                                    }
                                }
                            }
                            athoc.iws.integrationmanager.IsRefered = false;
                            $.AjaxLoader.hideLoader();

                            //set popup max and min heights
                            if (athoc.iws.integrationmanager.editModel.IsNew()) {
                                $("#editAgentManagerModal .modal-body").css('max-height', '174px');
                                $("#editAgentManagerModal .modal-body").css('min-height', '174px');
                            }
                            else {
                                $("#editAgentManagerModal .modal-body").css('max-height', '283px');
                                $("#editAgentManagerModal .modal-body").css('min-height', '283px');
                            }
                            athoc.iws.integrationmanager.showModalPopup('editAgentManagerModal');
                            $("html,body").scrollTop(0);
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.integrationmanager.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
                return true;

            },

            //to fill Agent Managers List
            viewAgentList: function () {

                athoc.iws.integrationmanager.IsRefered = false;
                $(document).scrollTop(0);
                athoc.iws.integrationmanager.resetSearchCriteria();
                athoc.iws.integrationmanager.refreshGrid();
                athoc.iws.integrationmanager.listLoad();
                mode = 0;
                athoc.iws.integrationmanager.updateTitle();

            },

            // Triggered, When deleteing the Agent Manager record
            deleteAgentManagerDetails: function () {
                $('#saveMessagePanel').html('');
                AgentIds.length = 0;
                // Get selected Agent Manager  records
                var items = datasource.data();

                var selectedIds = new Array();
                // Keep selected  Agent Manager  records in array ie. validated
                $.grep(items, function (v) {
                    if (v.IsChecked) {
                        if (athoc.iws.integrationmanager.ContextProvider == v.providerId) {
                            if ((athoc.iws.integrationmanager.IsSysAdmin || athoc.iws.integrationmanager.IsEnterprises || athoc.iws.integrationmanager.IsVirtualSysAdmin || v.IsOwner)) {
                                AgentIds.push(v);
                                selectedIds.push(v.agentId);
                            }
                        }
                    }
                });
                athoc.iws.integrationmanager.AgentManagerCriteria.AgentIds = selectedIds;

                var jsonData = JSON.stringify(athoc.iws.integrationmanager.AgentManagerCriteria);
                var dlAjaxOption =
                    {
                        url: athoc.iws.integrationmanager.urls.DeleteAgentManagerUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            $("#dialogAgentDeleteConfirm").modal('hide');
                            athoc.iws.integrationmanager.isChanged = false;
                            athoc.iws.integrationmanager.editModel.checkedtemplatecount(0);
                            athoc.iws.integrationmanager.refreshGrid();
                            athoc.iws.integrationmanager.listLoad();
                            athoc.iws.integrationmanager.clearFilters();
                            $("#btn_delete").attr('disabled', 'true');
                        },
                        error: function (e) {
                            $("#dialogAgentDeleteConfirm").modal('hide');
                            athoc.iws.integrationmanager.handleError(e);
                        }

                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);

                $.ajax(ajaxOptions);

                return true;
            },

            //cancel Save event
            cancelEditAgentdata: function () {
                athoc.iws.integrationmanager.editModel.isSaveBtnClicked(false);
                if (athoc.iws.integrationmanager.editModel.IsNew())
                    athoc.iws.integrationmanager.isChanged = false;
                localStorage.setItem("cancelClicked_a", true);
                var isModified = athoc.iws.integrationmanager.isChanged;
                if (isModified == true) {
                    var confirmLeave = confirm(athoc.iws.integrationmanager.resources.Unsaved_Data_Text);
                    if (confirmLeave == true) {
                        athoc.iws.integrationmanager.isChanged = false;
                    }
                    else
                        return false;
                }
                athoc.iws.integrationmanager.closeModalPopup('editAgentManagerModal');
                return false;
            },

            // saves Agent data in the database
            saveAgentdata: function () {
                athoc.iws.integrationmanager.editModel.isSaveBtnClicked(true);
                $('#errorMessagePanel').html('');
                var result = ko.validation.group(athoc.iws.integrationmanager.editModel.agentmanagermodel, { deep: true });
                if (result().length > 0) {
                    athoc.iws.integrationmanager.editModel.agentmanagermodel.errors.showAllMessages();
                    return false;
                }

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.integrationmanager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();

                athoc.iws.integrationmanager.IsRefered = false;
                athoc.iws.integrationmanager.editModel.agentmanagermodel.agentcommonName(athoc.iws.integrationmanager.editModel.agentmanagermodel.agentName().trim());
                var jsonData = ko.toJSON(athoc.iws.integrationmanager.editModel.agentmanagermodel);

                var dlAjaxOption =
                    {
                        url: athoc.iws.integrationmanager.urls.SaveAgentDetailsUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {

                            if (data.Success) {
                                if (athoc.iws.integrationmanager.editModel.agentmanagermodel.agentId() == 0) {
                                    localStorage.setItem("cancelClicked_a", false);
                                    localStorage.setItem("pageSize_a", 50);
                                    localStorage.setItem("cPage_a", 1);
                                    localStorage.setItem("sortInfo_a", JSON.stringify({ colName: "agentName", order: "asc" }));
                                    athoc.iws.integrationmanager.defaultPageSize = 50;
                                    athoc.iws.integrationmanager.currentPaging = 1;
                                    datasource.pageSize(50);
                                    datasource.page(1);
                                }
                                else {
                                    localStorage.setItem("cancelClicked_a", true);
                                }

                                athoc.iws.integrationmanager.closeModalPopup('editAgentManagerModal');
                                athoc.iws.integrationmanager.isChanged = false;
                                $.titleCrumb("pageBreadcrumbs");
                                $.AjaxLoader.hideLoader();
                                athoc.iws.integrationmanager.resetSearchCriteria();
                                athoc.iws.integrationmanager.refreshGrid();
                                athoc.iws.integrationmanager.clearFilters();
                                athoc.iws.integrationmanager.listLoad();

                            }
                            else if (data.HasErrors) {
                                $.AjaxLoader.hideLoader();
                                $('#errorMessagePanel').messagesPanel({ messages: data.Messages });
                                if (data.ReturnType == 1) {
                                    $("#txtCommonName").focus();
                                    $("html,body").scrollTop(0);
                                }
                            }
                            else {
                                $.AjaxLoader.hideLoader();
                                $('#errorMessagePanel').messagesPanel({ messages: data.Messages || data.Error });
                            }

                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.integrationmanager.handleError(e);
                        }
                    };


                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
                return false;
            },

            //subscribers
            editSubscribeMethods: function () {

                athoc.iws.integrationmanager.editModel.agentmanagermodel.agentName.subscribe(function (newValue) {
                    athoc.iws.integrationmanager.editModel.isSaveBtnClicked(false);
                    if ($.trim(newValue) != "") {
                        athoc.iws.integrationmanager.isChanged = true;
                        if (athoc.iws.integrationmanager.editModel.agentmanagermodel.agentcommonName() == null || athoc.iws.integrationmanager.editModel.agentmanagermodel.agentcommonName() == "") {
                            athoc.iws.integrationmanager.editModel.agentmanagermodel.agentcommonName(athoc.iws.integrationmanager.editModel.agentmanagermodel.agentName().trim().replace(/\s/g, '-'));
                        }
                    }
                });

                athoc.iws.integrationmanager.editModel.agentmanagermodel.agentcommonName.subscribe(function (newValue) {
                    athoc.iws.integrationmanager.editModel.isSaveBtnClicked(false);
                    if ($.trim(newValue) != "") {
                        athoc.iws.integrationmanager.isChanged = true;
                        if (athoc.iws.integrationmanager.editModel.agentmanagermodel.agentcommonName() == "") {
                            athoc.iws.integrationmanager.editModel.agentmanagermodel.agentcommonName(athoc.iws.integrationmanager.editModel.agentmanagermodel.agentName().trim().replace(/\s/g, '-'));
                        }
                    }
                });
                athoc.iws.integrationmanager.editModel.agentmanagermodel.configURL.subscribe(function (newValue) {
                    athoc.iws.integrationmanager.editModel.isSaveBtnClicked(false);
                    if ($.trim(newValue) != "")
                        athoc.iws.integrationmanager.isChanged = true;
                });
                athoc.iws.integrationmanager.editModel.agentmanagermodel.statusURL.subscribe(function (newValue) {
                    athoc.iws.integrationmanager.editModel.isSaveBtnClicked(false);
                    if ($.trim(newValue) != "")
                        athoc.iws.integrationmanager.isChanged = true;
                });
                athoc.iws.integrationmanager.editModel.agentmanagermodel.removechannelpreferencesURL.subscribe(function (newValue) {
                    athoc.iws.integrationmanager.editModel.isSaveBtnClicked(false);
                    if ($.trim(newValue) != "")
                        athoc.iws.integrationmanager.isChanged = true;
                });
                athoc.iws.integrationmanager.editModel.agentmanagermodel.addUrl.subscribe(function (newValue) {
                    athoc.iws.integrationmanager.editModel.isSaveBtnClicked(false);
                    if ($.trim(newValue) != "")
                        athoc.iws.integrationmanager.isChanged = true;
                });
                athoc.iws.integrationmanager.editModel.agentmanagermodel.updateUrl.subscribe(function (newValue) {
                    athoc.iws.integrationmanager.editModel.isSaveBtnClicked(false);
                    if ($.trim(newValue) != "")
                        athoc.iws.integrationmanager.isChanged = true;
                });
                athoc.iws.integrationmanager.editModel.agentmanagermodel.deleteURL.subscribe(function (newValue) {
                    athoc.iws.integrationmanager.editModel.isSaveBtnClicked(false);
                    if ($.trim(newValue) != "")
                        athoc.iws.integrationmanager.isChanged = true;
                });
            },
            updateTitle: function () {

                switch (mode) {
                    case 1:
                        athoc.iws.integrationmanager.breadcrumbModel.updateTitle(athoc.iws.integrationmanager.editModel.agentmanagermodel.agentName(), undefined, undefined, 'editAgentManager');
                        break
                    case 2:
                        athoc.iws.integrationmanager.breadcrumbModel.updateTitle(athoc.iws.integrationmanager.editModel.agentmanagermodel.agentName(), undefined, undefined, 'viewAgentManager');
                        break;

                    default:
                        athoc.iws.integrationmanager.breadcrumbModel.updateTitle("", undefined, undefined, 'editAgentManager');
                        athoc.iws.integrationmanager.breadcrumbModel.updateTitle("", undefined, undefined, 'viewAgentManager');
                        break;
                }
            },

            resetSearchCriteria: function () {
                athoc.iws.integrationmanager.AgentManagerCriteria.SearchString = [];
                athoc.iws.integrationmanager.editModel.checkedtemplatecount(0);
            },

            //to open configuration URL
            showConfigURLContent: function (value) {

                var url = athoc.iws.integrationmanager.editModel.agentmanagermodel.configURL();
                if (url == null || url == undefined || url.trim() == '')
                    return false;
                url = url.trim();
                if (url != "") {
                    url = (window.location.origin ? window.location.origin : window.location.protocol + '//' + window.location.hostname) + url;

                    var queryStringParam = "ProviderID=" + athoc.iws.integrationmanager.editModel.agentmanagermodel.providerId() + "&AgentID=" + athoc.iws.integrationmanager.editModel.agentmanagermodel.agentId() + "";

                    if (url.indexOf("?") > -1) {
                        url = url + '&' + queryStringParam;
                    }
                    else {
                        url = url + '?' + queryStringParam;
                    }
                    window.open(url, "ConfigurationURL", "height=400,width=600,resizable=no,status=no,toolbar=no,menubar=no,location=no,maximize=no");


                }
                return false;
            },
            //to open status URL
            openStatusURL: function () {
                /* var url = athoc.iws.integrationmanager.editModel.agentmanagermodel.statusURL();
                if (url == null || url == undefined || url.trim() == '')
                    return false;
                url = url.trim();
                if (url != "") {
                    if ((!url.toLowerCase().startsWith("http")) && (url.toLowerCase().startsWith("www"))) {
                            url = "http://" + url;
                        }             
                    window.open(url, "StatusURL", "height=400,width=600,resizable=no,status=no,toolbar=no,menubar=no,location=no");
                }  */
                var url = athoc.iws.integrationmanager.editModel.agentmanagermodel.statusURL();
                if (url == null || url == undefined || url.trim() == '')
                    return false;
                url = url.trim();
                if (url != "") {
                    url = (window.location.origin ? window.location.origin : window.location.protocol + '//' + window.location.hostname) + url;

                    var queryStringParam = "ProviderID=" + athoc.iws.integrationmanager.editModel.agentmanagermodel.providerId() + "&AgentID=" + athoc.iws.integrationmanager.editModel.agentmanagermodel.agentId() + "";

                    if (url.indexOf("?") > -1) {
                        url = url + '&' + queryStringParam;
                    }
                    else {
                        url = url + '?' + queryStringParam;
                    }
                    window.open(url, "StatusURL", "height=400,width=600,resizable=no,status=no,toolbar=no,menubar=no,location=no,maximize=no");
                }
                return false;
            },

            validateXML: function (val) {
                var status = false;
                if (val != null) {

                    try {
                        var xmlDoc = $.parseXML(val);
                        if (xmlDoc != null)
                            status = true;
                        else
                            status = false;
                    } catch (exception)
                    { status = false; }
                }
                return status;
            },

            //validations
            getValidation: function () {
                //remove old validation warnings
                $(".warning").each(function () {
                    $(this).parent().remove();
                });


                var validationMapping = {
                    agentName: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {
                                    onlyIf: athoc.iws.integrationmanager.editModel.isSaveBtnClicked,
                                    params: true,
                                    message: athoc.iws.integrationmanager.resources.Settings_AgentManager_NameReq
                                },
                                minLength: {
                                    onlyIf: athoc.iws.integrationmanager.editModel.isSaveBtnClicked,
                                    params: 3,
                                    message: athoc.iws.integrationmanager.resources.Settings_AgentManager_Namelimit
                                },
                                maxLength: {
                                    onlyIf: athoc.iws.integrationmanager.editModel.isSaveBtnClicked,
                                    params: 100,
                                    message: athoc.iws.integrationmanager.resources.Settings_AgentManager_100Length
                                },
                                pattern: {
                                    onlyIf: athoc.iws.integrationmanager.editModel.isSaveBtnClicked,
                                    message: athoc.iws.integrationmanager.resources.Settings_AgentManager_notAllowedInName + ' \\ / : * ? ` ; " < > | [ ]',
                                    params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$"
                                }, 
                            });
                        }
                    },

                };

                return validationMapping;
            },
             
            // Createing pills when search is done
            createPills: function (value) {
                var found = _.find(athoc.iws.integrationmanager.AgentManagerCriteria.SearchString, function (item) {
                    return (item == value);
                });
                if (!found) {
                    athoc.iws.integrationmanager.AgentManagerCriteria.SearchString.push(value);
                    $("#txtSearch").val($.trim($("#txtSearch").val()));
                    athoc.iws.integrationmanager.editModel.checkedtemplatecount(0);
                    athoc.iws.integrationmanager.refreshGrid();
                    athoc.iws.integrationmanager.listLoad();
                    athoc.iws.integrationmanager.renderPills();
                    $("#txtSearch").val("");
                    $("#btn-search").attr('disabled', 'true');
                    $("#btn_delete").attr('disabled', 'true');
                    $("#dvAgentSearch").find("#pillContainer").show();

                }
            },

            // Rendering the pills when search is done
            renderPills: function (css) {
                var self = this;
                var html = "";
                if ($("#dvAgentSearch .pill-container").html() == '') {
                    $(".table-crown-center").css("height", ($(".table-crown-center").height() + $("#dvAgentSearch .pill-container").height() + 9) + "px");
                    localStorage.setItem("maxPillContainer", "false");
                }

                $("#dvAgentSearch .pill-container").html('');
                if (athoc.iws.integrationmanager.AgentManagerCriteria.SearchString && athoc.iws.integrationmanager.AgentManagerCriteria.SearchString.length > 0) {
                    _.each(athoc.iws.integrationmanager.AgentManagerCriteria.SearchString, function (item, index) {
                        var iconCss = "";
                        var prefix = "";
                        var pillLabel = prefix + $.htmlEncode(item);
                        var pillTooltip = prefix + $.htmlEncode(item);
                        var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" href="#"></a>' : '');
                        html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                    });

                    var pillsElm = $("#dvAgentSearch .pill-container");
                    pillsElm.html(html);



                    $("#dvAgentSearch .whiteout").removeAttr("style");
                    if (($("#dvAgentSearch .pill-container").height() > 30) && (localStorage.getItem("maxPillContainer") == "false")) {

                        $("#dvAgentSearch .whiteout").attr("style", "height:" + ($("#dvAgentSearch .whiteout").height() + $("#dvAgentSearch .pill-container").height() + 15) + "px");

                        localStorage.setItem("maxPillContainer", "true");
                        $(".table-crown-center").css("height", ($(".table-crown-center").height() + 30) + "px");
                        $("#AgentManagerList .k-grid-header").css("margin-top", $("#dvAgentSearch .pill-container").height() + 15);

                        $("#AgentManagerList").css("margin-top", $("#dvAgentSearch .pill-container").height() + 15);
                    }

                    if (localStorage.getItem("maxPillContainer") == "false") {
                        $("#dvAgentSearch .whiteout").attr("style", "height:" + ($("#dvAgentSearch .whiteout").height() + $("#dvAgentSearch .pill-container").height()) + "px");

                        $("#AgentManagerList .k-grid-header").css("margin-top", $("#dvAgentSearch .pill-container").height());

                        $("#AgentManagerList").css("margin-top", $("#dvAgentSearch .pill-container").height());
                    }


                    if (html != "") {
                        $(".push").attr("style", 'margin-bottom:0px');
                    };
                    //wire up events
                    $("#dvAgentSearch .pill-close").click(function (event) {
                        var parentElm = $(this).parent(".pill");
                        athoc.iws.integrationmanager.deSelect(parentElm.data("index"));
                        event.stopPropagation();
                    });
                }
            },

            // Deleteing the pills
            deSelect: function (index, onSuccess) {
                if (athoc.iws.integrationmanager.AgentManagerCriteria.SearchString && athoc.iws.integrationmanager.AgentManagerCriteria.SearchString.length > index) {
                    athoc.iws.integrationmanager.AgentManagerCriteria.SearchString.splice(index, 1);
                    athoc.iws.integrationmanager.refreshGrid();
                    athoc.iws.integrationmanager.listLoad();
                    athoc.iws.integrationmanager.renderPills();
                }

                if (athoc.iws.integrationmanager.AgentManagerCriteria.SearchString && athoc.iws.integrationmanager.AgentManagerCriteria.SearchString.length == 0) {
                    $("#dvAgentSearch").find("#pillContainer").hide();
                    $("#AgentManagerList .k-grid-header").css("margin-top", "0px");
                    $("#AgentManagerList").css("margin-top", "0px");
                    $(".table-crown-center").css("height", "50px");
                    $(".push").removeAttr("style");
                    $("#dvAgentSearch .whiteout").removeAttr("style");
                }
            },

        };
    }();
}
