﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.subaccountmanager = athoc.iws.subaccountmanager || {};

if (athoc.iws.subaccountmanager) {


    athoc.iws.subaccountmanager = function () {
        return {

            IsRightToLeft: false,
            providerId:0,
            editModel: {
                subaccountmanagermodel: ko.observable()
            },
            ViewModel: kendo.observable(
                {
                    TotalCount: 0,
                    SelectedCount: 0,
                }),

            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for scenario list, will be triggered before document load
            init: function () {
                athoc.iws.subaccountmanager.initBreadcrumb();
                navigateToPage('viewSubAccountManager', function () { });
            },

            //load method, will be tirggered on document load
            load: function () {
                athoc.iws.subaccountmanager.bindBreadcrumb();
               
                $("#btn_new").click(function () { athoc.iws.subaccountmanager.createSubAccountManager(); });
                $("#btn_duplicate").click(function () { athoc.iws.subaccountmanager.duplicateSubAccountManager(); });
                $("#btn_save").click(function () { athoc.iws.subaccountmanager.editSubAccountManager(); });
                $("#btn_nsave").click(function () { athoc.iws.subaccountmanager.saveSubAccountManager(); });
                $("#btn_cancel").click(function ()
                {
                    navigateToPage('viewSubAccountManager', function () { });
                    var breadcrumbsModel = athoc.iws.subaccountmanager.breadcrumbModel;
                    breadcrumbsModel.SelectedPage('viewSubAccountManager');
                    $.titleCrumb("pageBreadcrumbs");
                    $(document).scrollTop(0);
                    athoc.iws.subaccountmanager.refreshGrid();
                    athoc.iws.subaccountmanager.listLoad();
                });
                $("#btn_ncancel").click(function () {
                    navigateToPage('viewSubAccountManager', function () { });
                    var breadcrumbsModel = athoc.iws.subaccountmanager.breadcrumbModel;
                    breadcrumbsModel.SelectedPage('viewSubAccountManager');
                    $.titleCrumb("pageBreadcrumbs");
                    $(document).scrollTop(0);
                    athoc.iws.subaccountmanager.refreshGrid();
                    athoc.iws.subaccountmanager.listLoad();
                });

                athoc.iws.subaccountmanager.createSubaccountmanagerListGrid();
                athoc.iws.subaccountmanager.listLoad();
            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {
        
                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.subaccountmanager.breadcrumbModel;

                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', "Settings", '', function () {
                    window.location.href = "settings";
                });

                var subaccountmanagerLink = new Breadcrumb('systemsLink', "Sub Account Manager", '', function () {

                    navigateToPage('viewSubAccountManager', function () { });
                    athoc.iws.subaccountmanager.breadcrumbModel.SelectedPage('viewSubAccountManager');
                    $.titleCrumb("pageBreadcrumbs");
             
                });


                //Page breadcrumb
                var viewPageBreadcrumb = new PageBreadcrumb('viewSubAccountManager', 'Sub Account Manager', [settingLink], '');
                var editPageBreadcrumb = new PageBreadcrumb('editSubAccountManager', 'Edit', [settingLink, subaccountmanagerLink], '');
                var newPageBreadcrumb = new PageBreadcrumb('newSubAccountManager', 'New', [settingLink, subaccountmanagerLink], '');

                breadcrumbsModel.addPage(viewPageBreadcrumb);
                breadcrumbsModel.addPage(editPageBreadcrumb);
                breadcrumbsModel.addPage(newPageBreadcrumb);

            },

            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.subaccountmanager.breadcrumbModel;
                breadcrumbsModel.SelectedPage('viewSubAccountManager');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            createSubAccountManager: function () {
                navigateToPage('newSubAccountManager', function () { });
                var breadcrumbsModel = athoc.iws.subaccountmanager.breadcrumbModel;
                breadcrumbsModel.SelectedPage('newSubAccountManager');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);



            },
            editSubAccountManager: function () {
             
           
                 $('#saveMessagePanel').html('');
                 $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.subaccountmanager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%' }).showLoader();
                 var jsonData = ko.toJSON(athoc.iws.subaccountmanager.editModel.subaccountmanagermodel);
                 var dlAjaxOption =
                     {
                         url: athoc.iws.subaccountmanager.urls.SaveSubAccountManagersUrl,
                         contentType: "application/json; charset=utf-8",
                         dataType: 'json',
                         type: 'POST',
                         data: jsonData,
                         success: function (data) {
                             if (data.Success)
                             {
                                 navigateToPage('viewSubAccountManager', function () { });
                                 athoc.iws.subaccountmanager.breadcrumbModel.SelectedPage('viewSubAccountManager');
                                 $.titleCrumb("pageBreadcrumbs");
                                 athoc.iws.subaccountmanager.refreshGrid();
                                 athoc.iws.subaccountmanager.listLoad();
                             } else {
                                 $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                             }

                             $.AjaxLoader.hideLoader();
                         }
                     };

                 var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                 $.ajax(ajaxOptions);

                 return true;
           
            },
           saveSubAccountManager: function () {

               var providername = $('#txtVirtualSystem').val();
               var dataPost = {
                                   Providername: providername
                               };
                $('#saveMessagePanel').html('');
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.subaccountmanager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%' }).showLoader();
                var jsonData = ko.toJSON(athoc.iws.subaccountmanager.editModel.subaccountmanagermodel);

               
                var dlAjaxOption =
                    {
                        url: athoc.iws.subaccountmanager.urls.CreateSubAccountManagersUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(dataPost),
                        success: function (data) {
                            if (data.Success) {
                                navigateToPage('viewSubAccountManager', function () { });
                                athoc.iws.subaccountmanager.breadcrumbModel.SelectedPage('viewSubAccountManager');
                                $.titleCrumb("pageBreadcrumbs");
                                $.AjaxLoader.hideLoader();
                                athoc.iws.subaccountmanager.refreshGrid();
                                athoc.iws.subaccountmanager.listLoad();
                            } else {
                                $.AjaxLoader.hideLoader();
                                $('#saveMessagePanel').css("display:none");
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }

                           
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;

           },

           getProvider:function(obj)
           {
               athoc.iws.subaccountmanager.providerId = obj;
           },
            duplicateSubAccountManager: function () {
                if (athoc.iws.subaccountmanager.providerId > 0) {
                   
                    $('#saveMessagePanel').html('');
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.subaccountmanager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%' }).showLoader();
                    var jsonData = ko.toJSON(athoc.iws.subaccountmanager.editModel.subaccountmanagermodel);


                    var dlAjaxOption =
                        {
                            url: athoc.iws.subaccountmanager.urls.CreateDuplicateSubAccountManagersUrl,
                            contentType: "application/json; charset=utf-8",
                            dataType: 'json',
                            type: 'POST',
                            data: JSON.stringify(dataPost),
                            success: function (data) {
                                if (data.Success) {
                                    navigateToPage('viewSubAccountManager', function () { });
                                    athoc.iws.subaccountmanager.breadcrumbModel.SelectedPage('viewSubAccountManager');
                                    $.titleCrumb("pageBreadcrumbs");
                                    $.AjaxLoader.hideLoader();
                                    athoc.iws.subaccountmanager.refreshGrid();
                                    athoc.iws.subaccountmanager.listLoad();
                                } else {
                                    $.AjaxLoader.hideLoader();
                                    $('#saveMessagePanel').css("display:none");
                                    $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                                }


                            }
                        };

                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                    $.ajax(ajaxOptions);

                    return true;
                }
            },
            listLoad: function () {
                kendo.bind($(".kendoBound"), this.ViewModel);
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
            },
            createSubaccountmanagerListGrid: function () {

                var self = this;
                var url = athoc.iws.subaccountmanager.urls.GetSubAccountManagerUrl;
                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.subaccountmanager.ViewModel);
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                    },
                    requestEnd: function (e) {

                        if (e.response) {
                            athoc.iws.subaccountmanager.ViewModel.set("TotalCount", e.response.TotalCount);
                            //clear selected
                            athoc.iws.subaccountmanager.ViewModel.set("SelectedCount", 0);

                            $.AjaxLoader.hideLoader();
                        }
                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                    },
                    sort: { field: "Name", dir: "asc" },
                    pageSize:20,
                    error: function (e) {
                        $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] });

                    },

                });

                $("#pageInfo").kendoPager({
                    dataSource: datasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.subaccountmanager.resources.SubAccountManager_List_PageInfo,
                    }
                    //refresh: true,
                    //width: 300,
                });
             
                var grid = $("#subaccountmanagerList").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    height: 450,
                    top:120,
                    //resizable: true,
                    sortable: true,
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5
                    },
                    columns:
                            [
                                {
                                    template: $("#subaccountmanager-radio-template").html(),
                                    width: 40,
                                    title: "",
                                    sortable: false
                                },
                                 {
                                     field: "ProviderId",
                                     title: athoc.iws.subaccountmanager.resources.SubAccountManager_ID,
                                     width: 50
                                 },
                                {
                                    field: "ProviderName",
                                    title: athoc.iws.subaccountmanager.resources.SubAccountManager_VirtualSystem,
                                    width: 250
                                },
                                {
                                    field: "ProvideType",
                                    title: athoc.iws.subaccountmanager.resources.SubAccountManager_VPSType,
                                    width: 50
                                },

                              {
                                  field: "ProviderStatus",
                                  title: athoc.iws.subaccountmanager.resources.SubAccountManager_Status,
                                  width: 50
                              },


                            ],
                    dataBound: athoc.iws.subaccountmanager.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                        //athoc.iws.subaccountmanager.viewSubAccountManagerDetail(model.ProviderId);
                    }
                }).data().kendoGrid;
               
              
                this.refreshGrid();
                
            },

           
            refreshGrid: function () {
                //show the loader when we make a request to the server..
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.wrap-all'), imageURL: athoc.iws.subaccountmanager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000 }).showLoader();
                //Per telerik, this will set the page only after datasource refreshes.
                datasource.one("change", function () {
                //pagination needs to be reset after a reload
                    this.page(1);
                });
                datasource.read();
               
              
            },
            OnDataBound: function () {
               
                $("#subaccountmanagerList tbody").find("tr").attr("tabindex", "0");

                var grid = $("#subaccountmanagerList").data("kendoGrid");
                var data = grid.dataSource.data();

                $(grid.tbody).on("click", "td", function (e) {

                    var row = $(this).closest("tr");
                    var rowIdx = $("tr", grid.tbody).index(row);
                    var colIdx = $("td", row).index(this);

                    if (colIdx > 0 && colIdx < 5) {
                        var model = data[rowIdx];
                      
                       athoc.iws.subaccountmanager.viewSubAccountManagerDetail(model);
                    }
                });

                $(grid.tbody).on("keypress", "tr", function (e) {

                    var code = e.keyCode || e.which;

                    if (code == 13) {
                        var row = $(this);
                        var rowIdx = $("tr", grid.tbody).index(row);
                        var model = data[rowIdx];
                        //athoc.iws.subaccountmanager.viewSubAccountManagerDetail(model);
                    }
                });

                if (athoc.iws.subaccountmanager.IsRightToLeft) {
                    $("#subaccountmanagerList").find('.pull-right').addClass('pull-left');
                    $("#subaccountmanagerList").find('.pull-right').removeClass('pull-right');
                }
            },

            viewSubAccountManagerDetail:function(model)
            {
                navigateToPage('editSubAccountManager', function () { });
                athoc.iws.subaccountmanager.breadcrumbModel.SelectedPage('editSubAccountManager');
                $.titleCrumb("pageBreadcrumbs");
                athoc.iws.subaccountmanager.editModel.subaccountmanagermodel = ko.mapping.fromJS(model, athoc.iws.subaccountmanager.getValidation());
               
                ko.cleanNode($("#editSubAccountManager").get(0));
                ko.applyBindings(athoc.iws.subaccountmanager.editModel, $("#editSubAccountManager").get(0));
          
            },
            updateSelectedTotal: function () {
                var items = datasource.data();
                var r = $.grep(items, function (v) {
                    return v.IsChecked;
                });
                athoc.iws.subaccountmanager.ViewModel.set("SelectedCount", r.length);
            },

            getProviderId: function () {
                var items = datasource.data();
                var selected = $.grep(items, function (v) {
                    return v.Checked;
                });

                if (selected.length == 1) {
                    return selected[0].ProviderId;
                }
                alert(selected);
                return -1;
            },
            // to validate system settings before save
            getValidation: function () {
                //remove old validation
                $(".warning").each(function () {
                    $(this).parent().remove();
                });

                var validationMapping = {
                    ProviderName: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: true,
                                maxLength: 200,
                                pattern: {
                                    message: 'The following characters are not allowed in name \"`~!^()={};\:?"<>|"',
                                    params: "^[a-zA-Z0-9 _@#-.]+$"
                                }
                            });
                        }
                    },
                };

                return validationMapping;
            },
        };
    }();
}