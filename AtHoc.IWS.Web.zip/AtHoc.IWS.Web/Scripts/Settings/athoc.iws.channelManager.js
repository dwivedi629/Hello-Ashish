﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.channelManager = athoc.iws.channelManager || {};

if (athoc.iws.channelManager) {
    var ids = new Array();
    var selectedItems;
    var fileData;
    var tooltip;
    var testModel;
    var isPreview = false;
    var mode;
    var groupPermDataSourceGrid;
    var channelDatasource = null;


    athoc.iws.channelManager = function () {
        var sortState;
        var errorTitleStrings = new Array();
        return {
            currentPaging: 1,
            defaultPageSize: 50,
            isRelease: true,
            isChanged: false,
            channeldId: 0,
            deliveryFilter: 0,
            searchMaxLength: 100,
            TemplateFilter: [],
            imgOption: "",
            ContextProvider: 0,
            templateDefinitionTemp: "",
            IsEnterprises: false,
            IsSysAdmin: false,
            IsVirtualSysAdmin: false,
            ChannelCriteria: {
                SearchString: [],
                ProviderId: 0,
                OperatorId: 0,
                ChannelIds: [],
                IsEnabled: false,
            },
            lengthValidation: function (str, minChar, maxChar) {
                if (str.length < minChar[1] || str.length > minChar[2]) {
                    return false;
                }
                return true;
            },
            //search model
            searchModel: {
                selectedChannels: ko.observable(0),
                searchString: ko.observable(),
                SearchDisabled: ko.observable(),
                searchChannels: function () {
                    athoc.iws.channelManager.search();
                },
                htmlPillContent: ko.observable(''),

                clearFilter: function () {
                    athoc.iws.channelManager.clearFilters();
                },

                searchByEnter: function (data, event) {
                    athoc.iws.channelManager.searchByEnter(data, event);
                },

                searchBlur: function (data, event) {
                    //To enable or disable the search button
                    if (athoc.iws.channelManager.searchModel.searchString && athoc.iws.channelManager.searchModel.searchString() != null && athoc.iws.channelManager.searchModel.searchString().trim() != '')
                        athoc.iws.channelManager.searchModel.SearchDisabled(false);
                    else
                        athoc.iws.channelManager.searchModel.SearchDisabled(true);
                },
            },

            //actions model
            listActionModel: {
                isEditMode: ko.observable(false),

                saveChannelDetailsInfo: function () {
                    athoc.iws.channelManager.saveChannelDetails();
                },

                cancelSave: function () {
                    athoc.iws.channelManager.cancelSaving();
                },

                updateChannelStatus: function (status) {
                    athoc.iws.channelManager.updateChannelStatus(status);
                },

                saveNewChannelDetails: function (status) {
                    athoc.iws.channelManager.saveNewChannelDetailsdata();
                },

                deleteChannels: function () { athoc.iws.channelManager.showdeleteConfirmation(); },
            },


            moreActionModel: {
                groupStatusUpdate: ko.observable(),
            },

            //edit model
            editModel: {
                channelmodel: ko.observable(),
                DeviceToFilter: ko.observable(0),
                isEditMode: ko.observable(),
                ChannelGroupPermissions: ko.observableArray([]),
                ChannelGroups: ko.observableArray([]),
                ChannelAgents: ko.observableArray([]),
                ChannelSettings: {},
                isChannelEnabled: ko.observable(true),
                channelGroupName: ko.observableArray([]),
                isPopupMode: ko.observable(false),
                selectAllGroups: function (objectOfThis) { return athoc.iws.channelManager.selectAllGroupSet(objectOfThis); },
                groupPermissionCheck: function (strOption, objOfThis) { return athoc.iws.channelManager.groupPermissionCheck(strOption, objOfThis); },
                closeMetaStorePopup: function () { return athoc.iws.channelManager.closeMetaStorePopupAction(athoc.iws.channelManager.editModel.ChannelSettings.Meta_Store()); },
                isSaveBtnClicked: ko.observable(false),
            },

            //view model
            ViewModel: {
                channelmodel: ko.observable(),
            },

            //list model
            ListModel: kendo.observable(
                {
                    TotalCount: 0,
                    SelectedCount: 0,
                }),

            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for scenario list, will be triggered before document load
            init: function () {
                athoc.iws.channelManager.isRelease = true;
                ko.cleanNode($("#staticChannelListActionButtons").get(0));
                ko.applyBindings(athoc.iws.channelManager.listActionModel, $("#staticChannelListActionButtons").get(0));
                ko.cleanNode($("#editActionButton").get(0));
                ko.applyBindings(athoc.iws.channelManager.listActionModel, $("#editActionButton").get(0));

                athoc.iws.channelManager.initBreadcrumb();

                String.prototype.format = function () {
                    var args = arguments;
                    return this.replace(/\{\{|\}\}|\{(\d+)\}/g, function (curlyBrack, index) {
                        return ((curlyBrack == "{{") ? "{" : ((curlyBrack == "}}") ? "}" : args[index]));
                    });
                };

                //init sorting for grid
                localStorage.setItem("sortInfo", JSON.stringify({ colName: "Name", order: "asc" }));

            },

            //load method, will be tirggered on document load
            load: function () {
                //To fill the Message popup title strings from resource 
                errorTitleStrings.push(athoc.iws.channelManager.resources.AtHoc_CommonErrMsg_Title_Information);
                errorTitleStrings.push(athoc.iws.channelManager.resources.AtHoc_CommonErrMsg_Title_Warning);
                errorTitleStrings.push(athoc.iws.channelManager.resources.AtHoc_CommonErrMsg_Title_Error);
                errorTitleStrings.push(athoc.iws.channelManager.resources.AtHoc_CommonErrMsg_Title_Success);
                errorTitleStrings.push(athoc.iws.channelManager.resources.AtHoc_CommonErrMsg_Title_Completed);

                // bind Breadcrumb 
                athoc.iws.channelManager.bindBreadcrumb();
                var sortInfo = JSON.parse(localStorage.getItem("sortInfo"));
                if (sortInfo == undefined || sortInfo == "")
                    localStorage.setItem("sortInfo", JSON.stringify({ colName: "Name", order: "asc" }));

                // Load kendo grid
                athoc.iws.channelManager.bindChannelList();

                kendo.bind($(".kendoBound"), this.ListModel);
                //Fix the grid header
                var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
                if (gridHeader) {
                    gridHeader.addClass('table-header affix');
                }

                athoc.iws.channelManager.searchModel.selectedChannels(0);
                //filterContent
                athoc.iws.channelManager.listLoad();

                athoc.iws.channelManager.searchModel.SearchDisabled(true);


                ko.cleanNode($('#showGenericMessage').get(0));
                ko.applyBindings(athoc.iws.channelManager.warningMsg, $('#showGenericMessage').get(0));

                ko.cleanNode($("#dialogDeleteConfirm").get(0));
                ko.applyBindings(athoc.iws.channelManager.bindDeleteObjects, $("#dialogDeleteConfirm").get(0));

                ko.cleanNode($("#dialogDeleteDependancyConfirm").get(0));
                ko.applyBindings(athoc.iws.channelManager.bindDeleteObjects, $("#dialogDeleteDependancyConfirm").get(0));

                $("#channelList .k-pager-numbers").click(function () {
                    localStorage.setItem("cancelClicked", false);
                    localStorage.setItem("cPage", 1);
                });
               

                window.onbeforeunload = function () {
                    var isModified = athoc.iws.channelManager.isChanged;

                    if (isModified) {
                        return "";
                    } else {
                        $(window).scrollTop(0);

                    }
                };

            },

            //on click enter on search textbox
            searchByEnter: function (data, event) {
                if (event != undefined) {
                    if (athoc.iws.channelManager.searchModel.searchString)
                        athoc.iws.channelManager.searchModel.SearchDisabled(false);
                    if ($.hotkeys.enter(event)) {
                        athoc.iws.channelManager.search();
                    }
                }
            },

            //delete object and events
            bindDeleteObjects: {
                headerMsg: ko.observable(''),
                bodyHeadingMsg: ko.observable(''),
                noOfItems: ko.observableArray([]),
                folderName: ko.observable(''),
                cancelDialog: function () {
                    $("#dialogDeleteConfirm").modal('hide');
                },
                confirmDelete: function () {
                    athoc.iws.channelManager.deletechannelManager();
                },
                cancelDependencyDialog: function () {
                    $("#dialogDeleteDependancyConfirm").modal('hide');
                },
                confirmDependencyDelete: function () {
                    athoc.iws.channelManager.deletechannelManager();
                },

                exportDependency: function () {
                    $("#dependencyList").getKendoGrid().saveAsExcel();

                },

            },



            //warning message
            warningMsg: {
                Message: ko.observable(),
                CancelButtonMsg: ko.observable(''),
                HeaderText: ko.observable(),
                ClosePopup: function () {
                    $('#showGenericMessage').modal('hide');
                },
            },

            // To toggle collapse panel
            collapsePanel: function () {
                $(this).parent().find('.expand-arrow-open').toggle();
                $('.bucket-toggle h2').click(function () {
                    $(this).parent().find('.row').slideToggle(500);
                    $(this).parent().find('.expand-arrow-open').toggle();
                    $(this).parent().find('.expand-arrow-closed').toggle();
                });
            },

            // Triggered, when clear all link is clicked, it clear the searchCriteria and reload the grid
            clearFilters: function () {
                //Reset Selected Channel Ids 
                athoc.iws.channelManager.ChannelCriteria.ChannelIds = [];
                $('#saveGroupMessagePanel').html('');

                athoc.iws.channelManager.searchModel.htmlPillContent('');
                $("#channelList .k-grid-header").css("margin-top", "0px");
                $("#channelList").css("margin-top", "0px");

                athoc.iws.channelManager.searchModel.searchString("");
                athoc.iws.channelManager.ChannelCriteria.SearchString = [];
                athoc.iws.channelManager.refreshGrid();
                athoc.iws.channelManager.listLoad();
                $("#btn_delete").attr('disabled', 'true');
                $("#channelList .k-grid-header").css("z-index", "10");

                athoc.iws.channelManager.searchModel.SearchDisabled(true);
                //   $('#ddlAgentType').val([]);
                //  $('#ddlAgentType').selectpicker('refresh');

            },

            // Triggered, when search button or hit enter in search textbox
            search: function () {
                //Reset Selected Channel Ids 
                athoc.iws.channelManager.ChannelCriteria.ChannelIds = [];
                if ($.trim(athoc.iws.channelManager.searchModel.searchString()).length <= athoc.iws.channelManager.searchMaxLength) {
                    if (athoc.iws.channelManager.searchModel.searchString() != "")
                        athoc.iws.channelManager.createPills(athoc.iws.channelManager.searchModel.searchString());
                    //reset the search text
                    athoc.iws.channelManager.searchModel.searchString('');
                    athoc.iws.channelManager.searchModel.SearchDisabled(true);
                }
                else
                    $('#saveGroupMessagePanel').modal("show");
            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.channelManager.breadcrumbModel;
                var isModified = athoc.iws.channelManager.isChanged;


                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.channelManager.resources.Action_Button_Settings, '', function () {
                    window.location.href = "/client/setup/settings";
                });

                var channelTemplate = new Breadcrumb('editChannel', athoc.iws.channelManager.resources.Settings_FolderManager_Folders, '', function () {
                    if (isModified) {
                        var confirmLeave = confirm(athoc.iws.channelManager.resources.Confirm_Leave);
                        if (confirmLeave == true) {
                            athoc.iws.channelManager.isChanged = false;
                        }
                    }
                    else { window.location.reload(); }

                });

                breadcrumbsModel.addPage(new PageBreadcrumb('viewChannel', '', [settingLink, channelTemplate], ''));
                breadcrumbsModel.addPage(new PageBreadcrumb('listChannel', athoc.iws.channelManager.resources.Settings_FolderManager_Folders, [settingLink], ''));
                breadcrumbsModel.addPage(new PageBreadcrumb('editChannel', '', [settingLink, channelTemplate], ''));


            },

            //breadcrumb
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.channelManager.breadcrumbModel;
                breadcrumbsModel.SelectedPage('listChannel');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');

                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
                athoc.iws.channelManager.breadcrumbModel.updateTitle(athoc.iws.channelManager.resources.Settings_FolderManager_Folders, undefined, undefined, 'listChannel');
            },

            //update breadcrumb title
            updateTitle: function () {
                mode = 1;
                switch (mode) {
                    case 1:
                        athoc.iws.channelManager.breadcrumbModel.updateTitle(athoc.iws.channelManager.editModel.ChannelSettings.Name, undefined, undefined, 'editChannel');
                        break

                    default:
                        athoc.iws.channelManager.breadcrumbModel.updateTitle("", undefined, undefined, 'editChannel');
                        break;
                }
            },


            bindDependencyGrid: function (dependencyList) {


                var ds = new kendo.data.DataSource({
                    data: dependencyList,
                    pageSize:50
                });
                //build grid
                var grid = $("#dependencyList").kendoGrid({
                    dataSource: ds,
                    selectable: false,
                    width: 100,
                    sortable: {
                        allowUnsort: false
                    },
                    excel: {
                        fileName: athoc.iws.channelManager.resources.Settings_FolderManager_FileDownload_Name + ".xlsx",
                        allPages: true,
                        filterable: false,
                        // proxyURL: athoc.iws.userattribute.details.urls.ExportDependenciesUrl,
                       // forceProxy: false,
                    },
                    excelExport: function (e) {
                        var sheet = e.workbook.sheets[0];
                        for (var i = 0; i < sheet.columns.length; i++) {
                            sheet.columns[i].autoWidth = true;
                        }
                    },

                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5, messages: {
                            itemsPerPage: athoc.iws.channelManager.resources.AtHoc_Pager_Message_Items_Per_Page,
                            display: athoc.iws.channelManager.resources.AtHoc_Pager_Message_Summary,
                            empty: athoc.iws.channelManager.resources.IWS_Common_NoRecordsFound,

                            first: $.htmlDecode(athoc.iws.channelManager.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.channelManager.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.channelManager.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: athoc.iws.channelManager.resources.AtHoc_Pager_Message_Go_To_The_Last_Page
                        }
                    },
                    columns: [
                                {
                                    field: "Type",
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.channelManager.resources.Settings_FolderManager_Dependency_Type, athoc.iws.channelManager.resources.Settings_FolderManager_Dependency_Type),
                                    width: 25,
                                    template: '<span class="cellTooltip" title="#=Type#">#=Type#</span>'
                                },
                                {
                                    field: "Name",
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.channelManager.resources.Settings_FolderManager_Dependency_Name, athoc.iws.channelManager.resources.Settings_FolderManager_Dependency_Name),
                                    width: 25,
                                    template: $("#dep-name-tooltip-template").html()
                                },
                                 {
                                     field: "Id",
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.channelManager.resources.Settings_FolderManager_Dependency_ID, athoc.iws.channelManager.resources.Settings_FolderManager_Dependency_ID),
                                     width: 25,
                                     template: '<span class="cellTooltip" title="#=Id#">#=Id#</span>'
                                 },
                                {
                                    field: "OrgName",
                                    width: 25,
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.channelManager.resources.Settings_FolderManager_Dependency_Organization, athoc.iws.channelManager.resources.Settings_FolderManager_Dependency_Organization),
                                    template: '<span class="cellTooltip" title="#=$.htmlEncode(OrgName)#">#=$.htmlEncode(OrgName)#</span>'
                                },
                    ],
                    dataBound: athoc.iws.channelManager.OnDependencyDataBound,
                    change: function (e) {
                    },
                }).data().kendoGrid;

                var $template = kendo.template($("#dep-name-tooltip-template").html());

                tooltip = $("#dependencyList").kendoTooltip({
                    filter: "td:nth-child(2)", //this filter selects the first column cells                   
                    content: function (e) {
                        var dataItem = $("#dependencyList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },

                }).data("kendoTooltip");

                //$("#dependencyList").data("kendoGrid").dataSource.data(dependencyList);
               // $("#dependencyList").data("kendoGrid").dataSource.page(1);
            },

          
            deleteDependencyCheck: function (channelId) {

                var jsonData = { ChannelId: channelId };
                var dlAjaxOption =
                    {
                        url: athoc.iws.channelManager.urls.GetDependencyListUrl,
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            if (data.IsSystemFolder) {
                                athoc.iws.channelManager.showNoDeleteAllowedPopup();
                            }
                            else if (data.Data.length == 0) {// No dependencies
                                athoc.iws.channelManager.showModalPopup('dialogDeleteConfirm');
                            }
                            else {
                                athoc.iws.channelManager.bindDependencyGrid(data.Data);
                                athoc.iws.channelManager.showModalPopup('dialogDeleteDependancyConfirm');

                            }
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);

                $.ajax(ajaxOptions);
            },


            //show Delete confirmation dialog
            showdeleteConfirmation: function (ChannelId) {
                $('#btnFolderDelete').show();
                athoc.iws.channelManager.warningMsg.CancelButtonMsg(athoc.iws.channelManager.resources.Settings_FolderManager_btnCancel);
                
                var items = athoc.iws.channelManager.getSelectedItems(ChannelId);
                athoc.iws.channelManager.bindDeleteObjects.folderName((items.length > 0) ? items[0].Name : '');
                athoc.iws.channelManager.bindDeleteObjects.headerMsg(athoc.iws.channelManager.resources.Settings_FolderManager_Delete_Confirmation.format(athoc.iws.channelManager.bindDeleteObjects.folderName()));
                
                athoc.iws.channelManager.bindDeleteObjects.noOfItems([]);
                athoc.iws.channelManager.bindDeleteObjects.noOfItems(items);
                //athoc.iws.channelManager.bindDeleteObjects.bodyHeadingMsg(athoc.iws.channelManager.resources.Delete_Channels.format(athoc.iws.channelManager.bindDeleteObjects.noOfItems().length));
                athoc.iws.channelManager.bindDeleteObjects.bodyHeadingMsg(athoc.iws.channelManager.resources.Settings_FolderManager_Delete_Channels.format(athoc.iws.channelManager.bindDeleteObjects.folderName()));


                $("#lblDeleteFolderName").text(" " + items[0].Name); 
                if (athoc.iws.channelManager.isHavingPermission(items[0]))
                    athoc.iws.channelManager.deleteDependencyCheck(ChannelId);
                else {
                    athoc.iws.channelManager.showNoDeleteAllowedPopup();
                }

            },

            showNoDeleteAllowedPopup: function() {
                //athoc.iws.channelManager.showModalPopup('dialogDeleteConfirm');
                athoc.iws.channelManager.warningMsg.HeaderText(athoc.iws.channelManager.resources.Settings_FolderManager_DeleteConfirmation);
                athoc.iws.channelManager.warningMsg.Message(athoc.iws.channelManager.resources.Settings_FolderManager_systemLevelDelete.format(athoc.iws.channelManager.bindDeleteObjects.folderName()));
                athoc.iws.channelManager.showModalPopup('showGenericMessage');
                athoc.iws.channelManager.warningMsg.HeaderText(athoc.iws.channelManager.resources.Settings_FolderManager_systemLevelDelete_HeaderText);
                $('#btnFolderDelete').hide();
                athoc.iws.channelManager.warningMsg.CancelButtonMsg(athoc.iws.channelManager.resources.AtHoc_Common_Close);
            },

            //show model pop-up
            showModalPopup: function (IdOfdiv) {
              
                $('#' + IdOfdiv).modal({ backdrop: 'static', keyboard: false }).promise().done(function () {
                    setTimeout(function () {
                        if ($("#content-title").is(":visible"))
                            $("#content-title").focus();
                    }, 1000);
                });             


            },
            //fit the modal according to the screen
            fitHeighEndUserList: function (IdOfdiv) {
                modal = $('#' + IdOfdiv);
                var windowHeight = modal.find(".modal-body").height();
                if (windowHeight > 500) {
                    modal.find(".k-grid-content").css("height", (windowHeight * 73 / 100) - 10);
                }
                else if ((windowHeight <= 500) && (windowHeight > 400)) {
                    modal.find(".k-grid-content").css("height", (windowHeight * 65 / 100) - 15);
                }
                else {
                    modal.find(".k-grid-content").css("height", (windowHeight * 70 / 100) - 50);
                }
            },

            //fit the modal according to the screen when grid is filled
            resizeModalBasedOnScreen: function (IdOfdiv) {

                modal = $('#' + IdOfdiv);
                modal.find(".modal-body").css("max-height", 600);
                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 56 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 56 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 265);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }

            },

            //close model pop-up
            closeModalPopup: function (IdOfdiv) {
                $('#' + IdOfdiv).modal('hide');
                $('#' + IdOfdiv).hide();
                $(".modal-backdrop").each(function() {
                    $(this).remove();
                });
                athoc.iws.channelManager.listActionModel.isEditMode(false);

            },

            // Triggered, When deleteing the delivery Template records
            deletechannelManager: function () {
                $('#saveGroupMessagePanel').html('');

                var channelId = athoc.iws.channelManager.bindDeleteObjects.noOfItems()[0].Channel_Id;

                var jsonData = { intChannelId: channelId };

                var dlAjaxOption =
                    {
                        url: athoc.iws.channelManager.urls.DeleteChannelUrl,
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            $("#dialogDeleteDependancyConfirm").modal('hide');
                            $("#dialogDeleteConfirm").modal('hide');
                            athoc.iws.channelManager.searchModel.selectedChannels(0);
                            athoc.iws.channelManager.updateSelectedTotal(true);
                            //reload the folders list;
                            athoc.iws.channelManager.reloadFoldersList();
                        },
                        error: function (e) {
                            $("#dialogDeleteDependancyConfirm").modal('hide');
                            $("#dialogDeleteConfirm").modal('hide');
                            athoc.iws.channelManager.handleError(e);
                        }

                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);

                $.ajax(ajaxOptions);

                return true;
            },


            //to reload the folders list
            reloadFoldersList: function () {
                athoc.iws.channelManager.ChannelCriteria.ChannelIds = [];
                athoc.iws.channelManager.ChannelCriteria.SearchString = [];
                athoc.iws.channelManager.refreshGrid();
                athoc.iws.channelManager.listLoad();
                athoc.iws.channelManager.renderPills();
                $("#channelList .k-grid-header").css("margin-top", "0px");
                $("#channelList").css("margin-top", "0px");
                $("#btn_delete").attr('disabled', 'true');
                $("#channelList .k-grid-header").css("z-index", "10");
                athoc.iws.channelManager.searchModel.searchString('');
                athoc.iws.channelManager.searchModel.SearchDisabled(true);
            },

            // to display the template settings in edit mode
            editchannelDetail: function (model) {

                $("#ddlAgents").selectpicker({});
                $("#selectAgents").find(".bootstrap-select").remove();
                athoc.iws.channelManager.ChannelCriteria.ChannelIds = [];
                athoc.iws.channelManager.ChannelCriteria.SearchString = [];
                $('#editForder').show();
                $('#errorMessagePanel').html('');
                $('#saveGroupMessagePanel').html('');
                athoc.iws.channelManager.isChanged = false;
                athoc.iws.channelManager.editModel.isEditMode = false;
                athoc.iws.channelManager.listActionModel.isEditMode(false);
                athoc.iws.channelManager.editModel.isPopupMode = true;
                athoc.iws.channelManager.editModel.saveChannelDetailsInfo = athoc.iws.channelManager.listActionModel.saveChannelDetailsInfo;
                athoc.iws.channelManager.editModel.cancelSave = athoc.iws.channelManager.listActionModel.cancelSave;

                if (model != null) {
                    athoc.iws.channelManager.ChannelCriteria.ChannelIds.push(model.Channel_Id);
                    athoc.iws.channelManager.ChannelCriteria.ProviderId = model.Provider_Id;
                    athoc.iws.channelManager.ChannelCriteria.OperatorId = model.OperatorId;
                }
                else {
                    athoc.iws.channelManager.ChannelCriteria.ChannelIds.push(0);
                    athoc.iws.channelManager.ChannelCriteria.ProviderId = athoc.iws.channelManager.ContextProvider;
                }

                var jsonData = { channelCriteria: athoc.iws.channelManager.ChannelCriteria };
                var dlAjaxOption =
                    {
                        url: athoc.iws.channelManager.urls.ChannelDetailsForEdit,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(jsonData),
                        success: function (data) {
                            if (data.Success) {
                                localStorage.setItem("sortInfo", JSON.stringify({ colName: channelDatasource.sort()[0].field, order: channelDatasource.sort()[0].dir }));
                                if (model != undefined) {
                                    athoc.iws.channelManager.editModel.ChannelSettings = data.Data.ChannelSettings;
                                    athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.selectedFolderId(data.Data.ChannelSettings.Channel_Id);

                                }
                                else {

                                    athoc.iws.channelManager.editModel.ChannelSettings = {
                                        Status: "Enabled",
                                        Description: "",
                                        Name: "",
                                        Common_Name: "",
                                        Meta_Store: "",
                                        CreatedDate: "",
                                        UpdatedByUsername: "",
                                        CreatedByUsername: "",
                                        UpdatedDate: "",
                                        Channel_Id: 0,
                                    };
                                }

                                athoc.iws.channelManager.isChanged = false;
                                athoc.iws.channelManager.IsEnterprises = data.IsEnterprises;
                                athoc.iws.channelManager.IsSysAdmin = data.IsSysAdmin;
                                athoc.iws.channelManager.IsVirtualSysAdmin = data.IsVirtualSysAdmin;

                                athoc.iws.channelManager.editModel.ChannelSettings = ko.mapping.fromJS(athoc.iws.channelManager.editModel.ChannelSettings);
                                athoc.iws.channelManager.validateControls();

                                if (athoc.iws.channelManager.isHavingPermission(data.Data.ChannelSettings) || (model == null)) {
                                    athoc.iws.channelManager.editModel.isEditMode = true;
                                    athoc.iws.channelManager.listActionModel.isEditMode(true);

                                }

                                ko.cleanNode($("#editData").get(0));

                                ko.applyBindings(athoc.iws.channelManager.editModel, $("#editData").get(0));
                                athoc.iws.channelManager.editSubsribeMethod();
                                $("#ddlAgents").selectpicker('refresh');


                                athoc.iws.channelManager.isRelease = true;
                                $.AjaxLoader.hideLoader();
                            }
                            else {

                                if (data.HasErrors) {
                                    $('#saveGroupMessagePanel').messagesPanel({ messages: data.Messages }, undefined, undefined, undefined, errorTitleStrings);
                                    if (data.ReturnType == 1) {

                                        $("html,body").scrollTop(0);
                                    }
                                }

                            }

                            athoc.iws.channelManager.showModalPopup('editData');
                            $("html,body").scrollTop(0);
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.channelManager.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);


                return true;
            },

            

            //Subsribers
            editSubsribeMethod: function () {
                athoc.iws.channelManager.editModel.ChannelSettings.Name.subscribe(function (newValue) {
                    athoc.iws.channelManager.editModel.isSaveBtnClicked(false);
                    if ($.trim(newValue) != "" && athoc.iws.channelManager.editModel.isEditMode) {
                        athoc.iws.channelManager.isChanged = true;
                        $('#errorMessagePanel').html('');
                        athoc.iws.channelManager.breadcrumbModel.updateTitle(athoc.iws.channelManager.editModel.ChannelSettings.Name(), undefined, undefined, 'editChannel');
                    }

                });


                athoc.iws.channelManager.editModel.ChannelSettings.Description.subscribe(function (newValue) {
                    athoc.iws.channelManager.editModel.isSaveBtnClicked(false);
                    if ($.trim(newValue) != "" && athoc.iws.channelManager.editModel.isEditMode)
                        athoc.iws.channelManager.isChanged = true;
                    $('#errorMessagePanel').html('');
                });

            },

            groupPermissionCheck: function (strOption, objOfthis) {

                if (strOption === 'M') {
                    objOfthis.GroupPermissions.isMandatory = true;
                    objOfthis.GroupPermissions.isDefault = false;
                    objOfthis.GroupPermissions.isOptional = false;
                    objOfthis.GroupPermissions.isBlocked = false;
                }
                else if (strOption === 'D') {
                    objOfthis.GroupPermissions.isMandatory = false;
                    objOfthis.GroupPermissions.isDefault = true;
                    objOfthis.GroupPermissions.isOptional = false;
                    objOfthis.GroupPermissions.isBlocked = false;
                }
                else if (strOption === 'O') {
                    objOfthis.GroupPermissions.isMandatory = false;
                    objOfthis.GroupPermissions.isDefault = false;
                    objOfthis.GroupPermissions.isOptional = true;
                    objOfthis.GroupPermissions.isBlocked = false;
                }
                else if (strOption === 'B') {
                    objOfthis.GroupPermissions.isMandatory = false;
                    objOfthis.GroupPermissions.isDefault = false;
                    objOfthis.GroupPermissions.isOptional = false;
                    objOfthis.GroupPermissions.isBlocked = true;
                }

                return true;
            },

            checkAll: function (objhtml) {

                var className = objhtml.className;
                var count = $("." + className).length;
                var noOfChecked = 0;
                $("." + className).each(function () {
                    if ($(this).is(":checked"))
                        noOfChecked++;
                });

                if (noOfChecked == count)
                    $("." + className.replace("_C", "")).prop('checked', 'checked');
                else
                    $("." + className.replace("_C", "")).removeAttr('checked');

            },

            selectAllGroupSet: function (objInfo) {
                var isChecked = $('.' + objInfo.groupSetId).is(':checked');


                $('.' + objInfo.groupSetId + '_C').each(function () {
                    if (isChecked)
                        $(this).prop('checked', 'checked');
                    else
                        $(this).removeAttr('checked');

                });

                _.each(athoc.iws.channelManager.editModel.ChannelGroups(), function (item) {
                    if (item.GroupSetId == objInfo.groupSetId) {
                        item.isSelected = isChecked;
                    }
                });

                return true;
            },

            //validation functions
            isRequired: function (val, required) {
                var stringTrimRegEx = /^\s+|\s+$/g,
                 testVal;

                if ($.trim(val) === undefined || $.trim(val) === null) {
                    return !required;
                }

                testVal = $.trim(val);
                if (typeof ($.trim(val)) == "string") {
                    testVal = $.trim(val).replace(stringTrimRegEx, '');
                }

                return required && (testVal + '').length > 0;
            },

            maxLength: function (val, maxLength) {
                return athoc.iws.channelManager.isEmptyVal(val) || $.trim(val).length <= maxLength;
            },

            isEmptyVal: function (val) {
                if ($.trim(val) == undefined) {
                    return true;
                }
                if ($.trim(val) == null) {
                    return true;
                }
                if ($.trim(val) == "") {
                    return true;
                }
            },

            pattern: function (val, regex, type) {
                var pattern = regex;
                var $opts = { "rule": "format", "format": { "pattern": regex } };

                if (typeof $opts.format.pattern === "string")
                    var pattern = (typeof $opts.format.pattern === "object") ? $opts.format.pattern : new RegExp($opts.format.pattern, "g");
                return pattern.test($.trim(val));

            },

            resetSearchCriteria: function () {
                athoc.iws.channelManager.searchModel.searchString("");
            },

            // saves channels details
            saveChannelDetails: function () {
                $('#errorMessagePanel').html('');
                athoc.iws.channelManager.editModel.isSaveBtnClicked(true);
                var result = ko.validation.group(athoc.iws.channelManager.editModel.ChannelSettings, { deep: true });
                if (result().length > 0) {
                    athoc.iws.channelManager.editModel.ChannelSettings.errors.showAllMessages();
                    $("html, body").animate({ scrollTop: 0 }, 600);
                    return false;
                }
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('[data-page="editChannel"]'), imageURL: athoc.iws.channelManager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();

                if (athoc.iws.channelManager.editModel.ChannelSettings.Common_Name() == null || athoc.iws.channelManager.editModel.ChannelSettings.Common_Name() == "") {
                    athoc.iws.channelManager.editModel.ChannelSettings.Common_Name(athoc.iws.channelManager.editModel.ChannelSettings.Name().trim().replace(/\s/g, '-'));
                }

                athoc.iws.channelManager.editModel.ChannelSettings.Name(
                athoc.iws.channelManager.editModel.ChannelSettings.Name().trim());
                athoc.iws.channelManager.isChanged = false;


                $('#saveGroupMessagePanel').html('');
                $('#saveGroupMessagePanel_edit').html('');
                var channelData = ko.mapping.toJS(athoc.iws.channelManager.editModel.ChannelSettings);

                var paramInfo = {
                    ChannelSettings: channelData,
                    ChannelGroupPermissions: ko.mapping.toJS(athoc.iws.channelManager.editModel.ChannelGroupPermissions),
                    ChannelGroups: null,
                    ChannelAgents: null,
                };
                var jsonData = { channelSettingsModel: paramInfo };
                var dlAjaxOption =
                {
                    url: athoc.iws.channelManager.urls.SaveChannelUrl,
                    dataType: 'json',
                    type: 'POST',
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify(jsonData),
                    success: function (data) {
                        if (data.Success) {
                            $('#errorMessagePanel').html('');
                            if (athoc.iws.channelManager.editModel.ChannelSettings.Channel_Id() == 0) {
                                localStorage.setItem("cancelClicked", false);
                                localStorage.setItem("pageSize", 50);
                                localStorage.setItem("cPage", 1);
                                localStorage.setItem("sortInfo", JSON.stringify({ colName: "Name", order: "asc" }));
                            } else {
                                localStorage.setItem("cancelClicked", true);
                            }
                            athoc.iws.channelManager.closeModalPopup('editData');
                            athoc.iws.channelManager.reloadFoldersList();
                        } else {

                            $('#errorMessagePanel').messagesPanel({ messages: data.Messages }, undefined, undefined, undefined, errorTitleStrings);
                            if (data.ReturnType == 1) {
                                $("html,body").scrollTop(0);
                            }
                        }
                        $.AjaxLoader.hideLoader();
                    },
                    error: function (data) {
                        this.showError(data.Success);
                    },
                }
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },

            //cancel save event
            cancelSaving: function () {
                athoc.iws.channelManager.editModel.isSaveBtnClicked(false);
                if (athoc.iws.channelManager.editModel.isEditMode && athoc.iws.channelManager.ChannelCriteria.ChannelIds[0] == 0) {
                    athoc.iws.channelManager.isChanged = false;
                    isModified = true;
                }
                localStorage.setItem("cancelClicked", true);
                var isModified = athoc.iws.channelManager.isChanged;
                if ((athoc.iws.channelManager.editModel.isEditMode) && (isModified == true)) {
                    var confirmLeave = confirm(athoc.iws.channelManager.resources.Unsaved_Data_Text);
                    if (confirmLeave == true) {
                        athoc.iws.channelManager.isChanged = false;
                        athoc.iws.channelManager.closeModalPopup('editData');
                    }
                }
                else {
                    athoc.iws.channelManager.closeModalPopup('editData');
                }
            },

            listLoad: function () {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
            },

            bindChannelList: function () {
                //Reset Selected Channel Ids 
                athoc.iws.channelManager.ChannelCriteria.ChannelIds = [];
                var jsonData = JSON.stringify(athoc.iws.channelManager.ChannelCriteria);
                var sortInfo = JSON.parse(localStorage.getItem("sortInfo"));
                channelDatasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: athoc.iws.channelManager.urls.GetChannelListsUrl,
                            cache: false,
                            data: JSON.stringify(jsonData),
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.channelManager.ChannelCriteria);
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                    },
                    requestEnd: function (e) {

                        if (e.response) {
                            athoc.iws.channelManager.ListModel.set("TotalCount", e.response.TotalCount);
                            //clear selected
                            athoc.iws.channelManager.ListModel.set("SelectedCount", 0);
                            athoc.iws.channelManager.IsSysAdmin = true;
                            athoc.iws.channelManager.ContextProvider = e.response.ContextProvider;
                            $('#chkSelectAll').attr("checked", false);
                            $.AjaxLoader.hideLoader();
                            $('#saveGroupMessagePanel').html('');
                        }


                        var isClicked = localStorage.getItem("cancelClicked");
                        var getCPSize = localStorage.getItem("pageSize");
                        var getCPPage = localStorage.getItem("cPage");

                        if (getCPSize == undefined) {
                            localStorage.setItem("pageSize", channelDatasource.pageSize());
                            localStorage.setItem("cPage", channelDatasource.page());
                            athoc.iws.channelManager.defaultPageSize = channelDatasource.pageSize();
                            athoc.iws.channelManager.currentPaging = channelDatasource.page();
                        }
                        else if (getCPSize != undefined && ((getCPSize != channelDatasource.pageSize()) || (getCPPage != channelDatasource.page()))) {

                            if (isClicked == "true") {
                                localStorage.setItem("pageSize", getCPSize);
                                localStorage.setItem("cPage", getCPPage);
                                athoc.iws.channelManager.defaultPageSize = getCPSize;
                                athoc.iws.channelManager.currentPaging = getCPPage;

                            } else {
                                localStorage.setItem("pageSize", channelDatasource.pageSize());
                                localStorage.setItem("cPage", channelDatasource.page());
                                athoc.iws.channelManager.defaultPageSize = channelDatasource.pageSize();
                                athoc.iws.channelManager.currentPaging = channelDatasource.page();
                            }
                        }
                        else
                            athoc.iws.channelManager.currentPaging = (channelDatasource.page ? channelDatasource.page() : 1);



                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                    },
                    sort: { field: sortInfo.colName, dir: sortInfo.order },
                    pageSize: athoc.iws.channelManager.defaultPageSize,


                    error: function (e) {
                        $.AjaxLoader.hideLoader();
                    },
                    change: function (e) {
                        athoc.iws.channelManager.enableSelectAll();
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            //when sort changes, go to first page.
                            this.page(1);
                        }
                        //scrolling to the top when paging and sorting.
                        $("html,body").scrollTop(0);
                    }



                });


                //build grid
                var grid = $("#channelList").kendoGrid({
                    dataSource: channelDatasource,
                    autoBind: false,
                    selectable: false,
                    width: 400,
                    sortable: {
                        allowUnsort: false
                    },


                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        pageSize: 20,
                        buttonCount: 5, messages: {
                            itemsPerPage: athoc.iws.channelManager.resources.AtHoc_Pager_Message_Items_Per_Page,
                            display: athoc.iws.channelManager.resources.AtHoc_Pager_Message_Summary,
                            empty: athoc.iws.channelManager.resources.IWS_Common_NoRecordsFound,

                            first: $.htmlDecode(athoc.iws.channelManager.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.channelManager.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.channelManager.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: athoc.iws.channelManager.resources.AtHoc_Pager_Message_Go_To_The_Last_Page
                        }
                    },
                    columns: [
                                //{
                                //    field: "IsChecked",
                                //    template: $("#channelMng-chkDelete-template").html(),
                                //    width: 20,
                                //    title: "",
                                //    headerTemplate: kendo.format('<input type="checkbox" class="senario-select" id="chkSelectAll" title="{0}" onclick="athoc.iws.channelManager.selectAllChannels();" />', athoc.iws.channelManager.resources.Settings_FolderManager_Select_Current_Page),
                                //    sortable: false,
                                //    headerAttributes: {
                                //        style: "cursor: default",
                                //    }
                                //},
                                {
                                    field: "Name",
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.channelManager.resources.Settings_FolderManager_GridColumnTitle_Prefix + ' ' + athoc.iws.channelManager.resources.Settings_FolderManager_Name, athoc.iws.channelManager.resources.Settings_FolderManager_Name),
                                    width: 350
                                },

                                {
                                    field: "UpdatedDate",
                                    width: 100,  
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.channelManager.resources.Settings_FolderManager_GridColumnTitle_Prefix + ' ' + athoc.iws.channelManager.resources.Settings_FolderManager_UpdatedOn, athoc.iws.channelManager.resources.Settings_FolderManager_UpdatedOn),
                                    template: "#=UpdatedDate#",
                                },
                                {
                                    field: "Provider_Name",
                                    width: 100,
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.channelManager.resources.Settings_FolderManager_GridColumnTitle_Prefix + ' ' + athoc.iws.channelManager.resources.Settings_FolderManager_Scope, athoc.iws.channelManager.resources.Settings_FolderManager_Scope),
                                    template: '<span class="cellTooltip" title="#= $.htmlEncode(Provider_Name) #">#=$.htmlEncode(Provider_Name)#</span>'
                                },
                                 {
                                     field: "Action",
                                     template: $("#channelMng-DeleteonEachRow-template").html(),
                                     width: 40,
                                     title: "",
                                     headerTemplate: '',
                                     sortable: false,
                                     headerAttributes: {
                                         style: "cursor: default",
                                     }
                                 },
                    ],
                    dataBound: athoc.iws.channelManager.OnDataBound,
                    pageSize: athoc.iws.channelManager.defaultPageSize,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                    }
                }).data().kendoGrid;


                var lastMouseX;
                var $template = kendo.template($("#name-tooltip-template").html());

                var alertFolderTooltip = $("#channelList").kendoTooltip({
                    filter: "td:nth-child(1)", //this filter selects the first column cells     
                    position: "right",
                    show: function() {
                        $(this.popup.wrapper).css({
                            left: lastMouseX + 60
                        });
                    },
                    content: function(e) {
                        e.sender.content.parent().addClass('alert-folder-name-tooltip');
                        var dataItem = $("#channelList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },

                }).on('mouseout', function() {
                    alertFolderTooltip.data('kendoTooltip').hide();
                });

                tooltip = alertFolderTooltip.data("kendoTooltip");

                $(document).on("mousemove", function (e) {
                    lastMouseX = e.pageX;
                    $(".alert-folder-name-tooltip").parent().css({
                        left: lastMouseX + 60
                    });
                });

                $("#channelList").kendoTooltip({
                    filter: ".cellTooltip",
                    content: function (e) {
                        var dataItem = e.target.parent();
                        return dataItem.find('.cellTooltip').html();
                    }
                });

                $("#pageInfo").kendoPager({
                    dataSource: channelDatasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.channelManager.resources.Settings_FolderManager_DisplayFolder,
                        empty: athoc.iws.channelManager.resources.IWS_Common_NoRecordsFound
                    }
                });
                athoc.iws.channelManager.searchModel.selectedChannels(athoc.iws.channelManager.getSelectedItems().length);

                ko.cleanNode($("#dvFolderSearch").get(0));
                ko.applyBindings(athoc.iws.channelManager.searchModel, $("#dvFolderSearch").get(0));

                this.refreshGrid();




            },

            //this function will refresh the grid rows
            refreshGrid: function () {
                if (channelDatasource != undefined) {
                    //show the loader when we make a request to the server..
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-filter'), imageURL: athoc.iws.channelManager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: this.resources.General_LoadingMessage }).showLoader();
                    //Per telerik, this will set the page only after channelDatasource refreshes.
                    channelDatasource.one("change", function () {
                        //pagination needs to be reset after a reload

                        this.pageSize(athoc.iws.channelManager.defaultPageSize);
                        this.page(athoc.iws.channelManager.currentPaging);
                    });


                    channelDatasource.read();
                    athoc.iws.channelManager.searchModel.selectedChannels(0);
                    $.AjaxLoader.hideLoader();
                }
            },

            errors: null,

            //Method to handle error and session time out, this is bound with Ajax calls
            handleError: function (e) {
                $.AjaxLoader.hideLoader();
                athoc.iws.channelManager.errors = [];
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else if (e.errorThrown != "") {
                    if (athoc.iws.channelManager.errors === null) {
                        athoc.iws.channelManager.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.channelManager.errors.push({ Type: '4', Value: e.errorThrown });
                    }

                    $("#channelList .k-grid-header").css("top", "315px");
                    $("#channelList").css('cssText', 'top: 346px !important');
                    $("#dvFolderSearch .whiteout").css("height", "315px");
                    $('#saveGroupMessagePanel').messagesPanel({ messages: this.errors }, undefined, undefined, undefined, errorTitleStrings);



                    $("#saveGroupMessagePanel .close").prop("click", function () {
                        $("#channelList .k-grid-header").css("top", "210px");
                        $("#channelList").css("cssText", "top: 241px !important");
                        $("#dvFolderSearch .whiteout").css("height", "210px");
                    });

                }
            },

            showEditError: function (msg) {
                $.AjaxLoader.hideLoader();
                $('#saveGroupMessagePanel_edit').messagesPanel({ messages: [{ Type: '4', Value: msg }] }, undefined, undefined, undefined, errorTitleStrings);

            },

            FilterScenarioList: function (e) {
                //only update when enter key is pressed and when the apply button is clicked
                if ($.hotkeys.enter(e) || e.target.id == "btn_filter")
                    athoc.iws.channelManager.refreshGrid();

                if (e.target.id == "btn_filter")
                    $("#btn_clear").focus();
            },

            OnDependencyDataBound: function () {

                $("#dependencyList tbody").find("tr").attr("tabindex", "0");
                var grid = $("#dependencyList").data("kendoGrid");

                if (athoc.iws.channelManager.IsRightToLeft) {
                    $("#dependencyList").find('.pull-right').addClass('pull-left');
                    $("#dependencyList").find('.pull-right').removeClass('pull-right');
                }
                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(grid.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.channelManager.resources.IWS_Common_NoRecordsFound + '</td></tr>');
                }
            },

            //On Grid databound navigate to Edit page or View page w.r.t device Type
            OnDataBound: function () {

                $("#channelList tbody").find("tr").attr("tabindex", "0");
                var grid = $("#channelList").data("kendoGrid");

                $(grid.tbody).on("click", "td", function (e) {

                    var isFirstRowCheck = $(this).closest("td").find('#chkchannelMngId');
                    if (isFirstRowCheck.length == 0) {
                        var row = $(this).closest("tr");
                        var rowIdx = $("tr", grid.tbody).index(row);
                        var colIdx = $("td", row).index(this);

                        var colIdx = $("td", row).index(this);
                        var lastColumnIndex = $("td", row).index(row.find('td:last'));


                        if (colIdx >= 0 && athoc.iws.channelManager.isRelease == true && colIdx != lastColumnIndex) {
                            athoc.iws.channelManager.searchModel.selectedChannels(athoc.iws.channelManager.getSelectedItems().length);
                            tooltip.hide();
                            var model = channelDatasource.view()[rowIdx];
                            //verify model
                            if (model) {
                                athoc.iws.channelManager.isRelease = false;
                                athoc.iws.channelManager.editchannelDetail(model);
                            }
                        }
                    }
                });

                //On Grid row key press navigate to Edit page or View page w.r.t device Type
                $(grid.tbody).on("keypress", "tr", function (e) {

                    var code = e.keyCode || e.which;

                    if (code == 13 && athoc.iws.channelManager.isRelease == true) {
                        athoc.iws.channelManager.searchModel.selectedChannels(athoc.iws.channelManager.getSelectedItems().length);
                        var row = $(this);
                        var rowIdx = $("tr", grid.tbody).index(row);
                        var model = channelDatasource.view()[rowIdx];
                        tooltip.hide();
                        if (model) {
                            athoc.iws.channelManager.isRelease = false;
                            athoc.iws.channelManager.editchannelDetail(model);
                        }

                    }
                });

                grid.tbody.on("change", ".channelManager-select", function (e) {
                    var row = $(e.target).closest("tr");
                    var item = grid.dataItem(row);
                    if (item != undefined) {
                        item.IsChecked = $(e.target).is(":checked");
                        athoc.iws.channelManager.enableSelectAll();
                        athoc.iws.channelManager.updateSelectedTotal();
                        athoc.iws.channelManager.searchModel.selectedChannels(athoc.iws.channelManager.getSelectedItems().length);
                    }
                });

                if (athoc.iws.channelManager.IsRightToLeft) {
                    $("#channelList").find('.pull-right').addClass('pull-left');
                    $("#channelList").find('.pull-right').removeClass('pull-right');
                }
                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(grid.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.channelManager.resources.IWS_Common_NoRecordsFound + '</td></tr>');
                }
            },

            //this function will return the channel ids for the selected rows of grid 
            getSelectedItems: function (selectedItem) {
                ids = new Array();
                var grid = $("#channelList").data("kendoGrid");
                if (grid != undefined) {
                    $.each(grid.dataSource.data(), function (i, item) {
                        if (selectedItem != undefined && item.Channel_Id == selectedItem) {
                            ids.push(item);
                        }
                        else if (item.IsChecked)
                            ids.push(item);
                    });
                }
                return ids;
            },

            //to update channel status
            updateChannelStatus: function (isEnable) {
                var idOfSelectedChannels = athoc.iws.channelManager.getSelectedItems();

                if (idOfSelectedChannels != undefined) {
                    athoc.iws.channelManager.isRelease = true;
                    // call controller to update Folder status.
                    var channelIds = new Array();
                    var isError = false;
                    _.each(idOfSelectedChannels, function (item) {
                        if (!athoc.iws.channelManager.isHavingPermission(item)) {
                            isError = true;
                            athoc.iws.channelManager.warningMsg.HeaderText(athoc.iws.channelManager.resources.Settings_FolderManager_Warning);
                            athoc.iws.channelManager.warningMsg.Message(athoc.iws.channelManager.resources.Settings_FolderManager_Update_Permission);
                            athoc.iws.channelManager.showModalPopup('showGenericMessage');
                            return;

                        }
                        else if ((item.Status == "Enabled" && isEnable == true) || (item.Status == "Disabled" && isEnable == false)) {
                            isError = true;
                            athoc.iws.channelManager.warningMsg.HeaderText(athoc.iws.channelManager.resources.Settings_FolderManager_Warning);
                            athoc.iws.channelManager.warningMsg.Message(athoc.iws.channelManager.resources.Settings_FolderManager_EnableDisable);
                            athoc.iws.channelManager.showModalPopup('showGenericMessage');
                            return;
                        }

                        channelIds.push(item.Channel_Id);

                    });

                    athoc.iws.channelManager.ChannelCriteria.ChannelIds = channelIds;
                    athoc.iws.channelManager.ChannelCriteria.IsEnabled = isEnable;
                    if (!isError && channelIds.length > 0) {
                        var jsonData = { channelCriteria: athoc.iws.channelManager.ChannelCriteria };
                        var dlAjaxOption =
                        {
                            url: athoc.iws.channelManager.urls.UpdateStatus,
                            dataType: "json",
                            type: "post",
                            data: jsonData,
                            success: function (result) {
                                athoc.iws.channelManager.ChannelCriteria.ChannelIds = [];
                                athoc.iws.channelManager.resetSearchCriteria();
                                athoc.iws.channelManager.refreshGrid();
                                athoc.iws.channelManager.clearFilters();
                                athoc.iws.channelManager.listLoad();
                                athoc.iws.channelManager.searchModel.selectedChannels(0);
                            },
                            error: function (e) {
                                $.AjaxLoader.hideLoader();
                                athoc.iws.channelManager.handleError(e);
                            }
                        };
                        var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                        $.ajax(ajaxOptions);
                    }
                };

            },

            //validate the permisstions
            isHavingPermission: function (rowDetails) {

                if (rowDetails) {
                    if (athoc.iws.channelManager.ContextProvider == rowDetails.Provider_Id) {
                        if (athoc.iws.channelManager.IsSysAdmin || athoc.iws.channelManager.IsEnterprises || athoc.iws.channelManager.IsVirtualSysAdmin || rowDetails.IsOwner) {
                            return true;
                        }
                    }
                }
                return false;
            },

            //Select All check boxes in the grid
            selectAllChannels: function (obj) {

                var checked = $('#chkSelectAll').is(':checked');
                var grid = $('#channelList').data().kendoGrid;
                if (!checked) {
                    ids = new Array();

                }
                $.each(grid.dataSource.view(), function (i, item) {
                    item.IsChecked = checked;
                });


                $('#channelList').data().kendoGrid.refresh();
                athoc.iws.channelManager.updateSelectedTotal();

            },

            //check box selection 
            selectChannel: function (obj) {
                var grid = $('#channelList').data().kendoGrid;

                $.each(grid.dataSource.view(), function (i, item) {
                    if (obj.Channel_Id() == item.Channel_Id()) {
                        item.IsChecked = checked;
                    }
                });

                $('#channelList').data().kendoGrid.refresh();
                athoc.iws.channelManager.updateSelectedTotal(true);
            },

            //to update selected count
            updateSelectedTotal: function (isChild) {
                var r = [];
                if (isChild === undefined) {
                    r = $.grep(channelDatasource.data(), function (v) {
                        return v.IsChecked;
                    });
                };

                athoc.iws.channelManager.searchModel.selectedChannels(r.length);
                if (r.length > 0) {
                    $("#btn_delete").removeAttr('disabled');
                }
                else {
                    athoc.iws.channelManager.searchModel.selectedChannels(0);
                    $("#btn_delete").attr('disabled', 'disabled');
                }
            },

            enableSelectAll: function () {
                var items = channelDatasource.view();
                //get the selected items for the current page.
                var r = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                $("#chkSelectAll").prop('checked', false);
                if (r.length > 0 && (items.length == r.length))
                    $("#chkSelectAll").prop('checked', true);
            },

            saveNewChannelDetailsdata: function () {
                athoc.iws.channelManager.editchannelDetail();
            },

            getSelectedGroups: function () {
                var selectedGroups = [];
                return athoc.iws.channelManager.editModel.ChannelGroupPermissions();
                _.each(athoc.iws.channelManager.editModel.ChannelGroupPermissions(), function (item) {

                    if (item.GroupPermissions.isMandatory() || item.GroupPermissions.isDefault()
                        || item.GroupPermissions.isOptional() || item.GroupPermissions.isBlocked()) {
                        selectedGroups.push({
                            ChannelGroups: { GroupId: item.ChannelGroups.GroupId() },
                            GroupPermissions: {
                                isMandatory: item.GroupPermissions.isMandatory(),
                                isDefault: item.GroupPermissions.isDefault(),
                                isOptional: item.GroupPermissions.isOptional(),
                                isBlocked: item.GroupPermissions.isBlocked()
                            }
                        });
                    };
                });

                return selectedGroups;
            },

            validateControls: function () {
                //remove old validation
                $("#editData .warning").each(function () {
                    $(this).parent().remove();
                });
                athoc.iws.channelManager.editModel.ChannelSettings.Name.extend({
                    required: {
                        onlyIf: athoc.iws.channelManager.editModel.isSaveBtnClicked,
                        params: true,
                        message: athoc.iws.channelManager.resources.Settings_FolderManager_folderNameReq
                    },
                    validation: [{
                        validator: athoc.iws.channelManager.lengthValidation,
                        message: athoc.iws.channelManager.resources.Settings_FolderManager_folderNamelimit,
                        params: [this.value, 3, 100]
                    }],


                    pattern: {
                        message: athoc.iws.channelManager.resources.Settings_FolderManager_notAllowedInName + '  :  ? ` ; " < > | ! $ % ( ) = { } , ^',
                        params: "^[^`^!^$^^^%^(^)^=^{^}^,^;^\^:^?^\"^<^>^|]+$"

                    },
                });
                athoc.iws.channelManager.editModel.ChannelSettings.Description.extend({

                    validation: [{
                        validator: athoc.iws.channelManager.lengthValidation,
                        message: athoc.iws.channelManager.resources.Settings_FolderManager_folderDeslimit,
                        params: [this.value, 0, 200]
                    }],
                });
            },

            // This function will check the dependencies.
            dependencyCheckWithAlert: function (noOfAdmin) {

                noOfAdmin = noOfAdmin == undefined ? [] : noOfAdmin;

                var jsonData = { strChannelIds: $.map(athoc.iws.channelManager.bindDeleteObjects.noOfItems(), function (val) { return val.Channel_Id; }).join(',') };
                var dlAjaxOption =
                    {
                        url: athoc.iws.channelManager.urls.ChannelDependecyCheckUrl,
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            if (data.Data.length == 0) {// No dependencies
                                athoc.iws.channelManager.showModalPopup('dialogDeleteConfirm');
                            }
                            else {

                                if (athoc.iws.channelManager.bindDeleteObjects.noOfItems().length != data.Data.length) {
                                    athoc.iws.channelManager.bindDeleteObjects.bodyHeadingMsg(athoc.iws.channelManager.resources.Settings_FolderManager_systemLevelORAlertTempAssociatedDelete.format(((athoc.iws.channelManager.bindDeleteObjects.noOfItems().length + noOfAdmin.length) - (data.Data.length + noOfAdmin.length)), (data.Data.length + noOfAdmin.length)));
                                    var filterItem = athoc.iws.channelManager.bindDeleteObjects.noOfItems();
                                    for (var i = 0; i < data.Data.length; i++) {
                                        filterItem = _.filter(filterItem, function (item) {
                                            return item.Channel_Id != data.Data[i];
                                        });
                                    }

                                    athoc.iws.channelManager.bindDeleteObjects.noOfItems([]);
                                    filterItem = _(filterItem).sortBy(
                                                       function (item) {
                                                           return [item.Name.toLowerCase()];
                                                       });
                                    athoc.iws.channelManager.bindDeleteObjects.noOfItems(filterItem);
                                    athoc.iws.channelManager.showModalPopup('dialogDeleteConfirm');
                                }
                                else {

                                    if (noOfAdmin.length > 0) {
                                        athoc.iws.channelManager.warningMsg.HeaderText(athoc.iws.channelManager.resources.Settings_FolderManager_DeleteConfirmation);
                                        athoc.iws.channelManager.warningMsg.Message(athoc.iws.channelManager.resources.Settings_FolderManager_systemLevelORAlertTempAssociatedDelete1);

                                        athoc.iws.channelManager.showModalPopup('showGenericMessage');//
                                    }
                                    else {
                                        athoc.iws.channelManager.warningMsg.HeaderText(athoc.iws.channelManager.resources.Settings_FolderManager_DeleteConfirmation);
                                        athoc.iws.channelManager.warningMsg.Message(athoc.iws.channelManager.resources.Settings_FolderManager_associatedDelete);

                                        athoc.iws.channelManager.showModalPopup('showGenericMessage');//
                                    }
                                }
                            }
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);

                $.ajax(ajaxOptions);
            },

            // Createing pills when search is done
            createPills: function (value) {
                var found = _.find(athoc.iws.channelManager.searchModel.SearchString, function (item) {
                    return (item == value);
                });
                if (!found) {
                    athoc.iws.channelManager.ChannelCriteria.SearchString.push(value);
                    athoc.iws.channelManager.refreshGrid();
                    athoc.iws.channelManager.listLoad();
                    athoc.iws.channelManager.renderPills();
                }
            },

            // Rendering the pills when search is done
            renderPills: function (css) {
                var self = this;
                var html = "";
                athoc.iws.channelManager.searchModel.htmlPillContent('');
                if (athoc.iws.channelManager.ChannelCriteria.SearchString && athoc.iws.channelManager.ChannelCriteria.SearchString.length > 0) {
                    _.each(athoc.iws.channelManager.ChannelCriteria.SearchString, function (item, index) {
                        var iconCss = "";
                        var prefix = "";
                        var pillLabel = prefix + $.htmlEncode(item);
                        var pillTooltip = prefix + $.htmlEncode(item);
                        var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" href="#"></a>' : '');
                        html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                    });

                    if (html != "") {
                        $(".push").attr("style", 'margin-bottom:0px');
                    };

                    athoc.iws.channelManager.searchModel.htmlPillContent(html);
                    $("#dvFolderSearch .whiteout").removeAttr("style");
                    $("#dvFolderSearch .whiteout").attr("style", "height:" + ($("#dvFolderSearch .whiteout").height() + $("#dvFolderSearch .pill-container").height() + 6) + "px");

                    $("#channelList .k-grid-header").css("margin-top", $("#dvFolderSearch .pill-container").height() + 6);
                    $("#channelList").css("margin-top", $("#dvFolderSearch .pill-container").height() + 6);

                    //wire up events
                    $("#dvFolderSearch .pill-close").click(function (event) {
                        var parentElm = $(this).parent(".pill");
                        athoc.iws.channelManager.deSelect(parentElm.data("index"));
                        event.stopPropagation();
                    });
                }
            },
            // Deleteing the pills

            deSelect: function (index, onSuccess) {
                if (athoc.iws.channelManager.ChannelCriteria.SearchString && athoc.iws.channelManager.ChannelCriteria.SearchString.length > index) {
                    athoc.iws.channelManager.ChannelCriteria.SearchString.splice(index, 1);
                    athoc.iws.channelManager.refreshGrid();
                    athoc.iws.channelManager.listLoad();
                    athoc.iws.channelManager.renderPills();
                }

                if (athoc.iws.channelManager.ChannelCriteria.SearchString && athoc.iws.channelManager.ChannelCriteria.SearchString.length == 0) {
                    athoc.iws.channelManager.searchModel.htmlPillContent('');
                    $("#channelList .k-grid-header").css("margin-top", "0px");
                    $("#channelList").css("margin-top", "0px");
                    $(".push").removeAttr("style");
                    $("#dvFolderSearch .whiteout").removeAttr("style");
                }
            },

            
        };
    }();
}

