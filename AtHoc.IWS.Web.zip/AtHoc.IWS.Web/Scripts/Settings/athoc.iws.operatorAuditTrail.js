﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.OperatorAuditTrail = athoc.iws.OperatorAuditTrail || {};

if (athoc.iws.OperatorAuditTrail) {

    athoc.iws.OperatorAuditTrail = function () {

        return {

            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},
            errors: null,
            // SearchModel to fill the search panel
            searchModel: {
                operators: ko.observableArray(),
                operatorId: ko.observable(""),
                entities: ko.observableArray(),
                selectedEntityId: ko.observable(0),
                attributes: ko.observableArray(),
                selectedAttrIds: ko.observableArray(),
                fromDate: ko.observable(""),
                toDate: ko.observable(""),
                showAttributes: ko.observable(false),
                enableCheckbox: ko.observable(false),
                dateFormate: ko.observable(),
                downLoadExcelUrl: ko.observable("#"),
                isActions: ko.observable(false),
            },
            // To get search attribute to send to controller
            searchCriteria: {
                operatorName: "",
                fromDate: "",
                toDate: "",
                entityId: "",
                actionId: ""
            },
            // EntityModel to fill the dropdown
            entityModel: function () {
                this.ObjectId = ko.observable();
                this.ObjectName = ko.observable();
                this.DisplayControlSetting = ko.observable();
            },
            //init method for scenario list, will be triggered before document load
            init: function () {
                athoc.iws.OperatorAuditTrail.initBreadcrumb();
                navigateToPage('operatorAuditTrail', function () { });
            },
            // Loadning of initial data
            load: function () {
                $("#operatorAuditListContent").hide();
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#loading'), imageURL: athoc.iws.OperatorAuditTrail.urls.cdnUrl + '/Images/ajax-loader.gif', top: '500px', left: '50%', zIndex: 2000, displayText: this.resources.General_LoadingMessage }).showLoader();

                athoc.iws.OperatorAuditTrail.bindBreadcrumb();
                ko.cleanNode($("#searchAudit").get(0));
                athoc.iws.OperatorAuditTrail.searchModel.dateFormate($.vpsDateFormat);
                ko.applyBindings(athoc.iws.OperatorAuditTrail.searchModel, $("#searchAudit").get(0));

                athoc.iws.OperatorAuditTrail.searchModel.selectedEntityId.subscribe(function (newValue) {
                    athoc.iws.OperatorAuditTrail.searchModel.showAttributes(false);
                    athoc.iws.OperatorAuditTrail.searchModel.enableCheckbox(true);
                    $("#specificAction").prop('checked', false);
                    athoc.iws.OperatorAuditTrail.searchModel.isActions(false);
                    athoc.iws.OperatorAuditTrail.searchModel.selectedAttrIds([]);
                    if (newValue == 0) {
                        athoc.iws.OperatorAuditTrail.searchModel.enableCheckbox(false);
                    }
                });

                /*$("#fromDateInput").keyup(function (e) {
                    if (e.key != "Backspace") {
                        var newDate = new Date(moment($("#fromDateInput").val()).format($.vpsDateFormat.toUpperCase()));
                        var now = new Date(moment(new Date()).format($.vpsDateFormat.toUpperCase()));
                        if (newDate > now) {
                            $("#fromDatePicker").data("datetimepicker").setDate(now);
                            athoc.iws.OperatorAuditTrail.searchModel.fromDate(now);
                            $("#fromDateInput").val(now);
                            return;
                        }
                    }
                });*/
                athoc.iws.OperatorAuditTrail.searchModel.fromDate.subscribe(function (newValue) {
                    $('#errorMessagePanel').messagesPanel('reset');
                    var now = new Date(moment(new Date()).format("M/D/YYYY"));
                    var reqError = new Array();
                    if (newValue == null || newValue.length == 0) {
                        $("#toDatePicker").data("datetimepicker").setStartDate(-Infinity);
                        athoc.iws.OperatorAuditTrail.searchModel.fromDate("");
                    } else if (typeof newValue == "string") { //ingore if not dateTime object
                        return;
                    } else {
                        var newDate = moment(newValue);
                        if (newDate.isValid()) {
                            //var newDate = moment(newValue).format("M/D/YYYY");
                            $("#toDatePicker").data("datetimepicker").setStartDate(newValue);
                            $("#toDatePicker").data("datetimepicker").setEndDate(now);
                            //need to convert to datetime object for accurate comparison.
                            var todate = new Date(athoc.iws.OperatorAuditTrail.searchModel.toDate());
                            //when input is typed in and is invalid (from is after to date and vice versa), copy that value. 
                            if (todate < newValue) {
                                $("#toDatePicker").data("datetimepicker").setDate(newValue);
                            }
                        } else {
                            $("#toDatePicker").data("datetimepicker").setStartDate(-Infinity);
                            $("#toDatePicker").data("datetimepicker").setEndDate(now);
                        }
                    }
                });

                athoc.iws.OperatorAuditTrail.searchModel.toDate.subscribe(function (newValue) {
                    $('#errorMessagePanel').html('');
                    if (newValue == null || newValue.length == 0) {
                        //$("#fromDatePicker").data("datetimepicker").setEndDate(Infinity);
                        athoc.iws.OperatorAuditTrail.searchModel.toDate("");
                    } else if (typeof newValue == "string") { //ingore if not dateTime object
                        return;
                    } else {
                        var newDate = moment(newValue);
                        if (newDate.isValid()) {

                            //var newDate = moment(newValue).format("M/D/YYYY");

                            $("#fromDatePicker").data("datetimepicker").setEndDate($.getVPSLocalDateTime(newValue.toDateString()));

                            //need to convert to datetime object for accurate comparison.
                            var fromdate = new Date(athoc.iws.OperatorAuditTrail.searchModel.fromDate());
                            //when input is typed in and is invalid (from is after to date and vice versa), copy that value. 
                            if (fromdate > newValue) {
                                $("#fromDatePicker").data("datetimepicker").setDate(newValue);
                            }
                        } else {
                            // $("#fromDatePicker").data("datetimepicker").setEndDate(Infinity);
                        }
                    }
                });
                athoc.iws.OperatorAuditTrail.getEntities();

                $("#specificAction").click(function () {
                    athoc.iws.OperatorAuditTrail.getActions();
                });

                $("#downloadExcel").click(function () {
                    athoc.iws.OperatorAuditTrail.downloadExcel();
                });

                $("#printFormat").click(function () {
                    athoc.iws.OperatorAuditTrail.printFormat();
                });

                $("#btnSearch").click(function () {
                    athoc.iws.OperatorAuditTrail.setSearchData();
                    athoc.iws.OperatorAuditTrail.refreshGrid();
                });

                $("#Operators").keyup(function (e) {
                    if ($.hotkeys.enter(e)) {
                        athoc.iws.OperatorAuditTrail.searchModel.operatorId(e.currentTarget.value);
                        athoc.iws.OperatorAuditTrail.setSearchData();
                        athoc.iws.OperatorAuditTrail.refreshGrid();
                    }
                });

                athoc.iws.OperatorAuditTrail.initiateDatetimePicker();
                athoc.iws.OperatorAuditTrail.getData();

                var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
                if (gridHeader) {
                    gridHeader.addClass('table-header affix');
                }

                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");

            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.OperatorAuditTrail.breadcrumbModel;

                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.OperatorAuditTrail.resources.Action_Button_Settings, '', function () {
                    window.location.href = "/client/setup/settings";
                });

                //Page breadcrumb
                var viewPageBreadcrumb = new PageBreadcrumb('operatorAuditTrail', athoc.iws.OperatorAuditTrail.resources.Settings_Audit_BreadCrumb, [settingLink], '');
                breadcrumbsModel.addPage(viewPageBreadcrumb);

            },

            // Bind breadcrumb model to the breadcrumb control
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.OperatorAuditTrail.breadcrumbModel;
                breadcrumbsModel.SelectedPage('operatorAuditTrail');
                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },
            // Fill datepickers to default values
            initiateDatetimePicker: function () {
                if (athoc.iws.OperatorAuditTrail.searchModel.fromDate() == "" && athoc.iws.OperatorAuditTrail.searchModel.toDate() == "") {
                    var d = $.vpsTimeZone.CurrentVPSDate;//$.getVPSLocalDateTime(new Date().toDateString() + " " + new Date().toTimeString());
                    var yesd = $.vpsTimeZone.Yesterday;//$.getVPSLocalDateTime(new Date().toDateString() + " " + new Date().toTimeString());
                    //yesd.setDate(d.getDate() - 1);
                    athoc.iws.OperatorAuditTrail.searchModel.fromDate(yesd);
                    athoc.iws.OperatorAuditTrail.searchModel.toDate(d);
                   
                    $("#fromDatePicker").datetimepicker("setDate",  yesd );
                    $("#toDatePicker").datetimepicker("setDate", d ); 
                }
            },
            // Get entities
            getEntities: function () {

                var dlAjaxOption =
                  {
                      url: athoc.iws.OperatorAuditTrail.urls.GetEntities,
                      contentType: "application/json; charset=utf-8",
                      dataType: 'json',
                      type: 'GET',
                      success: function (data) {
                          if (data.Success) {
                              if (data.Data != null) {
                                  var entity = new athoc.iws.OperatorAuditTrail.entityModel();
                                  entity.ObjectId("0");
                                  entity.ObjectName(athoc.iws.OperatorAuditTrail.resources.Settings_Audit_AllEntities);
                                  athoc.iws.OperatorAuditTrail.searchModel.entities.push(entity);
                                  _.each(data.Data, function (obj, index) {
                                      var entity = new athoc.iws.OperatorAuditTrail.entityModel();
                                      entity.ObjectId(obj.ObjectId);
                                      entity.ObjectName(obj.ObjectName);
                                      entity.DisplayControlSetting(obj.DisplayControlSetting)
                                      athoc.iws.OperatorAuditTrail.searchModel.entities.push(entity);
                                  });
                                  $("#operatorAuditListContent").show();
                                  $.AjaxLoader.hideLoader();
                              }

                              $("#Operators").selectpicker();
                              $("#entity").selectpicker();
                              $("#attributes").selectpicker();
                          }
                      },
                      error: function (e) {
                          athoc.iws.OperatorAuditTrail.handleError(e);
                      }

                  };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },
            // Get Actions related to Entity
            getActions: function () {
                var checked = $("#specificAction").is(':checked');
                athoc.iws.OperatorAuditTrail.searchModel.selectedAttrIds("");
                $("#attributes").val("");
                if (checked) {
                    var entityId = athoc.iws.OperatorAuditTrail.searchModel.selectedEntityId();
                    var dataPost = ko.toJSON(entityId);
                    var parameters = {
                        entityId: entityId,
                    };
                    var dlAjaxOption =
                      {
                          url: athoc.iws.OperatorAuditTrail.urls.GetActionsByEntityId,
                          dataType: 'json',
                          type: 'POST',
                          data: parameters,
                          success: function (data) {
                              if (data.Success) {
                                  if (data.Data != null) {
                                      athoc.iws.OperatorAuditTrail.searchModel.attributes(data.Data);
                                      $("#attributes").selectpicker("selectAll");
                                      athoc.iws.OperatorAuditTrail.searchModel.selectedAttrIds($("#attributes").val());
                                      athoc.iws.OperatorAuditTrail.searchModel.showAttributes(true);
                                  }
                              }
                          },
                          error: function (e) {
                              athoc.iws.OperatorAuditTrail.handleError(e);
                          }

                      };
                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                    $.ajax(ajaxOptions);
                    athoc.iws.OperatorAuditTrail.searchModel.showAttributes(true);
                }
                else
                    athoc.iws.OperatorAuditTrail.searchModel.showAttributes(false);
            },
            // Fill search data to send to controller.
            setSearchData: function () {
                athoc.iws.OperatorAuditTrail.searchCriteria.operatorName = athoc.iws.OperatorAuditTrail.searchModel.operatorId();
                athoc.iws.OperatorAuditTrail.searchCriteria.fromDate = athoc.iws.OperatorAuditTrail.searchModel.fromDate().toDateString();//toLocaleDateString();
                athoc.iws.OperatorAuditTrail.searchCriteria.toDate = athoc.iws.OperatorAuditTrail.searchModel.toDate().toDateString();//.toLocaleDateString();
                athoc.iws.OperatorAuditTrail.searchCriteria.entityId = athoc.iws.OperatorAuditTrail.searchModel.selectedEntityId();
                athoc.iws.OperatorAuditTrail.searchCriteria.actionId = athoc.iws.OperatorAuditTrail.searchModel.selectedAttrIds() != "" ? athoc.iws.OperatorAuditTrail.searchModel.selectedAttrIds().join("','") : "";
            },
            // Get Audit data and bind to the grid.
            bindOperatorAuditDetails: function () {
                var sortState = '';
                var url = athoc.iws.OperatorAuditTrail.urls.GetOperatorAuditDetails;
                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.OperatorAuditTrail.searchCriteria);
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                    },
                    requestEnd: function (e) {

                        if (e.response) {

                        }
                    },
                    schema: {
                        data: "Data",
                    },
                    pageSize: 50,
                    error: function (e) {
                        athoc.iws.OperatorAuditTrail.handleError(e);
                    },
                    sort: { field: "Action_TimeStamp", dir: "desc" },
                    change: function (e) {
                        $("html,body").scrollTop(0);
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                        e.preventDefault();
                    }
                });

                $("#pageInfo").kendoPager({
                    dataSource: datasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.OperatorAuditTrail.resources.Settings_Audit_ListPageInfo,
                        empty: athoc.iws.OperatorAuditTrail.resources.AtHoc_Pager_Message_Empty,
                    }
                });

                var grid = $("#operatorAuditList").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    selectable: false,
                    sortable: { allowUnsort: false },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5, messages: {
                            itemsPerPage: $.htmlDecode(athoc.iws.OperatorAuditTrail.resources.AtHoc_Pager_Message_Items_Per_Page),
                            display: $.htmlDecode(athoc.iws.OperatorAuditTrail.resources.Settings_Audit_Itemsdisplay),
                            empty: $.htmlDecode(athoc.iws.OperatorAuditTrail.resources.AtHoc_Pager_Message_Empty),
                            first: $.htmlDecode(athoc.iws.OperatorAuditTrail.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.OperatorAuditTrail.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.OperatorAuditTrail.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.OperatorAuditTrail.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                {
                                    field: "UserName",
                                    title: athoc.iws.OperatorAuditTrail.resources.Settings_Audit_UserName,
                                    template: '<span >#=UserName#</span>',
                                    headerTemplate: kendo.format('<span>{1}</span>', athoc.iws.OperatorAuditTrail.resources.Settings_Audit_UserName, athoc.iws.OperatorAuditTrail.resources.Settings_Audit_UserName),
                                    width: 90,
                                    sortable: false,
                                    headerAttributes: {
                                        tabindex: "240",
                                        style: "cursor:default",
                                    },
                                    attributes: {
                                        style: "cursor:default",
                                    }
                                },
                                {
                                    field: "UserId",
                                    title: athoc.iws.OperatorAuditTrail.resources.Settings_Audit_UserID,
                                    template: '<span >#=UserId#</span>',
                                    headerTemplate: kendo.format('<span>{1}</span>', athoc.iws.OperatorAuditTrail.resources.Settings_Audit_UserID, athoc.iws.OperatorAuditTrail.resources.Settings_Audit_UserID),
                                    width: 70,
                                    sortable: false,
                                    headerAttributes: {
                                        tabindex: "240",
                                        style: "cursor:default",
                                    },
                                    attributes: {
                                        style: "cursor:default",
                                    }
                                },
                                {
                                    field: "Entity_Name",
                                    title: athoc.iws.OperatorAuditTrail.resources.Settings_Audit_Entity,
                                    template: '<span >#=Entity_Name#</span>',
                                    headerTemplate: kendo.format('<span>{1}</span>', athoc.iws.OperatorAuditTrail.resources.Settings_Audit_Entity, athoc.iws.OperatorAuditTrail.resources.Settings_Audit_Entity),
                                    width: 100,
                                    sortable: false,
                                    headerAttributes: {
                                        tabindex: "240",
                                        style: "cursor:default",
                                    },
                                    attributes: {
                                        style: "cursor:default",
                                    }
                                },
                                {
                                    field: "Action_Name",
                                    title: athoc.iws.OperatorAuditTrail.resources.Settings_Audit_Action,
                                    template: '<span >#=Action_Name#</span>',
                                    headerTemplate: kendo.format('<span>{1}</span>', athoc.iws.OperatorAuditTrail.resources.Settings_Audit_Action, athoc.iws.OperatorAuditTrail.resources.Settings_Audit_Action),
                                    width: 100,
                                    sortable: false,
                                    headerAttributes: {
                                        tabindex: "240",
                                        style: "cursor:default",
                                    },
                                    attributes: {
                                        style: "cursor:default",
                                    }
                                },
                                {
                                    field: "Object_Name",
                                    title: athoc.iws.OperatorAuditTrail.resources.Settings_Audit_ObjectName,
                                    template: '<span >#=Object_Name#</span>',
                                    headerTemplate: kendo.format('<span>{1}</span>', athoc.iws.OperatorAuditTrail.resources.Settings_Audit_ObjectName, athoc.iws.OperatorAuditTrail.resources.Settings_Audit_ObjectName),
                                    width: 90,
                                    sortable: false,
                                    headerAttributes: {
                                        tabindex: "240",
                                        style: "cursor:default",
                                    },
                                    attributes: {
                                        style: "cursor:default",
                                    }
                                },
                                 {
                                     field: "Action_TimeStamp",
                                     title: athoc.iws.OperatorAuditTrail.resources.Settings_Audit_Timestamp,
                                     template: '<span>#=Action_TimeStamp_Display#</span>',
                                     headerTemplate: kendo.format('<span>{1}</span>', athoc.iws.OperatorAuditTrail.resources.Settings_Audit_Timestamp, athoc.iws.OperatorAuditTrail.resources.Settings_Audit_Timestamp),
                                     width: 105,
                                     headerAttributes: {
                                         tabindex: "240",
                                         style: "cursor:default",
                                     },
                                     attributes: {
                                         style: "cursor:default",
                                     }
                                 },

                            ],
                    dataBound: athoc.iws.OperatorAuditTrail.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                        this.select().removeClass("k-state-selected");
                    }
                }).data().kendoGrid;
                // to allow preventing the tooltip from being shown
                kendo.ui.Tooltip.fn._show = function (show) {
                    return function (target) {
                        var e = {
                            sender: this,
                            target: target,
                            preventDefault: function () {
                                this.isDefaultPrevented = true;
                            }
                        };

                        if (typeof this.options.beforeShow === "function") {
                            this.options.beforeShow.call(this, e);
                        }
                        if (!e.isDefaultPrevented) {
                            show.call(this, target);
                        }
                    };
                }(kendo.ui.Tooltip.fn._show);
                // Kendo tooltip for cells
                var audioNameToolTip = $("#operatorAuditList").kendoTooltip({
                    filter: "td",
                    beforeShow: function (e) {
                        //if (e.target.context.offsetWidth == e.target.context.scrollWidth)
                        //    e.preventDefault();

                        var $this = $(e.target);
                        var $c = $this
                                    .clone()
                                    .css({ display: 'inline', width: 'auto', visibility: 'hidden' })
                                    .appendTo('body');
                        var c_width = $c.width();
                        $c.remove();
                        if (c_width < $this.width())
                            e.preventDefault();
                    },
                    content: function (e) {
                        //var dataItem = $("#operatorAuditList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        //if (e.target.context.offsetWidth < e.target.context.scrollWidth)
                            return $(e.target).text();

                    }
                }).data("kendoTooltip");

                athoc.iws.OperatorAuditTrail.refreshGrid();
                $(document).scrollTop(0);
            },
            //  Refresh grid when modifying search details
            refreshGrid: function () {
                datasource.one("change", function () {
                    //pagination needs to be reset after a reload
                    this.page(1);
                });
                datasource.read();
            },

            OnDataBound: function (e) {
                var grid = $("#operatorAuditList").data("kendoGrid");
                if (grid.dataSource._data.length == 0) {
                    var colCount = grid.columns.length;
                    $(e.sender.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.OperatorAuditTrail.resources.IWS_Common_NoRecordsFound + '</td></tr>');
                }
            },
            // Clearing the search data and fill with default data
            clearAll: function () {
                athoc.iws.OperatorAuditTrail.searchModel.fromDate("");
                athoc.iws.OperatorAuditTrail.searchModel.toDate("");
                athoc.iws.OperatorAuditTrail.initiateDatetimePicker();
                athoc.iws.OperatorAuditTrail.searchModel.operatorId("");
                athoc.iws.OperatorAuditTrail.searchModel.selectedEntityId(0);
                athoc.iws.OperatorAuditTrail.searchModel.enableCheckbox(false);
                athoc.iws.OperatorAuditTrail.searchModel.showAttributes(false);
                athoc.iws.OperatorAuditTrail.searchModel.selectedAttrIds([]);
                athoc.iws.OperatorAuditTrail.searchModel.isActions(false);
                athoc.iws.OperatorAuditTrail.setSearchData();
                athoc.iws.OperatorAuditTrail.refreshGrid();
            },
            // Get audit data 
            getData: function () {
                athoc.iws.OperatorAuditTrail.setSearchData();
                athoc.iws.OperatorAuditTrail.bindOperatorAuditDetails();
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
            },
            // Get data in excel
            downloadExcel: function () {
                var rows = "";
                rows += athoc.iws.OperatorAuditTrail.resources.Settings_Audit_ExcelHeadings + '\n';
                var dataRows = datasource.data();
                for (var i = 0; i < dataRows.length; i++) {
                    var dataItem = dataRows[i];
                    rows += '"' + dataItem.Action_TimeStamp + '","' + dataItem.provider_id + '","' + dataItem.UserId + '","' + dataItem.UserName + '","' + dataItem.Action_Name + '","' + dataItem.Entity_Name + '","' + dataItem.Object_Id + '","' + dataItem.Object_Name + '","' + dataItem.Client_IP + '","' + dataItem.Source + '","' + dataItem.Server_Name + '","' + dataItem.FromEntity_Id + '","' + dataItem.FromEntity_Name + '","' + dataItem.FromObject_Id + '","' + dataItem.FromObject_Name + '","' + dataItem.AdditionalInfo + '"';
                    rows += '\n';
                }
                var csvfileName = athoc.iws.OperatorAuditTrail.resources.Settings_Audit_ExcelFileName + ".csv";

                var blob = new Blob([rows], { type: 'text/csv;charset=utf-8' });
                saveAs(blob, csvfileName);
            },
            // Get Print friendly report.
            printFormat: function () {
                var data = athoc.iws.OperatorAuditTrail.searchCriteria;
                var entityName = "";
                var actions = "";
                athoc.iws.OperatorAuditTrail.setSearchData();
                if (data.entityId == 0)
                    entityName = athoc.iws.OperatorAuditTrail.resources.Settings_Audit_AllEntities;
                else
                    entityName = $("#entity option:selected").text();

                if (data.actionId != "")
                    $("#attributes option:selected").each(function (i, t) { actions += $(t).text() + "," })

                var url = "OperatorAuditTrail/AuditPrintReport?operatorName=" + data.operatorName + "&fromDate=" + data.fromDate + "&toDate=" + data.toDate + "&entityId=" + data.entityId + "&actionId=" + data.actionId + "&entityName=" + entityName + "&actions=" + actions;
                window.open(url);
            },
            // Handling errors
            handleError: function (e) {

                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;

                } else if (e.errorThrown != "") {
                    if (athoc.iws.OperatorAuditTrail.errors === null) {
                        athoc.iws.OperatorAuditTrail.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.OperatorAuditTrail.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#errorMessagePanel').messagesPanel({ messages: this.errors });
                }
            },

        };
    }();

}