﻿
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
if (athoc.iws) {
    
    athoc.iws.disabledeleteendusers = function () {
        var isSearched = false;
        var DisableTimeOut;
        var DeleteTimeOut;
        var timeInterval = 10000;
        var disableNowInProgress = false;
        var deleteNowInProgress = false;
       
        return {
            pageName_divDisableDeleteEndUsers: "divDisableDeleteEndUsers",
            disableDivQueryBuilder: "queryBuilderDisableDiv",
            deleteDivQueryBuilder: "queryBuilderDeleteDiv",
            EndUsersPageSize: 50,
            EndUsersPage: 1,
            searchString: [],
            columnDefs: null,
            gridColumnDefs: null,
            EndUsersSortColumn: 'LOGIN_ID',
            EndUsersSortOrder: 'asc',
            EndUsersSortField: '_LOGIN_ID',
            EndUsersDatasource: null,
            EndUsersgrid: null,
            isChanged: false,
            isCancelClicked: false,
            isDowlLoadClick: false,
            errors: [],
            errorTitleStrings: [],


            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for scenario list, will be triggered before document load
            init: function () {
                athoc.iws.disabledeleteendusers.initBreadcrumb();
            },

            //DisableDelete View Model 
            DisableDeleteEndUsersSpec: {

                totalUserToDisableToCount: ko.observable(-1),
                IsCheckedForDisable: ko.observable(false),
                nextDisableExecutionTime: ko.observable(),
                lastDisableExecutionTime: ko.observable(),
                checkDisableSelection: ko.observable(false),
                DisableJobAuditID: ko.observable(0),
                showDisableUserList: ko.observable(true),
                isFromDisable: ko.observable(true),
                disableInterval: ko.observable(),
                IsCheckedForDisable: ko.observable(false),
                DownloadExcelForDisableURL: ko.observable("#"),
                TargetDisableModel: ko.observable(),
                UserName: ko.observable(),
                DisableDynamicCriteria: ko.observable({ display: [], selections: [] }),
                LastDisableExecutionStatus: ko.observable(''),
                disableExecutionStatus: ko.observable(''),
                chkDsTitle: ko.observable(''),

                totalUserToDeleteToCount: ko.observable(-1),
                IsCheckedForDelete: ko.observable(false),
                nextDeleteExecutionTime: ko.observable(),
                lastDeleteExecutionTime: ko.observable(),
                checkDeleteSelection: ko.observable(false),
                DeleteJobAuditID: ko.observable(0),
                showDeleteUserList: ko.observable(true),
                deleteInterval: ko.observable(),
                DownloadExcelForDeleteURL: ko.observable("#"),
                TargetDeleteModel: ko.observable(),
                DeleteDynamicCriteria: ko.observable({ display: [], selections: [] }),
                LastDeleteExecutionStatus: ko.observable(''),
                deleteExecutionStatus: ko.observable(''),
                chkDlTitle: ko.observable(''),
                actionType: ko.observable(""),


                PurgeUsersModel: {
                    IsUserPurgedRequest: ko.observable(false),
                    SelectedPurgeDuration: ko.observable(),
                    availablePurgeDurations: ko.observableArray(),
                },

                //model used to search the users
                SearchEndUsersCriteriaModel: {
                    showList: true,
                    isfromDisable: false,
                    searchString: [],
                    sortBy: "USER_ID",
                    sortOrder: "ASC",
                    page: 1,
                    pageSize: "",
                    searchModel: "",
                },
                //Method used to hit for search and get the users detail and count calls from search popup and main screen as well
                getDisableEndUsersDetail: function () { athoc.iws.disabledeleteendusers.getDisableEndUsersDetail(false); },

                //Method used to hit for search and get the users detail and count calls from search popup and main screen as well
                getDeleteEndUsersDetail: function () { athoc.iws.disabledeleteendusers.getDeleteEndUsersDetail(false); },

                //Showing popup of search users on showlist click
                showDisableEndUserList: function () { athoc.iws.disabledeleteendusers.showUserList(athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Disable_Popup_Title, true); },
                //Showing popup of search users on showlist click
                showDeleteEndUserList: function () { athoc.iws.disabledeleteendusers.showUserList(athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Delete_Popup_Title, false); },



            },
            //search model
            searchModel: {
                selectedEndUsersCount: ko.observable(0),
                searchString: ko.observable(""),
                SearchDisabled: ko.observable(),
                searchCriteria: ko.observable(""),
                availableEndUsers: ko.observableArray(),
                targetedEndUsers: ko.observableArray(),
                IsEndUsersChecked: ko.observable(false),
            },


            //load method, will be tirggered on document load
            load: function () {

                //To fill the Message popup title strings from resource for errors 
                athoc.iws.disabledeleteendusers.errorTitleStrings.push(athoc.iws.disabledeleteendusers.resources.IWS_CommonErrMsg_Title_Information);
                athoc.iws.disabledeleteendusers.errorTitleStrings.push(athoc.iws.disabledeleteendusers.resources.IWS_CommonErrMsg_Title_Warning);
                athoc.iws.disabledeleteendusers.errorTitleStrings.push(athoc.iws.disabledeleteendusers.resources.IWS_CommonErrMsg_Title_Error);
                athoc.iws.disabledeleteendusers.errorTitleStrings.push(athoc.iws.disabledeleteendusers.resources.IWS_CommonErrMsg_Title_Success);
                athoc.iws.disabledeleteendusers.errorTitleStrings.push(athoc.iws.disabledeleteendusers.resources.IWS_CommonErrMsg_Title_Completed);

                //Loading of Breadcrumb
                athoc.iws.disabledeleteendusers.bindBreadcrumb();

                //Binding  page
                ko.cleanNode($("#" + athoc.iws.disabledeleteendusers.pageName_divDisableDeleteEndUsers).get(0));
                ko.applyBindings(athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec, $("#" + athoc.iws.disabledeleteendusers.pageName_divDisableDeleteEndUsers).get(0));

                //Getting the previous saved records on load
                athoc.iws.disabledeleteendusers.getInitailDatatoLoad();

                //button events!

                $("#downloadExcelforDisable").click(function () {
                    athoc.iws.disabledeleteendusers.exportDisableUsersData();
                });

                $("#downloadExcelforDelete").click(function () {
                    athoc.iws.disabledeleteendusers.exportDeleteUsersData();
                });

                $("#btn_disable").click(function () {
                    athoc.iws.disabledeleteendusers.disableUsers();
                });

                $("#btn_delete").click(function () {
                    athoc.iws.disabledeleteendusers.deleteUsers();
                });

                $("#btn_Cancel").click(function () {
                    athoc.iws.disabledeleteendusers.cancelEndUsers();
                });

                $("#btn_Save").click(function () {

                    athoc.iws.disabledeleteendusers.saveEndUsers();

                });

                ///ok click on modal message
                $('#dlgUserSelection .btn.btn-large.btn-default').on('click', function (e) {
                    athoc.iws.disabledeleteendusers.hideMessage();
                    $('#dlgUserSelection').modal('hide');
                    //if (athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.isFromDisable())
                    //    $("#btn_disable").focus();
                    //else
                    //    $("#btn_delete").focus();
                   
                   
                });
                window.onbeforeunload = function () {
                    var isValueChanged = false;
                    if (!athoc.iws.disabledeleteendusers.isCancelClicked)
                        isValueChanged = true;
                    if (athoc.iws.disabledeleteendusers.isDowlLoadClick)
                        isValueChanged = false;

                    if (isValueChanged) {
                        var isModified = athoc.iws.disabledeleteendusers.isChanged;
                        if (isModified) {
                            return athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Unsaved_Data_Text;
                        } else {
                            $(window).scrollTop(0);
                        }
                    }
                };
            },

            //bindindg the properties after queryload
            bind: function (data) {
                //AdvanceSearch to  loads the querybuilder
                athoc.iws.disabledeleteendusers.loadUserAdvanceSearch();
                athoc.iws.disabledeleteendusers.SetModel(data);
                athoc.iws.disabledeleteendusers.subscribeChanges();

                $('#btn_Cancel').keydown(function (e) {
                    if (e.keyCode === 9) {
                        e.preventDefault();
                        $(document).scrollTop(0);
                        athoc.iws.disabledeleteendusers.setFocus();
                    }
                });
                
                $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).find("#criteriaContainer").find("#addConditionLink").bind('click', function (e) {
                    //e.preventDefault();
                    $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).find("#criteriaContainer").find("#addConditionLink").focus();
                });
                $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).find("#criteriaContainer").find("#addConditionLink").bind('click', function (e) {
                    //e.preventDefault();
                    $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).find("#criteriaContainer").find("#addConditionLink").focus();
                });
            },

            ///setting the save and last run criteria on load
            SetModel: function (data) {

                //Set Disable Model Values
                var disablemodel = data.DisableInformation;
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.lastDisableExecutionTime(disablemodel.EndUsersDisableDeleteModel.LastJobExecutionTime);
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.nextDisableExecutionTime(disablemodel.EndUsersDisableDeleteModel.NextJobExecutionTime);
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableJobAuditID(disablemodel.EndUsersDisableDeleteModel.AuditId);
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.disableInterval(disablemodel.EndUsersDisableDeleteModel.Interval);

                if (disablemodel.EndUsersDisableDeleteModel.LastExecutionStatus != null) {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDisableExecutionStatus(
                        athoc.iws.disabledeleteendusers.replaceStatusText(disablemodel.EndUsersDisableDeleteModel.LastExecutionStatus.toUpperCase()));
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.disableExecutionStatus(disablemodel.EndUsersDisableDeleteModel.LastExecutionStatus.toUpperCase());
                }
                else {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDisableExecutionStatus(disablemodel.EndUsersDisableDeleteModel.LastExecutionStatus);
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.disableExecutionStatus(disablemodel.EndUsersDisableDeleteModel.LastExecutionStatus);
                }

                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.IsCheckedForDisable(disablemodel.IsCheckedForDisable);
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount(-1);
                disableNowInProgress = disablemodel.EndUsersDisableDeleteModel.LastExecutionStatus != null && disablemodel.EndUsersDisableDeleteModel.LastExecutionStatus.toUpperCase() == "IPC" ? true : false;
                athoc.iws.disabledeleteendusers.updateTargetCriteriaforDisable(null);

                //Set Delete Model Values
                var deletemodel = data.DeleteInformation;
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.lastDeleteExecutionTime(deletemodel.EndUsersDisableDeleteModel.LastJobExecutionTime)
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.nextDeleteExecutionTime(deletemodel.EndUsersDisableDeleteModel.NextJobExecutionTime)
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteJobAuditID(deletemodel.EndUsersDisableDeleteModel.AuditId)
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.deleteInterval(deletemodel.EndUsersDisableDeleteModel.Interval);

                if (deletemodel.EndUsersDisableDeleteModel.LastExecutionStatus != null) {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDeleteExecutionStatus(
                        athoc.iws.disabledeleteendusers.replaceStatusText(deletemodel.EndUsersDisableDeleteModel.LastExecutionStatus.toUpperCase()));
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.deleteExecutionStatus(deletemodel.EndUsersDisableDeleteModel.LastExecutionStatus.toUpperCase());
                }
                else {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDeleteExecutionStatus(deletemodel.EndUsersDisableDeleteModel.LastExecutionStatus);
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.deleteExecutionStatus(deletemodel.EndUsersDisableDeleteModel.LastExecutionStatus);
                }
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.IsCheckedForDelete(deletemodel.IsCheckedForDelete)
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDeleteToCount(-1);
                deleteNowInProgress = deletemodel.EndUsersDisableDeleteModel.LastExecutionStatus != null && deletemodel.EndUsersDisableDeleteModel.LastExecutionStatus.toUpperCase() == "IPC" ? true : false;
                athoc.iws.disabledeleteendusers.updateTargetCriteriaforDelete(null);

                //Set Purge Model Values
                var purgemodel = data.PurgeInformation;
                //Setting purge dropdown
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.PurgeUsersModel.availablePurgeDurations(purgemodel.PurgeUsersModel.PurgeDurationList);
                $('.selectpicker').selectpicker();

                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.PurgeUsersModel.IsUserPurgedRequest(purgemodel.PurgeUsersModel.IsUserPurgedRequest);
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.PurgeUsersModel.SelectedPurgeDuration(purgemodel.PurgeUsersModel.SelectedPurgeDuration)

                athoc.iws.disabledeleteendusers.changeScreenControlStatus();

            },

            //getting the disaled users details
            getDisableEndUsersDetail: function (isDisableNowClick) {

                athoc.iws.disabledeleteendusers.hideMessage();
                $("#CalculatedsbSpan").removeClass("hide");
                if (!disableNowInProgress && (!athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableDynamicCriteria().selections || athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableDynamicCriteria().selections.length > 0)) {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.showList = false;
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.isfromDisable = true;
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.searchModel = athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableDynamicCriteria();
                    var model = ko.mapping.fromJS(athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec);
                    $.AjaxLoader.setup({ useBlock: true, idToShow: $("#uniquedisableDiv"), elementToBlock: $('.title-bar'), imageURL: athoc.iws.disabledeleteendusers.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.disabledeleteendusers.resources.General_LoadingMessage }).showLoader();
                    var myAjaxOptions = {
                        url: athoc.iws.disabledeleteendusers.urls.GetEndUsersDetailUrl,
                        contentType: 'application/json',
                        dataType: 'json',
                        type: 'POST',
                        data: ko.toJSON(model),
                        success: function (data) {
                            if (data.Success) {
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount(data.UserCount);
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.UserName(data.UserName);
                                if (isDisableNowClick)
                                    athoc.iws.disabledeleteendusers.disableEndUsers();
                            }
                            else {
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages }, undefined, undefined, undefined, athoc.iws.disabledeleteendusers.errorTitleStrings);
                                $(document).scrollTop(0);
                            }
                            $.AjaxLoader.hideLoader();


                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.disabledeleteendusers.handleError(e);
                        }

                    };
                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                    $.ajax(ajaxOptions);
                }
            },

            //getting the deleted users details
            getDeleteEndUsersDetail: function (isDeleteNowClick) {
                athoc.iws.disabledeleteendusers.hideMessage();
                $("#CalculatedelSpan").removeClass("hide");

                if (!deleteNowInProgress && (!athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteDynamicCriteria().selections || athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteDynamicCriteria().selections.length > 0)) {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.showList = false;
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.isfromDisable = false;
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.searchModel = athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteDynamicCriteria();
                    var model = ko.mapping.fromJS(athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec);

                        $.AjaxLoader.setup({ useBlock: true, idToShow: $("#uniquedisableDiv"), elementToBlock: $('.title-bar'), imageURL: athoc.iws.disabledeleteendusers.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.disabledeleteendusers.resources.General_LoadingMessage }).showLoader();
                    var myAjaxOptions = {
                        url: athoc.iws.disabledeleteendusers.urls.GetEndUsersDetailUrl,
                        contentType: 'application/json',
                        dataType: 'json',
                        type: 'POST',
                        data: ko.toJSON(model),
                        success: function (data) {
                            if (data.Success) {
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDeleteToCount(data.UserCount);
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.UserName(data.UserName);
                                if (isDeleteNowClick)
                                    athoc.iws.disabledeleteendusers.deleteEndUsers();
                            }
                            else {
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages }, undefined, undefined, undefined, athoc.iws.disabledeleteendusers.errorTitleStrings);
                                $(document).scrollTop(0);
                            }
                            $.AjaxLoader.hideLoader();


                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.disabledeleteendusers.handleError(e);
                        }

                    };
                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                    $.ajax(ajaxOptions);
                }
            },

            //Showing popup of search users on showlist click
            showUserList: function (title, isFromDisable) {
                athoc.iws.disabledeleteendusers.hideMessage();
                $("#DisableDeleteEndUserdgrid").html('');
                athoc.iws.disabledeleteendusers.searchString.length = 0;
                var $disableTitle = $('#userslist #TitleCaption');
                $disableTitle.html(title);
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.isFromDisable(isFromDisable);
                var result = athoc.iws.disabledeleteendusers.createEndUsersGrid(isFromDisable);
                if (result != 0) {
                    $("#txtSearch").val("");
                    $("#btn_userSearch").attr("disabled", "disabled");
                    athoc.iws.disabledeleteendusers.resizeModalBasedOnScreen($("#userslist"));
                    $('#userslist').modal('show');
                    athoc.iws.disabledeleteendusers.fitHeighEndUserList();
                    $.AjaxLoader.hideLoader();
                }
            },

            //subscriber for screen/model propertis changes
            subscribeChanges: function () {
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.IsCheckedForDisable.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        athoc.iws.disabledeleteendusers.isChanged = true;
                        athoc.iws.disabledeleteendusers.hideMessage();
                    }
                });

                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.IsCheckedForDelete.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        athoc.iws.disabledeleteendusers.isChanged = true;
                        athoc.iws.disabledeleteendusers.hideMessage();
                    }
                });

                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.PurgeUsersModel.SelectedPurgeDuration.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        athoc.iws.disabledeleteendusers.isChanged = true;
                        athoc.iws.disabledeleteendusers.hideMessage();
                    }
                });



                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.PurgeUsersModel.IsUserPurgedRequest.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        athoc.iws.disabledeleteendusers.isChanged = true;
                        athoc.iws.disabledeleteendusers.hideMessage();
                        if ($.trim(newValue) == "true")
                            $('.selectpicker').attr('disabled', false).selectpicker('refresh');
                        else
                            $('.selectpicker').attr('disabled', true).selectpicker('refresh');

                    }
                });

            },

            //load advance search option for query builder
            loadUserAdvanceSearch: function () {
                $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).athocQueryBuilder({
                    options: {
                        queryBuilderDiv: "#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder,
                        hideGeolocation: true,
                        i18n: athoc.iws.disabledeleteendusers.resources.AtHoc_User_Criteria,
                        title: athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_AtHoc_User_Search_Create_Conditions,
                        cdnUrl: athoc.iws.disabledeleteendusers.urls.cdnUrl,
                        startTabIndex: 20000,
                        dateFormat: $.vpsDateFormat,
                        dateTimeFormat: $.vpsDateTimeFormat,
                        utcOffsetInMinutes: $.vpsTimeZone.UtcOffsetInMinutes,
                        vpsOffsetFromSystemInMinutes: $.vpsTimeZone.VPSOffsetFromSystemInMinutes,
                        hierarchySelectorTagId: "publishingHierarchySelectorPopup",
                        style_span3: "span2",
                        style_add_criteria: "mar-left10 selectpicker",
                        style_select_picker_left: "0",
                        style_select_picker_top: "-3",
                        showAlertEntity: false,
                        AutoDisableDeleteUser: true,
                        hideGeolocation: true,

                    }

                });

                $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).athocQueryBuilder({
                    options: {
                        queryBuilderDiv: "#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder,
                        hideGeolocation: true,
                        i18n: athoc.iws.disabledeleteendusers.resources.AtHoc_User_Criteria,
                        title: athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_AtHoc_User_Search_Create_Conditions,
                        cdnUrl: athoc.iws.disabledeleteendusers.urls.cdnUrl,
                        startTabIndex: 25000,
                        dateFormat: $.vpsDateFormat,
                        dateTimeFormat: $.vpsDateTimeFormat,
                        utcOffsetInMinutes: $.vpsTimeZone.UtcOffsetInMinutes,
                        vpsOffsetFromSystemInMinutes: $.vpsTimeZone.VPSOffsetFromSystemInMinutes,
                        hierarchySelectorTagId: "publishingHierarchySelectorPopup",
                        style_span3: "span2",
                        //style_add_criteria: "mar-left10",
                        style_select_picker_left: "0",
                        style_select_picker_top: "-3",
                        AutoDisableDeleteUser: true,
                        hideGeolocation: true,


                    }

                });

                $("#publishingHierarchySelectorPopup").athocEntitySelectorPopup({
                    i18n: athoc.iws.disabledeleteendusers.resources.AtHoc_User_Criteria,
                    title: athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_User_Criteria_Builder_Select_Hierarchy,
                    isHierarchySelector: true,
                    showSummary: true,
                    cdnUrl: athoc.iws.disabledeleteendusers.urls.cdnUrl,
                    startTabIndex: 25000,
                    onApplyClick: function (selections) {
                        //$("#query-search-popup-container").find("#groupSelectorContent").modal("show");
                    },
                    applyPreselectionViaLineage: true,
                    hierarchyContext: athoc.iws.disabledeleteendusers.resources.HierarchyContext,
                });

                athoc.iws.disabledeleteendusers.setAdvanceCriteria();

                $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).find("#addConditionLink").removeAttr("disabled", "disabled");

            },

            //setting the dynamic query advance criteria for disable/delete
            setAdvanceCriteria: function () {

                var onDisableShown = function (queryDivSelector) {
                    return function () {
                        var tempCriteria = $(queryDivSelector).athocQueryBuilder("getCurrentSelections");
                        athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableDynamicCriteria(tempCriteria);
                        $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).find("#addConditionLink").removeAttr("disabled", "disabled");
                        if (disableNowInProgress)
                            athoc.iws.disabledeleteendusers.updateTargetCriteriaforDisable(null);
                        else
                            athoc.iws.disabledeleteendusers.updateTargetCriteriaforDisable(tempCriteria);
                        athoc.iws.disabledeleteendusers.setFocus();
                        athoc.iws.disabledeleteendusers.setDisableTabbing();

                    };
                }($("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder));
                $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).athocQueryBuilder("setOnShownFunction", onDisableShown);

                var onDisableChanged = function (queryDivSelector) {
                    return function () {
                        //update 
                        var tempCriteria = $(queryDivSelector).athocQueryBuilder("getCurrentSelections");
                        if (!athoc.iws.disabledeleteendusers.isQueryCriteriaEqual(tempCriteria, athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableDynamicCriteria())) {
                            athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount(-1);
                            athoc.iws.disabledeleteendusers.isChanged = true;
                          
                        }
                        athoc.iws.disabledeleteendusers.hideMessage();
                        athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableDynamicCriteria(tempCriteria);
                        $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).find("#addConditionLink").removeAttr("disabled", "disabled");
                        if (disableNowInProgress)
                            athoc.iws.disabledeleteendusers.updateTargetCriteriaforDisable(null);
                        else
                            athoc.iws.disabledeleteendusers.updateTargetCriteriaforDisable(tempCriteria);
                        //athoc.iws.disabledeleteendusers.setFocus();
                    };

                }($("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder));

                $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).athocQueryBuilder("setOnChangedFunction", onDisableChanged);

                $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).athocQueryBuilder("setPreselections", athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableDynamicCriteria().selections);
                $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).athocQueryBuilder("show");
                $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).find("#criteriaContainer").removeClass('cond-panel-content height200');
                $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).find("#criteriaContainer #selectedGroup").removeClass('mar-top-neg8');
                $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).find(".modal-desc").attr("style", "display:none");


                var onDeleteShown = function (queryDivSelector) {
                    return function () {
                        var tempCriteria = $(queryDivSelector).athocQueryBuilder("getCurrentSelections");
                        athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteDynamicCriteria(tempCriteria);
                        $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).find("#addConditionLink").removeAttr("disabled", "disabled");
                        if (deleteNowInProgress)
                            athoc.iws.disabledeleteendusers.updateTargetCriteriaforDelete(null);
                        else
                            athoc.iws.disabledeleteendusers.updateTargetCriteriaforDelete(tempCriteria);
                        athoc.iws.disabledeleteendusers.setFocus();
                        athoc.iws.disabledeleteendusers.setDeleteTabbing();
                        $.AjaxLoader.hideLoader();
                    };
                }($("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder));
                $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).athocQueryBuilder("setOnShownFunction", onDeleteShown);


                var onDeleteChanged = function (queryDivSelector) {
                    return function () {
                        //update 
                        var tempCriteria = $(queryDivSelector).athocQueryBuilder("getCurrentSelections");
                        if (!athoc.iws.disabledeleteendusers.isQueryCriteriaEqual(tempCriteria, athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteDynamicCriteria())) {
                            athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDeleteToCount(-1);
                            athoc.iws.disabledeleteendusers.isDeleteChanged = true;
                            
                        }
                        athoc.iws.disabledeleteendusers.hideMessage();
                        athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteDynamicCriteria(tempCriteria);
                        $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).find("#addConditionLink").removeAttr("disabled", "disabled");
                        if (deleteNowInProgress)
                            athoc.iws.disabledeleteendusers.updateTargetCriteriaforDelete(null);
                        else
                            athoc.iws.disabledeleteendusers.updateTargetCriteriaforDelete(tempCriteria);
                        //athoc.iws.disabledeleteendusers.setFocus();

                    };
                }($("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder));

                $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).athocQueryBuilder("setOnChangedFunction", onDeleteChanged);
                $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).athocQueryBuilder("setPreselections", athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteDynamicCriteria().selections);
                $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).athocQueryBuilder("show");
                $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).find("#criteriaContainer").removeClass('cond-panel-content height200');
                $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).find(".modal-desc").attr("style", "display:none");

            },

            setFocus: function () {
            $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).find("#criteriaContainer").find("#s2id_autogen43").find(".ie-hack").focus();
            },

            setDisableTabbing:function()
            {
                var tabIndex = $("#" + athoc.iws.disabledeleteendusers.disableDivQueryBuilder).find("#criteriaContainer").find("#addConditionLink").attr('tabindex');
                if (tabIndex > 0) {
                    // $("#dvDisable").attr('tabIndex', ++tabIndex)
                    $("#dvDisable").find('input,a').each(function () {
                        if ($(this).attr('id') != undefined && $(this).attr('id') != "addConditionLink") {
                            tabIndex++;
                            if ($(this).attr('id') == "btn_disable") {
                                var n = tabIndex;
                                $(this).attr('tabindex', n + 10)
                            }
                            else
                                $(this).attr('tabindex', tabIndex)
                        }
                    });
                }
            },
            setDeleteTabbing:function()
            {
                var tabIndex = $("#" + athoc.iws.disabledeleteendusers.deleteDivQueryBuilder).find("#criteriaContainer").find("#addConditionLink").attr('tabindex');
                var ControlTabIndex = tabIndex;

                if (tabIndex > 0) {
                    $("#dvDelete").find('input, a').each(function () {
                        if ($(this).attr('id') != undefined && $(this).attr('id') != "addConditionLink") {
                            tabIndex++;
                            if ($(this).attr('id') == "btn_delete") {
                                var n = tabIndex;
                                $(this).attr('tabindex', n + 8);
                            }
                            else
                                $(this).attr('tabindex', tabIndex);
                        }
                        ControlTabIndex = tabIndex;
                    });
                }
                
                ControlTabIndex = ControlTabIndex + 10;
                $("#dvPurge").find('input, select, button').each(function () {
                    $(this).attr('tabindex', ControlTabIndex++);
                });
                ControlTabIndex = ControlTabIndex + 10;
                $("#staticDisableDeleteEndUsersActionButtons").find('a').each(function () {
                    $(this).attr('tabindex', ControlTabIndex++);
                });
            },
            //updating the screen based on the selected query criteria for disable
            updateTargetCriteriaforDisable: function (tempCriteria) {
                if (tempCriteria != null && tempCriteria.selections && tempCriteria.selections.length == 0) {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.IsCheckedForDisable(false);
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.checkDisableSelection(false);
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount(-1);
                    $("#addDisableConditionLinkCalculate").addClass('link-disabled');
                    $("#usersDisablelistlink").addClass('link-disabled');
                    $("#btn_disable").attr("disabled", "disabled");

                }
                else if (disableNowInProgress) {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.IsCheckedForDisable(false);
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.checkDisableSelection(false);
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount(-1);
                    $("#addDisableConditionLinkCalculate").addClass('link-disabled');
                    $("#usersDisablelistlink").addClass('link-disabled');
                    $("#btn_disable").attr("disabled", "disabled");
                    $("#downloadExcelforDisable").addClass('link-disabled');
                    $("#disableSuccessIcon").addClass("hide");
                }
                else {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.checkDisableSelection(true);
                    $("#addDisableConditionLinkCalculate").removeClass('link-disabled');
                    $("#usersDisablelistlink").removeClass('link-disabled');
                    $("#btn_disable").removeClass('link-disabled');
                    $("#btn_disable").removeAttr("disabled", "disabled");
                    $("#downloadExcelforDisable").removeClass('link-disabled');
                    $("#disableSuccessIcon").removeClass("hide");
                }


            },

            //updating the screen based on the selected query criteria for delete
            updateTargetCriteriaforDelete: function (tempCriteria) {
                if (tempCriteria != null && tempCriteria.selections && tempCriteria.selections.length == 0) {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.IsCheckedForDelete(false);
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.checkDeleteSelection(false);
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDeleteToCount(-1);
                    $("#addDeleteConditionLinkCalculate").addClass('link-disabled');
                    $("#usersDeletelistlink").addClass('link-disabled');
                    $("#btn_delete").attr("disabled", "disabled");
                }
                else if (deleteNowInProgress) {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.IsCheckedForDelete(false);
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.checkDeleteSelection(false);
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDeleteToCount(-1);
                    $("#addDeleteConditionLinkCalculate").addClass('link-disabled');
                    $("#usersDeletelistlink").addClass('link-disabled');
                    $("#btn_delete").attr("disabled", "disabled");
                    $("#downloadExcelforDelete").addClass('link-disabled');
                    $("#deleteSuccessIcon").addClass("hide");
                }
                else {
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.checkDeleteSelection(true);
                    $("#addDeleteConditionLinkCalculate").removeClass('link-disabled');
                    $("#usersDeletelistlink").removeClass('link-disabled');
                    $("#btn_delete").removeAttr("disabled", "disabled");
                    $("#downloadExcelforDelete").removeClass('link-disabled');
                    $("#deleteSuccessIcon").removeClass("hide");
                }

            },

            //helper function to compare query criteria
            isQueryCriteriaEqual: function (criteriaOne, criteriaTwo) {
                try {
                    return criteriaOne.display.join() == criteriaTwo.display.join();
                } catch (e) {
                    return true;
                }
            },

            //search on pop up for users
            searchUser: function (data, event) {
                var searchString = $.trim($('#txtSearch').val());
                if ((event != undefined && ($.hotkeys.enter(event) || event.type == "click")) && searchString != "") {

                    athoc.iws.disabledeleteendusers.searchString.push({ searchItem: $.trim($('#txtSearch').val()) });
                    athoc.iws.disabledeleteendusers.createEndUsersGrid();
                }
                else if ((event != undefined && ($.hotkeys.enter(event) || event.type == "click")) && searchString == "") {
                    athoc.iws.disabledeleteendusers.clearFilters();

                }
                if (searchString.length > 0) {
                    $("#btn_userSearch").removeAttr("disabled", "disabled");
                }
                else
                    $("#btn_userSearch").attr("disabled", "disabled");
            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {
                var dl = athoc.iws.disabledeleteendusers;
                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = dl.breadcrumbModel;

                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_breadCrumbSettings, '', function () {
                    athoc.iws.disabledeleteendusers.cancelEndUsers();
                });

                //Page breadcrumb
                var editPageBreadcrumb = new PageBreadcrumb('editdisabledeleteendusers', athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_breadCurmbdisabledeleteendusers, [settingLink], '');

                breadcrumbsModel.addPage(editPageBreadcrumb);

            },

            //breadcrumb implementation
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.disabledeleteendusers.breadcrumbModel;
                breadcrumbsModel.SelectedPage('editdisabledeleteendusers');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');

                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
                $(".title").attr("style", "width: 250px !important")
            },

            //disable users call first to check wheater user clicked on calculate button 
            disableUsers: function () {
                athoc.iws.disabledeleteendusers.hideMessage();
                athoc.iws.disabledeleteendusers.getDisableEndUsersDetail(true);
            },

            //calls from the disableUsers Method
            //after certain check actually disabling the end users
            disableEndUsers: function () {

                if (athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount() == 0) {
                    var $disableErrorHeaderTag = $('#dlgUserSelection #dvErrorMsg');
                    var Title = athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Error_NoUserDisable_Message;
                    $disableErrorHeaderTag.html(Title);
                    
                    $('#dlgUserSelection').modal().css(
                      {
                          'z-index': '3000'
                      });
                   // $('#dlgUserSelection .btn.btn-large.btn-default').focus();
                    return false;
                }

                var $disableHeader = $('#disable-user #ErrorMesage');
                var $disableContent = $('#disable-user .modal-body');

                $('#Disable_Delete_Users #Disable_Delete_message').html(athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Disabling);

                var contentTitle = athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_DisableUsers_ConfirmMessage;
                var headerTitle = athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_DisableUsers_Title;

                contentTitle = contentTitle.replace('{0}', athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount());
                $disableContent.html(contentTitle);

                headerTitle = headerTitle.replace('{0}', athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount());
                $disableHeader.html(headerTitle);

                if (athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount() == 1) {


                    //below is to get the display of the selected user
                    var contentTitle = athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_DisableUser_ConfirmMessage;

                    var username = "";
                    username = athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.UserName();

                    contentTitle = contentTitle.replace('{0}', username);
                    $disableContent.html(contentTitle);

                    var headerTitle = athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_DisableUser_Title;
                    headerTitle = headerTitle.replace('{0}', athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount());
                    $disableHeader.html(headerTitle);
                }
                if (athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount() > 0) {
                    $('#disable-user').modal().css(
                    {
                        'z-index': '3000'
                    });

                    $('#saveMessagePanel').messagesPanel('reset');
                    $('#disableUserButton').off('click').on('click', function (e) {
                        e.preventDefault();
                        //$("disableUserButton").focus();
                        $('#disable-user').modal('hide');
                        athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.disableExecutionStatus('IPC');
                        athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDisableExecutionStatus(athoc.iws.disabledeleteendusers.resources.DisableDelete_UserModified_Status_IPC);
                        athoc.iws.disabledeleteendusers.SubmitDisableJob(true);
                    });
                }
            },

            //checkingstatus of the submitted job to disable users
            SubmitDisableJob: function (jobsubmitted) {
                athoc.iws.disabledeleteendusers.isChanged = false;
                var Url = "";
                if (jobsubmitted) {
                    Url = athoc.iws.disabledeleteendusers.urls.DisableDeleteEndUsersUrl;
                    disableNowInProgress = true;
                    athoc.iws.disabledeleteendusers.updateTargetCriteriaforDisable(null);
                }
                else
                    Url = athoc.iws.disabledeleteendusers.urls.CheckRunNowStatusUrl;

                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.actionType('DisableUsers');
                var model = ko.mapping.fromJS(athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec);

                var myAjaxOptions = {
                    url: Url,
                    contentType: 'application/json',
                    dataType: 'json',
                    type: 'POST',
                    data: ko.toJSON(model),
                    success: function (data) {
                        if (data.Success && data.TargetDisableModel != null) {
                            $('#Disable_Delete_Users').modal('hide');
                            if (data.TargetDisableModel.LastExecutionStatus.toUpperCase() == "SUCCESS") {
                                clearTimeout(DisableTimeOut);
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDisableExecutionStatus(athoc.iws.disabledeleteendusers.resources.DisableDelete_UserModified_Status_Success);
                                athoc.iws.disabledeleteendusers.setDisableModel(data.TargetDisableModel);
                                $("downloadExcelforDisable").removeClass("hide");
                                $('#saveMessagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Disable_Success_Msg }] });
                                $(document).scrollTop(0);
                                athoc.iws.disabledeleteendusers.setFocus();
                            }
                            else if (data.TargetDisableModel.LastExecutionStatus.toUpperCase() == "FAILURE") {
                                clearTimeout(DisableTimeOut);
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDisableExecutionStatus(athoc.iws.disabledeleteendusers.resources.DisableDelete_UserModified_Status_Failure);
                                athoc.iws.disabledeleteendusers.setDisableModel(data.TargetDisableModel);
                                athoc.iws.disabledeleteendusers.setFocus();
                            }
                            else if (data.TargetDisableModel.LastExecutionStatus.toUpperCase() == "IPC") {
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDisableExecutionStatus(athoc.iws.disabledeleteendusers.resources.DisableDelete_UserModified_Status_IPC);
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.disableExecutionStatus(data.TargetDisableModel.LastExecutionStatus.toUpperCase());
                                disableNowInProgress = true;
                                athoc.iws.disabledeleteendusers.updateTargetCriteriaforDisable(null);
                                DisableTimeOut = setTimeout(function () { athoc.iws.disabledeleteendusers.SubmitDisableJob(); }, timeInterval);
                            }
                        }
                        else {
                            $('#Disable_Delete_Users').modal('hide');
                            $('#saveMessagePanel').messagesPanel({ messages: data.Messages }, undefined, undefined, undefined, errorTitleStrings);
                            $(document).scrollTop(0);
                        }
                    },
                    error: function (e) {
                        $.AjaxLoader.hideLoader();
                        athoc.iws.disabledeleteendusers.handleError(e);
                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

            },

            setDisableModel: function (TargetDisableModel) {
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.lastDisableExecutionTime(TargetDisableModel.LastJobExecutionTime);
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.nextDisableExecutionTime(TargetDisableModel.NextJobExecutionTime);
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableJobAuditID(TargetDisableModel.AuditId);
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.disableExecutionStatus(TargetDisableModel.LastExecutionStatus.toUpperCase());
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDisableToCount(-1);
                disableNowInProgress = false;
                athoc.iws.disabledeleteendusers.updateTargetCriteriaforDisable(null);
            },

            setDeleteModel: function (TargetDeleteModel) {
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.lastDeleteExecutionTime(TargetDeleteModel.LastJobExecutionTime)
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.nextDeleteExecutionTime(TargetDeleteModel.NextJobExecutionTime)
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteJobAuditID(TargetDeleteModel.AuditId)
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.deleteExecutionStatus(TargetDeleteModel.LastExecutionStatus.toUpperCase());
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDeleteToCount(-1);
                deleteNowInProgress = false;
                athoc.iws.disabledeleteendusers.updateTargetCriteriaforDelete(null);
            },

            //delete users call first to check wheater user clicked on calculate button 
            deleteUsers: function () {
                athoc.iws.disabledeleteendusers.hideMessage();
                athoc.iws.disabledeleteendusers.getDeleteEndUsersDetail(true);
            },

            //calls from the deleteUsers Method
            deleteEndUsers: function () {

                if (athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDeleteToCount() == 0) {
                    var $disableErrorHeaderTag = $('#dlgUserSelection #dvErrorMsg');
                    var Title = athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Error_NoUserDisable_Message;
                    $disableErrorHeaderTag.html(Title);
                    //$("#noRecordOK").focus();
                    $('#dlgUserSelection').modal().css(
                      {
                          'z-index': '3000'
                      });
                   
                    return false;
                }

                var userIds = [];
                var listType = "";
                var $deleteHeaderTag = $('#delete-user #ErrorMesage');

                $('#Disable_Delete_Users #Disable_Delete_message').html(athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Deleting);

                var headerTitle = athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_DeleteUsers_ConfirmMessage

                headerTitle = headerTitle.replace('{0}', athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDeleteToCount());
                $deleteHeaderTag.html(headerTitle);

                if (athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDeleteToCount() == 1) {
                    //below is to get the display of the selected user
                    username = athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.UserName();
                    var headerTitle = athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_DeleteUser_ConfirmMessage;
                    headerTitle = headerTitle.replace('{0}', username);
                    $deleteHeaderTag.html(headerTitle);
                }
                if (athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.totalUserToDeleteToCount() > 0) {
                    $('#delete-user').modal().css(
                    {
                        'z-index': '3000'
                    });
                    $('#deleteUserButton').off('click').on('click', function (e) {
                        e.preventDefault();
                        //$("deleteUserButton").focus();
                        $('#delete-user').modal('hide');
                        athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.deleteExecutionStatus('IPC');
                        athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDeleteExecutionStatus(athoc.iws.disabledeleteendusers.resources.DisableDelete_UserModified_Status_IPC);
                        athoc.iws.disabledeleteendusers.SubmitDeleteJob(true);
                    });

                }

            },

            //checkingstatus of the submitted job to delete users
            SubmitDeleteJob: function (jobsubmitted) {
                athoc.iws.disabledeleteendusers.isChanged = false;
                var Url = "";
                if (jobsubmitted) {
                    Url = athoc.iws.disabledeleteendusers.urls.DisableDeleteEndUsersUrl;
                    deleteNowInProgress = true;
                    athoc.iws.disabledeleteendusers.updateTargetCriteriaforDelete(null);
                }
                else
                    Url = athoc.iws.disabledeleteendusers.urls.CheckRunNowStatusUrl;

                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.actionType('DeleteUsers');
                var model = ko.mapping.fromJS(athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec);

                var myAjaxOptions = {
                    url: Url,
                    contentType: 'application/json',
                    dataType: 'json',
                    type: 'POST',
                    data: ko.toJSON(model),
                    success: function (data) {
                        if (data.Success && data.TargetDeleteModel != null) {
                            $('#Disable_Delete_Users').modal('hide');
                            if (data.TargetDeleteModel.LastExecutionStatus.toUpperCase() == "SUCCESS") {
                                clearTimeout(DeleteTimeOut);
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDeleteExecutionStatus(athoc.iws.disabledeleteendusers.resources.DisableDelete_UserModified_Status_Success);
                                athoc.iws.disabledeleteendusers.setDeleteModel(data.TargetDeleteModel);
                                $("downloadExcelforDelete").removeClass("hide");
                                $('#saveMessagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Delete_Success_Msg }] });
                                $(document).scrollTop(0);
                                athoc.iws.disabledeleteendusers.setFocus();
                            }
                            else if (data.TargetDeleteModel.LastExecutionStatus.toUpperCase() == "FAILURE") {
                                clearTimeout(DeleteTimeOut);
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDeleteExecutionStatus(athoc.iws.disabledeleteendusers.resources.DisableDelete_UserModified_Status_Failure);
                                athoc.iws.disabledeleteendusers.setDeleteModel(data.TargetDeleteModel);
                                athoc.iws.disabledeleteendusers.setFocus();
                            }
                            else if (data.TargetDeleteModel.LastExecutionStatus.toUpperCase() == "IPC") {
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.LastDeleteExecutionStatus(athoc.iws.disabledeleteendusers.resources.DisableDelete_UserModified_Status_IPC);
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.deleteExecutionStatus(data.TargetDeleteModel.LastExecutionStatus.toUpperCase());
                                deleteNowInProgress = true;
                                athoc.iws.disabledeleteendusers.updateTargetCriteriaforDelete(null);
                                DeleteTimeOut = setTimeout(function () { athoc.iws.disabledeleteendusers.SubmitDeleteJob(); }, timeInterval);
                            }

                        }
                        else {
                            $('#Disable_Delete_Users').modal('hide');
                            $('#saveMessagePanel').messagesPanel({ messages: data.Messages }, undefined, undefined, undefined, errorTitleStrings);
                            $(document).scrollTop(0);
                        }
                    },
                    error: function (e) {
                        $.AjaxLoader.hideLoader();
                        athoc.iws.disabledeleteendusers.handleError(e);
                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

            },

            //Export the csv file of disabled users
            exportDisableUsersData: function () {
                athoc.iws.disabledeleteendusers.hideMessage();
                if (!disableNowInProgress) {
                    athoc.iws.disabledeleteendusers.isDowlLoadClick = true;
                    var auditId = "";
                    auditId = athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableJobAuditID();
                    var url = athoc.iws.disabledeleteendusers.urls.DownloadExcelForDisableDelete + "?auditID=" + auditId + "&typeString=" + athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Disable_FileText;
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DownloadExcelForDisableURL(url);
                }

            },

            //Export the csv file of deleted users
            exportDeleteUsersData: function () {
                athoc.iws.disabledeleteendusers.hideMessage();
                if (!deleteNowInProgress) {
                    athoc.iws.disabledeleteendusers.isDowlLoadClick = true;
                    var auditId = "";
                    auditId = athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteJobAuditID();
                    var url = athoc.iws.disabledeleteendusers.urls.DownloadExcelForDisableDelete + "?auditID=" + auditId + "&typeString=" + athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Delete_FileText;;
                    athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DownloadExcelForDeleteURL(url);
                }
            },

            //Save the settings of disabled/deleted users
            saveEndUsers: function (e) {

                var model = ko.mapping.fromJS(athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec);

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.disabledeleteendusers.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.disabledeleteendusers.resources.General_LoadingMessage }).showLoader();
                var myAjaxOptions = {
                    url: athoc.iws.disabledeleteendusers.urls.SaveEndUsersSettings,
                    contentType: 'application/json',
                    dataType: 'json',
                    type: 'POST',
                    data: ko.toJSON(model),
                    success: function (data) {
                        if (data.Success) {
                            //athoc.iws.disabledeleteendusers.GetInitailDatatoLoad();
                            $('#saveMessagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_DisableDelete_SaveSuccess }] });
                            athoc.iws.disabledeleteendusers.setFocus();
                        }
                        else {
                            $('#saveMessagePanel').messagesPanel({ messages: data.Messages }, undefined, undefined, undefined, athoc.iws.disabledeleteendusers.errorTitleStrings);
                        }
                        $.AjaxLoader.hideLoader();
                        $(document).scrollTop(0);
                    },
                    error: function (e) {
                        $.AjaxLoader.hideLoader();
                        athoc.iws.disabledeleteendusers.handleError(e);
                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
                athoc.iws.disabledeleteendusers.isChanged = false;
            },



            //cancel the changes and reload the original data.
            cancelEndUsers: function () {
                
                if (athoc.iws.disabledeleteendusers.isChanged) {
                    var confirmLeave = confirm(athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Unsaved_Data_Text);
                    if (confirmLeave) {
                        athoc.iws.disabledeleteendusers.isCancelClicked = true;
                        window.location.href = "/client/setup/settings";
                        return true;
                    }
                    athoc.iws.disabledeleteendusers.isCancelClicked = false;
                    return false;
                }
                window.location.href = "/client/setup/settings";
            },

            // on loading getting the data if users has saved any for the VPS
            getInitailDatatoLoad: function () {
                $('#saveMessagePanel').messagesPanel('reset');
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.disabledeleteendusers.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.disabledeleteendusers.resources.General_LoadingMessage }).showLoader();

                var myAjaxOptions = {
                    url: athoc.iws.disabledeleteendusers.urls.GetInitailDatatoLoadUrl,
                    contentType: 'application/json',
                    dataType: 'json',
                    type: 'POST',
                    data: null,
                    success: function (data) {
                        if (data.Success) {

                            ///Disable Initial data to load
                            var disablemodel = data.DisableInformation;
                            if (disablemodel.DisableDynamicCriteria != null && disablemodel.DisableDynamicCriteria.display != null && disablemodel.DisableDynamicCriteria.selections != null) {
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableDynamicCriteria(disablemodel.DisableDynamicCriteria);
                            }
                            else
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableDynamicCriteria({ display: [], selections: [] });

                            //Delete Initial data to load
                            var deletemodel = data.DeleteInformation;
                            if (deletemodel.DeleteDynamicCriteria != null && deletemodel.DeleteDynamicCriteria.display != null && deletemodel.DeleteDynamicCriteria.selections != null) {
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteDynamicCriteria(deletemodel.DeleteDynamicCriteria);
                            }
                            else
                                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteDynamicCriteria({ display: [], selections: [] });

                            //loading the query builder with preselected data if any saved
                            athoc.iws.disabledeleteendusers.bind(data);
                        }
                        else {
                            $('#saveMessagePanel').messagesPanel({ messages: data.Messages }, undefined, undefined, undefined, athoc.iws.disabledeleteendusers.errorTitleStrings);
                            $.AjaxLoader.hideLoader();
                            $(document).scrollTop(0);
                        }

                    },
                    error: function (e) {
                        $.AjaxLoader.hideLoader();
                        athoc.iws.disabledeleteendusers.handleError(e);
                    }
                };
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
            },

            //remove hide class to show values after load
            changeScreenControlStatus: function () {
                $("#downloadExcelforDisable").removeClass("hide");
                $("#addDisableConditionLinkCalculate").removeClass("hide");
                $("#addDeleteConditionLinkCalculate").removeClass("hide");
                $("#disableNA").removeClass("hide");
                $("#disableSuccessIcon").removeClass("hide");
                $("#downloadExcelforDelete").removeClass("hide");
                $("#deleteNA").removeClass("hide");
                $("#deleteSuccessIcon").removeClass("hide");
                $("#NextDisableSpanDiv").removeClass("hide");
                $("#NextDeleteSpanDiv").removeClass("hide");
                $("#disableinterval").removeClass("hide");
                $("#deleteinterval").removeClass("hide");

                if (athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.PurgeUsersModel.IsUserPurgedRequest())
                    $('.selectpicker').attr('disabled', false).selectpicker('refresh');
                else
                    $('.selectpicker').attr('disabled', true).selectpicker('refresh');

                var dsTitle = athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Disable_CheckTitle.replace('{0}', athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.disableInterval())
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.chkDsTitle(dsTitle);

                var dlTitle = athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_Delete_CheckTitle.replace('{0}', athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.deleteInterval())
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.chkDlTitle(dlTitle);
            },

            //hide message pannel
            hideMessage: function () {
                $('#saveMessagePanel').html('');
                //$('#treeview').height(treeviewMaxHeight);
            },

            // Triggered, when clear all link is clicked, it clear the searchCriteria and reload the grid
            clearFilters: function () {
                $("#txtSearch").val("");
                athoc.iws.disabledeleteendusers.clearSearchedValues();
                athoc.iws.disabledeleteendusers.createEndUsersGrid();
                $("#btn_userSearch").removeAttr("disabled", "disabled");
            },


            clearSearchedValues: function () {
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.searchString = null;
                athoc.iws.disabledeleteendusers.EndUsersSortColumn = "LOGIN_ID";
                athoc.iws.disabledeleteendusers.EndUsersSortField = "_LOGIN_ID";
                athoc.iws.disabledeleteendusers.EndUsersSortOrder = "asc";
                athoc.iws.disabledeleteendusers.EndUsersPageSize = 50;
                athoc.iws.disabledeleteendusers.EndUsersPage = 1;
                athoc.iws.disabledeleteendusers.searchString.length = 0;
            },
            //on checking the checkbox collect the user ids to be disable/delete
            closeModelSearchData: function () {
                athoc.iws.disabledeleteendusers.clearSearchedValues();
                $('#userslist').modal('hide');
                //if (athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.isFromDisable())
                //    $("#CalculatedsbSpan").focus();
                // else
                //    $("#CalculatedelSpan").focus();
               

            },

            //// Triggered, when search button 
            search: function () {
                if ($.trim($('#txtSearch').val()).length > 0) {
                    athoc.iws.disabledeleteendusers.searchString.push({ searchItem: $.trim($('#txtSearch').val()) });
                    athoc.iws.disabledeleteendusers.createEndUsersGrid();
                    $("#btn_userSearch").attr("disabled", "disabled");
                }
            },

            // Get end users data and bind to kendo grid
            createEndUsersGrid: function () {
                var jsonData = "";
                if (athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.isFromDisable()) {
                    jsonData = athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DisableDynamicCriteria();
                }
                else if (!athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.isFromDisable()) {
                    jsonData = athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.DeleteDynamicCriteria();
                }

                if (!jsonData || jsonData.selections.length == 0)
                    return 0;

                var self = this;
                var strSearch = [];
                var gridRowsObject = [];

                $.grep(athoc.iws.disabledeleteendusers.searchString, function (i) {
                    strSearch.push(i.searchItem);
                });

                var url = athoc.iws.disabledeleteendusers.urls.GetEndUsersDetailUrl;


                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.showList = true;
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.isfromDisable = athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.isFromDisable();
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.searchString = strSearch;
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.sortBy = athoc.iws.disabledeleteendusers.EndUsersSortColumn;
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.sortOrder = athoc.iws.disabledeleteendusers.EndUsersSortOrder;
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.pageSize = athoc.iws.disabledeleteendusers.EndUsersPageSize;
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.page = athoc.iws.disabledeleteendusers.EndUsersPage;
                athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.searchModel = jsonData;
                var model = ko.mapping.fromJS(athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec);

                gridColumnDefs = [];
                EndUsersDatasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            // dataType: "json",
                            data: ko.toJSON(model),
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec);
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                        athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.pageSize = EndUsersDatasource._pageSize;
                        athoc.iws.disabledeleteendusers.DisableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.page = EndUsersDatasource._page;
                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-filter'), imageURL: athoc.iws.disabledeleteendusers.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.disabledeleteendusers.resources.General_LoadingMessage }).showLoader();
                    },
                    requestEnd: function (e) {

                        if (e.response) {
                            gridColumnDefs.length = 0;
                            // column width based on column count

                            if (e.response.Columns.length < 7)
                                colWidth = "auto";
                            else
                                colWidth = "120px";

                            // Add coumns to column array
                            _.each(e.response.Columns, function (column, cIndex) {
                                var headerTemplate = "";
                                var field = "_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\\/]/g, "");
                                headerTemplate = '<span  title="' + athoc.iws.disabledeleteendusers.replaceTitle(column.ViewId) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '"data-key="' + column.Key + '"onclick="athoc.iws.disabledeleteendusers.endUsersGridColumnSort(\'' + field + '\',\'' + column.Key + '\');" >' + $.htmlEncode(column.DisplayName) + '</span>';

                                if (athoc.iws.disabledeleteendusers.EndUsersSortColumn.toUpperCase() == column.Key) {
                                    athoc.iws.disabledeleteendusers.EndUsersSortField = field;
                                    if (athoc.iws.disabledeleteendusers.EndUsersSortOrder.toUpperCase() == "ASC") {
                                        headerTemplate += '<span class="sort-indicator-ascending"></span>';
                                    }
                                    else if (athoc.iws.disabledeleteendusers.EndUsersSortOrder.toUpperCase() == "DESC") {
                                        headerTemplate += '<span class="sort-indicator-descending"></span>';
                                    }
                                }
                                headerTemplate = kendo.format(headerTemplate);
                                gridColumnDefs.push({
                                    title: column.DisplayName,
                                    field: field,
                                    width: colWidth,
                                    template: '<span title="#=' +field + '#">#=' + field + '#</span>',
                                    headerTemplate: headerTemplate,
                                    headerAttributes: {
                                        viewid: column.ViewId,
                                        id: column.Id,
                                        customviewcolumntype: "",
                                        key: column.Key
                                    }

                                });

                            });

                            // Prepare datasource for kendo grid
                            gridRowsObject.length = 0;
                            _.each(e.response.Rows, function(row, rIndex) {
                                var colObject = new Object();
                                _.each(e.response.Columns, function(column, cIndex) {
                                    var value = athoc.iws.disabledeleteendusers.getColumnValue(column, row);
                                    if (column.DataFormat && column.DataType && (!(column.DataType == 4 || column.DataType == 5)))
                                        value = $.getFormattedValue(column.DataType, column.DataFormat, value);
                                    colObject["_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\/]/g, "")] = $.customizedHtmlEncoding(value);
                                });

                                gridRowsObject.push(colObject);
                            })
                            EndUsersDatasource._total = e.response.TotalCounts;


                        }
                        $("#pageInfo").kendoPager({
                            dataSource: EndUsersDatasource,
                            autoBind: false,
                            numeric: false,
                            previousNext: false,
                            messages: {
                                display: athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_List_PageInfo,
                                empty: athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_DisplayEmpty
                            }
                        });
                        $("#pageInfo").removeClass("kendo-mini-pager k-pager-wrap k-widget k-floatwrap").addClass("kendo-mini-pager");
                        $("#DisableDeleteEndUserdgrid .k-grid-header").html('');
                        $("#DisableDeleteEndUserdgrid").find(".bootstrap-select").remove();

                        athoc.iws.disabledeleteendusers.EndUsersgrid = $("#DisableDeleteEndUserdgrid").kendoGrid({
                            columns: gridColumnDefs,
                            dataSource: gridRowsObject,
                            scrollable: true,
                            autoBind: true,
                            sortable: false,
                            pageable: {
                                refresh: false,
                                pageSizes: true,
                                pageSizes: [20, 50, 100],
                                buttonCount: 5,
                                messages: {
                                    display: athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_DisplayItems,
                                    itemsPerPage: athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_ItemsPerPage,
                                    empty: athoc.iws.disabledeleteendusers.resources.DisableDeleteEndUsers_DisplayEmpty,
                                    first: $.htmlDecode(athoc.iws.disabledeleteendusers.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                                    previous: $.htmlDecode(athoc.iws.disabledeleteendusers.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                                    next: $.htmlDecode(athoc.iws.disabledeleteendusers.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                                    last: $.htmlDecode(athoc.iws.disabledeleteendusers.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                                }
                            },
                            dataBinding: athoc.iws.disabledeleteendusers.onEndUsersDataBinding,
                            dataBound: athoc.iws.disabledeleteendusers.onEndUsersDataBound,
                            change: function (e) {
                                var model = this.dataItem(this.select());
                                this.select().removeClass("k-state-selected");
                            }

                        }).data().kendoGrid;

                        athoc.iws.disabledeleteendusers.EndUsersPageSize = EndUsersDatasource._pageSize;

                        setTimeout(function () {
                            athoc.iws.disabledeleteendusers.fitHeighEndUserList();
                            $.AjaxLoader.hideLoader();
                        }, 200);
                    },
                    schema: {
                        data: "Rows",
                        total: "TotalCounts",
                    },
                    serverPaging: true,
                    serverSorting: true,
                    serverFiltering: true,
                    sort: { field: "Username", dir: "desc" },
                    pageSize: athoc.iws.disabledeleteendusers.EndUsersPageSize,

                    error: function (e) {
                        $.AjaxLoader.hideLoader();
                        athoc.iws.disabledeleteendusers.handleError(e);
                    },
                    change: function (e) {
                        //scrolling to the top when paging and sorting.
                        $("html,body").scrollTop(0);
                    }

                });
                ko.cleanNode($("#dvEndUsersSearch").get(0));
                ko.applyBindings(athoc.iws.disabledeleteendusers.searchModel, $("#dvEndUsersSearch").get(0));

                EndUsersDatasource._pageSize = athoc.iws.disabledeleteendusers.EndUsersPageSize;
                EndUsersDatasource.read();
                return 1;


            },

            // Sorting of columns for users grid
            endUsersGridColumnSort: function (field, key) {
                athoc.iws.disabledeleteendusers.EndUsersSortField = field;
                athoc.iws.disabledeleteendusers.EndUsersSortColumn = key;
                if (athoc.iws.disabledeleteendusers.EndUsersSortOrder == "desc")
                    athoc.iws.disabledeleteendusers.EndUsersSortOrder = "asc";
                else
                    athoc.iws.disabledeleteendusers.EndUsersSortOrder = "desc";
                athoc.iws.disabledeleteendusers.createEndUsersGrid();

            },

            //creating the meaningful title
            replaceTitle: function (val) {
                switch (val) {
                    case 1:
                        return athoc.iws.disabledeleteendusers.resources.DisableDelete_ShowList_Username_Title;
                        break;
                    case 2:
                        return athoc.iws.disabledeleteendusers.resources.DisableDelete_ShowList_Displayname_Title;
                        break;
                    case 3:
                        return athoc.iws.disabledeleteendusers.resources.DisableDelete_ShowList_Createdon_Title;
                        break;
                }
            },

            replaceStatusText: function (val) {
                switch (val) {
                    case 'IPC':
                        return athoc.iws.disabledeleteendusers.resources.DisableDelete_UserModified_Status_IPC;
                        break;
                    case 'FAILURE':
                        return athoc.iws.disabledeleteendusers.resources.DisableDelete_UserModified_Status_Failure;
                        break;
                }
            },

            //fit the modal according to the screen
            fitHeighEndUserList: function () {

                var windowHeight = $(".userslist .modal-content").height() - $(".userslist .content-current").height();
                if (windowHeight > 500) {
                    $("#DisableDeleteEndUserdgrid .k-grid-content").css("height", (windowHeight * 73 / 100) - 10);
                }
                else if ((windowHeight <= 500) && (windowHeight > 400)) {
                    $("#DisableDeleteEndUserdgrid .k-grid-content").css("height", (windowHeight * 65 / 100) - 15);
                }
                else {
                    $("#DisableDeleteEndUserdgrid .k-grid-content").css("height", (windowHeight * 67 / 100) - 40);
                }
            },

            //fit the modal according to the screen when grid is filled
            resizeModalBasedOnScreen: function (modal) {

                modal.find(".modal-body").css("max-height", 600);
                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 56 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 56 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 265);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }

            },

            // Binding the knedo grid with End Users data
            onEndUsersDataBound: function (e) {

                var data = $("#DisableDeleteEndUserdgrid").data("kendoGrid").dataSource.view();
                athoc.iws.disabledeleteendusers.searchModel.availableEndUsers(data);

                var grid = $("#DisableDeleteEndUserdgrid").data("kendoGrid");
                grid.pager.dataSource = EndUsersDatasource;

                if (data.length > 0)
                    $("#DisableDeleteEndUserdgrid .k-grid-header").css("width", "98% !important");
                else
                    $("#DisableDeleteEndUserdgrid .k-grid-header").css("width", "100% !important");

                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    if (isSearched) {
                        $(e.sender.wrapper)
                            .find('tbody')
                            .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.disabledeleteendusers.resources.AtHoc_Grid_NoRecords + '</td></tr>');
                    } else {
                        $(e.sender.wrapper)
                            .find('tbody')
                            .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.disabledeleteendusers.resources.DisableDelete_No_Records_Found + '</td></tr>');
                    }
                }

            },

            //getting the column values
            getColumnValue: function (column, row) {
                if (column.Key == "OPERATOR-ROLES") {
                    var roleCount = row.UserAttributes["ROLECOUNT_OTHERORGS"];
                    if (roleCount && roleCount != " ") {
                        return row.UserAttributes[column.Key] + " (" + row.UserAttributes["ROLECOUNT_OTHERORGS"] + ") ";
                    } else {
                        return row.UserAttributes[column.Key];
                    }
                }
                return column.CustomViewColumnType === "CF"
                    ? row.UserAttributes[column.Key]
                    : row.UserDevice[column.Key];
            },

            //databinding events
            onEndUsersDataBinding: function (e) {
                var ds = $("#DisableDeleteEndUserdgrid").data("kendoGrid").dataSource;
                ds._sort = [{ field: athoc.iws.disabledeleteendusers.EndUsersSortField, dir: athoc.iws.disabledeleteendusers.EndUsersSortOrder }];
            },

            // To show erros and hadle timeout error
            handleError: function (e) {

                if ((e != undefined && e.status == 401) || (e != undefined && e.xhr != undefined && e.xhr.status == 401)) {
                    window.onbeforeunload = null;
                    window.location = window.location;

                } else if (e.errorThrown != "") {
                    if (athoc.iws.disabledeleteendusers.errors === null) {
                        athoc.iws.disabledeleteendusers.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.disabledeleteendusers.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#saveMessagePanel').messagesPanel({ messages: this.errors }, undefined, undefined, undefined, errorTitleStrings);
                    $(document).scrollTop(0);
                }
            },

        };


    }();
}




