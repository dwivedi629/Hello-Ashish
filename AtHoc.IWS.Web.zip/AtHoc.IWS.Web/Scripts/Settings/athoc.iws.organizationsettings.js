﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.organizationSettings = athoc.iws.organizationSettings || {};

if (athoc.iws.organizationSettings) {
    athoc.iws.organizationSettings = function () {
        return {
            init: function () {
                athoc.iws.organizationSettings.initBreadcrumb();
                navigateToPage('viewOrganizationSetting', function () { });
            },

            //load method, will be tirggered on document load
            load: function () {
                athoc.iws.organizationSettings.bindBreadcrumb();
            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            //
            initBreadcrumb: function () {

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.organizationSettings.breadcrumbModel;

                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.organization.resources.AtHoc_Common_Settings, '', function () {
                    window.location.href = "/client/setup/Settings";
                });

                //Page breadcrumb
                var viewPageBreadcrumb = new PageBreadcrumb('viewOrganizationSetting', athoc.iws.organization.resources.Organization_BreadCrumb_Title, [settingLink], '');
                breadcrumbsModel.addPage(viewPageBreadcrumb);

            },

            // Bind breadcrumb model to the breadcrumb control
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.organizationSettings.breadcrumbModel;
                breadcrumbsModel.SelectedPage('viewOrganizationSetting');
                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            }
        };
    }();
}