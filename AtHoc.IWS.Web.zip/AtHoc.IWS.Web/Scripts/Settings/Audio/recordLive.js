var audio_context,
    recorder,
    volume,
    volumeLevel = 0,
    currentEditedSoundIndex,
     AudioURL;

function __log(e, data) {
    log.innerHTML += "\n" + e + " " + (data || '');
}

function startUserMedia(stream) {
   
    var input = audio_context.createMediaStreamSource(stream);
    console.log('Media stream created.');

    volume = audio_context.createGain();
    volume.gain.value = volumeLevel;
    input.connect(volume);
    volume.connect(audio_context.destination);
    //console.log('Input connected to audio context destination.');
    //__log('Input connected to audio context destination.');
    recorder = new Recorder(input);
    //__log('Recorder initialised.');

    //recording start
    //$('.timer').timer('remove');
    //$('.timer').timer({
    //    editable: true
    //});

    recorder && recorder.record();
    $('#recordAudio').attr("title", "Stop");
    $('#recordAudio').text("Stop");
    $('#playRecord').attr('disabled', true);
    $('#stopRecord').attr('disabled', true);
   
    __log('Recording...');
    //recording end
}

$('#recordAudio').on('click', function () {
    if ($('#recordAudio').text() == "Record") {
        init();

    }
    else if ($('#recordAudio').text() == "Stop") {
        recorder && recorder.stop();
        $("#log").attr("style", "display:none");
        $('#recordAudio').attr("title", "Record");
        $('#recordAudio').text("Record");
        $('#playRecord').attr('disabled', false);
        $('#stopRecord').attr('disabled', false);
        getAudioURL();

        recorder.clear();
    }
});

function getAudioURL() {
    recorder && recorder.exportWAV(function (blob) {
        AudioURL = URL.createObjectURL(blob);
    });
}
$('#playRecord').on('click', function () {
    //__log('Playing record.');
    $("#audio").attr("src", AudioURL);
    $("#audio")[0].play();
    //$('#stopRecord').attr('disabled', false);
    //$('#playRecord').attr('disabled', true);
});
$('#stopRecord').on('click', function () {
    //__log('Stopped Playing');
    var vid = document.getElementById("audio");
    vid.pause();
    vid.currentTime = 0;
    //$('#playRecord').attr('disabled', false);
});

function createDownloadLink() {
    __log('Creating Dowload Link.');
    recorder && recorder.exportWAV(function (blob) {
        var url = URL.createObjectURL(blob);
        var li = document.createElement('li');
        var au = document.createElement('audio');
        var hf = document.createElement('a');

        au.controls = true;
        au.src = url;
        hf.href = url;
        hf.download = new Date().toISOString() + '.wav';
        hf.innerHTML = hf.download;
        li.appendChild(au);
        li.appendChild(hf);
        recordingslist.appendChild(li);
        __log('Click play to hear recorded audio');
    });
}



function init() {
    $("#log").attr("style", "display:block");
    $("#log").text("");
    try {
        // webkit shim
        window.AudioContext = window.AudioContext || window.webkitAudioContext || window.mozAudioContext;
        navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;
        window.URL = window.URL || window.webkitURL || window.mozURL;

        audio_context = new AudioContext();
        //console.log('Audio context set up.');
        //console.log('navigator.getUserMedia ' + (navigator.getUserMedia ? 'available.' : 'not present!'));

        //__log('Audio context set up.');
        //__log('navigator.getUserMedia ' + (navigator.getUserMedia ? 'available.' : 'not present!'));
        navigator.getUserMedia({ audio: true }, startUserMedia, function (e) {
            __log('No live audio input: ' + e);
        });
    } catch (e) {
        //console.warn('No web audio support in this browser!');
        __log('No web audio support!');
    }

    
}