﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.AudioFileManager = athoc.iws.AudioFileManager || {};

if (athoc.iws.AudioFileManager) {

    var ids = new Array();
    var isModalOpened = false;

    var fileData;
    var fileEditData;
   
    // Enable/disable controls in all browsers
    ko.bindingHandlers['CustomEnable'] = (function () {
        return {
            init: function (element, valueAccessor) {
                var $element = $(element);
                var value = ko.utils.unwrapObservable(valueAccessor());
                if (value)
                    $element.removeAttr("disabled");
                else
                    $element.attr("disabled", true);

            },
            update: function (element, valueAccessor) {
                var value = ko.utils.unwrapObservable(valueAccessor());
                var $element = $(element);
                if (value)
                    $element.removeAttr("disabled");
                else
                    $element.attr("disabled", true);

            }
        };
    }());



    athoc.iws.AudioFileManager = function () {
        var sortState;
        return {
            isRightToLeft: false,
            audioId: 0,
            searchMaxLength: 200,
            searchString: [],
            audioNamePattern: "^[^&^'^%^/^:^*^?^\^\"^<^>^|]+$",
            LanguageName: ko.observable(),
            Languages: [],
            Severity: [],
            ContextProvider: 0,
            // To keep the search options to get the audio list data.
            audioSearchCriteria: { isAudioPublic: true, searchString: "", providerId: "" },

            // ViewModel to store the audio data
            editModel: {
                audioModel: ko.observable(),
                selectedCnt: ko.observable(0),
                selectedViewCnt: ko.observable(0),
                downloadUrl: ko.observable(''),
                isChanged: ko.observable(false),
                SevArray: ko.observableArray(),
                langSupports: ko.observableArray(),
                defaultSeverties: ko.observableArray(),
            },

            viewModel: kendo.observable(
                {
                    totalCount: 0,
                    selectedCount: 0,
                }),


            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for scenario list, will be triggered before document load
            init: function () {
                athoc.iws.AudioFileManager.initBreadcrumb();
                navigateToPage('viewAudioFileManager', function () { });
            },

            //load method, will be tirggered on document load
            load: function () {
                athoc.iws.AudioFileManager.bindBreadcrumb();
                // Bind all events to the controls
                $("#btn_new").click(function () { athoc.iws.AudioFileManager.createAudioFile(); });
                $("#btn_delete").click(function () { athoc.iws.AudioFileManager.deleteAudioFileFromList(); });
                $("#btn_edit").click(function () { athoc.iws.AudioFileManager.actionEditAudioFile(); });
                $("#btn_download").click(function () { athoc.iws.AudioFileManager.actionDownloadAudioFile(); });
                $("#btn_play").click(function () { athoc.iws.AudioFileManager.actionPlayAudioFile(); });
                $("#clearAllBtn").click(function () { athoc.iws.AudioFileManager.clearFilters(); });
                $("#searchBtn").click(function () {
                    athoc.iws.AudioFileManager.createPills($.trim($('#txtAudioSearchText').val()), "SIMPLESEARCH", $.trim($('#txtAudioSearchText').val()));
                    $("#txtAudioSearchText").val("");
                    $('#pillContainer').show();
                    if ($("#txtAudioSearchText").val().length == 0) {
                        $("#searchBtn").attr('disabled', 'true');
                    }
                });
                $("#btnDeleteCancel").click(function () { $("#dialogDeleteConfirm").modal('hide'); });
                $("#btnDeleteConfirm").click(function () { athoc.iws.AudioFileManager.deleteAudioFileManager(); });


                $("#btnCrossTenant").click(function (event) {
                    $("#AudioError").hide();
                    athoc.iws.AudioFileManager.audioSearchCriteria.searchString = "";
                    $("#pillContainer").html("");
                    $("#pillContainer").hide();
                    athoc.iws.AudioFileManager.searchString.length = 0;
                    athoc.iws.AudioFileManager.setGridHeight();
                });
                $("#btnSeverityCancel").click(function () {
                    athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity(false);
                    $("#dialogDefaultSeverityConfirm").modal('hide');
                    $('#displayShadowOrgView').remove();
                    $('#editAudiofileManager .blockUI').remove();
                });

                $("#btnSeverityConfirm").click(function () {
                    $("#dialogDefaultSeverityConfirm").modal('hide');
                    $('#displayShadowOrgView').remove();
                    $('#editAudiofileManager .blockUI').remove();
                });

                $("#chkPublicAudio").change(function () {
                    $("#searchBtn").removeAttr('disabled');;
                });
                // to clear the special char error message in IE 10 when click X mark in input
                $("#txtAudioSearchText").bind("mouseup", function (e) {
                    var $input = $(this),
                        oldValue = $input.val();

                    if (oldValue == "") return;
                    // When this event is fired after clicking on the clear button
                    // the value is not cleared yet. We have to wait for it.
                    setTimeout(function () {
                        var newValue = $input.val();
                        if (newValue == "") {
                            $input.trigger("cleared");
                            $("#errAudioSearchText").addClass("hide");
                            if ($('#AudioError').css('display') == 'block') {
                                athoc.iws.AudioFileManager.setGridHeight();
                                $("#topSpace").css("height", "257px");
                            } else {
                                athoc.iws.AudioFileManager.setGridHeight();
                            }
                        }
                    }, 1);
                });

                // Set max length property for Search option 
                var inputElm = $("#txtAudioSearchText");
                inputElm.maxLength({
                    maxLength: athoc.iws.AudioFileManager.searchMaxLength,
                    onMaxReached: function () {
                        $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                    }
                });

                // Execute search options when press enter key in search textbox
                inputElm.keyup(function (e) {
                    var seaString = $.trim($('#txtAudioSearchText').val());

                    if (!athoc.iws.AudioFileManager.pattern(seaString, athoc.iws.AudioFileManager.audioNamePattern)) {
                        $("#errAudioSearchText").removeClass("hide");
                        $("#errAudioSearchText").html($.htmlDecode(athoc.iws.AudioFileManager.resources.Settings_AudioFile_NamePattern));
                        $("#topSpace").css("height", "240px");
                        athoc.iws.AudioFileManager.resizeSearchPanel(athoc.iws.AudioFileManager.searchString);
                        $("#searchBtn").attr('disabled', 'true');
                        if ($('#AudioError').css('display') == 'block') {
                            $(".k-grid-header").attr('style', "top:277px;");
                            $(".kgrid-fix-header").attr('style', "top:24px;");
                            $(".table-crown-center").attr('style', "top:40px;height:auto;");
                            $("#topSpace").css("height", "277px");
                        }
                    } else {
                        // TODO : why we need this code
                        if ($('#errAudioSearchText').css('display') == 'block') {
                            $(".k-grid-header").css("top", "210px");
                            $("#filterContent").css("margin-top", "0px");
                            $('.kgrid-fix-header').attr('style', "top:0px;");
                            $(".table-crown-center").attr('style', "top:0px;height:50px;");
                            $("#topSpace").css("height", "240px");
                        } else {
                            if (athoc.iws.AudioFileManager.searchString.length > 0) {
                                if ($('#AudioError').css('display') == 'block') {
                                    $(".k-grid-header").attr('style', "top:300px;");
                                    $(".kgrid-fix-header").attr('style', "top:37px;");
                                    $(".table-crown-center").attr('style', "top:40px;height:auto;");
                                    $("#topSpace").css("height", "240px");
                                } else {
                                    $(".k-grid-header").attr('style', "top:257px;");
                                    $(".kgrid-fix-header").attr('style', "top:0px;");
                                    $(".table-crown-center").attr('style', "top:0px;height:auto;");
                                    $("#topSpace").css("height", "257px");
                                }
                            } else {
                                if ($('#AudioError').css('display') == 'block') {
                                    athoc.iws.AudioFileManager.setGridHeight();
                                    $("#topSpace").css("height", "257px");
                                } else {
                                    athoc.iws.AudioFileManager.setGridHeight();
                                }
                            }
                        }
                        $("#errAudioSearchText").addClass("hide");
                        if ($.hotkeys.enter(e) && seaString != "") {
                            $('#pillContainer').show();
                            athoc.iws.AudioFileManager.createPills(seaString, "SIMPLESEARCH", $('#txtAudioSearchText').val());
                            $("#txtAudioSearchText").val("");
                            $("#searchBtn").attr('disabled', 'true');

                        }
                        if ($('#txtAudioSearchText').val().length > 0) {
                            $("#searchBtn").removeAttr('disabled');
                        }
                    }
                });
             
                // Load kendo grid
                athoc.iws.AudioFileManager.createAudioFileManagerListGrid();

                kendo.bind($(".kendoBound"), this.viewModel);
                var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
                if (gridHeader) {
                    gridHeader.addClass('table-header affix');
                }

                //filterContent
                athoc.iws.AudioFileManager.listLoad();

                //$("#ddlLocale").selectpicker({});
                //$("#ddlEditLocale").selectpicker({});
                window.onbeforeunload = function (event) {
                    var isModified = athoc.iws.AudioFileManager.editModel.isChanged();
                    if (isModified) {
                        return athoc.iws.AudioFileManager.resources.Unsaved_Data_Text;
                    } else {
                        $(window).scrollTop(0);
                    }
                };
            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.AudioFileManager.breadcrumbModel;

                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.AudioFileManager.resources.Breadcrumb_Settings, '', function () {
                    window.location.href = "/client/setup/settings";
                });

                //Page breadcrumb
                var viewPageBreadcrumb = new PageBreadcrumb('viewAudioFileManager', athoc.iws.AudioFileManager.resources.Settings_AudioFile_BreadCurmbAudioFileManager, [settingLink], '');
                breadcrumbsModel.addPage(viewPageBreadcrumb);

            },

            // Bind breadcrumb model to the breadcrumb control
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.AudioFileManager.breadcrumbModel;
                breadcrumbsModel.SelectedPage('viewAudioFileManager');
                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            resizeSearchPanel: function (search) {
                if (search.length > 0) {
                    $(".k-grid-header").attr('style', "top:281px;");
                    $("#topSpace").attr('style', "height:281px;");
                    $(".kgrid-fix-header").attr('style', "top:25px;");
                    $(".table-crown-center").attr('style', "top:0px;height:auto;");

                } else {
                    $(".k-grid-header").attr('style', "top:240px;");
                    $("#topSpace").attr('style', "height:240px;");
                    $(".kgrid-fix-header").attr('style', "top:25px;");
                    $(".table-crown-center").attr('style', "top:0px;height:auto;");
                }
            },
            // Display Create New Audio popup 
            createAudioFile: function () {
                $("#ddlSeverity").selectpicker('refresh');
                $("#ddlEditSeverity").selectpicker('refresh');
                $("#ddlLocale").selectpicker('refresh');
                $("#ddlEditLocale").selectpicker('refresh');
                $(document).scrollTop(0);
                var data = {
                    AudioId: 0,
                    AudioName: "",
                    Description: "",
                    AudioSize: "",
                    AudioCommonName: "",
                    FileName: "",
                    Severity: "Unknown",
                    DefaultSeverity: false,
                    Locale: $.culture,
                    ActualDefaultSeverity: false
                };

                athoc.iws.AudioFileManager.editModel.audioModel = ko.mapping.fromJS(data);



                athoc.iws.AudioFileManager.editModel.audioModel.AudioName.subscribe(function (value) {
                    if (value != "")
                        athoc.iws.AudioFileManager.editModel.isChanged(true);
                    else
                        athoc.iws.AudioFileManager.editModel.isChanged(false);
                });
                athoc.iws.AudioFileManager.editModel.audioModel.Description.subscribe(function (value) {
                    if (value != "")
                        athoc.iws.AudioFileManager.editModel.isChanged(true);
                    else
                        athoc.iws.AudioFileManager.editModel.isChanged(false);
                });
                athoc.iws.AudioFileManager.editModel.audioModel.Severity.subscribe(function (value) {
                    if (value != "")
                        athoc.iws.AudioFileManager.editModel.isChanged(true);
                    else
                        athoc.iws.AudioFileManager.editModel.isChanged(false);
                });
                athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity.subscribe(function (value) {
                    if (value != "")
                        athoc.iws.AudioFileManager.editModel.isChanged(true);
                    else
                        athoc.iws.AudioFileManager.editModel.isChanged(false);
                    athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity(value);
                    athoc.iws.AudioFileManager.CheckDefaultSeverityforTemplate(value);
                });



                athoc.iws.AudioFileManager.editModel.audioModel.Locale.subscribe(function (value) {
                    if (value != "")
                        athoc.iws.AudioFileManager.editModel.isChanged(true);
                    else
                        athoc.iws.AudioFileManager.editModel.isChanged(false);
                });

                document.getElementById("fUpload").value = "";

                $("#btnBrowse").addClass("fileinput-button-align");
                $("#btnBrowse").removeClass("fileinput-button-align-height");
                $("#newAudiofileManager").find(".bootstrap-select").remove();
                ko.cleanNode($("#newAudiofileManager").get(0));
                ko.applyBindings(athoc.iws.AudioFileManager.editModel, $("#newAudiofileManager").get(0));
                athoc.iws.AudioFileManager.initiateSelectPicker();

                $('#newMessagePanel').html('');
                $('#newAudiofileManager').modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        $("#newAudioNameTxt").attr("tabindex", 5).focus();
                    }, 1000);
                });
                fileData = null;
                $("#fUpload").fileupload({
                    dataType: 'json',
                    autoUpload: false,
                    maxFileSize: 5000000,
                    done: function (e, data) {
                        $.AjaxLoader.hideLoader();
                        if (data.result.Success) {
                            $.AjaxLoader.hideLoader();
                            document.getElementById("fUpload").value = "";
                            $("#newAudiofileManager").modal('hide');
                            athoc.iws.AudioFileManager.refreshGrid();
                            athoc.iws.AudioFileManager.listLoad();
                        }
                        else if (data.result.HasErrors) {
                            $.AjaxLoader.hideLoader();
                            $('#newMessagePanel').messagesPanel({ messages: data.result.Messages });
                            $("#newAudioNameTxt").focus();
                        }
                        else {
                            athoc.iws.AudioFileManager.handleError(data);
                        }
                        athoc.iws.AudioFileManager.editModel.isChanged(false);
                    },
                    add: function (e, data) {
                        fileData = data;
                        $('#newMessagePanel').html('');
                        $.each(data.files, function (index, file) {
                            var ext = file.name.split(".")[file.name.split(".").length - 1].toLowerCase();
                            $("#importFileText").val("");
                            if (ext !== "wav") {
                                var reqError = new Array();
                                reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_AudioFilePattern });
                                $('#newMessagePanel').messagesPanel({ messages: reqError });
                            } else {
                                $("#importFileText").val(file.name);
                                athoc.iws.AudioFileManager.editModel.audioModel.FileName(file.name);
                                athoc.iws.AudioFileManager.editModel.isChanged(true);
                            }
                        });

                    },
                    change: function (e, data) {

                    },
                    error: function (e) {
                        athoc.iws.AudioFileManager.handleError(e);
                    }
                });
            },



            // Display Edit Audio popup
            editAudioFile: function (model) {

                $(document).scrollTop(0);

                //athoc.iws.AudioFileManager.editModel.langSupports(athoc.iws.AudioFileManager.Languages);
                ko.cleanNode($("#editAudiofileManager").get(0));
                $("#editAudiofileManager").find(".bootstrap-select").remove();

                athoc.iws.AudioFileManager.editModel.audioModel = ko.mapping.fromJS(model);

                var defaultseverity = ((model.DefaultSeverity == "Y") || (model.ActualDefaultSeverity == "Y")) ? true : false;
                athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity(defaultseverity);

                athoc.iws.AudioFileManager.editModel.audioModel.AudioName.subscribe(function (value) {
                    athoc.iws.AudioFileManager.editModel.isChanged(true);
                    athoc.iws.AudioFileManager.editModel.audioModel.AudioName($.trim(athoc.iws.AudioFileManager.editModel.audioModel.AudioName()));
                });
                athoc.iws.AudioFileManager.editModel.audioModel.Description.subscribe(function () {
                    athoc.iws.AudioFileManager.editModel.isChanged(true);
                });
                athoc.iws.AudioFileManager.editModel.audioModel.AudioCommonName.subscribe(function (value) {
                    athoc.iws.AudioFileManager.editModel.isChanged(true);
                    athoc.iws.AudioFileManager.editModel.audioModel.AudioCommonName($.trim(athoc.iws.AudioFileManager.editModel.audioModel.AudioCommonName()));
                });



                athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity.subscribe(function (value) {
                    athoc.iws.AudioFileManager.editModel.isChanged(true);
                    //athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity($.trim(athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity()));

                    athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity(athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity());
                    athoc.iws.AudioFileManager.CheckDefaultSeverityforTemplate(value);

                });

                athoc.iws.AudioFileManager.editModel.audioModel.Severity.subscribe(function (value) {
                    athoc.iws.AudioFileManager.editModel.isChanged(true);
                    athoc.iws.AudioFileManager.editModel.audioModel.Severity($.trim(athoc.iws.AudioFileManager.editModel.audioModel.Severity()));
                    athoc.iws.AudioFileManager.CheckDefaultSeverityforTemplate(athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity());
                });
                athoc.iws.AudioFileManager.editModel.audioModel.Locale.subscribe(function (value) {
                    athoc.iws.AudioFileManager.editModel.isChanged(true);
                    athoc.iws.AudioFileManager.editModel.audioModel.Locale($.trim(athoc.iws.AudioFileManager.editModel.audioModel.Locale()));
                    athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity(athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity());
                    athoc.iws.AudioFileManager.CheckDefaultSeverityforTemplate(athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity());
                });

                //athoc.iws.AudioFileManager.clearFilters();

                ko.applyBindings(athoc.iws.AudioFileManager.editModel, $("#editAudiofileManager").get(0));
                athoc.iws.AudioFileManager.initiateSelectPicker();

                $('#editMessagePanel').html('');
                $('#editAudiofileManager').modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        $("#editAudioNameTxt").attr("tabindex", 10).focus();
                    }, 1000);
                });
                document.getElementById("fEUpload").value = "";
                fileData = null;
                $('[data-id=ddlEditLocale]').attr("disabled", "disabled");
                $("#importEditFileText").val('');
                fileEditData = $("#fEUpload").fileupload({
                    dataType: 'json',
                    autoUpload: false,
                    maxFileSize: 5000000,
                    done: function (e, data) {
                        $.AjaxLoader.hideLoader();
                        if (data.result.Success) {
                            $.AjaxLoader.hideLoader();
                            document.getElementById("fEUpload").value = "";
                            $("#editAudiofileManager").modal('hide');
                            athoc.iws.AudioFileManager.refreshGrid();
                            athoc.iws.AudioFileManager.listLoad();
                            athoc.iws.AudioFileManager.editModel.SevArray(data.SeverityList);
                            athoc.iws.AudioFileManager.editModel.langSupports(athoc.iws.AudioFileManager.Languages);
                        }
                        else if (data.result.HasErrors) {
                            $.AjaxLoader.hideLoader();
                            $('#editMessagePanel').messagesPanel({ messages: data.result.Messages });
                            $("#editAudioNameTxt").focus();
                        }
                        else {
                            athoc.iws.AudioFileManager.handleError(data);
                        }
                        athoc.iws.AudioFileManager.editModel.isChanged(false);
                    },
                    add: function (e, data) {
                        fileEditData = data;
                        $('#editMessagePanel').html('');
                        $.each(data.files, function (index, file) {
                            var ext = file.name.split(".")[file.name.split(".").length - 1].toLowerCase();
                            $("#importEditFileText").val("");
                            if (ext !== "wav") {
                                var reqError = new Array();
                                reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_AudioFilePattern });
                                $('#editMessagePanel').messagesPanel({ messages: reqError });
                            } else {
                                $("#importEditFileText").val(file.name);
                                athoc.iws.AudioFileManager.editModel.isChanged(true);
                            }
                        });

                    },
                    change: function (e, data) {

                    },
                    error: function (e) {
                        $.AjaxLoader.hideLoader();
                        athoc.iws.AudioFileManager.handleError(e);
                    }
                });
                athoc.iws.AudioFileManager.editModel.isChanged(false);
            },

            deleteAudioFileFromList: function () {
                var items = datasource.data();
                var selectedIds = new Array();
                var selectedNames = new Array();
                var selectedGScopeCnt = 0;
                var nameTags = "";
                $("#privateFiles").hide();
                $("#globalFiles").hide();
                $("#itemsToDelete").hide();
                $("#itemsToDelete").html('');
                $("#btnDeleteConfirm").attr("disabled", true);
                $.grep(items, function (v) {
                    if (v.IsChecked) {

                        if (athoc.iws.AudioFileManager.ContextProvider == v.providerId) {
                            if ((v.DefaultSeverity == "N") || ((v.providerId != 3) && (v.DefaultSeverity == "Y"))) {
                                selectedIds.push(v.AudioId);
                                selectedNames.push(v.AudioName);
                            }
                            else
                                selectedGScopeCnt++;
                        }
                        else
                            selectedGScopeCnt++;
                    }
                });

                if (selectedIds.length > 0) {
                    $("#privateFiles").show();
                    $("#itemsToDelete").show();
                    $("#btnDeleteConfirm").removeAttr("disabled");
                    $("#privateFiles").text(athoc.iws.AudioFileManager.resources.Settings_AudioFile_PrivateDeleteDialogText.replace("{0}", selectedIds.length) + '.');
                    if (selectedGScopeCnt > 0) {
                        $("#privateFiles").text(athoc.iws.AudioFileManager.resources.Settings_AudioFile_PrivateDeleteDialogText.replace("{0}", selectedIds.length) + ', ' + athoc.iws.AudioFileManager.resources.Settings_AudioFile_GlobalDeleteDialogText.replace("{0}", selectedGScopeCnt));
                    }
                    selectedNames.sort();
                    for (var i = 0; i < selectedNames.length; i++) {
                        nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(selectedNames[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(selectedNames[i]) + "</div>";
                    }
                    $("#itemsToDelete").html("<div class='mar-top10'>" + nameTags + "</div>");
                }
                else if (selectedGScopeCnt > 0) {
                    selectedNames.sort();
                    for (var i = 0; i < selectedNames.length; i++) {
                        nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(selectedNames[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(selectedNames[i]) + "</div>";
                    }
                    $("#itemsToDelete").html("<div class='mar-top10'>" + nameTags + "</div>");
                    $("#itemsToDelete").show();
                    $("#globalFiles").show();
                    $("#globalFiles").text(athoc.iws.AudioFileManager.resources.Settings_AudioFile_GlobalDeleteDialogText.replace("{0}", selectedGScopeCnt));
                }

                $('#dialogDeleteConfirm').modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        $("#btnDeleteCancel").attr("tabindex", 15).focus();
                    }, 1000);
                });
            },

            // Triggered, when Edit link clicked from more action
            actionEditAudioFile: function () {

                var item = athoc.iws.AudioFileManager.selectedAudioFile();
                if (item != -1) {
                    athoc.iws.AudioFileManager.editAudioFile(item);
                }
            },

            // Triggered, when Play link clicked from more action
            actionPlayAudioFile: function () {
                var item = athoc.iws.AudioFileManager.selectedAudioFile();
                if (item != -1) {
                    athoc.iws.AudioFileManager.playAudioFile(item);
                }
            },

            // Triggered, when Download link clicked from more action click
            actionDownloadAudioFile: function () {
                var item = athoc.iws.AudioFileManager.selectedAudioFile();
                if (item != -1) {
                    var url = "AudioFileManager/DownloadAudioFile?audioId=" + item.AudioId + "&audioName=" + item.AudioName + ".wav";
                    $.fileDownload(url, {
                        httpMethod: "GET",
                        successCallback: function () {
                        },
                        failureCallback: function (e) {
                            athoc.iws.AudioFileManager.handleError(e);
                        }
                    });
                }

            },

            // Check multiple audio files are checked or not
            selectedAudioFile: function () {
                var items = datasource.view();
                var r = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                if (r.length == 1)
                    return r[0];
                else
                    return -1;
            },

            // Triggered, when selected the audio file
            audioChange: function () {
                var file = document.getElementById("fUpload").files[0];
                if (file != null)
                    athoc.iws.AudioFileManager.editModel.audioModel.FileName(file.name);

            },

            // Triggered, When deleteing the audio records
            deleteAudioFileManager: function () {
                $('#saveMessagePanel').html('');

                // Get selected audio records
                var items = datasource.data();
                ids.length = 0;
                // Keep selected audio records in array
                $.grep(items, function (v) {
                    if (v.IsChecked) {
                        if (!v.AudioOwner) {
                            ids.push(v.AudioId);
                        }
                    }
                });

                var dlAjaxOption =
                    {
                        url: athoc.iws.AudioFileManager.urls.DeleteAudioFileUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(ids),
                        success: function (data) {
                            $("#dialogDeleteConfirm").modal('hide');
                            athoc.iws.AudioFileManager.refreshGrid();
                            athoc.iws.AudioFileManager.listLoad();
                        },
                        error: function (e) {
                            $("#dialogDeleteConfirm").modal('hide');
                            athoc.iws.AudioFileManager.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);

                $.ajax(ajaxOptions);

                return true;
            },

            // Editing selected audio file 
            editAudioFileManager: function () {


                $('#editMessagePanel').html('');


                var dataPost = ko.toJSON(athoc.iws.AudioFileManager.editModel.audioModel);
                var dlAjaxOption =
                    {
                        url: athoc.iws.AudioFileManager.urls.EditAudioUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: dataPost,
                        success: function (data) {
                            if (data.Success) {
                                $.AjaxLoader.hideLoader();
                                $("#editAudiofileManager").modal('hide');
                                athoc.iws.AudioFileManager.refreshGrid();
                                athoc.iws.AudioFileManager.listLoad();
                                $("#ddlSeverity").selectpicker('refresh');
                                $("#ddlEditSeverity").selectpicker('refresh');
                                $("#ddlLocale").selectpicker('refresh');
                                $("#ddlEditLocale").selectpicker('refresh');

                            } else {
                                $.AjaxLoader.hideLoader();
                                if (data.HasErrors) {
                                    $('#editMessagePanel').messagesPanel({ messages: data.Messages });
                                    if (data.Sender == 1)
                                        $("#editAudioNameTxt").focus();
                                    else if (data.Sender == 2)
                                        $("#audioCommonametxt").focus();

                                }
                            }
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.AudioFileManager.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#editAudiofileManager'), imageURL: athoc.iws.AudioFileManager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();

                $.ajax(ajaxOptions);
                isModalOpened = false;
                return true;

            },
            initiateSelectPicker: function () {

                $("#ddlSeverity").selectpicker();
                $("#ddlEditSeverity").selectpicker();
                $("#ddlLocale").selectpicker();
                $("#ddlEditLocale").selectpicker();

            },
            UploadEditAudioFile: function () {

                $('#editMessagePanel').html('');
                var dataPost = ko.toJSON(athoc.iws.AudioFileManager.editModel.audioModel);
                // Validate audio data
                if (!athoc.iws.AudioFileManager.performEditAudioValidation())
                    return false;
                athoc.iws.AudioFileManager.editModel.isChanged(false);
                if ($("#importEditFileText").val() != "") {
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#editAudiofileManager'), imageURL: athoc.iws.AudioFileManager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                    $('#fEUpload').fileupload({
                        formData: { audioFile: dataPost }
                    });
                    fileEditData.submit();
                }
                else
                    athoc.iws.AudioFileManager.editAudioFileManager();

            },
            performEditAudioValidation: function () {
                var reqError = new Array();
                var focusField = null;
                if (!athoc.iws.AudioFileManager.isRequired(athoc.iws.AudioFileManager.editModel.audioModel.AudioName(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_NameRequired, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    focusField = "#editAudioNameTxt";
                }
                if (!athoc.iws.AudioFileManager.maxLength(athoc.iws.AudioFileManager.editModel.audioModel.AudioName(), 100)) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_NameMaxLength, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#editAudioNameTxt";
                }

                if (!athoc.iws.AudioFileManager.pattern(athoc.iws.AudioFileManager.editModel.audioModel.AudioName(), "^[^'^%^^&/^:^*^?^\^\"^<^>^|]+$")) { 
                    reqError.push({ Type: '4', Value: $.htmlDecode(athoc.iws.AudioFileManager.resources.Settings_AudioFile_NamePattern), Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#editAudioNameTxt";
                }
                if (!athoc.iws.AudioFileManager.maxLength(athoc.iws.AudioFileManager.editModel.audioModel.Description(), 200)) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_DescriptionMaxLength, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#audioDescEditTxt";
                }
                if (!athoc.iws.AudioFileManager.pattern(athoc.iws.AudioFileManager.editModel.audioModel.Description(), "^[^/^&^\'^\"^<^>^]+$")) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_DescPattern, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#audioDescEditTxt";
                }

                if (!athoc.iws.AudioFileManager.isRequired(athoc.iws.AudioFileManager.editModel.audioModel.AudioCommonName(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_CommonNamePattern, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#audioCommonametxt";
                }

                if (!athoc.iws.AudioFileManager.maxLength(athoc.iws.AudioFileManager.editModel.audioModel.AudioCommonName(), 100)) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_AudioCommonNameMaxLength, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#audioCommonametxt";
                }

                if (!athoc.iws.AudioFileManager.pattern(athoc.iws.AudioFileManager.editModel.audioModel.AudioCommonName(), "^[^'^%^^&/^:^*^?^\^\"^<^>^|]+$")) {
                    reqError.push({ Type: '4', Value: $.htmlDecode(athoc.iws.AudioFileManager.resources.Settings_AudioFile_AudioCommonNamePattern), Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#audioCommonametxt";
                }

                if (!athoc.iws.AudioFileManager.pattern($("#importEditFileText").val(), ".*\.(WAV|wav)$")) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_AudioFilePattern, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#fEUpload";
                }
                if (reqError.length > 0) {
                    $('#editMessagePanel').messagesPanel({ messages: reqError });
                    $(focusField).focus();
                    return false;
                }
                return true;
            },
            isRequired: function (val, required) {
                var stringTrimRegEx = /^\s+|\s+$/g,
                    testVal;

                if (val === undefined || val === null) {
                    return !required;
                }

                testVal = val;
                if (typeof (val) == "string") {
                    testVal = val.replace(stringTrimRegEx, '');
                }

                return required && (testVal + '').length > 0;
            },
            maxLength: function (val, maxLength) {
                return athoc.iws.AudioFileManager.isEmptyVal(val) || val.length <= maxLength;
            },
            isEmptyVal: function (val) {
                if (val == undefined) {
                    return true;
                }
                if (val == null) {
                    return true;
                }
                if (val == "") {
                    return true;
                }
            },
            pattern: function (val, regex) {
                if (athoc.iws.AudioFileManager.isEmptyVal(val))
                    return athoc.iws.AudioFileManager.isEmptyVal(val);
                else if (athoc.iws.AudioFileManager.backslaceValidation(val))
                    return !athoc.iws.AudioFileManager.backslaceValidation(val);
                else
                    return val.match(regex) != null;
            },
            backslaceValidation: function (val) {

                for (var i = 0; i < val.length; i++) {
                    if (val.charAt(i) == "\\")
                        return true;
                }
            },
            performNewAudioValidation: function () {
                var reqError = new Array();
                var focusField = null;
                if (!athoc.iws.AudioFileManager.isRequired(athoc.iws.AudioFileManager.editModel.audioModel.AudioName(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_NameRequired, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    focusField = "#newAudioNameTxt";
                }
                if (!athoc.iws.AudioFileManager.maxLength(athoc.iws.AudioFileManager.editModel.audioModel.AudioName(), 100)) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_NameMaxLength, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#newAudioNameTxt";
                }
                if (!athoc.iws.AudioFileManager.pattern(athoc.iws.AudioFileManager.editModel.audioModel.AudioName(), "^[^'^%^^&/^:^*^?^\^\"^<^>^|]+$")) {
                    reqError.push({ Type: '4', Value: $.htmlDecode(athoc.iws.AudioFileManager.resources.Settings_AudioFile_NamePattern), Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#newAudioNameTxt";
                }

                if (!athoc.iws.AudioFileManager.maxLength(athoc.iws.AudioFileManager.editModel.audioModel.Description(), 200)) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_DescriptionMaxLength, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#audioDescTxt";
                }
                if (!athoc.iws.AudioFileManager.pattern(athoc.iws.AudioFileManager.editModel.audioModel.Description(), "^[^/^&^\'^\"^<^>^]+$")) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_DescPattern, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#audioDescTxt";
                }
                if (!athoc.iws.AudioFileManager.isRequired(athoc.iws.AudioFileManager.editModel.audioModel.FileName(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_AudioFileRequired, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#fUpload";
                }
                if (!athoc.iws.AudioFileManager.pattern(athoc.iws.AudioFileManager.editModel.audioModel.FileName(), ".*\.(WAV|wav)$")) {
                    reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.Settings_AudioFile_AudioFilePattern, Header: athoc.iws.AudioFileManager.resources.General_ErrorLabel });
                    if (focusField == null)
                        focusField = "#fUpload";
                }

                if (reqError.length > 0) {
                    $('#newMessagePanel').messagesPanel({ messages: reqError });
                    $(focusField).focus();
                    return false;
                }
                return true;
            },
            UploadAudioFile: function () {

                $('#newMessagePanel').html('');
                athoc.iws.AudioFileManager.editModel.audioModel.AudioCommonName(athoc.iws.AudioFileManager.editModel.audioModel.AudioName());
                // Validate audio data
                if (!athoc.iws.AudioFileManager.performNewAudioValidation())
                    return false;
                athoc.iws.AudioFileManager.editModel.audioModel.Severity(athoc.iws.AudioFileManager.getDropdownvalue(athoc.iws.AudioFileManager.editModel.SevArray(), athoc.iws.AudioFileManager.editModel.audioModel.Severity()));
                if ($("#importFileText").val() != "") {
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#newAudiofileManager'), imageURL: athoc.iws.AudioFileManager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                    $('#fUpload').fileupload({
                        formData: {
                            audioName: athoc.iws.AudioFileManager.editModel.audioModel.AudioName(),
                            description: $.htmlEncode(athoc.iws.AudioFileManager.editModel.audioModel.Description()),
                            severity: athoc.iws.AudioFileManager.editModel.audioModel.Severity(),
                            defaultseverity: athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity(),
                            locale: athoc.iws.AudioFileManager.editModel.audioModel.Locale()
                        }
                    });
                    fileData.submit();

                }
            },
            // Saving new audio file
            saveAudioFile: function (audioId) {

                $('#newMessagePanel').html('');
                athoc.iws.AudioFileManager.editModel.audioModel.AudioCommonName(athoc.iws.AudioFileManager.editModel.audioModel.AudioName());
                // Validate audio data
                if (!athoc.iws.AudioFileManager.performNewAudioValidation())
                    return false;
                //var result = ko.validation.group(athoc.iws.AudioFileManager.editModel.audioModel, { deep: true });

                var file = document.getElementById("fUpload").files[0];
                // Keep audio file and data in one object
                var formData = new FormData();
                formData.append("audioName", $.trim(athoc.iws.AudioFileManager.editModel.audioModel.AudioName()));
                formData.append("description", $.trim(athoc.iws.AudioFileManager.editModel.audioModel.Description()));
                formData.append("uploadFile", file);
                formData.append("severity", $.trim(athoc.iws.AudioFileManager.editModel.audioModel.Severity(athoc.iws.AudioFileManager.getDropdownvalue(athoc.iws.AudioFileManager.editModel.SevArray(), athoc.iws.AudioFileManager.editModel.audioModel.Severity()))));
                formData.append("defaultseverity", $.trim(athoc.iws.AudioFileManager.editModel.audioModel.DefaultSeverity()));
                formData.append("locale", $.trim(athoc.iws.AudioFileManager.editModel.audioModel.Locale()));
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#newAudiofileManager'), imageURL: athoc.iws.AudioFileManager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        url: athoc.iws.AudioFileManager.urls.SaveAudioFilesUrl,
                        contentType: false,
                        type: 'POST',
                        data: formData,
                        cache: false,
                        processData: false,
                        success: function (data) {
                            if (data.Success) {
                                $.AjaxLoader.hideLoader();
                                document.getElementById("fUpload").value = "";
                                $("#newAudiofileManager").modal('hide');
                                athoc.iws.AudioFileManager.refreshGrid();
                                athoc.iws.AudioFileManager.listLoad();
                            }
                            else if (data.HasErrors) {
                                $.AjaxLoader.hideLoader();
                                $('#newMessagePanel').messagesPanel({ messages: data.Messages });
                                $("#newAudioNameTxt").focus();
                            }
                            else {
                                athoc.iws.AudioFileManager.handleError(data);
                            }
                            athoc.iws.AudioFileManager.editModel.isChanged(false);
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.AudioFileManager.handleError(e);
                            athoc.iws.AudioFileManager.editModel.isChanged(false);
                        }

                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },


            // Triggered, when clear all link is clicked, it clear the searchCriteria and reload the grid
            clearFilters: function () {
                $("#txtAudioSearchText").val("");
                $("#chkPublicAudio").prop("checked", true);
                $("#searchBtn").attr('disabled', 'true');
                athoc.iws.AudioFileManager.audioSearchCriteria.searchString = "";
                athoc.iws.AudioFileManager.audioSearchCriteria.isAudioPublic = true;
                athoc.iws.AudioFileManager.refreshGrid();
                athoc.iws.AudioFileManager.listLoad();
                $("#pillContainer").html("");
                $("#pillContainer").hide();
                athoc.iws.AudioFileManager.searchString.length = 0;
                athoc.iws.AudioFileManager.setGridHeight();
                $("#btnCrossTenant").trigger("click");
                $("#ddlSeverity").selectpicker('refresh');
                $("#ddlEditSeverity").selectpicker('refresh');
                $("#ddlLocale").selectpicker('refresh');
                $("#ddlEditLocale").selectpicker('refresh');
                $("#AudioError").hide();
                $("#errAudioSearchText").addClass("hide");
            },

            // Triggered, when search button or hit enter in search textbox
            search: function () {
                if ($("#txtAudioSearchText").length <= athoc.iws.AudioFileManager.searchMaxLength) {
                    athoc.iws.AudioFileManager.audioSearchCriteria.searchString = athoc.iws.AudioFileManager.searchString;
                    athoc.iws.AudioFileManager.audioSearchCriteria.isAudioPublic = $("#chkPublicAudio").is(':checked');
                    athoc.iws.AudioFileManager.refreshGrid();
                    athoc.iws.AudioFileManager.listLoad();
                    if ($('#AudioError').css('display') == 'block') {
                        $(".k-grid-header").attr('style', "top:257px;");
                        $(".kgrid-fix-header").attr('style', "top:0px;");
                        $(".table-crown-center").attr('style', "top:0px;height:auto;");
                    } 
                   
                }
                else
                    $('#saveMessagePanel').modal("show");
                //$("#txtAudioSearchText").focus();
            },
            // It plays the selected audio file
            playAudioFile: function (model) {
                //eventually call utilities from here
                if (navigator.vendor && navigator.vendor.indexOf('Apple') > -1 &&
                    navigator.userAgent && !navigator.userAgent.match('CriOS')) {
                    athoc.iws.utilities.playAudio("/csi/getAudio.asp?id=" + model.AudioId);
                }
                else if (navigator.userAgent.toLowerCase().indexOf('trident') == -1) {
                    //7313. Changed the download url to the legacy asp page because there is an authentication issue w/ safari.
                    $("#audioPlayer").attr("src", "/csi/getAudio.asp?id=" + model.AudioId).trigger("play");

                } else {
                    bgPlay.src = "/csi/getAudio.asp?id=" + model.AudioId;
                }
            },

            // Triggered, when 'Select All' check box is checked
            audioSelectAll: function () {

                //change the underlying observable...
                var checked = $('#chkSelectAll').is(':checked');
                var grid = $('#audiofilemanagerList').data().kendoGrid;
                $.each(grid.dataSource.view(), function (i, item) {
                    item.IsChecked = checked;
                });
                grid.refresh();//update the grid...
                athoc.iws.AudioFileManager.retainSelectAll();// update view count to enable/disable action items
                athoc.iws.AudioFileManager.updateSelectedTotal();// Update selected count
            },

            listLoad: function () {

                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
            },

            // Preaparing Grid to display audio files
            createAudioFileManagerListGrid: function () {

                var self = this;
                var url = athoc.iws.AudioFileManager.urls.GetAudioFilesUrl;

                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            if ($.isArray(athoc.iws.AudioFileManager.audioSearchCriteria.searchString) && athoc.iws.AudioFileManager.audioSearchCriteria.searchString.length == 0) {
                                athoc.iws.AudioFileManager.audioSearchCriteria.searchString = "";
                            }
                            $.extend(options, athoc.iws.AudioFileManager.audioSearchCriteria);
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                    },
                    requestEnd: function (e) {

                        if (e.response) {

                            if (e.response.Success != undefined && e.response.Success) {
                                athoc.iws.AudioFileManager.viewModel.set("totalCount", e.response.TotalCount);
                                athoc.iws.AudioFileManager.editModel.SevArray(e.response.SeverityList);
                                athoc.iws.AudioFileManager.editModel.defaultSeverties(e.response.defaultSeverties);


                                //clear selected
                                athoc.iws.AudioFileManager.viewModel.set("selectedCount", 0);
                                athoc.iws.AudioFileManager.Languages = e.response.languages;
                                athoc.iws.AudioFileManager.Languages.unshift({ LanguageName: athoc.iws.AudioFileManager.resources.Settings_AudioFile_Locale_Any, LocalCode: athoc.iws.AudioFileManager.resources.Settings_AudioFile_Locale_Any });
                                athoc.iws.AudioFileManager.editModel.langSupports(athoc.iws.AudioFileManager.Languages);
                                $('#chkSelectAll').attr("checked", false);
                                athoc.iws.AudioFileManager.editModel.selectedCnt(0);
                                athoc.iws.AudioFileManager.editModel.selectedViewCnt(0);
                                athoc.iws.AudioFileManager.ContextProvider = e.response.ContextProvider;
                                $("#AudioError").hide();
                                $.AjaxLoader.hideLoader();
                                $("#btn_new").removeAttr('disabled');
                            }
                            else {

                                $.AjaxLoader.hideLoader();
                                $("#pillContainer").html("");
                                $("#pillContainer").hide();
                                athoc.iws.AudioFileManager.searchString.length = 0;
                                $("#AudioError").show();
                                athoc.iws.AudioFileManager.setGridHeight();
                            }
                        }
                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                    },
                    sort: { field: "AudioName", dir: "asc" },
                    pageSize: 50,
                    error: function (e) {
                        athoc.iws.AudioFileManager.handleError(e);
                    },
                    change: function (e) {
                        athoc.iws.AudioFileManager.retainSelectAll();
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            //when sort changes, go to first page.
                            this.page(1);
                        }
                        //scrolling to the top when paging and sorting.
                        $("html,body").scrollTop(0);
                    }

                });

                $("#pageInfo").kendoPager({
                    dataSource: datasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.AudioFileManager.resources.Settings_AudioFile_ListPageInfo,
                        empty: this.resources.AtHoc_Pager_Message_Empty
                    }
                });

                var grid = $("#audiofilemanagerList").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    top: 130,
                    selectable: true,
                    sortable: {
                        allowUnsort: false
                    },

                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: athoc.iws.AudioFileManager.resources.Settings_AudioFile_ListPageInfo,
                            empty: this.resources.AtHoc_Pager_Message_Empty,
                            first: athoc.iws.AudioFileManager.resources.AtHoc_Pager_Message_Go_To_The_First_Page,
                            previous: athoc.iws.AudioFileManager.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page,
                            next: athoc.iws.AudioFileManager.resources.AtHoc_Pager_Message_Go_To_The_Next_Page,
                            last: athoc.iws.AudioFileManager.resources.AtHoc_Pager_Message_Go_To_The_Last_Page,
                            itemsPerPage: athoc.iws.AudioFileManager.resources.AtHoc_Pager_Message_Items_Per_Page,
                        }
                    },
                    columns:
                            [
                                {
                                    field: "IsChecked",
                                    template: $("#audiofilemanager-chkDelete-template").html(),
                                    width: 25,
                                    title: "",
                                    headerTemplate: kendo.format('<input type="checkbox" class="senario-select" id="chkSelectAll" title="{0}" onclick="athoc.iws.AudioFileManager.audioSelectAll();" />', athoc.iws.AudioFileManager.resources.Settings_AudioFile_ChkSelect),
                                    sortable: false,
                                    headerAttributes: {
                                        style: "cursor: default",
                                    }
                                },
                                {
                                    field: "AudioName",

                                    template: '#=athoc.iws.AudioFileManager.getDefaultAudioName(AudioName,DefaultSeverity)#',
                                    title: "",
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', athoc.iws.AudioFileManager.resources.Settings_AudioFile_AudioNameTitle, athoc.iws.AudioFileManager.resources.Settings_AudioFile_Name),
                                    width: 250,
                                    headerAttributes: {
                                        tabindex: "240"
                                    }
                                },
                                {
                                    field: "Severity",
                                    title: '',
                                    template: '#=athoc.iws.AudioFileManager.getSeverityName(Severity)#',
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', athoc.iws.AudioFileManager.resources.Settings_AudioFile_Severity_Title, athoc.iws.AudioFileManager.resources.Settings_AudioFile_Severity),
                                    width: 80,
                                    headerAttributes: {
                                        tabindex: "240"
                                    }
                                },

                                 {
                                     field: "AudioScope",
                                     title: '',
                                     template: '<span title="#=$.htmlEncode(AudioScope)#">#=$.htmlEncode(AudioScope)#</span>',
                                     headerTemplate: kendo.format('<span title="{0}">{1}</span>', athoc.iws.AudioFileManager.resources.Settings_AudioFile_AudioScopeTitle, athoc.iws.AudioFileManager.resources.Settings_AudioFile_Scope),
                                     width: 80,
                                     headerAttributes: {
                                         tabindex: "240"
                                     }
                                 },

                                {
                                    field: "AudioSize",
                                    title: '',
                                    template: '<span title="#=AudioSize#">#=AudioSize#</span>',
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', athoc.iws.AudioFileManager.resources.Settings_AudioFile_AudioSizeTitle, athoc.iws.AudioFileManager.resources.Settings_AudioFile_Size),
                                    width: 60,
                                    headerAttributes: {
                                        tabindex: "240"
                                    }
                                },


                                 {
                                     field: "Locale",
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.AudioFileManager.resources.AudioFile_Locale_Sort, athoc.iws.AudioFileManager.resources.AudioFile_Locale),
                                     template: "#= athoc.iws.AudioFileManager.getLanguageName(Locale) #",
                                     width: 150,
                                 },

                            ],
                    dataBound: athoc.iws.AudioFileManager.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                        this.select().removeClass("k-state-selected");
                        audioNameToolTip.data("kendoTooltip").hide();
                        //this.select().addClass("k-alt");

                        athoc.iws.AudioFileManager.editAudioFile(model);
                    }
                }).data().kendoGrid;

                var lastMouseX;
                var $template = kendo.template($("#audioname-tooltip-template").html());
                var audioNameToolTip = $("#audiofilemanagerList").kendoTooltip({
                    filter: "td:nth-child(2)", //this filter selects the first column cells
                    position: "right",
                    show: function () {
                        $(this.popup.wrapper).css({
                            left: lastMouseX + 60
                        });                      
                    },
                    content: function (e) {
                        e.sender.content.parent().addClass('audio-file-tooltip');
                        var dataItem = $("#audiofilemanagerList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    }
                }).on('mouseout', function () {
                    audioNameToolTip.data('kendoTooltip').hide();
                });              

                $(document).on("mousemove", function (e) {
                    lastMouseX = e.pageX;
                    $(".audio-file-tooltip").parent().css({
                        left: lastMouseX + 60
                    });
                });
                ko.applyBindings(athoc.iws.AudioFileManager.editModel, $("#SelectedCount").get(0));
                ko.applyBindings(athoc.iws.AudioFileManager.editModel, $("#divActions").get(0));

                this.refreshGrid();

            },

            refreshGrid: function () {
                //show the loader when we make a request to the server..
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#audiofilemanagerList'), imageURL: athoc.iws.AudioFileManager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: this.resources.General_LoadingMessage }).showLoader();
                datasource.read();
            },
            errors: null,
            //Method to handle erro and session time out, this is boud with Ajax calls
            handleError: function (e) {

                if ((e != undefined && e.status == 401) || (e != undefined && e.xhr != undefined && e.xhr.status == 401)) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else if (e.errorThrown != "") {
                    if (athoc.iws.AudioFileManager.errors === null) {
                        athoc.iws.AudioFileManager.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.AudioFileManager.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#saveMessagePanel').messagesPanel({ messages: this.errors });
                }
            },

            OnDataBound: function (e) {

                $("#audiofilemanagerList tbody").find("tr").attr("tabindex", "0");

                var grid = $("#audiofilemanagerList").data("kendoGrid");

                // Keep the viewmodel update when we select the audio file 
                grid.tbody.on("change", ".audiofilemanager-select", function (e) {
                    var row = $(e.target).closest("tr");
                    var item = grid.dataItem(row);
                    item.IsChecked = $(e.target).is(":checked");
                    // Check all audio files are checked if so check 'Select All' checkbox
                    athoc.iws.AudioFileManager.retainSelectAll();
                    // Updtate the selected count
                    athoc.iws.AudioFileManager.updateSelectedTotal();

                });

                if (athoc.iws.AudioFileManager.isRightToLeft) {
                    $("#audiofilemanagerList").find('.pull-right').addClass('pull-left');
                    $("#audiofilemanagerList").find('.pull-right').removeClass('pull-right');
                }

                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(e.sender.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.AudioFileManager.resources.IWS_Common_NoRecordsFound + '</td></tr>');
                }

            },

            // Check all audio files are checked if so then check 'Select All' checkbox
            retainSelectAll: function () {
                var items = datasource.view();

                // Get the selected items for the current page.
                var selected = $.grep(items, function (v) {
                    return v.IsChecked;
                });
                athoc.iws.AudioFileManager.editModel.selectedViewCnt(selected.length);
                // Check total page count equal to selected count 
                var checked = selected.length > 0 && (items.length == selected.length);
                $("#chkSelectAll").prop('checked', checked);
            },

            // It Updates the selected count in a grid
            updateSelectedTotal: function () {
                var items = datasource.data();
                var r = $.grep(items, function (v) {
                    return v.IsChecked;
                });
                athoc.iws.AudioFileManager.editModel.selectedCnt(r.length);

            },

            // It is not used, need to remove
            getAudioFileId: function (obj) {

                var items = datasource.data();
                var r = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                ids = new Array();
                $('.k-grid-content table input:checked').each(function (item, index) {
                    ids.push($(this).val());
                });

                if (ids.length > 0)
                    $("#btn_delete").removeAttr('disabled');
                else
                    $("#btn_delete").attr('disabled', 'disabled');
                return -1;
            },

            // To validate Audio File before save/edit
            getValidation: function (flag) {
                //remove old validation
                $(".warning").each(function () {
                    $(this).parent().remove();
                });

                var validationMapping = {
                    AudioName: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: true,
                                maxLength: 100,
                                pattern: {
                                    message: 'The following characters are not allowed in name % \\ / : * ? " < > | [ ]',
                                    params: "^[a-zA-Z0-9 _@#-.~!$&()={}^]+$"
                                }
                            });
                        }
                    },
                    FileName: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: true,
                                pattern: {
                                    message: 'Audio file must be a WAV file',
                                    params: ".*\.(WAV|wav)$"
                                }
                            });
                        }
                    },
                    AudioCommonName: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: true
                            });
                        }
                    },
                    Description: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: 200
                            });
                        }
                    },

                };

                return validationMapping;
            },

            // Createing pills when search is done
            createPills: function (value, type, display) {
                if (value == "")
                    return;
                var found = _.find(athoc.iws.AudioFileManager.searchString, function (item) {
                    return (item.value == value && item.type == type);
                });
                if (!found) {
                    athoc.iws.AudioFileManager.searchString.push(value);
                    //athoc.iws.AudioFileManager.searchString.push({ value: value, type: type, display: display });
                    athoc.iws.AudioFileManager.renderPills();
                    athoc.iws.AudioFileManager.search();

                }
            },

            // Rendering the pills when search is done
            renderPills: function (css) {
                var self = this;
                var html = "";
                $("#filterContent .pill-container").html('');
                if (athoc.iws.AudioFileManager.searchString && athoc.iws.AudioFileManager.searchString.length > 0) {
                    _.each(athoc.iws.AudioFileManager.searchString, function (item, index) {
                        var iconCss = "";
                        var prefix = "";
                        //html += '<div class="pill" data-index="' + index + '"><span class="pill-content">' + prefix + item.display + '</span><div class="pill-icon ' + iconCss + '"></div><a class="pill-close" href="javascript://"></a></div>';
                        var pillLabel = prefix + $.htmlEncode(item);
                        var pillTooltip = prefix + $.htmlEncode(item);
                        var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" href="#"></a>' : '');
                        html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                    });

                    var pillsElm = $("#filterContent .pill-container");
                    pillsElm.html(html);
                    //wire up events
                    $("#filterContent .pill-close").click(function (event) {
                        var parentElm = $(this).parent(".pill");
                        athoc.iws.AudioFileManager.deSelect(parentElm.data("index"));

                        if ($('#errAudioSearchText').is(':visible')) {
                            $(".k-grid-header").attr('style', "top:245px;");
                            $(".kgrid-fix-header").attr('style', "top:0px;");
                            $(".table-crown-center").attr('style', "top:0px;height:auto;");
                            $("#topSpace").css("height", "245px");
                        } else {
                            athoc.iws.AudioFileManager.setGridHeight();
                        }
                        
                        event.stopPropagation();
                    });
                    athoc.iws.AudioFileManager.setGridHeight();
                }
            },

            // Deleteing the pills
            deSelect: function (index, onSuccess) {
                if (athoc.iws.AudioFileManager.searchString && athoc.iws.AudioFileManager.searchString.length > index) {
                    athoc.iws.AudioFileManager.searchString.splice(index, 1);
                    athoc.iws.AudioFileManager.renderPills();
                    athoc.iws.AudioFileManager.search();
                    athoc.iws.AudioFileManager.setGridHeight();
                }
            },
            // Keep grid height according to the pills.
            setGridHeight: function () {

                if (athoc.iws.AudioFileManager.searchString.length > 0) {

                    $("#filterContent").css("margin-top", "46px");
                    $("#topSpace").css("height", "257px");


                    if ($('#AudioError').css('display') == 'block') {
                        $(".k-grid-header").attr('style', "top:294px;");
                        $(".kgrid-fix-header").attr('style', "top:32px;");
                        $(".table-crown-center").attr('style', "top:40px;height:auto;");
                    }
                    else {
                        $(".k-grid-header").css("top", "257px");
                        $('.kgrid-fix-header').attr('style', "top:0px;");
                        $(".table-crown-center").attr('style', "top:0px;height:auto;");
                    }

                }
                else {

                    if ($('#AudioError').css('display') == 'block') {
                        $(".k-grid-header").css("top", "257px");
                        $('.kgrid-fix-header').attr('style', "top:0px;");
                        $(".table-crown-center").attr('style', "top:40px;height:auto;");
                    } else {
                        $(".k-grid-header").css("top", "210px");
                        $("#filterContent").css("margin-top", "0px");
                        $('.kgrid-fix-header').attr('style', "top:0px;");
                        $(".table-crown-center").attr('style', "top:0px;height:50px;");
                        $("#topSpace").css("height", "210px");
                    }

                }
            },


            confirmCancel: function (id) {
                $("#ddlSeverity").selectpicker('refresh');
                $("#ddlEditSeverity").selectpicker('refresh');
                if (athoc.iws.AudioFileManager.editModel.isChanged()) {
                    if (confirm(athoc.iws.AudioFileManager.resources.Unsaved_Data_Text)) {
                        athoc.iws.AudioFileManager.editModel.isChanged(false);
                        $(id).modal('hide');
                    }
                }
                else
                    $(id).modal('hide');



            },


            CheckDefaultSeverityforTemplate: function (flag) {
                if (!flag)
                    return true;
                var showPopup = false;
                if (athoc.iws.AudioFileManager.editModel.audioModel.Locale() == "Any" && athoc.iws.AudioFileManager.editModel.defaultSeverties().length > 0
                    && athoc.iws.AudioFileManager.CheckAnySeverityExists(athoc.iws.AudioFileManager.editModel) > 0)
                    showPopup = true;
                var severityAudioId = athoc.iws.AudioFileManager.CheckSeverityExists(athoc.iws.AudioFileManager.editModel);
                if ((severityAudioId > 0) && (severityAudioId != athoc.iws.AudioFileManager.editModel.audioModel.AudioId()) && (!showPopup))
                    showPopup = true;
                if (showPopup) {
                    $("#dialogDefaultSeverityConfirm").modal('show');
                    $('#dialogDefaultSeverityConfirm .blockUI').remove();
                    $('#editAudiofileManager').append('<div id="displayShadowOrgView" class="modal-backdrop fade in"></div>');
                    $("#DefSeverityText").text(athoc.iws.AudioFileManager.resources.Settings_AudioFile_Severity_Confirmation_Message);
                    $('#dialogDefaultSeverityConfirm').modal({
                        keyboard: true
                    }).promise().done(function () {
                        setTimeout(function () {
                            $("#btnSeverityCancel").attr("tabindex", 15).focus();
                        }, 1000);
                    });
                }
            },


            //To give confirmation if already default severity exits for that desktop group

            //To check whether default severity exists
            CheckSeverityExists: function (obj) {

                var severityAudioId = _.find(obj.defaultSeverties(), function (item) {
                    if ($.trim(obj.audioModel.Severity()).toUpperCase() == item.Severity.toUpperCase() && (item.LocaleCode == "Any" || obj.audioModel.Locale() == item.LocaleCode) && item.AudioId != obj.audioModel.AudioId())
                        return item;
                }
                );
                return (severityAudioId != undefined && severityAudioId.AudioId != undefined) ? severityAudioId.AudioId : 0;

            },
            CheckAnySeverityExists: function (obj) {

                var severityAudioId = _.find(obj.defaultSeverties(), function (item) {
                    if ($.trim(obj.audioModel.Severity()).toUpperCase() == item.Severity.toUpperCase() && item.AudioId != obj.audioModel.AudioId())
                        return item;
                }
                );
                return (severityAudioId != undefined && severityAudioId.AudioId != undefined) ? severityAudioId.AudioId : 0;

            },

            getAudioName: function (audioName, defaultSeverity) {
                return (defaultSeverity == 'Y') ? audioName + ' ' + athoc.iws.AudioFileManager.resources.Settings_AudioFile_Name_Default : audioName;
            },

            getDefaultAudioName: function (AudioName, Default) {
                return Default == "Y" ? AudioName + " (Default)" : AudioName;
            },

            getSeverityName: function (severity) {
                var data = athoc.iws.AudioFileManager.editModel.SevArray();
                var serverity = _.find(data, function (item) {
                    if (item.SeverityId.toUpperCase() == severity.toUpperCase())
                        return item;
                });
                return (serverity != undefined ? serverity.SeverityName : '');
            },
            getLanguageName: function (defaultLocale) {
                defaultLocale = (defaultLocale == null) ? athoc.iws.AudioFileManager.resources.Settings_Default_Locale : defaultLocale;
                var languageSettings = _.find(athoc.iws.AudioFileManager.Languages, function (item) {
                    if (item.LocalCode != undefined && item.LocalCode.toUpperCase() == defaultLocale.toUpperCase())
                        return item;
                });
                return (languageSettings != undefined ? languageSettings.LanguageName : '');
            },
            getDropdownvalue: function (objArray, val) {


                var obj = _.find(objArray, function (item) {
                    return (item.SeverityId.toLowerCase() == val.toLowerCase());
                });
                if (obj != null)
                    return obj.SeverityName;
                else
                    return val;
            },
        };

    }();
}