﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.placeholder = athoc.iws.placeholder || {};

if (athoc.iws.placeholder) {
    athoc.iws.placeholder.list = function () {
        var datasource = null;
        var sortState = null;
        var isRepeated = false;
        var isSearched = false;

        return {
            viewModel: {
            },
            searchString: [],
            loadViewModel: function () {

                //Need this because with kendo textbox binding, IE9 is not showing the placeholder - this is work around
                /* $("#txtSearch").focus();
                $("#txtSearch").blur();*/


                this.viewModel =
                {
                    SearchText: ko.observableArray(),
                    AttributeTypes: ko.observable([]),
                    SelectedAttributeTypes: ko.observable([]),
                    CurrentOrganizationAttributesOnly: ko.observable(false),
                    OtherOrganizationAttributesOnly: ko.observable(false),
                    OrgaType: ko.observable(),

                    // Enable or disable search button
                    ShouldEnableSearch: function (e) {
                        if ($.trim($('#txtSearch').val()).length > 0)
                            return true;
                        else
                            return false;
                    },

                    // Show pills while searching
                    FilterPlaceholdersList: function (e) {
                        athoc.iws.placeholder.list.createPills($.trim($('#txtSearch').val()));
                        $('#txtSearch').val('');
                        $('#pillContainer').show();
                    },

                    ClearAll: function (e) {
                        athoc.iws.placeholder.list.searchString.length = 0;
                        athoc.iws.placeholder.list.viewModel.SearchText([]);
                        $("#koBoundElement .pill-container").html('');
                        $("#koBoundElement #pillContainer").hide();
                        athoc.iws.placeholder.list.refreshGrid(); 
                        athoc.iws.placeholder.list.setGridHeight();
                    },
                };
            },

            load: function () {

                this.loadViewModel();
                athoc.iws.placeholder.list.viewModel.OrgaType(athoc.iws.placeholder.resources.UserAttributeManager_SimpleSearch_Type_AllAttributes);
                ko.applyBindings(this.viewModel, document.getElementById("koBoundElement"));
                this.createAttributeListGrid();
                $("#caret").removeClass("hide");

                // On seleting the menu item corresponding attributes are loading in grid.
                $("#contextDropdown .text-select").click(function () {
                    athoc.iws.placeholder.list.viewModel.OrgaType(this.innerHTML);
                    var type = this.getAttribute("value");
                    athoc.iws.placeholder.list.viewModel.CurrentOrganizationAttributesOnly(false);
                    athoc.iws.placeholder.list.viewModel.OtherOrganizationAttributesOnly(false);

                    if (type == 1) {
                        athoc.iws.placeholder.list.viewModel.CurrentOrganizationAttributesOnly(false);
                        athoc.iws.placeholder.list.viewModel.OtherOrganizationAttributesOnly(false);
                    }
                    else if (type == 2)
                        athoc.iws.placeholder.list.viewModel.CurrentOrganizationAttributesOnly(true);
                    else if (type == 3)
                        athoc.iws.placeholder.list.viewModel.OtherOrganizationAttributesOnly(true);

                    athoc.iws.placeholder.list.refreshGrid();
                    $("#contextDropdown").hide();
                });

                // To hide the context dorpdown
                $("body").click(function () {
                    $("#contextDropdown").hide();
                });

                // Execute search options when press enter key in search textbox
                $("#txtSearch").keyup(function (e) {
                    // $("#searchBtn").removeAttr('disabled');
                    var seaString = $.trim($('#txtSearch').val());
                    if ($.hotkeys.enter(e) && seaString != "") {
                        $('#pillContainer').show();
                        athoc.iws.placeholder.list.createPills(seaString);
                        $("#txtSearch").val("");
                    }
                });
                $("#ulNavLinks li a").keyup(function (e) {
                    if ($.hotkeys.enter(e))
                        window.location.href = this.href;
                });

                $("#orgTypes").keyup(function (e) {
                    if ($.hotkeys.enter(e))
                        athoc.iws.placeholder.list.showOrgnizationTypes(event);
                });

               // $("#txtSearch").focus();
                $("#btnNewUserAttribute").focus();
            },

            // Diplaying the organization types
            showOrgnizationTypes: function (event) {
                $("#contextDropdown").show();
                event.cancelBubble = true;
            },

            // Fill attribute list in grid
            createAttributeListGrid: function () {
                var self = this;
                var url = athoc.iws.placeholder.urls.GetPlaceholderListUrl;

                // Prepare datasource for grid
                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.placeholder.list.viewModel);

                            var newState = JSON.stringify(options.sort);
                            if ((sortState) && newState != sortState) {
                                sortState = newState;
                                isRepeated = true;
                                options.page = 1;
                                options.skip = 0;
                                datasource.page(1);
                            }
                            return ko.toJSON(options);
                        },
                    },
                    requestStart: function (e) {
                        //isRepeated flag is to save duplicate calls to 
                        //server during sorting
                        if (isRepeated) {
                            e.preventDefault();
                            isRepeated = false;
                        }
                    },
                    requestEnd: function (e) {
                        sortState = JSON.stringify(e.sender._sort);
                        athoc.iws.placeholder.list.setGridHeight();
                        athoc.iws.placeholder.list.fitHeight();
                        //if ($('#placeholderListActionButtons ul li').length == 0 Commented as per the Dan Review
                        //    athoc.iws.placeholder.list.fillAtributeDropdown(e.response.Attributes)
                        $.AjaxLoader.hideLoader();
                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount"
                    },
                    serverPaging: true,
                    serverSorting: true,
                    serverFiltering: true,
                    sort: { field: "AttributeName", dir: "asc" },
                    pageSize: 50,
                    error: function (e) {
                        athoc.iws.placeholder.list.handleError(e);
                    },
                });

                // Bind datasource to the grid
                var grid = $("#attributeList").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: athoc.iws.placeholder.resources.UserAttributeManager_PlaceHolder_List_PageInfo,
                            empty: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Empty,
                            //page: athoc.iws.placeholder.resources.UserAttributeManager_Pageable_page,
                            //of: athoc.iws.placeholder.resources.UserAttributeManager_Pageable_of,
                            itemsPerPage: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Items_Per_Page,
                            first: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_First_Page,
                            previous: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page,
                            next: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Next_Page,
                            last: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Last_Page
                            //refresh: athoc.iws.placeholder.resources.UserAttributeManager_Pageable_refresh
                        }
                    },
                    columns:
                    [
                        {
                            field: "Id",
                            hidden: true
                        },
                        {
                            width: "200px",
                            field: "AttributeName",
                            title: athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Name,
                            headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Name + '">' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Name + '</span>',
                            template: '<span class="cellTooltip" title="#=$.htmlEncode(AttributeName)#">#=$.htmlEncode(AttributeName)#</span>',

                        },
                        {
                            width: "130px",
                            field: "AttributeType",
                            title: athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_AttributeType,
                            headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_AttributeType + '" >' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_AttributeType + '</span>',                            
                            template: '<span class="cellTooltip" title="#=athoc.iws.placeholder.list.replaceType(AttributeTypeId)#">#=athoc.iws.placeholder.list.replaceType(AttributeTypeId)#</span>',
                            
                        },
                        
                        {
                            width: "149px",
                            field: "AttributeOrigin",
                            title: athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Origin,
                            headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Origin + '">' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Origin + '</span>',
                            template: '<span class="cellTooltip" title="#=$.htmlEncode(AttributeOrigin)#">#=$.htmlEncode(AttributeOrigin)#</span>',

                        },
                        {
                            width: "120px",
                            field: "UpdatedOn",
                            title: athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_UpdatedOn,
                            headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_UpdatedOn + '">' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_UpdatedOn + '</span>',
                            template: '<span class="cellTooltip" title="#=UpdatedOn#">#=athoc.iws.placeholder.list.replaceString(UpdatedOn)#</span>'
                        }
                    ],
                    dataBound: athoc.iws.placeholder.list.OnDataBound
                }).data().kendoGrid;

                this.refreshGrid();
                $(".k-grid-header").css("top", "1px");
            },

            // Reload the grid
            refreshGrid: function () {
                //show the loader when we make a request to the server...
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.placeholder.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();
                datasource.page(1);
            },

            replaceString: function (value) {
                var d = new Date("1/1/2000");
                var vD = new Date(value);
                if (d.getTime() == vD.getTime())
                    return " ";
                else
                    return value;
            },

            replaceType: function (val) {
                switch (val) {
                    case 1:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Number;
                        break;
                    case 2:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Text;
                        break;
                    case 3:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Memo;
                        break;
                    case 4:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Date;
                        break;
                    case 5:
                        return athoc.iws.placeholder.resources.UserAttributeManager_DateTime;
                        break;
                    case 6:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Single_select_Picklist;
                        break;
                    case 7:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Multi_select_Picklist;
                        break;
                    case 8:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Checkbox;
                        break;
                    case 9:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Path;
                        break;
                    case 10:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Geolocation;
                        break;
                    case 11:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Time;
                        break;
                }
            },

            // Adjust height of grid
            fitHeight: function () {
                var gridTop = $('.header-bar-wrap').outerHeight() + $('.title-bar-wrap').outerHeight() + $('.table-crown-wrap').outerHeight(); //+10 is for space between crown and top of the grid
                $(".whiteout").css("height", gridTop);
                $("#attributeList").css("top", gridTop);
                  var extraSpace = $('.footer-wrap').outerHeight() + 10;
                 var headerHeight = $('.k-grid-header').outerHeight();
                 var pagerHeight = $('.k-pager-wrap').outerHeight();
                $("#attributeList").css("height", $(window).height() - gridTop - extraSpace);
                $(".k-grid-content").css("height", $(window).height() - (gridTop + headerHeight + pagerHeight) - extraSpace);

            },

            // Adjust height of grid after message panel is closed.
            fitHeightAfterMessagePanelClosed: function () {
                $(".table-crown-wrap").css("top", "");
                athoc.iws.placeholder.list.fitHeight();
            },

            // Adjust height of grid when messaage pannel is appear
            fitHeightWithMessagePanel: function () {

                var messagePanelTop = $('.header-bar-wrap').outerHeight() + $('.title-bar-wrap').outerHeight();
                var tableCrownTop = $('.header-bar-wrap').outerHeight() + $('.title-bar-wrap').outerHeight() + $('#listMessagePanel').outerHeight();
                var gridTop = tableCrownTop + $('.table-crown-wrap').outerHeight() + 10; //+10 is for space between crown and top of the grid
                var extraSpace = $('.footer-wrap').outerHeight() + 10;
                var headerHeight = $('.k-grid-header').outerHeight();
                var pagerHeight = $('.k-pager-wrap').outerHeight();

                $("#listMessagePanel").css("top", messagePanelTop);
                $(".table-crown-wrap").css("top", tableCrownTop - 20); //this should add because of messagepanel bottom margin - checked with jeff
                $(".whiteout").css("height", messagePanelTop);
                $("#attributeList").css("top", gridTop - 20);
                $("#attributeList").css("height", $(window).height() - gridTop - extraSpace + 22);
                $(".k-grid-content").css("height", $(window).height() - (gridTop + headerHeight + pagerHeight) - extraSpace + 20);
            },

            // Databound event of grid
            OnDataBound: function (e) {

                $("#attributeList tbody").find("tr").attr("tabindex", "0");
                // this.pager.element.hide();
                $("#attributeList .k-auto-scrollable").scrollTop(0);
                var grid = $("#attributeList").data("kendoGrid");
                var data = grid.dataSource.data();

                $(grid.tbody).unbind("click");

                $(grid.tbody).on("click", "td", function (e) {

                    var row = $(this).closest("tr");
                    var rowIdx = $("tr", grid.tbody).index(row);
                    var view = grid.dataSource.view();
                    var model = view[rowIdx];
                    window.location.href = window.location.href.replace(/\/*$/, "") + "/Edit/" + model.Id;
                    e.stopPropagation();

                });

                $(grid.tbody).on("keypress", "tr", function (e) {

                    var code = e.keyCode || e.which;

                    if (code == 13) {
                        var row = $(this);
                        var rowIdx = $("tr", grid.tbody).index(row);
                        var model = data[rowIdx];
                        window.location.href = window.location.href.replace(/\/*$/, "") + "/Edit/" + model.Id;
                    }
                });

                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    if (isSearched) {
                        $(e.sender.wrapper)
                            .find('tbody')
                            .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.placeholder.resources.AtHoc_Grid_NoRecords + '</td></tr>');
                    } else {
                        $(e.sender.wrapper)
                            .find('tbody')
                            .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.placeholder.resources.UserAttributeManager_No_Records_Found + '</td></tr>');
                    }
                }
            },


            // Error handler
            handleError: function (e) {
                var errorCallBack = function (returnedErrorObject) {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, null, athoc.iws.placeholder.list.fitHeightWithMessagePanel, athoc.iws.placeholder.list.fitHeightAfterMessagePanelClosed);
                };
                window.AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);
            },

            //to fill attributes dropdown with model data
            fillAtributeDropdown: function (data) {
                _.each(data, function (item) {
                    var value = item.Value;
                    if (item.Value == 'GeoLocation')
                        value = 'Geography'
                    else if (item.Value == 'MultiPicklist')
                        value = 'Multi-Picklist'
                    $('#placeholderListActionButtons ul').append('<li><a href=/athoc.iws.placeholder.lists/New/' + value + ' >' + item.Text + '</a></li>');
                });
            },

            // This is not using as attributes dropdown is removed.
            getAttributeTypes: function () {
                var myAjaxOptions = {
                    url: athoc.iws.placeholder.urls.GetPlaceholderTypesUrl,
                    type: "GET",
                    contentType: 'application/json',
                    dataType: 'json',


                };

                var onError = function (errorResult) {

                };

                var onSuccess = function (data) {

                    if (data && data.Success && data.Success === true) {
                        if (data.Data && data.Data.length > 0) {
                            var items = [];
                            for (var i = 0; i < data.Data.length; ++i) {
                                var item = { "optionText": data.Data[i].AttributeType, "optionValue": data.Data[i].AttributeTypeId };
                                items.push(item); //athoc.iws.placeholder.list.viewModel.AttributeTypes().push(item);

                            }
                            athoc.iws.placeholder.list.viewModel.AttributeTypes(items);
                            $("#attributeTypes").selectpicker('refresh');
                            $("#attributeTypes").selectpicker('selectAll');

                        }
                    }
                };
                var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

            },

            // Createing pills when search is done
            createPills: function (value) {
                $("#btnClearAll").removeClass("hide");
                if (value == "")
                    return;
                var found = _.find(athoc.iws.placeholder.list.searchString, function (item) {
                    return (item == value);
                });
                if (!found) {
                    isSearched = true;
                    athoc.iws.placeholder.list.searchString.push(value);
                    athoc.iws.placeholder.list.renderPills();
                    athoc.iws.placeholder.list.viewModel.SearchText(athoc.iws.placeholder.list.searchString);
                    athoc.iws.placeholder.list.refreshGrid();

                }
            },

            // Rendering the pills when search is done
            renderPills: function (css) {
                var self = this;
                var html = "";
                $("#koBoundElement .pill-container").html('');
                if (athoc.iws.placeholder.list.searchString && athoc.iws.placeholder.list.searchString.length > 0) {
                    _.each(athoc.iws.placeholder.list.searchString, function (item, index) {
                        var iconCss = "";
                        var prefix = "";
                        var pillLabel = prefix + $.htmlEncode(item);
                        var pillTooltip = prefix + $.htmlEncode(item);
                        var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" style="cursor:pointer" ></a>' : '');
                        html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                    });

                    var pillsElm = $("#koBoundElement .pill-container");
                    pillsElm.html(html);
                    //wire up events
                    $("#koBoundElement .pill-close").click(function (event) {
                        var parentElm = $(this).parent(".pill");
                        athoc.iws.placeholder.list.deSelect(parentElm.data("index"));
                        event.stopPropagation();
                    });
                    athoc.iws.placeholder.list.setGridHeight();
                }
            },

            // Deleteing the pills
            deSelect: function (index, onSuccess) {
                if (athoc.iws.placeholder.list.searchString && athoc.iws.placeholder.list.searchString.length > index) {
                    athoc.iws.placeholder.list.searchString.splice(index, 1);
                    if (athoc.iws.placeholder.list.searchString.length == 0)
                        athoc.iws.placeholder.list.viewModel.SearchText([]);
                    athoc.iws.placeholder.list.renderPills();
                    athoc.iws.placeholder.list.refreshGrid();
                    athoc.iws.placeholder.list.setGridHeight();
                }
            },

            // Adjust grid and search panel height according to the pills.
            setGridHeight: function () {
                if (athoc.iws.placeholder.list.searchString.length > 0) {
                    $(".table-crown-center").css("height", "auto");
                    $(".k-grid-header").css("top", "40px");
                    $(".k-grid-content").css("top", "39px");
                    $("#topSpace").css("height", "257px");
                } else {
                    $("#koBoundElement .pill-container").html('');
                    $("#koBoundElement #pillContainer").hide();                   
                    $(".k-grid-header").css("top", "1px");
                    $(".k-grid-content").css("top", "0px");
                    $("#koBoundElement").css("margin-top", "0px");
                    $(".table-crown-center").css("height", "27px");
                    $("#topSpace").css("height", "210px");

                }
            },
        };
    }();
}