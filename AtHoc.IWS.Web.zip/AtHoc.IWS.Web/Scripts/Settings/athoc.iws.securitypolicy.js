﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
if (athoc.iws) {
   

    /*trimmed value binder for knockout*/
ko.bindingHandlers.trimedValue = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $(element).on("change", function () {
            var observable = valueAccessor();
            var trimedValue = $.trim($(this).val());
            observable($(this).val());
            observable(trimedValue);
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor());
        var trimedValue = $.trim(value);
        $(element).val(trimedValue);
    }
};
    athoc.iws.securitypolicy = function () {

        return {
            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},
            SystemVPS: 3,
            defaultPopupTimeOutInterval: 2,
            IsChanged: false,
            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},
            //viewmodel to hold individual System settings record
            viewModel: {
                SecurityPolicySettings: ko.observable(),
                mode: ko.observable(true),
                globaledit: ko.observable(true),
                MinmumLengthArray: ko.observableArray([{ value: "7", text: "7" }, { value: "8", text: "8" }, { value: "9", text: "9" }, { value: "10", text: "10" }, { value: "11", text: "11" }, { value: "12", text: "12" }, { value: "13", text: "13" }, { value: "14", text: "14" }, { value: "15", text: "15" }, { value: "16", text: "16" }, { value: "17", text: "17" }, { value: "18", text: "18" }, { value: "19", text: "19" }, { value: "20", text: "20" }]),
                MinArray: ko.observableArray([{ value: "0", text: "0" }, { value: "1", text: "1" }, { value: "2", text: "2" }, { value: "3", text: "3" }, { value: "4", text: "4" }, { value: "5", text: "5" }, { value: "6", text: "6" }]),
            },
            //editmodel to hold individual System settings record
            editModel: {
                SecurityPolicySettings: ko.observable()
            },
            //init method for distribution list, will be triggered before document load
            init: function () {
                athoc.iws.securitypolicy.initBreadcrumb();
            },

            //load method, will be triggered on document load
            load: function () {
                athoc.iws.securitypolicy.bindBreadcrumb();


                //button events!
                athoc.iws.securitypolicy.getsecuritypolicy();

                $("#btn_edit").click(function () {
                    athoc.iws.securitypolicy.editSecurityPolicy();
                });


                $("#btn_cancel").click(function () {

                    var isModified = athoc.iws.securitypolicy.isChanged;
                    if (isModified == true) {
                        var confirmLeave = confirm(athoc.iws.securitypolicy.resources.Unsaved_Data_Text);
                        if (confirmLeave == true) {
                            athoc.iws.securitypolicy.isChanged = false;
                            window.location.href = "/client/setup/settings";
                        }
                    }
                    else {
                        window.location.href = "/client/setup/settings";
                    }
                });

                $("#btn_save").click(function () {
                    athoc.iws.securitypolicy.savesecuritypolicy();
                });

                $("#btn_defaultsettings").click(function () {
                    athoc.iws.securitypolicy.deletesecuritypolicy();
                });

                $("#btnDeleteCancel").click(function () { $("#dialogSecurity").modal('hide'); });
                $("#okButton").click(function () {
                    athoc.iws.securitypolicy.updatesecuritypolicyEnforcePassword();
                });

                window.onbeforeunload = function (event) {
                    var isModified = athoc.iws.securitypolicy.isChanged;
                    if (isModified) {
                        return athoc.iws.securitypolicy.resources.Unsaved_Data_Text;
                    } else {
                        $(window).scrollTop(0);
                    }
                };
            },

            //
            collapsePanel: function () {
                $(this).parent().find('.expand-arrow-open').toggle();
                $('.bucket-toggle h2').click(function () {
                    $(this).parent().find('.row').slideToggle(500);
                    $(this).parent().find('.expand-arrow-open').toggle();
                    $(this).parent().find('.expand-arrow-closed').toggle();
                });
            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            //
            initBreadcrumb: function () {
                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.securitypolicy.breadcrumbModel;
                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.securitypolicy.resources.Action_Button_Settings, '', function () {
                    var isModified = athoc.iws.securitypolicy.IsChanged;
                    if (isModified) {
                        var confirmLeave = confirm(athoc.iws.securitypolicy.resources.Unsaved_Data_Text);
                        if (confirmLeave == true) {
                            athoc.iws.securitypolicy.IsChanged = false;
                            window.location.href = "/client/setup/settings";
                        }
                    }
                    else { window.location.href = "/client/setup/settings"; }


                });

                var securitypolicyLink = new Breadcrumb('securitypolicyLink', athoc.iws.securitypolicy.resources.SecurityPolicy_TitleLink, '', function () {

                    navigateToPage('viewSecurityPolicy', function () { });
                    athoc.iws.securitypolicy.breadcrumbModel.SelectedPage('viewSecurityPolicy');
                    $.titleCrumb("pageBreadcrumbs");
                    athoc.iws.securitypolicy.getsecuritypolicy();
                });

                var viewPageBreadcrumb = new PageBreadcrumb('viewSecurityPolicy', athoc.iws.securitypolicy.resources.SecurityPolicy_TitleLink, [settingLink], '');
                //To Edit Security Policy data
                var editPageBreadcrumb = new PageBreadcrumb('editSecurityPolicy', 'Edit', [settingLink, securitypolicyLink], '');

                breadcrumbsModel.addPage(viewPageBreadcrumb);
                breadcrumbsModel.addPage(editPageBreadcrumb);
            },

            //
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.securitypolicy.breadcrumbModel;
                breadcrumbsModel.SelectedPage('viewSecurityPolicy');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            //
            editSubscribe: function () {


                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeDays.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.securitypolicy.isChanged = true;
                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeDays($.trim(newValue));
                });

                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.RememberPreviousPassword.subscribe(function (newValue) {

                    if ($.trim(newValue) != "")
                        athoc.iws.securitypolicy.isChanged = true;
                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.RememberPreviousPassword($.trim(newValue));
                });


                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinLength.subscribe(function (newValue) {

                    athoc.iws.securitypolicy.isChanged = true;
                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinLength($.trim(newValue));
                });



                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinLCaseChars.subscribe(function (newValue) {
                    athoc.iws.securitypolicy.isChanged = true;
                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinLCaseChars($.trim(newValue));
                });


                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinUCaseChars.subscribe(function (newValue) {
                    athoc.iws.securitypolicy.isChanged = true;
                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinUCaseChars($.trim(newValue));
                });


                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinNumericChars.subscribe(function (newValue) {
                    athoc.iws.securitypolicy.isChanged = true;
                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinNumericChars($.trim(newValue));
                });

                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinSpecialChars.subscribe(function (newValue) {
                    athoc.iws.securitypolicy.isChanged = true;
                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinSpecialChars($.trim(newValue));
                });



                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinDays.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.securitypolicy.isChanged = true;
                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinDays($.trim(newValue));
                });

                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockoutTimeout.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.securitypolicy.isChanged = true;
                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockoutTimeout($.trim(newValue));
                });

                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockAttempts.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.securitypolicy.isChanged = true;

                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockAttempts($.trim(newValue));
                })

                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinChars.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.securitypolicy.isChanged = true;
                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinChars($.trim(newValue));
                });


                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.AllowMutipleSessions.subscribe(function (newValue) {

                    athoc.iws.securitypolicy.isChanged = true;
                });


                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.SessionTimeoutInterval.subscribe(function (newValue) {
                    athoc.iws.securitypolicy.isChanged = true;
                    athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.SessionTimeoutInterval($.trim(newValue));
                });

                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PopupTimeoutInterval.subscribe(function (newValue) {
                    athoc.iws.securitypolicy.isChanged = true;
                    if ($.trim(newValue) != "")
                        athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PopupTimeoutInterval($.trim(newValue));
                    else

                        athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PopupTimeoutInterval(athoc.iws.securitypolicy.defaultPopupTimeOutInterval);
                });

                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.EnableAutoLogin.subscribe(function (newValue) {
                    //if(newValue === false)
                    //	athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.SmartCardEnforced(false);
                    athoc.iws.securitypolicy.isChanged = true;
                });

                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.SmartCardEnforced.subscribe(function (newValue) {
                    athoc.iws.securitypolicy.isChanged = true;
                });

                athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.RequireCaptcha.subscribe(function (newValue) {
                    athoc.iws.securitypolicy.isChanged = true;
                });


            },

            //
            initiateSelectPicker: function () {

                $("#ddlminLength").selectpicker();
                $("#ddlminLCase").selectpicker();
                $("#ddlminUCase").selectpicker();
                $("#ddlminNumeric").selectpicker();
                $("#ddlminSpecial").selectpicker();
            },

            //get or load security policy detail record from json request
            getsecuritypolicy: function () {
                $('#saveMessagePanel').messagesPanel('reset');

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.securitypolicy.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                var dlAjaxOption =
                    {
                        type: "POST",
                        url: athoc.iws.securitypolicy.urls.GetsecuritypolicyUrl,
                        success: function (data) {
                            $(document).scrollTop(0);

                            athoc.iws.securitypolicy.viewModel.SecurityPolicySettings = ko.mapping.fromJS(data.Data);
                            $("#viewSecurityPolicy").find(".bootstrap-select").remove();
                            //Binding
                            ko.cleanNode($("#viewSecurityPolicy").get(0));
                            ko.applyBindings(athoc.iws.securitypolicy.viewModel, $("#viewSecurityPolicy").get(0));
                            athoc.iws.securitypolicy.editSubscribe();
                            athoc.iws.securitypolicy.collapsePanel();
                            athoc.iws.securitypolicy.initiateSelectPicker();

                            //hide all buttons
                            $('#btn_Enforce').hide();
                            $('#btn_defaultsettings').hide();

                            // enable enforce button for Enterprise admin and System admin
                            //if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.IsEnterpriseAdmin() || athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.IsSystemAdmin())
                            if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.IsModifySecurityPolicyAllowed())
                                $('#btn_Enforce').show();

                            //Show default settings for other providers if they have own copy of security policy settings
                            if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.IsSelf())
                                if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.ProviderId() != athoc.iws.securitypolicy.SystemVPS)
                                    $('#btn_defaultsettings').show();

                            if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.IsEnterpriseAdmin() || athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.IsSystemAdmin())
                                athoc.iws.securitypolicy.viewModel.globaledit(true);
                            else
                                athoc.iws.securitypolicy.viewModel.globaledit(false);


                            if (data.HasErrors) {
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }
                            $.AjaxLoader.hideLoader();
                            $("#showLoading").show();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.securitypolicy.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },

            // to save security policy in the database
            savesecuritypolicy: function () {
                $('#saveMessagePanel').html('');

                // Validate Securitypolicy data
                if (!athoc.iws.securitypolicy.performSecuritypolicyValidation())
                    return false;
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.securitypolicy.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();

                var jsonData = ko.toJSON(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings);
                var token =encodeURIComponent($("input[name='__RequestVerificationToken']").val());
                var dlAjaxOption =
                    {
                        url: athoc.iws.securitypolicy.urls.SavesecuritypolicyUrl,
                        type: 'POST',
                        data: jsonData,
                        headers: { '__RequestVerificationToken': token },
                        dataType: "JSON",
                        contentType: "application/json; charset=utf-8",
                        processData : false,

                        success: function (data) {
                            if (data.Success) {
                                athoc.iws.securitypolicy.isChanged = false;
                                navigateToPage('viewSecurityPolicy', function () { });
                                athoc.iws.securitypolicy.breadcrumbModel.SelectedPage('viewSecurityPolicy');
                                $.titleCrumb("pageBreadcrumbs");
                                $('#saveMessagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_SaveSuccess }] });
                                // athoc.iws.securitypolicy.getsecuritypolicy();
                                athoc.iws.securitypolicy.showMessagePanel();
                                if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.ProviderId() != athoc.iws.securitypolicy.SystemVPS)
                                    $('#btn_defaultsettings').show();
                            }
                            else {
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }
                            $.AjaxLoader.hideLoader();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.securitypolicy.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;
            },

            //
            insertsecuritypolicy: function () {
                $('#saveMessagePanel').html('');
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.securitypolicy.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                var jsonData = ko.toJSON(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings);
                var token = encodeURIComponent($("input[name='__RequestVerificationToken']").val());
                var dlAjaxOption =
                    {
                        url: athoc.iws.securitypolicy.urls.InsertsecuritypolicyUrl,
                        type: 'POST',
                        data: jsonData,
                        headers: { '__RequestVerificationToken': token },
                        dataType: "JSON",
                        contentType: false,
                        processData: false,
                        success: function (data) {
                            if (data.Success) {
                                navigateToPage('viewSecurityPolicy', function () { });
                                athoc.iws.securitypolicy.breadcrumbModel.SelectedPage('viewSecurityPolicy');
                                $.titleCrumb("pageBreadcrumbs");
                                athoc.iws.securitypolicy.getsecuritypolicy();
                            }
                            else {
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }

                            $.AjaxLoader.hideLoader();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.securitypolicy.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;
            },

            // to update security policy Password Parameter  in the database
            updatesecuritypolicyEnforcePassword: function () {
                $('#saveMessagePanel').html('');

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.securitypolicy.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                var token = encodeURIComponent($("input[name='__RequestVerificationToken']").val());
                var dlAjaxOption =
                    {
                        url: athoc.iws.securitypolicy.urls.UpdatesecuritypolicyUrl,
                        type: 'POST',
                        headers: { '__RequestVerificationToken': token },
                        dataType: "JSON",
                        contentType: false,
                        processData: false,
                        success: function (data) {
                            if (data.Success) {

                                navigateToPage('viewSecurityPolicy', function () { });

                                athoc.iws.securitypolicy.breadcrumbModel.SelectedPage('viewSecurityPolicy');

                                $.titleCrumb("pageBreadcrumbs");
                                athoc.iws.securitypolicy.viewModel.mode(true);
                                athoc.iws.securitypolicy.viewModel.globaledit(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.IsSystemAdmin());
                                athoc.iws.securitypolicy.getsecuritypolicy();
                                $("#dialogSecurity").modal('hide');

                            } else {
                                $("#dialogSecurity").modal('hide');
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }

                            $.AjaxLoader.hideLoader();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.securitypolicy.handleError(e);
                        }

                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;
            },

            //
            deletesecuritypolicy: function () {
                $('#saveMessagePanel').html('');
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.securitypolicy.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                var jsonData = ko.toJSON(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings);
                var token = encodeURIComponent($("input[name='__RequestVerificationToken']").val());
                var dlAjaxOption =
                    {
                        url: athoc.iws.securitypolicy.urls.DeletesecuritypolicyUrl,
                        type: 'POST',
                        data: jsonData,
                        headers: { '__RequestVerificationToken': token },
                        dataType: "JSON",
                        contentType: false,
                        processData: false,
                        success: function (data) {
                            if (data.Success) {
                                athoc.iws.securitypolicy.isChanged = false;
                                navigateToPage('viewSecurityPolicy', function () { });
                                athoc.iws.securitypolicy.breadcrumbModel.SelectedPage('viewSecurityPolicy');
                                $.titleCrumb("pageBreadcrumbs");
                                athoc.iws.securitypolicy.getsecuritypolicy();

                            } else {
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }

                            $.AjaxLoader.hideLoader();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.securitypolicy.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;
            },
            //
            enforcePassword: function () {

                $('#dialogSecurity').modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        $("#btnDeleteCancel").attr("tabindex", 15).focus();
                    }, 1000);
                });

            },

            // to perform validation on securitypolicy data before save
            performSecuritypolicyValidation: function () {
                var reqError = new Array();

                var focusField = null;

                if (!athoc.iws.securitypolicy.isRequired(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeDays(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Days_Validation });
                    focusField = "#txtpasswordchangedays";
                }
                if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeDays() != "") {
                    if (!athoc.iws.securitypolicy.pattern(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeDays(), "^[0-9]+$", "3")) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Days_Range.format(0, 365) });
                        if (focusField == null)
                            focusField = "#txtpasswordchangedays";
                    }

                    if (athoc.iws.securitypolicy.PasswordChangeVal(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeDays(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Days_Range.format(0, 365) });
                        if (focusField == null)
                            focusField = "#txtpasswordchangedays";
                    }
                }

                if (!athoc.iws.securitypolicy.isRequired(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.RememberPreviousPassword(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Previous_Validation });
                    if (focusField == null)
                        focusField = "#txtPasswordReusePrevious";
                }

                if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.RememberPreviousPassword() != "") {
                    if (!athoc.iws.securitypolicy.pattern(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.RememberPreviousPassword(), "^[0-9]+$", "3")) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Previous_Range.format(0, 25) });
                        if (focusField == null)
                            focusField = "#txtPasswordReusePrevious";
                    }

                    if (athoc.iws.securitypolicy.PrevPasswordVal(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.RememberPreviousPassword(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Previous_Range.format(0, 25) });
                        if (focusField == null)
                            focusField = "#txtPasswordReusePrevious";
                    }
                }


                if (!athoc.iws.securitypolicy.isRequired(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinDays(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Update_Validation });
                    if (focusField == null)
                        focusField = "#txtPasswordUpdate";
                }
                if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinDays() != "") {
                    if (!athoc.iws.securitypolicy.pattern(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinDays(), "^[0-9]+$", "3")) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Update_Range.format(0, 30) });
                        if (focusField == null)
                            focusField = "#txtPasswordUpdate";
                    }

                    if (athoc.iws.securitypolicy.PasswordUpdateVal(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinDays(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Update_Range.format(0, 30) });
                        if (focusField == null)
                            focusField = "#txtPasswordUpdate";
                    }
                }

                if (!athoc.iws.securitypolicy.isRequired(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinChars(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Atleast_Validation });
                    if (focusField == null)
                        focusField = "#txtPasswordChangeAtleast";
                }
                if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinChars() != "") {
                    if (!athoc.iws.securitypolicy.pattern(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinChars(), "^[0-9]+$", "3")) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Atleast_Range.format(0, 7) });
                        if (focusField == null)
                            focusField = "#txtPasswordChangeAtleast";
                    }

                    if (athoc.iws.securitypolicy.PasswordChangeMinCharVal(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordChangeMinChars(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Atleast_Range.format(0, 7) });
                        if (focusField == null)
                            focusField = "#txtPasswordChangeAtleast";
                    }
                }

                if (!athoc.iws.securitypolicy.isRequired(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockAttempts(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Lockout_Validation });
                    if (focusField == null)
                        focusField = "#txtLockoutUser";
                }

                if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockAttempts() != "") {
                    if (!athoc.iws.securitypolicy.pattern(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockAttempts(), "^[0-9]+$", "3")) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Lockout_Range.format(0, 10) });
                        if (focusField == null)
                            focusField = "#txtLockoutUser";
                    }

                    if (athoc.iws.securitypolicy.PasswordChangeAtleastVal(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockAttempts(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Lockout_Range.format(0, 10) });
                        if (focusField == null)
                            focusField = "#txtLockoutUser";
                    }
                }

                if (!athoc.iws.securitypolicy.isRequired(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockoutTimeout(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Lockattempts_Validation });
                    if (focusField == null)
                        focusField = "#txtLockAfterMinutes";
                }

                if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockoutTimeout() != "") {
                    if (!athoc.iws.securitypolicy.pattern(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockoutTimeout(), "^[0-9]+$", "3")) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Lockattempts_Range.format(0, 9999999) });
                        if (focusField == null)
                            focusField = "#txtLockAfterMinutes";
                    }
                    if (athoc.iws.securitypolicy.PasswordLockoutTime(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.LoginLockoutTimeout(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Password_Lockattempts_Range.format(0, 9999999) });
                        if (focusField == null)
                            focusField = "#txtLockAfterMinutes";
                    }
                }
                if (!athoc.iws.securitypolicy.isRequired(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.SessionTimeoutInterval(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Session_Timeout_Validation });
                    if (focusField == null)
                        focusField = "#txtSessionTimeout";
                }
                if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.SessionTimeoutInterval() != "") {

                    if (!athoc.iws.securitypolicy.pattern(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.SessionTimeoutInterval(), "^[0-9]+$", "3")) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Session_Timeout_Range.format(1, 1440) });
                        if (focusField == null)
                            focusField = "#txtSessionTimeout";

                    }
                    else if (athoc.iws.securitypolicy.SessionTimeoutInterval(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.SessionTimeoutInterval(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Session_Timeout_Range.format(1, 1440) });
                        if (focusField == null)
                            focusField = "#txtSessionTimeout";
                    }

                }

                if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PopupTimeoutInterval() != "") {

                    if (!athoc.iws.securitypolicy.pattern(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PopupTimeoutInterval(), "^[0-9]+$", "3")) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Popup_Timeout_InvalidInput_Msg });
                        if (focusField == null)
                            focusField = "#txtPopupTimeout";

                    }
                    else if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.SessionTimeoutInterval() != "") {
                        var lessThanValue = Math.floor(parseFloat(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.SessionTimeoutInterval()) / 2);
                        if (parseFloat(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PopupTimeoutInterval()) >= lessThanValue ) {
                            reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_Popup_Timeout_Less_Than_Msg + " " + lessThanValue });
                            if (focusField == null)
                                focusField = "#txtPopupTimeout";
                        }
                    }

                }
                if (athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinLength() != "") {

                    if (parseInt(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinLength()) < (parseInt(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinLCaseChars()) + parseInt(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinUCaseChars()) + parseInt(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinNumericChars()) + parseInt(athoc.iws.securitypolicy.viewModel.SecurityPolicySettings.PasswordMinSpecialChars()))) {
                        reqError.push({ Type: '4', Value: athoc.iws.securitypolicy.resources.SecurityPolicy_MinimumPasswordLengthValidation });
                        if (focusField == null)
                            focusField = "";
                    }

                }
                //pop out the error message 
                if (reqError.length > 0) {

                    $('#saveMessagePanel').messagesPanel({ messages: reqError });
                    $(window).scrollTop(0);
                    // $(focusField).focus();
                    return false;
                }
                return true;
            },

            //
            isRequired: function (val, required) {


                var stringTrimRegEx = /^\s+|\s+$/g,
                    testVal;

                if ($.trim(val) === undefined || $.trim(val) === null) {
                    return !required;
                }

                testVal = $.trim(val);
                if (typeof ($.trim(val)) == "string") {
                    testVal = $.trim(val).replace(stringTrimRegEx, '');
                }

                return required && (testVal + '').length > 0;
            },

            //
            maxLength: function (val, maxLength) {
                return athoc.iws.securitypolicy.isEmptyVal(val) || $.trim(val).length <= maxLength;
            },

            //
            isEmptyVal: function (val) {
                if ($.trim(val) == undefined) {
                    return true;
                }
                if ($.trim(val) == null) {
                    return true;
                }
                if ($.trim(val) == "") {
                    return true;
                }
            },

            //
            pattern: function (val, regex, type) {
                var pattern = regex;
                var $opts = { "rule": "format", "format": { "pattern": regex } };

                if (typeof $opts.format.pattern === "string")
                    var pattern = (typeof $opts.format.pattern === "object") ? $opts.format.pattern : new RegExp($opts.format.pattern, "g");
                return pattern.test($.trim(val));

            },

            //
            PasswordChangeVal: function (val) {
                if (!athoc.iws.securitypolicy.isEmptyVal(val)) {
                    if (val > 365) {
                        return true;
                    }
                    else
                        return false;
                }
            },

            //
            PrevPasswordVal: function (val) {
                if (!athoc.iws.securitypolicy.isEmptyVal(val)) {
                    if (val > 25) {
                        return true;
                    }
                    else
                        return false;
                }

            },

            //
            PasswordUpdateVal: function (val) {
                if (!athoc.iws.securitypolicy.isEmptyVal(val)) {
                    if (val > 30) {
                        return true;
                    }
                    else
                        return false;
                }

            },

            //
            PasswordChangeMinCharVal: function (val) {
                if (!athoc.iws.securitypolicy.isEmptyVal(val)) {
                    if (val > 7) {
                        return true;
                    }
                    else
                        return false;
                }

            },

            //
            PasswordChangeAtleastVal: function (val) {
                if (!athoc.iws.securitypolicy.isEmptyVal(val)) {
                    if (val > 10) {
                        return true;
                    }
                    else
                        return false;
                }

            },

            //
            PasswordLockoutTime: function (val) {
                if (!athoc.iws.securitypolicy.isEmptyVal(val)) {
                    if (val > 9999999) {
                        return true;
                    }
                    else
                        return false;
                }

            },

            //
            SessionTimeoutInterval: function (val) {
                if (!athoc.iws.securitypolicy.isEmptyVal(val)) {
                    val = parseInt(val);
                    if (val >= 1 && val <= 1440)
                        return false;
                    else
                        return true;
                }

            },

            //
            errors: null,

            //
            showMessagePanel: function () {
                if ($('body').scrollTop() > 0) {     //Chrome,Safari
                    $('body').scrollTop(0);
                } else {
                    if ($('html').scrollTop() > 0) { //IE, FF
                        $('html').scrollTop(0);
                    }
                }
            },

            // To show erros and handle timeout error
            handleError: function (e) {
                athoc.iws.securitypolicy.errors = [];
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else if (e.errorThrown != "") {
                    if (athoc.iws.securitypolicy.errors === null) {
                        athoc.iws.securitypolicy.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.securitypolicy.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#saveMessagePanel').messagesPanel({ messages: this.errors });
                    athoc.iws.securitypolicy.showMessagePanel();
                }
            },

        };
    }();
}




