﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};



if (athoc.iws) {
    athoc.iws.rule = function () {
        var errorTitleStrings = new Array();
        return {
            urls: {},
            ruleById: [],
            scenarios: [],

            getRuleById: function (id) {
                return this.ruleById[id];
            },

            getScenarioById: function (id) {
                for (var i = 0; i < athoc.iws.rule.scenarios.length; i++) {
                    var scenario = athoc.iws.rule.scenarios[i];
                    if (scenario.Id == id) {
                        return scenario;
                    }
                }

                return null;
            },

            init: function () {
                athoc.iws.rule.initBreadcrumb();
            },

            ruleListButtonModel: {
                hasSelectedRules: ko.observable(false),
            },

            load: function () {
                require(["ssa/eventManagerUtil"], function (eventMgrUtil) {
                    athoc.iws.rule.eventUtil = eventMgrUtil;
                });

                //To fill the Message popup title strings from resource 
                errorTitleStrings.push(athoc.iws.rule.resources.AtHoc_CommonErrMsg_Title_Information);
                errorTitleStrings.push(athoc.iws.rule.resources.AtHoc_CommonErrMsg_Title_Warning);
                errorTitleStrings.push(athoc.iws.rule.resources.AtHoc_CommonErrMsg_Title_Error);
                errorTitleStrings.push(athoc.iws.rule.resources.AtHoc_CommonErrMsg_Title_Success);
                errorTitleStrings.push(athoc.iws.rule.resources.AtHoc_CommonErrMsg_Title_Completed);

                kendo.bind($(".kendoBoundRuleContext"), this.ViewModel);
                athoc.iws.rule.bindBreadcrumb();
                //ko.applyBindings(this.ruleListButtonModel, document.getElementById('ruleListActionButton'));
                navigateToPage('ruleList', function () { $("body,.title-bar-wrap").css("background-color", "#eeeeee"); });

                window.onbeforeunload = function (event) {

                    if (athoc.iws.rule.detailViewModel && athoc.iws.rule.detailViewModel.model
                                && athoc.iws.rule.detailViewModel.model.isChanged) {
                        return athoc.iws.rule.resources.Unsaved_Data_Text;
                    } else {
                        $(window).scrollTop(0);
                    }

                };

            },

            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {
                var rule = athoc.iws.rule;

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = rule.breadcrumbModel;

                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.rule.resources.EventRule_Manager_Settings_Title, '', function () {
                    window.location.href = "/client/setup/Settings";
                });

                var ruleBreadCrumb = new Breadcrumb('ruleList', athoc.iws.rule.resources.EventRule_Manager_Title, '', function () {
                    athoc.iws.rule.onRuleDetailNavigateAway();
                });

                //Page breadcrumb                
                var rulePageBreadCrumb = new PageBreadcrumb('ruleList', athoc.iws.rule.resources.EventRule_Manager_Title, [settingLink], '');
                var ruleDetailPageBreadCrumb = new PageBreadcrumb('ruleDetail', athoc.iws.rule.resources.EventRule_Manager_Rule_Title, [settingLink, ruleBreadCrumb], '');
                breadcrumbsModel.addPage(rulePageBreadCrumb);
                breadcrumbsModel.addPage(ruleDetailPageBreadCrumb);
            },

            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.rule.breadcrumbModel;
                breadcrumbsModel.SelectedPage('ruleList');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            getGridColumns: function () {
                var columns = new Array();
                columns.push({
                    field: "Id",
                    hidden: true,
                });

                columns.push({
                    field: "Order",
                    hidden: true,
                });

                columns.push({
                    field: "IsChecked",
                    //template: $("#rule-checkbox-template").html(),
                    width: 40,
                    headerTemplate: kendo.format('<div align="center"><input type="checkbox" class="senario-select mar-left6" id="rule-select-all" title="{0}" onclick="athoc.iws.rule.selectAll();"/></div>', athoc.iws.rule.resources.EventRule_Manager_SelectAll),
                    //sortable: false
                    headerAttributes: { "class": "no-pointer" }
                });

                columns.push({
                    width: 60,
                    headerTemplate: kendo.format('<div title="{0}" align="center">{1}</div>', athoc.iws.rule.resources.EventRule_Manager_Col_Order_tip, athoc.iws.rule.resources.EventRule_Manager_Col_Order),
                    headerAttributes: { "class": "no-pointer" }
                });

                columns.push({
                    width: 50,
                    headerTemplate: kendo.format('<div title="{0}" align="center">{1}</div>', athoc.iws.rule.resources.EventRule_Manager_Col_ReOrder_tip, "&nbsp;"),
                    headerAttributes: { "class": "no-pointer" }
                    //headerTemplate: kendo.format('<div align="center"><span class="icon-drag-row"></div>'),
                    //headerAttributes: { "class": "no-pointer", "title": athoc.iws.rule.resources.EventRule_Manager_Col_ReOrder_Tip }

                });

                columns.push({
                    field: "Name",
                    headerTemplate: kendo.format('<div>{0}</div>', athoc.iws.rule.resources.EventRule_Manager_Col_Name),
                    headerAttributes: { "class": "no-pointer", "title": athoc.iws.rule.resources.EventRule_Manager_Col_Name_Tip }
                });

                columns.push({
                    field: "RuleAction",
                    width: 300,
                    title: athoc.iws.rule.resources.EventRule_Manager_Col_Action,
                    headerAttributes: { "class": "no-pointer", "title": athoc.iws.rule.resources.EventRule_Manager_Col_Action_Tip }
                });

                columns.push({
                    //field: "Somewthing",
                    width: 120,
                    title: athoc.iws.rule.resources.EventRule_Manager_Col_Stop,
                    headerAttributes: { "class": "no-pointer", "title": athoc.iws.rule.resources.EventRule_Manager_Col_Stop_Tip }
                });
                return columns;
            },

            CreateGrid: function () {
                var url = athoc.iws.rule.urls.Get;

                var datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.rule.ViewModel);
                            return kendo.stringify(options);
                        },
                    },
                    schema: {
                        data: "Rules",
                        total: "GridTotalCount",
                        model: {
                            fields: {
                                Id: { type: "int" },
                                Name: { type: "string" },
                                Order: { type: "int" },
                            }
                        }
                    },
                    sort: {
                        field: "Order",
                        dir: "asc"
                    },
                    requestEnd: function (e) {
                        if (e.response && e.response.Rules) {
                            athoc.iws.rule.displayIndex = 0;
                            e.response.Rules.forEach(function (rule) {
                                athoc.iws.rule.ruleById[rule.Id] = rule;
                            });

                            e.response.AlertScenarios.forEach(function (scenario) {
                                if (!scenario.IsReady) {
                                    scenario.Name = athoc.iws.rule.resources.EventRule_Manager_Scenario_NotReady_Prefix + scenario.Name;
                                }

                            });

                            athoc.iws.rule.scenarios = e.response.AlertScenarios;

                            try {
                                $.AjaxLoader.hideLoader();
                            } catch (err) {

                            }
                        }
                    },
                    error: function (e) {
                        athoc.iws.rule.handleError(e);
                    },

                    pageSize: 150,
                    serverPaging: false,
                    serverSorting: false,
                }
                );

                var grid = $("#ruleList").kendoGrid({
                    dataSource: datasource,
                    sortable: false,
                    groupable: false,
                    columns: athoc.iws.rule.getGridColumns(),
                    change: function (e) {
                        var model = this.dataItem(this.select());
                        athoc.iws.rule.showRule(model.Id);
                    },

                    rowTemplate: kendo.template("<tr>" + $("#rowRuleTemplate").html() + "</tr>"),
                    altRowTemplate: kendo.template("<tr>" + $("#rowRuleTemplate").html() + "</tr>"),
                    dataBound: athoc.iws.rule.OnDataBound,
                }).data("kendoGrid");

                grid.table.kendoSortable({
                    filter: ">tbody >tr",
                    handler: ".icon-drag-row",
                    cursor: "move",
                    //hint: $.noop,
                    hint: function (element) {
                        var root = $('<div style="width:500px"></div>');
                        element.clone().addClass("hint").appendTo(root);
                        return root;
                    },
                    placeholder: function (element) {
                        return $('<tr><td colspan="6"><div style="width:500px">' + athoc.iws.rule.resources.EventRule_Manager_Drop_Here + '</div></td></tr>').addClass("placeholder");
                    },
                    cursorOffset: {
                        top: -10,
                        left: -230
                    },
                    container: "#ruleList tbody",
                    change: function (e) {
                        var skip = grid.dataSource.skip();
                        var oldIndex = e.oldIndex + skip;
                        var newIndex = e.newIndex + skip;

                        var orderedRules = []; //  start with the old order
                        for (var i = 0; i < grid.dataSource.view().length; i++) {
                            var rule = grid.dataSource.view()[i];
                            orderedRules.push({ RuleId: rule.Id, Name: rule.Name });
                        }

                        // reorder according to the new order
                        orderedRules.splice(/*to*/newIndex, 0, orderedRules.splice(/*from*/oldIndex, 1)[0]);
                        // now add the order attribute                       
                        for (var i = 0; i < orderedRules.length; i++) {
                            orderedRules[i].Order = i + 1;
                        }

                        athoc.iws.rule.reorderRules({ orderedRules: orderedRules });
                    }
                });

                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
            },

            handleError: function (e) {

                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                }

                var res = e.xhr ? e.xhr.responseText : e.responseText;
                if (res) {
                    // load event manager util for 

                    var timeOut = athoc.iws.rule.eventUtil.sessionTimeOut(res);
                    if (timeOut) {
                        return;
                    }
                }

                athoc.iws.rule.showErrorMessage(athoc.iws.rule.resources.EventRule_Manager_Error_General);
            },

            refreshGrid: function (successCallback) {
                //show the loader when we make a request to the server...
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: athoc.iws.rule.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.rule.resources.General_LoadingMessage }).showLoader();
                //Per telerik, this will set the page only after datasource refreshes.
                var grid = $("#ruleList").data("kendoGrid");

                grid.dataSource.one("change", function () {
                    //pagination needs to be reset after a reload
                    this.page(1);
                    if (athoc.iws.rule.OnRefreshGridSuccessCallback) {
                        athoc.iws.rule.OnRefreshGridSuccessCallback();
                        athoc.iws.rule.OnRefreshGridSuccessCallback = null;
                    }

                    //scrolling to the top when paging and sorting.
                    $("html,body").scrollTop(0);
                });
                athoc.iws.rule.clearSelection();
                athoc.iws.rule.displayIndex = 0;
                grid.dataSource.read();
                //
                athoc.iws.rule.OnRefreshGridSuccessCallback = successCallback;
            },

            OnDataBound: function () {
                athoc.iws.rule.displayIndex = 0;

                /*if (!athoc.iws.rule.ViewModel.FilterDisabled) {
                    return;
                }*/
                // show empty list message                  
                var colCount = $("#ruleList").find('.k-grid-header colgroup > col').length;
                var grid = $("#ruleList").data("kendoGrid");
                if (grid.dataSource.view().length == 0) {
                    $("#ruleList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:200px"><b> ' +
                            kendo.format(athoc.iws.rule.resources.EventRule_Manager_EmptyDataMsg, 'athoc.iws.rule.showRule(0);') +
                            '</b></td></tr>');
                }
                athoc.iws.rule.bindCheckboxChanged();
            },

            showRuleList: function () {
                var breadcrumbsModel = athoc.iws.rule.breadcrumbModel;
                breadcrumbsModel.SelectedPage('ruleList');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);
                navigateToPage('ruleList', function () { $("body,.title-bar-wrap").css("background-color", "#eeeeee"); });
                athoc.iws.rule.clearSelection();
                athoc.iws.rule.onMessagePanelHide();
                $(".help-icon").attr('onClick', 'FMCOpenHelp(1004, null, null, null );');
            },            
            showRule: function (ruleId) {
                

                var successRuleLoad = function (ruleCriteria) {

                    // this is for second applyBindings, for some reason is there is a validation object involved it throus an error.
                    // we we clear the dom object first...
                    $("#RuleDetail").find(".warning").parent().remove();

                    // first move out the control so it will be out of the binding scope.
                    $("#queryBuilderDiv").appendTo("#outsideRuleModel");

                    //Binding                    
                    ko.cleanNode($("#RuleDetail").get(0));
                    athoc.iws.rule.detailViewModel = new athoc.iws.rule.ruleDetailViewModel(ruleId, ruleCriteria);
                    ko.applyBindings(athoc.iws.rule.detailViewModel.model, $("#RuleDetail").get(0));

                    var result = ko.validation.group(athoc.iws.rule.detailViewModel.model, { deep: true });
                    if (result().length > 0) {
                        result.showAllMessages(true);
                    }

                    $("#queryBuilderDiv").appendTo("#queryBuilderDivContainer");

                    if (ruleCriteria && ruleCriteria.SearchCriteriaModel && ruleCriteria.SearchCriteriaModel.selections) {
                        $("#queryBuilderDiv").athocQueryBuilder("setPreselections", ruleCriteria.SearchCriteriaModel.selections);
                    } else {
                        $("#queryBuilderDiv").athocQueryBuilder("setPreselections", null);
                    }

                    $('#queryBuilderDiv').athocQueryBuilder("setOnChangedFunction", function () {
                        athoc.iws.rule.detailViewModel.model.isChanged = true;
                    });
                    $("#mainAlertRuleContainer").hide();
                    $(document).scrollTop(0);
                    $(".container.hide.content-height").css("display", "block");

                    //match column size for left & right 
                    //$("#RuleDetail .bucket").height('auto');
                    //$.expandToFit("#RuleDetail [id^='eumRow_']:visible", ".bucket:last-child", ">:first-child");

                    var breadcrumbsModel = athoc.iws.rule.breadcrumbModel;
                    breadcrumbsModel.SelectedPage('ruleDetail');
                    athoc.iws.rule.breadcrumbModel.updateTitle(athoc.iws.rule.detailViewModel.model.rule.Name(), undefined, undefined, 'ruleDetail');
                    $.titleCrumb("pageBreadcrumbs");
                    $(document).scrollTop(0);

                    navigateToPage('ruleDetail', function () { $("body,.title-bar-wrap").css("background-color", "#FFFFFF");});

                    /*var onShown = function (queryDivSelector) {
                        return function () {
                            // do somthing
                        };
                    }("#queryBuilderDiv");*/

                    $("#queryBuilderDiv").athocQueryBuilder("show");
                    // patch for the createia control
                    $("#criteriaContainer").removeClass('height200');

                    $("#ruleDetailMessagePanel").hide();

                    $(".help-icon").attr('onClick', 'FMCOpenHelp(1005, null, null, null );');
                };

                var failRuleLoad = function (errorMessage) {
                    alert(errorMessage);
                }

                athoc.iws.rule.loadRuleCriteria(ruleId, successRuleLoad, failRuleLoad);
            },

            getNewRuleOrder: function () {
                var maxRuleOrder = 0;
                athoc.iws.rule.ruleById.forEach(function (rule) {
                    if (rule.Order > maxRuleOrder) {
                        maxRuleOrder = rule.Order;
                    }
                });

                return maxRuleOrder + 1;
            },

            ruleDetailViewModel: function (ruleId, ruleCriteria) {
                var self = this;
                self.getModel = function (ruleId) {
                    var ruleInfo;
                    if (ruleId == 0) {
                        ruleInfo = { Id: 0, Name: athoc.iws.rule.resources.EventRule_Manager_New_Rule_Default_Name, StopProcessing: false, CriteriaEntityId: 0, DelegateResponses: false, Scenario: 0, Order: athoc.iws.rule.getNewRuleOrder() };
                    } else {
                        ruleInfo = athoc.iws.rule.getRuleById(ruleId);
                    }
                    ruleInfo.SearchCriteriaInput = ruleCriteria;

                    var scenarioList = [];
                    scenarioList.push({ Name: athoc.iws.rule.resources.EventRule_Manager_Default_Scenario_Name, Id: 0 });
                    for (var i = 0; i < athoc.iws.rule.scenarios.length; i++) {
                        var scenario = athoc.iws.rule.scenarios[i];
                        if (scenario != null && (scenario.IsReady || scenario.Id == ruleInfo.Scenario)) {
                            scenarioList.push(scenario);
                        }
                    }

                    return { scenarios: ko.observableArray(scenarioList), rule: ko.mapping.fromJS(ruleInfo, athoc.iws.rule.getNewRuleValidation()), isChanged: false };
                };

                var newModel = self.getModel(ruleId);
                self.model = newModel;//ko.mapping.fromJS(newModel, athoc.iws.rule.getNewRuleValidation());

                /*self.refreshModel = function(ruleId)
                {
                    newModel = self.getModel(ruleId);
                    //ugly!!! but we can't rebind the model so we have to clean it manually
                    self.model.rule.Id(newModel.rule.Id);
                    self.model.rule.Name(newModel.rule.Name);
                    self.model.rule.Order(newModel.rule.Order);
                    self.model.rule.Scenario(newModel.rule.Scenario > 0 ? newModel.rule.Scenario : '');
                    self.model.rule.StopProcessing(newModel.rule.StopProcessing);
                    self.model.rule.CriteriaEntityId(newModel.rule.CriteriaEntityId);
                    self.model.rule.DelegateResponses(newModel.rule.DelegateResponses);                                        

                    // update scenarios
                    //while (self.model.scenarios.length) { self.model.scenarios.pop(); }
                    self.model.scenarios = [];
                    // add the new values
                    newModel.scenarios.forEach(function (scenario) {
                        self.model.scenarios.push(scenario);
                    });

                    self.model.IsChanged(false);
                }*/

                self.model.rule.Name.subscribe(function (newValue) {
                    self.model.rule.Name($.trim(newValue));
                    self.model.isChanged = true;
                });

                self.model.rule.Scenario.subscribe(function (newValue) {
                    var isScenarioSelected = (newValue != null && newValue > 0);
                    self.model.rule.DelegateResponses(isScenarioSelected);
                    $('#ruleDelegateResponsesCheckbox').attr("disabled", !isScenarioSelected);
                    self.model.rule.DelegateResponses(isScenarioSelected);

                    $('#ruleScenarioSelectDiv').toggleClass('error', !athoc.iws.rule.isScenarioReady(newValue));
                    self.model.isChanged = true;
                });

                self.model.rule.DelegateResponses.subscribe(function (newValue) {
                    $('#ruleStopProcessingCheckbox').attr("disabled", self.model.rule.DelegateResponses());
                    if (self.model.rule.DelegateResponses()) {
                        self.model.rule.StopProcessing(true);

                    }

                    self.model.isChanged = true;
                });

                self.udpateUI = function () {
                };

                self.model.rule.StopProcessing.subscribe(function (newValue) {
                    self.model.isChanged = true;
                });

                self.setOptionStyling = function (option, item) {
                    if (item) {
                        ko.applyBindingsToNode(option, { css: { 'red': !item.IsReady } }, item);
                    }
                }
            },

            //setup validation
            getNewRuleValidation: function () {
                var validationMapping = {
                    Name: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {
                                    params: true,
                                    message: athoc.iws.rule.resources.EventRule_Manager_Validation_Name
                                },
                                minLength: {
                                    params: 3,
                                    message: athoc.iws.rule.resources.EventRule_Manager_Validation_Name
                                },
                                maxLength: {
                                    params: 100,
                                    message: athoc.iws.rule.resources.EventRule_Manager_Validation_Name
                                }
                            });
                        }
                    },

                    Scenario: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                readyScenario: {
                                    params: true,
                                    message: athoc.iws.rule.resources.EventRule_Manager_Validation_Scenario_Ready
                                },
                            });
                        }
                    },
                };

                return validationMapping;
            },

            loadRuleCriteria: function (ruleId, successCallback, failCallback) {
                var ruleInfo = athoc.iws.rule.getRuleById(ruleId);
                if (ruleId > 0 && ruleInfo == null) {
                    // error, can't find id
                    if (failCallback) {
                        failCallback(athoc.iws.rule.resources.EventRule_Manager_Error_General);
                    }
                    return;
                }
                if (ruleId == 0 || ruleInfo.CriteriaEntityId == 0) {
                    if (successCallback) {
                        successCallback(null);
                    }
                    return;
                }

                var postData = { ruleId: ruleId };
                athoc.iws.rule.makeAjaxCall(athoc.iws.rule.urls.LoadRuleCriteria, postData, successCallback, failCallback, null, athoc.iws.rule.resources.EventRule_Manager_Error_LoadRule);
            },

            reorderRules: function (ruleOrder) {
                var postData = ruleOrder;

                var successCallback = function (data) {
                    athoc.iws.rule.refreshGrid();
                };
                athoc.iws.rule.makeAjaxCall(athoc.iws.rule.urls.ReorderRules, postData, successCallback, null, athoc.iws.rule.resources.EventRule_Manager_Success_Reorder, athoc.iws.rule.resources.EventRule_Manager_Error_Reorder);
            },

            onRuleDetailNavigateAway: function () {
                if (athoc.iws.rule.detailViewModel && athoc.iws.rule.detailViewModel.model
            				&& athoc.iws.rule.detailViewModel.model.isChanged) {
                    var confirmLeave = confirm($.htmlDecode(athoc.iws.rule.resources.Unsaved_Data_Text));
                    if (confirmLeave === true) {
                        athoc.iws.rule.detailViewModel.model.isChanged = false;
                        athoc.iws.rule.showRuleList();
                    }
                } else {
                    athoc.iws.rule.showRuleList();
                }

            },
            saveRule: function () {
                //validation here
                var result = ko.validation.group(athoc.iws.rule.detailViewModel, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages(true);
                    return false;
                }

                var ruleCriteria = $('#queryBuilderDiv').athocQueryBuilder("getCurrentSelections");

                if (!ruleCriteria.selections || ruleCriteria.selections.length == 0) {
                    athoc.iws.rule.showErrorMessage(athoc.iws.rule.resources.EventRule_Manager_Validation_Criteria, true);
                    return false;
                }

                var ruleInfo = ko.mapping.toJS(athoc.iws.rule.detailViewModel).model.rule;

                ruleInfo.SearchCriteriaInput = ruleCriteria;
                var postData = ruleInfo;

                athoc.iws.rule.detailViewModel.model.isChanged = false;
                var successCallback = function (data) {
                    athoc.iws.rule.showRuleList();
                    athoc.iws.rule.showSuccessMessage(athoc.iws.rule.resources.EventRule_Manager_Success_Save);
                    athoc.iws.rule.refreshGrid();
                };
                var failCallback = function (data) {
                    athoc.iws.rule.showRuleList();
                    athoc.iws.rule.showErrorMessage(athoc.iws.rule.resources.EventRule_Manager_Error_Save);
                    athoc.iws.rule.refreshGrid();
                };
                athoc.iws.rule.makeAjaxCall(athoc.iws.rule.urls.SaveRule, postData, successCallback, failCallback, null, null);
            },

            // Triggered, when 'Select All' check box is checked
            selectAll: function () {
                //change the underlying observable...
                var checked = $('#rule-select-all').is(':checked');
                var grid = $('#ruleList').data().kendoGrid;
                $.each(grid.dataSource.view(), function (i, item) {
                    item.IsChecked = checked;
                });

                grid.refresh();//update the grid...
                //athoc.iws.rule.retainSelectAll();// update view count to enable/disable action items
                athoc.iws.rule.updateSelectedTotal();// Update selected count
            },

            clearSelection: function () {
                //change the underlying observable...
                $('#rule-select-all').prop('checked', false);
                var grid = $('#ruleList').data().kendoGrid;
                $.each(grid.dataSource.view(), function (i, item) {
                    item.IsChecked = false;
                });
                grid.refresh();//update the grid...
                athoc.iws.rule.updateSelectedTotal();
            },

            bindCheckboxChanged: function () {
                var grid = $('#ruleList').data().kendoGrid;
                grid.tbody.on("change", ".senario-select", function (e) {
                    var row = $(e.target).closest("tr");
                    var item = grid.dataItem(row);
                    item.IsChecked = $(e.target).is(":checked");
                    athoc.iws.rule.updateSelectedTotal();
                });
            },

            getSelectedRules: function () {
                var grid = $('#ruleList').data().kendoGrid;
                var items = grid.dataSource.view();

                // Get the selected items for the current page.
                var selected = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                return selected;
            },
            on: function (evtName, callback) {
                this[evtName] = callback;
            },
            updateSelectedTotal: function () {
                athoc.iws.rule.ruleListButtonModel.hasSelectedRules(athoc.iws.rule.getSelectedRules().length > 0);
                athoc.iws.rule.selectionChanged(athoc.iws.rule.getSelectedRules().length);
            },
            selectionChanged: function (count) { },
            deleteRules: function () {
                var selectedItems = athoc.iws.rule.getSelectedRules();
                var count = athoc.iws.rule.getSelectedRules().length;
                var seletedIds = [];
                selectedItems.forEach(function (selectedRule) {
                    seletedIds.push(selectedRule.Id);
                });
                var postData = { ids: seletedIds };
                // var postData = { ids: [1] };

                athoc.iws.rule.showConfirmationDialog(
                    {
                        Title: athoc.iws.rule.resources.EventRule_Manager_Confirm_Delete_Title,
                        Body: kendo.format(athoc.iws.rule.resources.EventRule_Manager_Confirm_Delete_Body, ""),
                        Footer: athoc.iws.rule.resources.EventRule_Manager_Confirm_Delete_Footer,
                        ConfirmAction: function () {
                            var successCallback = function (data) {
                                athoc.iws.rule.hideConfirmationDialog();
                                athoc.iws.rule.refreshGrid();
                            };
                            athoc.iws.rule.makeAjaxCall(athoc.iws.rule.urls.DeleteRule, postData, successCallback, null, athoc.iws.rule.resources.EventRule_Manager_Success_Delete, athoc.iws.rule.resources.EventRule_Manager_Error_Delete);
                        },
                    }
                );
            },

            isScenarioReady: function (id) {
                if (!id || id <= 0) {
                    return true;
                }
                var scenario = athoc.iws.rule.getScenarioById(id);
                return (scenario && scenario.IsReady);
            },

            //params: should include: Title, Body, Footer, ConfirmAction
            showConfirmationDialog: function (params) {
                athoc.iws.rule.CancelDlgData = ko.observable(params);
                //Binding
                ko.cleanNode($("#genericConfirmDialog").get(0));
                ko.applyBindings(athoc.iws.rule.CancelDlgData, $("#genericConfirmDialog").get(0));

                $('#genericConfirmDialog .btn-confirm').off("click").click(function () {
                    if (params.ConfirmAction) {
                        params.ConfirmAction();
                    }
                    return false;
                });
                $('#genericConfirmDialog .btn-cancel').off("click").click(function () {
                    athoc.iws.rule.hideConfirmationDialog();
                    return false;
                });
                $('#genericConfirmDialog').show();
                $('.modal-backdrop').show();
            },

            hideConfirmationDialog: function (params) {
                $('.modal-backdrop').hide();
                $('#genericConfirmDialog').hide();
            },

            showErrorMessage: function (msg, isDetailView) {
                if (isDetailView) {
                    $('#ruleDetailMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: msg }] }, null, null, null, errorTitleStrings);
                } else {
                    $('#ruleMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: msg }] }, null, athoc.iws.rule.onMessagePanelShow, athoc.iws.rule.onMessagePanelHide, errorTitleStrings);
                }
            },

            showSuccessMessage: function (msg, isDetailView) {
                if (isDetailView) {
                    $('#ruleDetailMessagePanel').messagesPanel({ messages: [{ Type: '8', Value: msg }] }, null, null, null, errorTitleStrings);
                } else {
                    $('#ruleMessagePanel').messagesPanel({ messages: [{ Type: '8', Value: msg }] }, null, athoc.iws.rule.onMessagePanelShow, athoc.iws.rule.onMessagePanelHide, errorTitleStrings);
                }
            },

            onMessagePanelShow: function () {
                if (typeof athoc.iws.rule.messagePanelViewAdjusted !== 'undefined' && athoc.iws.rule.messagePanelViewAdjusted) {
                    return;
                }
                var stsPanel = $("html").find(".kgrid-status-panel");
                if (stsPanel) {
                    var pnlHgt = parseInt($(".kgrid-status-panel").css("height"), 10);

                    var tcwTp = parseInt($(".table-crown-wrap").css("top"), 10);
                    var kgrdFxHdrTp = parseInt($(".kgrid-fix-header").css("top"), 10);
                    var kgrdHdrTp = parseInt($(".k-grid-header").css("top"), 10);
                    var whtoutHgt = parseInt($(".whiteout").css("height"), 10);

                    $(".table-crown-wrap").css("top", tcwTp + pnlHgt);
                    $(".k-grid-header").css("top", kgrdHdrTp + pnlHgt);
                    //$(".kgrid-fix-header").css("top", "305px");

                    $(".kgrid-fix-header").css("top", kgrdFxHdrTp + pnlHgt);
                    $(".whiteout").css("height", whtoutHgt + pnlHgt);
                    $("html,body").scrollTop(0);
                    athoc.iws.rule.messagePanelViewAdjusted = true;
                }
            },

            onMessagePanelHide: function () {
                if (!athoc.iws.rule.messagePanelViewAdjusted) {
                    // already adjusted
                    return;
                }
                var stsPanel = $("html").find(".kgrid-status-panel");
                if (stsPanel) {
                    var pnlHgt = parseInt($(".kgrid-status-panel").css("height"), 10);
                    var tcwTp = parseInt($(".table-crown-wrap").css("top"), 10);
                    var kgrdFxHdrTp = parseInt($(".kgrid-fix-header").css("top"), 10);
                    var kgrdHdrTp = parseInt($(".k-grid-header").css("top"), 10);
                    var whtoutHgt = parseInt($(".whiteout").css("height"), 10);
                    $(".table-crown-wrap").css("top", tcwTp - pnlHgt);
                    //$(".kgrid-fix-header").css("top", "235px");
                    $(".kgrid-fix-header").css("top", "235px");
                    $(".kgrid-fix-header").css("top", kgrdFxHdrTp - pnlHgt);
                    $(".k-grid-header").css("top", kgrdHdrTp - pnlHgt);
                    $(".whiteout").css("height", whtoutHgt - pnlHgt);
                    $(".kgrid-status-panel").hide();
                    athoc.iws.rule.messagePanelViewAdjusted = false;
                }
            },

            makeAjaxCall: function (url, postData, successCallback, failCallback, successMessage, errorMessage) {
                //$.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.rule.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%' }).showLoader();
                var dlSuccess = function (data) {
                    //$.AjaxLoader.hideLoader();
                    if (data.Success) {
                        if (successMessage) {
                            athoc.iws.rule.showSuccessMessage(successMessage);
                        }
                        if (successCallback) {
                            successCallback(data);
                        }
                    } else {
                        athoc.iws.rule.handleError(data);
                        if (errorMessage) {
                            athoc.iws.rule.showErrorMessage(errorMessage);
                        }
                        if (failCallback) {
                            failCallback();
                        }
                    }
                };

                var dlAjaxOption =
                    {
                        contentType: 'application/json',
                        dataType: 'json',
                        type: "POST",
                        data: JSON.stringify(postData),
                        url: url,
                    };

                var dlError = function (data) {
                    $.AjaxLoader.hideLoader();
                    if (errorMessage) {
                        athoc.iws.rule.showErrorMessage(errorMessage);
                    }
                    athoc.iws.rule.handleError(data);
                    if (failCallback) {
                        failCallback(errorMessage);
                    }
                }
                var ajaxOptions = $.extend({}, AjaxUtility(dlError, dlSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },
        };
    }();
}



ko.validation.rules['readyScenario'] = {
    validator: athoc.iws.rule.isScenarioReady,
    message: ''
};

ko.validation.registerExtenders();

