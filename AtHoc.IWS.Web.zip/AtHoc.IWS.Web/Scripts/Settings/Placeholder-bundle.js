﻿///#source 1 1 /Scripts/Settings/athoc.iws.Placeholder.list.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.placeholder = athoc.iws.placeholder || {};

if (athoc.iws.placeholder) {
    athoc.iws.placeholder.list = function () {
        var datasource = null;
        var sortState = null;
        var isRepeated = false;
        var isSearched = false;

        return {
            viewModel: {
            },
            searchString: [],
            loadViewModel: function () {

                //Need this because with kendo textbox binding, IE9 is not showing the placeholder - this is work around
                /* $("#txtSearch").focus();
                $("#txtSearch").blur();*/


                this.viewModel =
                {
                    SearchText: ko.observableArray(),
                    AttributeTypes: ko.observable([]),
                    SelectedAttributeTypes: ko.observable([]),
                    CurrentOrganizationAttributesOnly: ko.observable(false),
                    OtherOrganizationAttributesOnly: ko.observable(false),
                    OrgaType: ko.observable(),

                    // Enable or disable search button
                    ShouldEnableSearch: function (e) {
                        if ($.trim($('#txtSearch').val()).length > 0)
                            return true;
                        else
                            return false;
                    },

                    // Show pills while searching
                    FilterPlaceholdersList: function (e) {
                        athoc.iws.placeholder.list.createPills($.trim($('#txtSearch').val()));
                        $('#txtSearch').val('');
                        $('#pillContainer').show();
                    },

                    ClearAll: function (e) {
                        athoc.iws.placeholder.list.searchString.length = 0;
                        athoc.iws.placeholder.list.viewModel.SearchText([]);
                        $("#koBoundElement .pill-container").html('');
                        $("#koBoundElement #pillContainer").hide();
                        athoc.iws.placeholder.list.refreshGrid(); 
                        athoc.iws.placeholder.list.setGridHeight();
                    },
                };
            },

            load: function () {

                this.loadViewModel();
                athoc.iws.placeholder.list.viewModel.OrgaType(athoc.iws.placeholder.resources.UserAttributeManager_SimpleSearch_Type_AllAttributes);
                ko.applyBindings(this.viewModel, document.getElementById("koBoundElement"));
                this.createAttributeListGrid();
                $("#caret").removeClass("hide");

                // On seleting the menu item corresponding attributes are loading in grid.
                $("#contextDropdown .text-select").click(function () {
                    athoc.iws.placeholder.list.viewModel.OrgaType(this.innerHTML);
                    var type = this.getAttribute("value");
                    athoc.iws.placeholder.list.viewModel.CurrentOrganizationAttributesOnly(false);
                    athoc.iws.placeholder.list.viewModel.OtherOrganizationAttributesOnly(false);

                    if (type == 1) {
                        athoc.iws.placeholder.list.viewModel.CurrentOrganizationAttributesOnly(false);
                        athoc.iws.placeholder.list.viewModel.OtherOrganizationAttributesOnly(false);
                    }
                    else if (type == 2)
                        athoc.iws.placeholder.list.viewModel.CurrentOrganizationAttributesOnly(true);
                    else if (type == 3)
                        athoc.iws.placeholder.list.viewModel.OtherOrganizationAttributesOnly(true);

                    athoc.iws.placeholder.list.refreshGrid();
                    $("#contextDropdown").hide();
                });

                // To hide the context dorpdown
                $("body").click(function () {
                    $("#contextDropdown").hide();
                });

                // Execute search options when press enter key in search textbox
                $("#txtSearch").keyup(function (e) {
                    // $("#searchBtn").removeAttr('disabled');
                    var seaString = $.trim($('#txtSearch').val());
                    if ($.hotkeys.enter(e) && seaString != "") {
                        $('#pillContainer').show();
                        athoc.iws.placeholder.list.createPills(seaString);
                        $("#txtSearch").val("");
                    }
                });
                $("#ulNavLinks li a").keyup(function (e) {
                    if ($.hotkeys.enter(e))
                        window.location.href = this.href;
                });

                $("#orgTypes").keyup(function (e) {
                    if ($.hotkeys.enter(e))
                        athoc.iws.placeholder.list.showOrgnizationTypes(event);
                });

               // $("#txtSearch").focus();
                $("#btnNewUserAttribute").focus();
            },

            // Diplaying the organization types
            showOrgnizationTypes: function (event) {
                $("#contextDropdown").show();
                event.cancelBubble = true;
            },

            // Fill attribute list in grid
            createAttributeListGrid: function () {
                var self = this;
                var url = athoc.iws.placeholder.urls.GetPlaceholderListUrl;

                // Prepare datasource for grid
                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.placeholder.list.viewModel);

                            var newState = JSON.stringify(options.sort);
                            if ((sortState) && newState != sortState) {
                                sortState = newState;
                                isRepeated = true;
                                options.page = 1;
                                options.skip = 0;
                                datasource.page(1);
                            }
                            return ko.toJSON(options);
                        },
                    },
                    requestStart: function (e) {
                        //isRepeated flag is to save duplicate calls to 
                        //server during sorting
                        if (isRepeated) {
                            e.preventDefault();
                            isRepeated = false;
                        }
                    },
                    requestEnd: function (e) {
                        sortState = JSON.stringify(e.sender._sort);
                        athoc.iws.placeholder.list.fitHeight();
                        //if ($('#placeholderListActionButtons ul li').length == 0 Commented as per the Dan Review
                        //    athoc.iws.placeholder.list.fillAtributeDropdown(e.response.Attributes)
                        $.AjaxLoader.hideLoader();
                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount"
                    },
                    serverPaging: true,
                    serverSorting: true,
                    serverFiltering: true,
                    sort: { field: "AttributeName", dir: "asc" },
                    pageSize: 50,
                    error: function (e) {
                        athoc.iws.placeholder.list.handleError(e);
                    },
                });

                // Bind datasource to the grid
                var grid = $("#attributeList").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: athoc.iws.placeholder.resources.UserAttributeManager_PlaceHolder_List_PageInfo,
                            empty: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Empty,
                            //page: athoc.iws.placeholder.resources.UserAttributeManager_Pageable_page,
                            //of: athoc.iws.placeholder.resources.UserAttributeManager_Pageable_of,
                            itemsPerPage: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Items_Per_Page,
                            first: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_First_Page,
                            previous: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page,
                            next: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Next_Page,
                            last: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Last_Page
                            //refresh: athoc.iws.placeholder.resources.UserAttributeManager_Pageable_refresh
                        }
                    },
                    columns:
                    [
                        {
                            field: "Id",
                            hidden: true
                        },
                        {
                            width: "200px",
                            field: "AttributeName",
                            title: athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Name,
                            headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Name + '">' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Name + '</span>',
                            template: '<span class="cellTooltip" title="#=$.htmlEncode(AttributeName)#">#=$.htmlEncode(AttributeName)#</span>',

                        },
                        {
                            width: "130px",
                            field: "AttributeType",
                            title: athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_AttributeType,
                            headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_AttributeType + '" >' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_AttributeType + '</span>',                            
                            template: '<span class="cellTooltip" title="#=athoc.iws.placeholder.list.replaceType(AttributeTypeId)#">#=athoc.iws.placeholder.list.replaceType(AttributeTypeId)#</span>',
                            
                        },
                        
                        {
                            width: "149px",
                            field: "AttributeOrigin",
                            title: athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Origin,
                            headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Origin + '">' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_Origin + '</span>',
                            template: '<span class="cellTooltip" title="#=AttributeOrigin#">#=AttributeOrigin#</span>',

                        },
                        {
                            width: "120px",
                            field: "UpdatedOn",
                            title: athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_UpdatedOn,
                            headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_UpdatedOn + '">' + athoc.iws.placeholder.resources.UserAttributeManager_ColHeader_UpdatedOn + '</span>',
                            template: '<span class="cellTooltip" title="#=UpdatedOn#">#=athoc.iws.placeholder.list.replaceString(UpdatedOn)#</span>'
                        }
                    ],
                    dataBound: athoc.iws.placeholder.list.OnDataBound
                }).data().kendoGrid;

                this.refreshGrid();
            },

            // Reload the grid
            refreshGrid: function () {
                //show the loader when we make a request to the server...
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.placeholder.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();
                datasource.page(1);
            },

            replaceString: function (value) {
                var d = new Date("1/1/2000");
                var vD = new Date(value);
                if (d.getTime() == vD.getTime())
                    return " ";
                else
                    return value;
            },

            replaceType: function (val) {
                switch (val) {
                    case 1:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Number;
                        break;
                    case 2:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Text;
                        break;
                    case 3:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Memo;
                        break;
                    case 4:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Date;
                        break;
                    case 5:
                        return athoc.iws.placeholder.resources.UserAttributeManager_DateTime;
                        break;
                    case 6:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Single_select_Picklist;
                        break;
                    case 7:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Multi_select_Picklist;
                        break;
                    case 8:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Checkbox;
                        break;
                    case 9:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Path;
                        break;
                    case 10:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Geolocation;
                        break;
                    case 11:
                        return athoc.iws.placeholder.resources.UserAttributeManager_Time;
                        break;
                }
            },

            // Adjust height of grid
            fitHeight: function () {
                var gridTop = $('.header-bar-wrap').outerHeight() + $('.title-bar-wrap').outerHeight() + $('.table-crown-wrap').outerHeight(); //+10 is for space between crown and top of the grid
                $(".whiteout").css("height", gridTop);
                $("#attributeList").css("top", gridTop);
                  var extraSpace = $('.footer-wrap').outerHeight() + 10;
                 var headerHeight = $('.k-grid-header').outerHeight();
                 var pagerHeight = $('.k-pager-wrap').outerHeight();
                $("#attributeList").css("height", $(window).height() - gridTop - extraSpace);
                $(".k-grid-content").css("height", $(window).height() - (gridTop + headerHeight + pagerHeight) - extraSpace);

            },

            // Adjust height of grid after message panel is closed.
            fitHeightAfterMessagePanelClosed: function () {
                $(".table-crown-wrap").css("top", "");
                athoc.iws.placeholder.list.fitHeight();
            },

            // Adjust height of grid when messaage pannel is appear
            fitHeightWithMessagePanel: function () {

                var messagePanelTop = $('.header-bar-wrap').outerHeight() + $('.title-bar-wrap').outerHeight();
                var tableCrownTop = $('.header-bar-wrap').outerHeight() + $('.title-bar-wrap').outerHeight() + $('#listMessagePanel').outerHeight();
                var gridTop = tableCrownTop + $('.table-crown-wrap').outerHeight() + 10; //+10 is for space between crown and top of the grid
                var extraSpace = $('.footer-wrap').outerHeight() + 10;
                var headerHeight = $('.k-grid-header').outerHeight();
                var pagerHeight = $('.k-pager-wrap').outerHeight();

                $("#listMessagePanel").css("top", messagePanelTop);
                $(".table-crown-wrap").css("top", tableCrownTop - 20); //this should add because of messagepanel bottom margin - checked with jeff
                $(".whiteout").css("height", messagePanelTop);
                $("#attributeList").css("top", gridTop - 20);
                $("#attributeList").css("height", $(window).height() - gridTop - extraSpace + 22);
                $(".k-grid-content").css("height", $(window).height() - (gridTop + headerHeight + pagerHeight) - extraSpace + 20);
            },

            // Databound event of grid
            OnDataBound: function (e) {

                $("#attributeList tbody").find("tr").attr("tabindex", "0");
                // this.pager.element.hide();
                $("#attributeList .k-auto-scrollable").scrollTop(0);
                var grid = $("#attributeList").data("kendoGrid");
                var data = grid.dataSource.data();

                $(grid.tbody).unbind("click");

                $(grid.tbody).on("click", "td", function (e) {

                    var row = $(this).closest("tr");
                    var rowIdx = $("tr", grid.tbody).index(row);
                    var view = grid.dataSource.view();
                    var model = view[rowIdx];
                    window.location.href = window.location.href.replace(/\/*$/, "") + "/Edit/" + model.Id;
                    e.stopPropagation();

                });

                $(grid.tbody).on("keypress", "tr", function (e) {

                    var code = e.keyCode || e.which;

                    if (code == 13) {
                        var row = $(this);
                        var rowIdx = $("tr", grid.tbody).index(row);
                        var model = data[rowIdx];
                        window.location.href = window.location.href.replace(/\/*$/, "") + "/Edit/" + model.Id;
                    }
                });

                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    if (isSearched) {
                        $(e.sender.wrapper)
                            .find('tbody')
                            .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.placeholder.resources.AtHoc_Grid_NoRecords + '</td></tr>');
                    } else {
                        $(e.sender.wrapper)
                            .find('tbody')
                            .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.placeholder.resources.UserAttributeManager_No_Records_Found + '</td></tr>');
                    }
                }
            },


            // Error handler
            handleError: function (e) {
                var errorCallBack = function (returnedErrorObject) {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, null, athoc.iws.placeholder.list.fitHeightWithMessagePanel, athoc.iws.placeholder.list.fitHeightAfterMessagePanelClosed);
                };
                window.AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);
            },

            //to fill attributes dropdown with model data
            fillAtributeDropdown: function (data) {
                _.each(data, function (item) {
                    var value = item.Value;
                    if (item.Value == 'GeoLocation')
                        value = 'Geography'
                    else if (item.Value == 'MultiPicklist')
                        value = 'Multi-Picklist'
                    $('#placeholderListActionButtons ul').append('<li><a href=/athoc.iws.placeholder.lists/New/' + value + ' >' + item.Text + '</a></li>');
                });
            },

            // This is not using as attributes dropdown is removed.
            getAttributeTypes: function () {
                var myAjaxOptions = {
                    url: athoc.iws.placeholder.urls.GetPlaceholderTypesUrl,
                    type: "GET",
                    contentType: 'application/json',
                    dataType: 'json',


                };

                var onError = function (errorResult) {

                };

                var onSuccess = function (data) {

                    if (data && data.Success && data.Success === true) {
                        if (data.Data && data.Data.length > 0) {
                            var items = [];
                            for (var i = 0; i < data.Data.length; ++i) {
                                var item = { "optionText": data.Data[i].AttributeType, "optionValue": data.Data[i].AttributeTypeId };
                                items.push(item); //athoc.iws.placeholder.list.viewModel.AttributeTypes().push(item);

                            }
                            athoc.iws.placeholder.list.viewModel.AttributeTypes(items);
                            $("#attributeTypes").selectpicker('refresh');
                            $("#attributeTypes").selectpicker('selectAll');

                        }
                    }
                };
                var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

            },

            // Createing pills when search is done
            createPills: function (value) {
                $("#btnClearAll").removeClass("hide");
                if (value == "")
                    return;
                var found = _.find(athoc.iws.placeholder.list.searchString, function (item) {
                    return (item == value);
                });
                if (!found) {
                    isSearched = true;
                    athoc.iws.placeholder.list.searchString.push(value);
                    athoc.iws.placeholder.list.renderPills();
                    athoc.iws.placeholder.list.viewModel.SearchText(athoc.iws.placeholder.list.searchString);
                    athoc.iws.placeholder.list.refreshGrid();

                }
            },

            // Rendering the pills when search is done
            renderPills: function (css) {
                var self = this;
                var html = "";
                $("#koBoundElement .pill-container").html('');
                if (athoc.iws.placeholder.list.searchString && athoc.iws.placeholder.list.searchString.length > 0) {
                    _.each(athoc.iws.placeholder.list.searchString, function (item, index) {
                        var iconCss = "";
                        var prefix = "";
                        var pillLabel = prefix + $.htmlEncode(item);
                        var pillTooltip = prefix + $.htmlEncode(item);
                        var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" style="cursor:pointer" ></a>' : '');
                        html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                    });

                    var pillsElm = $("#koBoundElement .pill-container");
                    pillsElm.html(html);
                    //wire up events
                    $("#koBoundElement .pill-close").click(function (event) {
                        var parentElm = $(this).parent(".pill");
                        athoc.iws.placeholder.list.deSelect(parentElm.data("index"));
                        event.stopPropagation();
                    });
                    athoc.iws.placeholder.list.setGridHeight();
                }
            },

            // Deleteing the pills
            deSelect: function (index, onSuccess) {
                if (athoc.iws.placeholder.list.searchString && athoc.iws.placeholder.list.searchString.length > index) {
                    athoc.iws.placeholder.list.searchString.splice(index, 1);
                    if (athoc.iws.placeholder.list.searchString.length == 0)
                        athoc.iws.placeholder.list.viewModel.SearchText([]);
                    athoc.iws.placeholder.list.renderPills();
                    athoc.iws.placeholder.list.refreshGrid();
                    athoc.iws.placeholder.list.setGridHeight();
                }
            },

            // Adjust grid and search panel height according to the pills.
            setGridHeight: function () {
                if (athoc.iws.placeholder.list.searchString.length > 0) {
                    $(".table-crown-center").css("height", "auto");
                    $(".k-grid-header").css("top", "205px");
                    $("#topSpace").css("height", "257px");
                } else {
                    $("#koBoundElement .pill-container").html('');
                    $(".k-grid-header").css("top", "210px");
                    $("#koBoundElement").css("margin-top", "0px");
                    $(".table-crown-center").css("height", "27px");
                    $("#topSpace").css("height", "210px");

                }
            },
        };
    }();
}
///#source 1 1 /Scripts/Settings/athoc.iws.Placeholder.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};

if (athoc.iws) {
    athoc.iws.placeholder= function() {
        return {

            urls: {},

            resources: {},

            init: function() {
                //athoc.iws.Placeholder.initBreadcrumb();
                ko.applyBindings(athoc.iws.placeholder.details.breadCrumbModel, $("#navigationBar").get(0));
            },
            breadCrumbModel: {
                gotoList: function () {
                    window.location.href = athoc.iws.placeholder.details.urls.IndexUrl + "/";
                }
            },
            gotoList: function () {
                    window.location.href = "/client/setup/settings";
            },
            load: function() {
                

                if (window.location.pathname.split('/').length==3 || window.location.pathname.split('/').length == 4) {
                    window.navigateToPage('placeholderList', function () { });
                    athoc.iws.placeholder.list.load();
                }
                else if ($.inArray("Edit",window.location.pathname.split('/'))>-1 && window.location.pathname.split('/').length==5)
                    athoc.iws.placeholder.viewattributeDetail(parseInt(window.location.pathname.split('/')[4]));
                else if ($.inArray("New",window.location.pathname.split('/'))>-1)
                    athoc.iws.placeholder.newAttributeDetails(window.location.pathname.split('/')[4]);
                   
                
                //if (!isNaN(parseInt(window.location.pathname.split('/')[3])))
                  //  athoc.iws.placeholder.viewattributeDetail(parseInt(window.location.pathname.split('/')[3]));
                $("#btnExcelExport").kendoButton({
                    click: function () {
                        //$('#placeholderDependencyList').data('kendoGrid').dataSource.group([]);
                        $("#placeholderDependencyList").getKendoGrid().saveAsExcel();
                    }
                });
            },

            

            viewAttributeList: function (refresh) {

                window.navigateToPage('placeholderList', function () { });
                var breadcrumbsModel = athoc.iws.placeholder.breadcrumbModel;
                breadcrumbsModel.SelectedPage('placeholderList');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);
                
                if (refresh) {
                    athoc.iws.placeholder.list.refreshGrid();
                }
            },

            viewattributeDetail: function (id) {

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.placeholder.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();

                var placeholderDetails = null;
                var myAjaxOptions = {
                    url: athoc.iws.placeholder.urls.GetPlaceholderDetailstUrl,
                    type: "POST",
                    contentType: 'application/json',
                    dataType: 'json',
                    async: false,
                    data: JSON.stringify({'placeholderId': id })
                };

                var onError = function (errorResult) {
                    $.AjaxLoader.hideLoader();
                };

                var onSuccess = function (data, textStatus, jqXHR) {

                    placeholderDetails = data.Data;
                    athoc.iws.placeholder.details.editPlaceholder(placeholderDetails, data.IsDeletable);
                    window.navigateToPage('placeholderDetail', function () { });
                    //window.location.hash = "#attributeDetail";
                    var breadcrumbsModel = athoc.iws.placeholder.breadcrumbModel;
                    breadcrumbsModel.SelectedPage('placeholderDetail');
                    $.titleCrumb("pageBreadcrumbs");
                    breadcrumbsModel.updateTitle(placeholderDetails.AttributeName);

                    $(document).scrollTop(0);
                    $.AjaxLoader.hideLoader();

                    //if (typeof deleteSuccessCallback == "function") {
                    //    deleteSuccessCallback(data, textStatus, jqXHR);
                    //}
                }

                var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

                $.AjaxLoader.hideLoader();
            },

            newAttributeDetails:function(type){
                window.navigateToPage('newAttributeDetail', function () { });
                //window.location.hash = "#attributeDetail";
                var placeholderDetails = null;
                athoc.iws.placeholder.details.createOptionsGrid();
                var breadcrumbsModel = athoc.iws.placeholder.breadcrumbModel;
                breadcrumbsModel.SelectedPage('newAttributeDetail');
                $.titleCrumb("pageBreadcrumbs");
                breadcrumbsModel.updateTitle(type);

            },

            checkForDependencies: function (id) {
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.placeholder.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();
               
                athoc.iws.placeholder.showDependencyList(id);
                /*   var myAjaxOptions = {
                    url: athoc.iws.placeholder.urls.GetPlaceholderDependencyListUrl,
                    type: "POST",
                    contentType: 'application/json',
                    dataType: 'json',
                    async: false,
                    data: JSON.stringify({ 'placeholderId': id })
                };

                var onError = function (errorResult) {
                    $.AjaxLoader.hideLoader();
                };

                var onSuccess = function (data, textStatus, jqXHR) {

                    if (data && data.Success && data.Success === true) {
                        if (data.Data && data.Data.length > 0)
                            athoc.iws.placeholder.showDependencyList(data.Data);
                        else {
                            athoc.iws.placeholder.deletePlaceholder(id);
                        }
                    }
                    $.AjaxLoader.hideLoader();
                }

                var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

                $.AjaxLoader.hideLoader(); */
            },

            showDependencyList: function (dependencyList) {
               
                var dataSource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: athoc.iws.placeholder.urls.GetPlaceholderDependencyListUrl,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },

                        parameterMap: function (data) {
                            var moreData = { "placeholderId": dependencyList };
                            $.extend(data, moreData);
                            return kendo.stringify(data);
                        },

                       

                    },

                    requestStart: function (e) {
                        $.AjaxLoader.setup({ useBlock: true, elementToBlock: $('#placeholderDependencyList .k-grid-content'), imageURL: athoc.iws.placeholder.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage });
                        $.AjaxLoader.showLoader();

                    },
                    requestEnd: function (e) {
                        athoc.iws.placeholder.centerTheDependencyModal();
                        $.AjaxLoader.hideLoader();

                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                        model: {
                                    fields: {
                                        UsedIn: { type: "string"  },
                                        EntityName: { type: "string" },
                                        EntityId: { type: "number" },
                                        UsedFor: { type: "string" },
                                        SourceProvider: { type: "string" }
                                    }
                                },
                    },
                    serverPaging:true,
                   // group: { field: "UsedIn", dir: "asc" }, // set grouping for the dataSource
                    //groupable: false, // this will remove the group bar
                   
                    pageSize: 50,
                });


               

                    $("#placeholderDependencyList").kendoGrid({
                        excel: {
                            fileName: "User Attribute Dependency List.xlsx",
                            allPages: true,
                            filterable: true,
                            proxyURL: athoc.iws.placeholder.urls.ExportDependenciesUrl,
                            forceProxy: true,
                        },
                        dataSource: dataSource,
                        pageable: {
                            refresh: false,
                            pageSizes: [20, 50, 100],
                            buttonCount: 5,
                            messages: {
                                display: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Summary,
                                empty: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Empty,
                                //page: athoc.iws.placeholder.resources.PlaceholderManager_Pageable_page,
                                //of: athoc.iws.placeholder.resources.PlaceholderManager_Pageable_of,
                                itemsPerPage: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Items_Per_Page,
                                first: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_First_Page,
                                previous: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page,
                                next: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Next_Page,
                                last: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Last_Page
                                //refresh: athoc.iws.placeholder.resources.UserAttributeManager_Pageable_refresh
                            }
                        },
                        serverPaging: true,
                        height: 320,
                        sort: { field: "EntityName", dir: "asc" },
                        columns: [
                            { field: "UsedIn", title: "Used In", width: '150px', sortable: false },
                            { field: "EntityName", title: "Name", width: '200px' },
                            { field: "EntityId", title: "ID", width: '100px' },
                            { field: "UsedFor", title: "Used For", width: '150px' },
                            { field: "SourceProvider", title: "Origin" }
                        ],

                    });
               

                athoc.iws.placeholder.centerTheDependencyModal();
                $("#placeholderDependencyList").data('kendoGrid').dataSource.data([]);
                $('#dialogDependencyList').modal('show');
           
            },

            centerTheDependencyModal: function () {
                var leftPosition = ($(window).width() / 2) - ($('#dialogDependencyList').width() / 2);
                var d = document.getElementById('dialogDependencyList');
                d.style.position = "absolute";
                d.style.left = 0;
                d.style.marginLeft = leftPosition + 'px';
            },

            deletePlaceholder: function(id) {

                $('#dlgGenericConfirmation .genericHeaderMesage').text(athoc.iws.placeholder.resources.UserAttributeManager_Delete_Modal_Heading); //set Header Title
                $('#dlgGenericConfirmation .genericBodyContent').text(athoc.iws.placeholder.resources.UserAttributeManager_Delete_Modal_Warning); //Set Confirmation Message
                $('#dlgGenericConfirmation').modal();
                $('#genericConfirmationOk').off('click').on('click', function(e) {
                    e.preventDefault();

                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.placeholder.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();

                    var myAjaxOptions = {
                        url: athoc.iws.placeholder.urls.DeletePlaceholderUrl,
                        type: "POST",
                        contentType: 'application/json',
                        dataType: 'json',
                        async: false,
                        data: JSON.stringify({ 'placeholderId': id })
                    };
                    var onError = function(errorResult) {
                        $.AjaxLoader.hideLoader();
                    };
                    var onSuccess = function(data, textStatus, jqXHR) {
                        if (data && data.Success && data.Success === true) {
                            $('#dlgGenericConfirmation').modal('hide');
                            athoc.iws.placeholder.viewAttributeList(true);
                        } else {
                            //show the error/validation.
                            $('#dlgGenericConfirmation').modal('hide');
                            $('#AttributeEditMessagePanel').messagesPanel('reset');
                            var messagePanel = $('#AttributeEditMessagePanel').messagesPanel({ messages: data.Messages });
                            $('html, body').animate({
                                scrollTop: $('#AttributeEditMessagePanel').offset().top - 175
                            }, 500);
                        }
                        $.AjaxLoader.hideLoader();
                    }
                    var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                    $.ajax(ajaxOptions);
                    $.AjaxLoader.hideLoader();
                });
            },

            OnDataBound: function () {

                if (this.dataSource.group().length > 0) {
                    var firstGroup = $(".k-grouping-row").first();
                    this.collapseGroup(firstGroup);
                }

                //if (this.dataSource.group().length > 0) {
                //    var GrpList = $(".k-grouping-row");

                //    for (var i = 0; i < GrpList.length; i++) {
                //        var firstGroup = GrpList[i];
                //        if (firstGroup) {
                //            this.collapseGroup(firstGroup);
                //        }
                //    }
                //}
            }
        }
    }();
}
///#source 1 1 /Scripts/Settings/athoc.iws.Placeholder.Details.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.placeholder = athoc.iws.placeholder || {};

if (athoc.iws.placeholder) {
    window.onbeforeunload = function (event) {
        var isModified = athoc.iws.placeholder.details.editmodel.isRefresh();
        if (isModified) {
            return athoc.iws.placeholder.details.resources.Unsaved_Data_Text;
        } else {
            $(window).scrollTop(0);
        }
    },
    // Enable/disable controls in all browsers
    ko.bindingHandlers['CustomEnable'] = (function () {
        return {
            init: function (element, valueAccessor) {
                var $element = $(element);
                var value = ko.utils.unwrapObservable(valueAccessor());
                if (value)
                    $element.removeAttr("disabled");
                else
                    $element.attr("disabled", true);

            },
            update: function (element, valueAccessor) {
                var value = ko.utils.unwrapObservable(valueAccessor());
                var $element = $(element);
                if (value)
                    $element.removeAttr("disabled");
                else
                    $element.attr("disabled", true);

            }
        };
    }()),
    athoc.iws.placeholder.details = function () {
        var dataedit;
        var ihierarchytype;
        var saveelist = new Array();
        var flag = 0;
        var isSearchTextFound = 0;

        return {
            parameters: null,
            isNew: false,
            isChanged: false,
            specialCharacter: "^[^<>]+$", // & added after code review from Santhosh
            viewModel: {
                placeholder: ko.observable()
            },
            pickListArray: [],
            pickListImportValuesArray: [],
            pickListgrid: null,
            currPickListUid: null,
            ImportModel: {
                successCount: ko.observable(),
                failedCount: ko.observable(),
            },
            picklistObject: function (id, order, name, defaultOption, commonName) {
                this.Id = id;
                this.Order = order;
                this.pickListName = name;
                this.Default = defaultOption;
                this.pickListCommonName = commonName == undefined ? "" : commonName;
                return this;
            },
            oldAttributeName: '',
            oldPickListName: '',
            selectedMap: 0,
            // Attirbute Model that is used to get and save the attribute details
            // TODO: This may be changed while doing retrive or save functionality
            placeholderModel: {
                Id: ko.observable(),
                Name: ko.observable(),
                AttributeType: ko.observable(),
                AttributeTypeId: ko.observable(),
                AttributeOrigin: ko.observable(),
                CommonName: ko.observable(),
                OldCommonName: ko.observable(),
                LinesToShow: ko.observable("3"),
                DefaultText: ko.observable(),
                UserCanUpdate: ko.observable(true),// This is dependent on EditLevel if it is checked EditLevel=3 or EditLevel=2
                IsMandatory: ko.observable(false),
                UserDetailsSectionName: ko.observable(),
                SelfServiceSectionName: ko.observable(),
                AvailableForReporting: ko.observable(),
                ReportName: ko.observable(),
                Description: ko.observable(),
                MaxValue: ko.observable("400"),
                MinValue: ko.observable("1"),
                DefaultValue: ko.observable(),
                SupportsHistory: ko.observable(),
                PickListValues: ko.observableArray([]),
                IconId: ko.observable(),
                CreatedBy: ko.observable(),
                CreatedDate: ko.observable(),
                UpdatedBy: ko.observable(),
                UpdatedDate: ko.observable(),
                UserDetailsSectionNames: ko.observableArray([]),
                SelfServiceSectionNames: ko.observableArray([]),
                EarliestAllowedDate: ko.observable(),  // To hold the selected date
                LatestAllowedDate: ko.observable(),
                EditLevel: ko.observable(),
                SearchAllowed: ko.observable(),
                DisplayDropdown: ko.observable("N"), // I don’t think we have UI for this. We need to figure this out, for now set it to ‘N’
                IsStandard: ko.observable(), // This is for out of the box attributes only . Always N for attributes created on other VPSes
                IsSystem: ko.observable(), // Is only for system level attributes (VPS 3) – IT should be Yes or NO
                EntityId: ko.observable("PLACEHOLDER"),
                IsEditable: ko.observable(true),
                DupAttributeName: ko.observable(),
                CommonNameDup: ko.observable(),
                PickListValuesCSV: ko.observable(),//Added this property to map PickListValuesCSV
                LocaleCode: ko.observable(),
                ProviderId: ko.observable(),
                IsGridEditing: ko.observable(),
            },
            editmodel: { nodemodel: ko.observable(), isAdd: ko.observable(true), isDelete: ko.observable(false), isRefresh: ko.observable(false), isCollapse: ko.observable(true), sTitle: ko.observable("") },

            // Breadcrumb model to display breadcrumb
            breadCrumbModel: {
                attributeText: ko.observable(),
                isDeletable: ko.observable(false),
                isStandardAttribute: ko.observable(false),
                gotoList: function () {
                    var isModified = athoc.iws.placeholder.details.isChanged;
                    if (isModified == true) {
                        var confirmLeave = confirm(athoc.iws.placeholder.details.resources.UserAttributeManager_Unsaved_Data_Text);
                        if (confirmLeave == true) {
                            athoc.iws.placeholder.details.isChanged = false;
                            athoc.iws.placeholder.details.gotoPlaceholder();
                        }
                    }
                    else {
                        athoc.iws.placeholder.details.gotoPlaceholder();
                    }
                    //window.location.href = athoc.iws.placeholder.details.urls.IndexUrl + "/";
                },
                gotoSettings: function () {
                    window.location.href = "/client/setup/settings";
                },
            },

            init: function (args) {
                this.parameters = args;

                // Button Even Handlers
                $('#btnDelete').off('click').on('click', (function () {
                    athoc.iws.placeholder.details.checkForDependencies(athoc.iws.placeholder.details.placeholderModel.Id());
                }));

            },

            handleError: function (e) {

                if (e != undefined && e.status == 401 || e.status == "error") {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else if (e.errorThrown != undefined && e.errorThrown != "") {
                    if (athoc.iws.placeholder.details.errors === null) {
                        athoc.iws.placeholder.details.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.placeholder.details.errors.push({ Type: '4', Value: e.errorThrown });
                    }

                    athoc.iws.placeholder.details.showErrorMessage(this.errors);
                } else if (e.responseText != undefined && e.responseText != "") {
                    athoc.iws.placeholder.details.showErrorMessage(e.responseText);
                }
            },
            //Path Attribute Tree d
            load: function (id, organization) {
                $(document).scrollTop(0);
                $("#userList").selectpicker();
                $("#selfServiceList").selectpicker();
                athoc.iws.placeholder.details.getDetails(id, organization);
                athoc.iws.placeholder.details.collapsePanel();
                athoc.iws.placeholder.details.subscribeAttributeChanges();

                if (athoc.iws.placeholder.details.isNew == "True")
                    $("#btnCancel").removeClass('hide');
                if (this.placeholderModel.IsStandard() == 'Y') {
                    $("#btnReset").removeClass('btn-info');
                    $("#btnReset").addClass('btn-primary');
                    $("#btnSave").addClass("hide");
                }
                else {
                    $("#btnSave").removeClass("hide");
                    $("#btnReset").removeClass('btn-primary');
                    $("#btnReset").addClass('btn-info');
                }

                //in case of attribute Checkbox,Multipicklist,singlepick list need to show the Report section
                if (this.placeholderModel.AttributeTypeId() == 6 || this.placeholderModel.AttributeTypeId() == 7 || this.placeholderModel.AttributeTypeId() == 8)
                    $("#dvReportSection").removeClass('hide');

                athoc.iws.placeholder.details.bindControlEvent();

                //Method to handle save button actions                
                $("#btn_Save").click(function () {
                    athoc.iws.placeholder.details.isInEdit = false;
                    athoc.iws.placeholder.details.hideErrorMessage();
                    $("#txtSearch").val('');
                    $("#btn_search").attr("disabled", true);
                    //Save the changes and close the model popup 
                    athoc.iws.placeholder.details.SaveDetails();

                });
                /////End of Tree
                $("#txtAttributeName").focus();
            },

            //Method to clear the panel
            ClearPanel: function () {
                $("#update").css("display", "none");
                $("#information").css("display", "");
            },
            //
            moveCursorToEnd: function moveCursorToEnd(el) {
                window.setTimeout(function () {
                    if (typeof el.selectionStart == "number") {
                        el.selectionStart = el.selectionEnd = el.value.length;
                    } else if (typeof el.createTextRange != "undefined") {
                        var range = el.createTextRange();
                        range.collapse(false);
                        range.select();
                    }
                }, 1);
            },
            //
            bindControlEvent: function () {
                $("#ancExportValue").kendoButton({
                    click: function (e) {
                        var grid = $("#optionsGrid").getKendoGrid();
                        var rows = "";
                        var trs = $("#optionsGrid").find('tr');
                        for (var i = 1; i < trs.length; i++) {
                            var dataItem = grid.dataItem(trs[i]);
                            rows += '"' + dataItem.pickListName + '"';
                            rows += '\n';
                        }
                        var vpsDateTime = $.vpsTimeZone.CurrentVPSDate.toLocaleDateString().replace("/", "");
                        // TODO
                        var CSVfileName = "Athoc-IWS_" + athoc.iws.placeholder.details.placeholderModel.AttributeOrigin() + "_PlaceholderExport_" + vpsDateTime.replace("/", "").replace(":", "") + ".csv";

                        var blob = new Blob([rows], { type: 'text/csv;charset=utf-8' });
                        saveAs(blob, CSVfileName);
                    }

                });

                $("#btnExcelExport").kendoButton({
                    click: function () {
                        $("#placeholderDependencyList").getKendoGrid().saveAsExcel();
                    }
                });
                $("#btnPLDeleteExcelExport").kendoButton({
                    click: function () {
                        $("#pLDeleteDependencyList").getKendoGrid().saveAsExcel();
                    }
                });
                $("#btnCancel").click(function () {
                    var isModified = athoc.iws.placeholder.details.isChanged;
                    if (isModified == true) {
                        var confirmLeave = confirm(athoc.iws.placeholder.details.resources.UserAttributeManager_Unsaved_Data_Text);
                        if (confirmLeave == true) {
                            athoc.iws.placeholder.details.isChanged = false;
                            athoc.iws.placeholder.details.gotoPlaceholder();
                        }
                    }
                    else {
                        athoc.iws.placeholder.details.gotoPlaceholder();
                    }
                });

                $("#btnReset").click(function () {
                    var isModified = athoc.iws.placeholder.details.isChanged;
                    if (isModified == true) {
                        var confirmLeave = confirm(athoc.iws.placeholder.details.resources.UserAttributeManager_Unsaved_Data_Text);
                        if (confirmLeave == true) {
                            athoc.iws.placeholder.details.isChanged = false;
                            athoc.iws.placeholder.details.gotoPlaceholder();
                        }
                    }
                    else {
                        athoc.iws.placeholder.details.gotoPlaceholder();
                    }
                });
                //onblur event of Name textbox to update the common name conditionally
                $("#txtAttributeName").blur(function () {
                    if (athoc.iws.placeholder.details.placeholderModel.Name() != "" && athoc.iws.placeholder.details.placeholderModel.Name() != undefined) {
                        if (athoc.iws.placeholder.details.isNew == "True") {
                            if (athoc.iws.placeholder.details.placeholderModel.CommonName() == undefined || athoc.iws.placeholder.details.placeholderModel.CommonName() == "")
                                athoc.iws.placeholder.details.placeholderModel.CommonName($.trim(athoc.iws.placeholder.details.placeholderModel.Name()).split(' ').join('-'));
                        }
                        if (athoc.iws.placeholder.details.isNew == "False" && (athoc.iws.placeholder.details.placeholderModel.CommonName() == undefined ||
                            athoc.iws.placeholder.details.placeholderModel.CommonName() == ""))
                            athoc.iws.placeholder.details.placeholderModel.CommonName($.trim(athoc.iws.placeholder.details.placeholderModel.Name()).split(' ').join('-'));

                        if (athoc.iws.placeholder.details.placeholderModel.Name() != "" && athoc.iws.placeholder.details.oldAttributeName.toUpperCase() == $.trim(athoc.iws.placeholder.details.placeholderModel.CommonName()).toUpperCase())
                            athoc.iws.placeholder.details.placeholderModel.CommonName($.trim(athoc.iws.placeholder.details.placeholderModel.Name()).split(' ').join('-'));
                        athoc.iws.placeholder.details.oldAttributeName = $.trim(athoc.iws.placeholder.details.placeholderModel.Name());
                        $("#commonName").attr('tabindex', 101);
                        $("#commonName").focus();
                    }
                });

                //onblur event of CommonName textbox to update the common name conditionally
                $("#commonName").blur(function () {
                    if (athoc.iws.placeholder.details.placeholderModel.CommonName() != undefined && athoc.iws.placeholder.details.placeholderModel.CommonName() != "") {
                        athoc.iws.placeholder.details.placeholderModel.CommonName($.trim($("#commonName").val()).split(' ').join('-'));
                        if (athoc.iws.placeholder.details.isNew == "True") {
                            if (athoc.iws.placeholder.details.placeholderModel.CommonName() != undefined && athoc.iws.placeholder.details.placeholderModel.CommonName() == "")
                                athoc.iws.placeholder.details.placeholderModel.CommonName($.trim(athoc.iws.placeholder.details.placeholderModel.Name()).split(' ').join('-'));
                        }

                        if (athoc.iws.placeholder.details.isNew == "False" && (athoc.iws.placeholder.details.placeholderModel.CommonName() == undefined ||
                            athoc.iws.placeholder.details.placeholderModel.CommonName() == "")) {
                            athoc.iws.placeholder.details.placeholderModel.CommonName($.trim(athoc.iws.placeholder.details.placeholderModel.Name()).split(' ').join('-'));
                        }
                    }
                });

            },
            excelExport: function (csv, e) {

                var vpsDateTime = $.vpsTimeZone.CurrentVPSDate.toLocaleDateString().replace("/", "");
                // TODO
                var CSVfileName = "Athoc-IWS_" + athoc.iws.placeholder.details.placeholderModel.AttributeOrigin() + "_PlaceholderExport_" + vpsDateTime.replace("/", "").replace(":", "") + ".csv";
                var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
                saveAs(blob, CSVfileName);
                e.preventDefault();
            },

            EnableAttribute: function () {
                $("#txtReportDescription").val($.trim($("#txtReportDescription").val()));
                if (athoc.iws.placeholder.details.placeholderModel.Id() != undefined && athoc.iws.placeholder.details.placeholderModel.AvailableForReporting() == true) {
                    if (athoc.iws.placeholder.details.placeholderModel.IsEditable() == true)
                        return true;
                    else
                        return false;
                }
                else if (athoc.iws.placeholder.details.placeholderModel.AvailableForReporting() == true && athoc.iws.placeholder.details.placeholderModel.IsEditable() == true) {
                    return true;
                } else {
                    return false;
                }

            },
            //Setting the common name automatically when name is entered only on creating  New 
            subscribeAttributeChanges: function () {

                athoc.iws.placeholder.details.placeholderModel.Name.subscribe(function (newValue) {
                    newValue = $.trim(newValue);
                    athoc.iws.placeholder.details.placeholderModel.Name(newValue);
                    $("#attrErrMsg").text(""); $("#commonNameErrMsg").text("");
                    athoc.iws.placeholder.details.isChanged = true;
                    $('#saveMessagePanel').css("display", "none");
                    if ($.trim(newValue) != "")
                        athoc.iws.placeholder.details.breadCrumbModel.attributeText(newValue);
                    else
                        athoc.iws.placeholder.details.breadCrumbModel.attributeText(athoc.iws.placeholder.details.resources.UserAttributeManager_PlaceHolder_New_PlaceHolder);


                });

                athoc.iws.placeholder.details.placeholderModel.CommonName.subscribe(function (newValue) {
                    $("#commonNameErrMsg").text(""); $("#attrErrMsg").text("");
                    $('#saveMessagePanel').css("display", "none");
                    athoc.iws.placeholder.details.commonNameValue = $.trim(newValue);
                });
                athoc.iws.placeholder.details.placeholderModel.LinesToShow.subscribe(function (newValue) {
                    $('#saveMessagePanel').css("display", "none");
                    athoc.iws.placeholder.details.isChanged = true;
                });
                athoc.iws.placeholder.details.placeholderModel.DefaultText.subscribe(function (newValue) {
                    newValue = $.trim(newValue);
                    athoc.iws.placeholder.details.placeholderModel.DefaultText(newValue);
                    $('#saveMessagePanel').css("display", "none");
                    athoc.iws.placeholder.details.isChanged = true;
                });
                athoc.iws.placeholder.details.placeholderModel.Description.subscribe(function (newValue) {
                    $('#saveMessagePanel').css("display", "none");
                    athoc.iws.placeholder.details.placeholderModel.Description($.trim(newValue));
                    athoc.iws.placeholder.details.isChanged = true;
                });
                athoc.iws.placeholder.details.placeholderModel.MinValue.subscribe(function (newValue) {
                    $('#saveMessagePanel').css("display", "none");
                    athoc.iws.placeholder.details.isChanged = true;
                });
                athoc.iws.placeholder.details.placeholderModel.MaxValue.subscribe(function (newValue) {
                    $('#saveMessagePanel').css("display", "none");
                    athoc.iws.placeholder.details.isChanged = true;
                });
                athoc.iws.placeholder.details.placeholderModel.DefaultValue.subscribe(function (newValue) {
                    newValue = $.trim(newValue);
                    athoc.iws.placeholder.details.placeholderModel.DefaultValue(newValue);
                    $('#saveMessagePanel').css("display", "none");
                    athoc.iws.placeholder.details.isChanged = true;
                    var element = $(".divLatestDate").next();
                    if (element != undefined)
                        element.children().css("margin-left", "21px");
                });

            },
            // Get attribute details based on attributeId
            getDetails: function (id, organization) {
                // For new attribute
                if (athoc.iws.placeholder.details.isNew == "True") {
                    athoc.iws.placeholder.details.pickListArray = [];
                    // If attribute type is picklist only create picklist grid
                    if (this.placeholderModel.AttributeTypeId() == 6 || this.placeholderModel.AttributeTypeId() == 7)
                        athoc.iws.placeholder.details.createOptionsGrid();
                    athoc.iws.placeholder.details.breadCrumbModel.attributeText(athoc.iws.placeholder.details.resources.UserAttributeManager_PlaceHolder_New_PlaceHolder);
                    athoc.iws.placeholder.details.breadCrumbModel.isDeletable(false);
                    $("#btnSave").removeClass("hide");
                    athoc.iws.placeholder.details.placeholderModel.AttributeType(this.replaceType(this.placeholderModel.AttributeTypeId()));
                    athoc.iws.placeholder.details.placeholderModel.AttributeOrigin($.htmlDecode(organization));
                    athoc.iws.placeholder.details.initiateBindings();
                    athoc.iws.placeholder.details.placeholderModel.IconId("601");
                }
                    // For edit attribute Note: id is AttributeId
                else {
                    athoc.iws.placeholder.details.viewAttributeDetail(id);
                }
                // Initiate DateTimePicker for Date and DateTime attribute
                if (this.placeholderModel.AttributeTypeId() == 4 || this.placeholderModel.AttributeTypeId() == 5 || this.placeholderModel.AttributeTypeId() == 11) {
                    athoc.iws.placeholder.details.initiateDatetimePicker();
                    if (!athoc.iws.placeholder.details.placeholderModel.IsEditable()) {
                        $(".icon-calendar").css({ cursor: "default" });
                        $("#latestDate").datetimepicker("disable");
                        $("#earliestDate").datetimepicker("disable");
                    }
                }
                // Load Layout section for User and SelfService
                // athoc.iws.placeholder.details.getLayoutValues();

            },
            // Bind model to controls
            initiateBindings: function () {

                athoc.iws.placeholder.details.validateControls();
                //ko.validation.init({ insertMessages: false });
                ko.validation.insertValidationMessage = function (element) {
                    var br = document.createElement("br");
                    element.appendChild(br);
                    var span = document.createElement('span');
                    span.className = "myErrorClass";
                    var inputGroups = $(element).closest(".divLatestDate"); //This is for getting Date Fields
                    if (inputGroups.length > 0) {
                        // We're in an input-group so we place the message after
                        // the group rather than inside it in order to not break the design
                        //$(span).addClass("");
                        inputGroups.className = "controls";
                        $(span).insertAfter(inputGroups);

                        //element.style.marginLeft = "180px";
                    }
                    else {
                        // The default in knockout-validation
                        element.parentNode.insertBefore(span, element.nextSibling);

                    }
                    return span;
                };

                athoc.iws.placeholder.details.viewPlaceholders();
            },
            //
            replaceType: function (val) {
                switch (val) {
                    case 1:
                        return athoc.iws.placeholder.details.resources.UserAttributeManager_Number;
                        break;
                    case 2:
                        return athoc.iws.placeholder.details.resources.UserAttributeManager_Text;
                        break;
                    case 3:
                        return athoc.iws.placeholder.details.resources.UserAttributeManager_Memo;
                        break;
                    case 4:
                        return athoc.iws.placeholder.details.resources.UserAttributeManager_Date;
                        break;
                    case 5:
                        return athoc.iws.placeholder.details.resources.UserAttributeManager_DateTime;
                        break;
                    case 6:
                        return athoc.iws.placeholder.details.resources.UserAttributeManager_Single_select_Picklist;
                        break;
                    case 7:
                        return athoc.iws.placeholder.details.resources.UserAttributeManager_Multi_select_Picklist;
                        break;
                    case 8:
                        return athoc.iws.placeholder.details.resources.UserAttributeManager_Checkbox;
                        break;
                    case 9:
                        return athoc.iws.placeholder.details.resources.UserAttributeManager_Path;
                        break;
                    case 10:
                        return athoc.iws.placeholder.details.resources.UserAttributeManager_Geolocation;
                        break;
                    case 11:
                        return athoc.iws.placeholder.details.resources.UserAttributeManager_Time;
                        break;
                }
            },
            //
            viewPlaceholders: function () {
                //ko.cleanNode($("#placeholderDetailsDiv").get(0));
                ko.applyBindings(athoc.iws.placeholder.details.placeholderModel, $("#placeholderDetailsDiv").get(0));

                //ko.cleanNode($("#navigationBar").get(0));
                ko.applyBindings(athoc.iws.placeholder.details.breadCrumbModel, $("#navigationBar").get(0));

                ko.applyBindings(athoc.iws.placeholder.details.breadCrumbModel, $("#dialogDependencyList").get(0));
                $("#placeholders-edit").removeClass("hide");
                athoc.iws.placeholder.details.IsExportEnabled();
                athoc.iws.placeholder.details.IsClearDefaultSelectionEnabled();

            },
            // Save attribute details
            saveAttribute: function () {
                $('#saveMessagePanel').html('');
                athoc.iws.placeholder.details.placeholderModel.DupAttributeName('');
                athoc.iws.placeholder.details.placeholderModel.CommonNameDup('');

                var result = ko.validation.group(athoc.iws.placeholder.details.placeholderModel, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages(true);

                    return false;
                }
                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 6 || athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 7) {
                    var pickListErrorMessage = [];
                    if (pickListgrid.dataSource._data.length <= 0 || _.filter(pickListgrid.dataSource._data, function (sd) { return sd.Default == true }).length <= 0) {
                        pickListErrorMessage.push({ Type: '4', Value: (pickListgrid.dataSource._data.length <= 0 ? athoc.iws.placeholder.details.resources.Placeholder_Placeholder_DefaultValue : athoc.iws.placeholder.details.resources.Placeholder_Placeholder_SelectDefaultValue) });
                        $('#saveMessagePanel').messagesPanel({ messages: pickListErrorMessage });
                        return false;
                    }
                }
                if (athoc.iws.placeholder.details.placeholderModel.IsGridEditing()) {
                    $("#optionsGrid .k-grid-edit-row").find(".k-grid-update").click();
                    if ($(".k-tooltip-validation").length > 0)
                        return false;
                }
                //athoc.iws.placeholder.details.placeholderModel.IsStandard("N");
                athoc.iws.placeholder.details.placeholderModel.IsSystem("N");
                if (athoc.iws.placeholder.details.placeholderModel.IsMandatory() == true && (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 6 || athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 7)) {
                    var pickListErrorMessage = [];
                    if (pickListgrid.dataSource._data.length <= 0 || _.filter(pickListgrid.dataSource._data, function (sd) { return sd.Default == true }).length <= 0) {
                        pickListErrorMessage.push({ Type: '4', Value: (athoc.iws.placeholder.details.resources.UserAttributeManager_PickList_Mandatory) });
                        $('#saveMessagePanel').messagesPanel({ messages: pickListErrorMessage });
                        return false;
                    }
                }
                athoc.iws.placeholder.details.placeholderModel.SearchAllowed("Y");
                if (athoc.iws.placeholder.details.placeholderModel.UserCanUpdate())
                    athoc.iws.placeholder.details.placeholderModel.EditLevel(3);
                else
                    athoc.iws.placeholder.details.placeholderModel.EditLevel(2);

                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 8)
                    athoc.iws.placeholder.details.placeholderModel.PickListValuesCSV("Yes,No");

                if (!athoc.iws.placeholder.details.placeholderModel.AvailableForReporting()) {
                    athoc.iws.placeholder.details.placeholderModel.ReportName("");
                    athoc.iws.placeholder.details.placeholderModel.Description("");
                }

                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 6 || athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 7) {
                    athoc.iws.placeholder.details.getPicklistValues();
                }

                var model = ko.mapping.toJS(athoc.iws.placeholder.details.placeholderModel);
                model.IsMandatory = athoc.iws.placeholder.details.placeholderModel.IsMandatory() ? "Y" : "N";
                model = _.omit(model, "UserDetailsSectionNames", "SelfServiceSectionNames");

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#placeholderDetailsDiv'), imageURL: athoc.iws.placeholder.details.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();
                var myAjaxOptions = {
                    url: athoc.iws.placeholder.details.urls.SaveAttributeUrl,
                    type: "POST",
                    contentType: 'application/json',
                    dataType: 'json',
                    async: true,
                    data: JSON.stringify({ 'model': model })
                };

                var onError = function (e) {
                    athoc.iws.placeholder.details.handleError(e);
                    $.AjaxLoader.hideLoader();
                };

                var onSuccess = function (data, textStatus, jqXHR) {
                    var messageArray = [];
                    var errorData = data.ErrorMessage;//JSON.parse(data.ErrorMessage);
                    if (data.Success == false) {
                        var attributeResourceKeys = ["Placeholder_Placeholder_Duplicate", "UserAttributeManager_Attribute_No_PlaceHolders", "UserAttributeManager_PlaceHolder_Save_Success_Message"];
                        var commonNameResourceKeys = ["UserAttributeManager_CommonName_Unique_Message", "UserAttributeManager_CommonName_No_StaticDistributionList"];
                        $.each(errorData, function (index, iVal) {
                            if (_.contains(attributeResourceKeys, iVal.Value)) {
                                athoc.iws.placeholder.details.placeholderModel.DupAttributeName((athoc.iws.placeholder.details.resources[iVal.Value]));
                                $("#attrErrMsg").removeClass("hide");
                                //messageArray.push({ Type: '4', Value: (athoc.iws.placeholder.details.resources[iVal.Value]).replace("{0}", athoc.iws.placeholder.details.placeholderModel.Name()) });
                            }
                            else if (_.contains(commonNameResourceKeys, iVal.Value)) {
                                athoc.iws.placeholder.details.placeholderModel.CommonNameDup((athoc.iws.placeholder.details.resources[iVal.Value]));
                                $("#commonNameErrMsg").removeClass("hide");
                                // messageArray.push({ Type: '4', Value: (athoc.iws.placeholder.details.resources[iVal.Value]).replace("{0}", athoc.iws.placeholder.details.placeholderModel.CommonName()) });
                            }
                            else {
                                messageArray.push({ Type: '4', Value: iVal.Value });
                            }
                            //$('#saveMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: iVal.Value }] });
                        });
                    }
                    else if (data.Success == true) {
                        messageArray.push({ Type: '8', Value: athoc.iws.placeholder.details.resources[errorData[0].Value] });
                        athoc.iws.placeholder.details.setScreenInfo(data);//Updating the screen properties after saving the attribute
                        athoc.iws.placeholder.details.placeholderModel.ReportName.isModified(false);
                        athoc.iws.placeholder.details.isChanged = false;
                    }
                    else {
                        messageArray.push({ Type: '4', Value: data.ErrorMessage[0].Value });
                    }
                    $('#saveMessagePanel').messagesPanel({ messages: messageArray });
                    //if (!data.Success) {
                    //    $('#saveMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.ErrorMessage }] });
                    //}
                    $.AjaxLoader.hideLoader();
                    $(document).scrollTop(0);
                }

                var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

                $.AjaxLoader.hideLoader();
            },

            //Updating the screen properties after saving the attribute as screen becomes in edit mode
            setScreenInfo: function (data) {
                athoc.iws.placeholder.details.isNew = "False";
                $(".bucket.bucket-toggle").removeClass('hide');//Bulk Update and info sction show on save success(Edit)
                athoc.iws.placeholder.details.breadCrumbModel.isDeletable(true);//Delete Button show on save success(Edit)
                $("#btnReset").removeClass('hide');
                $("#btnSave").removeClass("hide");
                $("#btnCancel").addClass('hide');
                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() != 9)
                    $("#btnDelete").removeClass('hide');//Delete Button show on save success
                athoc.iws.placeholder.details.placeholderModel.CreatedBy(data.UserName);
                athoc.iws.placeholder.details.placeholderModel.CreatedDate(data.CreatedOn);
                athoc.iws.placeholder.details.placeholderModel.UpdatedBy(data.UpdatedBy);
                athoc.iws.placeholder.details.placeholderModel.UpdatedDate(data.UpdatedOn);
                athoc.iws.placeholder.details.placeholderModel.Id(data.AttributeID);
                athoc.iws.placeholder.details.placeholderModel.IsEditable(data.IsEditeable);
                athoc.iws.placeholder.details.placeholderModel.OldCommonName(data.OldCommonName);
                var placeholderDetails = data.PlaceholderDetails;
                athoc.iws.placeholder.details.pickListArray = [];
                if (placeholderDetails.PickListValuesCSV == null)
                    placeholderDetails.PickListValuesCSV = "";
                if (placeholderDetails.DefaultValue == null)
                    placeholderDetails.DefaultValue = "";
                // If attribute type is picklist only create picklist grid
                if ((this.placeholderModel.AttributeTypeId() == 6 || this.placeholderModel.AttributeTypeId() == 7)) {
                    var pListStr = placeholderDetails.PickListValuesCSV;
                    var pickList = pListStr.split('<>');
                    this.placeholderModel.DefaultValue(placeholderDetails.DefaultValue);
                    _.each(pickList, function (item, index) {
                        if (item != "") {
                            var itemList = item.split("<->");
                            var defaultValue = _.find(placeholderDetails.DefaultValue.split(','), function (val) {
                                return parseInt(val) == parseInt(itemList[0]);
                            });
                            var obj = new athoc.iws.placeholder.details.picklistObject(itemList[0], index, itemList[1], defaultValue != undefined ? true : false, itemList[2]);
                            athoc.iws.placeholder.details.pickListArray.push(obj);
                        }
                    });
                    athoc.iws.placeholder.details.createOptionsGrid();
                }
            },

            // Validating model
            validateControls: function () {
                // Validate attribute name
                athoc.iws.placeholder.details.placeholderModel.Name.extend({
                    required: {
                        params: true,
                        message: athoc.iws.placeholder.details.resources.UserAttributeManager_AttributeName_Required_Message
                    },
                    maxLength: {
                        params: 200,
                        message: athoc.iws.placeholder.details.resources.Placeholder_AttributeName_MaxLength_Message
                    },
                    pattern: {
                        message: athoc.iws.placeholder.details.resources.Placeholder_AttributeName_SpecialCharacter_Message,
                        params: athoc.iws.placeholder.details.specialCharacter
                    },

                });

                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 2) {
                    // Validate linesToShow
                    athoc.iws.placeholder.details.placeholderModel.LinesToShow.extend({
                        required: {
                            params: true,
                            message: athoc.iws.placeholder.details.resources.UserAttributeManager_CommonName_Required_Message
                        },
                        pattern: {
                            message: athoc.iws.placeholder.details.resources.UserAttributeManager_Lines_To_Show_Type,
                            params: '^[0-9\-]+$',
                        },
                        min: {
                            params: 1,
                            message: athoc.iws.placeholder.details.resources.Placeholder_Lines_To_Show_Range
                        },
                        max: {
                            params: 5,
                            message: athoc.iws.placeholder.details.resources.Placeholder_Lines_To_Show_Range
                        },
                        validation: [
                                  {
                                      validator: athoc.iws.placeholder.details.validateLinesToShow,
                                      message: athoc.iws.placeholder.details.resources.Placeholder_Lines_To_Show_Range,
                                      params: [this.value]
                                  },
                        ]
                    });
                    // Vlaidate defaultValue
                    athoc.iws.placeholder.details.placeholderModel.DefaultText.extend({
                        required: {
                            params: true,
                            message: athoc.iws.placeholder.details.resources.UserAttributeManager_CommonName_Required_Message,
                            onlyIf: function () { return (athoc.iws.placeholder.details.placeholderModel.MinValue() != null) && (athoc.iws.placeholder.details.placeholderModel.MaxValue() != null); }
                        },
                        validation: [

                                     {
                                         validator: athoc.iws.placeholder.details.validatDefaultTextValue,
                                         onlyIf: function () { return (athoc.iws.placeholder.details.placeholderModel.MinValue() != null) && (athoc.iws.placeholder.details.placeholderModel.MaxValue() != null); },
                                         message: athoc.iws.placeholder.details.resources.Placeholder_DefaultText_MaxLength_Message,
                                         params: [this.value, athoc.iws.placeholder.details.placeholderModel.MaxValue(), athoc.iws.placeholder.details.placeholderModel.MinValue()]
                                     },
                        ]

                    });
                }

                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 5 || athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 4 || athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 11) {
                    athoc.iws.placeholder.details.placeholderModel.DefaultValue.extend({
                        required: {
                            params: true,
                            message: athoc.iws.placeholder.details.resources.UserAttributeManager_CommonName_Required_Message
                        }
                    });
                }

                // Validate MinValue
                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 1 || athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 2) {
                    athoc.iws.placeholder.details.placeholderModel.MinValue.extend({
                        required: {
                            params: true,
                            message: athoc.iws.placeholder.details.resources.UserAttributeManager_AttributeName_Required_Message
                        },
                        pattern: {
                            message: athoc.iws.placeholder.details.resources.UserAttributeManager_Length_Minimum_Type,
                            params: '^[0-9\-]+$',
                        },
                        validation: [
                                   {
                                       validator: athoc.iws.placeholder.details.validateMinValue,
                                       message: athoc.iws.placeholder.details.resources.Placeholder_Length_Minimum_Range,
                                       params: [this.value, 1, 400]
                                   },
                        ]
                    });

                    // Validate MaxValue
                    athoc.iws.placeholder.details.placeholderModel.MaxValue.extend({
                        required: {
                            params: true,
                            message: athoc.iws.placeholder.details.resources.UserAttributeManager_AttributeName_Required_Message
                        },
                        pattern: {
                            message: athoc.iws.placeholder.details.resources.UserAttributeManager_Length_Maximum_Type,
                            params: '^[0-9\-]+$',
                        },
                        validation: [
                                   {
                                       validator: athoc.iws.placeholder.details.validateMaxValue,
                                       message: athoc.iws.placeholder.details.resources.Placeholder_Length_Maximum_Range,
                                       params: [this.value, 1, 400]
                                   },
                                   {
                                       validator: athoc.iws.placeholder.details.validateMinMaxValues,
                                       message: athoc.iws.placeholder.details.resources.UserAttributeManager_Length_Min_Max_Combined,
                                       params: [this.value, athoc.iws.placeholder.details.placeholderModel.MaxValue(), athoc.iws.placeholder.details.placeholderModel.MinValue()]
                                   },
                        ]
                    })
                }
            },
            //
            validateLatestDateValue: function () {

                if (athoc.iws.placeholder.details.isValidDate(athoc.iws.placeholder.details.placeholderModel.EarliestAllowedDate()) && athoc.iws.placeholder.details.isValidDate(athoc.iws.placeholder.details.placeholderModel.LatestAllowedDate())) {
                    //if (moment(athoc.iws.placeholder.details.placeholderModel.EarliestAllowedDate(), $.vpsDateFormat.toUpperCase()).toDate().getTime() > moment(athoc.iws.placeholder.details.placeholderModel.LatestAllowedDate(), $.vpsDateFormat.toUpperCase()).toDate().getTime())
                    var d1 = new Date($("#edTime").val());
                    var d2 = new Date($("#ldTime").val());
                    if (d1 > d2)
                        return false;
                    //var x=moment(new Date(athoc.iws.placeholder.details.placeholderModel.EarliestAllowedDate()), athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 4 ? $.vpsDateFormat.toUpperCase() : $.vpsDateTimeFormat.toUpperCase());
                    //var y = moment(athoc.iws.placeholder.details.placeholderModel.LatestAllowedDate(), athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 4 ? $.vpsDateFormat.toUpperCase() : $.vpsDateTimeFormat.toUpperCase());
                    //if (moment($("#edTime").val(), athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 4 ? $.vpsDateFormat.toUpperCase() : $.vpsDateTimeFormat.replace('tt', 'A').toUpperCase()).toDate().getTime() > moment($("#ldTime").val(), athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 4 ? $.vpsDateFormat.toUpperCase() : $.vpsDateTimeFormat.replace('tt', 'A').toUpperCase()).toDate().getTime())
                    //    return false;
                }
                return true;
            },
            //
            isValidDate: function (val) {
                var isValid = true;
                try {
                    isValid = moment(val, $.vpsDateFormat.toUpperCase()).isValid();
                }
                catch (error) {
                    isValid = false;
                }

                return isValid;
            },

            validateMinValue: function (val) {
                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 2 && val != "" && val != undefined) {
                    this.message = athoc.iws.placeholder.details.resources.Placeholder_Length_Minimum_Range;
                    if (val > 0 && val >= this.params[1] && val <= this.params[2])
                        return true;
                    else
                        return false;
                }

                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 1 && val != "" && val != undefined) {
                    this.message = athoc.iws.placeholder.details.resources.Placeholder_Length_Minimum_Range;
                    if (val >= 0 && val <= 214783647)
                        return true;
                    else
                        return false;
                }
                return true;
            },
            //
            validateLinesToShow: function (val) {
                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 2 && val != "" && val != undefined) {
                    this.message = athoc.iws.placeholder.details.resources.Placeholder_Lines_To_Show_Range;
                    if (val > 0)
                        return true;
                    else
                        return false;
                }
                return true;
            },
            //
            validateMaxValue: function (val) {
                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 2 && val != "" && val != undefined) {
                    this.message = athoc.iws.placeholder.details.resources.Placeholder_Length_Maximum_Range;
                    if (val > 0 && val >= this.params[1] && val <= this.params[2])
                        return true;
                    else
                        return false;
                }

                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 1 && val != "" && val != undefined) {
                    this.message = athoc.iws.placeholder.details.resources.Placeholder_Length_Maximum_Range;
                    if (val >= 0 && val <= 214783647)
                        return true;
                    else
                        return false;
                }
                return true;
            },
            //
            validateMinMaxValues: function (val) {
                var min = athoc.iws.placeholder.details.placeholderModel.MinValue();
                var max = athoc.iws.placeholder.details.placeholderModel.MaxValue();
                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 2 && min != "" && max != "") {
                    this.message = athoc.iws.placeholder.details.resources.UserAttributeManager_Length_Min_Max_Combined;
                    if ((max != undefined && !isNaN(parseInt(max))) && (min != undefined && !isNaN(parseInt(min)))) {
                        if (parseInt(max) >= parseInt(min))
                            return true;
                        else
                            return false;
                    }
                    return true;
                }

                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 1 && min != "" && max != "") {
                    this.message = athoc.iws.placeholder.details.resources.UserAttributeManager_Value_Min_Max;
                    if ((max != undefined && !isNaN(parseFloat(max))) && (min != undefined && !isNaN(parseFloat(min)))) {
                        if (parseFloat(max) >= parseFloat(min))
                            return true;
                        else
                            return false;
                    }
                    return true;
                }
                return true;

            },
            //
            validatDefaultTextValue: function (val) {
                var min = athoc.iws.placeholder.details.placeholderModel.MinValue();
                var max = athoc.iws.placeholder.details.placeholderModel.MaxValue();
                if (athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 2 && min != "" && max != "") {
                    if ((max != undefined && !isNaN(parseInt(max))) && (min != undefined && !isNaN(parseInt(min)))) {
                        if (parseInt(max) >= parseInt(min))
                            if (val != null && val.length >= min && val.length <= max)
                                return true;
                            else
                                return false;
                        else
                            return false;
                    }
                    return true;
                }
                return true;
            },
            gotoPlaceholder: function () {
                window.location.href = athoc.iws.placeholder.details.urls.IndexUrl;
            },
            // Toggle the buckets
            collapsePanel: function () {
                $(this).parent().find('.expand-arrow-open').toggle();
                $('.bucket-toggle h2').click(function () {
                    $(this).parent().find('.row').slideToggle(500);
                    $(this).parent().find('.expand-arrow-open').toggle();
                    $(this).parent().find('.expand-arrow-closed').toggle();
                });
            },
            // Get Attribute datails based on attributeId
            viewAttributeDetail: function (id) {
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.placeholder.details.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();
                var placeholderDetails = null;
                var myAjaxOptions = {
                    url: athoc.iws.placeholder.details.urls.GetPlaceholderDetailstUrl,
                    type: "POST",
                    contentType: 'application/json',
                    dataType: 'json',
                    async: false,
                    data: JSON.stringify({ 'placeholderId': id })
                };

                var onError = function (e) {
                    $.AjaxLoader.hideLoader();
                    athoc.iws.placeholder.details.handleError(e);
                };

                var onSuccess = function (data, textStatus, jqXHR) {
                    if (data.Success) {
                        placeholderDetails = data.Data;
                        athoc.iws.placeholder.details.placeholderModel.IsEditable(data.IsEditeable);
                        athoc.iws.placeholder.details.breadCrumbModel.attributeText(placeholderDetails.Name);
                        athoc.iws.placeholder.details.breadCrumbModel.isDeletable(data.IsDeletable);

                        athoc.iws.placeholder.details.editPlaceholder(placeholderDetails, data.IsDeletable);
                        athoc.iws.placeholder.details.initiateBindings();
                        athoc.iws.placeholder.details.initiateDatetimePicker();

                        if (athoc.iws.placeholder.details.isNew == "False") {
                            // $("#commonName").attr("disabled", "disabled");
                            $("#btnReset").removeClass('hide');
                            $("#btnCancel").addClass('hide');
                            if (data.Data.IsStandard == 'Y')
                                $("#btnSave").addClass('hide');
                        }
                    }
                    else {
                        $.AjaxLoader.hideLoader();
                        $('#saveMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] });
                        $(document).scrollTop(0);
                    }
                    $(document).scrollTop(0);
                    $.AjaxLoader.hideLoader();
                }

                var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

                $.AjaxLoader.hideLoader();
            },
            // Get page layout section for User and SelfService
            getLayoutValues: function () {
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#placeholderDetailsDiv'), imageURL: athoc.iws.placeholder.details.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();
                var myAjaxOptions = {
                    url: athoc.iws.placeholder.details.urls.GetLayoutValues,
                    type: "POST",
                    contentType: 'application/json',
                    dataType: 'json',
                    async: false,
                    data: JSON.stringify({ 'commonName': this.placeholderModel.CommonName(), 'providerId': this.placeholderModel.ProviderId() })
                };

                var onError = function (e) {
                    athoc.iws.placeholder.details.handleError(e);
                    $.AjaxLoader.hideLoader();
                };

                var onSuccess = function (data, textStatus, jqXHR) {
                    if (data.Success) {
                        $("#userList").selectpicker('clear');
                        $("#selfServiceList").selectpicker('clear');
                        athoc.iws.placeholder.details.placeholderModel.UserDetailsSectionNames(data.UserList);
                        athoc.iws.placeholder.details.placeholderModel.SelfServiceSectionNames(data.SSList);
                        athoc.iws.placeholder.details.placeholderModel.UserDetailsSectionName(athoc.iws.placeholder.details.setLayoutValues(data.UserList));
                        athoc.iws.placeholder.details.placeholderModel.SelfServiceSectionName(athoc.iws.placeholder.details.setLayoutValues(data.SSList));

                        $("#userList").selectpicker('refresh');
                        $("#selfServiceList").selectpicker('refresh');
                        $.AjaxLoader.hideLoader();
                    }
                }

                var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

                $.AjaxLoader.hideLoader();
            },
            // Get selected layout value
            setLayoutValues: function (list) {
                var val = "0";
                _.each(list, function (item, index) {
                    if (item.IsSelected)
                        val = item.Name;
                    if (item.Children.length > 0) {
                        _.each(item.Children, function (child, index) {
                            if (child.IsSelected)
                                val = child.Name;
                        });
                    }
                });
                return val;
            },
            //Fill datepickers to default values
            initiateDatetimePicker: function () {
                var momentdateformat = this.getVPSTimeFormat('momentdateformat');
                var momentdatetimeformat = this.getVPSTimeFormat('momentformat');
                var momenttimeformat = this.getVPSTimeFormat('momenttimeformat');
                $('#defaultDate').datetimepicker({
                    pickDate: (this.placeholderModel.AttributeTypeId() == 4 || this.placeholderModel.AttributeTypeId() == 5) ? true : false,
                    pickTime: (this.placeholderModel.AttributeTypeId() == 5 || this.placeholderModel.AttributeTypeId() == 11) ? true : false,
                    startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleDateString(), 'MM/DD/YYYY')),
                    language: $.culture,
                    format: this.placeholderModel.AttributeTypeId() == 4 ? $.vpsDateFormat : $.vpsDateTimeFormat.replace('tt', 'A')
                }).on('changeDate', function (ev) {
                    if (ev.localDate != null) {
                        var newDate = moment(ev.localDate).format(athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 5 ? momentdatetimeformat : momentdateformat);
                        athoc.iws.placeholder.details.placeholderModel.DefaultValue(newDate);
                    }
                });
                $('#defaultime').datetimepicker({
                    pickDate: false,
                    pickTime: true,
                    pick12HourFormat: $.vpsDateTimeFormat.indexOf('tt') > 0 ? true : false,
                    pickSeconds: false,
                    language: $.culture,
                    startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleString(), $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP")))),
                    format: $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP"))
                }).on('changeDate', function (ev) {
                    if (ev.localDate != null) {
                        var newDate = moment(ev.localDate).format(momenttimeformat);
                        athoc.iws.placeholder.details.placeholderModel.DefaultValue(newDate);
                    }
                });

            },
            //
            getVPSTimeFormat: function (formatType) {
                var timeFormat;
                var meridianFormat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? " A" : "";
                var secondsIncluded = $.vpsDateTimeFormat.indexOf('ss') > 0 ? ":ss" : "";
                var dateFormat;
                switch (formatType) {

                    case "timeformat":
                        timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP").replace("hh", "hh"));
                        return timeFormat;

                    case "dateformat":
                        dateFormat = $.vpsDateFormat;
                        return dateFormat;

                    case "momenttimeformat":
                        if (meridianFormat == "")
                            timeFormat = "HH:mm" + secondsIncluded;
                        else
                            timeFormat = "hh:mm" + secondsIncluded + meridianFormat;
                        return timeFormat;

                    case "momentdateformat":
                        dateFormat = $.vpsDateFormat.toUpperCase();
                        return dateFormat;
                    case "momentformat":
                        dateFormat = $.vpsDateFormat.toUpperCase();
                        if (meridianFormat == "")
                            timeFormat = "HH:mm" + secondsIncluded;
                        else
                            timeFormat = "hh:mm" + secondsIncluded + meridianFormat;

                        return dateFormat + ' ' + timeFormat;

                }
            },
            // Edit user attribute
            editPlaceholder: function (placeholderDetails, isDeletable) {
                $('#AttributeEditMessagePanel').messagesPanel('reset');
                if (isDeletable == true)
                    $("#btnDelete").removeClass('hide');

                //Making BulkUpdate and info section visible on edit only
                $(".bucket.bucket-toggle").removeClass('hide');

                if (placeholderDetails.IsStandard != "Y")
                    $("#bulk").removeClass('hide');
                else
                    $("#bulk").addClass('hide');

                if (placeholderDetails.IsStandard == "Y" && placeholderDetails.ProviderId == 3) {
                    $("#valuesPanel").addClass('hide');
                    $("#valuePanelDefult").addClass('block');
                    // Remove
                    $("#valuesPanel").removeClass('block');
                    $("#valuePanelDefult").removeClass('hide');

                }
                else {
                    $("#valuesPanel").addClass('block');
                    $("#valuePanelDefult").addClass('hide');
                    // Remove
                    $("#valuesPanel").removeClass('hide');
                    $("#valuePanelDefult").removeClass('block');
                }

                // Copy values to model
                if (placeholderDetails) {
                    this.placeholderModel.IsStandard(placeholderDetails.IsStandard);
                    this.placeholderModel.Id(placeholderDetails.Id);
                    this.placeholderModel.ProviderId(placeholderDetails.ProviderId);
                    this.placeholderModel.LocaleCode(placeholderDetails.LocaleCode);
                    this.placeholderModel.AttributeType(this.replaceType(placeholderDetails.AttributeTypeId));
                    this.placeholderModel.AttributeTypeId(placeholderDetails.AttributeTypeId);
                    this.placeholderModel.Name(placeholderDetails.Name);
                    athoc.iws.placeholder.details.oldAttributeName = placeholderDetails.Name;
                    this.placeholderModel.CommonName(placeholderDetails.CommonName);
                    this.placeholderModel.OldCommonName(placeholderDetails.OldCommonName);
                    this.placeholderModel.AttributeOrigin($.htmlDecode(placeholderDetails.AttributeOrigin));
                    this.placeholderModel.DefaultText(placeholderDetails.DefaultText);
                    this.placeholderModel.UserCanUpdate(placeholderDetails.EditLevel == "3" ? true : false);
                    this.placeholderModel.LinesToShow(placeholderDetails.LinesToShow);
                    this.placeholderModel.IsMandatory(placeholderDetails.IsMandatory == "Y" ? true : false);
                    // For Attribute Type is Text and Number
                    if (this.placeholderModel.AttributeTypeId() == 1 || this.placeholderModel.AttributeTypeId() == 2) {
                        this.placeholderModel.MaxValue(placeholderDetails.MaxValue != null ? placeholderDetails.MaxValue.toString() : "");
                        this.placeholderModel.MinValue(placeholderDetails.MinValue != null ? placeholderDetails.MinValue.toString() : "");
                        this.placeholderModel.DefaultValue(placeholderDetails.DefaultValue);
                    }
                    // For Attribute Type is GeoGraphy
                    if (this.placeholderModel.AttributeTypeId() == 10) {
                        this.placeholderModel.IconId(placeholderDetails.IconId == null ? "601" : placeholderDetails.IconId);
                        this.placeholderModel.SupportsHistory(placeholderDetails.SupportsHistory == "Y" ? true : false);
                    }
                    // For Attribute Type is Checkbox
                    if (this.placeholderModel.AttributeTypeId() == 8) {
                        this.placeholderModel.DefaultValue(placeholderDetails.DefaultValue == "Yes" ? true : false);
                    }

                    if (this.placeholderModel.AttributeTypeId() == 6 || this.placeholderModel.AttributeTypeId() == 7 || this.placeholderModel.AttributeTypeId() == 8) {
                        this.placeholderModel.ReportName(placeholderDetails.ReportName);
                        this.placeholderModel.Description(placeholderDetails.Description);
                        this.placeholderModel.DefaultValue(placeholderDetails.DefaultValue);
                        if ((placeholderDetails.ReportName != null && placeholderDetails.ReportName != "") || (placeholderDetails.Description != null && placeholderDetails.Description != ""))
                            this.placeholderModel.AvailableForReporting(true);
                        else
                            this.placeholderModel.AvailableForReporting(false);
                    }
                    // For Attribute Type is Date and DateTime
                    if (this.placeholderModel.AttributeTypeId() == 4 || this.placeholderModel.AttributeTypeId() == 5) {
                        athoc.iws.placeholder.details.placeholderModel.DefaultValue(placeholderDetails.DefaultValue);
                    }

                    // For Attribute Type is Time
                    if (this.placeholderModel.AttributeTypeId() == 11) {
                        athoc.iws.placeholder.details.placeholderModel.DefaultValue(placeholderDetails.DefaultValue);
                    }

                    this.placeholderModel.UpdatedBy(placeholderDetails.UpdatedBy);
                    this.placeholderModel.UpdatedDate(placeholderDetails.UpdatedOn);

                    this.placeholderModel.CreatedBy(placeholderDetails.CreatedBy);
                    this.placeholderModel.CreatedDate(placeholderDetails.CreatedOn);
                }
                if (placeholderDetails.PickListValuesCSV == null)
                    placeholderDetails.PickListValuesCSV = "";
                if (placeholderDetails.DefaultValue == null)
                    placeholderDetails.DefaultValue = "";
                // If attribute type is picklist only create picklist grid
                if ((this.placeholderModel.AttributeTypeId() == 6 || this.placeholderModel.AttributeTypeId() == 7)) {
                    var pListStr = placeholderDetails.PickListValuesCSV;
                    var pickList = pListStr.split('<>');
                    this.placeholderModel.DefaultValue(placeholderDetails.DefaultValue);
                    _.each(pickList, function (item, index) {
                        if (item != "") {
                            var itemList = item.split("<->");
                            var defaultValue = _.find(placeholderDetails.DefaultValue.split(','), function (val) {
                                return parseInt(val) == parseInt(itemList[0]);
                            });
                            var obj = new athoc.iws.placeholder.details.picklistObject(itemList[0], index, itemList[1], defaultValue != undefined ? true : false, itemList[2]);
                            athoc.iws.placeholder.details.pickListArray.push(obj);
                        }
                    });
                    athoc.iws.placeholder.details.createOptionsGrid();
                    if (!athoc.iws.placeholder.details.placeholderModel.IsEditable()) {
                        $("#optionsGrid [id='plDelete']").attr("disabled", "disabled");
                        $("#optionsGrid [id='plDelete']").append().css("pointer-events", "none");
                        $("#plDelete, #plDelete .close").not(".k-grid-edit-row").css({ cursor: "Default", textDecoration: "none", "pointer-events": "none" });
                    }

                }
            },
            // Creating picklist grid
            createOptionsGrid: function () {
                var dataSource = new kendo.data.DataSource({
                    data: athoc.iws.placeholder.details.pickListArray,
                    schema: {
                        model: {
                            id: "Id",
                            fields: {
                                Id: { editable: false, nullable: false },
                                Order: { type: "int", editable: false },
                                pickListName: {
                                    type: "string",
                                    validation: {
                                        pickListNameCheckLength: function (input) {
                                            if (input.is("[name='pickListName']") && $.trim(input.val()) != "") {
                                                input.attr("data-pickListNameCheckLength-msg", athoc.iws.placeholder.details.resources.UserAttributeManager_PickList_OptionLabel_Min);
                                                return input.val().length <= 200;
                                            }
                                            return true;
                                        },
                                        nameSpecialCharacters: function (input) {
                                            if (input.is("[name='pickListName']") && $.trim(input.val()) != "") {
                                                var msg = athoc.iws.placeholder.details.resources.Placeholder_PickList_SpecialChars.replace('`!$%&^()={},;\\:?\"<>|', '<>');
                                                input.attr("data-nameSpecialCharacters-msg", msg);

                                                var temp = (!(input.val().indexOf("<") >= 0 || input.val().indexOf(">") >= 0));
                                                return temp;
                                            }
                                            return true;
                                        },
                                        nameEmptyName: function (input) {
                                            if ($.trim(input.val()) == "" && input.is("[name='pickListName']")) {
                                                input.attr("data-nameEmptyName-msg", athoc.iws.placeholder.details.resources.UserAttributeManager_PickList_OptionLabel_Required);
                                                athoc.iws.placeholder.details.oldPickListName = "";
                                                return false;
                                            }
                                            return true;
                                        },
                                        validateDuplicate: function (input) {
                                            if (input.is("[name='pickListName']") && $.trim(input.val()) != "") {
                                                input.attr("data-validateDuplicate-msg", athoc.iws.placeholder.details.resources.UserAttributeManager_PickList_OptionLabel_Duplicate);
                                                var category = _.find(pickListgrid.dataSource._data, function (pickList) {
                                                    return (pickList.uid != athoc.iws.placeholder.details.currPickListUid) && (pickList.pickListName.toUpperCase() == $.trim(input.val().toUpperCase()));
                                                });
                                                if (category != null && $("#optionsGrid").data("kendoGrid").dataSource.total() > 1) {
                                                    athoc.iws.placeholder.details.oldPickListName = $.trim($(input.closest('tr')).find('[name="pickListName"]').val());
                                                    return false;
                                                }
                                            }
                                            return true;
                                        },
                                    }
                                },
                                pickListCommonName: { type: "string", editable: false },
                                Default: { type: "boolean" }
                            }
                        }
                    }
                });

                pickListgrid = $("#optionsGrid").kendoGrid({
                    //excel: {
                    //    fileName: "Placeholder Values List.csv",
                    //    allPages: true,
                    //    filterable: false,
                    //    proxyURL: athoc.iws.placeholder.details.urls.ExportValuesUrl,
                    //    forceProxy: true,
                    //},
                    //excelExport: function (e) {
                    //    optionsGrid
                    //    var sheet = e.workbook.sheets[0];
                    //    for (var i = 0; i < sheet.columns.length; i++) {
                    //        sheet.columns[i].autoWidth = false;
                    //    }
                    //},
                    dataSource: dataSource,
                    scrollable: false,
                    navigatable: false,
                    sortable: false,
                    columns: [
                        {
                            field: "Id"
                            , hidden: true
                        },
                        { field: "Order", hidden: true },
                        {
                            width: 100,
                            sortable: false,
                            headerTemplate: kendo.format('<div title="{0}" align="center">{1}</div>', athoc.iws.placeholder.details.resources.UserAttributeManager_PickList_Drag_Message, athoc.iws.placeholder.details.resources.UserAttributeManager_PickList_Drag_Title),
                            headerAttributes: { "class": "no-pointer" },
                            template: '<div align="center"><span id="rowNum"></span><span class="icon-drag-row" style="cursor: move"></div>'
                            , hidden: true
                        },
                        {

                            field: "pickListName",
                            //title: "Option Label",
                            headerTemplate: kendo.format('<span class="cellTooltip" title="{0}">{1}</span>', athoc.iws.placeholder.details.resources.Placeholder_PickList_OptionLabel_Title, athoc.iws.placeholder.details.resources.Placeholder_PickList_OptionLabel_Title),
                            template: '<div class="cellTooltip width610 ellipsis" title="#=$.htmlEncode(pickListName)#">#=$.htmlEncode(pickListName)#</div>',
                        },
                          { field: "pickListCommonName", hidden: true },
                        {
                            width: 100,
                            field: "Default",
                            // title: "Default",
                            sortable: false,
                            headerTemplate: kendo.format('<span class="cellTooltip" title="{0}">{1}</span>', athoc.iws.placeholder.details.resources.UserAttributeManager_PickList_Default_Title, athoc.iws.placeholder.details.resources.UserAttributeManager_PickList_Default_Title),
                            template: $("#default-template").html(), //"#= Default === true ? 'Yes' : 'No' #",
                            //editor: '<input name="radiogroup" type="radio" #= Default ? \'checked="checked"\' : "" #/>'
                            editor: radioEditor,
                            attributes: { class: "text-center" }
                        },
                        {
                            width: 148,
                            attributes: { class: "text-center" },
                            command: [
                                {
                                    name: "edit",
                                    text: "",
                                    template: "<span><a class='k-grid-edit' id='plEdit' title='" + athoc.iws.placeholder.details.resources.UserAttributeManager_PickList_Edit_Title + "' href=''><span class='icon-edit-row'></span></a></span>"
                                },
                                {
                                    name: "Delete",
                                    text: "",
                                    template: "<a class='' id='plDelete' title='" + athoc.iws.placeholder.details.resources.UserAttributeManager_PickList_Delete_Title + "' href=''><span class='close mar-top3 mar-left20 no-float'>x</span></a>",
                                }
                            ]
                        }
                    ],
                    editable: {
                        createAt: "bottom",
                        mode: "inline"
                    },
                    edit: function (e) {
                        $('#saveMessagePanel').html("");
                        athoc.iws.placeholder.details.isChanged = true;
                        athoc.iws.placeholder.details.currPickListUid = e.model.uid;
                        if (e.model.Default === true)
                            e.container.find("input[id='defaultId']")[0].checked = true;
                        else
                            e.container.find("input[id='defaultId']")[0].checked = false;
                        athoc.iws.placeholder.details.placeholderModel.IsGridEditing(true);
                        athoc.iws.placeholder.details.oldPickListName = e.model.pickListName;



                    },
                    save: function (e) {
                        athoc.iws.placeholder.details.isChanged = true;
                        var defaultVal = e.container.find("input[id='defaultId']")[0].checked;
                        var name = e.container.find("input[name='pickListName']")[0].value.trim();
                        //e.container.find("input[name='pickListCommonName']")[0].value = e.container.find("input[name='pickListCommonName']")[0].value.toUpperCase();
                        //var commonName = " ";
                        $(".k-grid-edit").parent().append().css("pointer-events", "auto");
                        $(".k-grid tr,#plEdit .k-grid-edit, #plDelete, #plDelete .close, .icon-drag-row, #ancAddAnohterValue,#ancImportValue").css({ cursor: "pointer", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });
                        var currentObj = e.model;
                        currentObj.pickListName = name;
                        //currentObj.pickListCommonName = commonName;
                        var match = _.find(athoc.iws.placeholder.details.pickListArray, function (item) {
                            return item.Id === (currentObj.Id == "" ? currentObj.uid : currentObj.Id);
                        });

                        if (match) {
                            match.pickListName = name;
                            //match.pickListCommonName = commonName;
                            match.Default = defaultVal;
                        } else {
                            match = new athoc.iws.placeholder.details.picklistObject(currentObj.uid, currentObj.Order, name, defaultVal, currentObj.pickListCommonName);
                            athoc.iws.placeholder.details.pickListArray.push(match);
                        }

                        if (defaultVal === true && athoc.iws.placeholder.details.placeholderModel.AttributeTypeId() == 6) {
                            $.each(pickListgrid.dataSource._data, function (index, item) {
                                pickListgrid.dataSource._data[index].set("Default", false);
                                athoc.iws.placeholder.details.pickListArray[index].Default = false;
                            });
                        }

                        e.model.Default = defaultVal;
                        match.Default = defaultVal;
                        athoc.iws.placeholder.details.placeholderModel.IsGridEditing(false);
                        $("#ancAddAnohterValue").focus();
                        pickListgrid.refresh();
                        athoc.iws.placeholder.details.IsExportEnabled();
                        athoc.iws.placeholder.details.IsClearDefaultSelectionEnabled();
                    },
                    cancel: function (e) {

                        var match = _.find(athoc.iws.placeholder.details.pickListArray, function (item) {
                            return item.Id === (e.model.Id == "" ? e.model.uid : e.model.Id);
                        });
                        if (match) {
                            e.model.pickListName = match.pickListName;
                            e.model.pickListCommonName = match.pickListCommonName;
                            e.model.Default = match.Default;
                        }
                        else {
                            pickListgrid.dataSource.remove(e.model);
                        }
                        athoc.iws.placeholder.details.placeholderModel.IsGridEditing(false);
                        pickListgrid.refresh();
                        $(".k-grid-edit").parent().append().css("pointer-events", "auto");
                        $(".k-grid tr,#plEdit .k-grid-edit, #plDelete, #plDelete .close, .icon-drag-row, #ancAddAnohterValue,#ancImportValue").css({ cursor: "pointer", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });
                        $("#ancAddAnohterValue").focus();

                        // e.preventDefault();
                    },
                    dataBound: athoc.iws.placeholder.details.onDataBound,

                }).data("kendoGrid");

                function radioEditor(container, options) {
                    var input = $("<input/>");
                    input.attr("name", options.field);
                    input.attr("id", "defaultId");
                    input.attr("type", "checkbox");
                    input.appendTo(container);
                }
                pickListgrid.table.kendoSortable({
                    filter: ">tbody >tr",
                    handler: ".icon-drag-row",
                    cursor: "move",
                    ignore: "TD, input",
                    hint: $.noop,
                    disabled: ".disabled",
                    start: function (e) {
                        if (athoc.iws.placeholder.details.placeholderModel.IsGridEditing()) {
                            e.preventDefault();
                        }
                    },
                    placeholder: function (element) {
                        return element.clone().addClass("k-state-hover").css("opacity", 0.65);
                    },
                    cursorOffset: {
                        top: -10,
                        left: -230
                    },
                    container: "#optionsGrid tbody",
                    change: function (e) {
                        $('#saveMessagePanel').html("");
                        var dataItem = pickListgrid.dataSource.getByUid(e.item.data("uid"));
                        pickListgrid.dataSource.remove(dataItem);
                        pickListgrid.dataSource.insert(e.newIndex, dataItem);
                    }
                });

                $("#optionsGrid").on("click", ".k-grid-edit", function () {
                    athoc.iws.placeholder.details.customizeUpdateButtons();
                });

                $("#optionsGrid").on("click", "#plDelete", function (e) {
                    e.preventDefault();
                    $('#saveMessagePanel').html("");
                    if (!athoc.iws.placeholder.details.placeholderModel.IsGridEditing()) {
                        var model = pickListgrid.dataItem($(e.target).closest("tr"));
                        athoc.iws.placeholder.details.checkForPickListItemDependencies(model);
                    }
                });
            },
            //
            IsExportEnabled: function () {
                if (athoc.iws.placeholder.details.pickListArray.length == 0) {
                    $('#ancExportValue').addClass('disabled');
                    $('#ancExportValue').css({ cursor: "Default", textDecoration: "none", "pointer-events": "none", color: "gray" });
                } else {
                    $('#ancExportValue').removeClass('disabled');
                    $('#ancExportValue').css({ cursor: "pointer", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });
                }

            },

            IsClearDefaultSelectionEnabled: function () {
                if (!athoc.iws.placeholder.details.checkDefaultSelectionCount()) {
                    $('#ancClearDefaultSelection').addClass('disabled');
                    $('#ancClearDefaultSelection').css({ cursor: "Default", textDecoration: "none", "pointer-events": "none", color: "gray" });
                } else {
                    $('#ancClearDefaultSelection').removeClass('disabled');
                    $('#ancClearDefaultSelection').css({ cursor: "pointer", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });
                }

            },
            checkForPickListItemDependencies: function (plItem) {
                if (plItem.Id != "") {
                    var dataSource = new kendo.data.DataSource({
                        transport: {
                            read: {
                                url: athoc.iws.placeholder.details.urls.GetPlaceholderDependencyListUrl,
                                cache: false,
                                dataType: "json",
                                contentType: "application/json; charset=utf-8",
                                type: "POST",
                                async: false,
                            },

                            parameterMap: function (data) {
                                var moreData = { "providerId": athoc.iws.placeholder.details.placeholderModel.ProviderId(), "placeholderId": athoc.iws.placeholder.details.placeholderModel.Id(), "valueId": plItem.Id };
                                $.extend(data, moreData);
                                return kendo.stringify(data);
                            },
                        },

                        requestStart: function (e) {
                            $.AjaxLoader.setup({ useBlock: true, elementToBlock: $('#placeholderDependencyList .k-grid-content'), imageURL: athoc.iws.placeholder.details.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage });
                            $.AjaxLoader.showLoader();

                        },
                        requestEnd: function (e) {
                            athoc.iws.placeholder.details.centerThePLDependencyModal();
                            $.AjaxLoader.hideLoader();

                        },
                        schema: {
                            data: "Data",
                            total: "TotalCount",
                            model: {
                                fields: {
                                    UsedIn: { type: "string" },
                                    EntityName: { type: "string" },
                                    EntityId: { type: "number" },
                                    UsedFor: { type: "string" },
                                    SourceProvider: { type: "string" }
                                }
                            },
                        },
                        serverPaging: true,
                        sort: { field: "UsedIn", dir: "asc" },
                        pageSize: 50,
                    });

                    $("#pLDeleteDependencyList").kendoGrid({
                        excel: {
                            fileName: "PickList Dependency List.xlsx",
                            allPages: true,
                            filterable: false,
                            proxyURL: athoc.iws.placeholder.details.urls.ExportDependenciesUrl,
                            forceProxy: true,
                        },
                        dataSource: dataSource,
                        autoBind: true,
                        sortable: {
                            allowUnsort: false
                        },
                        pageable: {
                            refresh: false,
                            pageSizes: [20, 50, 100],
                            buttonCount: 5,
                            messages: {
                                display: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Summary,
                                empty: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Empty,
                                itemsPerPage: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Items_Per_Page,
                                first: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Go_To_The_First_Page,
                                previous: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page,
                                next: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Go_To_The_Next_Page,
                                last: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Go_To_The_Last_Page
                            }
                        },
                        excelExport: function (e) {
                            var sheet = e.workbook.sheets[0];
                            for (var i = 0; i < sheet.columns.length; i++) {
                                sheet.columns[i].autoWidth = true;
                            }
                        },
                        serverPaging: true,
                        sort: { field: "UsedIn", dir: "asc" },
                        height: 303,
                        columns: [
                         {
                             field: "UsedIn", title: "Page", width: '20%',
                             headerTemplate: '<span class="cellTooltip" title="Page">Page</span>',
                             template: '<span class="cellTooltip" title="#=UsedIn#">#=UsedIn#</span>'
                         },
                         {
                             field: "UsedFor", title: "Section", width: '20%',
                             headerTemplate: '<span class="cellTooltip" title="Section">Section</span>',
                             template: '<span class="cellTooltip" title="#=UsedFor#">#=UsedFor#</span>',
                         },
                         {
                             field: "EntityName", title: "Name", width: '25%',
                             headerTemplate: '<span class="cellTooltip" title="Name">Name</span>',
                             template: '<span class="cellTooltip" title="#=EntityName#">#=EntityName#</span>',
                         },
                         {
                             field: "EntityId", title: "ID", width: '15%',
                             headerTemplate: '<span class="cellTooltip" title="ID">ID</span>',
                             template: '<span class="cellTooltip" title="#=EntityId#">#=EntityId#</span>',
                         },
                         {
                             field: "SourceProvider", title: "Organization",
                             headerTemplate: '<span class="cellTooltip" title="Organization">Organization</span>',
                             template: '<span class="cellTooltip" title="#=SourceProvider#">#=SourceProvider#</span>',
                         }
                        ],

                    });

                    if (dataSource._data.length > 0) {
                        athoc.iws.placeholder.details.centerThePLDependencyModal();
                        $("#dlgPLDeleteDependencyList #plDDHeading").text(athoc.iws.placeholder.details.resources.UserAttributeManager_Delete_PickList_Modal_Heading + ": " + plItem.pickListName);
                        $('#dlgPLDeleteDependencyList').modal('show');
                        return;
                    }
                }

                $('#dlgPLDeleteGenericConfirmation .genericHeaderMesage').text(athoc.iws.placeholder.details.resources.UserAttributeManager_Delete_PickList_Modal_Heading + ' : ' + plItem.pickListName);//set Header Title
                $('#dlgPLDeleteGenericConfirmation .genericBodyContent').text(athoc.iws.placeholder.details.resources.Placeholder_Delete_PickList_Modal_Message); //Set Confirmation Message
                $('#dlgPLDeleteGenericConfirmation').modal();

                $('#genericPLDConfirmationOk').off('click').on('click', function (e) {
                    e.preventDefault();
                    pickListgrid.dataSource._data.remove(plItem);
                    var id = plItem.Id == "" ? plItem.uid : plItem.Id;
                    athoc.iws.placeholder.details.pickListArray = $.grep(athoc.iws.placeholder.details.pickListArray, function (item) {
                        return item.Id != id;
                    });
                    athoc.iws.placeholder.details.isChanged = true;
                    if (pickListgrid.tbody.find('tr').length == 0) {
                        var colCount = pickListgrid.columns.length;
                        pickListgrid.tbody.append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.placeholder.details.resources.UserAttributeManager_No_Values_Added + '</td></tr>');
                    }
                    $('#dlgPLDeleteGenericConfirmation').modal('hide');
                    athoc.iws.placeholder.details.IsExportEnabled();
                    athoc.iws.placeholder.details.IsClearDefaultSelectionEnabled();


                });
            },
            //
            getPicklistValues: function () {
                var listValueStr = "";

                _.each(pickListgrid.dataSource._data, function (item) {
                    listValueStr = listValueStr + item.pickListName + "<->" + item.pickListCommonName + "<->" + (item.Default ? "1" : "0") + "<>";
                });

                athoc.iws.placeholder.details.placeholderModel.PickListValuesCSV(listValueStr);
            },
            //
            onDataBound: function (e) {
                var grid = $("#optionsGrid").data("kendoGrid");
                var rows = this.items();
                $(rows).each(function () {
                    var index = $(this).index() + 1;
                    var rowLabel = $(this).find("#rowNum");
                    $(rowLabel).html(index);
                });
                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(e.sender.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.placeholder.details.resources.UserAttributeManager_No_Values_Added + '</td></tr>');
                }
            },
            // Insert new item in grid
            insertItem: function (e) {
                //var grid = $("#optionsGrid").data("kendoGrid");
                pickListgrid.addRow();
                //to move the sroll bar down otherwise validation message is not showing up
                //grid.content.scrollTop(grid.tbody.height());etElementsByClassName('k-grid-cancel')[0].outerHTML);
                athoc.iws.placeholder.details.customizeUpdateButtons();

            },
            //
            showImport: function (e) {
                // $("#divReplace").addClass("hide");
                $("#btnPLImportValue").prop("disabled", true);
                $("#chkReplaceAll").prop("checked", false);
                $('#saveMessagePanel').css("display", "none");
                athoc.iws.placeholder.details.registerFileUpload();
                $("#plIVHeading").text(athoc.iws.placeholder.details.resources.Placeholder_Import_Modal_Header + " " + athoc.iws.placeholder.details.breadCrumbModel.attributeText());
                $("#plRCHeading").text(athoc.iws.placeholder.details.resources.Placeholder_Import_Modal_Header + " " + athoc.iws.placeholder.details.breadCrumbModel.attributeText());
                $('#dlgImportValues').modal('show');
                return;
            },
            // Display control on edit of pick list grid.
            customizeUpdateButtons: function (e) {
                $(".k-grid-update").html("Save").removeClass("k-button k-button-icontext k-primary");
                $(".k-grid-cancel").html("Cancel").removeClass("k-button k-button-icontext k-primary");
                $(".k-grid-update").text(athoc.iws.placeholder.details.resources.Action_Link_Save);
                $(".k-grid-cancel").text(athoc.iws.placeholder.details.resources.Action_Link_Cancel);
                $(".k-grid-update").parent('td').html(document.getElementById('optionsGrid').getElementsByClassName('k-grid-update')[0].outerHTML + '<span class="mar-left10 mar-right10">|</span>'
                    + document.getElementById('optionsGrid').getElementsByClassName('k-grid-cancel')[0].outerHTML);

                $("#optionsGrid").on('DOMNodeInserted', function (e) {
                    $(".k-tooltip-validation").css("color", "#b61211");
                    $(".k-tooltip-validation").each(function () { this.style.setProperty("color", "#b61211", "important"); });
                });

                var data = $("#optionsGrid").data("kendoGrid");
                var row = $('#optionsGrid').find('.k-grid-edit-row');
                //$.each(data.dataSource._data, function (index, element) {
                //    if (element.uid != row.attr('data-uid')) {
                $(".k-grid-edit").parent().append().css("pointer-events", "none");
                $(".k-grid tr,#plEdit .k-grid-edit, #plDelete, #plDelete .close, .icon-drag-row,  #ancAddAnohterValue, #ancImportValue").not(".k-grid-edit-row").css({ cursor: "Default", textDecoration: "none", "pointer-events": "none", color: "gray" });
                //    }
                //});
            },
            // Clear default values of picklist
            clearDefaultSelection: function (e) {
                var grid = pickListgrid;
                $('#saveMessagePanel').html("");
                $.each(grid.dataSource._data, function (index, element) {
                    grid.dataSource._data[index].set("Default", false);
                });
                _.each(athoc.iws.placeholder.details.pickListArray, function (item, index) {
                    item.Default = false;
                });
                athoc.iws.placeholder.details.IsClearDefaultSelectionEnabled();
            },
            checkDefaultSelectionCount: function () {
                var exits = $(athoc.iws.placeholder.details.pickListArray).filter(function () {
                    return this.Default;
                });
                return exits.length > 0;
            },

            // Check for dependency while deletion
            checkForDependencies: function (id) {
                athoc.iws.placeholder.details.showDependencyList(id);
            },
            // Show Dependency list in model popup
            showDependencyList: function (dependencyList) {

                var dataSource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: athoc.iws.placeholder.details.urls.GetPlaceholderDependencyListUrl,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST",
                            async: false,
                        },

                        parameterMap: function (data) {
                            var moreData = { "userAttributeId": dependencyList };
                            $.extend(data, moreData);
                            return kendo.stringify(data);
                        },
                    },

                    requestStart: function (e) {
                        $.AjaxLoader.setup({ useBlock: true, elementToBlock: $('#placeholderDependencyList .k-grid-content'), imageURL: athoc.iws.placeholder.details.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage });
                        $.AjaxLoader.showLoader();
                    },
                    requestEnd: function (e) {
                        athoc.iws.placeholder.details.centerTheDependencyModal();
                        $.AjaxLoader.hideLoader();
                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                        model: {
                            fields: {
                                UsedIn: { type: "string" },
                                EntityName: { type: "string" },
                                EntityId: { type: "number" },
                                UsedFor: { type: "string" },
                                SourceProvider: { type: "string" }
                            }

                        },
                    },
                    serverPaging: true,
                    //serverSorting: true,
                    //serverFiltering: true,
                    sort: { field: "UsedIn", dir: "asc" },
                    pageSize: 50,
                    error: function (e) {
                        athoc.iws.placeholder.details.handleError(e);
                    }
                });

                $("#placeholderDependencyList").kendoGrid({
                    excel: {
                        fileName: "Placeholder Dependency List.xlsx",
                        allPages: true,
                        filterable: false,
                        proxyURL: athoc.iws.placeholder.details.urls.ExportDependenciesUrl,
                        forceProxy: true,
                    },
                    dataSource: dataSource,
                    autoBind: true,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Summary,
                            empty: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Empty,
                            itemsPerPage: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Items_Per_Page,
                            first: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Go_To_The_First_Page,
                            previous: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page,
                            next: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Go_To_The_Next_Page,
                            last: athoc.iws.placeholder.details.resources.AtHoc_Pager_Message_Go_To_The_Last_Page
                        }
                    },
                    excelExport: function (e) {
                        var sheet = e.workbook.sheets[0];
                        for (var i = 0; i < sheet.columns.length; i++) {
                            sheet.columns[i].autoWidth = true;
                        }
                    },

                    serverPaging: true,
                    height: 303,
                    sort: { field: "UsedIn", dir: "asc" },
                    columns: [
                         {
                             field: "UsedIn", title: "Page", width: '20%',
                             headerTemplate: '<span class="cellTooltip" title="Page">Page</span>',
                             template: '<span class="cellTooltip" title="#=UsedIn#">#=UsedIn#</span>'
                         },
                         {
                             field: "UsedFor", title: "Section", width: '20%',
                             headerTemplate: '<span class="cellTooltip" title="Section">Section</span>',
                             template: '<span class="cellTooltip" title="#=UsedFor#">#=UsedFor#</span>',
                         },
                         {
                             field: "EntityName", title: "Name", width: '25%',
                             headerTemplate: '<span class="cellTooltip" title="Name">Name</span>',
                             template: '<span class="cellTooltip" title="#=EntityName#">#=EntityName#</span>',
                         },
                         {
                             field: "EntityId", title: "ID", width: '15%',
                             headerTemplate: '<span class="cellTooltip" title="ID">ID</span>',
                             template: '<span class="cellTooltip" title="#=EntityId#">#=EntityId#</span>',
                         },
                         {
                             field: "SourceProvider", title: "Organization",
                             headerTemplate: '<span class="cellTooltip" title="Organization">Organization</span>',
                             template: '<span class="cellTooltip" title="#=SourceProvider#">#=SourceProvider#</span>',
                         }
                    ],

                });
                athoc.iws.placeholder.details.centerTheDependencyModal();
                //$("#placeholderDependencyList").data('kendoGrid').dataSource.data([]);
                if (dataSource._data.length > 0) {
                    $('#dialogDependencyList').modal('show');
                }
                else
                    athoc.iws.placeholder.details.deletePlaceholder(dependencyList, athoc.iws.placeholder.details.placeholderModel.Name());
            },
            // Keep modal popup to center of screen
            centerTheDependencyModal: function () {
                var leftPosition = ($(window).width() / 2) - ($('#dialogDependencyList').width() / 2);
                var d = document.getElementById('dialogDependencyList');
                d.style.position = "absolute";
                d.style.left = 0;
                d.style.marginLeft = leftPosition + 'px';
            },
            // Keep modal popup to center of screen
            centerThePLDependencyModal: function () {
                var leftPosition = ($(window).width() / 2) - ($('#dlgPLDeleteDependencyList').width() / 2);
                var d = document.getElementById('dlgPLDeleteDependencyList');
                d.style.position = "absolute";
                d.style.left = 0;
                d.style.marginLeft = leftPosition + 'px';
            },
            // Deleting attribute based on id
            deletePlaceholder: function (id, commonName) {

                $('#dlgGenericConfirmation .genericHeaderMesage').text(athoc.iws.placeholder.details.resources.Placeholder_Delete + ": " + athoc.iws.placeholder.details.placeholderModel.Name()); //set Header Title
                $('#dlgGenericConfirmation .genericBodyContent').text(athoc.iws.placeholder.details.resources.Placeholder_Delete_Modal_Warning); //Set Confirmation Message
                $('#dlgGenericConfirmation').modal();
                $('#genericConfirmationOk').off('click').on('click', function (e) {
                    e.preventDefault();

                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.placeholder.details.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();

                    var myAjaxOptions = {
                        url: athoc.iws.placeholder.details.urls.DeletePlaceholderUrl,
                        type: "POST",
                        contentType: 'application/json',
                        dataType: 'json',
                        async: false,
                        data: JSON.stringify({ 'placeholderId': id, 'commonName': commonName })
                    };
                    var onError = function (e) {
                        athoc.iws.placeholder.details.handleError(e);
                        $.AjaxLoader.hideLoader();
                    };
                    var onSuccess = function (data) {
                        if (data && data.Success && data.Success === true) {
                            $('#dlgGenericConfirmation').modal('hide');
                            //athoc.iws.placeholder.viewAttributeList(true);
                            athoc.iws.placeholder.details.gotoPlaceholder();

                        } else {
                            //show the error/validation.
                            $('#dlgGenericConfirmation').modal('hide');
                            $('#AttributeEditMessagePanel').messagesPanel('reset');
                            var messagePanel = $('#SaveMessagePanel').messagesPanel({ messages: data.Messages });
                        }
                        $.AjaxLoader.hideLoader();
                    }
                    var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                    $.ajax(ajaxOptions);
                    $.AjaxLoader.hideLoader();
                });
            },
            // Show modal popup when clear all Users button is clicked
            clearforAllUsers: function () {
                $('#dlgClearAllUsers').modal('show');
                $('#cauConfirmationOk').off('click').on('click', function (e) {
                    athoc.iws.placeholder.details.clearAttributeDefaultValues(athoc.iws.placeholder.details.placeholderModel.Id());
                });

            },
            //
            clearAttributeDefaultValues: function (id) {
                var messageArray = [];
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.placeholder.details.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();

                var myAjaxOptions = {
                    url: athoc.iws.placeholder.details.urls.DeleteAttributeDefaultValuesUrl,
                    type: "POST",
                    contentType: 'application/json',
                    dataType: 'json',
                    async: false,
                    data: JSON.stringify({ 'placeholderId': id })
                };
                var onError = function (e) {
                    $.AjaxLoader.hideLoader();
                    athoc.iws.placeholder.details.handleError(e);
                    $(document).scrollTop(0);
                };
                var onSuccess = function (data) {
                    $('#dlgClearAllUsers').modal('hide');
                    $.AjaxLoader.hideLoader();
                    if (data.Success) {
                        messageArray.push({ Type: '8', Value: athoc.iws.placeholder.details.resources.UserAttributeManager_ClearDefault_Success_Message });
                    }
                    else {
                        messageArray.push({ Type: '4', Value: athoc.iws.placeholder.details.resources.UserAttributeManager_ClearDefault_Failed_Message });
                    }
                    $('#saveMessagePanel').messagesPanel({ messages: messageArray });
                    $(document).scrollTop(0);
                }
                var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

            },
            // Show modal popup when enforce default button is clicked
            enforceDefault: function () {
                $('#dlgEnforceDefault').modal('show');
                $('#eduConfirmationOk').off('click').on('click', function (e) {
                    athoc.iws.placeholder.details.setAttributeDefaultValues(athoc.iws.placeholder.details.placeholderModel.Id());
                });

            },
            setAttributeDefaultValues: function (id) {
                var messageArray = [];
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.placeholder.details.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();

                var myAjaxOptions = {
                    url: athoc.iws.placeholder.details.urls.SetAttributeDefaultValuesUrl,
                    type: "POST",
                    contentType: 'application/json',
                    dataType: 'json',
                    async: false,
                    data: JSON.stringify({ 'placeholderId': id })
                };
                var onError = function (e) {
                    $.AjaxLoader.hideLoader();
                    athoc.iws.placeholder.details.handleError(e);
                };
                var onSuccess = function (data, textStatus, jqXHR) {
                    $('#dlgEnforceDefault').modal('hide');
                    $.AjaxLoader.hideLoader();
                    if (data.Success) {
                        messageArray.push({ Type: '8', Value: athoc.iws.placeholder.details.resources.UserAttributeManager_DefaultValues_Success_Message });
                    }
                    else {
                        messageArray.push({ Type: '4', Value: athoc.iws.placeholder.details.resources.UserAttributeManager_DefaultValues_Failed_Message });
                    }
                    $('#saveMessagePanel').messagesPanel({ messages: messageArray });
                    $(document).scrollTop(0);
                }
                var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

            },
            // Display Create New Import popup 
            registerFileUpload: function () {
                document.getElementById("fUpload").value = "";
                $("#btnBrowse").addClass("fileinput-button-align");
                $("#btnBrowse").removeClass("fileinput-button-align-height");
                $('#importFileText').val("");
                //$('#newMessagePanel').html('');
                $('#newMessagePanel').addClass("hide");
                fileData = null;
                $("#fUpload").fileupload({
                    dataType: 'json',
                    autoUpload: false,
                    maxFileSize: 5000000,
                    url: athoc.iws.placeholder.details.urls.GetImportValueUrl,
                    done: function (e, data) {
                        var reqError = new Array();
                        if (data.result.Success) {
                            athoc.iws.placeholder.details.pickListImportValuesArray = [];
                            athoc.iws.placeholder.details.ImportModel.successCount(data.result.data.length);
                            athoc.iws.placeholder.details.ImportModel.failedCount(data.result.errorrecords);
                            $.each(data.result.data, function (i, item) {
                                athoc.iws.placeholder.details.pickListImportValuesArray.push(item);
                            });
                            $('#newMessagePanel').addClass("hide");
                            // $("#divReplace").removeClass("hide");
                            $('#newMessagePanel').text("");
                            $("#btnPLImportValue").prop("disabled", false);
                        }
                        else {
                            $('#importFileText').val("");
                            $("html,body").scrollTop(0);
                            $('#newMessagePanel').removeClass("hide");
                            //$("#divReplace").addClass("hide");
                            $('#newMessagePanel').text(data.result.Error);
                            $("#btnPLImportValue").prop("disabled", true);
                        }
                    },
                    add: function (e, data) {
                        fileData = data;
                        $('#newMessagePanel').html('');
                        $.each(data.files, function (index, file) {
                            var ext = file.name.split(".")[file.name.split(".").length - 1].toLowerCase();
                            switch (ext) {
                                case 'csv':
                                    {
                                        $("#importFileText").val(file.name);
                                        data.submit();
                                        break;
                                    }
                                default:
                                    $("#btnPLImportValue").prop("disabled", true);
                                    var reqError = new Array();
                                    reqError.push({ Type: '4', Value: athoc.iws.placeholder.details.resources.Placeholder_ImportFile_Pattern });
                                    $('#importFileText').val("");
                                    $("html,body").scrollTop(0);

                                    $('#newMessagePanel').removeClass("hide");
                                    $('#newMessagePanel').text(athoc.iws.placeholder.details.resources.Placeholder_ImportFile_Pattern);
                                    /* handle */
                                    break;
                            }
                        });

                    },
                    change: function (e, data) {

                    },
                    error: function (e) {
                    }
                });
            },
            //
            ImportValues: function () {
                if (athoc.iws.placeholder.details.pickListImportValuesArray.length > 0) {
                    athoc.iws.placeholder.details.bindImportValues();
                    $("#importFileText").val("");
                    $('#dlgImportValues').modal('hide');
                    //$("#divReplace").addClass("hide");
                    $('#dlgPLResultConfirmation').modal('show');
                }
            },
            //
            bindImportValues: function () {
                var importValuesCnt = 0;
                var notImportedValues = 0;
                if ($("#chkReplaceAll").is(":checked")) {
                    athoc.iws.placeholder.details.pickListArray = [];
                    pickListgrid.dataSource._data.length = 0;
                    //var grid = $("#optionsGrid").data("kendoGrid");
                    //var colCount = grid.columns.length;
                    //grid.find('tbody').append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.placeholder.details.resources.UserAttributeManager_No_Values_Added + '</td></tr>');
                    pickListgrid.refresh();
                    $.each(athoc.iws.placeholder.details.pickListImportValuesArray, function (i, item) {
                        var obj = new athoc.iws.placeholder.details.picklistObject(i + 1, i + 1, item, false, "");
                        athoc.iws.placeholder.details.pickListArray.push(obj);
                        pickListgrid.dataSource._data.push(obj);
                        pickListgrid.refresh();
                        importValuesCnt++;
                    });
                }
                else {
                    if (athoc.iws.placeholder.details.pickListArray.length > 0) {
                        var max = 0;
                        $.each(athoc.iws.placeholder.details.pickListArray, function (i, v) {
                            thisVal = v.Id;
                            max = (max < thisVal) ? thisVal : max;
                        });
                        _.each(athoc.iws.placeholder.details.pickListImportValuesArray, function (fromValues, i) {
                            var toImportValues = _.find(athoc.iws.placeholder.details.pickListArray, function (toValues) {
                                return fromValues.toLowerCase() === toValues.pickListName.toLowerCase();
                            });
                            if (!toImportValues) {
                                var cnt = max + 1;
                                var obj = new athoc.iws.placeholder.details.picklistObject(cnt, cnt, fromValues, false, "");
                                athoc.iws.placeholder.details.pickListArray.push(obj);
                                pickListgrid.dataSource._data.push(obj);
                                pickListgrid.refresh();
                                importValuesCnt++;
                                max = cnt;
                            } else {
                                notImportedValues++;
                            }
                        });
                    }
                    else {
                        $.each(athoc.iws.placeholder.details.pickListImportValuesArray, function (i, item) {
                            var obj = new athoc.iws.placeholder.details.picklistObject(i + 1, i + 1, item, false, "");
                            athoc.iws.placeholder.details.pickListArray.push(obj);
                            pickListgrid.dataSource._data.push(obj);
                            pickListgrid.refresh();
                            importValuesCnt++;
                        });
                    }
                }
                if (importValuesCnt > 0)
                    pickListgrid.refresh();

                var totalCnt = (athoc.iws.placeholder.details.ImportModel.successCount() + athoc.iws.placeholder.details.ImportModel.failedCount());
                $("#pSucessResult").text(importValuesCnt);
                $("#pFailedResult").text(totalCnt - importValuesCnt);
            },

        }
    }();
}
