﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.hierarchydefinition = athoc.iws.hierarchydefinition || {};

if (athoc.iws.hierarchydefinition) {



    athoc.iws.hierarchydefinition = function () {
        var treeview;
        var dataedit;
        var ihierarchytype;
        var saveelist = new Array();
        var flag = 0;
        var isDuplicate = false;
        var searchItem;
        var NewListId = 0;
        var SortOrder = 0;
        var isSearchTextFound = 0;
        var isInEdit = false;
        var treeviewMaxHeight = 275;
        return {
            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},
            editmodel: { nodemodel: ko.observable(), isAdd: ko.observable(true), isDelete: ko.observable(false), isRefresh: ko.observable(false), isCollapse: ko.observable(true), sTitle: ko.observable("") }
            ,

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for scenario list, will be triggered before document load
            init: function () {
                athoc.iws.hierarchydefinition.initBreadcrumb();
                navigateToPage('viewHierarchyDefinition', function () { });

            },

            //load method, will be tirggered on document load
            load: function () {

                var inputElm = $("#txtSearch");
                // Set max length property for Search option 
                inputElm.maxLength({
                    maxLength: 100,
                    onMaxReached: function () {
                        $('#saveMessagePanel').modal("show");
                    }

                }

                );



                //Disable the Search button if search textbox is empty
                inputElm.blur(function (e) {
                    inputElm.val(inputElm.val().trim());
                    if (inputElm.val() == "") {
                        $("#btn_search").attr("disabled", true);
                        athoc.iws.hierarchydefinition.hideErrorMessage();
                        //clear the highlighted  text 
                        $('span.child > span.highlight').each(function () {
                            $(this).parent().text($(this).parent().text());
                        });
                        //iws12985
                        var root = $('.k-item:first');
                        treeview.select(root);
                        treeview.trigger('select', { node: root });
                    }
                    else
                        $("#btn_search").removeAttr("disabled");

                });
                // Execute search options when press search button
                inputElm.keyup(function (e) {

                    if (inputElm.val().trim() == "")
                        $("#btn_search").attr("disabled", true);
                    else
                        $("#btn_search").removeAttr("disabled");

                    if ($.hotkeys.enter(e)) {
                        //athoc.iws.hierarchydefinition.SearchName(treeview.dataSource.view());
                        $("#btn_search").click();
                    }


                });
                treeview = $("#treeview").kendoTreeView({
                    autoBind: false,
                    toggle: false,
                    dragAndDrop: true,
                    template: kendo.template($("#treeview-template").html()),
                    dataTextField: ["Name"],
                    dataImageUrlField: ["imageUrl"],
                    select: athoc.iws.hierarchydefinition.onSelect,
                    loadOnDemand: false,
                    expand: function (e) {
                    },
                    dragend: function (e) {
                        //on drag and drop change the node class to new-node
                        treeview.findByUid(treeview.dataItem(e.sourceNode).uid).find('.child').addClass("new-node");
                    },
                    drag: function (e) {
                        /* Manually set the status class. */
                    },
                    drop: function (e) {
                        //Method to handle drop actions on the treeview
                        athoc.iws.hierarchydefinition.hideErrorMessage();

                        //return if basic drag and drop action is not valid
                        if (!e.valid) {
                            e.preventDefault();
                            return;
                        }

                        var errorType = athoc.iws.hierarchydefinition.resources.Hierarchy_MsgParentNodeCanNotMove;

                        var sourceNode = e.sourceNode;
                        var parent = e.destinationNode;

                        if (treeview.dataItem(sourceNode).level() < 1) {
                            errorType = athoc.iws.hierarchydefinition.resources.RootNodeCanNotMove;
                            e.valid = false;
                            e.preventDefault();
                            //athoc.iws.hierarchydefinition.showErrorMessage(errorType);
                            return;
                        }

                        if (e.valid && (treeview.dataItem(parent) == undefined || parent == undefined || athoc.iws.hierarchydefinition.isInEdit)) {
                            errorType = athoc.iws.hierarchydefinition.resources.Hierarchy_MsgDragNDropNotAllowed;
                            e.valid = false;
                            e.preventDefault();
                            return;
                        }

                        if (e.valid)
                            if (e.dropPosition == "over") {
                                parent = e.destinationNode;
                            } else
                                parent = e.destinationNode.parentNode;

                        if (e.valid && (treeview.dataItem(parent) == undefined)) {
                            e.valid = false;
                            e.preventDefault();
                            return;
                        }

                        if (e.valid && treeview.dataItem(parent).hasChildren) {
                            if (treeview.dataItem(parent).Children.length > 0)
                                for (var i = 0 ; i < treeview.dataItem(parent).Children.length; i++) {
                                    if (treeview.dataItem(parent).Children[i].Name.toLowerCase() == treeview.dataItem(e.sourceNode).Name.toLowerCase()) {
                                        if (treeview.dataItem(parent).Children[i].level() != treeview.dataItem(e.sourceNode).level()) {
                                            e.valid = false;
                                            errorType = athoc.iws.hierarchydefinition.resources.UniqueNodeName;
                                            e.preventDefault();
                                            athoc.iws.hierarchydefinition.showErrorMessage(errorType);
                                        }
                                    }
                                }
                        }


                        if (e.valid) { 
                            if (treeview.dataItem(e.destinationNode).Status == "N" || treeview.dataItem(e.sourceNode).Status == "N")
                                treeview.dataItem(e.sourceNode).NewParentListId = treeview.dataItem(parent).NewListId;
                            $(parent).find(".k-state-hover > .k-image").attr("src", "/athoc-cdn/images/icon3-groups-purple.png");
                            treeview.dataItem(parent).imageUrl = "/athoc-cdn/images/icon3-groups-purple.png";
                            if (treeview.dataItem(treeview.parent(sourceNode)).Children.length == 1) {
                                $(treeview.parent(sourceNode)).find(".k-image").attr("src", "/athoc-cdn/images/icon3-users-purple.png");
                                treeview.dataItem(treeview.parent(sourceNode)).imageUrl = "/athoc-cdn/images/icon3-users-purple.png";

                            }
                            athoc.iws.hierarchydefinition.editmodel.isRefresh(true);
                            athoc.iws.hierarchydefinition.changeImageStatus("Refresh");


                        }
                        else {
                            // athoc.iws.hierarchydefinition.showErrorMessage(errorType);
                            return;
                        }

                    },
                    //To hide the root node
                    dataBound: function () {
                       // $("#treeview > ul > li > div").hide();
                       // athoc.iws.hierarchydefinition.displayEmptyMessage();
                    }
                }).on('dblclick', '.child', function (event) {
                    //Method to handle double click on node

                    event.preventDefault();
                    //on edit mode disable the save button
                    $("#btn_Save").attr("disabled", true);

                    athoc.iws.hierarchydefinition.hideErrorMessage();
                    athoc.iws.hierarchydefinition.isInEdit = true;
                    $target = $(event.target);
                    if ($target[0].innerText != undefined)
                        $target[0].innerHTML = $target[0].innerText;
                    var editNode = treeview.select();

                    //Restrict paste functionality
                    /* $target.on("paste", function (e) {
                         return false;
                     });
                     */

                    //on key enter, come outside from edit mode 
                    $target.keyup(function (e) {
                        $("#btn_Save").attr("disabled", true);
                        if ($.hotkeys.enter(e)) {
                            editNode[0].parentNode.click();
                        }
                    });


                    $target.editable(function (value) {
                        if (value != "") {
                            value = value.replace(/</g, "").replace(/>/g, "").replace(/"/g, "").replace(/\\/g, "").replace(/\//g, "");
                            if (value.length > 128)
                                value = value.substr(0, 128);
                            return ($.htmlDecode(value));
                        }
                        else
                            return "";
                    },
                    {
                        cssclass: "treeInlineEdit",
                        placeholder: athoc.iws.hierarchydefinition.resources.Hierarchy_NewNodeText,
                        onblur: "submit",
                        event: "dblclick",
                        callback: function (data) {
                            //Record the changes
                            $("#btn_Save").attr("disabled", false);
                            data = $.htmlDecode(data);
                            athoc.iws.hierarchydefinition.isInEdit = false;
                            if (data.length > 128) {
                                data = data.substr(0, 128);
                                $target[0].innerText = data;
                            }

                            var selectedNode = editNode;
                            var flag = true;

                            if (data == "" && treeview.dataItem(selectedNode).Name != "") {
                                data = treeview.dataItem(selectedNode).Name;
                                treeview.dataItem(selectedNode).set('Name', data);
                                $target[0].innerText = data;
                            }



                            if (flag && treeview.dataItem(selectedNode).Name != data) {
                                treeview.dataItem(selectedNode).set('Name', $.trim(data));
                                treeview.dataItem(selectedNode).set('CommonName', $.trim(data).replace(/ /g, "-"));
                                if (treeview.dataItem(selectedNode).Status != "N")
                                    treeview.dataItem(selectedNode).set('Status', "M");
                                athoc.iws.hierarchydefinition.editmodel.isRefresh(true);
                                athoc.iws.hierarchydefinition.changeImageStatus("Refresh");
                                // data.$el gives you a reference to the element that was edited
                                //  data.$target.effect('blink');
                                $(selectedNode).find('.child:first').addClass("new-node");
                            }
                            else if (!flag || treeview.dataItem(selectedNode).Name != data) {
                                treeview.dataItem(selectedNode).set('Name', treeview.dataItem(selectedNode).Name);
                                $target[0].innerText = treeview.dataItem(selectedNode).Name;
                            }

                        }
                    });
                    //  $target.trigger('dblclick', [event]);
                    return false;

                }).data("kendoTreeView");

                dataedit = {
                    Name: "",
                    CommonName: "",
                    ListId: 0,
                    ParentListId: 0,
                    HierarchyId: 0,
                    ListType: "",
                    Status: "",
                    NewListId: "",
                    NewParentListId: "",
                    Lineage: "",
                    imageUrl: "",
                    SortOrder: 0,
                };

                athoc.iws.hierarchydefinition.bindBreadcrumb();
                athoc.iws.hierarchydefinition.OpenHierarchy(1);
                //Method to handle cancel button actions
                $("#btn_Cancel").click(function () {

                    if (athoc.iws.hierarchydefinition.isChanged) {
                        var confirmLeave = confirm(athoc.iws.hierarchydefinition.resources.Unsaved_Data_Text);
                        if (confirmLeave) {
                            athoc.iws.hierarchydefinition.isCancelClicked = true;
                            window.location.href = "/client/setup/settings";
                            return true;
                        }
                        athoc.iws.hierarchydefinition.isCancelClicked = false;
                        return false;
                    }
                    window.location.href = "/client/setup/settings";
                });


                $('#treeviewdeselect').on('click', "div", function (e) {

                    if (e.target !== this)
                        return;
                    // alert('test');
                    ////Clear node selection                    
                    treeview.select().find("span.k-state-selected").removeClass("k-state-focused");
                    treeview.select($());
                    //treeview.trigger('select', { node: $() });
                    var root = $('.k-item:first');
                    treeview.select(root);
                    treeview.trigger('select', { node: root });
                    window.setTimeout(function () {
                        $("#deleteNode").attr("disabled", "disabled");
                    }, 100);
                });


                //Method to handle save button actions                
                $("#btn_Save").click(function () {
                    athoc.iws.hierarchydefinition.isInEdit = false;
                    athoc.iws.hierarchydefinition.hideErrorMessage();
                    $("#txtSearch").val('');
                    $("#btn_search").attr("disabled", true);
                    //Save the changes and close the model popup 
                    athoc.iws.hierarchydefinition.SaveDetails();

                });

                //Method to handle search on treeview                
                $("#btn_search").click(function () {
                    isSearchTextFound = 0;
                    athoc.iws.hierarchydefinition.hideErrorMessage();
                    //Clear node selection                    
                    treeview.select().find("span.k-state-selected").removeClass("k-state-focused");
                    treeview.select($());
                    treeview.trigger('select', { node: $() });
                    //disable Add/Delete buttons as no node is in selection
                    $("#addNodes").attr("disabled", "disabled");
                    $("#deleteNode").attr("disabled", "disabled");

                    //Search the node text and highlight the node text                     
                    athoc.iws.hierarchydefinition.SearchName(treeview.dataSource.view());
                    athoc.iws.hierarchydefinition.changeImageStatus("DEL");
                    if (isSearchTextFound == 0) {
                        athoc.iws.hierarchydefinition.showErrorMessage(athoc.iws.hierarchydefinition.resources.SearchNotFound);
                    }
                });


                //collapse all nodes
                $("#collapseAllNodes").click(function () {
                    //IWS-10043 - collapse all nodes upto root level
                    //treeview.collapse(".k-item:first");
                    treeview.collapse(".k-item:not(li:first)");
                });

                //Expand all nodes
                $("#expandAllNodes").click(function () {

                    treeview.expand(".k-item");
                });

                //Method to handle add new node functionality                
                $("#addNodes").click(function () {
                    //athoc.iws.hierarchydefinition.displayEmptyMessage(true);
                    athoc.iws.hierarchydefinition.isInEdit = true;
                    athoc.iws.hierarchydefinition.hideErrorMessage();

                    var selectedNode = treeview.select();
                    if (selectedNode.length == 0) {
                        selectedNode = null;
                    }

                    var kitems = $(selectedNode).parentsUntil('.k-treeview', '.k-item');
                    //Verify the node levels
                    /*   if (kitems.length > 2)
                       {
                           var reqError = new Array();
                           reqError.push({ Type: '4', Value: athoc.iws.hierarchydefinition.resources.NodeMaxLevels });
                           $('#saveMessagePanel').messagesPanel({ messages: reqError });
                           return false;
                       } */
                    $(selectedNode).find(".k-state-selected > .k-image").attr("src", "/athoc-cdn/images/icon3-groups-purple.png");
                    treeview.dataItem(selectedNode).imageUrl = "/athoc-cdn/images/icon3-groups-purple.png";
                    //Append a new node to the treeview
                    var newNode = treeview.append(
                        {
                            ListId: -1,
                            ParentListId: treeview.dataItem(selectedNode).NewListId != null ? 0 : treeview.dataItem(selectedNode).ListId,
                            NewListId: (++NewListId) + "_1",
                            Name: "", CommonName: "",
                            NewParentListId: treeview.dataItem(selectedNode).ListId == -1 ? treeview.dataItem(selectedNode).NewListId : treeview.dataItem(selectedNode).ListId,
                            HierarchyId: treeview.dataItem(selectedNode).HierarchyId,
                            expanded: true,
                            Status: "N",
                            items: [],
                            imageUrl: "/athoc-cdn/images/icon3-users-purple.png",
                            SortOrder: 0,
                        }, selectedNode);
                    treeview.select(newNode);
                    treeview.trigger('select', { node: newNode });
                    $("#btn_Save").attr("disabled", true);
                    $target = $(newNode[0]).find(".child");
                    $target[0].innerHTML = "";
                    $target.keyup(function (e) {
                        $("#btn_Save").attr("disabled", true);
                        if ($.hotkeys.enter(e)) {
                            newNode[0].parentNode.click();
                        }
                    });

                    $target.editable(function (value) {
                        if (value != "") {
                            value = value.replace("<", "").replace(">", "").replace(/"/g, "").replace(/\\/g, "").replace("/", "").replace(/\//g, "");
                            $target.keyup(function (e) {
                                if ($.hotkeys.enter(e)) {
                                    newNode[0].parentNode.click();
                                }
                            });
                            return (value);
                        }
                        else
                            return "";
                    }, {
                        cssclass: "treeInlineEdit",
                        placeholder: athoc.iws.hierarchydefinition.resources.Hierarchy_NewNodeText,
                        onblur: "submit",
                        event: "dblclick",
                        callback: function (data) {

                            athoc.iws.hierarchydefinition.isInEdit = false;
                            $("#btn_Save").attr("disabled", false);
                            data = $.trim($.htmlDecode(data));
                            var selectedNode = newNode;
                            var flag = true;
                            if (data == "") {
                                data = athoc.iws.hierarchydefinition.resources.Hierarchy_NewNodeText;
                            }
                            //set Node text max length
                            if (data.length > 128) {
                                data = data.substr(0, 128);
                            }

                            //commented; as while saving, duplicate node verification in the same level will be performed 
                            /* $.each(selectedNode.siblings(), function (i, n) {
                                 if (treeview.dataItem(n).Name == data && data != "new node") {
                                     flag = false;
                                 }
                             });*/

                            if (flag) {
                                treeview.dataItem(selectedNode).set('Name', $.trim(data));
                                treeview.dataItem(selectedNode).set('CommonName', $.trim(data).replace(/ /g, "-"));
                                treeview.dataItem(selectedNode).set('Status', "N");
                                athoc.iws.hierarchydefinition.editmodel.isRefresh(true);
                                athoc.iws.hierarchydefinition.editmodel.isDelete(true);
                                athoc.iws.hierarchydefinition.changeImageStatus('Del');
                                athoc.iws.hierarchydefinition.changeImageStatus("Refresh");
                                selectedNode.addClass("new-node");
                            }
                            else {
                                $target.dblclick();
                            }
                            // data.$el gives you a reference to the element that was edited
                            //  data.$target.effect('blink');
                        }

                    });
                    $target.dblclick();
                });

                //Method to handle delete functionality              
                $("#deleteNode").click(function () {
                    //iws-12419

                    $("#btn_Save").attr("disabled", false);
                    athoc.iws.hierarchydefinition.isInEdit = false;
                    athoc.iws.hierarchydefinition.hideErrorMessage();
                    //Delete selected Node
                    if (athoc.iws.hierarchydefinition.editmodel.isDelete()) {
                        var selectedNode = treeview.select();
                        var selectitem = treeview.findByUid(treeview.dataItem(selectedNode[0].parentNode).uid);
                        flag = 1;
                        var datadelete = new Object();
                        datadelete.Name = $.htmlDecode(treeview.dataItem(selectedNode).Name);
                        datadelete.CommonName = $.htmlDecode(treeview.dataItem(selectedNode).CommonName);
                        datadelete.ListId = treeview.dataItem(selectedNode).ListId;
                        datadelete.HierarchyId = treeview.dataItem(selectedNode).HierarchyId;
                        datadelete.Status = "D";
                        datadelete.ParentListId = treeview.dataItem(selectedNode).ParentListId;
                        datadelete.NewListId = treeview.dataItem(selectedNode).NewListId;
                        datadelete.ListType = "TREE";
                        datadelete.NewParentListId = treeview.dataItem(selectedNode).NewParentListId;
                        datadelete.OldLineage = (treeview.dataItem(selectedNode).OldLineage != null && treeview.dataItem(selectedNode).OldLineage != undefined) ? treeview.dataItem(selectedNode).OldLineage : treeview.dataItem(selectedNode).Lineage + $.htmlDecode(treeview.dataItem(selectedNode).CommonName) + "/";
                        datadelete.Lineage = "/";
                        saveelist[saveelist.length] = datadelete;

                        var n = treeview.dataItem(selectedNode);
                        if (n.hasChildren)
                            athoc.iws.hierarchydefinition.readallChildNodes(n.children.view());

                        treeview.remove(selectedNode);
                        treeview.select(selectitem);
                        if ((treeview.dataItem(selectitem).Children && treeview.dataItem(selectitem).Children.length == 0)) {
                            treeview.dataItem(selectitem).imageUrl = "/athoc-cdn/images/icon3-users-purple.png";
                            $(selectitem).find(".k-image").attr("src", "/athoc-cdn/images/icon3-users-purple.png");
                        }
                        athoc.iws.hierarchydefinition.editmodel.isRefresh(true);
                        athoc.iws.hierarchydefinition.changeImageStatus("Refresh");

                        var root = $('.k-item:first');;
                        if (treeview.dataItem(root).selected) {
                            $("#deleteNode").attr("disabled", "disabled");
                            athoc.iws.hierarchydefinition.editmodel.isDelete(false);
                        }

                    }

                });

                //Method to handle refresh nodes                
                $("#refreshNode").click(function () {

                    athoc.iws.hierarchydefinition.isInEdit = false;
                    athoc.iws.hierarchydefinition.hideErrorMessage();
                    $("#txtSearch").val('');
                    $("#btn_search").attr("disabled", true);
                    //Reload the treeview nodes
                    athoc.iws.hierarchydefinition.GetDataTreeview(ihierarchytype);
                    $("#update").css("display", "none");
                    athoc.iws.hierarchydefinition.editmodel.isRefresh(false);
                    athoc.iws.hierarchydefinition.changeImageStatus("Refresh");
                    NewListId = 0;

                });

                $("#treeview").on("click", ".delete-link", function (e) {
                    e.preventDefault();
                    var treeview = $("#treeview").data("kendoTreeView");
                    treeview.remove($(this).closest(".k-item"));
                });
                $('#treeviewdeselect').on('click', "div", function (e) {

                    if (e.target !== this)
                        return;
                    ////Clear node selection                    
                    treeview.select().find("span.k-state-selected").removeClass("k-state-focused");
                    treeview.select($());
                    treeview.trigger('select', { node: $() });
                    var root = $('.k-item:first');
                    treeview.select(root);
                    treeview.trigger('select', { node: root });
                });
                $("#closeNodeInfo").click(function () {
                    $("#update").css("display", "none");
                });

                window.onbeforeunload = function (event) {
                    var isModified = athoc.iws.hierarchydefinition.editmodel.isRefresh();
                    if (isModified) {
                        return athoc.iws.hierarchydefinition.resources.Unsaved_Data_Text;
                    } else {
                        $(window).scrollTop(0);
                    }
                };
            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            //Method to read Child Nodes
            readallChildNodes: function (selectedNode) {
                $.map(selectedNode, function (n, i) {
                    athoc.iws.hierarchydefinition.recordNodeDetails(n);
                    if (n.hasChildren)
                        athoc.iws.hierarchydefinition.readallChildNodes(n.children.view());
                });
            },

            //Method to Add node details
            recordNodeDetails: function (selectedNode) {
                var datadelete = new Object();
                datadelete.Name = $.htmlDecode(selectedNode.Name);
                datadelete.CommonName = $.htmlDecode(selectedNode.CommonName);
                datadelete.ListId = selectedNode.ListId;
                datadelete.HierarchyId = selectedNode.HierarchyId;
                datadelete.Status = "D";
                datadelete.ParentListId = selectedNode.ParentListId;
                datadelete.NewListId = selectedNode.NewListId;
                datadelete.ListType = "TREE";
                datadelete.NewParentListId = selectedNode.NewParentListId;
                datadelete.OldLineage = (selectedNode.OldLineage != null && selectedNode.OldLineage != undefined) ? selectedNode.OldLineage : selectedNode.Lineage + $.htmlDecode(selectedNode.CommonName) + "/";
                datadelete.Lineage = "/";
                saveelist[saveelist.length] = datadelete;
            },

            //Method to init Bread crumb
            initBreadcrumb: function () {
                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.hierarchydefinition.breadcrumbModel;
                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', $.htmlDecode(athoc.iws.hierarchydefinition.resources.AtHoc_Common_Settings), '', function () {
                    window.location.href = "/client/setup/settings";
                });

                var hierarchydefinitionLink = new Breadcrumb('hierarchydefinitionLink', $.htmlDecode(athoc.iws.hierarchydefinition.resources.NavBar_Hierarchy_Builder), '', function () {
                    navigateToPage('viewHierarchyDefinition', function () { });
                    athoc.iws.hierarchydefinition.breadcrumbModel.SelectedPage('viewhierarchydefinition');
                    $.titleCrumb("pageBreadcrumbs");

                });

                //Page breadcrumb
                var viewPageBreadcrumb = new PageBreadcrumb('viewHierarchyDefinition', $.htmlDecode(athoc.iws.hierarchydefinition.resources.NavBar_Hierarchy_Builder), [settingLink], '');
                //To Edit Delivery template data
                var editPageBreadcrumb = new PageBreadcrumb('edithierarchydefinition', 'Edit', [settingLink, hierarchydefinitionLink], '');
                breadcrumbsModel.addPage(viewPageBreadcrumb);
                breadcrumbsModel.addPage(editPageBreadcrumb);

            },

            //Method to clear the panel
            ClearPanel: function () {
                $("#update").css("display", "none");
                $("#information").css("display", "");
            },

            //Method to Verify the Name Uniqueness
            VerifyNameUniqueness: function (pnode, cname, uid) {

                if (pnode.children.length > 0) {
                    for (var i = 0; i < pnode.children.length; i++)
                        if ($.trim(treeview.dataItem(pnode.children[i]).Name.toLowerCase()) == $.trim(cname.toLowerCase()) && treeview.dataItem(pnode.children[i]).uid != uid)
                            return true;
                }
            },

            //Method to Verify the Common Name Uniqueness
            VerifyCommonNameUniqueness: function (nodes) {
                for (var i = 0; i < nodes.length; i++) {
                    if (($.trim(nodes[i].CommonName.toLowerCase()) == athoc.iws.hierarchydefinition.editmodel.nodemodel.CommonName().toLowerCase()) && (nodes[i].uid != treeview.dataItem(treeview.select()).uid)) {
                        isDuplicate = true;
                        return false;
                    }

                    if (nodes[i].hasChildren) {
                        athoc.iws.hierarchydefinition.VerifyCommonNameUniqueness(nodes[i].children.view());
                    }
                }
            },

            //Method to handle search functionality
            SearchName: function (nodes) {
                for (var i = 0; i < nodes.length; i++) {
                    if ($.trim(nodes[i].Name.toLowerCase()) == $.trim($("#txtSearch").val())) {
                        searchItem = nodes[i].uid;
                        isSearchTextFound = 1;
                        //return false;
                        break;
                    }

                    if (nodes[i].hasChildren) {
                        athoc.iws.hierarchydefinition.SearchName(nodes[i].children.view());
                    }
                }

                $('span.child > span.highlight').each(function () {
                    $(this).parent().text($(this).parent().text());
                });

                if ($.trim($("#txtSearch").val()) == '') { return; }

                var term = $.trim($("#txtSearch").val()).toUpperCase();
                var tlen = term.length;

                $('#treeview span.child').each(function () {
                    var text = $(this).text();
                    var p = text.toUpperCase().indexOf(term);
                    if (p >= 0) {
                        var s1 = '', s2 = '';

                        var high = '<span class="highlight">' + text.substr(p, tlen) + '</span>';

                        if (p > 0) {
                            s1 = text.substr(0, p);
                        }

                        if (p + tlen < text.length) {
                            s2 = text.substring(p + tlen);
                        }

                        $(this).html(s1 + high + s2);
                        isSearchTextFound = 1;
                    }
                });

            },

            //Method to handle read node details in order to save the details
            treeToJson: function (nodes) {

                return $.map(nodes, function (n, i) {
                    dataedit = new Object();
                    dataedit.Name = $.htmlDecode($.trim(n.Name));
                    dataedit.CommonName = $.htmlDecode($.trim(n.CommonName));
                    dataedit.ListId = n.ListId;
                    dataedit.HierarchyId = n.HierarchyId;
                    dataedit.Status = n.Status;
                    dataedit.NewListId = n.NewListId;
                    dataedit.ListType = "TREE";
                    dataedit.NewParentListId = n.NewParentListId;
                    dataedit.OldLineage = n.OldLineage;
                    dataedit.SortOrder = athoc.iws.hierarchydefinition.SortOrder++;

                    var node = treeview.findByUid(n.uid);

                    var kitems = $(node).parentsUntil('.k-treeview', '.k-item');
                    var parentcnt = 0;
                    var texts = $.map(kitems, function (kitem) {
                        //if (treeview.dataItem(kitem).ListId > 0) {
                        if (parentcnt == 0) {
                            dataedit.ParentListId = treeview.dataItem(kitem).ListId;
                            parentcnt++;
                        }
                        return $(kitem).find('>div span.child').text();

                    });

                    if (texts.length > 1) {
                        texts.pop();
                        var lineage = texts.reverse().join('/');
                        dataedit.Lineage = lineage == "" ? "/" : "/" + lineage + "/";// + dataedit.Name + "/";
                    }
                    else
                        dataedit.Lineage = "/";// + dataedit.Name + "/";

                    /*if (texts.length > 1) {
                        texts.pop();
                        var lineage = texts.reverse().join('/');
                        dataedit.Lineage = lineage == "" ? "/" : "/" + lineage + "/" + dataedit.Name + "/";
                    }
                    else
                        if (texts.length == 1)
                                dataedit.Lineage = "/"  + dataedit.Name + "/";
                            else
                                dataedit.Lineage = "/";
                                */

                    if ((dataedit.Lineage != n.Lineage) && (dataedit.Status != "N") && (dataedit.Status != "D"))
                        dataedit.Status = "M";
                    if (dataedit.Status == null) {
                        dataedit.SortOrder = athoc.iws.hierarchydefinition.SortOrder++;
                        dataedit.Status = "M";
                    }
                    if (dataedit.Status == null) {
                        dataedit.Status = "M";
                    }
                    saveelist.push(dataedit);

                    if (n.hasChildren)
                        athoc.iws.hierarchydefinition.treeToJson(n.children.view());
                });
            },

            //Method to verify duplicate node names
            checkDuplicate: function (nodes) {

                $.map(nodes, function (n, i) {
                    var node = treeview.findByUid(n.uid);

                    $.each(node.siblings(), function (i, s) {
                        if ((treeview.dataItem(s).Name != null) && (n.Name != null)) {
                            if (treeview.dataItem(s).Name.toUpperCase() == n.Name.toUpperCase()) {
                                treeview.select(node);
                                treeview.trigger('select', { node: node });
                                isDuplicate = true;
                                athoc.iws.hierarchydefinition.showErrorMessage(athoc.iws.hierarchydefinition.resources.UniqueNodeName);
                                return;
                            }
                        }
                    });

                    if (!isDuplicate && n.hasChildren)
                        athoc.iws.hierarchydefinition.checkDuplicate(n.children.view());
                });
            },

            //Method to handle save functionality
            //verify for duplicates in the same level then Save the details
            SaveDetails: function () {
                isDuplicate = false;
                $('#saveMessagePanel').html('');

                athoc.iws.hierarchydefinition.checkDuplicate(treeview.dataSource.view());

                if (isDuplicate)
                    return;
                athoc.iws.hierarchydefinition.SortOrder = 0;
                athoc.iws.hierarchydefinition.treeToJson(treeview.dataSource.view());

                var jsonData = { pldlistsettings: saveelist, hierarchytype: ihierarchytype };

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.hierarchydefinition.urls.cdnUrl + '/Images/ajax-loader.gif', top: '50%', left: '50%', displayText: athoc.iws.hierarchydefinition.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        //make a request to the server
                        url: athoc.iws.hierarchydefinition.urls.SaveHierarchyUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(jsonData),
                        success: function (data) {
                            if (data.Success) {
                                var tvds = eval(data.Data);
                                //treeview.setDataSource(tvds);
                                treeview.setDataSource(new kendo.data.HierarchicalDataSource({
                                    data: data.Data,
                                    schema: {
                                        model: {
                                            children: "Children",//the child nodes property in the data model

                                        },
                                    }
                                }));
                                treeview.expand(".k-item");
                                var root = $('.k-item:first');
                                treeview.select(root);
                                treeview.trigger('select', { node: root });
                                saveelist = new Array();
                                athoc.iws.hierarchydefinition.editmodel.isRefresh(false);
                                athoc.iws.hierarchydefinition.changeImageStatus("Refresh");
                                NewListId = 0;
                                $('#HierarchyEdit').modal('hide'); $('#saveMessagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.hierarchydefinition.resources.DistributionListsHierarchy_SaveSuccess }] });
                                $('#treeview').height(treeviewMaxHeight - $('#saveMessagePanel').height());
                                $("#saveMessagePanel").find('button.close').click(function () { athoc.iws.hierarchydefinition.hideErrorMessage() });
                                $(window).scrollTop(0);
                            }
                            else {
                                if (data.HasErrors) {
                                    $(window).scrollTop(0);
                                    var reqError = "";
                                    if (data.Messages[0].Value == undefined)
                                        reqError = data.Messages;
                                    else
                                        reqError = data.Messages[0].Value;
                                    saveelist = new Array();
                                    athoc.iws.hierarchydefinition.showErrorMessage(reqError);
                                }
                            }

                            $.AjaxLoader.hideLoader();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.hierarchydefinition.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

            },

            //to bind bread crumb
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.hierarchydefinition.breadcrumbModel;
                breadcrumbsModel.SelectedPage('viewHierarchyDefinition');
                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            //Method to handle node name changed
            onNameChange: function () {
                var selectedNode = treeview.select();
                treeview.dataItem(selectedNode).set('Name', $("#txtName").val());
                treeview.dataItem(selectedNode).set('Status', "M");
            },

            //Method to handle node changes
            onCommonChange: function () {
                var selectedNode = treeview.select();
                treeview.dataItem(selectedNode).set('CommonName', $("#txtCommon").val());
                treeview.dataItem(selectedNode).set('Status', "M");
            },

            //Method to handle node selection
            onSelect: function (e) {
                //clear the highlighted  text 
                $('span.child > span.highlight').each(function () {
                    $(this).parent().text($(this).parent().text());
                });
                var data = treeview.dataItem(e.node);
                $("#addNodes").removeAttr("disabled");
                flag = 1;
                var root = $('.k-item:first');;
                if (data != undefined) {
                    if (data.uid == (treeview.dataItem(root)).uid) {
                        athoc.iws.hierarchydefinition.editmodel.isDelete(false);
                        athoc.iws.hierarchydefinition.editmodel.isRefresh(false);
                    }
                    else
                        athoc.iws.hierarchydefinition.editmodel.isDelete(true);
                    //Clear the search text
                    $("#txtSearch").val("");
                    $("#btn_search").attr("disabled", true);
                    athoc.iws.hierarchydefinition.isInEdit = false;
                }
                if (data != null) {
                    dataedit.ListId = data.ListId;
                    dataedit.Name = $.htmlEncode(data.Name);
                    dataedit.CommonName = $.htmlEncode(data.CommonName);
                    dataedit.ParentListId = data.ParentListId;
                    dataedit.OldLineage = data.OldLineage;
                    if (dataedit.status != "N")
                        dataedit.NewParentListId = data.ParentListId;
                    else
                        dataedit.NewParentListId = data.NewParentListId;

                    dataedit.HierarchyId = data.HierarchyId;
                    dataedit.imageUrl = data.imageUrl;
                    flag = 0;
                    //4th level Node is not allowed 
                    /*if (data.level() == 3)
                        $("#addNodes").attr("disabled", "disabled");*/
                }

                athoc.iws.hierarchydefinition.changeImageStatus('Del');
                athoc.iws.hierarchydefinition.changeImageStatus('Refresh');
                $("#btn_Save").attr("disabled", false);
            },

            //to change image status
            changeImageStatus: function (type) {
                if (type == 'Del') {
                    if (athoc.iws.hierarchydefinition.editmodel.isDelete()) {
                        $("#deleteNode").removeAttr("disabled");
                        $("#deleteNode").css("cursor", "pointer");
                    }
                    else {
                        $("#deleteNode").attr("src", "/athoc-cdn/images/icon_minus_dis.png");

                        $("#deleteNode").attr("disabled", "disabled");
                    }

                } 

                if (type == 'Refresh') {
                    if (athoc.iws.hierarchydefinition.editmodel.isRefresh()) {
                        $("#refreshNode").removeAttr("disabled");
                        $("#refreshNode").css("cursor", "pointer");
                    }
                    else {

                        $("#refreshNode").attr("disabled", "disabled");
                        $("#refreshNode").css("cursor", "");
                    }
                }

            },

            //to resize model window
            resizeModalBasedOnScreen: function () {
                var modal = $('#HierarchyEdit');
                modal.find(".modal-body").css("max-height", 600);
                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 20 - (windowHeight / 2) + ((windowHeight - 800) / 2));
                } else {
                    modal.css("margin-top", 20 - (windowHeight / 2));
                }
                treeviewMaxHeight = windowHeight * (45 / 100);

                if (modal.height() + 170 > windowHeight) {
                    windowHeight = windowHeight - 210;
                    modal.find(".modal-body").css("max-height", windowHeight);
                    treeviewMaxHeight = windowHeight * (66 / 100);

                }

                $("#treeview").height(treeviewMaxHeight);
            },

            //
            moveCursorToEnd: function moveCursorToEnd(el) {
                window.setTimeout(function () {
                    if (typeof el.selectionStart == "number") {
                        el.selectionStart = el.selectionEnd = el.value.length;
                    } else if (typeof el.createTextRange != "undefined") {
                        var range = el.createTextRange();
                        range.collapse(false);
                        range.select();
                    }
                }, 1);
            },

            //to load hierarchy
            OpenHierarchy: function (type) {
                ihierarchytype = type;
                saveelist = new Array();
                
                //show the loader when we make a request to the server..
                athoc.iws.hierarchydefinition.GetDataTreeview(type);

            },

            //bind tree data
            GetDataTreeview: function (type) {
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.hierarchydefinition.urls.cdnUrl + '/Images/ajax-loader.gif', top: '50%', left: '50%', displayText: athoc.iws.hierarchydefinition.resources.General_LoadingMessage }).showLoader();


                var dlAjaxOption =
                    {   //make a request to the server
                        type: "post",
                        url: athoc.iws.hierarchydefinition.urls.GetHierarchyUrl,
                        data: { "hierarchytype": ihierarchytype },
                        dataType: "json",
                        success: function (data) {
                            switch (type) {
                                case 0:
                                    $("#Title").html(athoc.iws.hierarchydefinition.resources.Organizational_Hierarchy);
                                    break;
                                case 1:
                                    $("#Title").html(athoc.iws.hierarchydefinition.resources.Distribution_List);
                                    break;
                                case 2:
                                    $("#Title").html(athoc.iws.hierarchydefinition.resources.Location_List);

                                    break;
                            }
                            if (data.Success) {
                                var tvds = eval(data.Data);
                                //treeview.setDataSource(tvds);
                                treeview.setDataSource(new kendo.data.HierarchicalDataSource({
                                    data: data.Data,
                                    schema: {
                                        model: {
                                            children: "Children",//the child nodes property in the data model                                                
                                        },
                                    }
                                }));
                                treeview.expand(".k-item");
                                var root = $('.k-item:first');
                                treeview.select(root);
                                treeview.trigger('select', { node: root });
                                saveelist = new Array();
                            }
                            else {
                                if (data.HasErrors) {
                                    treeview.setDataSource({});
                                    athoc.iws.hierarchydefinition.showErrorMessage(data.Messages);
                                }
                            }
                            $.AjaxLoader.hideLoader();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            treeview.setDataSource({});
                            athoc.iws.hierarchydefinition.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },

            //Method to handle error and session time out, this is boud with Ajax calls
            handleError: function (e) {

                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else if (e.errorThrown != undefined && e.errorThrown != "") {
                    if (athoc.iws.hierarchydefinition.errors === null) {
                        athoc.iws.hierarchydefinition.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.hierarchydefinition.errors.push({ Type: '4', Value: e.errorThrown });
                    }

                    athoc.iws.hierarchydefinition.showErrorMessage(this.errors);
                } else if (e.responseText != undefined && e.responseText != "") {
                    athoc.iws.hierarchydefinition.showErrorMessage(e.responseText);
                }
            },

            //Method to show the error panel
            showErrorMessage: function (errorType) {
                var errorMessageText = errorType;
                var reqError = new Array();
                reqError.push({ Type: '4', Value: errorMessageText });
                $('#saveMessagePanel').messagesPanel({ messages: ($.isArray(errorType) ? errorType : reqError) });
                $('#treeview').height(treeviewMaxHeight - $('#saveMessagePanel').height());
                $("#saveMessagePanel").find('button.close').click(function () { athoc.iws.hierarchydefinition.hideErrorMessage() });

            },

            //Method to hide the error panel
            hideErrorMessage: function () {
                $('#saveMessagePanel').html('');
                $('#treeview').height(treeviewMaxHeight);
            },
            //to Display empty tree message
            displayEmptyMessage: function (isNew) { 
                $("#divNoData").remove();
                if ($("#treeview").data("kendoTreeView").root.children().children().length == 1 && isNew == undefined)
                    $("#treeview").append("<div id=\"divNoData\" style=\"width: 100%; height:275px; text-align: center; display: table;\"><span class=\"section-desc\" style=\"vertical-align: middle; display: table-cell;\">" + athoc.iws.hierarchydefinition.resources.UserAttributeManager_Treeview_NoDataFound + "</span></div>");
            },
        };
    }();
}