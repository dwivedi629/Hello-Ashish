﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.weatherModule = athoc.iws.weatherModule || {};

if (athoc.iws.weatherModule) {

    //Root class of this functionality
    athoc.iws.weatherModule = function () {
        return {
            geoGridPageSize: 20,
            // ViewModel for this page
            viewModel: {

                createEventTypeRule:
                    {
                        personalEventCancel: function () { athoc.iws.weatherModule.personalEventCancel(); },
                        eventRuleSave: function () { athoc.iws.weatherModule.eventRuleSave(); },
                        msgCheckboxAttr: {
                            clsWarning_Urgency: ko.observable(),
                            clsWarning_Severity: ko.observable(),
                            clsWarning_Certainty: ko.observable(),
                        },
                        eventTypeAttribute:
                            {
                                customRuleName: ko.observable(),
                                optionalKey: ko.observable(),
                                urgencyAttributes: 'None',
                                severityAttributes: 'None',
                                certaintyAttributes: 'None',
                                errorMsg: ko.observable(),
                            },
                        urgencyCheckboxAttr: ko.observableArray(
                                [
                                    { Name: ko.observable('Immediate'), isSelected: ko.observable(false), isDisable: ko.observable(false) },
                                    { Name: ko.observable('Expected'), isSelected: ko.observable(false), isDisable: ko.observable(false) }, { Name: ko.observable('Future'), isSelected: ko.observable(false), isDisable: ko.observable(false) },
                                    { Name: ko.observable('Past'), isSelected: ko.observable(false), isDisable: ko.observable(false) }, { Name: ko.observable('Unknown'), isSelected: ko.observable(false), isDisable: ko.observable(false) },
                                ]),

                        severityCheckboxAttr: ko.observableArray(
                               [
                                   { Name: ko.observable('Extreme'), isSelected: ko.observable(false), isDisable: ko.observable(false) },
                                   { Name: ko.observable('Severe'), isSelected: ko.observable(false), isDisable: ko.observable(false) }, { Name: ko.observable('Moderate'), isSelected: ko.observable(false), isDisable: ko.observable(false) },
                                   { Name: ko.observable('Minor'), isSelected: ko.observable(false), isDisable: ko.observable(false) }, { Name: ko.observable('Unknown'), isSelected: ko.observable(false), isDisable: ko.observable(false) },
                               ]),

                        certaintyCheckboxAttr: ko.observableArray(
                               [
                                   { Name: ko.observable('Very Likely'), isSelected: ko.observable(false), isDisable: ko.observable(false) },
                                   { Name: ko.observable('Likely'), isSelected: ko.observable(false), isDisable: ko.observable(false) }, { Name: ko.observable('Probable'), isSelected: ko.observable(false), isDisable: ko.observable(false) },
                                   { Name: ko.observable('Possible'), isSelected: ko.observable(false), isDisable: ko.observable(false) }, { Name: ko.observable('Unknown'), isSelected: ko.observable(false), isDisable: ko.observable(false) },
                               ]),

                        allSelectedUrgency: ko.observable(false),

                        selectAllUrgency: function () {
                            var all = this.allSelectedUrgency();
                            ko.utils.arrayForEach(this.urgencyCheckboxAttr(), function (item) {
                                item.isSelected(all);
                                item.isDisable(all);
                            });
                            return true;
                        },

                        allSelectedSeverity: ko.observable(false),

                        selectAllSeverity: function () {
                            var all = this.allSelectedSeverity();
                            ko.utils.arrayForEach(this.severityCheckboxAttr(), function (item) {
                                item.isSelected(all);
                                item.isDisable(all);
                            });
                            return true;
                        },

                        allSelectedcertainty: ko.observable(false),

                        selectAllCertainty: function () {
                            var all = this.allSelectedcertainty();
                            ko.utils.arrayForEach(this.certaintyCheckboxAttr(), function (item) {
                                item.isSelected(all);
                                item.isDisable(all);
                            });
                            return true;
                        },
                    },

                geoCodesFinder:
                    {
                        geoCodeFinderSaveDisable: ko.observable(true),
                        geoCodeFinderSave: function () { athoc.iws.weatherModule.geoCodeFinderSave(); },
                        geoCodeSearch: function () { athoc.iws.weatherModule.geoCodeSearch(); },
                        searchClearAll: function () { athoc.iws.weatherModule.searchClearAll(); },
                        stateList: ko.observableArray([]),
                        selectedState: ko.observable(''),
                        zipCodeText: ko.observable(),
                        noOfSelectedgeoCodes: ko.observable(0),
                        gridGeoCode: ko.observableArray([]),
                        geoCodeCancel: function () { athoc.iws.weatherModule.geoCodeCancel(); },
                    },

                weatherAlertPrefrence:
                    {
                        typesOfEvents: ko.observableArray([]),
                        locationGeoCodes: ko.observable(),
                        publishForBadLocation: ko.observable(false),
                        publishForBadLocationText: ko.observable(''),
                        targetOptions:
                            {
                                groupNames: ko.observable(''),
                                isGroupNameChecked: ko.observable(false),
                                subscribedEndUser: ko.observable(false),
                                subscribedEndUserBasedOnLocation: ko.observable(false),
                                associatedFolderAlerts: ko.observableArray([]),
                                isFolderAlertChecked: ko.observable(false),
                                selectedAlertId: ko.observable(''),
                                isMatchedWeatherEventLocation: ko.observable(),
                                checkedTargetOptionValue:"",

                            },
                        eventRules: ko.observableArray([]),//This will add all custom rules

                        openEventRulePopup: function () { athoc.iws.weatherModule.openEventRulePopup(); },

                        closediv: function (idOfRootDiv, event) { athoc.iws.weatherModule.closediv(idOfRootDiv, event); },

                        openGeoCodePopup: function () { athoc.iws.weatherModule.openGeoCodePopup(); },

                        selectedAgentInfo: ko.observable(),

                        selectedFolderId: ko.observable(0),

                        disableWeather: ko.observable(false),

                        disableWeatherText: ko.observable(false),

                        saveWeatherSettings: function () { athoc.iws.weatherModule.saveWeatherSettings(); },

                        closeWarningModalPopup: function () { athoc.iws.weatherModule.closeWarningModalPopup(); },

                        msgWAP: {
                            warning_geoCode: ko.observable(),
                            warning_locationTxt: ko.observable(),
                            warning_groupName: ko.observable(),
                        },
                    },

            },

            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for scenario list, will be triggered before document load
            init: function () {


            },

            closediv: function (dataOfSelectedRow, event) {
                $("#" + ko.contextFor(event.target).$index()).remove();
                var updatedlist = athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.eventRules();
                updatedlist = _.reject(updatedlist, function (d) { return d.customRuleName === dataOfSelectedRow.customRuleName; });
                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.eventRules([]);
                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.eventRules(updatedlist);
            },

            //load method, will be tirggered on document load
            load: function () {

                //binding the main weather alert  preference page
                ko.cleanNode($("#alertPrefMainPage").get(0));
                ko.applyBindings(athoc.iws.weatherModule.viewModel.weatherAlertPrefrence, $("#alertPrefMainPage").get(0));

                //binding the custom rule page
                ko.cleanNode($("#addrule").get(0));
                ko.applyBindings(athoc.iws.weatherModule.viewModel.createEventTypeRule, $("#addrule").get(0));

                //binding the code finder page
                ko.cleanNode($("#geocodeFinder").get(0));
                ko.applyBindings(athoc.iws.weatherModule.viewModel.geoCodesFinder, $("#geocodeFinder").get(0));

                //$('#ddlStates').selectpicker({});
                //$('#ddlFolderAlerts').selectpicker({});

                athoc.iws.weatherModule.subscribeValidationObject();

            },

            isEventRuleValidated: function () {

                athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.errorMsg('');
                var objEventRule = ko.validation.group(athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.customRuleName, { deep: true });

                if ((objEventRule().length > 0) && (objEventRule()[0] != null)) {
                    athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.errorMsg(objEventRule()[0]);
                    return false;
                }

                objEventRule = ko.validation.group(athoc.iws.weatherModule.viewModel.createEventTypeRule.urgencyCheckboxAttr, { deep: true });

                if ((objEventRule().length > 0) && (objEventRule()[0] != null)) {
                    return false;
                }

                objEventRule = ko.validation.group(athoc.iws.weatherModule.viewModel.createEventTypeRule.severityCheckboxAttr, { deep: true });

                if ((objEventRule().length > 0) && (objEventRule()[0] != null)) {
                    return false;
                }

                objEventRule = ko.validation.group(athoc.iws.weatherModule.viewModel.createEventTypeRule.certaintyCheckboxAttr, { deep: true });

                if ((objEventRule().length > 0) && (objEventRule()[0] != null)) {
                    return false;
                }

                objEventRule = _.filter(athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.eventRules(), function (item) {
                    return item.customRuleName == athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.customRuleName();
                });


                if ((objEventRule != undefined) && (objEventRule.length > 0)) {
                    athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.errorMsg('Duplicate event not allowed.');
                    return false;
                }

                return true;
            },

            eventRuleSave: function () {

                if (athoc.iws.weatherModule.isEventRuleValidated() == false) return false;

                // For urgent Attribute
                var urgencyAttr = _.filter(athoc.iws.weatherModule.viewModel.createEventTypeRule.urgencyCheckboxAttr(), function (item) {
                    return item.isSelected() == true;
                });

                if ((urgencyAttr != undefined) && (urgencyAttr.length > 0)) {
                    if ((athoc.iws.weatherModule.viewModel.createEventTypeRule.urgencyCheckboxAttr().length > urgencyAttr.length))
                        athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.urgencyAttributes = _.pluck(ko.mapping.toJS(urgencyAttr), 'Name').join(",");
                    else
                        athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.urgencyAttributes = "All";
                }

                //End Urgent Attribute

                // For servityAttr Attribute
                var servityAttr = _.filter(athoc.iws.weatherModule.viewModel.createEventTypeRule.severityCheckboxAttr(), function (item) {
                    return item.isSelected() == true;
                });

                if ((servityAttr != undefined) && (servityAttr.length > 0)) {
                    if ((athoc.iws.weatherModule.viewModel.createEventTypeRule.severityCheckboxAttr().length > servityAttr.length))
                        athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.severityAttributes = _.pluck(ko.mapping.toJS(servityAttr), 'Name').join(",");
                    else
                        athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.severityAttributes = "All";
                }
                //End servityAttr Attribute

                // For certainty Attribute
                var certaintyAttr = _.filter(athoc.iws.weatherModule.viewModel.createEventTypeRule.certaintyCheckboxAttr(), function (item) {
                    return item.isSelected() == true;
                });

                if ((certaintyAttr != undefined) && (certaintyAttr.length > 0)) {
                    if ((athoc.iws.weatherModule.viewModel.createEventTypeRule.certaintyCheckboxAttr().length > certaintyAttr.length))
                        athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.certaintyAttributes = _.pluck(ko.mapping.toJS(certaintyAttr), 'Name').join(",");
                    else
                        athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.certaintyAttributes = "All";
                }
                //End certainty Attribute


                var key = athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.optionalKey();
                if (key == "")
                    athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.optionalKey("None");

                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.eventRules.push(ko.mapping.toJS(athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute));

                athoc.iws.weatherModule.closeModalPopup('addrule', 'alertPrefMainPage');

            },

            geoCodeFinderSave: function () {
                var selectedItem = new Array();
                var gridData = $('#geoCodeGrid').data().kendoGrid.dataSource.data();

                $.each(gridData, function (i, item) {
                    if (item.IsChecked)
                        selectedItem.push(item.GeoCode);
                });

                if (selectedItem.length > 0) {
                    // Start Fix for IWS-21680
                    var extraComma=", ";
                    if (!athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.locationGeoCodes().trim()) {
                        extraComma = "";
                    }
                    var items = athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.locationGeoCodes() + extraComma + selectedItem.join(', ');
                    // End Fix for IWS-21680

                    athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.locationGeoCodes(items);
                    athoc.iws.weatherModule.closeModalPopup('geocodeFinder', 'alertPrefMainPage');
                }
            },

            geoCodeSearch: function () {
                var IdOfdiv = "geoCodeGrid";
                $("#" + IdOfdiv).append('<div id="shawodOf_' + IdOfdiv + '"  class="modal-backdrop fade in"><div class="LoadingImage_Overlay"><img src= ' + athoc.iws.weatherModule.urls.cdnUrl + "Images/ajax-loader.gif" + '></img></div></div>');

                var jsonData = { objCriteria: { StateCode: '' + athoc.iws.weatherModule.viewModel.geoCodesFinder.selectedState() + '', ZipCode: athoc.iws.weatherModule.viewModel.geoCodesFinder.zipCodeText() } };

                var dlAjaxOption =
                    {
                        url: athoc.iws.weatherModule.urls.SearchGeoCodeURL,
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            athoc.iws.weatherModule.viewModel.geoCodesFinder.gridGeoCode([]);
                            if (data.Success) {
                                athoc.iws.weatherModule.viewModel.geoCodesFinder.gridGeoCode.push.apply(athoc.iws.weatherModule.viewModel.geoCodesFinder.gridGeoCode, data.Data);
                            }

                            // Bind grid
                            athoc.iws.weatherModule.bindGeoGrid();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.channelManager.handleError(e);
                            $("#" + IdOfdiv).find('#shawodOf_' + IdOfdiv).remove();
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);

                $.ajax(ajaxOptions);

                return true;
            },

            searchClearAll: function () {
                athoc.iws.weatherModule.viewModel.geoCodesFinder.geoCodeFinderSaveDisable(true);
                athoc.iws.weatherModule.viewModel.geoCodesFinder.noOfSelectedgeoCodes(0);
                athoc.iws.weatherModule.viewModel.geoCodesFinder.zipCodeText('');
                $('#chkAllGeoCodes').prop('checked', false);
                athoc.iws.weatherModule.viewModel.geoCodesFinder.selectedState(0);
                $('#ddlStates').selectpicker('refresh');
                if (athoc.iws.weatherModule.viewModel.geoCodesFinder.gridGeoCode().length > 0)
                    athoc.iws.weatherModule.bindGeoGrid();
            },

            getAlertPrefrenceDetails: function (agentId, fId) {
                var jsonData = { AgentId: agentId, FolderId: fId };
                var dlAjaxOption =
                    {
                        url: athoc.iws.weatherModule.urls.GetAlertingPreferenceInfoUrl,
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            if (data.Success) {
                                athoc.iws.weatherModule.viewModel.geoCodesFinder.stateList([]);
                                athoc.iws.weatherModule.viewModel.geoCodesFinder.stateList.push.apply(athoc.iws.weatherModule.viewModel.geoCodesFinder.stateList, data.Data.StatesList);
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.typesOfEvents([]);
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.typesOfEvents.push.apply(athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.typesOfEvents, data.Data.EventList);
                                $("#ddlFolderAlerts").find(".bootstrap-select").remove();
                                $('#ddlFolderAlerts').val([]);
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isFolderAlertChecked(data.Data.TargetOptions.isFolderAlertChecked);
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked(data.Data.TargetOptions.isGroupNameChecked);
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.
                                    targetOptions.associatedFolderAlerts([]);
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.
                                    targetOptions.associatedFolderAlerts
                                     .push.apply(athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.
                                     associatedFolderAlerts, data.Data.ListFolderAlerts);

                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.groupNames(data.Data.TargetOptions.GroupNames != null ? $.trim(data.Data.TargetOptions.GroupNames) : '');
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUser(data.Data.TargetOptions.AllSubscribeUser);


                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.
                                    targetOptions.subscribedEndUserBasedOnLocation(data.Data.TargetOptions.UserBasedOnLocation);

                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.
                                    targetOptions.isMatchedWeatherEventLocation(data.Data.TargetOptions.isMatchedWeatherEventLocation);

                              


                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.locationGeoCodes(data.Data.LocationGeoCodes != null ? $.trim(data.Data.LocationGeoCodes) : '');

                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.publishForBadLocation(data.Data.PublishForBadCondition);
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.publishForBadLocationText(data.Data.PublishForBadConditionText);
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.selectedAlertId(data.Data.TargetOptions.SelectedAlertId);
                                $('#ddlFolderAlerts').selectpicker('refresh');
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.disableWeather(data.Data.ChannelDisable);
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.disableWeatherText(data.Data.ChannelDisable);
                                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.eventRules([]);
                                if ((data.Data.PersonalizedEventList != null) && (data.Data.PersonalizedEventList.length > 0)) {
                                    _.each(data.Data.PersonalizedEventList, function (item) {
                                        athoc.iws.weatherModule.viewModel.createEventTypeRule.
                                            eventTypeAttribute.customRuleName(item.EventName);
                                        athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.
                                            certaintyAttributes = item.CertaintyValues != null ? item.CertaintyValues : 'All';
                                        athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.
                                           severityAttributes = item.SeverityValues != null ? item.SeverityValues : 'All';
                                        athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.
                                           urgencyAttributes = item.UrgencyValues != null ? item.UrgencyValues : 'All';
                                        athoc.iws.weatherModule.viewModel.createEventTypeRule.
                                            eventTypeAttribute.optionalKey(item.Keywords == "" ? "None" : item.Keywords);
                                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.eventRules.push(ko.mapping.toJS(athoc.iws.weatherModule.viewModel.
                                            createEventTypeRule.eventTypeAttribute));
                                    });
                                }
                                athoc.iws.weatherModule.registerCollapse();
                                $('#chkDisable').prop('checked', false);
                                if (data.Data.ChannelDisable == true) {
                                    athoc.iws.weatherModule.showModalPopup('informationDialog');
                                }
                            }
                            $("#alertPrefMainPage").find('#shawodOf_alertPrefMainPage').remove();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.channelManager.handleError(e);
                            $("#alertPrefMainPage").find('#shawodOf_alertPrefMainPage').remove();
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);

                $.ajax(ajaxOptions);

                return true;
            },

            ComputeRadioValues: function () {
                self.IsGlobalCheckbox = ko.computed({
                    read: function () {
                        return athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUserBasedOnLocation() + "";
                    },
                    write: function (v) {
                        if (v == "true") self.IsGlobal(true)
                        else self.IsGlobal(false)
                    }
                });

            },

            openEventRulePopup: function () {
                athoc.iws.weatherModule.validateEventRuleControls();
                athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.errorMsg('');
                athoc.iws.weatherModule.viewModel.createEventTypeRule.allSelectedcertainty(true);
                athoc.iws.weatherModule.viewModel.createEventTypeRule.selectAllCertainty();
                athoc.iws.weatherModule.viewModel.createEventTypeRule.allSelectedSeverity(true);
                athoc.iws.weatherModule.viewModel.createEventTypeRule.selectAllSeverity();
                athoc.iws.weatherModule.viewModel.createEventTypeRule.allSelectedUrgency(true);
                athoc.iws.weatherModule.viewModel.createEventTypeRule.selectAllUrgency();
                athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.customRuleName('');
                athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.optionalKey('');
                athoc.iws.weatherModule.showModalPopup('addrule', 10, 'alertPrefMainPage');
            },

            openGeoCodePopup: function () {
                athoc.iws.weatherModule.viewModel.geoCodesFinder.geoCodeFinderSaveDisable(true);
                $('#chkAllGeoCodes').prop('checked', false);
                $("#ddlStates").find(".bootstrap-select").remove();
                $('#ddlStates').val([]);
                $('#ddlStates').selectpicker('refresh');
                athoc.iws.weatherModule.viewModel.geoCodesFinder.noOfSelectedgeoCodes(0);
                athoc.iws.weatherModule.viewModel.geoCodesFinder.gridGeoCode([]);
                athoc.iws.weatherModule.bindGeoGrid();
                athoc.iws.weatherModule.showModalPopup('geocodeFinder', 10, 'alertPrefMainPage');
            },

            // Generic method to open the popup page
            showModalPopup: function (IdOfdiv, intervalTime, parentDivId) {
                if (intervalTime == undefined)
                    intervalTime = 10;
                $('#' + IdOfdiv).show();
                $('#' + IdOfdiv).modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {

                    }, intervalTime);
                });

                if (parentDivId != undefined) {
                    $('#' + parentDivId).append($("<div class='modal-backdrop fade in'></div>"));
                }

            },

            displayWeatherModuleSettings: function () {
                var IdOfdiv = 'alertPrefMainPage';

                $("#" + IdOfdiv).append('<div id="shawodOf_' + IdOfdiv + '"  class="modal-backdrop fade in"><div class="LoadingImage_Overlay"><img src= ' + athoc.iws.weatherModule.urls.cdnUrl + "Images/ajax-loader.gif" + '></img></div></div>');

                $('#' + IdOfdiv).show();
                $('#' + IdOfdiv).modal({
                    keyboard: true
                }).promise().done(function () {
                    athoc.iws.weatherModule.initialLoadControls();
                });

            },

            // Generic method to open the popup page
            closeModalPopup: function (IdOfdiv, parentDivId) {
                $('#' + IdOfdiv).modal('hide');
                if (parentDivId != undefined) {
                    $('#' + parentDivId + " .modal-backdrop").remove();
                }
                athoc.iws.weatherModule.registerCollapse();
            },

            validateEventRuleControls: function () {

                //Validate the controls on Add and duplicate popup
                athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.customRuleName.extend({
                    required: {
                        params: true,
                        message: 'Required'
                    },
                    validation: {
                        validator: athoc.iws.weatherModule.lengthValidation,
                        message: 'char length should between 3 and 62',
                        params: [3, 62]
                    },
                });

                athoc.iws.weatherModule.viewModel.createEventTypeRule.urgencyCheckboxAttr.extend({
                    validation: {
                        validator: athoc.iws.weatherModule.checkboxMandatory,
                        message: 'choose one of urgency',
                        params: [athoc.iws.weatherModule.viewModel.createEventTypeRule.urgencyCheckboxAttr(), 'clsWarning_Urgency']
                    },
                });

                athoc.iws.weatherModule.viewModel.createEventTypeRule.certaintyCheckboxAttr.extend({
                    validation: {
                        validator: athoc.iws.weatherModule.checkboxMandatory,
                        message: 'choose one of certainty',
                        params: [athoc.iws.weatherModule.viewModel.createEventTypeRule.certaintyCheckboxAttr(), 'clsWarning_Certainty']
                    },
                });

                athoc.iws.weatherModule.viewModel.createEventTypeRule.severityCheckboxAttr.extend({
                    validation: {
                        validator: athoc.iws.weatherModule.checkboxMandatory,
                        message: 'choose one of severity',
                        params: [athoc.iws.weatherModule.viewModel.createEventTypeRule.severityCheckboxAttr(), 'clsWarning_Severity']
                    },
                });

                athoc.iws.weatherModule.viewModel.createEventTypeRule.eventTypeAttribute.customRuleName.subscribe(
                      function () {
                          athoc.iws.weatherModule.isEventRuleValidated();
                      });
            },

            validateWAPControls: function () {
                var isValid = true;
                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_geoCode('');
                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_locationTxt('');
                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_groupName('');
                //Validate the controls on Add and duplicate popup
                if (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.locationGeoCodes().length == 0) {
                    athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_geoCode('Required');
                    isValid = false;
                }

                if (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.publishForBadLocation() && (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.publishForBadLocationText().length == 0)) {
                    athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_locationTxt('Required');
                    isValid = false;
                }

                if (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked() && (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.groupNames().length == 0)) {
                    athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_groupName('Required');
                    isValid = false;
                }

                return isValid;
            },

            checkboxMandatory: function (objItem, msg) {

                var item = _.find(objItem, function (item) {
                    return item.isSelected() == true;
                });

                athoc.iws.weatherModule.viewModel.createEventTypeRule.msgCheckboxAttr.clsWarning_Severity('');
                athoc.iws.weatherModule.viewModel.createEventTypeRule.msgCheckboxAttr.clsWarning_Certainty('');
                athoc.iws.weatherModule.viewModel.createEventTypeRule.msgCheckboxAttr.clsWarning_Urgency('');

                if (item == undefined) {
                    if (msg[1] == 'clsWarning_Severity') {
                        athoc.iws.weatherModule.viewModel.createEventTypeRule.msgCheckboxAttr.clsWarning_Severity('warning');
                    }
                    else if (msg[1] == 'clsWarning_Certainty') {
                        athoc.iws.weatherModule.viewModel.createEventTypeRule.msgCheckboxAttr.clsWarning_Certainty('warning');
                    }
                    else if (msg[1] == 'clsWarning_Urgency') {
                        athoc.iws.weatherModule.viewModel.createEventTypeRule.msgCheckboxAttr.clsWarning_Urgency('warning');
                    }

                    return false;
                }
                return true;
            },

            //check the length of string
            lengthValidation: function (str, minChar) {
                if (athoc.iws.weatherModule.getCharCount(str) < minChar[0] ||
                    athoc.iws.weatherModule.getCharCount(str) > minChar[1])
                    return false;
                return true;
            },

            //get character based on ascii value
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },

            bindGeoGrid: function () {
                var IdOfdiv = "geoCodeGrid";
                var sortState = '';
                var geoData = athoc.iws.weatherModule.viewModel.geoCodesFinder.gridGeoCode();

                var geoDataSource = new kendo.data.DataSource({
                    data: geoData,
                    pageSize: athoc.iws.weatherModule.geoGridPageSize,
                    error: function (e) {
                        alert('Hi');
                    },
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }
                        athoc.iws.weatherModule.retainSelectAll();
                    },

                });

                $("#geoCodeGrid").html('');//Mandatory Line for client side correct paging

                $("#geoCodeGrid").kendoGrid({
                    dataSource: geoDataSource,
                    scrollable: true,
                    sortable: true,
                    filterable: false,
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: "{0} - {1} of {2} items",
                            itemsPerPage: "items per page",
                            empty: "No Matches Found",
                            first: $.htmlDecode("Go to the first page"),
                            previous: $.htmlDecode("Go to the previous page"),
                            next: $.htmlDecode("Go to the next page"),
                            last: $.htmlDecode("Go to the last page"),
                        }
                    },
                    columns: [
                                {
                                    field: "IsChecked",
                                    template: $("#chkMultipleGeoCode").html(),
                                    width: 10,
                                    title: "",
                                    headerTemplate: kendo.format('<input type="checkbox" class="senario-select" id="chkAllGeoCodes" title="{0}" onclick="athoc.iws.weatherModule.SelectAllGeoCodes();" />', ""),
                                    sortable: false,
                                    headerAttributes: {
                                        style: "cursor: default",
                                    }
                                },
                                {
                                    field: "StateName",
                                    title: "State Name",
                                    width: 30,
                                },

                                {
                                    field: "CountryName",
                                    title: "Country Name",
                                    width: 30,
                                },
                                {
                                    field: "GeoCode",
                                    title: "Geo Code",
                                    width: 30,
                                },
                    ],
                    dataBound: athoc.iws.weatherModule.OnDataBound,
                    change: function (e) {
                    }

                }).data().kendoGrid;

                $("#geoCodeGrid").kendoTooltip({
                    filter: ".cellTooltip",
                });

                $("#geoPageInfo").kendoPager({
                    dataSource: geoDataSource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: "Showing {0} - {1} of {2} items",
                        empty: "No data found"
                    }
                });


                //geoDataSource.read();
                $('#geoCodeGrid  .k-grid-header').css("width", "100%");
                $('#geoPageInfo').removeAttr('class');
                $("#" + IdOfdiv).find('#shawodOf_' + IdOfdiv).remove();
                $('#geocodeFinder .modal-body').attr("style", "overflow:visible;max-height:330px !important");
                $('#geocodeFinder .k-grid-content').attr("style", "height:170px;overflow-y:auto !important");
            },

            //On Grid databound navigate to Edit page or View page w.r.t device Type
            OnDataBound: function () {

                $("#geoCodeGrid tbody").find("tr").attr("tabindex", "0");
                var grid = $("#geoCodeGrid").data("kendoGrid");
                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(grid.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + "No record found." + '</td></tr>');
                }

            },

            //Select All check boxes in the grid
            SelectAllGeoCodes: function () {

                var checked = $('#chkAllGeoCodes').is(':checked');
                var grid = $('#geoCodeGrid').data().kendoGrid;
                $.each(grid.dataSource.view(), function (i, item) {
                    item.IsChecked = checked;
                });

                $('#geoCodeGrid').data().kendoGrid.refresh();

                if (checked) {
                    var noOfSelected = 0;
                    $.each(grid.dataSource.data(), function (i, item) {
                        if (item.IsChecked) {
                            noOfSelected++;
                        }
                    });


                    athoc.iws.weatherModule.viewModel.geoCodesFinder.noOfSelectedgeoCodes(noOfSelected);
                    grid.dataSource.data().length > 0 ? athoc.iws.weatherModule.viewModel.geoCodesFinder.geoCodeFinderSaveDisable(false) : null;
                }
                else {
                    var isAnyItemSeelcted = true;
                    $.each(grid.dataSource.data(), function (i, item) {
                        if (item.IsChecked) {
                            isAnyItemSeelcted = false;
                            return;
                        }
                    });

                    athoc.iws.weatherModule.viewModel.geoCodesFinder.geoCodeFinderSaveDisable(isAnyItemSeelcted);
                    athoc.iws.weatherModule.viewModel.geoCodesFinder.noOfSelectedgeoCodes(athoc.iws.weatherModule.viewModel.geoCodesFinder.noOfSelectedgeoCodes() - grid.dataSource.view().length);
                }

            },

            //check box selection 
            selectGeoCode: function (geoCodeValue) {
                var checked = $('#' + geoCodeValue).is(':checked');
                $('#chkAllGeoCodes').attr('checked', false);
                var grid = $('#geoCodeGrid').data().kendoGrid;

                $.each(grid.dataSource.view(), function (i, item) {
                    if (geoCodeValue == item.GeoCode) {
                        item.IsChecked = checked;
                        return;
                    }
                });
                var noOfItem = athoc.iws.weatherModule.viewModel.geoCodesFinder.noOfSelectedgeoCodes();

                if (checked)
                    noOfItem = noOfItem + 1;
                else
                    noOfItem = noOfItem - 1;

                athoc.iws.weatherModule.viewModel.geoCodesFinder.noOfSelectedgeoCodes(noOfItem);

                if (athoc.iws.weatherModule.viewModel.geoCodesFinder.noOfSelectedgeoCodes() == grid.dataSource.view().length)
                    $('#chkAllGeoCodes').attr('checked', true);

                var isAnyItemSeelcted = true;
                $.each(grid.dataSource.data(), function (i, item) {
                    if (item.IsChecked) {
                        isAnyItemSeelcted = false;
                        return;
                    }
                });

                athoc.iws.weatherModule.viewModel.geoCodesFinder.geoCodeFinderSaveDisable(isAnyItemSeelcted);
            },

            initialLoadControls: function () {
                var agentInfo = athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.selectedAgentInfo();
                if (agentInfo != undefined) {
                    athoc.iws.weatherModule.getAlertPrefrenceDetails(agentInfo.agentId, athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.selectedFolderId());
                }
            },

            saveWeatherSettings: function () {

                var allWell = athoc.iws.weatherModule.validateWAPControls();
                if (!allWell) return false;

                var selectedEvents = _.filter(athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.typesOfEvents(), function (item) {
                    return item.isSelected;
                });

                var selectedEventRules = athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.eventRules();
                var personalizedEventRules = [];

                _.each(selectedEventRules, function (item) {
                    var tempEventRule = {
                        EventName: item.customRuleName,
                        CertaintyValues: item.certaintyAttributes,
                        SeverityValues: item.severityAttributes,
                        UrgencyValues: item.urgencyAttributes,
                        Keywords: $.trim(item.optionalKey) == "None" ? "" : item.optionalKey,
                    };

                    personalizedEventRules.push(tempEventRule);
                });

                var objTargetOptions = {
                    GroupNames: athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked() ? $.trim(athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.groupNames()) : null,
                    isGroupNameChecked: athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked(),
                    isFolderAlertChecked: athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isFolderAlertChecked(),
                    SelectedAlertId: athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isFolderAlertChecked() ? athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.selectedAlertId() : null,
                    AllSubscribeUser: athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.
                        subscribedEndUser(),
                    UserBasedOnLocation: athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions
                        .subscribedEndUserBasedOnLocation(),
                };

                var jsonData = {
                    ChannelDisable: athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.disableWeather(),
                    EventList: selectedEvents,
                    PersonalizedEventList: personalizedEventRules,
                    LocationGeoCodes: $.trim(athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.locationGeoCodes()),
                    PublishForBadCondition: athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.publishForBadLocation(),
                    PublishForBadConditionText: athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.publishForBadLocation() ? athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.publishForBadLocationText() : null,
                    TargetOptions: objTargetOptions,
                    BasicCriteria: {
                        AgentId: athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.selectedAgentInfo().agentId,
                        FolderId: athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.selectedFolderId()
                    },

                };

                var dlAjaxOption =
                    {
                        url: athoc.iws.weatherModule.urls.SaveWeatherModuleDataURL,
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            athoc.iws.weatherModule.closeModalPopup('alertPrefMainPage');
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.channelManager.handleError(e);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);

                $.ajax(ajaxOptions);

                return true;
            },

            disableWeather: function () {

                var jsonData = { objCriteria: { IsWeatherModuleDisable: false } };

                var dlAjaxOption =
                    {
                        url: athoc.iws.weatherModule.urls.DisableWeatherURL,
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            athoc.iws.weatherModule.closeModalPopup('alertPrefMainPage');
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.channelManager.handleError(e);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);

                $.ajax(ajaxOptions);

                return true;
            },

            registerCollapse: function () {
                $('.collapse').on('show', function () {
                    var $t = $(this);
                    var header = $("a[href='#" + $t.attr("id") + "']");
                    header.find(".icon-chevron-right").removeClass("icon-chevron-right").addClass("icon-chevron-down");
                }).on('hide', function () {
                    var $t = $(this);
                    var header = $("a[href='#" + $t.attr("id") + "']");
                    header.find(".icon-chevron-down").removeClass("icon-chevron-down").addClass("icon-chevron-right");
                });
            },

            retainSelectAll: function () {
                var grid = $('#geoCodeGrid').data().kendoGrid;
                var ttlCnt = 0;

                if (grid != undefined) {

                    var items = grid.dataSource.view();
                    // Get the selected items for the current page.
                    $.grep(items, function (v) {
                        if (v.IsChecked)
                            ttlCnt++;
                    });

                    // Check total page count equal to selected count 
                    var checked = ttlCnt > 0 && (items.length == ttlCnt);
                    $("#chkAllGeoCodes").prop('checked', checked);



                    //var checkedItem = _.filter(allViewData, function (item) {
                    //    return item.IsChecked;
                    //});

                    //if (allViewData.length == checkedItem.length) {
                    //    $('#chkAllGeoCodes').prop('checked', true);
                    //}
                    //else {
                    //    $('#chkAllGeoCodes').prop('checked', false);
                    //}
                }
            },

            closeWarningModalPopup: function () {
                athoc.iws.weatherModule.closeModalPopup('informationDialog');
            },

            subscribeValidationObject: function () {

                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked.subscribe(
                function () {
                    if (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked()) {
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isFolderAlertChecked(false);
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUser(false);
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUserBasedOnLocation(false);
                    }
                });

                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isFolderAlertChecked.subscribe(
                function () {
                    if (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isFolderAlertChecked()) {
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked(false);
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUser(false);
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUserBasedOnLocation(false);
                    }
                });

                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUser.subscribe(
                function () {
                    if (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUser()) {
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isFolderAlertChecked(false);
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked(false);
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUserBasedOnLocation(false);
                    }
                });

                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUserBasedOnLocation.subscribe(
                function () {
                    if (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUserBasedOnLocation()) {
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isFolderAlertChecked(false);
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.subscribedEndUser(false);
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked(false);
                    }
                });

                //Validate the controls on Add and duplicate popup
                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.locationGeoCodes.subscribe(
                function () {
                    athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_geoCode('');
                    if (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.locationGeoCodes().length == 0) {
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_geoCode('Required');
                    }
                });

                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.publishForBadLocationText.subscribe(
                function () {
                    athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_locationTxt('');
                    if (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.publishForBadLocation() && (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.publishForBadLocationText().length == 0)) {
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_locationTxt('Required');
                    }
                });

                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.publishForBadLocation.subscribe(
               function () {
                   athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_locationTxt('');
               });

                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked.subscribe(
                function () {
                    athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_groupName('');
                    if (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked() && (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.groupNames().length == 0)) {
                        athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_groupName('Required');
                    }
                });

                athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.groupNames.subscribe(
              function () {
                  athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_groupName('');
                  if (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.isGroupNameChecked() && (athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.targetOptions.groupNames().length == 0)) {
                      athoc.iws.weatherModule.viewModel.weatherAlertPrefrence.msgWAP.warning_groupName('Required');
                  }
              });
            },

            geoCodeCancel: function () {
                athoc.iws.weatherModule.closeModalPopup('geocodeFinder', 'alertPrefMainPage');
            },

            personalEventCancel: function () {
                athoc.iws.weatherModule.closeModalPopup('addrule', 'alertPrefMainPage');
            }
        };
    }();
}
