﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.changeOrganization = athoc.iws.changeOrganization || {};

if (athoc.iws) {

    if (athoc.iws.changeOrganization) {

        athoc.iws.changeOrganization = function () {
            return {
                urls: {},
                viewModel: {
                    providerList: ko.observableArray(),
                    currentProviderId: ko.observable(0),
                    providerId: ko.observable(0),
                },

                
           
                Change: function () {
                    if (athoc.iws.changeOrganization.viewModel.currentProviderId()!=0)
                    window.location.href = "ChangeOrganization/SetOrganization/" + athoc.iws.changeOrganization.viewModel.currentProviderId();

                },

                load: function () {
                    athoc.iws.changeOrganization.viewModel.providerList = ko.mapping.fromJS(athoc.iws.changeOrganization.providerList);

                    athoc.iws.changeOrganization.viewModel.currentProviderId(athoc.iws.changeOrganization.providerId);
                    $("#ChangeOrganization").find(".bootstrap-select").remove();
                    ko.cleanNode($("#ChangeOrganization").get(0));
                    ko.applyBindings(athoc.iws.changeOrganization.viewModel, $("#ChangeOrganization").get(0));
                    $("#ddlProvidersList").selectpicker( { noneResultsText: athoc.iws.changeOrganization.resources.ChangeOrganization_NoResultFound } );
                    
                    $('[data-id=ddlProvidersList]').trigger('click');
                    $("#ChangeOrganization").removeClass("hide");
                    $("#ChangeOrganization").find(".caret").addClass("hide");
                    $('[data-id=ddlProvidersList]').focus();
                    //$("#ChangeOrganization").find(".dropdown-toggle").addClass("hide");
                    $('#co_ok').on('click', function () {
                        athoc.iws.changeOrganization.Change();
                    });

                    $('#co_cancel').on('click', function () {
                        window.location.href = "/athoc-iws/";
                    });
                   
                    $('.selectpicker li a').click(function (e) {
                        var selected = $(".selectpicker option:contains(" + $(this).text() + ")").val();//$('.selectpicker option:selected').val();
                        $('.selectpicker li').removeClass("active");
                        athoc.iws.changeOrganization.viewModel.currentProviderId(selected);
                        e.preventDefault();
                        e.stopPropagation();

                    });
                    $('.selectpicker li').dblclick(function (e) {
                        athoc.iws.changeOrganization.Change();
                    });

                    $(".bs-searchbox input,.selectpicker li a").keyup(function (e) {
                        var selected = $(".selectpicker option:contains(" + $(".selectpicker li.active").text() + ")").val();
                        $('#co_ok').removeAttr("disabled");
                        if (selected != undefined)
                            athoc.iws.changeOrganization.viewModel.currentProviderId(selected);
                        else {
                            athoc.iws.changeOrganization.viewModel.currentProviderId(0);
                            $('#co_ok').attr("disabled", "disabled");
                        }
                        if ($.hotkeys.enter(e) && selected!=undefined) {
                            selected = $(".selectpicker option:contains(" + $(".selectpicker li a.active").text() + ")").val();
                            athoc.iws.changeOrganization.viewModel.currentProviderId(selected);
                            athoc.iws.changeOrganization.Change();
                        }
                        if (e.keyCode == 27) {
                            $("[data-id=ddlProvidersList]").parent().addClass('open');
                        }

                    });
                   
                    $('[data-id=ddlProvidersList],#co_ok,#co_cancel').on('focus', function () {
                        $("[data-id=ddlProvidersList]").parent().addClass('open'); 
                    });
                   
                    $(".bs-searchbox input").focusout(function () {
                        $("[data-id=ddlProvidersList]").parent().addClass('open');

                    });

                    $(".bs-searchbox input").focus(function () {
                        if(this.value.length>0)
                            $('.placeholder').hide();
                        else
                            $('.placeholder').show();
                    });
                   
                    athoc.iws.changeOrganization.viewModel.currentProviderId.subscribe(function (newValue) {

                    });
                    $("#progress").hide();
                 }
            };
        }();
    }
}

