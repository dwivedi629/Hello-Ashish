﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};

if (athoc.iws) {
    athoc.iws.placeholder= function() {
        return {

            urls: {},

            resources: {},

            init: function() {
                //athoc.iws.Placeholder.initBreadcrumb();
                ko.applyBindings(athoc.iws.placeholder.details.breadCrumbModel, $("#navigationBar").get(0));
            },
            breadCrumbModel: {
                gotoList: function () {
                    window.location.href = athoc.iws.placeholder.details.urls.IndexUrl + "/";
                }
            },
            gotoList: function () {
                    window.location.href = "/client/setup/settings";
            },
            load: function() {
                

                if (window.location.pathname.split('/').length==3 || window.location.pathname.split('/').length == 4) {
                    window.navigateToPage('placeholderList', function () { });
                    athoc.iws.placeholder.list.load();
                }
                else if ($.inArray("Edit",window.location.pathname.split('/'))>-1 && window.location.pathname.split('/').length==5)
                    athoc.iws.placeholder.viewattributeDetail(parseInt(window.location.pathname.split('/')[4]));
                else if ($.inArray("New",window.location.pathname.split('/'))>-1)
                    athoc.iws.placeholder.newAttributeDetails(window.location.pathname.split('/')[4]);
                   
                
                //if (!isNaN(parseInt(window.location.pathname.split('/')[3])))
                  //  athoc.iws.placeholder.viewattributeDetail(parseInt(window.location.pathname.split('/')[3]));
                $("#btnExcelExport").kendoButton({
                    click: function () {
                        //$('#placeholderDependencyList').data('kendoGrid').dataSource.group([]);
                        $("#placeholderDependencyList").getKendoGrid().saveAsExcel();
                    }
                });
            },

            

            viewAttributeList: function (refresh) {

                window.navigateToPage('placeholderList', function () { });
                var breadcrumbsModel = athoc.iws.placeholder.breadcrumbModel;
                breadcrumbsModel.SelectedPage('placeholderList');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);
                
                if (refresh) {
                    athoc.iws.placeholder.list.refreshGrid();
                }
            },

            viewattributeDetail: function (id) {

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.placeholder.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();

                var placeholderDetails = null;
                var myAjaxOptions = {
                    url: athoc.iws.placeholder.urls.GetPlaceholderDetailstUrl,
                    type: "POST",
                    contentType: 'application/json',
                    dataType: 'json',
                    async: false,
                    data: JSON.stringify({'placeholderId': id })
                };

                var onError = function (errorResult) {
                    $.AjaxLoader.hideLoader();
                };

                var onSuccess = function (data, textStatus, jqXHR) {

                    placeholderDetails = data.Data;
                    athoc.iws.placeholder.details.editPlaceholder(placeholderDetails, data.IsDeletable);
                    window.navigateToPage('placeholderDetail', function () { });
                    //window.location.hash = "#attributeDetail";
                    var breadcrumbsModel = athoc.iws.placeholder.breadcrumbModel;
                    breadcrumbsModel.SelectedPage('placeholderDetail');
                    $.titleCrumb("pageBreadcrumbs");
                    breadcrumbsModel.updateTitle(placeholderDetails.AttributeName);

                    $(document).scrollTop(0);
                    $.AjaxLoader.hideLoader();

                    //if (typeof deleteSuccessCallback == "function") {
                    //    deleteSuccessCallback(data, textStatus, jqXHR);
                    //}
                }

                var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

                $.AjaxLoader.hideLoader();
            },

            newAttributeDetails:function(type){
                window.navigateToPage('newAttributeDetail', function () { });
                //window.location.hash = "#attributeDetail";
                var placeholderDetails = null;
                athoc.iws.placeholder.details.createOptionsGrid();
                var breadcrumbsModel = athoc.iws.placeholder.breadcrumbModel;
                breadcrumbsModel.SelectedPage('newAttributeDetail');
                $.titleCrumb("pageBreadcrumbs");
                breadcrumbsModel.updateTitle(type);

            },

            checkForDependencies: function (id) {
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.placeholder.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();
               
                athoc.iws.placeholder.showDependencyList(id);
                /*   var myAjaxOptions = {
                    url: athoc.iws.placeholder.urls.GetPlaceholderDependencyListUrl,
                    type: "POST",
                    contentType: 'application/json',
                    dataType: 'json',
                    async: false,
                    data: JSON.stringify({ 'placeholderId': id })
                };

                var onError = function (errorResult) {
                    $.AjaxLoader.hideLoader();
                };

                var onSuccess = function (data, textStatus, jqXHR) {

                    if (data && data.Success && data.Success === true) {
                        if (data.Data && data.Data.length > 0)
                            athoc.iws.placeholder.showDependencyList(data.Data);
                        else {
                            athoc.iws.placeholder.deletePlaceholder(id);
                        }
                    }
                    $.AjaxLoader.hideLoader();
                }

                var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);

                $.AjaxLoader.hideLoader(); */
            },

            showDependencyList: function (dependencyList) {
               
                var dataSource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: athoc.iws.placeholder.urls.GetPlaceholderDependencyListUrl,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },

                        parameterMap: function (data) {
                            var moreData = { "placeholderId": dependencyList };
                            $.extend(data, moreData);
                            return kendo.stringify(data);
                        },

                       

                    },

                    requestStart: function (e) {
                        $.AjaxLoader.setup({ useBlock: true, elementToBlock: $('#placeholderDependencyList .k-grid-content'), imageURL: athoc.iws.placeholder.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage });
                        $.AjaxLoader.showLoader();

                    },
                    requestEnd: function (e) {
                        athoc.iws.placeholder.centerTheDependencyModal();
                        $.AjaxLoader.hideLoader();

                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                        model: {
                                    fields: {
                                        UsedIn: { type: "string"  },
                                        EntityName: { type: "string" },
                                        EntityId: { type: "number" },
                                        UsedFor: { type: "string" },
                                        SourceProvider: { type: "string" }
                                    }
                                },
                    },
                    serverPaging:true,
                   // group: { field: "UsedIn", dir: "asc" }, // set grouping for the dataSource
                    //groupable: false, // this will remove the group bar
                   
                    pageSize: 50,
                });


               

                    $("#placeholderDependencyList").kendoGrid({
                        excel: {
                            fileName: "User Attribute Dependency List.xlsx",
                            allPages: true,
                            filterable: true,
                            proxyURL: athoc.iws.placeholder.urls.ExportDependenciesUrl,
                            forceProxy: true,
                        },
                        dataSource: dataSource,
                        pageable: {
                            refresh: false,
                            pageSizes: [20, 50, 100],
                            buttonCount: 5,
                            messages: {
                                display: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Summary,
                                empty: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Empty,
                                //page: athoc.iws.placeholder.resources.PlaceholderManager_Pageable_page,
                                //of: athoc.iws.placeholder.resources.PlaceholderManager_Pageable_of,
                                itemsPerPage: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Items_Per_Page,
                                first: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_First_Page,
                                previous: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page,
                                next: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Next_Page,
                                last: athoc.iws.placeholder.resources.AtHoc_Pager_Message_Go_To_The_Last_Page
                                //refresh: athoc.iws.placeholder.resources.UserAttributeManager_Pageable_refresh
                            }
                        },
                        serverPaging: true,
                        height: 320,
                        sort: { field: "EntityName", dir: "asc" },
                        columns: [
                            { field: "UsedIn", title: "Used In", width: '150px', sortable: false },
                            { field: "EntityName", title: "Name", width: '200px' },
                            { field: "EntityId", title: "ID", width: '100px' },
                            { field: "UsedFor", title: "Used For", width: '150px' },
                            { field: "SourceProvider", title: "Origin" }
                        ],

                    });
               

                athoc.iws.placeholder.centerTheDependencyModal();
                $("#placeholderDependencyList").data('kendoGrid').dataSource.data([]);
                $('#dialogDependencyList').modal('show');
           
            },

            centerTheDependencyModal: function () {
                var leftPosition = ($(window).width() / 2) - ($('#dialogDependencyList').width() / 2);
                var d = document.getElementById('dialogDependencyList');
                d.style.position = "absolute";
                d.style.left = 0;
                d.style.marginLeft = leftPosition + 'px';
            },

            deletePlaceholder: function(id) {

                $('#dlgGenericConfirmation .genericHeaderMesage').text(athoc.iws.placeholder.resources.UserAttributeManager_Delete_Modal_Heading); //set Header Title
                $('#dlgGenericConfirmation .genericBodyContent').text(athoc.iws.placeholder.resources.UserAttributeManager_Delete_Modal_Warning); //Set Confirmation Message
                $('#dlgGenericConfirmation').modal();
                $('#genericConfirmationOk').off('click').on('click', function(e) {
                    e.preventDefault();

                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.placeholder.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.placeholder.resources.General_LoadingMessage }).showLoader();

                    var myAjaxOptions = {
                        url: athoc.iws.placeholder.urls.DeletePlaceholderUrl,
                        type: "POST",
                        contentType: 'application/json',
                        dataType: 'json',
                        async: false,
                        data: JSON.stringify({ 'placeholderId': id })
                    };
                    var onError = function(errorResult) {
                        $.AjaxLoader.hideLoader();
                    };
                    var onSuccess = function(data, textStatus, jqXHR) {
                        if (data && data.Success && data.Success === true) {
                            $('#dlgGenericConfirmation').modal('hide');
                            athoc.iws.placeholder.viewAttributeList(true);
                        } else {
                            //show the error/validation.
                            $('#dlgGenericConfirmation').modal('hide');
                            $('#AttributeEditMessagePanel').messagesPanel('reset');
                            var messagePanel = $('#AttributeEditMessagePanel').messagesPanel({ messages: data.Messages });
                            $('html, body').animate({
                                scrollTop: $('#AttributeEditMessagePanel').offset().top - 175
                            }, 500);
                        }
                        $.AjaxLoader.hideLoader();
                    }
                    var ajaxOptions = $.extend({}, window.AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                    $.ajax(ajaxOptions);
                    $.AjaxLoader.hideLoader();
                });
            },

            OnDataBound: function () {

                if (this.dataSource.group().length > 0) {
                    var firstGroup = $(".k-grouping-row").first();
                    this.collapseGroup(firstGroup);
                }

                //if (this.dataSource.group().length > 0) {
                //    var GrpList = $(".k-grouping-row");

                //    for (var i = 0; i < GrpList.length; i++) {
                //        var firstGroup = GrpList[i];
                //        if (firstGroup) {
                //            this.collapseGroup(firstGroup);
                //        }
                //    }
                //}
            }
        }
    }();
}