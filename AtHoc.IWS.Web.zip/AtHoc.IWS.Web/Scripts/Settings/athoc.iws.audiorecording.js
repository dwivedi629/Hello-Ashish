﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.AudioRecording = athoc.iws.AudioRecording || {};

if (athoc.iws.AudioRecording) {

    var ids = new Array();
    var isModalOpened = false;


    athoc.iws.AudioRecording = function () {
        var sortState;
        return {
            isRightToLeft: false,
            audioId: 0,
            isRecording: false,
            audioData: null,
            audioURL: null,
            searchMaxLength: 200,
            providerId: 0,
            recorder: null,
            audio_context: null,
            audioBase64Data: null,

            viewModel: {
                audioFileName: ko.observable(''),
            },

            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for audio recording, will be triggered before document load
            init: function () {

                athoc.iws.AudioRecording.uploadAudioFile();

                $("#recordAudio").click(function () {
                    if (!athoc.iws.AudioRecording.isRecording) {
                        athoc.iws.AudioRecording.recordAudioFile();

                    } else
                        athoc.iws.AudioRecording.stopRecordAudioFile();
                });

                $("#playRecord").click(function () {
                    athoc.iws.AudioRecording.actionPlayAudioFile();
                });

                $("#stopRecord").click(function () {
                    athoc.iws.AudioRecording.stopPlayAudioFile();
                });

                $("#uploadPlay").click(function () {
                    athoc.iws.AudioRecording.actionPlayUploadFile();
                });
            },



            //Starts Audio recording
            recordAudioFile: function () {
                $(document).scrollTop(0);
                if (!athoc.iws.AudioRecording.isRecording) {
                    try {
                        // webkit shim
                        window.AudioContext = window.AudioContext || window.webkitAudioContext || window.mozAudioContext;
                        navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;
                        window.URL = window.URL || window.webkitURL || window.mozURL;

                        audio_context = new AudioContext();
                        console.log('Audio context set up.');
                        console.log('navigator.getUserMedia ' + (navigator.getUserMedia ? 'available.' : 'not present!'));

                    } catch (e) {
                        console.log('No web audio support in this browser!');
                    }
                    navigator.getUserMedia({ audio: true }, athoc.iws.AudioRecording.startUserMedia, function (e) {
                        console.log('No live audio input: ' + e);
                    });
                }
                return true;
            },

            //Stops Audio recording
            stopRecordAudioFile: function () {
                if ($('#recordAudio').text() == "Stop") {
                    athoc.iws.AudioRecording.recorder && athoc.iws.AudioRecording.recorder.stop();
                    $('#recordAudio').attr("title", "Record");
                    $('#recordAudio').text("Record");
                    $('#playRecord').attr('disabled', false);
                    $('#stopRecord').attr('disabled', true);
                    athoc.iws.AudioRecording.isRecording = false;
                    athoc.iws.AudioRecording.getAudioURL();
                    athoc.iws.AudioRecording.recorder.clear();
                }
                return true;
            },

            uploadAudioFile: function () {
                $("#btnBrowse").addClass("fileinput-button-align");
                $("#btnBrowse").removeClass("fileinput-button-align-height");
                ko.cleanNode($("#uploadAudiofileManager").get(0));
                ko.applyBindings(athoc.iws.AudioRecording.viewModel, $("#uploadAudiofileManager").get(0));

                $("#audioUpload").fileupload({
                    dataType: 'json',
                    autoUpload: false,
                    maxFileSize: 5000000,
                    add: function (e, data) {
                        fileData = data;
                        $('#newMessagePanel').html('');
                        $.each(data.files, function (index, file) {
                            var ext = file.name.split(".")[file.name.split(".").length - 1].toLowerCase();
                            $("#importFileText").val("");
                            if (ext !== "wav") {
                                var reqError = new Array();
                                reqError.push({ Type: '4', Value: athoc.iws.AudioFileManager.resources.AudioFile_AudioFile_Pattern });
                                $('#newMessagePanel').messagesPanel({ messages: reqError });
                            } else {
                                athoc.iws.AudioRecording.viewModel.audioFileName(file.name);
                                var fReader = new FileReader();
                                fReader.readAsDataURL(file);
                                fReader.onloadend = function (event) {
                                    //console.log(event.target.result);
                                    athoc.iws.AudioRecording.audioURL = event.target.result;
                                }
                            }
                        });

                    },
                    change: function (e, data) {

                    },
                    error: function (e) {
                        athoc.iws.AudioFileManager.handleError(e);
                    }
                });
            },

            // initializing media control in client browser
            startUserMedia: function (stream) {
                var input = audio_context.createMediaStreamSource(stream);
                console.log('Media stream created.');
                console.log('Input connected to audio context destination.');
                athoc.iws.AudioRecording.recorder = new Recorder(input);

                //recording start
                athoc.iws.AudioRecording.recorder && athoc.iws.AudioRecording.recorder.record();
                athoc.iws.AudioRecording.isRecording = true;
                $('#recordAudio').attr("title", "Stop");
                $('#recordAudio').text("Stop");
                $('#playRecord').attr('disabled', true);
                $('#stopRecord').attr('disabled', true);
                //recording end
            },

            // Save Audio File
            saveAudioFile: function (model) {
                $(document).scrollTop(0);

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: '', top: '200px', left: '50%' }).showLoader();
                var dataPost = { alertId: 1, operatorId: athoc.iws.AudioRecording.providerId };
                var dlAjaxOption =
                    {
                        url: athoc.iws.AudioRecording.urls.SaveAudioUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(dataPost),
                        success: function (data) {
                            if (data.Success) {
                                athoc.iws.AudioRecording.isRecording = false;
                                $("#recordAudioVB").text("Record");
                                athoc.iws.AudioRecording.audioData = data.audioData;

                            }
                            $.AjaxLoader.hideLoader();
                            $("html,body").scrollTop(0);
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
                return true;
            },

            // Triggered, when Play link clicked from more action
            actionPlayAudioFile: function () {
                $("#audio").attr("src", athoc.iws.AudioRecording.audioURL).trigger("play");
                $('#stopRecord').attr('disabled', false);
                $('#playRecord').attr('disabled', true);
            },
            // Triggered, when Play link clicked from more action
            stopPlayAudioFile: function () {
                //$("#audioPlayer").trigger("stop");
                var vid = document.getElementById("audio");
                vid.pause();
                vid.currentTime = 0;
                $('#playRecord').attr('disabled', false);
                $('#stopRecord').attr('disabled', true);
            },

            //Gets the URL of the recorded audio file.
            getAudioURL: function () {
                athoc.iws.AudioRecording.recorder && athoc.iws.AudioRecording.recorder.exportWAV(function (blob) {
                    athoc.iws.AudioRecording.audioURL = URL.createObjectURL(blob);
                    athoc.iws.AudioRecording.getBase64Data(blob);
                });
            },
            getBase64Data: function (blob) {
                var reader = new window.FileReader();
                reader.readAsDataURL(blob);
                reader.onloadend = function () {
                    athoc.iws.AudioRecording.audioBase64Data = reader.result;
                }
            },

            // Triggered, when Play link clicked for uploaded file
            actionPlayUploadFile: function () {
                if (navigator.userAgent.toLowerCase().indexOf('trident') == -1) {
                    $("#audioPlayer").attr("src", athoc.iws.AudioRecording.audioURL).trigger("play");
                }
                else {

                    //var wavString = athoc.iws.AudioRecording.audioURL;
                    //var len = wavString.length;
                    //var buf = new ArrayBuffer(len);
                    //var view = new Uint8Array(buf);
                    //for (var i = 0; i < len; i++) {
                    //    view[i] = wavString.charCodeAt(i) & 0xff;
                    //}
                    //var blob = new Blob([view], { type: "audio/wav" });
                    //athoc.iws.AudioRecording.audioURL = URL.createObjectURL(blob);
                    //bgPlay.src = blob;
                    bgPlay.src = athoc.iws.AudioRecording.audioURL;
                }
            },

        };
    }();


    //athoc.iws.AudioRecording = function () {
    //    var sortState;
    //    return {
    //        isRightToLeft: false,
    //        audioId: 0,
    //        isRecording: false,
    //        audioData: null,
    //        searchMaxLength: 200,
    //        providerId : 0,

    //        //Required URLs these URLs should be loaded from inline page JavaScript
    //        urls: {},

    //        //Required resources these resources should be loaded from inline page JavaScript
    //        resources: {},

    //        //init method for scenario list, will be triggered before document load
    //        init: function () {
    //            $("#recordAudioVB").click(function() {
    //                if (!athoc.iws.AudioRecording.isRecording) {
    //                    athoc.iws.AudioRecording.recordAudioFile();

    //                } else
    //                    athoc.iws.AudioRecording.saveAudioFile();
    //            });

    //            $("#playRecordVB").click(function () {
    //                    athoc.iws.AudioRecording.actionPlayAudioFile();
    //            });

    //            $("#stopRecordVB").click(function () {
    //                athoc.iws.AudioRecording.stopPlayAudioFile();
    //            });
    //        },



    //        // Display Create New Audio popup 
    //        recordAudioFile: function () {
    //            $(document).scrollTop(0);


    //            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: '', top: '200px', left: '50%' }).showLoader();
    //            if (!athoc.iws.AudioRecording.isRecording)
    //                var dataPost = { alertId: 1, operatorId: athoc.iws.AudioRecording.providerId };
    //            var dlAjaxOption =
    //                {
    //                    url: athoc.iws.AudioRecording.urls.RecordAudioUrl,
    //                    contentType: "application/json; charset=utf-8",
    //                    dataType: 'json',
    //                    type: 'POST',
    //                    data: JSON.stringify(dataPost),
    //                    success: function (data) {
    //                        if (data.Success) {

    //                            athoc.iws.AudioRecording.isRecording = true;
    //                            $("#recordAudioVB").text("Stop");

    //                        }
    //                        $.AjaxLoader.hideLoader();
    //                        $("html,body").scrollTop(0);
    //                    },
    //                    error: function (e) {
    //                        $.AjaxLoader.hideLoader();
    //                    }
    //                };

    //            var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
    //            $.ajax(ajaxOptions);
    //            return true;
    //        },

    //        // Display Edit Audio popup
    //        saveAudioFile: function (model) {
    //            $(document).scrollTop(0);

    //            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: '', top: '200px', left: '50%' }).showLoader();
    //            var dataPost = { alertId: 1, operatorId: athoc.iws.AudioRecording.providerId };
    //            var dlAjaxOption =
    //                {
    //                    url: athoc.iws.AudioRecording.urls.SaveAudioUrl,
    //                    contentType: "application/json; charset=utf-8",
    //                    dataType: 'json',
    //                    type: 'POST',
    //                    data: JSON.stringify(dataPost),
    //                    success: function (data) {
    //                        if (data.Success) {
    //                            athoc.iws.AudioRecording.isRecording = false;
    //                            $("#recordAudioVB").text("Record");
    //                            athoc.iws.AudioRecording.audioData = data.audioData;

    //                        }
    //                        $.AjaxLoader.hideLoader();
    //                        $("html,body").scrollTop(0);
    //                    },
    //                    error: function (e) {
    //                        $.AjaxLoader.hideLoader();
    //                    }
    //                };

    //            var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
    //            $.ajax(ajaxOptions);
    //            return true;
    //        },

    //        // Triggered, when Play link clicked from more action
    //        actionPlayAudioFile: function () {
    //            $("#audioPlayer").attr("src", "data:audio/wav;base64," + athoc.iws.AudioRecording.audioData).trigger("play");
    //        },
    //        // Triggered, when Play link clicked from more action
    //        stopPlayAudioFile: function () {
    //            $("#audioPlayer").trigger("stop");
    //        },




    //    };
    //}();
}