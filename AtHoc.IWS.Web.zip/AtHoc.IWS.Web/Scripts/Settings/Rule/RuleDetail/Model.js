﻿define([], function () {
    function Model() {
        var self = this;
        self.HasValidation = ko.observable();
        self.breadCrumbName = ko.observable();


    }
    return Model;

});
