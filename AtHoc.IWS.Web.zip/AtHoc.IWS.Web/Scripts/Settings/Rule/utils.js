﻿define([],function () {
    var i18n = {};

    var common = {
        AppnedResources: function(resourcesToAppned) {
            i18n = $.extend(i18n, resourcesToAppned);
            this.resources = i18n;
        },
        resources: i18n, 
        createGridOptions: function() {
            return {
               
                pager: {
                    messageSummary: i18n.AtHoc_Pager_Message_Summary,
                    messageEmpty: i18n.AtHoc_Pager_Message_Empty,
                    messageItemsPerPage: i18n.AtHoc_Pager_Message_Items_Per_Page,
                    messageGoToFirstPage: i18n.AtHoc_Pager_Message_Go_To_The_First_Page,
                    messageGoToPreviousPage: i18n.AtHoc_Pager_Message_Go_To_The_Previous_Page,
                    messageGoToNextpage: i18n.AtHoc_Pager_Message_Go_To_The_Next_Page,
                    messageGoToLastPage: i18n.AtHoc_Pager_Message_Go_To_The_Last_Page
                },

                loadingMessage: i18n.General_LoadingMessage,
                SelectAll: i18n.WAMRule_Grid_SelectAll,
                Name: i18n.WAMRule_Grid_NameColumn_Headertext,
                Counties: i18n.WAMRule_Grid_CountiesColumn_Headertext,
                Action: i18n.WAMRule_Grid_ActionColumn_Headertext,
                Enabled: i18n.WAMRule_Grid_EnabledColumn_Headertext,
                noRecordsMessage: i18n.WAMRule_Grid_NoRecords_Message,
                selectAllText: i18n.AtHoc_Common_Select_All
            };
        },

        createDialogOption: function() {
            return {
                dialogCloseButtonText: i18n.PA_Dialog_Close_Button_Text,
                dlgClass: "width650"
            };
        },

        createConfirmOption: function() {
            return {
                confirmButtonText: i18n.PA_Event_Manager_End,
                cancelButtonText: i18n.PA_Event_Cancel_Button,
                dialogCloseButtonText: i18n.PA_Dialog_Close_Button_Text,
                dlgClass: "width650"
            };
        },

        createNavigationOption: function() {
            return {
                moreActionsLinkText: i18n.PA_Event_Summary_More_Actions_Link_Text
            };
        },

        createBasicSearchOption: function() {
            return {
                generalLoadingMessage: i18n.Event_General_LoadingMessage,
                searchBoxText: i18n.PA_Event_Manager_SearchBox,
                searchTitle: i18n.Event_Search,
                clearAllText: i18n.Event_Clear_All
            };
        },

        createAdvancedSearchOption: function() {
            return {
                colNumber: 0,
                isAdvancedFilter: true,
                filterPropertyName: "SearchStrings",
                pageInfoText: i18n.PA_Event_List_PageInfo,
                pageInfoNoRecordsText: i18n.PA_Event_List_PageInfo_NoRecords,
                //searchByTitle: i18n.PA_Event_List_Search_By_Title,
                searchByTitle: i18n.WAMRule_Grid_SearchByZipCode_Text,
                criteriaBuilderSelectedText: i18n.PA_Event_Criteria_Builder_selected,
                listAdvancedTitle: i18n.PA_Event_List_Advanced,
                buttonClearAllText: i18n.PA_Event_Button_ClearAll,
                cancelButtonText: i18n.PA_Template_Details_Cancel_Button_Text,
                applyButtonText: i18n.PA_Template_Details_Apply_Button_Text,
                advancedFilterPopupTitle: i18n.PA_Event_List_AdvancedFilter_Popup_Title,
                searchKeywordText: ""
            };
        },

        createMultiSelectSearchOptions: function() {
            return {
                noListItemText: i18n.PA_Event_List_NoList,
                listSelectAllText: i18n.PA_Event_List_Select_All,
                selectedCountText: i18n.PA_Event_List_Selected,
                noneItemSelectedText: i18n.PA_Event_List_None,

                labelText: "", //need to override
                filterPropertyName: "" //need to override
            };
        },

        createDateRangeSearchOption: function() {
            return {
                labelStartDate: resources.PA_Event_List_Search_StartDate,
                labelToDate: resources.PA_Event_List_Search_Date_To,
                FromDate: resources.PA_Event_List_Search_Datepicker_Please_Enter_Date_In_Format,
                ToDate: resources.PA_Event_List_Search_Datepicker_Please_Enter_Date_In_Format,
                DateRange: resources.PA_Event_List_Search_Date_Range,
                DateAfter: resources.PA_Event_List_Search_Date_after,
                DateBefore: resources.PA_Event_List_Search_Date_before,
                filterPropertyName_FromDate: "StartDate",
                filterPropertyName_ToDate: "EndDate"
            };
        },

        


        createGeneralOption: function () {
            return {
                titleText: i18n.WAMRule_General_Section_Title,
                tabIndex: 1000,
                controlID: "generalID",
                cssClass: "",
                labelCaption1: i18n.WAMRule_General_Name_Label,
                labelCaption2: i18n.WAMRule_General_Enabled_Label,
                required1: i18n.WAMRule_General_Name_Validation_Message,
                lenghtValidation: i18n.WAMRule_General_Name_Length_Valiadation_Message,
                placeHolder1: i18n.WAMRule_General_Name_Palceholder,
                placeHolder2: i18n.WAMRule_General_Enabled_Palceholder
            };
        },
        createConditionOption: function () {
            return {
                titleText: i18n.WAMRule_Condition_Section_Title,
                sectionWatermark: i18n.WAMRule_Condition_Section_Watermark,
                tabIndex: 0,
                controlID: "conditionID",
                cssClass: "",
                descWatermark: i18n.WAMRule_Condition_Desc_Watermark,
                labelCaption1: i18n.WAMRule_Condition_Counties_Label,
                labelCaption2: i18n.WAMRule_Condition_Severity_Label,
                labelCaption3: i18n.WAMRule_Condition_EventType_Label,
                labelCaption4: i18n.WAMRule_Condition_Keyword_Label,
                linkLabelCaption: i18n.WAMRule_Condition_Select_Label,
                linkLabelModifyCaption: i18n.WAMRule_Condition_Modify_Label,
                linkLabelCountiesSelectdCaption: i18n.WAMRule_Condition_Counties_Selected_Label_Plural,
                linkLabelCountySelectdCaption: i18n.WAMRule_Condition_Counties_Selected_Label_Single,
                placeHolder: i18n.WAMRule_Condition_Keyword_Palceholder,
                required: i18n.WAMRule_Condition_Counties_Require_Message,
                //Urls: WeatherUrls,

                tabTextCounty: i18n.WAMRule_Grid_SelectCounties_TabText,
                tabTextSelectCounty: i18n.WAMRule_Grid_SelectedCounties_TabText,
                watermarkZipCode: i18n.WAMRule_Grid_SearchByZipCode_Text,
                labelAllState: i18n.WAMRule_Grid_AllStates,
                labelCounty: i18n.WAMRule_Grid_County,
                labelState: i18n.WAMRule_Grid_State,
                labelGeoCode: i18n.WAMRule_Grid_GeoCode,
                Urls: WeatherUrls,  //This variable is defined on cshtml page
                labelMessageTypeCaption: i18n.WAMRule_Condition_MessageType_Label,
            };
        },
        createActionOption: function () {
            return {
                titleText: i18n.WAMRule_Action_Section_Title,
                descText: i18n.WAMRule_Action_Section_Watermark,
                tabIndex: 0,
                controlID: "actionID",
                cssClass: "",
                labelCaption: i18n.WAMRule_Action_Counties_Label,
                requiredMessage: i18n.WAMRule_Action_Template_Required_Message,
                GeoLabelCaption: i18n.WAMRule_Action_GeoEnabled_Title,
                GeoEnabledCaption: i18n.WAMRule_Action_GeoEnabled_Text,
                GeoSubTitle: i18n.WAMRule_Action_GeoEnabled_SubTitle,
            };
        },
        createActionDropDownTemplateOption: function () {
            return {
                optionTextValue: "Name",
                optionIDValue: "Id",
                tabIndex: 0,
                controlID: "templateID",
                cssClass: "width500",
                width: 200,
                no_List_Item_String: "",
                hasValidation: true,
                optionCaption: i18n.KO_SelectText
            };
        },

        createmultiSeverityDropdownOption: function () {
            return {
                optionTextValue: "name",
                optionIDValue: "id",
                tabIndex: 0,
                controlID: "severityID",
                cssClass: "",
                width: 200,
                no_List_Item_String: "",
                hasValidation: true,
                selectAllText: i18n.AtHoc_Common_Select_All,
                countSelectedText: "Count",
                noneString: i18n.WAMRule_Condition_SelectText
            };
        },
        createmultiEventTypeDropdownOption: function () {
            return {
                optionTextValue: "name",
                optionIDValue: "id",
                tabIndex: 0,
                controlID: "severityID",
                cssClass: "",
                width: 200,
                no_List_Item_String: "",
                hasValidation: true,
                selectAllText: i18n.AtHoc_Common_Select_All,
                countSelectedText: "Count",
                noneString: i18n.WAMRule_Condition_SelectText
            };
        },
        //IWS-32561
        createmultiMessageTypeDropdownOption: function () {
            return {
                optionTextValue: "name",
                optionIDValue: "id",
                tabIndex: 0,
                controlID: "messageID",
                cssClass: "",
                width: 200,
                no_List_Item_String: "",
                hasValidation: true,
                selectAllText: i18n.AtHoc_Common_Select_All,
                countSelectedText: "Count",
                noneString: i18n.WAMRule_Condition_SelectText
            };
        },
        createDetailPageOption: function() {
            return {
                cancelButtonText: i18n.WAMRule_Details_Cancel,
                saveButtonText: i18n.WAMRule_Details_Save,
                breadCrumbSettingText: i18n.WAMRule_Breadcrumb_Settings_Title,
                breadCrumbPageText: i18n.WAMRule_Breadcrumb_WAM_Title,
                breadCrumbNewPageText: i18n.WAMRule_Details_NewRule,
                breadCrumbEditPageText: i18n.WAMRule_Details_EditRule,
                confirmMessage: i18n.WAMRule_Details_Confirm_Message,
                failedMessage: i18n.WamRule_Detail_Error_Message,
                successMessage: i18n.WAMRule_Details_Sucess_Message,
                loaderrorMessage: i18n.WAMRule_Load_failed_Message,
                information: i18n.WAMRule_Message_Popup_Title_Information,
                warning: i18n.WAMRule_Message_Popup_Title_Warning,
                error: i18n.WAMRule_Message_Popup_Title_Error,
                success: i18n.WAMRule_Message_Popup_Title_Success,
                completed: i18n.WAMRule_Message_Popup_Title_Completed,               
                weatherText: i18n.WAMRule_Details_Weather
            };
        },
        createConfirmOption: function () {
            return {
                confirmButtonText: i18n.WAMRule_Delete,
                cancelButtonText: i18n.WAMRule_Cancel,
                dlgClass: "width650",
                title: i18n.WAMRule_Delete_Title,
                body: i18n.WAMRule_Delete_Body
            };
        },

        showAjaxLoader: function (elementToBlock) {
            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(elementToBlock), imageURL: athoc.iws.rule.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', padding: "10px", displayText: athoc.iws.rule.resources.General_LoadingMessage }).showLoader();
        },

        hideAjaxLoader: function (elementToBlock) {
            $.AjaxLoader.hideLoader(undefined, undefined, elementToBlock);
        },

        makeAjaxCall: function(url, postData, successCallback, failCallback, async, elementToBlock,isCustomAjaxLoader) {
            var self = this;
            elementToBlock = (typeof elementToBlock === 'undefined') ? '.title-bar' : elementToBlock;
            if (isCustomAjaxLoader!= undefined && !isCustomAjaxLoader)
            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(elementToBlock), imageURL: athoc.iws.rule.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.rule.resources.General_LoadingMessage }).showLoader();
            

            var dlSuccess = function (data) {
               if (isCustomAjaxLoader != undefined && !isCustomAjaxLoader)
               self.hideAjaxLoader(elementToBlock);
                if (data.Success) {
                    if (successCallback) {
                        successCallback(data);
                    }
                } else {
                    self.handleError(data);
                    if (failCallback) {
                        failCallback(data);
                    }
                }
            };

            var dlAjaxOption =
            {
                contentType: 'application/json',
                dataType: 'json',
                type: "POST",
                data: JSON.stringify(postData),
                url: url,
                async: async == null ? true : async
            };
            var dlError = function(data) {
                $.AjaxLoader.hideLoader();
                self.handleError(data);
                if (failCallback) {
                    failCallback(data);
                }
            }
            var ajaxOptions = $.extend({}, AjaxUtility(dlError, dlSuccess).ajaxPostOptions, dlAjaxOption);
            $.ajax(ajaxOptions);
        },

        handleError: function(e) {
            var self = this;
            if (e != undefined && e.status == 401) {
                window.onbeforeunload = null;
                window.location = window.location;
            }
            var res = e.xhr ? e.xhr.responseText : e.responseText;
            if (res) {
                // load event manager util for 
                var timeOut = self.sessionTimeOut(res);
                if (timeOut) {
                    return;
                }
            }
        },
        sessionTimeOut: function (response) {
            var timeOut = false;
            if (response.indexOf && (response.indexOf(i18n.Event_SessionTimeOut_Condition1) > -1 || response.indexOf(i18n.Event_SessionTimeOut_Condition2) > -1)) {
                window.location.href = "/client/auth/login?iwslogin=false";
                timeOut = true;
            }
            return timeOut;
        },
        createSingleSelectDropDownOptions: function () {
            return {
                optionTextValue: "",
                optionIDValue: "",
                cssClass: "",
                tabIndex: 0,
                no_List_Item_String: "",
                width: "",
                controlID: "",
                hasValidation: false,
                optionCaption: ""
            };
        },

        loadRuleDetailPage: function (ruleId, ruleName, selectedTabName) {
            var loadUrl = "";
            if (selectedTabName == athoc.iws.rule.resources.WAMRule_TabWeather) {
                loadUrl = "/athoc-iws/Rule/RuleDetail?ruleId=" + ruleId;
            }
            window.location = loadUrl;
        },
        LoadListPage: function (ruleId, selectedTabName) {
            var loadUrl = "";
            loadUrl = "/athoc-iws/rule?tabName=" + selectedTabName;
            window.location = loadUrl;
        },
        deleteWeather: function (ids, successCallback, failCallback) {          
            var loadUrl = "/athoc-iws/Rule/DeleteWeather";
            this.makeAjaxCall(loadUrl, {
                ids: ids }, successCallback, failCallback,null,'#weather-list',false);           
            },
        bindDataModel: function (providerId, filterIds, ruleId, successCallback, failCallback) {
            var loadUrl = "/athoc-iws/Rule/PopulateDataSource";
            this.makeAjaxCall(loadUrl, { providerId: providerId, filterIds: filterIds, ruleId: ruleId }, successCallback, failCallback,undefined,undefined,true);
        },
        getAllStates: function (successCallback, failCallback)
        {
            var loadUrl = "/athoc-iws/Rule/GetAllStates";
            this.makeAjaxCall(loadUrl, '', successCallback, failCallback, undefined, undefined, undefined);
        }
    };

    return common;
});
