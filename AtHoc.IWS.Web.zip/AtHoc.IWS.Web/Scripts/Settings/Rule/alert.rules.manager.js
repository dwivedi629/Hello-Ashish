﻿define([
    "common/baseView",
    "rule/utils",
    "rule/AlertRules/Model",
    "dojo/text!rule/AlertRules/template.html",
    "wam/grid.WAM",
    "common/navigation",
    "common/tabs",
    "common/grid",
    "rule/ruleDetail",
    "common/confirmationDialog"

], function (baseView, utils, model, template, weatherGrid, navigationView, tabsControl, baseCommonGrid, ruleDetailView, confirmDialog) {
    var baseGrid, weatherProvider;
    //constructor 
    var alertRules = function (refNode, navigationRefNode, gridManager, selectedTab, enabledVps) {
        this.base = baseView.call(this, gridManager, template, model, []);
        if ($.type(refNode) === "string") {
            this.parentRefNode = $("#" + refNode);
        } else {
            this.parentRefNode = refNode;
        }

        this.resources = "";
        this.URLs = WeatherUrls;
        this.selectedTab = selectedTab;
        this.tabSelectedName = selectedTab;
        this.confirmationDialog = new confirmDialog(utils.createConfirmOption());
        this.navigationRefNode = navigationRefNode;
        this.enabledVps = enabledVps;
        this.controlById = [];

        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
        this.requireRefresh = false;
        this.canRefresh = true;
    };

    $.extend(alertRules.prototype, {

        init: function () {
            var self = this;
            var showLoaderFlag = false;
            this.navigationModel = {
                sections: [
                    {
                        dataPage: "ruleList",
                        actions: [
                                     {
                                         id: "Delete", text: athoc.iws.rule.resources.WAMRule_Delete, primary: false, enable: false, btnToolTip: athoc.iws.rule.resources.EventRule_Manager_Btn_Delete_Tip, click: function () {
                                             if (self.tabName == self.tabNames.weather)
                                                 weatherProvider.deleteWeathers();
                                             else
                                                 athoc.iws.rule.deleteRules(); return false;
                                         }
                                     },
                                    {
                                        id: "Export", text: athoc.iws.rule.resources.WAMRule_Export, primary: false, enable: false, visible: true, btnToolTip: athoc.iws.rule.resources.WAMRule_Export, click: function () {
                                            self.ExportToCSV();
                                        }
                                    },
                                    {
                                        id: "NewRule", text: athoc.iws.rule.resources.WAMRule_New, primary: true, enable: true, btnToolTip: athoc.iws.rule.resources.EventRule_Manager_Btn_New_Rule_Tip, click: function () {
                                            if (self.tabName == self.tabNames.weather) {
                                                if (self.enabledVps == true)
                                                utils.loadRuleDetailPage(0, "", self.tabName);
                                            }
                                            else
                                                athoc.iws.rule.showRule(0); return false;
                                        }
                                    }
                        ]
                    },
                    {
                        dataPage: "ruleDetail",
                        visible: false,
                        actions: [
                                    {
                                        id: "Cancel", text: athoc.iws.rule.resources.WAMRule_Cancel, primary: false, visible: true, click: function () {
                                            athoc.iws.rule.onRuleDetailNavigateAway(); return false;
                                        }
                                    },
                                    { id: "Save", text: athoc.iws.rule.resources.WAMRule_Save, primary: true, visible: true, click: function () { athoc.iws.rule.saveRule(); return false; } }
                        ]
                    }
                ]
            };

            var navigationOption = utils.createNavigationOption();
            this.navigationView = new navigationView(this.navigationRefNode, this.navigationModel, navigationOption);
            this.navigationView.startup();


            this.tabsModel = [
                { id: this.tabNames.organization, Name: athoc.iws.rule.resources.WAMRule_TabConnect },
                { id: this.tabNames.weather, Name: athoc.iws.rule.resources.WAMRule_TabWeather }

            ];

            this.tabsControl = new tabsControl(this.refDomNode.find(".event-tabs"), this.tabsModel);
            this.tabsControl.startup();

            this.tabsControl.on("onSelect", function (prevSelecededTabName, selectedTabName) {

                if (prevSelecededTabName !== selectedTabName) {
                    var prevTabView = self.controlById[prevSelecededTabName];
                    if (prevTabView && prevTabView.onHide) {
                        prevTabView.onHide();
                    }

                    var tabView = self.controlById[selectedTabName];
                    if (tabView && tabView.onShow) {
                        tabView.onShow();
                    }
                }


            });

            this.tabsControl.on("onShow", function (prevSelecededTabName, selectedTabName) {
                if (self.enabledVps == false && selectedTabName == self.tabNames.weather) {
                    self.navigationView.getAction("NewRule").enable(false);
                    self.tabsControl.getTabContentElement(self.tabNames.weather).html('');
                    self.tabsControl.getTabContentElement(self.tabNames.weather).append(kendo.template($("#NoWeatherRecords").html())({ message: athoc.iws.rule.resources.WAMRule_NoRecords }));
                }
                if (selectedTabName == self.tabNames.organization) {
                    $("#tabstrip-1").append($("#ruleList"));
                    $("#ruleList").css("margin-top", "10px");
                    $("#ruleList").show();
                    self.navigationView.getAction("NewRule").enable(true);
                    self.navigationView.getAction("Export").visible(false);
                    self.navigationView.getAction("Delete").enable(self.orgCount > 0);
                }
                else if (selectedTabName == self.tabNames.weather) {
                    $("#weather-list .k-grid-header").css("width", "907px");
                    $("#weather-list").css("margin-top", "10px");
                    if (self.showLoaderFlag)
                        utils.showAjaxLoader('.title-bar');
                    self.navigationView.getAction("Export").visible(true);
                    self.navigationView.getAction("Delete").enable(self.weatherCount > 0);
                    $("#ruleMessagePanel").hide();
                }
                self.tabName = selectedTabName;
            });

            this.createTabControl(this.tabNames.organization, '');

            //For selecting the Tab
            var urlTabName = self.selectUrlTab('tabName');
            if (urlTabName != undefined) {
                this.tabSelectedName = this.tabNames.weather;
                window.history.pushState(null, null, "/athoc-iws/rule");
            }

            if (this.enabledVps == true) {

                this.createTabControl(this.tabNames.weather, weatherGrid);
                var gridOptions = utils.createGridOptions();
                weatherProvider = new weatherGrid(this.refDomNode.find(".user-listing"), this.URLs.GetWeatherListUrl, gridOptions, this.confirmationDialog);
                baseGrid = new baseCommonGrid(weatherProvider.gridNode, weatherProvider, false, true, false, false);
                baseGrid.showAjaxLoader = function () {
                    self.showLoaderFlag = true;
                    if (self.tabSelectedName == self.tabNames.weather) {
                        utils.showAjaxLoader('.title-bar');
                    }
                },
                baseGrid.hideAjaxLoader = function () {
                    self.showLoaderFlag = false;
                    utils.hideAjaxLoader('.title-bar');
                },
                baseGrid.startup();
                weatherProvider.onSelectionChanged = function (count) {
                    self.navigationView.getAction("Export").enable(count);
                    self.navigationView.getAction("Delete").enable(count);
                    self.weatherCount = count;
                },
                weatherProvider.refreshWAMGrid = function () {
                    baseGrid.refreshGrid();
                    self.navigationView.getAction("Export").enable(false);
                    self.navigationView.getAction("Delete").enable(false);
                }
            }

            this.tabsControl.select(this.tabSelectedName);
            athoc.iws.rule.on("selectionChanged", function (count) {
                self.navigationView.getAction("Delete").enable(count > 0);
                self.orgCount = count;
            });
        },
        isValidTab: function (tabName) {
            var self = this;
            var isValid = false;
            $.each(self.tabNames, function (key, value) {
                if (tabName === value)
                    isValid = true;
            });
            return isValid;
        },


        createTabControl: function (name, control) {
            var self = this;
            if (name == athoc.iws.rule.resources.WAMRule_TabWeather) {
                var tabView = new control(self.tabsControl.getTabContentElement(name), '', utils.createGridOptions());
                this.controlById[name] = tabView;
                tabView.startup();
            }

        },


        getModel: function () {
            return {};
        },


        selectTab: function (tabName, filter) {
            this.tabsControl.select(tabName);
            var view = this.controlById[tabName];
            if (view.onShow && filter != null && tabName == athoc.iws.rule.resources.WAMRule_TabWeather) {
                view.onChangeStatus(filter);
            }
            else {

            }
        },
        tabNames: {
            organization: athoc.iws.rule.resources.WAMRule_TabConnect,
            weather: athoc.iws.rule.resources.WAMRule_TabWeather

        },
        selectUrlTab: function (name) {
            if (window.location.href.indexOf("tabName") > -1) {
                var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
                return results[1] || 0;
            } else {
                return null;
            }
        },
        ExportToCSV: function () {
            var grid = $("#weather-list").getKendoGrid();
            var rows = "";
            rows += athoc.iws.rule.resources.WAMRule_ExportHeaders + "\n";
            var trs = $("#weather-list").find('tr');
            for (var i = 1; i < trs.length; i++) {
                var dataItem = grid.dataItem(trs[i]);
                if (dataItem.IsChecked) {
                    if (dataItem.WeatherCounty == undefined)
                        dataItem.WeatherCounty = '';
                    if (dataItem.Action == undefined)
                        dataItem.Action = '';
                    if (dataItem.isEnable == undefined)
                        dataItem.isEnable = '';
                    if (dataItem.WeatherSeverityType == undefined)
                        dataItem.WeatherSeverityType = '';
                    if (dataItem.WeatherEventType == undefined)
                        dataItem.WeatherEventType = '';
                   
                    if (dataItem.ScenarioName == undefined)
                        dataItem.ScenarioName = '';
                    rows += '"' + dataItem.Name.replace(/\"/g, '\'\'') + '","' + dataItem.WeatherCounty + '","' + dataItem.WeatherSeverityType + '","' + dataItem.WeatherEventType + '","' + dataItem.ScenarioName + '","' + dataItem.isEnable + '"';
                    rows += '\n';
                }
            }
            var csvfileName = athoc.iws.rule.resources.WAMRule_Export_File_Name + ".csv";

            var blob = new Blob([rows], { type: 'text/csv;charset=utf-8' });
            saveAs(blob, csvfileName);
        }


    });

    return alertRules;
});