﻿define([
    "common/baseView",
    "rule/utils",
    "rule/RuleDetail/Model",
    "dojo/text!rule/RuleDetail/template.html",
    "common/navigation",
    "wam/wamGeneral",
    "wam/wamCondition",
    "wam/wamAction"

], function (BaseView, utils, Model, template, navigationView, generalView, conditionView, actionView) {
    //constructor 
    var RuleDetail = function (refNode, navigationRefNode, ruleID, ruleName, IsWAMSupported) {
        var self = this;
        self.detailOptions = utils.createDetailPageOption();

        if (IsWAMSupported != undefined && IsWAMSupported == false) {
            utils.LoadListPage('', self.detailOptions.weatherText);
        }
        else {
            BaseView.call(this, refNode, template, Model, []);
            self.model.HasValidation(false);
            self.resources = "";
            self.navigationRefNode = navigationRefNode;
            self.RuleId = ruleID;
            self.RuleName = ruleName;
            self.model.breadCrumbName(ruleName);
            self.ruleById = [],
            self.RuleModel = [];
            self.isSaveClick = "N";
            self.baseStartup = self.startup;
            self.startup = function () {
                self.baseStartup.call(self);
                self.init();
            };
        }
        

    };
    $.extend(RuleDetail.prototype, {

        init: function () {
            var self = this;
            self.errorTitleStrings = new Array();

            self.navigationModel = {
                sections: [
                    {
                        dataPage: "ruleDetail",
                        actions: [
                               {
                                   id: "cancel", text: $.htmlDecode(self.detailOptions.cancelButtonText), primary: false, click: function () {
                                       self.checkForDirtyScreen();
                                   }
                               },
                               {
                                   id: "save", text: $.htmlDecode(self.detailOptions.saveButtonText), primary: true, click: function () {
                                       self.saveWeatherRule();
                                   }
                               }
                        ]
                    }
                ]
            };

            //Navigation View initiating
            var navigationOption = utils.createNavigationOption();
            self.navigationView = new navigationView(self.navigationRefNode, self.navigationModel, navigationOption);
            self.navigationView.startup();
            //~m
            self.onReadyChange = function (isReady) {
                self.navigationView.getAction("save").enable(isReady);
            };


            self.errorTitleStrings.push(self.detailOptions.information);
            self.errorTitleStrings.push(self.detailOptions.warning);
            self.errorTitleStrings.push(self.detailOptions.error);
            self.errorTitleStrings.push(self.detailOptions.success);
            self.errorTitleStrings.push(self.detailOptions.completed);

            self.breadcrumbModel = new BreadcrumbModel();
            //Page breadcrumb
            var settingLink = new Breadcrumb('settingLink', self.detailOptions.breadCrumbSettingText, '', function () {
                window.location.href = "/client/setup/settings";
            });
            var pageLink = new Breadcrumb('pageLink', self.detailOptions.breadCrumbPageText, '', function () {
                //if (self.isDirty()) {
                // var confirmLeave = confirm(self.detailOptions.confirmMessage);
                //if (confirmLeave == true) {
                utils.LoadListPage('', self.detailOptions.weatherText);
                // }
                // }
                // else {
                // $(window).scrollTop(0);
                //}

            });


            var pageBreadCrumb = new PageBreadcrumb('ruleDetail', self.detailOptions.breadCrumbPageText, [settingLink], '');

            //To New Rule data
            var newPageBreadcrumb = new PageBreadcrumb('newRule', self.detailOptions.breadCrumbNewPageText, [settingLink, pageLink], '');

            //To Edit Rule data
            var editPageBreadcrumb = new PageBreadcrumb('editRule', self.model.breadCrumbName(), [settingLink, pageLink], '');

            self.breadcrumbModel.addPage(pageBreadCrumb);
            self.breadcrumbModel.addPage(newPageBreadcrumb);
            self.breadcrumbModel.addPage(editPageBreadcrumb);

            // bind breadcrumb
            if (self.RuleId > 0)
                self.breadcrumbModel.SelectedPage('editRule');
            else
                self.breadcrumbModel.SelectedPage('newRule');

            ko.applyBindings(self.breadcrumbModel, $("#pageBreadcrumbs").get(0));
            $.titleCrumb("pageBreadcrumbs");




            //General Component
            var generalOptions = utils.createGeneralOption();
            self.generalDetail = new generalView(self.refDomNode.find("#generalDetail"), self.generalModel, generalOptions);
            self.generalDetail.startup();
            //~m
            self.generalDetail.onReadyChange = function (isReady) {
                self.refDomNode.find("#ruleDetailMessagePanel").hide();
                self.isGeneralSectionReady = isReady;
                if (self.generalDetail.model.EnabledYN() == "N") {
                    self.actionDetail.model.isActionSectionReady(true);
                    self.conditionDetail.model.isConditionSectionReady(true);
                }
                self.breadcrumbModel.updateTitle(self.generalDetail.getScenarioName());
                self.onReadyChange(self.checkAllSectionReady());
            };
            self.generalDetail.onEnabledChange = function (newValue) {
                ////if (newValue == "N") {
                //self.actionDetail.validateTemplate(newValue);
                //// }
                //self.model.HasValidation(newValue);
                if ($.trim(self.generalDetail.model.Name()) != "" && self.generalDetail.model.Name() != undefined)
                    self.generalDetail.model.isGeneralSectionReady(true);
                else
                    self.generalDetail.model.isGeneralSectionReady(false);

                if (newValue == "N") {
                    self.actionDetail.model.isActionSectionReady(true);
                    self.conditionDetail.model.isConditionSectionReady(true);
                }
                self.conditionDetail.validateCounties(newValue);
                self.actionDetail.validateTemplate(newValue);
                self.model.HasValidation(newValue);
                self.refDomNode.find("#ruleDetailMessagePanel").hide();
                self.onReadyChange(self.checkAllSectionReady());


            };

            //Condition Component
            var conditionOptions = utils.createConditionOption();
            //conditionOptions.Urls = WeatherUrls;
            self.conditionDetail = new conditionView(self.refDomNode.find("#conditionDetail"), conditionOptions);
            self.conditionDetail.startup();
            self.conditionDetail.onReadyChange = function (isReady) {
                self.refDomNode.find("#ruleDetailMessagePanel").hide();
                self.conditionDetail.model.isConditionSectionReady(isReady);
                self.onReadyChange(self.checkAllSectionReady());
            };
            /*self.conditionDetail.onClick = function () {
                alert("hi");
            };*/

            //Action Component
            var actionOptions = utils.createActionOption();
            self.actionDetail = new actionView(self.refDomNode.find("#actionDetail"), actionOptions);
            self.actionDetail.startup();
            self.actionDetail.onTemplateChange = function () {
                self.refDomNode.find("#ruleDetailMessagePanel").hide();
                if (self.generalDetail.model.EnabledYN() == "N")
                    self.actionDetail.model.isActionSectionReady(true);
                self.onReadyChange(self.checkAllSectionReady());
            };

            //Show warning message if any unsaved data
            window.onbeforeunload = function (event) {
                if (self.isDirty()) {
                    return self.detailOptions.confirmMessage;
                }
                else {
                    $(window).scrollTop(0);
                }
            }
            self.addEllipsisToDropdown();

            if (self.RuleId == 0)
                self.conditionDetail.refDomNode.find("#conditionCountiesDiv #dvLink").removeClass("hide");
            //Calling load method      
            this.bindDataModel("", "", self.RuleId);
        },

        //This method will bind the data on load in case of (Edit/New) Rule
        bindDataModel: function (providerId, filterIds, ruleId) {
            var self = this;
            utils.showAjaxLoader('.title-bar');
            
            var successFunction = function (data) {
                $.each(data.RuleList, function (index, rule) {
                    self.ruleById[rule.Id] = rule;
                    if (rule.Id == ruleId)
                        self.breadcrumbModel.updateTitle(rule.Name, undefined, undefined, 'editRule');
                });
                $.each(data.Data, function (index, item) {
                    if (item.FilterId != undefined && item.FilterId == "SCENARIOS") {
                        self.actionDetail.fillAlertTemplateDropDown(item.Data);
                    }
                    $.each(item.Data, function (index, value) {
                        if (item.FilterId == undefined) {
                            self.RuleModel[value.id] = value;
                            if (value.commonName != null && value.commonName != undefined) {
                                if (value.commonName == "WAM-SEVERITY") {
                                    self.conditionDetail.fillSeverityDropDown(value.values);
                                }
                                else if (value.commonName == "WAM-EVENT-TYPE") {
                                    self.conditionDetail.fillEventTypeDropDown(value.values.sort(self.compare));
                                }
                                //IWS-32561
                                else if (value.commonName == "WAM-MESSAGE-TYPE") {
                                    self.conditionDetail.fillMessageTypeDropDown(value.values.sort(self.compare));
                                }
                            }
                        }

                    });

                });
                if (ruleId == 0)
                    utils.hideAjaxLoader('.title-bar');
                //Setting the datatmodel on edit
                self.setRuleDetailBinding(data.CriteriaModel, ruleId)

                $(window).scrollTop(0);
                self.actionDetail.isDataChanged = false;
                self.generalDetail.isDataChanged = false;
                self.conditionDetail.isDataChanged = false;
                if (self.isSaveClick == "Y")
                    self.showSuccessMessage(self.detailOptions.successMessage);

                utils.hideAjaxLoader('.title-bar');

            }
            var onerror = function () {
                utils.hideAjaxLoader('.title-bar');
                self.showErrorMessage(self.detailOptions.loaderrorMessage);
            };
            
            utils.bindDataModel(providerId, filterIds, ruleId, successFunction, onerror);

        },






        //Setting the datatmodel on edit
        setRuleDetailBinding: function (CriteriaModel, ruleId) {
            var self = this;
            var ruleInfo = self.getRuleById(ruleId);
            if (CriteriaModel != null) {
                
                $.each(CriteriaModel.selections, function (index, item) {

                    if (item.commonName != null && item.commonName != undefined) {
                        if (item.commonName == "WAM-SEVERITY") {
                            self.conditionDetail.setSelectedSeverity(item.value.map(function (x) { return x.id; }));
                        }
                        else if (item.commonName == "WAM-EVENT-TYPE") {
                            self.conditionDetail.setSelectedEventType(item.value.map(function (x) { return x.id; }));
                        }
                        // IWS-32561
                        else if (item.commonName == "WAM-MESSAGE-TYPE") {
                            self.conditionDetail.setSelectedMessageType(item.value.map(function (x) { return x.id; }));
                        }
                        else if (item.commonName == "WAM-SEARCH-KEYWORD") {
                            self.conditionDetail.setOtherFormsValue(item.value.map(function (x) { return x.text; }))
                        }
                        else if (item.commonName == "WAM-COUNTY") {
                            self.refDomNode.find("#conditionCountiesDiv #dvLink").removeClass("hide");
                            self.conditionDetail.setCounties(item.value.map(function (x) { return x.text; }))
                        }
                        
                    }

                });

            }
            
            if (ruleInfo != null && ruleId != undefined) {
                self.actionDetail.setSelectedScenarioID(ruleInfo);
                self.actionDetail.setGeoEnabled(ruleInfo);
                self.actionDetail.isDataChanged = false;
                self.generalDetail.fillGeneralDetail(ruleInfo);
                self.generalDetail.isDataChanged = false;
                this.onReadyChange(true);
            }
            else
                this.onReadyChange(false);


        },


        //Show Success Message
        showSuccessMessage: function (msg, isDetailView) {
            var self = this;
            self.refDomNode.find("#ruleDetailMessagePanel").messagesPanel({ messages: [{ Type: '8', Value: msg }] }, null, null, null, self.errorTitleStrings);
            $('html,body').scrollTop(0);
        },

        //Show Error Message if any
        showErrorMessage: function (msg, isDetailView) {
            var self = this;
            self.refDomNode.find("#ruleDetailMessagePanel").messagesPanel({ messages: [{ Type: '4', Value: msg }] }, null, null, null, self.errorTitleStrings);
            $('html,body').scrollTop(0);

        },

        validateControls: function () {
            var self = this;
            if (self.generalDetail.model.Name() == "" || self.generalDetail.model.Name() == undefined)
                self.generalDetail.model.isGeneralValidate("Y")

            if (self.generalDetail.model.EnabledYN() == "N") {
                self.actionDetail.model.isActionSectionReady(true);
                self.conditionDetail.model.isConditionSectionReady(true);
            }
            self.conditionDetail.validateCounties(self.generalDetail.model.EnabledYN());
            self.actionDetail.validateTemplate(self.generalDetail.model.EnabledYN());
            //self.model.HasValidation(newValue);
            //self.onReadyChange(self.checkAllSectionReady());
            return self.checkAllSectionReady();
        },
        //Save Weather Rules
        saveWeatherRule: function () {
            var self = this;
            if (self.validateControls()) {
                //if (self.actionDetail.validateTemplate(self.model.HasValidation())) return false;
                var model = this.getModel();
                var dlSuccess = function (data) {
                    self.RuleId = data.Id;
                    self.breadcrumbModel.updateTitle(self.generalDetail.getScenarioName());
                    self.actionDetail.isDataChanged = false;
                    self.generalDetail.isDataChanged = false;
                    self.conditionDetail.isDataChanged = false;
                    self.isSaveClick = "Y";
                    self.bindDataModel("", "", self.RuleId);

                    self.showSuccessMessage(self.detailOptions.successMessage);
                };

                var error = function (data) {
                    utils.hideAjaxLoader('.title-bar');
                    self.showErrorMessage(self.detailOptions.failedMessage);
                };

                //Ajax call
                utils.makeAjaxCall(athoc.iws.ruleDetail.urls.SaveWeatherRule, model, dlSuccess, error);
            }
        },

        //Preparing model for save
        getModel: function () {
            var self = this;

            var ruleInfo;
            if (self.RuleId == 0) {
                ruleInfo = {
                    Id: 0,
                    CriteriaEntityId: 0,
                    Order: self.getNewRuleOrder()
                };
            } else {
                ruleInfo = self.getRuleById(self.RuleId);
            }
            if (ruleInfo != null && ruleInfo != undefined) {
                ruleInfo.WeatherSeverityType = [];
                ruleInfo.WeatherEventType = [];
                ruleInfo.countiesDetails = [];
                ruleInfo.keywords = [];
                ruleInfo.WeatherMessageType = [];

                //Severy Model Setup
                $.each(self.conditionDetail.getSelectedSeverity(), function (index, item) {
                    ruleInfo.WeatherSeverityType.push({ id: item })
                });

                //EventType Model Setup
                $.each(self.conditionDetail.getSelectedEventType(), function (index, item) {
                    ruleInfo.WeatherEventType.push({ id: item })
                });

                //IWS-32561
                //MessageType Model Setup
                $.each(self.conditionDetail.getSelectedMessageType(), function (index, item) {
                    ruleInfo.WeatherMessageType.push({ id: item })
                });

                //TODO: Counties Model Setup

                ruleInfo.Scenario = self.actionDetail.getSelectedScenarioID();
                ruleInfo.keywords.push({ text: self.conditionDetail.getOtherFormsValue() });
                ruleInfo.isEnable = self.generalDetail.getEnableDisableValue();
                ruleInfo.Name = self.generalDetail.getScenarioName();
                ruleInfo.GeoEnabled = self.actionDetail.model.GeoEnabled() ? "Y" : "N";
                ruleInfo.isWeatherModule = true;
                ruleInfo.SearchCriteriaInput = self.getSearchCriteriaModel(ruleInfo);
                ruleInfo.countiesDetails.push({ text: self.conditionDetail.getCounties().join(",") });
            }
            return ruleInfo;

        },
        //forming criteria in form of advance query builder
        getSearchCriteriaModel: function (ruleInfo) {
            var self = this;
            var selectionArray = new Array();
            self.RuleModel.forEach(function (item) {
                selectionArray.push({
                    entity: {
                        name: item.name,
                        dataType: item.dataType,
                        dataTypeId: item.dataTypeId,
                        commonName: item.commonName,
                        entityType: item.entityType,
                        id: item.id,
                        hierarchyId: item.hierarchyId
                    },
                    operand: 3,
                    operandName: "Contains",
                    value: self.getValue(item.commonName, ruleInfo)
                });


            });
            return {
                display: "",
                selections: selectionArray,
                displayNoStyle: ""
            }
        },

        getValue: function (commonName, ruleInfo) {
            var self = this;
            if (commonName != null && commonName != undefined) {
                if (commonName == "WAM-SEVERITY")
                    return ruleInfo.WeatherSeverityType;
                else if (commonName == "WAM-EVENT-TYPE")
                    return ruleInfo.WeatherEventType;
                 // IWS-32561
                else if (commonName == "WAM-MESSAGE-TYPE")
                    return ruleInfo.WeatherMessageType;
                else if (commonName == "WAM-SEARCH-KEYWORD")
                    return ruleInfo.keywords;
                else if (commonName == "WAM-COUNTY")
                    return ruleInfo.countiesDetails;
            }
        },
        //New Rule order
        getNewRuleOrder: function () {
            var self = this;
            var maxRuleOrder = 0;
            self.ruleById.forEach(function (rule) {
                if (rule.Order > maxRuleOrder) {
                    maxRuleOrder = rule.Order;
                }
            });
            return maxRuleOrder + 1;
        },
        //Check for screen unsaved data
        checkForDirtyScreen: function () {
            var self = this;
            // if (self.isDirty()) {
            //var confirmLeave = confirm(self.detailOptions.confirmMessage);
            // if (confirmLeave == true) {
            utils.LoadListPage('', self.detailOptions.weatherText);
            //}
            //else {
            //    $(window).scrollTop(0);
            //}
            // }
        },

        isDirty: function () {
            var self = this;
            return (self.generalDetail.isDataChanged || self.actionDetail.isDataChanged || self.conditionDetail.isDataChanged);
        },
        isGeneralSectionReady: true,
        isConditionSectionReady: true,
        isActionSectionReady: true,
        checkAllSectionReady: function () {

            var self = this;
            return (self.generalDetail.model.isGeneralSectionReady() && self.conditionDetail.model.isConditionSectionReady() && self.actionDetail.model.isActionSectionReady());
        },

        //Getting the existing rule in edit
        getRuleById: function (id) {
            var self = this;
            return self.ruleById[id];
        },

        //Getting the existing rule in edit
        getRuleModelById: function (id) {
            var self = this;
            return self.RuleModel[id];
        },
        //To fix Jira bug 30968
        addEllipsisToDropdown: function () {
            $(".selectallcontainer").addClass("ellipsis");
        },

        //Sorting 
        compare: function (a, b) {
            if (a.name < b.name)
                return -1;
            if (a.name > b.name)
                return 1;
            return 0;
        }
    });

    return RuleDetail;
});