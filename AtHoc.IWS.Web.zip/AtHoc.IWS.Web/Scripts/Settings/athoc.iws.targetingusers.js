﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.targetingusers = athoc.iws.targetingusers || {};

if (athoc.iws.targetingusers) {
    window.onbeforeunload = function (event) {
        var isModified = athoc.iws.targetingusers.editmodel.isRefresh();
        if (isModified) {
            return "";
        } else {
            $(window).scrollTop(0);
        }
    },
    athoc.iws.targetingusers = function () {
        return {
            //Use Legacy or new
            UseLegacyDetail: true,
            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},
            editmodel: { nodemodel: ko.observable(), isAdd: ko.observable(true), isDelete: ko.observable(false), isRefresh: ko.observable(false), isCollapse: ko.observable(true), sTitle: ko.observable("") }
            ,
            ListModel: kendo.observable(
               {
                   TotalCount: 0,
                   SelectedCount: 0,
               }),
            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},
            //init method for scenario list, will be triggered before document load
            init: function () {
                athoc.iws.targetingusers.initBreadcrumb();
                navigateToPage('viewTargetingUsers', function () { });
            },
            //load method, will be tirggered on document load
            load: function () {
                athoc.iws.targetingusers.bindBreadcrumb();
                $("#btn_Cancel").click(function () {
                    $('#HierarchyEdit').modal('hide');
                });

                $("#btn_Save").click(function () {
                    athoc.iws.targetingusers.SaveDetails();
                });
                $("#btn_search").click(function () {
                });

                // Load kendo grid
                athoc.iws.targetingusers.createTargettingUserListGrid();
                $('#TargettingUserList .k-grid-header').hide();
                $('#TargettingUserList .k-pager-wrap').hide();

                athoc.iws.targetingusers.createUserListGrid();
           
                kendo.bind($(".kendoBound"), this.ListModel);               
            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {
                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.targetingusers.breadcrumbModel;
                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', "Settings", '', function () {
                    window.location.href = "/client/setup/settings";
                });
                var hierarchydefinitionLink = new Breadcrumb('targetingUsersLink', "Targeting & Blocking Users", '', function () {
                    navigateToPage('viewTargetingUsers', function () { });
                    athoc.iws.targetingusers.breadcrumbModel.SelectedPage('viewTargetingUsers');
                    $.titleCrumb("pageBreadcrumbs");

                });

                //Page breadcrumb
                var viewPageBreadcrumb = new PageBreadcrumb('viewTargetingUsers', 'Targeting & Blocking Users', [settingLink], '');
                //To Edit Delivery template data
                breadcrumbsModel.addPage(viewPageBreadcrumb);

            },
            ClearPanel: function () {
                $("#update").css("display", "none");
                $("#information").css("display", "");},
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.targetingusers.breadcrumbModel;
                breadcrumbsModel.SelectedPage('viewTargetingUsers');
                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            openPopups: function (modalType, param) {
                $('#HierarchyEdit').modal('show');

            },

            //Method to handle erro and session time out, this is boud with Ajax calls
            handleError: function (e) {

                if ((e.xhr != undefined && e.xhr.responseText.indexOf(AjaxUtility().timeoutPageIndicatorString) != -1) || e.statusText == "InvalidSession") {
                    //IWS-7658: handling additional abort condition for FF
                    if (e.xhr.status != 0 && e.xhr.readyState != 0) {
                        window.location.href = dataservice.getServiceUrl('TimeoutErrorInLegacy');
                    }
                } else if (e.errorThrown != "") {
                    if (athoc.iws.targetingusers.errors === null) {
                        athoc.iws.targetingusers.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.targetingusers.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#saveMessagePanel').messagesPanel({ messages: this.errors });
                }
            },
            removeUserId:function(userId)
            {
                var raw = datasource.data();
                var length = raw.length;
                var item, i;
                for (i = length - 1; i >= 0; i--) {
                    if (raw[i].UserId == userId) {
                        item = raw[i];
                            datasource.remove(item);
                        break;
                    }

                }

            },
            listLoad: function () {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
            },
            createTargettingUserListGrid: function () {

                var self = this;
                var url = athoc.iws.targetingusers.urls.GetTargetingUsers;
                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                    },
                    requestStart: function (e) {
                    },
                    requestEnd: function (e) {

                        if (e.response) {

                        }
                    },
                    schema: {
                        data: "Data",
                    },
                    sort: { field: "Name", dir: "asc" },
                    pageSize: 20,
                    error: function (e) {
                        athoc.iws.targetingusers.handleError(e);
                    },
                    change: function (e) {

                    }
                });
                datasource.one("change", function () {
                    //pagination needs to be reset after a reload
                    this.page(1);
                });
                datasource.read();

                var grid = $("#TargettingUserList").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    top: 130,
                    selectable: false,
                    sortable: {
                        allowUnsort: false
                    },

                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount:5
                    },
                    columns:
                            [
                                
                                 {
                                     field: "",
                                     title: "",
                                     template: $("#targeting-imgtargeting-template").html(),
                                     headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "Users", ""),
                                     width: 5,
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                                {
                                    field: "Name",
                                    title: "",
                                    template: '<span title="#=Name#">#=Name#</span>',
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "Users", ""),
                                    width: 130,
                                    headerAttributes: {
                                        tabindex: "3"
                                    }
                                },                                
                                {
                                    field: "",
                                    title: "",
                                    template: $("#targeting-imgremove-template").html(),
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', "", ""),
                                    width: 10,
                                    headerAttributes: {
                                        tabindex: "5"
                                    }
                                },
                            ],
                    //dataBound: athoc.iws.targetingusers.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                    }
                }).data().kendoGrid;


            },

            createUserListGrid: function () {

                var self = this;
                var url = athoc.iws.targetingusers.urls.GetUserList;
                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                            parameterMap: function (options) {
                                $.extend(options, "{}");
                                return kendo.stringify(options);
                            },
                    },
                    requestStart: function (e) {
                    },
                    requestEnd: function (e) {

                        if (e.response) {

                        }
                    },
                    schema: {
                        data: "Rows",
                    },
                    sort: { field: "Name", dir: "asc" },
                    pageSize: 20,
                    error: function (e) {
                        athoc.iws.targetingusers.handleError(e);
                    },
                    change: function (e) {

                    }
                });
                datasource.one("change", function () {
                    //pagination needs to be reset after a reload
                    this.page(1);
                });
                datasource.read();

                var grid = $("#UserListCount").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    top: 130,
                    selectable: false,
                    sortable: {
                        allowUnsort: false
                    },

                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5
                    },
                    columns:
                            [

                                 {
                                     field: "FIRSTNAME",
                                     title: "",
                                     template: '<span title="#=FIRSTNAME#">#=FIRSTNAME#</span>',
                                     headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "First Name", ""),
                                     width: 5,
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                                {
                                    field: "LASTNAME",
                                    title: "",
                                    template: '<span title="#=LASTNAME#">#=LASTNAME#</span>',
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "Display Name", ""),
                                    width: 130,
                                    headerAttributes: {
                                        tabindex: "3"
                                    }
                                },
                                {
                                    field: "USERNAME",
                                    title: "",
                                    template: '<span title="#=DISPLAYNAME#">#=USERNAME#</span>',
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "User Name", ""),
                                    width: 10,
                                    headerAttributes: {
                                        tabindex: "5"
                                    }
                                },
                            ],
                    //dataBound: athoc.iws.targetingusers.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                    }
                }).data().kendoGrid;


            },
            //On Grid databound navigate to Edit page or View page w.r.t device Type
            OnDataBound: function () {

                $("#TargettingUserList tbody").find("tr").attr("tabindex", "0");
                var gridContent = $("#TargettingUserList").data("kendoGrid");
                var data = grid.dataSource.data();

           

            },

        };
    }();
}