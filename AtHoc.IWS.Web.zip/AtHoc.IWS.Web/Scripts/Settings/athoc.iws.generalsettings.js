﻿
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
if (athoc.iws) {
    var generalData;
    var isWebLogoExists = false;
    showPopup = function (sUrl, vArguments, sFeatures) {
        var wFeatures = sFeatures.replace(/dialog/gi, "").replace(/:/gi, "=").replace(/;/gi, ",");  // plus a little more replacement 
        var w = window.open(sUrl, "_blank", wFeatures);
        if (w.focus) {
            w.focus();
        }
    };
   
    var ColumnModel = function (displayName, type, name, id) {
        this.AttributeNameDisplay = displayName;
        this.AttributeType = type;
        this.AttributeName = name;
        this.Id = id;
        this.Selected = ko.observable(false);
        this.MarkedForRemove = ko.observable(false);
        return this;
    };

    var ColumnModelView = function () {
        var self = this;
        self.AttributeNames = ko.observableArray([]);
        self.SelectedAttributeNames = ko.observableArray([]);
        self.SelectedAttribute = undefined;
        self.IsSelected = ko.observable(false);
        self.IsMultiSelected = ko.observable(false);

        self.addAttribute = function (attributeDisplayName, type, attributeName, id) {
            self.AttributeNames.push(new ColumnModel(attributeDisplayName, type, attributeName, id));
        };
        self.addSelectedAttribute = function (attributeDisplayName, type, attributeName, id) {
            var newAttr = new ColumnModel(attributeDisplayName, type, attributeName, id);
            self.SelectedAttributeNames.push(newAttr);
        };

        self.MoveUp = function () {
            if (typeof (self.SelectedAttribute) !== 'undefined') {
                var i = self.SelectedAttributeNames.indexOf(self.SelectedAttribute);
                if (i >= 1) {
                    var array = self.SelectedAttributeNames();
                    self.SelectedAttributeNames.splice(i - 1, 2, array[i], array[i - 1]);
                }
            }
        };

        self.MoveDown = function () {
            if (typeof (self.SelectedAttribute) !== 'undefined') {
                var i = self.SelectedAttributeNames.indexOf(self.SelectedAttribute);
                var newPos = i + 1;
                if (i === -1) {
                    throw new Error('Element not found in array');
                }
                var array = self.SelectedAttributeNames();
                if (newPos >= array.length) {
                    newPos = array.length;
                }
                self.SelectedAttributeNames.splice(i, 1);
                self.SelectedAttributeNames.splice(newPos, 0, self.SelectedAttribute);
            }
        };

        self.Remove = function () {
            var deletedItems = [];
            $.each(self.SelectedAttributeNames(), function (index, attr) {
                if (attr.Selected() == true) {
                    deletedItems.push(attr);
                }
            });
            for (var i = 0; i < deletedItems.length; i++) {
                self.moveToAvailable(deletedItems[i]);
            }
        };

        self.MarkForRemove = function (attribute) {
            if (attribute.MarkedForRemove() == true) {
                attribute.MarkedForRemove(false);
                return false;
            }
            attribute.MarkedForRemove(true);
            return true;
        };

        self.setSelectedAttribute = function (attribute) {
            if (attribute.Selected()) {
                attribute.Selected(false);
            } else {
                attribute.Selected(true);
                self.SelectedAttribute = attribute;
            }
            var selectedFound = false;
            var counter = 0;
            self.IsMultiSelected(false);
            $.each(self.SelectedAttributeNames(), function (index, attr) {
                if (attr.Selected() == true) {
                    self.SelectedAttribute = attr;
                    selectedFound = true;
                    counter++;
                    self.IsMultiSelected(true);
                }
            });
            if (counter > 1) {
                self.SelectedAttribute = undefined;
                self.IsSelected(false);
            } else {
                self.IsSelected(selectedFound);
            }

        };

        self.moveToSelected = function (attribute) {
            self.SelectedAttributeNames.push(attribute);
            self.AttributeNames.remove(attribute);
        };

        self.moveToAvailable = function (attribute) {
            self.AttributeNames.push(attribute);
            self.AttributeNames.sort(function (left, right) {
                return left.AttributeNameDisplay == right.AttributeNameDisplay ? 0 : (left.AttributeNameDisplay < right.AttributeNameDisplay ? -1 : 1);
            });
            self.SelectedAttributeNames.remove(attribute);
            self.SelectedAttribute = undefined;
            self.IsSelected(false);
        };

        self.saveSelectedAttributes = function () {
            if (self.SelectedAttributeNames().length == 0) {
                $('#messages ul').html('');
                $('#messages ul').append('<li>' + athoc.iws.GeneralSettings.resources.GeneralSettings_ErrMsg_Attribute + '</li>');
                return;
            }
            var selected = ko.toJSON(self.SelectedAttributeNames, ['AttributeName', 'Type']);
            var data = ko.toJSON({ attributes: { Attributes: self.SelectedAttributeNames() } });
            updateSelectedColumns(data, function (data) {
                if (data.Success == true) {
                    if ('@ViewBag.ViewType' == 'UserManagerV2')
                        alert('@IWSResources.VirtualSystemSettings_UserManagerLayoutSave');
                    else if ('@ViewBag.ViewType' == 'UserReport')
                        alert('@IWSResources.VirtualSystemSettings_ReportColumnsLayoutSave');
                    window.returnValue = true;
                    window.close();
                } else {
                    //show error messages
                    $('#messages ul').html('');
                    $.each(data.Messages, function (index, message) {
                        $('#messages ul').append('<li>' + message.Value + '</li>');
                    });
                }
            });
        };

        self.cancel = function () {
            do_cancel();
        };
    };

    // Enable/disable controls in all browsers
    ko.bindingHandlers['CustomEnable'] = (function () {
        return {
            init: function (element, valueAccessor) {
                var $element = $(element);
                var value = ko.utils.unwrapObservable(valueAccessor());
                if (value)
                    $element.removeAttr("disabled");
                else
                    $element.attr("disabled", true);

            },
            update: function (element, valueAccessor) {
                var value = ko.utils.unwrapObservable(valueAccessor());
                var $element = $(element);
                if (value)
                    $element.removeAttr("disabled");
                else
                    $element.attr("disabled", true);

            }
        };
    }());

    athoc.iws.GeneralSettings = function () {
        var errorTitleStrings = new Array();
        return {
            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},
            pageId: "",
            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //viewmodel to hold General settings record
            viewModel: {
                generalSettingModel: ko.observable(),
            },
            //TimeZone to hold timezones record
            timeZone: function (id, name) {
                this.id = id;
                this.displayName = name;
            },
            //Editmodel to hold General settings record, dateformats, timeformats and timezones
            editModel: {
                generalSettingModel: ko.observable(),
                dateFormats: ko.observableArray(['DD/MM/YYYY', 'MM/DD/YYYY', 'DD/MM/YY', 'MM/DD/YY', 'DD-MM-YYYY', 'MM-DD-YYYY', 'DD-MM-YY', 'MM-DD-YY']),
                timeFormats: ko.observableArray([{ value: "HH:MM:SS TT", text: "HH:MM:SS AM/PM" }, { value: "HH:MM TT", text: "HH:MM AM/PM" }, { value: "HH:MM:SS", text: "HH:MM:SS" }, { value: "HH:MM", text: "HH:MM" }]),
                timeZones: ko.observableArray(),
                langSupports: ko.observableArray(),
                enabledLanguages: {},
                speechLanguages: ko.observableArray(),
                selectedLanguages: ko.observableArray(),
                isChanged: ko.observable(false),
                ProviderLocale: ko.observable(""),
                isAffiliate: false, 
                prevCountcode: ko.observable(),
                setOptionDisable: function (option, item) {

                    ko.applyBindingsToNode(option, {
                        disable: item.disable
                    }, item);
                },
                EnterpriseUserUniqueCheckbox: ko.observable(false),
                showEnterPriseUniqunessUsers: function () {
                    athoc.iws.GeneralSettings.checkEnterPriseRunCheck();
                },
                EnterpriseUniuenessDependencySpec: {},
               
            },
            checkEnterPriseRunCheck: function () {


                var dataSource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: athoc.iws.GeneralSettings.urls.GetUniquenessUsersListUrl,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST",
                            async: false,
                        },

                        parameterMap: function (data) { 
                            return kendo.stringify(data);
                        },
                    },

                    requestStart: function (e) {
                        $.AjaxLoader.setup({ useBlock: true, elementToBlock: $('#dupUsersList .k-grid-content'), imageURL: athoc.iws.GeneralSettings.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000 });
                        $.AjaxLoader.showLoader();
                    },
                    requestEnd: function (e) { 
                        $.AjaxLoader.hideLoader();
                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                        model: {
                            fields: {
                                DisplayName: { type: "string" },
                                UserName: { type: "string" }, 
                                MAPPING_ID: { type: "string" },
                                PROVIDER_DISPLAYNAME: { type: "string" }
                            }
                        },
                    },
                    serverPaging: true,
                    serverSorting: true,
                    //serverFiltering: true,
                    sort: { field: "UserName", dir: "asc" },
                    pageSize: 50,
                    error: function (e) {
                        athoc.iws.GeneralSettings.handleError(e);
                    }
                });

                $("#dupUsersList").kendoGrid({
                    excel: {
                        fileName: "Duplicate Users List.xlsx",
                        allPages: true,
                        filterable: false,
                        proxyURL: athoc.iws.GeneralSettings.urls.ExportDuplicateUsersUrl,
                        forceProxy: true,
                    },
                    dataSource: dataSource,
                    autoBind: true,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.GeneralSettings.gridresources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.GeneralSettings.gridresources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.GeneralSettings.gridresources.IUT_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.GeneralSettings.gridresources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.GeneralSettings.gridresources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.GeneralSettings.gridresources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.GeneralSettings.gridresources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    excelExport: function (e) {
                        var sheet = e.workbook.sheets[0];
                        for (var i = 0; i < sheet.columns.length; i++) {
                            sheet.columns[i].autoWidth = true;
                        }
                    },

                    serverPaging: true,
                    height: 250,
                    sort: { field: "UserName", dir: "asc" },
                    columns:
                                       [
                                            {
                                                field: "DisplayName", 
                                                width: "25%",
                                                headerAttributes: {
                                                    tabindex: "1"
                                                },
                                                headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.GeneralSettings.resources.GeneralSettings_User_List_DisplayName + '">' + athoc.iws.GeneralSettings.resources.GeneralSettings_User_List_DisplayName + '</span>',
                                                template: '<span class="cellTooltip" title="#=DisplayName#">#=DisplayName#</span>'
                                            },
                                            {
                                                field: "UserName",
                                                title: "User Name",
                                                width: "25%",
                                                headerAttributes: {
                                                    tabindex: "2"
                                                },
                                                headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.GeneralSettings.resources.GeneralSettings_User_List_UserName + '">' + athoc.iws.GeneralSettings.resources.GeneralSettings_User_List_UserName + '</span>',
                                                template: '<span class="cellTooltip" title="#=UserName#">#=UserName#</span>'
                                            },
                                           {
                                               field: "MAPPING_ID",
                                               title: "Mapping Id",
                                               width: "25%",
                                               headerAttributes: {
                                                   tabindex: "3"
                                               },
                                               headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.GeneralSettings.resources.GeneralSettings_User_List_MappingId + '">' + athoc.iws.GeneralSettings.resources.GeneralSettings_User_List_MappingId + '</span>',
                                               template: '<span class="cellTooltip" title="#=MAPPING_ID#">#=MAPPING_ID#</span>'
                                           },
                                            {
                                                field: "PROVIDER_DISPLAYNAME",
                                                title: "Organization",
                                                width: "25%",
                                                headerAttributes: {
                                                    tabindex: "3"
                                                },
                                                headerTemplate: '<span class="cellTooltip" title="' + athoc.iws.GeneralSettings.resources.GeneralSettings_User_List_Organization + '">' + athoc.iws.GeneralSettings.resources.GeneralSettings_User_List_Organization + '</span>',
                                                template: '<span class="cellTooltip" title="#=PROVIDER_DISPLAYNAME#">#=PROVIDER_DISPLAYNAME#</span>'
                                            },

                                       ]

                }); 

                if (dataSource._data.length == 0) {
                    $("#divCheckPass").modal("show");
                    athoc.iws.GeneralSettings.editModel.EnterpriseUserUniqueCheckbox(true);
                } else {
                    if ($(window).height() > 1024)
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#dupUsers'), 600, 770, 40, 170);
                    else
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#dupUsers'), 652, 525, 15, 145);
                    $("#dupUsers").modal("show");
                } 

            },
            // Hold array of errors
            errors: null,

            //init method for general settings, will be triggered before document load
            init: function () {
                athoc.iws.GeneralSettings.initBreadcrumb();
            },
            //load method, will be triggered on document load
            load: function () {
                //To fill the Message popup title strings from resource 
                errorTitleStrings.push(athoc.iws.GeneralSettings.resources.IWS_CommonErrMsg_Title_Information);
                errorTitleStrings.push(athoc.iws.GeneralSettings.resources.IWS_CommonErrMsg_Title_Warning);
                errorTitleStrings.push(athoc.iws.GeneralSettings.resources.IWS_CommonErrMsg_Title_Error);
                errorTitleStrings.push(athoc.iws.GeneralSettings.resources.IWS_CommonErrMsg_Title_Success);
                errorTitleStrings.push(athoc.iws.GeneralSettings.resources.IWS_CommonErrMsg_Title_Completed);


                // To display breadcrumb
                athoc.iws.GeneralSettings.bindBreadcrumb();

                // To get general settings
                athoc.iws.GeneralSettings.editGeneralSettings();

                $("#btnExcelExport").kendoButton({
                    click: function () {
                        $("#dupUsersList").getKendoGrid().saveAsExcel();
                    }
                });


                $("#btn_edit").click(function () {
                    athoc.iws.GeneralSettings.editGeneralSettings();
                });

                $("#btn_cancel").click(function () {
                    var isModified = athoc.iws.GeneralSettings.editModel.isChanged();
                    if (isModified == true) {
                        var confirmLeave = confirm(athoc.iws.GeneralSettings.resources.Unsaved_Data_Text);
                        if (confirmLeave == true) {
                            athoc.iws.GeneralSettings.editModel.isChanged(false);
                            window.location.href = athoc.iws.GeneralSettings.urls.SettingsUrl;
                        }
                    }
                    else {
                        window.location.href = athoc.iws.GeneralSettings.urls.SettingsUrl;
                    }
                });

                $("#btn_save").click(function () {
                    athoc.iws.GeneralSettings.saveGeneralSettings();
                });
                $('#btnOperatorSave').click(function () {
                    if ($('#pageLayoutXml').val().trim() == "") {
                        $('#messages ul').append('<li>' + athoc.iws.GeneralSettings.resources.GeneralSettings_ErrMsg_XML + '</li>');
                        return;
                    }
                    athoc.iws.GeneralSettings.updateXml($('#pageLayoutXml').val(), function (data) {
                        if (data.Success == true) {
                            alert(athoc.iws.GeneralSettings.resources.GeneralSettings_LayoutXmlMsg);
                            $("#pageDiv").modal("hide");
                        }
                        else {
                            //show error messages
                            $('#messages ul').html('');
                            $.each(data.Messages, function (index, message) {
                                $('#messages ul').append('<li style="word-wrap:break-word;">' + message.Value + '</li>');
                            });
                        }
                    });
                });

                window.onbeforeunload = function (event) {
                    var isModified = athoc.iws.GeneralSettings.editModel.isChanged();
                    if (isModified) {
                        return athoc.iws.GeneralSettings.resources.Unsaved_Data_Text;
                    } else {
                        $(window).scrollTop(0);
                    }
                };

            },
            //to update xml
            updateXml: function (xml, callback) {
                var updateUrl;
                switch (athoc.iws.GeneralSettings.pageId) {
                    case "NEWEUM":
                        updateUrl = athoc.iws.GeneralSettings.urls.UpdatePageLayoutUrl;
                        break;
                    case "OPERATORDETAILS":
                        updateUrl = athoc.iws.GeneralSettings.urls.UpdateOperatorLayoutUrl;
                        break;
                    default:
                        updateUrl = "";
                        break;
                }
                if (updateUrl) {
                    var myAjaxOptions =
                    {
                        type: "POST",
                        url: updateUrl,
                        data: xml,
                        contentType: 'text/xml',
                        dataType: "json",
                        cache: false,
                        success: function (data) {
                            if (callback && typeof (callback) == 'function') {
                                callback.call(this, data);
                            }
                        }
                    };

                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                    $.ajax(ajaxOptions);
                }
            },
            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),
            initBreadcrumb: function () {
                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.GeneralSettings.breadcrumbModel;
                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.GeneralSettings.resources.Breadcrumb_Settings, '', function () {
                    var isModified = athoc.iws.GeneralSettings.editModel.isChanged();
                    if (isModified == true) {
                        var confirmLeave = confirm(athoc.iws.GeneralSettings.resources.Unsaved_Data_Text);
                        if (confirmLeave == true) {
                            athoc.iws.GeneralSettings.editModel.isChanged(false);
                            window.location.href = athoc.iws.GeneralSettings.urls.SettingsUrl;
                        }
                    }
                    else {
                        window.location.href = athoc.iws.GeneralSettings.urls.SettingsUrl;
                    }
                });

                //Page breadcrumb
                var editPageBreadcrumb = new PageBreadcrumb('editgeneralsettings', athoc.iws.GeneralSettings.resources.GeneralSettings_BreadCurmbGeneralSettings, [settingLink], '');
                breadcrumbsModel.addPage(editPageBreadcrumb);
            },

            //breadcrumb
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.GeneralSettings.breadcrumbModel;
                breadcrumbsModel.SelectedPage('editgeneralsettings');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');

                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
                $(".title").addClass("titlewidth");

            },
            //pattern Validation
            validEmail: function (param1, param2, param3) {
                if ((param1 == "" || param1 == null) && (param2[1] == "Email" || param2[1] == "orgcode"))
                    return true;
                if (param2[1] == "Email") {
                    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
                    return re.test(param1);
                }
                if (param2[1] == "orgcode") {
                    return (!$.isNumeric(param1));
                }
                return true;
            },
            getValidation: function () {
                //remove old validation
                $(".warning").each(function () {
                    $(this).parent().remove();
                });

                var validationMapping = {
                    DisplayName: {

                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_ErrMsg_MaxDisplayNameLength,
                                    params: 62
                                }
                            });
                        }
                    },

                    OrgCode: {

                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_ErrMsg_MaxOrgCode,
                                    params: 300
                                },
                                pattern: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_ErrMsg_OrgCodeSpecialChars,
                                    params: "^[^`!$%()&=@*#_+{}^,;:?\"<>\\\\|]+$"
                                },
                                validation: [
                                {
                                    validator: athoc.iws.GeneralSettings.firstAndLastCharValidation,
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_ErrMsg_firstAndLastCharValidation,
                                    params: [this.value, "orgcode", 2]
                                },
                                {
                                    validator: athoc.iws.GeneralSettings.validEmail,
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_ErrMsg_OrgCodeNum,
                                    params: [this.value, "orgcode", 2]
                                },
                                ]
                            });
                        }
                    },
                    SupportEmail: {

                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_ErrMsg_MaxEmailLength,
                                    params: 200
                                },
                                validation: {
                                    validator: athoc.iws.GeneralSettings.validEmail,
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_ErrMsg_ValidEmail,
                                    params: [this.value, "Email", 2]
                                }
                            });
                        }
                    },
                    ProviderName: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_Name_Required,
                                    params: true
                                },
                                minLength: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_Name_MaxLength,
                                    params: 3
                                },
                                maxLength: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_Name_MaxLength,
                                    params: 62
                                },
                                pattern: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_Name_Pattern,
                                    params: "^[^`^!^$^^^%^(^)^=^{^}^,^;^\^:^?^\"^<^>^|]+$"
                                }
                            });
                        }
                    },
                    InformationBanner: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_InformationBanner_MaxLength,
                                    params: 120
                                },
                            });
                        }
                    },
                    WebImageText: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_Description_MaxLength,
                                    params: 100
                                },
                            });
                        }
                    },
                    WelcomeMesssage: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_Welcome_MaxLength,
                                    params: 500
                                },
                            });
                        }
                    },
                    CallId: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                minLength: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_CallId_MaxLength,
                                    params: 4
                                },
                                maxLength: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_CallId_MaxLength,
                                    params: 13
                                },
                                pattern: {
                                    message: athoc.iws.GeneralSettings.resources.GeneralSettings_CallId_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },

                            });
                        }
                    },                    
                   

                };

                return validationMapping;
            },
            firstAndLastCharValidation: function (str) {
                str = str.trim();
                //if empty - no validation
                if (str == "")
                    return true;
                //if not empty - validate
                if (str.indexOf('.') == 0 || str.indexOf('-') == 0)
                    return false;
                else
                    if (str.lastIndexOf('.') == str.length - 1 || str.lastIndexOf('-') == str.length - 1)
                        return false;
                return true;
            },
            // Bind select picker to controls
            initiateSelectPicker: function () {

                $("#ddlTimeZone").selectpicker();
                $("#ddlTimeFormat").selectpicker();
                $("#ddlDateformat").selectpicker();
                $("#ddlLocale").selectpicker();
                $("#ddlSpeechLanguages").selectpicker();

                $('#ddlSpeechLanguages').on('change', function () {
                    $('#ddlSpeechLanguages option:selected').each(function () {
                        $(this)[0].disabled = true;
                        $(this)[0].isDisabled = true;
                    });
                    $('#ddlSpeechLanguages').selectpicker('render');
                    athoc.iws.GeneralSettings.editModel.isChanged(true);
                });
            },




            // To display collapse panel in buckets
            collapsePanel: function () {
                $(this).parent().find('.expand-arrow-open').toggle();
                $('.bucket-toggle h2').click(function () {
                    $(this).parent().find('.row').slideToggle(500);
                    $(this).parent().find('.expand-arrow-open').toggle();
                    $(this).parent().find('.expand-arrow-closed').toggle();
                });
            },
            // To edit general settings  when edit button is clicked
            editGeneralSettings: function () {

                navigateToPage('editgeneralsettings', function () { });
                athoc.iws.GeneralSettings.breadcrumbModel.SelectedPage('editgeneralsettings');
                $.titleCrumb("pageBreadcrumbs");
                $('#saveMessagePanel').messagesPanel('reset');
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.GeneralSettings.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();

                var dlSuccess = function (data) {

                    if (data.Success) {
                        $(document).scrollTop(0);
                        $("#gProviderNameTxt").focus();
                        //Binding
                        $("#editGeneralSettings").find(".bootstrap-select").remove();
                        ko.cleanNode($("#editGeneralSettings").get(0));
                        athoc.iws.GeneralSettings.editModel.generalSettingModel = ko.mapping.fromJS(data.Data, athoc.iws.GeneralSettings.getValidation());
                        athoc.iws.GeneralSettings.editModel.langSupports(data.langSupports);
                        athoc.iws.GeneralSettings.editModel.enabledLanguages = data.Data.EnabledLanguages;
                        athoc.iws.GeneralSettings.editModel.ProviderLocale(data.ProviderLocale);
                        athoc.iws.GeneralSettings.editModel.prevCountcode(data.Data.CountryCode);
                        if (athoc.iws.GeneralSettings.editModel.speechLanguages().length == 0) {
                            athoc.iws.GeneralSettings.editModel.speechLanguages = ko.observableArray([]);
                            _.each(athoc.iws.GeneralSettings.editModel.enabledLanguages, function (item) {
                                athoc.iws.GeneralSettings.editModel.speechLanguages.push({ Name: item.Name, Code: item.Code, disable: item.IsEnabled });
                            });
                            athoc.iws.GeneralSettings.editModel.selectedLanguages = ko.observableArray(ko.toJS(athoc.iws.GeneralSettings.getSelectedSpeechLanguages()).map(function (item) { return item.Code; }));
                        }
                        athoc.iws.GeneralSettings.editModel.timeZones = data.TimeZones;

                        if (athoc.iws.GeneralSettings.editModel.generalSettingModel.OrgCode() != '') {
                            athoc.iws.GeneralSettings.editModel.generalSettingModel.LoginUrl(athoc.iws.GeneralSettings.editModel.generalSettingModel.SelfServiceUrl() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.OrgCode());
                            athoc.iws.GeneralSettings.editModel.generalSettingModel.RegistrationUrl(athoc.iws.GeneralSettings.editModel.generalSettingModel.SelfServiceUrl() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.OrgCode() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.RegisterName());
                        }

                        else {
                            athoc.iws.GeneralSettings.editModel.generalSettingModel.LoginUrl(athoc.iws.GeneralSettings.editModel.generalSettingModel.SelfServiceUrl() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.ProviderId());
                            athoc.iws.GeneralSettings.editModel.generalSettingModel.RegistrationUrl(athoc.iws.GeneralSettings.editModel.generalSettingModel.SelfServiceUrl() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.ProviderId() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.RegisterName());
                        }
                        ko.applyBindings(athoc.iws.GeneralSettings.editModel, $("#editGeneralSettings").get(0));

                        var result = ko.validation.group(athoc.iws.GeneralSettings.editModel.generalSettingModel, { deep: true });
                        if (result().length > 0) {
                            result.showAllMessages(true);
                            $('#saveMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.GeneralSettings.resources.GeneralSettings_ErrorSave }] });
                        }

                        athoc.iws.GeneralSettings.editSubscribe();
                        athoc.iws.GeneralSettings.collapsePanel();
                        athoc.iws.GeneralSettings.initiateSelectPicker();
                        SetPhoneNumber();
                        $('#txtOutgoingAreaCode').intlTelInput("setCountry", athoc.iws.GeneralSettings.editModel.generalSettingModel.IsoCountryCode());

                        $('[data-id=ddlLocale]').attr("disabled", "disabled");
                        //$("#ddlSpeechLanguages").refresh();
                        $("#ddlSpeechLanguages").trigger("chosen:updated");
                        if (data.Data.WebImageId != null && data.Data.WebImageId != "") {
                            $("#imgEditWebLogo").attr("src", athoc.iws.GeneralSettings.urls.EditWebLogoPath + data.Data.WebImageId);
                            $("#imgEditWebLogo").show();
                        }
                        else {
                            $("#imgEditWebLogo").hide();
                            $("#imgEditWebLogo").attr("src", athoc.iws.GeneralSettings.urls.DefaultLogoImage);
                        }

                        if (data.Data.AlertImageId != null && data.Data.AlertImageId != "") {
                            $("#imgEditAlertLogo").attr("src", athoc.iws.GeneralSettings.urls.EditWebLogoPath + data.Data.AlertImageId);
                            $("#imgEditAlertLogo").show();
                        }
                        else {
                            $("#imgEditAlertLogo").hide();
                            $("#imgEditAlertLogo").attr("src", athoc.iws.GeneralSettings.urls.DefaultLogoImage);
                        }

                        var inputElm = $("#gOrgCodeTxt");
                        // Disable save button when cursor is in orgcode textbox
                        inputElm.keyup(function (e) {
                            $("#btn_save").attr("disabled", true);
                        });
                        // Enable save button when cursor is out of orgcode textbox
                        inputElm.blur(function (e) {
                            $("#btn_save").removeAttr("disabled");
                        });

                        athoc.iws.GeneralSettings.editModel.EnterpriseUserUniqueCheckbox(athoc.iws.GeneralSettings.editModel.generalSettingModel.IsUserUniqueAcrossEnterprise());
                        if (athoc.iws.GeneralSettings.editModel.generalSettingModel.IsEnterpriseWithSubs())
                            $("#divEnterpriseUserUnique").removeClass("hide");
                        else
                            $("#divEnterpriseUserUnique").addClass("hide");

                    }

                    if (!data.Success && data.HasErrors) {
                        $('#saveMessagePanel').messagesPanel({ messages: data.Messages }, undefined, undefined, undefined, errorTitleStrings);
                        athoc.iws.GeneralSettings.showMessagePanel();
                    }

                    $.AjaxLoader.hideLoader();

                    generalData = null;
                    var orgLogoImageFilename, desktopAppLogoFilename;
                    $("#fuWebLogo").fileupload({
                        dataType: 'json',
                        autoUpload: false,
                        done: function (e, data) {
                            $.AjaxLoader.hideLoader();
                            isWebLogoExists = false;

                            if (data.result.Success != null && data.result.Success) {
                                athoc.iws.GeneralSettings.editModel.generalSettingModel.WebImageData(data.result.data);
                                athoc.iws.GeneralSettings.editModel.generalSettingModel.WebImageType(data.result.type);
                                athoc.iws.GeneralSettings.editModel.generalSettingModel.WebImageExtension(data.result.extension);
                                $("#imgEditWebLogo").attr("src", "data:image/gif;base64," + data.result.data);
                                athoc.iws.GeneralSettings.editModel.isChanged(true);
                                $("#imgEditWebLogo").show();
                            } else {
                                $("#txtWebLogo").val(orgLogoImageFilename);
                                var reqError = new Array();
                                reqError.push({ Type: '4', Value: athoc.iws.GeneralSettings.resources.MimeType_File_Exception });
                                $('#saveMessagePanel').messagesPanel({ messages: reqError }, undefined, undefined, undefined, errorTitleStrings);
                                athoc.iws.GeneralSettings.showMessagePanel();
                            }

                        },
                        add: function (e, data) {
                            generalData = data;
                            $('#saveMessagePanel').html('');
                            athoc.iws.GeneralSettings.editModel.isChanged(true);
                            orgLogoImageFilename=$("#txtWebLogo").val();
                            $.each(data.files, function (index, file) {
                                var ext = file.name.split(".")[file.name.split(".").length - 1].toLowerCase();
                                $("#txtWebLogo").val("");
                                if (ext != "gif" && ext != "jpg" && ext != "png") {

                                    var reqError = new Array();
                                    reqError.push({ Type: '4', Value: athoc.iws.GeneralSettings.resources.GeneralSettings_Image_Format });
                                    $('#saveMessagePanel').messagesPanel({ messages: reqError }, undefined, undefined, undefined, errorTitleStrings);
                                    athoc.iws.GeneralSettings.showMessagePanel();

                                } else {
                                    $("#txtWebLogo").val(file.name);
                                    $('#fuWebLogo').fileupload({
                                        url: athoc.iws.GeneralSettings.urls.WebLogoFileUploadPath
                                    });
                                    generalData.submit();
                                }
                            });
                        },
                        change: function (e, data) {
                        },
                        error: function (e) {
                            isWebLogoExists = false;
                            $.AjaxLoader.hideLoader();
                            athoc.iws.GeneralSettings.handleError(e);
                        }
                    });


                    $("#fuAlertLogo").fileupload({
                        url: athoc.iws.GeneralSettings.urls.WebLogoFileUploadPath,
                        dataType: 'json',
                        autoUpload: false,
                        done: function (e, data) {
                            $.AjaxLoader.hideLoader();
                            isWebLogoExists = false;

                            if (data.result.Success) {
                                athoc.iws.GeneralSettings.editModel.generalSettingModel.AlertImageData(data.result.data);
                                athoc.iws.GeneralSettings.editModel.generalSettingModel.AlertImageType(data.result.type);
                                athoc.iws.GeneralSettings.editModel.generalSettingModel.AlertImageExtension(data.result.extension);
                                $("#imgEditAlertLogo").attr("src", "data:image/gif;base64," + data.result.data);
                                athoc.iws.GeneralSettings.editModel.isChanged(true);
                                $("#imgEditAlertLogo").show();
                            } else {
                                $("#txtAlertLogo").val(desktopAppLogoFilename);
                                var reqError = new Array();
                                reqError.push({ Type: '4', Value: athoc.iws.GeneralSettings.resources.MimeType_File_Exception });
                                $('#saveMessagePanel').messagesPanel({ messages: reqError }, undefined, undefined, undefined, errorTitleStrings);
                                athoc.iws.GeneralSettings.showMessagePanel();
                            }

                        },
                        add: function (e, data) {
                            generalData = data;
                            $('#saveMessagePanel').html('');
                            athoc.iws.GeneralSettings.editModel.isChanged(true);
                            desktopAppLogoFilename = $("#txtAlertLogo").val();
                            $.each(data.files, function (index, file) {
                                var ext = file.name.split(".")[file.name.split(".").length - 1].toLowerCase();
                                $("#txtAlertLogo").val("");
                                if (ext != "gif" && ext != "jpg" && ext != "png") {

                                    var reqError = new Array();
                                    reqError.push({ Type: '4', Value: athoc.iws.GeneralSettings.resources.GeneralSettings_Image_Format });
                                    $('#saveMessagePanel').messagesPanel({ messages: reqError }, undefined, undefined, undefined, errorTitleStrings);
                                    athoc.iws.GeneralSettings.showMessagePanel();

                                } else {
                                    $("#txtAlertLogo").val(file.name);

                                    generalData.submit();

                                }
                            });
                        },
                        change: function (e, data) {
                        },
                        error: function (e) {
                            isWebLogoExists = false;
                            $.AjaxLoader.hideLoader();
                            athoc.iws.GeneralSettings.handleError(e);
                        }
                    });

                };

                var dlAjaxOption =
                    {
                        type: "POST",
                        url: athoc.iws.GeneralSettings.urls.GetgeneralsettingsUrl,
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.GeneralSettings.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility(null, dlSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);


            },
            // To save general settings in the database
            saveGeneralSettings: function () {
                $('#saveMessagePanel').html('');

                var result = ko.validation.group(athoc.iws.GeneralSettings.editModel.generalSettingModel, { deep: true });
                if (result().length > 0) {
                    $('#saveMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.GeneralSettings.resources.GeneralSettings_ErrorSave }] });
                    return false;
                }
                   
                    if ($.trim(athoc.iws.GeneralSettings.editModel.generalSettingModel.SSSecurityDisclaimerText()).length > 4000) {
                        $("#errSSDisclaimer").addClass("warning");
                        $("#errSSDisclaimer").html(athoc.iws.GeneralSettings.resources.GeneralSettings_SSDisclaimer_MaxLength);
                        $('#saveMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.GeneralSettings.resources.GeneralSettings_ErrorSave }] });
                        return false;                 
                    }
                    athoc.iws.GeneralSettings.editModel.generalSettingModel.SSSecurityDisclaimerText($.trim(athoc.iws.GeneralSettings.editModel.generalSettingModel.SSSecurityDisclaimerText()));
                
                $("#errSSDisclaimer").html('');
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.GeneralSettings.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();

                //set Enable Languages

                athoc.iws.GeneralSettings.editModel.generalSettingModel.EnabledLanguages(athoc.iws.GeneralSettings.setSelectedSpeechLanguages());
                athoc.iws.GeneralSettings.editModel.generalSettingModel.IsoCountryCode($('#txtOutgoingAreaCode').intlTelInput("getSelectedCountryData").iso2);
                athoc.iws.GeneralSettings.editModel.generalSettingModel.CountryCode($('#txtOutgoingAreaCode').val());
                var jsonData = ko.toJSON(athoc.iws.GeneralSettings.editModel.generalSettingModel);
                var dlAjaxOption =
                    {
                        url: athoc.iws.GeneralSettings.urls.SaveGeneralSettingsUrl,
                        contentType: false,
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            if (data.Success) {
                                // To get general settings
                                // athoc.iws.GeneralSettings.editGeneralSettings();
                                athoc.iws.GeneralSettings.editModel.prevCountcode(athoc.iws.GeneralSettings.editModel.generalSettingModel.CountryCode());
                                if (athoc.iws.GeneralSettings.editModel.generalSettingModel.OrgCode() != '') {
                                    athoc.iws.GeneralSettings.editModel.generalSettingModel.LoginUrl(athoc.iws.GeneralSettings.editModel.generalSettingModel.SelfServiceUrl() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.OrgCode());
                                    athoc.iws.GeneralSettings.editModel.generalSettingModel.RegistrationUrl(athoc.iws.GeneralSettings.editModel.generalSettingModel.SelfServiceUrl() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.OrgCode() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.RegisterName());
                                } else {
                                    athoc.iws.GeneralSettings.editModel.generalSettingModel.LoginUrl(athoc.iws.GeneralSettings.editModel.generalSettingModel.SelfServiceUrl() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.ProviderId());
                                    athoc.iws.GeneralSettings.editModel.generalSettingModel.RegistrationUrl(athoc.iws.GeneralSettings.editModel.generalSettingModel.SelfServiceUrl() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.ProviderId() + "/" + athoc.iws.GeneralSettings.editModel.generalSettingModel.RegisterName());
                                }
                                athoc.iws.GeneralSettings.editModel.EnterpriseUserUniqueCheckbox(athoc.iws.GeneralSettings.editModel.generalSettingModel.IsUserUniqueAcrossEnterprise());
                                $('#ddlSpeechLanguages').selectpicker('refresh');
                                athoc.iws.GeneralSettings.editModel.isChanged(false);
                                $('#saveMessagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.GeneralSettings.resources.GeneralSettings_SaveSuccess }] });
                                $('html,body').scrollTop(0);
                            } else {
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages }, undefined, undefined, undefined, errorTitleStrings);
                                athoc.iws.GeneralSettings.showMessagePanel();
                            }
                            isWebLogoExists = false;
                            $.AjaxLoader.hideLoader();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            isWebLogoExists = false;
                            athoc.iws.GeneralSettings.handleError(e);
                        }

                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);


                return true;
            },
            isLanguageChanged: function (obj) {
                athoc.iws.GeneralSettings.editModel.isChanged(true); $('#saveMessagePanel').html('');
                return true;
            },
            getSelectedSpeechLanguages: function (data) {
                var selectedLanguages = [];
                _.each(athoc.iws.GeneralSettings.editModel.enabledLanguages, function (item) {
                    if (item.IsEnabled)
                        selectedLanguages.push({ Name: item.Name, Code: item.Code });
                });
                return selectedLanguages;
            },

            setSelectedSpeechLanguages: function () {

                var iLanguages = [];
                _.each(athoc.iws.GeneralSettings.editModel.enabledLanguages, function (item) {
                    var flag = false;
                    _.each(athoc.iws.GeneralSettings.editModel.selectedLanguages(), function (item1) {
                        if (item.Code == item1)
                            flag = true;
                    });

                    iLanguages.push({
                        Name: item.Name,
                        Code: item.Code,
                        IsEnabled: flag
                    });
                });
                return iLanguages;
            },
            // Bind subscribe to all properties to notify change
            editSubscribe: function () {

                athoc.iws.GeneralSettings.editModel.generalSettingModel.ProviderName.subscribe(function (value) {
                    athoc.iws.GeneralSettings.editModel.generalSettingModel.ProviderName($.trim(athoc.iws.GeneralSettings.editModel.generalSettingModel.ProviderName()));
                    athoc.iws.GeneralSettings.editModel.isChanged(true);
                    $('#saveMessagePanel').html('');
                });
                athoc.iws.GeneralSettings.editModel.generalSettingModel.SSSecurityDisclaimerText.subscribe(function (value) {
                    $("#errSSDisclaimer").html('');
                    athoc.iws.GeneralSettings.editModel.isChanged(true);
                    $('#saveMessagePanel').html('');
                });

                athoc.iws.GeneralSettings.editModel.generalSettingModel.WelcomeMesssage.subscribe(function (value) { athoc.iws.GeneralSettings.editModel.isChanged(true); $('#saveMessagePanel').html(''); });
                athoc.iws.GeneralSettings.editModel.generalSettingModel.InformationBanner.subscribe(function (value) {
                    athoc.iws.GeneralSettings.editModel.generalSettingModel.InformationBanner($.trim(athoc.iws.GeneralSettings.editModel.generalSettingModel.InformationBanner()));
                    athoc.iws.GeneralSettings.editModel.isChanged(true);
                    $('#saveMessagePanel').html('');
                });
                athoc.iws.GeneralSettings.editModel.generalSettingModel.WebImageText.subscribe(function (value) {
                    athoc.iws.GeneralSettings.editModel.generalSettingModel.WebImageText($.trim(athoc.iws.GeneralSettings.editModel.generalSettingModel.WebImageText()));
                    athoc.iws.GeneralSettings.editModel.isChanged(true);
                    $('#saveMessagePanel').html('');
                });

                athoc.iws.GeneralSettings.editModel.generalSettingModel.CallId.subscribe(function (value) {

                    athoc.iws.GeneralSettings.editModel.generalSettingModel.CallId($.trim(athoc.iws.GeneralSettings.editModel.generalSettingModel.CallId()));
                    athoc.iws.GeneralSettings.editModel.isChanged(true); $('#saveMessagePanel').html('');
                });


                athoc.iws.GeneralSettings.editModel.generalSettingModel.TimeFormat.subscribe(function (value) { athoc.iws.GeneralSettings.editModel.isChanged(true); $('#saveMessagePanel').html(''); });
                athoc.iws.GeneralSettings.editModel.generalSettingModel.TimeZoneRegionId.subscribe(function (value) { athoc.iws.GeneralSettings.editModel.isChanged(true); $('#saveMessagePanel').html(''); });
                athoc.iws.GeneralSettings.editModel.generalSettingModel.OrgCode.subscribe(function(value) {
                    athoc.iws.GeneralSettings.editModel.generalSettingModel.OrgCode($.trim(value));
                    athoc.iws.GeneralSettings.editModel.isChanged(true); $('#saveMessagePanel').html('');
                });
                athoc.iws.GeneralSettings.editModel.generalSettingModel.SupportEmail.subscribe(function (value) { athoc.iws.GeneralSettings.editModel.isChanged(true); $('#saveMessagePanel').html(''); });



            },

            // To move the scrollbar position to top to display error messages
            showMessagePanel: function () {
                if ($('body').scrollTop() > 0) {     //Chrome,Safari
                    $('body').scrollTop(0);
                } else {
                    if ($('html').scrollTop() > 0) { //IE, FF
                        $('html').scrollTop(0);
                    }
                }
            },
            OperatorLayoutCancel: function () {
                $("#pageDiv").modal("hide");
            },
            showLayoutXml: function (pageId) {

                athoc.iws.GeneralSettings.pageId = pageId;
                var dataPost = { PageId: athoc.iws.GeneralSettings.pageId };
                $("#pageDiv").modal("show");
                $('#messages ul').html('');
                var myAjaxOptions =
                    {
                        url: athoc.iws.GeneralSettings.urls.LayoutXmlUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(dataPost),
                        success: function (data) {
                            if (data.Success) {
                                $("#pageLayoutXml").val(data.Data);
                            } else {
                                //write error message
                                $('#messages ul').html('');
                                $('#messages ul').append('<li style="word-wrap:break-word;">' + data.Error + '</li>');
                            }
                        }
                    };
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                $.ajax(ajaxOptions);
                return false;
            },
            showOperatorPageLayout: function () {

                var dlgUrl = athoc.iws.GeneralSettings.urls.OperatorPageLayoutUrl;
                var dlgProps = 'dialogWidth: 585px; dialogHeight: 600px; status: no; scroll: no';

                var params = "";
                var result = showPopup(dlgUrl, params, dlgProps);
                return false;
            },
            showNewPageLayout: function () {

                var dlgUrl = athoc.iws.GeneralSettings.urls.NewPageLayoutUrl;
                var dlgProps = 'dialogWidth: 585px; dialogHeight: 600px; status: no; scroll: no';

                var params = "";
                var result = showPopup(dlgUrl, params, dlgProps);
                return false;
            }
            ,

            customizeUserResultsView: function (viewType) {

                var dlgUrl = athoc.iws.GeneralSettings.urls.ListPageLayoutUrl + '?viewType=' + viewType;
                var dlgProps = 'dialogWidth: 860px; dialogHeight: 600px; status: no; scroll: no';
                var params = "";
                var result = showPopup(dlgUrl, params, dlgProps);
                /*
                athoc.iws.GeneralSettings.pageId = viewType;
                var dataPost = { viewType: athoc.iws.GeneralSettings.pageId };
                $("#listDiv").modal("show");SetPhoneNumber
                $('#messages ul').html('');
                var myAjaxOptions =
                    {
                        url: '/athoc-iws/PageLayout/GetCustomViews?viewType=' + viewType,
                        type: "GET",
                        data: { viewType: '@ViewBag.ViewType' },
                        cache: false,
                        success: function (data) {
                            if (data) {
                                athoc.iws.GeneralSettings.populateListPageLayout(data);
                            } else {
                                //write error message
                                $('#messages ul').html('');
                                $('#messages ul').append('<li style="word-wrap:break-word;">' + data.Error + '</li>');
                            }
                        }
                    };
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                $.ajax(ajaxOptions);
                */
                return false;
            },
            populateListPageLayout: function (data) {
                var koColumnModelView = new ColumnModelView();
                var availableColumns = document.getElementById('availableColumns');
                ko.applyBindings(koColumnModelView, availableColumns);
                //get all columns
                $.each(data.Available, function (index, item) {
                    koColumnModelView.addAttribute(item.DisplayName, item.CustomViewColumnType, item.Name, item.Id);
                });
                $.each(data.Existing, function (index, item) {
                    koColumnModelView.addSelectedAttribute(item.DisplayName, item.CustomViewColumnType, item.Name, item.Id);
                });
                return false;
            },
            showCustomFieldXML: function (hierarchyType) {

                var dlgUrl = athoc.iws.GeneralSettings.urls.CustomFieldXmlUrl + '?xmlType=' + hierarchyType;
                var dlgProps = 'dialogWidth: 585px; dialogHeight: 600px; status: no; scroll: no';

                var params = "";
                var result = showPopup(dlgUrl, params, dlgProps);
                return false;
            },
            // To show erros and hadle timeout error
            handleError: function (e) {

                if ((e.xhr != undefined && e.xhr.responseText.indexOf(AjaxUtility().timeoutPageIndicatorString) != -1) || e.statusText == "InvalidSession") {
                    //IWS-7658: handling additional abort condition for FF
                    if (e.xhr.status != 0 && e.xhr.readyState != 0) {
                        window.location.href = dataservice.getServiceUrl('TimeoutErrorInLegacy');
                    }
                } else if (e.errorThrown != "") {
                    if (athoc.iws.GeneralSettings.errors === null) {
                        athoc.iws.GeneralSettings.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.GeneralSettings.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#saveMessagePanel').messagesPanel({ messages: this.errors }, undefined, undefined, undefined, errorTitleStrings);
                    athoc.iws.GeneralSettings.showMessagePanel();
                }
            },


            onDataBound: function (e) {
                var data = $("#dupUsersList").data("kendoGrid").dataSource.data();
                athoc.iws.GeneralSettings.OnBoundEmptyRow(data);
            },
            OnBoundEmptyRow: function (data) {
                //alert("Hi");
                var colCount = $("#dupUsersList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#dupUsersList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:10px;overflow:auto;">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "No data found", "No data found") +
                            '</td></tr>');

                }
            },            
           
        };
    }();
}
