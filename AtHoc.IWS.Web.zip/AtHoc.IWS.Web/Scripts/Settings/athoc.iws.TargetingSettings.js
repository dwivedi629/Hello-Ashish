﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.TargetingSettings = athoc.iws.TargetingSettings || {};

if (athoc.iws.TargetingSettings) {
    // Enable/disable controls in all browsers
    ko.bindingHandlers['CustomEnable'] = (function () {
        return {
            init: function (element, valueAccessor) {
                var $element = $(element);
                var value = ko.utils.unwrapObservable(valueAccessor());
                if (value)
                    $element.removeAttr("disabled");
                else
                    $element.attr("disabled", true);

            },
            update: function (element, valueAccessor) {
                var value = ko.utils.unwrapObservable(valueAccessor());
                var $element = $(element);
                if (value)
                    $element.removeAttr("disabled");
                else
                    $element.attr("disabled", true);

            }
        };
    }());
    athoc.iws.TargetingSettings = function () {

        return {
         
            Option: function (name, id, eType, tType, providerId, displayOrder, selected) {
                this.AttributeName = ko.observable(name);
                this.AttributeId = ko.observable(id);
                this.EntityType = ko.observable(eType);
                this.TargetingType = ko.observable(tType);
                this.ProviderId = ko.observable(providerId);
                this.DisplayOrder = ko.observable(displayOrder);
                this.IsSelected = ko.observable(selected);
                this.IsDeleted = ko.observable(false);
            },

            Group: function (label, children) {
                this.label = ko.observable(label);
                this.children = ko.observableArray(children);
                this.addOption = function (option) {
                    this.children.push(option);

                };
            },

            // Hold array of errors
            errors: null,

            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            // ViewModel 
            viewModel: {                
                toList: ko.observableArray([]),
                fromList: ko.observableArray([]),
                distrubutionOption: ko.observable(),
                toListSelected: ko.observable([]),
                fromListSelected: ko.observable([]),
                isChanged: ko.observable(false),
                bridgeValue: ko.observable(false),
            },

            // Init method for scenario list, will be triggered before document load
            init: function () {
                athoc.iws.TargetingSettings.initBreadcrumb();
                navigateToPage('viewTargetingSetting', function () { });
            },

            //load method, will be tirggered on document load
            load: function () {
                athoc.iws.TargetingSettings.bindBreadcrumb();

                // Bind all events to the controls
                $('#btn_save').click(function () {
                    athoc.iws.TargetingSettings.SaveListColumns();
                });

                $("#btn_cancel").click(function () {
                    var isModified = athoc.iws.TargetingSettings.viewModel.isChanged();
                    if (isModified == true) {
                        var confirmLeave = confirm(athoc.iws.TargetingSettings.resources.cancelMessage);
                        if (confirmLeave == true) {
                            athoc.iws.TargetingSettings.viewModel.isChanged(false);
                            window.location.href = "/client/setup/settings";
                        }
                    }
                    else {
                        window.location.href = "/client/setup/settings";
                    }
                });

                

                //get all columns
                athoc.iws.TargetingSettings.loadTargetingSettings();

            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),
           
            initBreadcrumb: function () {

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.TargetingSettings.breadcrumbModel;

                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.TargetingSettings.resources.breadCrumbSettings, '', function () {
                    var isModified = athoc.iws.TargetingSettings.viewModel.isChanged();
                    if (isModified == true) {
                        var confirmLeave = confirm(athoc.iws.TargetingSettings.resources.cancelMessage);
                        if (confirmLeave == true) {
                            athoc.iws.TargetingSettings.viewModel.isChanged(false);
                            window.location.href = "/client/setup/settings";
                        }
                    }
                    else {
                        window.location.href = "/client/setup/settings";
                    }                   
                });

                //Page breadcrumb
                var viewPageBreadcrumb = new PageBreadcrumb('viewTargetingSetting', athoc.iws.TargetingSettings.resources.breadCrumbTargetingSettings, [settingLink], '');
                breadcrumbsModel.addPage(viewPageBreadcrumb);

            },

            // Bind breadcrumb model to the breadcrumb control
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.TargetingSettings.breadcrumbModel;
                breadcrumbsModel.SelectedPage('viewTargetingSetting');
                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            // Load all targeting setting and bind viewModel to the view
            loadTargetingSettings: function () {
                ko.cleanNode($("#availableColumns").get(0));
                athoc.iws.TargetingSettings.viewModel.fromList([]);
                athoc.iws.TargetingSettings.viewModel.toList([]);
                var availableColumns = document.getElementById('availableColumns');
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.TargetingSettings.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%' }).showLoader();

                athoc.iws.TargetingSettings.getListColumns(function (data) {

                    if (data.Success) {
                        var organizationGroup = new athoc.iws.TargetingSettings.Group(athoc.iws.TargetingSettings.resources.organizationLabel, []);
                        var attributeGroup = new athoc.iws.TargetingSettings.Group(athoc.iws.TargetingSettings.resources.attributesLabel, []);

                        $.each(data.SelectedAttr, function(index,element) {
                            if (element.IsSelected && element.EntityType != "LIST") {
                                if (!athoc.iws.TargetingSettings.itemInToList(element.AttributeId)) {
                                    athoc.iws.TargetingSettings.viewModel.toList().push(new athoc.iws.TargetingSettings.Option(element.AttributeName, element.AttributeId, element.EntityType, element.TargetingType, element.ProviderId, element.DisplayOrder, element.IsSelected));
                                }
                            }
                        });

                        $.each(data.AvailableAttr, function (index, element) {                          
                            switch (element.EntityType) {
                                case "ATTRIBUTE":
                                    if (!element.IsSelected)
                                    attributeGroup.addOption(new athoc.iws.TargetingSettings.Option(element.AttributeName, element.AttributeId, element.EntityType, element.TargetingType, element.ProviderId, element.DisplayOrder, element.IsSelected));
                                    break;
                                case "HRCHY":
                                    if (!element.IsSelected)
                                    organizationGroup.addOption(new athoc.iws.TargetingSettings.Option(element.AttributeName, element.AttributeId, element.EntityType, element.TargetingType, element.ProviderId, element.DisplayOrder, element.IsSelected));
                                    break;
                                case "LIST":
                                    athoc.iws.TargetingSettings.viewModel.distrubutionOption(new athoc.iws.TargetingSettings.Option(element.AttributeName, element.AttributeId, element.EntityType, element.TargetingType, element.ProviderId, element.DisplayOrder, element.IsSelected));
                                    break;
                            }
                        });

                        athoc.iws.TargetingSettings.viewModel.fromList().length = 0;
                        athoc.iws.TargetingSettings.viewModel.fromList().push(organizationGroup);
                        //athoc.iws.TargetingSettings.sortAttributes(attributeGroup);
                        athoc.iws.TargetingSettings.viewModel.fromList().push(attributeGroup);
                        athoc.iws.TargetingSettings.viewModel.bridgeValue(data.bridgeValue);                        
                        athoc.iws.TargetingSettings.viewModel.toList.valueHasMutated();                      
                        athoc.iws.TargetingSettings.viewModel.fromList.valueHasMutated();
                        ko.applyBindings(athoc.iws.TargetingSettings.viewModel, availableColumns);
                    }

                    if (!data.Success && data.HasErrors) {
                        $('#saveMessagePanel').messagesPanel({ messages: data.Messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    }

                });
            },

            // To move array items from one index to Another
            move: function (fromIndex, toIndex) {
                
                var fromElement = athoc.iws.TargetingSettings.viewModel.toList()[fromIndex];
                var toElement = athoc.iws.TargetingSettings.viewModel.toList()[toIndex];
                fromElement.DisplayOrder(toIndex + 1);
                toElement.DisplayOrder(fromIndex + 1);
                athoc.iws.TargetingSettings.viewModel.toList().splice(fromIndex, 1);
                athoc.iws.TargetingSettings.viewModel.toList().splice(toIndex, 0, fromElement);
                athoc.iws.TargetingSettings.viewModel.toList.valueHasMutated();
                athoc.iws.TargetingSettings.viewModel.isChanged(true);
            },

            //
            sortAttributes: function (attributeGroup) {
                var items = attributeGroup.children();

                for (var i = 0; i < items.length; i++ )
                    for (j = i+ 1; j < items.length; j++ )
                    {
                        if (items[i].AttributeName().toUpperCase() > items[j].AttributeName().toUpperCase())
                        {
                            var to=items[i];
                            var from=items[j];
                            items[i]=from;
                            items[j]=to;
                        }
                    }              
            },            

            //
            sortFromAttributes: function () {
                athoc.iws.TargetingSettings.sortAttributes(athoc.iws.TargetingSettings.viewModel.fromList()[0]);
                athoc.iws.TargetingSettings.sortAttributes(athoc.iws.TargetingSettings.viewModel.fromList()[1]);
            },

            //Adds items to the right side of shuttle box depending on what was selected on the left hand side
            addItem: function () {
                
                if (athoc.iws.TargetingSettings.viewModel.fromListSelected() === undefined)
                    return;
                if (athoc.iws.TargetingSettings.viewModel.fromListSelected().length == 0)
                    return;


                for (var i = 0; i < athoc.iws.TargetingSettings.viewModel.fromList().length; ++i) {
                    $.each(athoc.iws.TargetingSettings.viewModel.fromList()[i].children(), function (index, element) {

                        if ($.inArray(element.AttributeId(), athoc.iws.TargetingSettings.viewModel.fromListSelected()) > -1) {

                            //push only if the item is not in the list.
                            if (!athoc.iws.TargetingSettings.itemInToList(element.AttributeId())) {
                                if (athoc.iws.TargetingSettings.viewModel.toList().length > 0)
                                    element.DisplayOrder(athoc.iws.TargetingSettings.viewModel.toList()[athoc.iws.TargetingSettings.viewModel.toList().length - 1].DisplayOrder() + 1);
                                else
                                    element.DisplayOrder(1);
                                element.IsSelected(true);
                                element.IsDeleted(false);
                                athoc.iws.TargetingSettings.viewModel.toList().push(element);
                                athoc.iws.TargetingSettings.viewModel.toList.valueHasMutated();
                            }
                        }                                                         
                    });
                    var originalArray = athoc.iws.TargetingSettings.viewModel.fromList()[i].children().slice(0, athoc.iws.TargetingSettings.viewModel.fromList()[i].children().length);
                    var originalLength = originalArray.length;
                    for (var j = 0; j < originalLength; ++j) {
                        var element = originalArray[j];
                        if ($.inArray(element.AttributeId(), athoc.iws.TargetingSettings.viewModel.fromListSelected()) > -1) {
                            athoc.iws.TargetingSettings.viewModel.fromList()[i].children.remove(element);
                        }
                    }
                }              
                athoc.iws.TargetingSettings.viewModel.fromList.valueHasMutated();
                athoc.iws.TargetingSettings.viewModel.fromListSelected([]);
                athoc.iws.TargetingSettings.viewModel.fromListSelected.valueHasMutated();
                athoc.iws.TargetingSettings.viewModel.isChanged(true);
            },

            // Remove items from right side of shuttle box, and make visible in left side of shuttle box.
            removeItem: function () {
                if (athoc.iws.TargetingSettings.viewModel.toListSelected() == undefined)
                    return;
                if (athoc.iws.TargetingSettings.viewModel.toListSelected().length == 0)
                    return;

                var originalArray = athoc.iws.TargetingSettings.viewModel.toList().slice(0, athoc.iws.TargetingSettings.viewModel.toList().length);
                var originalLength = originalArray.length;

                for (var i = 0; i < originalLength; ++i) {
                    var element = originalArray[i];
                    if ($.inArray(element.AttributeId(), athoc.iws.TargetingSettings.viewModel.toListSelected()) > -1) {
                        athoc.iws.TargetingSettings.changeToDelete(element.AttributeId());
                        athoc.iws.TargetingSettings.viewModel.toList.remove(element);
                        element.IsSelected(false);
                        element.IsDeleted(true);
                        if (element.EntityType() == "ATTRIBUTE")
                            athoc.iws.TargetingSettings.viewModel.fromList()[1].children.push(element);
                        else
                            athoc.iws.TargetingSettings.viewModel.fromList()[0].children.push(element);
                    }                  
                }
              
                athoc.iws.TargetingSettings.viewModel.fromList.valueHasMutated();
                athoc.iws.TargetingSettings.viewModel.toListSelected([]);
                athoc.iws.TargetingSettings.viewModel.isChanged(true);               

            },

            // Add all items from left side of shuttle box
            addAll: function () {
                for (var i = 0; i < athoc.iws.TargetingSettings.viewModel.fromList().length; ++i) {
                    $.each(athoc.iws.TargetingSettings.viewModel.fromList()[i].children(), function (index, element) {
                        athoc.iws.TargetingSettings.viewModel.fromListSelected().push(element.AttributeId());
                    });
                }
                athoc.iws.TargetingSettings.addItem();

                for (var i = 0; i < athoc.iws.TargetingSettings.viewModel.fromList().length; ++i) {
                   
                    athoc.iws.TargetingSettings.viewModel.fromList()[i].children.removeAll();
                    
                }
            },

            // Removes all items from right side fo shuttlebox 
            removeAll: function () {
                for (var i = 0; i < athoc.iws.TargetingSettings.viewModel.toList().length; ++i) {

                        athoc.iws.TargetingSettings.viewModel.toListSelected().push(athoc.iws.TargetingSettings.viewModel.toList()[i].AttributeId());
                }
                athoc.iws.TargetingSettings.removeItem();
            },

            // Move items in right side of shuttle box to up side.
            moveUp: function () {
                var index = athoc.iws.TargetingSettings.warnMultipleMove();
                if (index == -1)
                    return;

                if (index == 0)
                    return;

                athoc.iws.TargetingSettings.move(index, index - 1);
            },

            // Move items in right side of shuttle box to down side.
            moveDown: function () {
                var index = athoc.iws.TargetingSettings.warnMultipleMove();
                if (index == -1)
                    return;
                if (index == (athoc.iws.TargetingSettings.viewModel.toList().length - 1))
                    return;
                athoc.iws.TargetingSettings.move(index, index + 1);
            },

            // Find item is already added to left side of shuttle box
            itemInToList: function (itemId) {
                var returnValue = false;
                $.each(athoc.iws.TargetingSettings.viewModel.toList(), function (index, element) {
                    if (element.AttributeId() == itemId) {
                        returnValue = true;
                        return;
                    }

                });
                return returnValue;
            },

            // Find idex of item in right side of shuttle box
            indexOfTo: function (itemId) {
                var returnValue = -1;
                $.each(athoc.iws.TargetingSettings.viewModel.toList(), function (index, element) {
                    if (element.AttributeId() == itemId) {
                        returnValue = index;
                        return;
                    }

                });
                return returnValue;
            },

            // Change status of item when item is moved from right to left box
            changeToDelete: function (itemId) {
                var returnValue = -1;
                for (var i = 0; i < athoc.iws.TargetingSettings.viewModel.fromList().length; ++i) {
                    $.each(athoc.iws.TargetingSettings.viewModel.fromList()[i].children(), function (index, element) {
                        if (element.AttributeId() == itemId) {
                            element.IsSelected(false);
                            element.IsDeleted(true);
                        }
                    });
                }
                return returnValue;
            },

            // Alert when move multiple item in right side of shuttle box
            warnMultipleMove: function () {
                if (athoc.iws.TargetingSettings.viewModel.toListSelected().length == 0)
                    return (-1);

                if (athoc.iws.TargetingSettings.viewModel.toListSelected().length > 1) {
                    $('#dialogMoving').modal('show');
                    return (-1);
                }

                var index = athoc.iws.TargetingSettings.indexOfTo(athoc.iws.TargetingSettings.viewModel.toListSelected()[0]);
                return index;

            },

            // Click event for Distribution checkbox
            clickDistbution:function () {
                athoc.iws.TargetingSettings.viewModel.isChanged(true);
            },

            // Click event for Call bridge response
            clickBrigeRespone:function () {
                athoc.iws.TargetingSettings.viewModel.isChanged(true);
                athoc.iws.TargetingSettings.viewModel.bridgeValue($("#chkBridgeRes").is(":checked"));
            },
            
            // Get List of Targeting settings
            getListColumns: function (callback) {
                var myAjaxOptions = {
                    type: "POST",
                    url: athoc.iws.TargetingSettings.urls.GetTargetingSettings,
                    cache: false,
                    error: function (e) {
                        $.AjaxLoader.hideLoader();
                        athoc.iws.TargetingSettings.handleError(e);
                    }
                };

                var successCallBack = function (callback) {
                    $.AjaxLoader.hideLoader();
                    return function (data) {
                        $("#chkBridgeRes").focus();
                        if (callback && typeof (callback) == 'function') {
                            callback.call(this, data);
                        }
                    };
                }(callback);

                var ajaxOptions = $.extend({}, AjaxUtility(null, successCallBack).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
            },

            // Save targeting settings
            SaveListColumns: function () {
                var items = new Array();
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.TargetingSettings.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%' }).showLoader();

                // newly Added or existing list 
                $.each(athoc.iws.TargetingSettings.viewModel.toList(), function (index, item) {
                    item.DisplayOrder(index + 1);
                    items.push(item);
                });

                // Deleted list
                for (var i = 0; i < athoc.iws.TargetingSettings.viewModel.fromList().length; ++i) {
                    $.each(athoc.iws.TargetingSettings.viewModel.fromList()[i].children(), function (index, element) {
                        if (element.IsDeleted() == true) {
                            items.push(element);
                        }
                    });
                }

                // Checking the distribution list checkbox is checked, if checked add distribution list to the toList
                if ($("#chkDistList").is(":checked")) {
                    athoc.iws.TargetingSettings.viewModel.distrubutionOption().IsSelected(true);
                    athoc.iws.TargetingSettings.viewModel.distrubutionOption().IsDeleted(false);
                    athoc.iws.TargetingSettings.viewModel.distrubutionOption().DisplayOrder(99);
                }
                else {
                    athoc.iws.TargetingSettings.viewModel.distrubutionOption().IsSelected(false);
                    athoc.iws.TargetingSettings.viewModel.distrubutionOption().IsDeleted(true);
                }
                items.push(athoc.iws.TargetingSettings.viewModel.distrubutionOption());

                var myAjaxOptions = {
                    type: "POST",
                    url: athoc.iws.TargetingSettings.urls.SaveTargetingSettings,
                    data: { data: items,bridgeValue:athoc.iws.TargetingSettings.viewModel.bridgeValue() },
                    cache: false,
                    error: function (e) {
                        $.AjaxLoader.hideLoader();
                        athoc.iws.TargetingSettings.handleError(e);
                    }
                };

                var successCallBack = function () {
                    //athoc.iws.TargetingSettings.loadTargetingSettings();
                    $.AjaxLoader.hideLoader();
                    athoc.iws.TargetingSettings.viewModel.isChanged(false);
                };


                var ajaxOptions = $.extend({}, AjaxUtility(null, successCallBack).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
            },

            // To show erros and hadle timeout error
            handleError: function (e) {

                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else if (e.errorThrown != "") {
                    if (athoc.iws.TargetingSettings.errors === null) {
                        athoc.iws.TargetingSettings.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.TargetingSettings.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#saveMessagePanel').messagesPanel({ messages: this.errors }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },

            getTrimmedString: function (stringValue) {

                function getAppropriateLength(value, length) {
                    value = value.substring(0, value.length - 1);
                    if ($('#hiddenSpan').text(value).width() < length) {
                        return value.length;
                    } else {
                        return getAppropriateLength(value, length);
                    }
                }


                if ($('#hiddenSpan').text(stringValue).width() > 250) {
                    var appropriateLength = getAppropriateLength(stringValue, 250);
                    stringValue = stringValue.substring(0, appropriateLength) + '...';
                }

                return stringValue;
            },
        };

    }();
}