﻿/// <reference path="../../Areas/Settings/Views/DeliveryTemplate/DesktopPreview.cshtml" />
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.deliverytemplate = athoc.iws.deliverytemplate || {};

if (athoc.iws.deliverytemplate) {
    var ids = new Array();
    var selectedItems;
    var fileData;
    var tooltip;
    var testModel;
    var ColorTitle, ColorBody, ColorPubBy, ColorPubOn, BackgroundColor, BorderColor;
    var isPreview = false;
    var mode;
   
    athoc.iws.deliverytemplate = function () {
        var sortState;
        var myWindow;
        return {
            IsRightToLeft: false,
            IsRefered: false,
            deliveryTemplatedId: 0,
            deliveryFilter: 0,
            searchMaxLength: 100,
            desktopType: "Private",
            TemplateFilter: [],
            Languages: [],
            Severity: [],
            imgOption: "",
            isChanged: false,
            IsEnterprises: false,
            IsSysAdmin: false,
            IsVirtualSysAdmin: false,
            ContextProvider: 0,
            templateDefinitionTemp: "",
            editModel: {
                deliverytemplatemodel: ko.observable(),
                DeviceToFilter: ko.observable(0),
                AllDeviceArray: ko.observableArray(),
                DefaultTemplateOnly: ko.observable(false),
                selectedSeverity: ko.observable(true),
                SeverityArray: ko.observableArray(0),
                langSupports: ko.observableArray(),
                checkedtemplatecount: ko.observable(0),
                SearchDisabled: ko.observable(true),
                BrowseDisabled: ko.observable(false),
                EditMode: ko.observable(false),
                FontArray: ko.observableArray(),
                FontTypeArray: ko.observableArray(),
                FontSizeArray: ko.observableArray([{ Value: "8", Text: "8" }, { Value: "9", Text: "9" }, { Value: "10", Text: "10" }, { Value: "11", Text: "11" }, { Value: "12", Text: "12" }, { Value: "14", Text: "14" }, { Value: "16", Text: "16" }, { Value: "18", Text: "18" }, { Value: "20", Text: "20" }, { Value: "24", Text: "24" }, { Value: "28", Text: "28" }, { Value: "36", Text: "36" }, { Value: "48", Text: "48" }]),
                DisplayArray: ko.observableArray(),
                ImagePositionArray: ko.observableArray(),
                PopupLocationArray: ko.observableArray(),
                TimeArray: ko.observableArray(),
                EntranceMotionArray: ko.observableArray(),
                ExitMotionArray: ko.observableArray(),
                BorderSizeArray: ko.observableArray([{ Value: "0", Text: "0" }, { Value: "1", Text: "1" }, { Value: "2", Text: "2" }, { Value: "3", Text: "3" }, { Value: "4", Text: "4" }, { Value: "5", Text: "5" }, { Value: "6", Text: "6" }, { Value: "7", Text: "7" }, { Value: "8", Text: "8" }, { Value: "9", Text: "9" }, { Value: "10", Text: "10" }, { Value: "18", Text: "18" }, { Value: "28", Text: "28" }]),
                SevArray: ko.observableArray(),
                selectedLocaleLanguage: ko.observable(),
                localizedSeverity: ko.observable(),
            },
            ViewModel: { deliverytemplatemodel: ko.observable() },
            // To keep the search options to get the Delivery Template list data.
            DeliveryTemplateCriteria: { SearchString: "", DeviceGroupId: 0, DefaultTemplateOnly: false },
            ListModel: kendo.observable(
                {
                    TotalCount: 0,
                    SelectedCount: 0,
                }),

            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for scenario list, will be triggered before document load
            init: function () {
                athoc.iws.deliverytemplate.initBreadcrumb();
                athoc.iws.deliverytemplate.editModel.AllDeviceArray([{ DeviceGroupId: 0, DeviceGroupName: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Device_All }]);
                navigateToPage('listDeliveryTemplate', function () { });
            },

            //load method, will be tirggered on document load
            load: function () {
                // bind Breadcrumb 
                athoc.iws.deliverytemplate.bindBreadcrumb();
                //bind control events
                athoc.iws.deliverytemplate.bindControlEvents();
                //initiate color pickers
                athoc.iws.deliverytemplate.loadColorPicker();


                // Load kendo grid
                athoc.iws.deliverytemplate.createdeliverytemplateListGrid();
                kendo.bind($(".kendoBound"), this.ListModel);
                //Fix the grid header
                var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
                if (gridHeader) {
                    gridHeader.addClass('table-header affix');
                }

                //filterContent
                athoc.iws.deliverytemplate.listLoad();


                // Getsearch data w.r.t Search option 
                var inputElm = $("#txtSearch");
                // Set max length property for Search option 
                inputElm.maxLength({
                    maxLength: athoc.iws.deliverytemplate.searchMaxLength,
                    onMaxReached: function () {
                        $('#saveMessagePanel').modal("show");
                    }
                });
                // Execute search options when press search button
                inputElm.keyup(function (e) {
                    athoc.iws.deliverytemplate.editModel.SearchDisabled(false);



                    if ($.hotkeys.enter(e)) {
                        athoc.iws.deliverytemplate.search();
                    }
                });
                athoc.iws.deliverytemplate.editModel.DeviceToFilter.subscribe(function (newValue) {
                    if (newValue != -1)
                        athoc.iws.deliverytemplate.editModel.SearchDisabled(false);
                });

                $("#chkDefaultTemplateOnly").change(function () {
                    if (athoc.iws.deliverytemplate.editModel.SearchDisabled()) {
                        athoc.iws.deliverytemplate.editModel.SearchDisabled(false);
                    }
                    //athoc.iws.deliverytemplate.search();
                });

                window.onbeforeunload = function () {
                    var isModified = athoc.iws.deliverytemplate.isChanged;

                    if (isModified) {
                        return athoc.iws.deliverytemplate.resources.Unsaved_Data_Text;
                    } else {
                        $(window).scrollTop(0);

                    }
                };

            },
            bindControlEvents: function () {
                // Bind all events to the controls
                $("#btn-search").click(function () {
                    athoc.iws.deliverytemplate.search();
                });
                $("#btn_New").click(function () { athoc.iws.deliverytemplate.CreateDeliveryTemplate(); });

                $("#btn_delete").click(function () { athoc.iws.deliverytemplate.showdeleteConfirmation(); });
                $("#btn_duplicate").click(function () { athoc.iws.deliverytemplate.showduplicateConfirmation(); });

                $("#btn_save").click(function () {
                    if (athoc.iws.deliverytemplate.editModel.EditMode() == true) {
                        athoc.iws.deliverytemplate.saveDeviceTemplatedata();
                    }
                    else {
                        athoc.iws.deliverytemplate.saveNewDeviceTemplatedata();
                    }
                });


                $("#btn-search").click(function () { athoc.iws.deliverytemplate.search(); });
                $("#clearAllBtn").click(function () { athoc.iws.deliverytemplate.clearFilters(); });
                $("#btnDeleteCancel").click(function () { $("#dialogDeleteConfirm").modal('hide'); });
                $("#btnDeleteConfirm").click(function () { athoc.iws.deliverytemplate.deleteDeliveryTemplateManager(); });

                $("#btnDuplicateCancel").click(function () { $("#dialogDuplicateConfirm").modal('hide'); });
                $("#btnDuplicateConfirm").click(function () { athoc.iws.deliverytemplate.duplicateDeliveryTemplateManager(); });

                $("#btnSeverityCancel").click(function () {
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.DefaultTemplateId(0);
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.DefaultSeverity(false);
                    $("#dialogDefaultSeverityConfirm").modal('hide');
                });

                $("#btnSeverityConfirm").click(function () {
                    $("#dialogDefaultSeverityConfirm").modal('hide');
                });

                $("#btn_ecancel").click(function () {
                    var isModified = athoc.iws.deliverytemplate.isChanged;
                    if (isModified == true) {
                        var confirmLeave = confirm(athoc.iws.deliverytemplate.resources.Unsaved_Data_Text);
                        if (confirmLeave == true) {
                            athoc.iws.deliverytemplate.isChanged = false;
                            athoc.iws.deliverytemplate.viewDeliveryList();
                        }
                    }
                    else {
                        athoc.iws.deliverytemplate.viewDeliveryList();
                    }
                    //athoc.iws.deliverytemplate.clearFilters();

                });
                $("#btn_vcancel").click(function () {
                    athoc.iws.deliverytemplate.IsRefered = false;
                    navigateToPage('listDeliveryTemplate', function () { });
                    var breadcrumbsModel = athoc.iws.deliverytemplate.breadcrumbModel;
                    breadcrumbsModel.SelectedPage('listDeliveryTemplate');
                    $.titleCrumb("pageBreadcrumbs");
                    $(document).scrollTop(0);
                    // athoc.iws.deliverytemplate.resetSearchCriteria();
                    athoc.iws.deliverytemplate.refreshGrid();
                    athoc.iws.deliverytemplate.listLoad();
                    // athoc.iws.deliverytemplate.clearFilters();
                });

                //bind click event for all the buttons defined at navigation page
                $("#btn_preview").click(function () {

                    athoc.iws.deliverytemplate.showDesktopTemplatePreview();
                });

                $("#btn_ncancel").click(function () {

                    var isModified = athoc.iws.deliverytemplate.isChanged;
                    if (isModified == true) {
                        var confirmLeave = confirm(athoc.iws.deliverytemplate.resources.Unsaved_Data_Text);
                        if (confirmLeave == true) {
                            athoc.iws.deliverytemplate.isChanged = false;
                            athoc.iws.deliverytemplate.viewDeliveryList();
                        }
                    }
                    else {
                        athoc.iws.deliverytemplate.viewDeliveryList();
                    }

                });
                $("#btn_npreview").click(function () {

                    athoc.iws.deliverytemplate.showDesktopTemplatePreview();
                });

                $("#btn_nsave").click(function () {
                    athoc.iws.deliverytemplate.saveNewDeviceTemplatedata();
                });
                $("#btn_vpreview").click(function () {

                    athoc.iws.deliverytemplate.showDesktopTemplatePreview();
                });

            },
            //to fill device dropdown with model data
            fillDeviceDropdown: function (data) {

                if (athoc.iws.deliverytemplate.editModel.AllDeviceArray().length <= 1) {
                    _.each(data, function (item) {
                        athoc.iws.deliverytemplate.editModel.AllDeviceArray.push(item);
                        $('#divActions ul').append('<li><a id=New_' + item.DeviceGroupName + ' onclick="athoc.iws.deliverytemplate.CreateDeliveryTemplate(' + item.DeviceGroupId + ')">' + item.DeviceGroupName + '</a></li>');
                    });
                }


            },


            getDropdownvalue: function (objArray, val, optionType) {


                var obj = _.find(objArray, function (item) {
                    if (optionType == 1)
                        return (item.SeverityId.toLowerCase() == val.toLowerCase());
                    else
                        return (item.Value.toLowerCase() == val.toLowerCase());
                });
                if (obj != null) {
                    if (optionType == 1)
                        return obj.SeverityName;
                    else
                        return obj.Text;
                }
                else
                    return val;
            }
            ,
            getDeviceGroupValue: function (objArray, val) {

                var devicegroup;
                _.each(objArray, function (item) {
                    if (item.DeviceGroupId == val)
                        devicegroup = item.DeviceGroupName;

                });
                return devicegroup;

            },
            // load color controls
            loadColorPicker: function () {

                // initiate Colorpicker for Title
                $("#ddlColorTitle").kendoColorPicker({
                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });
                $("#vddlColorTitle").kendoColorPicker({
                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });

                //initiate color for Body
                $("#ddlColorBody").kendoColorPicker({
                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });
                $("#vddlColorBody").kendoColorPicker({
                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });

                //initiate colorpicker for  published by
                $("#ddlColorPubBy").kendoColorPicker({
                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });
                $("#vddlColorPubBy").kendoColorPicker({
                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });

                //initiate Colorpicker for published On
                $("#ddlColorPubOn").kendoColorPicker({

                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });
                $("#vddlColorPubOn").kendoColorPicker({

                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });


                // intiate Colorpicker for Border Color
                $("#ddlBorderColor").kendoColorPicker({
                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });
                $("#vddlBorderColor").kendoColorPicker({
                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });

                //initiate Color picker for Background color
                $("#ddlBackgroundColor").kendoColorPicker({
                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });
                $("#vddlBackgroundColor").kendoColorPicker({
                    select: athoc.iws.deliverytemplate.preview,
                    messages: { apply: athoc.iws.deliverytemplate.resources.Action_Button_Apply, cancel: athoc.iws.deliverytemplate.resources.Action_Button_Cancel }
                });

                athoc.iws.deliverytemplate.ColorTitle = $("#ddlColorTitle").data("kendoColorPicker");
                athoc.iws.deliverytemplate.ColorBody = $("#ddlColorBody").data("kendoColorPicker");
                athoc.iws.deliverytemplate.ColorPubBy = $("#ddlColorPubBy").data("kendoColorPicker");
                athoc.iws.deliverytemplate.ColorPubOn = $("#ddlColorPubOn").data("kendoColorPicker");
                athoc.iws.deliverytemplate.BackgroundColor = $("#ddlBackgroundColor").data("kendoColorPicker");
                athoc.iws.deliverytemplate.BorderColor = $("#ddlBorderColor").data("kendoColorPicker");

                athoc.iws.deliverytemplate.vColorTitle = $("#vddlColorTitle").data("kendoColorPicker");
                athoc.iws.deliverytemplate.vColorBody = $("#vddlColorBody").data("kendoColorPicker");
                athoc.iws.deliverytemplate.vColorPubBy = $("#vddlColorPubBy").data("kendoColorPicker");
                athoc.iws.deliverytemplate.vColorPubOn = $("#vddlColorPubOn").data("kendoColorPicker");
                athoc.iws.deliverytemplate.vBackgroundColor = $("#vddlBackgroundColor").data("kendoColorPicker");
                athoc.iws.deliverytemplate.vBorderColor = $("#vddlBorderColor").data("kendoColorPicker");

            },
            // To toggle collapse panel
            collapsePanel: function () {
                $(this).parent().find('.expand-arrow-open').toggle();
                $('.bucket-toggle h2').click(function () {
                    $(this).parent().find('.row').slideToggle(500);
                    $(this).parent().find('.expand-arrow-open').toggle();
                    $(this).parent().find('.expand-arrow-closed').toggle();
                });
            },

            //To display image w.r.t base64Data
            displayImage: function (guid) {

                var imag;
                var defaultUrl = athoc.iws.deliverytemplate.urls.cdnUrl + "/images/default-logo.png";

                if ((guid != null) && (guid != "")) {
                    if (mode != 2)
                        $("#imgEdit").attr("src", "/athoc-iws/Media/Get/" + guid);
                    else
                        $("#imgView").attr("src", "/athoc-iws/Media/Get/" + guid);
                    $('#importFileText').val(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imagePath());
                    $('#divthumb').css("display", "");
                    $('#vdivthumb').css("display", "");

                }
                else {
                    if (mode != 2)
                        $("#imgEdit").attr("src", "");
                    else
                        $("#imgView").attr("src", "");
                    $('#divthumb').css("display", "none");
                    $('#vdivthumb').css("display", "none");
                    $('#importFileText').val("");
                }
            },

            // Triggered, when clear all link is clicked, it clear the searchCriteria and reload the grid
            clearFilters: function () {
                $("#txtSearch").val("");
                athoc.iws.deliverytemplate.DeliveryTemplateCriteria.SearchString = "";
                athoc.iws.deliverytemplate.editModel.checkedtemplatecount(0);
                athoc.iws.deliverytemplate.DeliveryTemplateCriteria.DeviceGroupId = 0;
                athoc.iws.deliverytemplate.DeliveryTemplateCriteria.DefaultTemplateOnly = false;
                $('#chkDefaultTemplateOnly').prop('checked', false);
                athoc.iws.deliverytemplate.editModel.DeviceToFilter(0);
                athoc.iws.deliverytemplate.refreshGrid();
                athoc.iws.deliverytemplate.listLoad();
                $("#btn_duplicate").attr('disabled', 'true');
                $("#btn_delete").attr('disabled', 'true');
                athoc.iws.deliverytemplate.editModel.SearchDisabled(true);
                $("#chkDefaultSev")[0].checked = false;
                $("#DeviceFilter").selectpicker('refresh');

            },
            // Triggered, when search button or hit enter in search textbox
            search: function () {
                if ($("#txtSearch").length <= athoc.iws.deliverytemplate.searchMaxLength) {
                    athoc.iws.deliverytemplate.DeliveryTemplateCriteria.SearchString = $.trim($("#txtSearch").val());
                    $("#txtSearch").val($.trim($("#txtSearch").val()));
                    athoc.iws.deliverytemplate.DeliveryTemplateCriteria.DefaultTemplateOnly = $('#chkDefaultTemplateOnly').prop('checked');
                    athoc.iws.deliverytemplate.editModel.checkedtemplatecount(0);
                    athoc.iws.deliverytemplate.DeliveryTemplateCriteria.DeviceGroupId = athoc.iws.deliverytemplate.editModel.DeviceToFilter();
                    athoc.iws.deliverytemplate.refreshGrid();
                    athoc.iws.deliverytemplate.listLoad();
                    $("#btn-search").attr('disabled', 'true');
                    $("#btn_delete").attr('disabled', 'true');
                    $("#btn_duplicate").attr('disabled', 'true');
                }
                else
                    $('#saveMessagePanel').modal("show");
                $("#txtSearch").focus();
            },
            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),
            initBreadcrumb: function () {

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.deliverytemplate.breadcrumbModel;
                var isModified = athoc.iws.deliverytemplate.isChanged;


                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.deliverytemplate.resources.AtHoc_Common_Settings, '', function () {
                    window.location.href = "/client/setup/settings";
                });

                var deliverytemplateLink = new Breadcrumb('deliverytemplateLink', athoc.iws.deliverytemplate.resources.DeliveryTemplate_TitleText, '', function () {
                    if (isModified) {
                        var confirmLeave = confirm(athoc.iws.deliverytemplate.resources.Unsaved_Data_Text);
                        if (confirmLeave == true) {
                            athoc.iws.deliverytemplate.isChanged = false;
                            athoc.iws.deliverytemplate.viewDeliveryList();
                        }
                    }
                    else { athoc.iws.deliverytemplate.viewDeliveryList(); }

                });


                //Page breadcrumb
                var listPageBreadcrumb = new PageBreadcrumb('listDeliveryTemplate', athoc.iws.deliverytemplate.resources.DeliveryTemplate_TitleText, [settingLink], '');
                //To View Delivery template data
                var viewPageBreadcrumb = new PageBreadcrumb('viewDeliveryTemplate', '', [settingLink, deliverytemplateLink], '');
                //To Edit Delivery template data
                var editPageBreadcrumb = new PageBreadcrumb('editDeliveryTemplate', '', [settingLink, deliverytemplateLink], '');


                breadcrumbsModel.addPage(listPageBreadcrumb);
                breadcrumbsModel.addPage(viewPageBreadcrumb);
                breadcrumbsModel.addPage(editPageBreadcrumb);

            },
            //

            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.deliverytemplate.breadcrumbModel;
                breadcrumbsModel.SelectedPage('listDeliveryTemplate');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');

                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            viewDeliveryList: function () {


                athoc.iws.deliverytemplate.IsRefered = false;
                navigateToPage('listDeliveryTemplate', function () { });
                var breadcrumbsModel = athoc.iws.deliverytemplate.breadcrumbModel;
                breadcrumbsModel.SelectedPage('listDeliveryTemplate');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);
                //athoc.iws.deliverytemplate.resetSearchCriteria();
                athoc.iws.deliverytemplate.refreshGrid();
                athoc.iws.deliverytemplate.listLoad();
                mode = 0;
                athoc.iws.deliverytemplate.updateTitle();
                //athoc.iws.deliverytemplate.clearFilters();

            }
            , updateTitle: function () {

                switch (mode) {
                    case 1:
                        athoc.iws.deliverytemplate.breadcrumbModel.updateTitle(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.name(), undefined, undefined, 'editDeliveryTemplate');
                        break;
                    case 2:
                        athoc.iws.deliverytemplate.breadcrumbModel.updateTitle(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.name(), undefined, undefined, 'viewDeliveryTemplate');
                        break;

                    default:
                        athoc.iws.deliverytemplate.breadcrumbModel.updateTitle("", undefined, undefined, 'editDeliveryTemplate');
                        athoc.iws.deliverytemplate.breadcrumbModel.updateTitle("", undefined, undefined, 'viewDeliveryTemplate');
                        break;
                }
            },
            //To duplicate template data w.r.t selected Template Id's
            duplicateDeliverTemplate: function () {
                athoc.iws.deliverytemplate.getSelectedItems();
                if (ids.length > 0) {

                    $('#saveMessagePanel').html('');

                    var dlAjaxOption =
                        {
                            url: athoc.iws.deliverytemplate.urls.DuplicateDeliveryTemplateUrl,
                            contentType: "application/json; charset=utf-8",
                            dataType: 'json',
                            type: 'POST',
                            data: JSON.stringify(ids),
                            success: function (data) {
                                if (data.Success) {
                                    athoc.iws.deliverytemplate.isChanged = false;
                                    athoc.iws.deliverytemplate.editModel.checkedtemplatecount(0);
                                    athoc.iws.deliverytemplate.refreshGrid();
                                    athoc.iws.deliverytemplate.listLoad();
                                    $("#btn_duplicate").attr('disabled', 'true');
                                    $("#btn_delete").attr('disabled', 'true');
                                } else {

                                    $('#saveMessagePanel').css("display:none");
                                    $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                                }


                            },
                            error: function (e) {
                                $.AjaxLoader.hideLoader();
                                athoc.iws.deliverytemplate.handleError(e);
                            }
                        };

                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                    $.ajax(ajaxOptions);

                    return true;
                }
            },
            //To New template data w.r.t selected Template Id's
            CreateDeliveryTemplate: function (deviceType) {

                athoc.iws.deliverytemplate.getDeviceStylesheet(deviceType);

            },

            initiateSelectPicker: function () {
                if (mode != 2) {
                    $("#ddlDeviceId").selectpicker();
                    $("#ddlTitleDisplay").selectpicker();
                    $("#ddlFontTitle").selectpicker();
                    $("#ddlFontTypeTitle").selectpicker();
                    $("#ddlSizeTitle").selectpicker();
                    $("#ddlDisplayBody").selectpicker();
                    $("#ddlFontBody").selectpicker();
                    $("#ddlFontTypeBody").selectpicker();
                    $("#ddlSizeBody").selectpicker();
                    $("#ddlDisplayPubBy").selectpicker();
                    $("#ddlFontPubBy").selectpicker();
                    $("#ddlFontTypePubBy").selectpicker();
                    $("#ddlSizePubBy").selectpicker();
                    $("#ddlDisplayPubOn").selectpicker();
                    $("#ddlFontPubOn").selectpicker();
                    $("#ddlFontTypePubOn").selectpicker();
                    $("#ddlSizePubOn").selectpicker();
                    $("#ddlBorderSize").selectpicker();
                    $("#ddlImageLogo").selectpicker();
                    $("#ddlPopupLocation").selectpicker();
                    $("#ddlPopupTimeout").selectpicker();
                    $("#ddlEntranceMotion").selectpicker();
                    $("#ddlExitMotion").selectpicker();
                    $("#ddlSeverity").selectpicker();
                    $("#ddlLocale").selectpicker();

                    // Added for bootstrap select drop-down hiding issue under footer [IWS-23022]
                    $(".dropdown-scrolldown button").click(function () {
                        var n = $(document).height();
                        $('html, body').animate({ scrollTop: n }, 100);
                        $('.dropdown-scrolldown .dropdown-menu').css("z-index", "99");
                    });

                    $('#ddlLocale').on('change', function () {
                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.deliverytemplate.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.deliverytemplate.resources.General_LoadingMessage }).showLoader();
                        var jsonData = ko.toJSON({ DeviceId: athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.deviceGroupId(), Locale: athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.LocaleCode() });
                        var dlAjaxOption =
                            {
                                url: athoc.iws.deliverytemplate.urls.getDeviceStylesheetByRegionURL,
                                contentType: "application/json; charset=utf-8",
                                dataType: 'json',
                                type: 'POST',
                                data: jsonData,
                                success: function (data) {
                                    if (data.Success) {
                                        athoc.iws.deliverytemplate.isChanged = true;
                                        athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateDefinition(data.Data.templateDefinition);
                                    }
                                    $.AjaxLoader.hideLoader();
                                    $("#editDeliveryTemplate").show();
                                },
                                error: function (e) {
                                    $.AjaxLoader.hideLoader();
                                    athoc.iws.deliverytemplate.handleError(e);
                                }
                            };

                        var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                        $.ajax(ajaxOptions);
                        return true;

                    });

                }

            },

            showdeleteConfirmation: function () {
                var items = datasource.data();
                var selectedIds = new Array();
                var selectedNames = new Array();
                var selectedStandardCnt = 0;
                var nameTags = "";
                $("#privateFiles").hide();
                $("#globalFiles").hide();
                $("#itemsToDelete").hide();
                $("#itemsToDelete").html('');
                $("#btnDeleteConfirm").attr("disabled", true);
                $.grep(items, function (v) {

                    if (v.IsChecked) {

                        if (athoc.iws.deliverytemplate.ContextProvider == v.Provider_Id) {
                            if ((athoc.iws.deliverytemplate.IsSysAdmin || athoc.iws.deliverytemplate.IsEnterprises || athoc.iws.deliverytemplate.IsVirtualSysAdmin || v.IsOwner) && ((v.AlertStatus) == "N") && ((v.Default_Severity == "N") || (v.Default_Severity == "Y" && v.Provider_Id != 3))) {
                                selectedIds.push(v.Template_Id);
                                selectedNames.push(v.Name);
                            }
                            else
                                selectedStandardCnt++;
                        }
                        else
                            selectedStandardCnt++;
                    }
                });

                if (selectedIds.length > 0) {
                    $("#privateFiles").show();
                    $("#itemsToDelete").show();
                    $("#btnDeleteConfirm").removeAttr("disabled");
                    $("#privateFiles").text(athoc.iws.deliverytemplate.resources.Delivery_Delete_DialogText.replace("{0}", selectedIds.length) + '.');
                    if (selectedStandardCnt > 0) {
                        $("#privateFiles").text(athoc.iws.deliverytemplate.resources.Delivery_Delete_DialogText.replace("{0}", selectedIds.length) + ', ' + athoc.iws.deliverytemplate.resources.Delivery_Standard_Delete_DialogText.replace("{0}", selectedStandardCnt));
                    }
                    selectedNames.sort();
                    for (var i = 0; i < selectedNames.length; i++) {
                        nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(selectedNames[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(selectedNames[i]) + "</div>";
                    }
                    $("#itemsToDelete").html("<div class='mar-top10'>" + nameTags + "</div>");
                }
                else if (selectedStandardCnt > 0) {
                    selectedNames.sort();
                    for (var i = 0; i < selectedNames.length; i++) {
                        nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(selectedNames[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(selectedNames[i]) + "</div>";
                    }
                    $("#itemsToDelete").html("<div class='mar-top10'>" + nameTags + "</div>");
                    $("#itemsToDelete").show();
                    $("#globalFiles").show();
                    $("#globalFiles").text(athoc.iws.deliverytemplate.resources.Delivery_Standard_Delete_DialogText.replace("{0}", selectedStandardCnt));
                }

                $('#dialogDeleteConfirm').modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        $("#btnDeleteCancel").attr("tabindex", 15).focus();
                    }, 1000);
                });
            },

            showduplicateConfirmation: function () {
                var items = datasource.data();
                var selectedIds = new Array();
                var selectedNames = new Array();
                var selectedStandardCnt = 0;
                var nameTags = "";
                $("#privateDuplicateFiles").hide();
                $("#globalDuplicateFiles").hide();
                $("#itemsToDuplicate").hide();
                $("#itemsToDuplicate").html('');
                $("#btnDuplicateConfirm").attr("disabled", true);
                $.grep(items, function (v) {
                    if (v.IsChecked) {

                        selectedIds.push(v.Template_Id);
                        selectedNames.push(v.Name);
                    }
                });

                if (selectedIds.length > 0) {
                    $("#privateDuplicateFiles").show();
                    $("#itemsToDuplicate").show();
                    $("#btnDuplicateConfirm").removeAttr("disabled");
                    $("#privateDuplicateFiles").text(athoc.iws.deliverytemplate.resources.Delivery_Duplicate_DialogText.replace("{0}", selectedIds.length) + '.');
                    if (selectedStandardCnt > 0) {
                        $("#privateDuplicateFiles").text(athoc.iws.deliverytemplate.resources.Delivery_Duplicate_DialogText.replace("{0}", selectedIds.length) + ', ' + athoc.iws.deliverytemplate.resources.Delivery_Standard_Duplicate_DialogText.replace("{0}", selectedStandardCnt));
                    }
                    selectedNames.sort();
                    for (var i = 0; i < selectedNames.length; i++) {
                        nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(selectedNames[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(selectedNames[i]) + "</div>";
                    }
                    $("#itemsToDuplicate").html("<div class='mar-top10'>" + nameTags + "</div>");
                }
                else if (selectedStandardCnt > 0) {
                    selectedNames.sort();
                    for (var i = 0; i < selectedNames.length; i++) {
                        nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(selectedNames[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(selectedNames[i]) + "</div>";
                    }
                    $("#itemsToDuplicate").html("<div class='mar-top10'>" + nameTags + "</div>");
                    $("#itemsToDuplicate").show();
                    $("#globalDuplicateFiles").show();
                    $("#globalDuplicateFiles").text(athoc.iws.deliverytemplate.resources.Delivery_Standard_Duplicate_DialogText.replace("{0}", selectedStandardCnt));
                }

                $('#dialogDuplicateConfirm').modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        $("#btnDuplicateCancel").attr("tabindex", 15).focus();
                    }, 1000);
                });
            },
            // Triggered, When deleteing the delivery Template records
            deleteDeliveryTemplateManager: function () {
                $('#saveMessagePanel').html('');
                ids.length = 0;
                // Get selected  delivery Template records
                var items = datasource.data();
                // Keep selected  delivery Template records in array
                $.grep(items, function (v) {
                    if (v.IsChecked) {
                        if ((v.Default_Severity == "N") || ((v.Provider_Id != 3) && (v.Default_Severity == "Y"))) {
                            ids.push(v);
                        }
                    }
                });

                var dlAjaxOption =
                    {
                        url: athoc.iws.deliverytemplate.urls.DeleteDeliveryTemplateUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(ids),
                        success: function (data) {
                            $("#dialogDeleteConfirm").modal('hide');
                            athoc.iws.deliverytemplate.isChanged = false;
                            athoc.iws.deliverytemplate.editModel.checkedtemplatecount(0);
                            athoc.iws.deliverytemplate.refreshGrid();
                            athoc.iws.deliverytemplate.listLoad();
                            athoc.iws.deliverytemplate.clearFilters();
                            $("#btn_duplicate").attr('disabled', 'true');
                            $("#btn_delete").attr('disabled', 'true');
                        },
                        error: function (e) {
                            $("#dialogDeleteConfirm").modal('hide');
                            athoc.iws.deliverytemplate.handleError(e);
                        }

                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);

                $.ajax(ajaxOptions);

                return true;
            },
            // Triggered, When duplicating the delivery Template records
            duplicateDeliveryTemplateManager: function () {
                $('#saveMessagePanel').html('');
                ids.length = 0;
                // Get selected  delivery Template records
                var items = datasource.data();
                // Keep selected  delivery Template records in array
                $.grep(items, function (v) {
                    if (v.IsChecked) {
                        ids.push(v);
                    }
                });
                $("#btnDuplicateConfirm").attr('disabled', 'true');
                var dlAjaxOption =
                    {
                        url: athoc.iws.deliverytemplate.urls.DuplicateDeliveryTemplateUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(ids),
                        success: function (data) {
                            $("#dialogDuplicateConfirm").modal('hide');
                            athoc.iws.deliverytemplate.isChanged = false;
                            athoc.iws.deliverytemplate.editModel.checkedtemplatecount(0);
                            athoc.iws.deliverytemplate.refreshGrid();
                            athoc.iws.deliverytemplate.listLoad();
                            athoc.iws.deliverytemplate.clearFilters();
                            $("#btn_duplicate").attr('disabled', 'true');
                            $("#btn_delete").attr('disabled', 'true');
                        },
                        error: function (e) {
                            $("#dialogDuplicateConfirm").modal('hide');
                            athoc.iws.deliverytemplate.handleError(e);
                        }

                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);

                $.ajax(ajaxOptions);

                return true;
            },
            // before preview set current color picker values to model so that preview will be generate based on current settings
            preview: function (input) {
                if (input.sender.element[0].id == "ddlColorBody")
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyColor = input.value;
                if (input.sender.element[0].id == "ddlColorTitle")
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleColor = input.value;
                if (input.sender.element[0].id == "ddlColorPubOn")
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnColor = input.value;
                if (input.sender.element[0].id == "ddlColorPubBy")
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByColor = input.value;
                if (input.sender.element[0].id == "ddlBorderColor")
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateBorderColor = input.value;
                if (input.sender.element[0].id == "ddlBackgroundColor")
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateBackgroundColor = input.value;

            },
            // todisplay the template settings in edit mode
            editdeliverytemplateDetail: function (model) {
                navigateToPage('editDeliveryTemplate', function () { });
                athoc.iws.deliverytemplate.breadcrumbModel.SelectedPage('editDeliveryTemplate');
                $.titleCrumb("pageBreadcrumbs");
                $('#editDeliveryTemplate').hide();
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.deliverytemplate.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                $('#saveMessagePanel').html('');
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel = ko.mapping.fromJS(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel, athoc.iws.deliverytemplate.getValidation());

                var dataPost = { TemplateId: model.Template_Id };
                var dlAjaxOption =
                    {
                        url: athoc.iws.deliverytemplate.urls.GetDeliveryTemplateDetailsUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(dataPost),
                        success: function (data) {
                            if (data.Success) {
                                athoc.iws.deliverytemplate.IsRefered = false;

                                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel = ko.mapping.fromJS(data.Data);
                                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.createdOn() != "")
                                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.createdOn($.getVPSLocalDateTime(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.createdOn(), $.getMomentDateTimeFormat(($.vpsTimeZone.dateTimeFormat))));
                                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.updatedOn() != "")
                                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.updatedOn($.getVPSLocalDateTime(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.updatedOn(), $.getMomentDateTimeFormat(($.vpsTimeZone.dateTimeFormat))));

                                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.deviceGroupName(model.Device_Group_Name);


                                // athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.name(model.Name);
                                athoc.iws.deliverytemplate.editModel.langSupports(data.languages);
                                // assign format model values to individual dropdowns
                                athoc.iws.deliverytemplate.editModel.FontArray(data.formatModel.FontList);
                                athoc.iws.deliverytemplate.editModel.FontTypeArray(data.formatModel.FontTypeList);
                                athoc.iws.deliverytemplate.editModel.ImagePositionArray(data.formatModel.ImagePositionList);
                                athoc.iws.deliverytemplate.editModel.PopupLocationArray(data.formatModel.PopupPositionList);
                                athoc.iws.deliverytemplate.editModel.TimeArray(data.formatModel.DesktopTimeList);
                                athoc.iws.deliverytemplate.editModel.DisplayArray(data.formatModel.DisplayStyleList);
                                athoc.iws.deliverytemplate.editModel.EntranceMotionArray(data.formatModel.EntranceMotionStyleList);
                                athoc.iws.deliverytemplate.editModel.ExitMotionArray(data.formatModel.ExitMotionStyleList);
                                athoc.iws.deliverytemplate.editModel.SevArray(data.formatModel.SeverityList);

                                athoc.iws.deliverytemplate.editModel.EditMode(true);

                                // athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.DefaultSeverity()? $("#chkDefaultSev")[0].checked=true:false;
                                $("#editDeliveryTemplate").find(".bootstrap-select").remove();

                                $("#editDeliveryTemplate").find(".k-select").addClass("colorpicker-sheight");

                                $("#editDeliveryTemplate").find(".k-picker-wrap").addClass("colorpicker-border");

                                $("#editDeliveryTemplate").find(".k-selected-color").addClass("colorpicker-height");


                                ko.cleanNode($("#editDeliveryTemplate").get(0));
                                ko.applyBindings(athoc.iws.deliverytemplate.editModel, $("#editDeliveryTemplate").get(0));


                                mode = 1;
                                athoc.iws.deliverytemplate.breadcrumbModel.updateTitle(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.name(), undefined, undefined, 'editDeliveryTemplate');
                                athoc.iws.deliverytemplate.collapsePanel();
                                athoc.iws.deliverytemplate.updateMoreLess();
                                athoc.iws.deliverytemplate.editSubscribeMethods();
                                athoc.iws.deliverytemplate.initiateSelectPicker();
                                $('[data-id=ddlLocale]').attr("disabled", "disabled");
                                //register FileUpload
                                if (fileData != null) {
                                    fileData = null;

                                }
                                athoc.iws.deliverytemplate.registerFileUpload();
                                $("#btn_preview").removeAttr("disabled");

                                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.IsDesktopTemplate() || athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.IsEmailTemplate()) {
                                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.IsDesktopTemplate())
                                        athoc.iws.deliverytemplate.setNotifierTemplateSettings(mode);
                                    $("#btn_preview").show();
                                }
                                else
                                    $("#btn_preview").hide();
                            }
                            else {

                                if (data.HasErrors) {
                                    $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                                    if (data.ReturnType == 1) {
                                        $("#TemplatedCommonNameTxt").focus();
                                        $("html,body").scrollTop(0);
                                    }
                                }
                            }


                            athoc.iws.deliverytemplate.IsRefered = false;
                            $.AjaxLoader.hideLoader();
                            $('#editDeliveryTemplate').show();
                            $("html,body").scrollTop(0);
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.deliverytemplate.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
                return true;
            },
            editSubscribeMethods: function () {

                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.name.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        athoc.iws.deliverytemplate.isChanged = true;

                        if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateCommonName() == null || athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateCommonName() == "") {
                            athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateCommonName(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.name().trim().replace(/\s/g, '-'));
                        }
                        athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.name($.trim(newValue));
                    }
                    athoc.iws.deliverytemplate.breadcrumbModel.updateTitle(newValue == "" ? athoc.iws.deliverytemplate.resources.DeliveryTemplate_NewTemplate : newValue, undefined, undefined, 'editDeliveryTemplate');



                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imgOption.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                    if (newValue == 'CUSTOM') {
                        if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imageData() == "" || athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imageData() == null)
                            athoc.iws.deliverytemplate.displayImage(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateImageGuid());
                        else {
                            $("#imgEdit").attr("src", "data:image/gif;base64," + athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imageData());
                            $("#divthumb").css("display", "block");
                            $("#vdivthumb").css("display", "block");
                        }
                    }
                    else {
                        athoc.iws.deliverytemplate.displayImage(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.vpsImageId());
                        $('#importFileText').val("");
                    }

                });

                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.DefaultSeverity.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.DefaultSeverity(newValue);

                    athoc.iws.deliverytemplate.CheckDefaultSeverityforTemplate(true);
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.Severity.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.Severity(newValue);
                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.DefaultSeverity)
                        athoc.iws.deliverytemplate.CheckDefaultSeverityforTemplate(true);
                });

                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.LocaleCode.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.LocaleCode(newValue);
                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.DefaultSeverity)
                        athoc.iws.deliverytemplate.CheckDefaultSeverityforTemplate(true);
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.timeOut.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.timeOutUnit.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.timeOutValue.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.timeOutValue($.trim(newValue));
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.width.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.width($.trim(newValue));
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.height.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.height($.trim(newValue));
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.leftOffset.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.topOffset.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.motionOn.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.motionOff.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateCommonName.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;

                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateCommonName() == "") {
                        athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateCommonName(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.name().trim().replace(/\s/g, '-'));
                    }

                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.description.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateDefinition.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.useAdvancedStyle.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });



                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.fullScreenYN.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });

                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleDisplay.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleColor.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleFont.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleFontType.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleSize.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyDisplay.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyColor.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyFont.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyFontType.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodySize.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByDisplay.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByColor.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByFont.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByFontType.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedBySize.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnDisplay.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnColor.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnFont.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnFontType.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnSize.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateBorderColor.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateBorderSize.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateBackgroundColor.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateImageLogo.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });


                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imagePath.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });

                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imageDisplay.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.deliverytemplate.isChanged = true;
                });




            },
            //set notifier template settings before data load
            setNotifierTemplateSettings: function (mode) {
                if (mode == 1 || mode == 3) {
                    athoc.iws.deliverytemplate.ColorTitle.enable(true);
                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleColor() != "")
                        athoc.iws.deliverytemplate.ColorTitle.value(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleColor());

                    athoc.iws.deliverytemplate.ColorBody.enable(true);
                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyColor() != "")
                        athoc.iws.deliverytemplate.ColorBody.value(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyColor());

                    athoc.iws.deliverytemplate.ColorPubBy.enable(true);
                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByColor() != "")
                        athoc.iws.deliverytemplate.ColorPubBy.value(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByColor());

                    athoc.iws.deliverytemplate.ColorPubOn.enable(true);
                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnColor() != "")
                        athoc.iws.deliverytemplate.ColorPubOn.value(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnColor());

                    athoc.iws.deliverytemplate.BackgroundColor.enable(true);
                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateBackgroundColor() != "")
                        athoc.iws.deliverytemplate.BackgroundColor.value(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateBackgroundColor());

                    athoc.iws.deliverytemplate.BorderColor.enable(true);
                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateBorderColor() != "")
                        athoc.iws.deliverytemplate.BorderColor.value(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateBorderColor());
                }


                athoc.iws.deliverytemplate.imgOption = athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imgOption();

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imgOption() == "CUSTOM") {
                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateImageGuid() != "")
                        athoc.iws.deliverytemplate.displayImage(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateImageGuid());
                    else {
                        athoc.iws.deliverytemplate.displayImage("");
                        athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imagePath("");

                    }

                }
                else {
                    athoc.iws.deliverytemplate.displayImage(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.vpsImageId());
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imagePath("");

                }


            },
            // to register file upload
            registerFileUpload: function () {
                var deliveryTemplateLogoImageFileName;
                $("#eUpload").fileupload({
                    dataType: 'json',
                    autoUpload: false,
                    maxFileSize: 5000000,
                    url: athoc.iws.deliverytemplate.urls.GetImageStringUrl,
                    done: function (e, data) {
                        $.AjaxLoader.hideLoader();
                        if (data.result.Success) {
                            athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imageData(data.result.data);
                            athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imageType(data.result.type);
                            athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imageExtension(data.result.extension);
                            $("#imgEdit").attr("src", "data:image/gif;base64," + data.result.data);
                            $("#divthumb").css("display", "block");
                            $("#vdivthumb").css("display", "block");

                        }
                        else if (data.result.HasErrors) {
                            $('#saveMessagePanel').html('');
                            $('#saveMessagePanel').messagesPanel({ messages: data.result.Messages });
                            $('#importFileText').val(deliveryTemplateLogoImageFileName);
                            $("html,body").scrollTop(0);
                        }
                        else {
                            athoc.iws.deliverytemplate.handleError(data);
                        }

                    },
                    add: function (e, data) {
                        fileData = data;
                        $('#saveMessagePanel').html('');
                        deliveryTemplateLogoImageFileName = $("#importFileText").val();
                        $.each(data.files, function (index, file) {
                            var ext = file.name.split(".")[file.name.split(".").length - 1].toLowerCase();
                            switch (ext) {
                                //if .jpg/.gif/.png do something
                                case 'jpg': case 'gif': case 'png': case 'bmp':
                                    {
                                        $("#importFileText").val(file.name);
                                        data.submit();
                                        break;
                                    }
                                    //if .zip/.rar do something else
                                default:
                                    var reqError = new Array();
                                    reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_ImageValidate });
                                    $('#importFileText').val("");
                                    $("html,body").scrollTop(0);
                                    $('#saveMessagePanel').messagesPanel({ messages: reqError });
                                    /* handle */
                                    break;
                            }

                        });

                    },
                    change: function (e, data) {
                    }
                });

            },
            // to display template details in readonly mode
            viewdeliverytemplateDetail: function (model) {
                navigateToPage('viewDeliveryTemplate', function () { });
                athoc.iws.deliverytemplate.breadcrumbModel.SelectedPage('viewDeliveryTemplate');
                $.titleCrumb("pageBreadcrumbs");
                // get details from controller
                $('#saveMessagePanel').html('');
                $("#viewDeliveryTemplate").hide();
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.deliverytemplate.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                var dlAjaxOption =
                    {
                        url: athoc.iws.deliverytemplate.urls.GetDeliveryTemplateDetailsUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify({ TemplateId: model.Template_Id }),
                        success: function (data) {
                            if (data.Success) {
                                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel = ko.mapping.fromJS(data.Data);
                                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.createdOn() != "")
                                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.createdOn($.getVPSLocalDateTime(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.createdOn(), $.getMomentDateTimeFormat(($.vpsTimeZone.dateTimeFormat))));
                                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.updatedOn() != "")
                                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.updatedOn($.getVPSLocalDateTime(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.updatedOn(), $.getMomentDateTimeFormat(($.vpsTimeZone.dateTimeFormat))));
                                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.deviceGroupName(model.Device_Group_Name);

                                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.DefaultSeverity(data.Data.DefaultSeverity);
                                athoc.iws.deliverytemplate.editModel.localizedSeverity(model.Severity);
                                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.Device_Group_Id = model.Device_Group_Id;

                                athoc.iws.deliverytemplate.editModel.selectedLocaleLanguage(athoc.iws.deliverytemplate.getLanguageName(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.LocaleCode()));

                                // assign format model values to individual dropdowns
                                athoc.iws.deliverytemplate.editModel.FontArray(data.formatModel.FontList);
                                athoc.iws.deliverytemplate.editModel.FontTypeArray(data.formatModel.FontTypeList);
                                athoc.iws.deliverytemplate.editModel.ImagePositionArray(data.formatModel.ImagePositionList);
                                athoc.iws.deliverytemplate.editModel.PopupLocationArray(data.formatModel.PopupPositionList);
                                athoc.iws.deliverytemplate.editModel.TimeArray(data.formatModel.DesktopTimeList);
                                athoc.iws.deliverytemplate.editModel.DisplayArray(data.formatModel.DisplayStyleList);
                                athoc.iws.deliverytemplate.editModel.EntranceMotionArray(data.formatModel.EntranceMotionStyleList);
                                athoc.iws.deliverytemplate.editModel.ExitMotionArray(data.formatModel.ExitMotionStyleList);
                                athoc.iws.deliverytemplate.editModel.SevArray(data.formatModel.SeverityList);

                                if (athoc.iws.deliverytemplate.editModel.localizedSeverity() != null)
                                    athoc.iws.deliverytemplate.editModel.localizedSeverity(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.SevArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.Severity(), 1));

                                // knock out binding
                                $("#viewDeliveryTemplate").find(".bootstrap-select").remove();
                                ko.cleanNode($("#viewDeliveryTemplate").get(0));
                                ko.applyBindings(athoc.iws.deliverytemplate.editModel, $("#viewDeliveryTemplate").get(0));
                                mode = 2;
                                athoc.iws.deliverytemplate.breadcrumbModel.updateTitle(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.name(), undefined, undefined, 'viewDeliveryTemplate');
                                athoc.iws.deliverytemplate.collapsePanel();
                                athoc.iws.deliverytemplate.updateMoreLess();
                                athoc.iws.deliverytemplate.setDropDownValues();


                                $("#btn_vpreview").removeAttr("disabled");

                                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.IsDesktopTemplate() || athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.IsEmailTemplate()) {
                                    if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.IsDesktopTemplate())
                                        athoc.iws.deliverytemplate.setNotifierTemplateSettings(mode);
                                    $("#btn_vpreview").show();
                                }
                                else
                                    $("#btn_vpreview").hide();

                            }
                            else {
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });


                            }
                            athoc.iws.deliverytemplate.IsRefered = false;
                            $.AjaxLoader.hideLoader();
                            $("#viewDeliveryTemplate").show();
                            $("html,body").scrollTop(0);
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.deliverytemplate.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;

            },
            setDropDownValues: function () {
                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyFont() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyFont(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyFont()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleFont() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleFont(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleFont()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnFont() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnFont(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnFont()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByFont() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByFont(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByFont()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyDisplay() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyDisplay(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.DisplayArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyDisplay()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleDisplay() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleDisplay(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.DisplayArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleDisplay()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnDisplay() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnDisplay(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.DisplayArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnDisplay()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByDisplay() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByDisplay(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.DisplayArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByDisplay()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyFontType() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyFontType(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontTypeArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyFontType()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleFontType() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleFontType(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontTypeArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleFontType()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnFontType() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnFontType(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontTypeArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnFontType()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByFontType() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByFontType(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontTypeArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByFontType()));
                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodySize() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodySize(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontSizeArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodySize()));
                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleSize() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleSize(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontSizeArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleSize()));
                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnSize() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnSize(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontSizeArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnSize()));
                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedBySize() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedBySize(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.FontSizeArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedBySize()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodySize() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodySize(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.BorderSizeArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodySize()));
                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.popupLocation() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.popupLocation(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.PopupLocationArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.popupLocation()));
                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.timeOutUnit() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.timeOutUnit(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.TimeArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.timeOutUnit()));

                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.motionOn() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.motionOn(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.EntranceMotionArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.motionOn()));
                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.motionOff() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.motionOff(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.ExitMotionArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.motionOff()));
                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imageDisplay() != null)
                    athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imageDisplayValue(athoc.iws.deliverytemplate.getDropdownvalue(athoc.iws.deliverytemplate.editModel.ImagePositionArray(), athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imageDisplay()));


            },
            // to initiate color pickers
            initiateColorPicker: function (data) {
                myCP = new dhtmlXColorPicker([
                { input: "ddlColorTitle", target_Value: "ddlColorTitle", color: data.titleColor },
				{ input: "ddlColorBody", target_Value: "ddlColorBody", color: data.bodyColor },
				{ input: "ddlColorPubBy", target_Value: "ddlColorPubBy", color: data.publishedByColor },
				{ input: "ddlColorPubOn", target_Value: "ddlColorPubOn", color: data.publishedOnColor },
                { input: "ddlBorderColor", target_Value: "ddlBorderColor", color: data.templateBorderColor },
                { input: "ddlBackgroundColor", target_Value: "ddlBackgroundColor", color: data.templateBackgroundColor }

                ]);

                myCP.attachEvent("onSelect", function (color, input) {
                    if (input.id == "ddlColorBody")
                        athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.bodyColor = color;
                    if (input.id == "ddlColorTitle") {
                        athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.titleColor = color;
                    }
                    if (input.id == "ddlColorPubOn")
                        athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedOnColor = color;

                    if (input.id == "ddlColorPubBy") {
                        athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.publishedByColor = color;

                    }

                    if (input.id == "ddlBorderColor")
                        athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateBorderColor = color;
                    if (input.id == "ddlBackgroundColor")
                        athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.templateBackgroundColor = color;

                });


            },
            // to perform validation on template data before save
            performEditDeliveryValidation: function (deliveryModel, deviceId) {
                var reqError = new Array();
                var focusField = null;
                var fullScreenYN = (deliveryModel.fullScreenYN() == "Y") ? true : false;
                var useAdvancedStyle = (deliveryModel.useAdvancedStyle() == "Y") ? true : false;
                // below validation rules are common for both Desktop Notifier and Device Template
                $('#saveMessagePanel').html('');
                if (!athoc.iws.deliverytemplate.isRequired(deliveryModel.name(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_TemplateName_Valid });
                    focusField = "#deliveryTemplateNameTxt";

                }

                if ((deliveryModel.name() != "") && ((deliveryModel.name() != null))) {
                    if (!athoc.iws.deliverytemplate.maxLength(deliveryModel.name(), 100)) {
                        reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Name_Max_Length });
                        if (focusField == null)
                            focusField = "#deliveryTemplateNameTxt";

                    }

                    if (!athoc.iws.deliverytemplate.pattern(deliveryModel.name(), "^[^*?,><:;\\\\[\\\]+=|\/\"]*$", "1")) {
                        reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Name_Special_Chars });
                        if (focusField == null)
                            focusField = "#deliveryTemplateNameTxt";

                    }
                }
                if (!athoc.iws.deliverytemplate.maxLength(deliveryModel.description(), 200)) {
                    reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Description_Max_length });
                    if (focusField == null)
                        focusField = "#deliveryTemplateDescriptionTxt";
                }

                //Common Name
                if (!athoc.iws.deliverytemplate.isRequired(deliveryModel.templateCommonName(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_CommonName_Required });
                    if (focusField == null)
                        focusField = "#TemplatedCommonNameTxt";
                }
                if (deliveryModel.templateCommonName() != "") {
                    if (!athoc.iws.deliverytemplate.maxLength(deliveryModel.templateCommonName(), 100)) {
                        reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_CommonName_Max_Length });
                        if (focusField == null)
                            focusField = "#TemplatedCommonNameTxt";

                    }
                }
                // end of common validation rules

                //if desktop notifier then perform other validations such as width, height, timeout
                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.IsDesktopTemplate()) {
                    if ((!fullScreenYN) && (!useAdvancedStyle)) {
                        //Width
                        if (!athoc.iws.deliverytemplate.isRequired(deliveryModel.width(), true)) {
                            reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Popup_Width_Required });
                            if (focusField == null)
                                focusField = "#txtPopupWidth";
                        }
                        if (deliveryModel.width() != "") {
                            if (!athoc.iws.deliverytemplate.pattern(deliveryModel.width(), "^[0-9]+$", "2")) {
                                reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Popup_Width_Max_Length });
                                if (focusField == null)
                                    focusField = "#txtPopupWidth";
                            }
                            if (athoc.iws.deliverytemplate.pattern(deliveryModel.width(), "^[0-9]+$", "2")) {
                                if (athoc.iws.deliverytemplate.widthVal(deliveryModel.width(), true)) {
                                    reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Popup_Width_Max_Length });
                                    if (focusField == null)
                                        focusField = "#txtPopupWidth";
                                }
                            }
                        }

                        //Height
                        if (!athoc.iws.deliverytemplate.isRequired(deliveryModel.height(), true)) {
                            reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Popup_Height_Required });
                            if (focusField == null)
                                focusField = "#txtPopupHeight";
                        }
                        if (deliveryModel.height() != "") {
                            if (!athoc.iws.deliverytemplate.pattern(deliveryModel.height(), "^[0-9]+$", "3")) {
                                reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Popup_Height_Max_Length });
                                if (focusField == null)
                                    focusField = "#txtPopupHeight";
                            }
                            if (athoc.iws.deliverytemplate.pattern(deliveryModel.height(), "^[0-9]+$", "3")) {
                                if (athoc.iws.deliverytemplate.heightVal(deliveryModel.height(), true)) {
                                    reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Popup_Height_Max_Length });
                                    if (focusField == null)
                                        focusField = "#txtPopupHeight";
                                }
                            }
                        }

                    }

                    //Timeout
                    if (!athoc.iws.deliverytemplate.isRequired(deliveryModel.timeOutValue(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Popup_Timeout_Required });
                        if (focusField == null)
                            focusField = "#txtPopupTimeout";
                    }
                    if (deliveryModel.timeOutValue() != "") {
                        if (!athoc.iws.deliverytemplate.pattern(deliveryModel.timeOutValue(), "^[0-9]+$", "4")) {
                            reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Popup_Timeout_Max_Length });
                            if (focusField == null)
                                focusField = "#txtPopupTimeout";
                        }
                        if (athoc.iws.deliverytemplate.pattern(deliveryModel.timeOutValue(), "^[0-9]+$", "4")) {
                            if (athoc.iws.deliverytemplate.timeoutVal(deliveryModel.timeOutValue(), true)) {
                                reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_Popup_Timeout_Max_Length });
                                if (focusField == null)
                                    focusField = "#txtPopupTimeout";
                            }
                        }
                    }



                }// desktop notiifer validation rules

                //XSLT
                if ((useAdvancedStyle) || (deliveryModel.IsDesktopTemplate()) || (deliveryModel.IsEmailTemplate())) {
                    if (!athoc.iws.deliverytemplate.validateXSLT(deliveryModel.templateDefinition(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.deliverytemplate.resources.DeliveryTemplate_XSLT_Valid });
                        if (focusField == null)
                            focusField = "#templateDataTxt";
                    }
                }

                //pop out the error message 
                if (reqError.length > 0) {
                    $('#saveMessagePanel').messagesPanel({ messages: reqError });
                    $(focusField).focus();
                    $("html,body").scrollTop(0);
                    return false;
                }
                return true;
            },
            isRequired: function (val, required) {
                var stringTrimRegEx = /^\s+|\s+$/g,
                 testVal;

                if ($.trim(val) === undefined || $.trim(val) === null) {
                    return !required;
                }

                testVal = $.trim(val);
                if (typeof ($.trim(val)) == "string") {
                    testVal = $.trim(val).replace(stringTrimRegEx, '');
                }

                return required && (testVal + '').length > 0;
            },
            maxLength: function (val, maxLength) {
                return athoc.iws.deliverytemplate.isEmptyVal(val) || $.trim(val).length <= maxLength;
            },
            isEmptyVal: function (val) {
                if ($.trim(val) == undefined) {
                    return true;
                }
                if ($.trim(val) == null) {
                    return true;
                }
                if ($.trim(val) == "") {
                    return true;
                }
            },
            pattern: function (val, regex, type) {
                var pattern = regex;
                var $opts = { "rule": "format", "format": { "pattern": regex } };

                if (typeof $opts.format.pattern === "string")
                    var pattern = (typeof $opts.format.pattern === "object") ? $opts.format.pattern : new RegExp($opts.format.pattern, "g");
                return pattern.test($.trim(val));

            },
            widthVal: function (val) {
                if (!athoc.iws.deliverytemplate.isEmptyVal(val)) {
                    val = parseInt(val);
                    if (val >= 1 && val <= 1000)
                        return false;
                    else
                        return true;
                }
            },
            heightVal: function (val) {
                if (!athoc.iws.deliverytemplate.isEmptyVal(val)) {
                    val = parseInt(val);
                    if (val >= 1 && val <= 700)
                        return false;
                    else
                        return true;
                }
            },
            timeoutVal: function (val) {

                if (!athoc.iws.deliverytemplate.isEmptyVal(val)) {
                    val = parseInt(val);
                    if (val >= 1 && val <= 9999)
                        return false;
                    else
                        return true;
                }
            },
            resetSearchCriteria: function () {
                athoc.iws.deliverytemplate.DeliveryTemplateCriteria.DeviceGroupId = athoc.iws.deliverytemplate.editModel.DeviceToFilter();
                athoc.iws.deliverytemplate.DeliveryTemplateCriteria.TemplateId = -1;
                athoc.iws.deliverytemplate.DeliveryTemplateCriteria.SearchString = "";
                athoc.iws.deliverytemplate.DeliveryTemplateCriteria.DefaultTemplateOnly = false;
                athoc.iws.deliverytemplate.editModel.checkedtemplatecount(0);
            },
            // to display template details in readonly mode
            getDeviceStylesheet: function (deviceType) {
                navigateToPage('editDeliveryTemplate', function () { });
                athoc.iws.deliverytemplate.breadcrumbModel.SelectedPage('editDeliveryTemplate');
                $.titleCrumb("pageBreadcrumbs");
                $('#deliveryTemplateNameTxt').focus();
                athoc.iws.deliverytemplate.breadcrumbModel.updateTitle(athoc.iws.deliverytemplate.resources.DeliveryTemplate_NewTemplate, undefined, undefined, 'editDeliveryTemplate');
                $("#editDeliveryTemplate").hide();
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.deliverytemplate.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.deliverytemplate.resources.General_LoadingMessage }).showLoader();
                mode = 3;
                $('#saveMessagePanel').html('');

                var jsonData = ko.toJSON({ DeviceId: deviceType });
                var dlAjaxOption =
                    {
                        url: athoc.iws.deliverytemplate.urls.getDeviceStylesheetURL,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            if (data.Success) {
                                athoc.iws.deliverytemplate.isChanged = false;
                                athoc.iws.deliverytemplate.editModel.EditMode(false);
                                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel = ko.mapping.fromJS(data.Data);
                                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.deviceGroupName(athoc.iws.deliverytemplate.getDeviceGroupValue(athoc.iws.deliverytemplate.editModel.AllDeviceArray(), deviceType));

                                // assign format model values to individual dropdowns
                                athoc.iws.deliverytemplate.editModel.FontArray(data.formatModel.FontList);
                                athoc.iws.deliverytemplate.editModel.FontTypeArray(data.formatModel.FontTypeList);
                                athoc.iws.deliverytemplate.editModel.ImagePositionArray(data.formatModel.ImagePositionList);
                                athoc.iws.deliverytemplate.editModel.PopupLocationArray(data.formatModel.PopupPositionList);
                                athoc.iws.deliverytemplate.editModel.TimeArray(data.formatModel.DesktopTimeList);
                                athoc.iws.deliverytemplate.editModel.DisplayArray(data.formatModel.DisplayStyleList);
                                athoc.iws.deliverytemplate.editModel.EntranceMotionArray(data.formatModel.EntranceMotionStyleList);
                                athoc.iws.deliverytemplate.editModel.ExitMotionArray(data.formatModel.ExitMotionStyleList);
                                athoc.iws.deliverytemplate.editModel.SevArray(data.formatModel.SeverityList);
                                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.Severity("Unknown");

                                athoc.iws.deliverytemplate.editModel.langSupports(data.languages);
                                // athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.DefaultSeverity() ? $("#chkDefaultSev")[0].checked = true : false;
                                // apply knock binding 
                                $("#editDeliveryTemplate").find(".bootstrap-select").remove();
                                ko.cleanNode($("#editDeliveryTemplate").get(0));
                                ko.applyBindings(athoc.iws.deliverytemplate.editModel, $("#editDeliveryTemplate").get(0));
                                athoc.iws.deliverytemplate.collapsePanel();
                                athoc.iws.deliverytemplate.updateMoreLess();
                                athoc.iws.deliverytemplate.editSubscribeMethods();
                                athoc.iws.deliverytemplate.initiateSelectPicker();
                                athoc.iws.deliverytemplate.setNotifierTemplateSettings(mode);
                                //register FileUpload
                                if (fileData != null) {
                                    fileData = null;

                                }
                                athoc.iws.deliverytemplate.registerFileUpload();
                                $("#btn_preview").removeAttr("disabled");
                                athoc.iws.deliverytemplate.isChanged = false;



                                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.IsDesktopTemplate() || athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.IsEmailTemplate()) {
                                    $("#btn_preview").show();
                                }
                                else
                                    $("#btn_preview").hide();


                            }
                            $.AjaxLoader.hideLoader();
                            $("#editDeliveryTemplate").show();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.deliverytemplate.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
                return true;

            },
            // saves template data in the database
            saveDeviceTemplatedata: function () {

                $('#saveMessagePanel').html('');

                if (!athoc.iws.deliverytemplate.performEditDeliveryValidation(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel))
                    return false;

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.deliverytemplate.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imagePath($('#importFileText').val());


                athoc.iws.deliverytemplate.IsRefered = false;
                var jsonData = ko.toJSON(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel);
                var dlAjaxOption =
                    {
                        url: athoc.iws.deliverytemplate.urls.SaveDeviceTemplateUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {

                            if (data.Success) {
                                navigateToPage('listDeliveryTemplate', function () { });
                                athoc.iws.deliverytemplate.breadcrumbModel.SelectedPage('listDeliveryTemplate');
                                athoc.iws.deliverytemplate.isChanged = false;
                                $.titleCrumb("pageBreadcrumbs");
                                $.AjaxLoader.hideLoader();
                                // athoc.iws.deliverytemplate.resetSearchCriteria();
                                athoc.iws.deliverytemplate.refreshGrid();
                                // athoc.iws.deliverytemplate.clearFilters();
                                athoc.iws.deliverytemplate.listLoad();
                            }
                            else if (data.HasErrors) {
                                $.AjaxLoader.hideLoader();
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                                if (data.ReturnType == 1)
                                    $("#deliveryTemplateNameTxt").focus();
                                else if (data.ReturnType == 2)
                                    $("#TemplatedCommonNameTxt").focus();
                                else if (data.ReturnType == 3)
                                    $("#templateDataTxt").focus();
                            }
                            else {
                                $.AjaxLoader.hideLoader();
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }

                        },
                        error: function (e) {
                            athoc.iws.deliverytemplate.handleError(e);
                        }
                    };


                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },
            listLoad: function () {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
            },
            createdeliverytemplateListGrid: function () {

                var self = this;
                var url = athoc.iws.deliverytemplate.urls.GetDeliveryTemplatesUrl;
                var jsonData = JSON.stringify(athoc.iws.deliverytemplate.DeliveryTemplateCriteria);
                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            data: JSON.stringify(jsonData),
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.deliverytemplate.DeliveryTemplateCriteria);
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                    },
                    requestEnd: function (e) {

                        if (e.response) {
                            athoc.iws.deliverytemplate.ListModel.set("TotalCount", e.response.TotalCount);
                            //clear selected
                            athoc.iws.deliverytemplate.ListModel.set("SelectedCount", 0);

                            if (athoc.iws.deliverytemplate.TemplateFilter.length == 0) {
                                athoc.iws.deliverytemplate.TemplateFilter = e.response.DeviceGroups;
                                athoc.iws.deliverytemplate.fillDeviceDropdown(e.response.DeviceGroups);
                                athoc.iws.deliverytemplate.LanguageListHierarchy = e.response.languages;
                                athoc.iws.deliverytemplate.Languages = e.response.languages;

                                athoc.iws.deliverytemplate.Severity = e.response.Serverity;
                                //DeviceGroups
                                athoc.iws.deliverytemplate.IsEnterprises = e.response.IsEnterprises;
                                athoc.iws.deliverytemplate.IsSysAdmin = e.response.IsSysAdmin;
                                athoc.iws.deliverytemplate.IsVirtualSysAdmin = e.response.IsVirtualSysAdmin;

                                athoc.iws.deliverytemplate.ContextProvider = e.response.ContextProvider;


                            }
                            $('#chkSelectAll').attr("checked", false);
                            $.AjaxLoader.hideLoader();
                        }
                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                    },
                    sort: { field: "Name", dir: "asc" },
                    pageSize: 50,


                    error: function (e) {
                        athoc.iws.deliverytemplate.handleError(e);
                    },
                    change: function (e) {
                        athoc.iws.deliverytemplate.enableSelectAll();
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            //when sort changes, go to first page.
                            this.page(1);
                        }
                        //scrolling to the top when paging and sorting.
                        $("html,body").scrollTop(0);
                    }



                });

                $("#pageInfo").kendoPager({
                    dataSource: datasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.deliverytemplate.resources.DeliveryTemplate_List_PageInfo,
                        empty: athoc.iws.deliverytemplate.resources.AtHoc_Pager_Message_Empty
                    }
                });

                var grid = $("#deliveryTemplateList").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    top: 130,
                    selectable: false,
                    resizable: true,
                    sortable: {
                        allowUnsort: false
                    },


                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5, messages: {
                            display: athoc.iws.deliverytemplate.resources.AtHoc_Pager_Message_Summary,
                            itemsPerPage: athoc.iws.deliverytemplate.resources.AtHoc_Pager_Message_Items_Per_Page,
                            empty: athoc.iws.deliverytemplate.resources.IWS_Common_NoRecordsFound,

                            first: $.htmlDecode(athoc.iws.deliverytemplate.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.deliverytemplate.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.deliverytemplate.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.deliverytemplate.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                {

                                    field: "IsChecked",
                                    template: $("#deliverytemplate-chkDelete-template").html(),
                                    width: 25,
                                    title: "",
                                    headerTemplate: kendo.format('<input type="checkbox" class="senario-select" id="chkSelectAll" title="{0}" onclick="athoc.iws.deliverytemplate.deliverySelectAll();" />', athoc.iws.deliverytemplate.resources.DeliveryTemplate_Select_Current_Page),
                                    sortable: false,
                                    headerAttributes: {
                                        style: "cursor: default",
                                    }
                                },
                                 {
                                     field: "Name",
                                     title: "",
                                     template: '#=$.htmlEncode(Name)#',
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}">{1}</span>', athoc.iws.deliverytemplate.resources.DeliveryTemplate_Name_Title, athoc.iws.deliverytemplate.resources.DeliveryTemplate_Name),
                                     width: 260,
                                     headerAttributes: {
                                         tabindex: "240"
                                     }
                                 },
                                 {
                                     field: "Severity",
                                     title: "",
                                     template: '#= athoc.iws.deliverytemplate.getSeverityName(Severity) #',
                                     headerTemplate: kendo.format('<span title="{0}">{1}</span>', athoc.iws.deliverytemplate.resources.DeliveryTemplate_Severity, athoc.iws.deliverytemplate.resources.DeliveryTemplate_Severity),
                                     width: 90,
                                     headerAttributes: {
                                         tabindex: "240"
                                     }
                                 },
                                {
                                    field: "Device_Group_Name",
                                    title: "",
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', athoc.iws.deliverytemplate.resources.DeliveryTemplate_Device_Title, athoc.iws.deliverytemplate.resources.DeliveryTemplate_Device),
                                    template: "#= Device_Group_Name #",
                                    width: 100,
                                    headerAttributes: {
                                        tabindex: "240"
                                    }
                                },
                                {
                                    field: "Scope",
                                    title: "",
                                    template: '<span  title="#=$.htmlEncode(Scope)#">#=$.htmlEncode(Scope)#</span>',
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', athoc.iws.deliverytemplate.resources.DeliveryTemplate_Scope_Title, athoc.iws.deliverytemplate.resources.DeliveryTemplate_Scope),
                                    width: 100,
                                    headerAttributes: {
                                        tabindex: "240"
                                    }
                                },
                                 {
                                     field: "Locale_Code",
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.deliverytemplate.resources.DeliveryTemplate_Language, athoc.iws.deliverytemplate.resources.DeliveryTemplate_Language),
                                     template: "#= athoc.iws.deliverytemplate.getLanguageName(Locale_Code) #",
                                     width: 120,
                                 }
                            ],
                    dataBound: athoc.iws.deliverytemplate.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());



                    }
                }).data().kendoGrid;


                var lastMouseX;
                var $template = kendo.template($("#name-tooltip-template").html());

                var deliveryTemplateTooltip = $("#deliveryTemplateList").kendoTooltip({
                    filter: "td:nth-child(2)", //this filter selects the first column cells 
                    position: "right",
                    show: function() {
                        $(this.popup.wrapper).css({
                            left: lastMouseX + 60
                        });
                    },
                    content: function (e) {
                        e.sender.content.parent().addClass('delivery-templ-tooltip');
                        var dataItem = $("#deliveryTemplateList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    }
                }).on('mouseout', function (e) {                
                    deliveryTemplateTooltip.data('kendoTooltip').hide();
                });

                tooltip = deliveryTemplateTooltip.data("kendoTooltip");

                $(document).on("mousemove", function (e) {
                    lastMouseX = e.pageX;
                    $(".delivery-templ-tooltip").parent().css({
                        left: lastMouseX + 60
                    });
                });              

                // ko.cleanNode($("#dvSearch").get(0));
                ko.applyBindings(athoc.iws.deliverytemplate.editModel, $("#dvSearch").get(0));

                this.refreshGrid();

            },
            refreshGrid: function () {
                //show the loader when we make a request to the server..
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.wrap-all'), imageURL: athoc.iws.deliverytemplate.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: this.resources.General_LoadingMessage }).showLoader();
                //Per telerik, this will set the page only after datasource refreshes.
                datasource.one("change", function () {
                    //pagination needs to be reset after a reload
                    this.page(1);
                });
                datasource.read();


            },
            errors: null,
            //Method to handle erro and session time out, this is boud with Ajax calls
            handleError: function (e) {

                if ((e != undefined && e.status == 401) || (e != undefined && e.xhr != undefined && e.xhr.status == 401)) {
                    window.onbeforeunload = null;
                    window.location = window.location;

                } else if (e.errorThrown != "") {
                    if (athoc.iws.deliverytemplate.errors === null) {
                        athoc.iws.deliverytemplate.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.deliverytemplate.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#saveMessagePanel').messagesPanel({ messages: this.errors });
                }
            },

            //On Grid databound navigate to Edit page or View page w.r.t device Type
            OnDataBound: function () {

                $("#deliveryTemplateList tbody").find("tr").attr("tabindex", "0");
                var grid = $("#deliveryTemplateList").data("kendoGrid");
                var data = grid.dataSource.data();



                $(grid.tbody).on("click", "td", function (e) {

                    var row = $(this).closest("tr");
                    var rowIdx = $("tr", grid.tbody).index(row);
                    var colIdx = $("td", row).index(this);

                    var colIdx = $("td", row).index(this);



                    if (athoc.iws.deliverytemplate.IsRefered == false && colIdx >= 0) {

                        if ((colIdx == 0 && e.target.className == "") || colIdx > 0) {
                            data = grid.dataSource.view();
                            var model = data[rowIdx];
                            athoc.iws.deliverytemplate.IsRefered = true;

                            tooltip.hide();

                            if (athoc.iws.deliverytemplate.ContextProvider == model.Provider_Id) {
                                if (athoc.iws.deliverytemplate.IsSysAdmin || athoc.iws.deliverytemplate.IsEnterprises || athoc.iws.deliverytemplate.IsVirtualSysAdmin || model.IsOwner)
                                    athoc.iws.deliverytemplate.editdeliverytemplateDetail(model);
                                else
                                    athoc.iws.deliverytemplate.viewdeliverytemplateDetail(model);
                            }
                            else
                                athoc.iws.deliverytemplate.viewdeliverytemplateDetail(model);
                        }
                    }
                });
                //On Grid row key press navigate to Edit page or View page w.r.t device Type
                $(grid.tbody).on("keypress", "tr", function (e) {

                    var code = e.keyCode || e.which;

                    if (code == 13 && athoc.iws.deliverytemplate.IsRefered == false) {
                        athoc.iws.deliverytemplate.IsRefered = true;
                        var row = $(this);
                        var rowIdx = $("tr", grid.tbody).index(row);
                        data = grid.dataSource.data();
                        var model = data[rowIdx];
                        tooltip.hide();

                        if (athoc.iws.deliverytemplate.ContextProvider == model.ProviderId) {
                            if (athoc.iws.deliverytemplate.IsSysAdmin || athoc.iws.deliverytemplate.IsEnterprises || athoc.iws.deliverytemplate.IsVirtualSysAdmin || model.IsOwner)
                                athoc.iws.deliverytemplate.editdeliverytemplateDetail(model);
                            else
                                athoc.iws.deliverytemplate.viewdeliverytemplateDetail(model);
                        }
                        else
                            athoc.iws.deliverytemplate.viewdeliverytemplateDetail(model);

                    }
                });

                grid.tbody.on("change", ".deliverytemplate-select", function (e) {
                    var row = $(e.target).closest("tr");
                    var item = grid.dataItem(row);
                    item.IsChecked = $(e.target).is(":checked");
                    athoc.iws.deliverytemplate.enableSelectAll();
                    athoc.iws.deliverytemplate.updateSelectedTotal();
                });

                if (athoc.iws.deliverytemplate.IsRightToLeft) {
                    $("#deliveryTemplateList").find('.pull-right').addClass('pull-left');
                    $("#deliveryTemplateList").find('.pull-right').removeClass('pull-right');
                }

                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(grid.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">' + athoc.iws.deliverytemplate.resources.IWS_Common_NoRecordsFound + '</td></tr>');
                }
            },

            getSeverityName: function (severity) {
                var serverity = _.find(athoc.iws.deliverytemplate.Severity, function (item) {
                    if (item.SeverityId.toUpperCase() == severity.toUpperCase())
                        return item;
                });
                return (serverity != undefined ? serverity.SeverityName : '');
            },
            getDefaultTemplateName: function (Name, Default) {
                return Default == "Y" ? Name + " (Default)" : Name;
            },

            getGroupName: function (deviceGroupId) {

                var deviceSettings = _.find(athoc.iws.deliverytemplate.TemplateFilter, function (item) {
                    if (item.DeviceGroupId == deviceGroupId)
                        return item;
                });
                return (deviceSettings != undefined ? deviceSettings.DeviceGroupName : '');
            },
            getLanguageName: function (defaultLocale, languageList) {
                defaultLocale = (defaultLocale == null) ? athoc.iws.deliverytemplate.resources.Settings_Default_Locale : defaultLocale;

                var languageSettings = _.find(athoc.iws.deliverytemplate.Languages, function (item) {
                    if (item.LocalCode != undefined && item.LocalCode.toUpperCase() == defaultLocale.toUpperCase())
                        return item;
                });
                return (languageSettings != undefined ? languageSettings.LanguageName : '');
            },
            getSelectedItems: function () {
                ids = new Array();
                var grid = $("#deliveryTemplateList").data("kendoGrid");

                $.each(grid.dataSource.view(), function (i, item) {

                    if (item.IsChecked)
                        ids.push(item);
                });

            },
            deliverySelectAll: function (obj) {

                var checked = $('#chkSelectAll').is(':checked');
                var grid = $('#deliveryTemplateList').data().kendoGrid;
                if (!checked)
                    ids = new Array();

                $.each(grid.dataSource.view(), function (i, item) {
                    item.IsChecked = checked;
                });

                $('#deliveryTemplateList').data().kendoGrid.refresh();
                athoc.iws.deliverytemplate.updateSelectedTotal();

            },
            updateSelectedTotal: function () {


                var items = datasource.data();
                var r = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                athoc.iws.deliverytemplate.editModel.checkedtemplatecount(r.length);

                if (r.length > 0) {
                    $("#btn_delete").removeAttr('disabled');
                    $("#btn_duplicate").removeAttr('disabled');
                }
                else {
                    $("#btn_delete").attr('disabled', 'disabled');
                    $("#btn_duplicate").attr('disabled', 'disabled');
                }
            },
            enableSelectAll: function () {
                var items = datasource.view();
                //get the selected items for the current page.
                var r = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                $("#chkSelectAll").prop('checked', false);
                if (r.length > 0 && (items.length == r.length))
                    $("#chkSelectAll").prop('checked', true);
            },
            showDesktopTemplatePreview: function () {

                $('#saveMessagePanel').html('');
                // Validate delivery template data
                if (!athoc.iws.deliverytemplate.performEditDeliveryValidation(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel))
                    return false;
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.deliverytemplate.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                var result = ko.validation.group(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages(true);

                    $.AjaxLoader.hideLoader();
                    return false;
                }
                athoc.iws.deliverytemplate.IsRefered = false;
                var IsEmailTemplate = athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.IsEmailTemplate();
                var jsonData = ko.toJSON(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel);
				
				if (myWindow != null)
					myWindow.close();

				var width = screen.availWidth;
				var height = screen.availHeight;
				var top = 0;
				var left = 0;

				if ((athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.useAdvancedStyle() == "N") && (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.fullScreenYN() != "Y")) {
					width = athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.width();
					height = parseInt(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.height());
					top = 450;
					left = 450;
				}
				if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.useAdvancedStyle() == "Y") {
					width = IsEmailTemplate ? 530 : 458;
					height = IsEmailTemplate ? 499 : 461;
					top = IsEmailTemplate ? 100 : 450;
					left = 450;
				}
				
				//on safari, window.open doesn't work inside async call
				if (athoc.iws.utilities.isSafari())
				{
					myWindow = window.open("", "DesktopPreview", 'top=' + top + ',left=' + left + ',width=' + width + ',height=' + height + ',location=no,toolbar=no,menubar=no,addressbar=0,titlebar=no,scrollbars=yes,resizable=yes');
	
				}
				
                var dlAjaxOption =
                    {
                        url: IsEmailTemplate ? athoc.iws.deliverytemplate.urls.EmailTemplatePreviewUrl : athoc.iws.deliverytemplate.urls.DesktopTemplatePreviewUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            if (data.Success) {

								if (!athoc.iws.utilities.isSafari())
								{	
									myWindow = window.open("", "DesktopPreview", 'top=' + top + ',left=' + left + ',width=' + width + ',height=' + height + ',location=no,toolbar=no,menubar=no,addressbar=0,titlebar=no,scrollbars=yes,resizable=yes');
								}
								
                                myWindow.window.document.write(data.data);
                                myWindow.window.focus();

                            } else {

                                $('#saveMessagePanel').css("display:none");
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }

                            $.AjaxLoader.hideLoader();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.deliverytemplate.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
                return true;

            },


            validateXSLT: function (val) {
                var status = false;
                if (val != null) {

                    try {
                        var xmlDoc = $.parseXML(val);
                        if (xmlDoc != null)
                            status = true;
                        else
                            status = false;
                    } catch (exception)
                    { status = false; }
                }
                return status;
            },
            //show more less for header
            updateMoreLess: function () {
                $('.moretext').each(function () {

                    if ($(this).find(".morecontent").length == 0) {
                        var showChar = 100;
                        var ellipsestext = "...";
                        var moretext = "more";
                        var content = $(this).html();

                        if (content.length > showChar) {

                            var c = content.substr(0, showChar);
                            var h = content.substr(showChar, content.length - showChar);

                            var html = c + '<span class="moreelipses">' + ellipsestext + '</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';

                            $(this).html(html);
                        }
                    }
                });

                $('.morelink').unbind('click');

                $(".morelink").click(function () {
                    var moretext = "more";
                    var lesstext = "less";
                    if ($(this).hasClass("less")) {
                        $(this).removeClass("less");
                        $(this).html(moretext);
                    } else {
                        $(this).addClass("less");
                        $(this).html(lesstext);
                    }
                    $(this).parent().prev().toggle();
                    $(this).prev().toggle();
                    return false;
                });
            }
            ,

            saveNewDeviceTemplatedata: function () {

                $('#saveMessagePanel').html('');

                if (!athoc.iws.deliverytemplate.performEditDeliveryValidation(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel))
                    return false;

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.deliverytemplate.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();

                athoc.iws.deliverytemplate.IsRefered = false;
                athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.imagePath($("#importFileText").val());

                var jsonData = ko.toJSON(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel);

                var dlAjaxOption =
                    {
                        url: athoc.iws.deliverytemplate.urls.SaveNewDeviceTemplateUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {

                            if (data.Success) {
                                navigateToPage('listDeliveryTemplate', function () { });
                                athoc.iws.deliverytemplate.isChanged = false;
                                athoc.iws.deliverytemplate.breadcrumbModel.SelectedPage('listDeliveryTemplate');
                                $.titleCrumb("pageBreadcrumbs");
                                $.AjaxLoader.hideLoader();
                                athoc.iws.deliverytemplate.resetSearchCriteria();
                                athoc.iws.deliverytemplate.refreshGrid();
                                athoc.iws.deliverytemplate.clearFilters();
                                athoc.iws.deliverytemplate.listLoad();
                            }
                            else if (data.HasErrors) {
                                $.AjaxLoader.hideLoader();
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                                if (data.ReturnType == 1)
                                    $("#deliveryTemplateNameTxt").focus();
                                else if (data.ReturnType == 2)
                                    $("#TemplatedCommonNameTxt").focus();
                                else if (data.ReturnType == 3)
                                    $("#templateDataTxt").focus();
                            }
                            else {
                                $.AjaxLoader.hideLoader();
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }

                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.deliverytemplate.handleError(e);
                        }
                    };


                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },

            // To validate Audio File before save/edit
            getValidation: function (flag) {
                //remove old validation
                $(".warning").each(function () {
                    $(this).parent().remove();
                });

                var validationMapping = {
                    name: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: true,
                                maxLength: 100,
                                pattern: {
                                    message: 'The following characters are not allowed in name \\ / : * ? " < > | [ ]',
                                    params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$"
                                }
                            });
                        }
                    },


                };

                return validationMapping;
            },
            //To give confirmation if already default severity exits for that desktop group
            CheckDefaultSeverityforTemplate: function (flag) {

                // athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.DefaultSeverity(($("#chkDefaultSev")[0].checked) ? true : false);
                if (athoc.iws.deliverytemplate.editModel.deliverytemplatemodel.DefaultSeverity() && flag) {

                    if (athoc.iws.deliverytemplate.CheckSeverityExists(athoc.iws.deliverytemplate.editModel.deliverytemplatemodel) > 0) {

                        $("#dialogDefaultSeverityConfirm").modal('show');
                        $("#DefSeverityText").text(athoc.iws.deliverytemplate.resources.DeliveryTemplate_Severity_Confirmation_Message);
                        $('#dialogDefaultSeverityConfirm').modal({
                            keyboard: true
                        }).promise().done(function () {
                            setTimeout(function () {
                                $("#btnSeverityCancel").attr("tabindex", 15).focus();
                            }, 1000);
                        });

                    }
                }
            },
            //To check whether default severity exists
            CheckSeverityExists: function (obj) {
                var severityTemplateId = _.find(obj.TemplateDefaultSeverities(), function (item) {
                    if ($.trim(obj.Severity()).toUpperCase() == item.Severity().toUpperCase() && obj.LocaleCode() == item.LocaleCode() && item.TemplateId() != obj.templateId())
                        return item;
                }
                );
                return (severityTemplateId != undefined && severityTemplateId.TemplateId() != undefined) ? severityTemplateId.TemplateId() : 0;
            },

        };
    }();
}