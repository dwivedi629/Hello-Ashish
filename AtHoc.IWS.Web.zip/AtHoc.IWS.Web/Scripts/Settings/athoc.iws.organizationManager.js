﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.organizationManager = athoc.iws.organizationManager || {};

if (athoc.iws.organizationManager) {
    var ids = new Array();
    var selectedItems;
    var tooltip;
    var organizationDatasource = null;

    //Root class of this functionality
    athoc.iws.organizationManager = function () {
        var errorTitleStrings = new Array();
        var sortState;
        return {
            // Scoped variables
            isRelease: true,
            isChanged: false,
            searchMaxLength: 100,
            //Please don't pick this text from resource file. This is not read only
            pageName_Dup: "orgDuplicate",
            pageName_New: "orgNew",
            pageName_View: "orgView",
            pageName_Search: "dvOrgMngSearch",
            pageName_OrgMain: "organizationList",
            searchinput: "searchinput",
            LanguageName: ko.observable(),
            Languages: [],
            // ViewModel for this page
            viewModel: {
                selectedorganization: {}, //To keep selected OrgId
                searchString: ko.observable(),
                SearchDisabled: ko.observable(false),
                langSupports: ko.observableArray(),
                searchorganizations: function () {
                    athoc.iws.organizationManager.search();
                },// For Pill
                htmlPillContent: ko.observable(''),
                clearFilter: function () {
                    athoc.iws.organizationManager.clearFilters();
                },
                selectedOprator: ko.observable(0),
                operatorInfo: ko.observableArray([]),
                searchByEnter: function (data, event) {
                    athoc.iws.organizationManager.searchByEnter(data, event);
                },//To search
                searchBlur: function (data, event) {
                    if (athoc.iws.organizationManager.viewModel.searchString && athoc.iws.organizationManager.viewModel.searchString() != null && athoc.iws.organizationManager.viewModel.searchString().trim() != '')
                        athoc.iws.organizationManager.viewModel.SearchDisabled(false);
                    else
                        athoc.iws.organizationManager.viewModel.SearchDisabled(true);
                },
                loginVpsType: ko.observable(0),
                loginVpsTypeId: ko.observable(0),
                //To keep Org Record and bind with controls
                organizationCriteria: {
                    SearchString: [],
                    ProviderId: ko.observable(0),
                    OperatorId: ko.observable(0),
                    OrgStatus: ko.observable('All'),
                    OrgName: ko.observable(),
                    OrgType: ko.observable(),
                    IsEnterprise: ko.observable(false),
                    EnterpriseProviderId: ko.observable(0),
                    ProviderLocale: ko.observable(""),
                    IsDuplicate: ko.observable(false),
                },


                OrgType: ko.observableArray(),
                // To open save popup
                saveorganizationDetailsInfo: function () {
                    athoc.iws.organizationManager.saveorganizationDetails('n');
                },
                // To open Duplicate popup
                saveDuplicateOrganizationDetails: function () {
                    athoc.iws.organizationManager.saveorganizationDetails('d');

                },

                isEditMode: ko.observable(false),
                // cancel save
                cancelSave: function () {
                    athoc.iws.organizationManager.cancelSaving();
                },
                //Cancel duplicate button
                cancelSaveDuplicate: function () {
                    athoc.iws.organizationManager.cancelSaveDuplicate();
                },

                // Save New Org Details on popup button
                saveNewOrganizationDetails: function () {
                    athoc.iws.organizationManager.isChanged = false;
                    athoc.iws.organizationManager.saveNewOrganizationDetailsData(athoc.iws.organizationManager.pageName_New);

                },
                // Save New Org Details on duplicate button
                createDuplicateOrg: function () {
                    athoc.iws.organizationManager.isChanged = false;
                    athoc.iws.organizationManager.saveNewOrganizationDetailsData(athoc.iws.organizationManager.pageName_Dup);
                },
            },
            //Read Only, Donot change
            enumVpsTypes: {

                System: "system",
                Enterprise: "enterprise",
                Enterprisetemplate: "enterprisetemplate",
                Basic: "basic",
                SubEnterprise: "subenterprise",
                VpsTypeIds: {
                    System: 3,
                    Basic: 6,
                    Enterprise: 5
                },
                OrgType: { TPL_ENT: "TPL_ENT", TPL_BAS: "TPL_BAS" }
            },
            //For kendo grid
            ListModel: kendo.observable(
                {
                    TotalCount: 0,
                    SelectedCount: 0,
                }),

            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for scenario list, will be triggered before document load
            init: function () {
                athoc.iws.organizationManager.isRelease = true;
                athoc.iws.organizationManager.initBreadcrumb();
                String.prototype.format = function () {
                    var args = arguments;
                    return this.replace(/\{\{|\}\}|\{(\d+)\}/g, function (curlyBrack, index) {
                        return ((curlyBrack == "{{") ? "{" : ((curlyBrack == "}}") ? "}" : args[index]));
                    });
                };

            },


            //load method, will be tirggered on document load
            load: function () {
                //To fill the Message popup title strings from resource 
                errorTitleStrings.push(athoc.iws.organizationManager.resources.AtHoc_CommonErrMsg_Title_Information);
                errorTitleStrings.push(athoc.iws.organizationManager.resources.AtHoc_CommonErrMsg_Title_Warning);
                errorTitleStrings.push(athoc.iws.organizationManager.resources.AtHoc_CommonErrMsg_Title_Error);
                errorTitleStrings.push(athoc.iws.organizationManager.resources.AtHoc_CommonErrMsg_Title_Success);
                errorTitleStrings.push(athoc.iws.organizationManager.resources.AtHoc_CommonErrMsg_Title_Completed);

                // bind Breadcrumb 
                athoc.iws.organizationManager.bindBreadcrumb();

                // Load kendo grid
                athoc.iws.organizationManager.bindorganizationList();

                kendo.bind($(".kendoBound"), this.ListModel);
                //Fix the grid header
                var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
                if (gridHeader) {
                    gridHeader.addClass('table-header affix');
                }
                // Rfefreshing this variable
                athoc.iws.organizationManager.viewModel.selectedorganization = {};
                //
                athoc.iws.organizationManager.listLoad();
                //
                athoc.iws.organizationManager.viewModel.SearchDisabled(true);
                //
                athoc.iws.organizationManager.validateControls();

                // Binding message div
                ko.cleanNode($('#showGenericMessage').get(0));
                ko.applyBindings(athoc.iws.organizationManager.warningMsg, $('#showGenericMessage').get(0));

                //Binding search page
                ko.cleanNode($("#" + athoc.iws.organizationManager.pageName_Search).get(0));
                ko.applyBindings(athoc.iws.organizationManager.viewModel, $("#" + athoc.iws.organizationManager.pageName_Search).get(0));

                //binding new popup page
                ko.cleanNode($("#" + athoc.iws.organizationManager.pageName_New).get(0));
                ko.applyBindings(athoc.iws.organizationManager.viewModel, $("#" + athoc.iws.organizationManager.pageName_New).get(0));

                //Binding duplicate popup
                ko.cleanNode($("#" + athoc.iws.organizationManager.pageName_Dup).get(0));
                ko.applyBindings(athoc.iws.organizationManager.viewModel, $("#" + athoc.iws.organizationManager.pageName_Dup).get(0));
                //initiablizing the bootraper dropdown
                $('#ddlOrgType').selectpicker({});
                $('#ddlOprators').selectpicker({});
                $("#ddlLocale").selectpicker({});

                $("#btnCrossTenant").click(function (event) {
                    $("#unAuthUser").hide();
                    $(".kgrid-fix-top").attr('style', "top:261px!important;");
                    $(".k-grid-header").attr('style', "top:230px!important;");
                    $(".table-crown-center").attr('style', "top:10px!important;");
                });
            },

            // Search functionality on keyboard enter 
            searchByEnter: function (data, event) {
                if (event != undefined) {
                    if (athoc.iws.organizationManager.viewModel.searchString)
                        athoc.iws.organizationManager.viewModel.SearchDisabled(false);
                    if ($.hotkeys.enter(event)) {
                        athoc.iws.organizationManager.search();
                    }
                }
            },


            //For warning message
            warningMsg: {
                Message: ko.observable(),
                HeaderText: ko.observable(),
                ClosePopup: function () {
                    $('#showGenericMessage').modal('hide');
                },
            },

            // To toggle collapse panel
            collapsePanel: function () {
                $(this).parent().find('.expand-arrow-open').toggle();
                $('.bucket-toggle h2').click(function () {
                    $(this).parent().find('.row').slideToggle(500);
                    $(this).parent().find('.expand-arrow-open').toggle();
                    $(this).parent().find('.expand-arrow-closed').toggle();
                });
            },

            // clear the controls on list page
            clearFiltersForPopup: function () {
                athoc.iws.organizationManager.viewModel.selectedOprator(0);
                $('#ddlOprators').val([]);
                $('#ddlOprators').selectpicker('refresh');
                $("#ddlLocale").selectpicker('refresh');
            },

            // Triggered, when clear all link is clicked, it clear the searchCriteria and reload the grid
            clearFilters: function () {
                $('#saveGroupMessagePanel').html('');
                athoc.iws.organizationManager.viewModel.htmlPillContent('');
                $("#" + athoc.iws.organizationManager.pageName_OrgMain + " .k-grid-header").css("margin-top", "0px");
                $("#" + athoc.iws.organizationManager.pageName_OrgMain + "").css("margin-top", "0px");
                athoc.iws.organizationManager.viewModel.searchString("");
                athoc.iws.organizationManager.viewModel.organizationCriteria.SearchString = [];
                athoc.iws.organizationManager.deSelect(1);
                athoc.iws.organizationManager.viewModel.selectedOprator(0);
                $('#ddlOprators').val([]);
                $('#ddlOprators').selectpicker('refresh');
                $("#ddlLocale").selectpicker('refresh');

                athoc.iws.organizationManager.refreshGrid();
                athoc.iws.organizationManager.listLoad();
                $("#" + athoc.iws.organizationManager.pageName_OrgMain + " .k-grid-header").css("z-index", "10");
                athoc.iws.organizationManager.viewModel.SearchDisabled(true);
            },

            // Triggered, when search button or hit enter in search textbox
            search: function () {

                if (((athoc.iws.organizationManager.viewModel.searchString() != undefined)) && ($.trim(athoc.iws.organizationManager.viewModel.searchString()).length > athoc.iws.organizationManager.searchMaxLength)) {
                    $('#saveGroupMessagePanel').html(athoc.iws.organizationManager.resources.Settings_Organization_SearchLengthCheck);
                    return;
                }
                //To create pill on search functionality
                athoc.iws.organizationManager.createPills(athoc.iws.organizationManager.viewModel.searchString());

            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            // initializing the link on page
            initBreadcrumb: function () {

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.organizationManager.breadcrumbModel;
                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.organizationManager.resources.Action_Button_Settings, '', function () {
                    window.location.href = "/client/setup/settings";
                });

                breadcrumbsModel.addPage(new PageBreadcrumb('listorganization', athoc.iws.organizationManager.resources.Settings_Organization_MainTitle, [settingLink], ''));
            },

            // Binding the link on page
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.organizationManager.breadcrumbModel;
                breadcrumbsModel.SelectedPage('listorganization');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');

                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            // Generic method to open the popup page
            showModalPopup: function (IdOfdiv, intervalTime) {
                if (intervalTime == undefined)
                    intervalTime = 100;
                $('#' + IdOfdiv).show();
                $('#' + IdOfdiv).modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        if ($("#" + IdOfdiv + " #Organization_name").is(":visible"))
                            $("#" + IdOfdiv + " #Organization_name").focus();
                    }, intervalTime);
                });

            },

            // todisplay the template settings in edit mode
            viewOrganizationDetail: function (model) {
                $('.modal-backdrop').remove();
                ko.cleanNode($("#" + athoc.iws.organizationManager.pageName_View).get(0));
                ko.applyBindings(model, $("#" + athoc.iws.organizationManager.pageName_View).get(0));
                athoc.iws.organizationManager.collapsePanel();
                athoc.iws.organizationManager.showModalPopup(athoc.iws.organizationManager.pageName_View, 1000);
                $("#btnCancelView").focus();
            },

            // subscribe method
            subscribeMethod: function () {
                // Subscribing the name and code to get changes
                athoc.iws.organizationManager.viewModel.organizationCriteria.OrgName.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        athoc.iws.organizationManager.isChanged = true;
                    }

                });

                athoc.iws.organizationManager.viewModel.organizationCriteria.OrgType.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.organizationManager.isChanged = true;
                });

                athoc.iws.organizationManager.viewModel.selectedOprator.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.organizationManager.isChanged = true;
                });

                athoc.iws.organizationManager.viewModel.organizationCriteria.ProviderLocale.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.organizationManager.isChanged = true;
                });
            },

            // check required controls
            isRequired: function (val, required) {
                var stringTrimRegEx = /^\s+|\s+$/g,
                 testVal;

                if ($.trim(val) === undefined || $.trim(val) === null) {
                    return !required;
                }

                testVal = $.trim(val);
                if (typeof ($.trim(val)) == "string") {
                    testVal = $.trim(val).replace(stringTrimRegEx, '');
                }

                return required && (testVal + '').length > 0;
            },

            // check for Max length
            maxLength: function (val, maxLength) {
                return athoc.iws.organizationManager.isEmptyVal(val) || $.trim(val).length <= maxLength;
            },

            // check for empty
            isEmptyVal: function (val) {
                if ($.trim(val) == undefined) {
                    return true;
                }
                if ($.trim(val) == null) {
                    return true;
                }
                if ($.trim(val) == "") {
                    return true;
                }
            },

            //
            pattern: function (val, regex, type) {
                var pattern = regex;
                var $opts = { "rule": "format", "format": { "pattern": regex } };

                if (typeof $opts.format.pattern === "string")
                    var pattern = (typeof $opts.format.pattern === "object") ? $opts.format.pattern : new RegExp($opts.format.pattern, "g");
                return pattern.test($.trim(val));

            },

            // saves organizations details
            saveorganizationDetails: function (mode) {
                var objModel = null;
                var result = null;
                if (mode == 'd')
                    result = ko.validation.group(athoc.iws.organizationManager.viewModel.organizationCriteria, { deep: true });
                else
                    result = ko.validation.group(athoc.iws.organizationManager.viewModel, { deep: true });

                if (result().length > 0) {
                    athoc.iws.organizationManager.viewModel.organizationCriteria.OrgName.valueHasMutated();
                    (mode != 'd') ? athoc.iws.organizationManager.viewModel.selectedOprator.valueHasMutated() : null;
                    return false;
                }

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: mode == 'd' ? $('#' + athoc.iws.organizationManager.pageName_Dup) : $('#' + athoc.iws.organizationManager.pageName_New), imageURL: athoc.iws.organizationManager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();

                if (mode == 'd') {

                    objModel = athoc.iws.organizationManager.viewModel.selectedorganization;
                }


                // Setting logged in provider id
                if (objModel == null)
                    athoc.iws.organizationManager.viewModel.organizationCriteria.ProviderId(athoc.iws.organizationManager.viewModel.loginVpsTypeId());
                else
                    athoc.iws.organizationManager.viewModel.organizationCriteria.ProviderId(objModel.ProviderId);
                athoc.iws.organizationManager.viewModel.organizationCriteria.ProviderLocale(athoc.iws.organizationManager.viewModel.ProviderLocale);
                if (objModel == null) { // For New Only
                    // checking if system user login
                    if (athoc.iws.organizationManager.viewModel.loginVpsTypeId() == athoc.iws.organizationManager.enumVpsTypes.VpsTypeIds.System) {
                        //if user is selected enterprise
                        if (athoc.iws.organizationManager.viewModel.organizationCriteria.OrgType() == athoc.iws.organizationManager.enumVpsTypes.OrgType.TPL_ENT) {
                            athoc.iws.organizationManager.viewModel.organizationCriteria.ProviderId(0);
                            athoc.iws.organizationManager.viewModel.organizationCriteria.IsEnterprise(true);
                            athoc.iws.organizationManager.viewModel.organizationCriteria.EnterpriseProviderId(0);
                            $('[data-id=ddlLocale]').removeAttr("disabled");
                        }//if user is selected basic
                        else if (athoc.iws.organizationManager.viewModel.organizationCriteria.OrgType() == athoc.iws.organizationManager.enumVpsTypes.OrgType.TPL_BAS) {
                            athoc.iws.organizationManager.viewModel.organizationCriteria.ProviderId(0); //For Basic
                            athoc.iws.organizationManager.viewModel.organizationCriteria.IsEnterprise(true);
                            athoc.iws.organizationManager.viewModel.organizationCriteria.EnterpriseProviderId(0);
                        }
                    }
                    else {//if user is not logged in through system but logged in as enterprise
                        athoc.iws.organizationManager.viewModel.organizationCriteria.ProviderId(athoc.iws.organizationManager.enumVpsTypes.VpsTypeIds.Enterprise);
                        athoc.iws.organizationManager.viewModel.organizationCriteria.OrgType(athoc.iws.organizationManager.enumVpsTypes.OrgType.TPL_ENT);
                        athoc.iws.organizationManager.viewModel.organizationCriteria.IsEnterprise(false);
                        athoc.iws.organizationManager.viewModel.organizationCriteria.EnterpriseProviderId(athoc.iws.organizationManager.viewModel.loginVpsTypeId());

                    }

                    athoc.iws.organizationManager.viewModel.organizationCriteria.IsDuplicate(false);
                }
                else // For duplicate only
                { // checking if  user logged in through system
                    if (athoc.iws.organizationManager.viewModel.loginVpsTypeId() == athoc.iws.organizationManager.enumVpsTypes.VpsTypeIds.System) {
                        athoc.iws.organizationManager.viewModel.organizationCriteria.ProviderId(objModel.ProviderId);
                        athoc.iws.organizationManager.viewModel.organizationCriteria.IsEnterprise(true);
                        athoc.iws.organizationManager.viewModel.organizationCriteria.EnterpriseProviderId(objModel.EntProviderId);
                        if (objModel.ProvideType === "Enterprise") {
                            athoc.iws.organizationManager.viewModel.organizationCriteria.OrgType(athoc.iws.organizationManager.enumVpsTypes.OrgType.TPL_ENT);
                        }
                        else if (objModel.ProvideType === "Basic") {
                            athoc.iws.organizationManager.viewModel.organizationCriteria.OrgType(athoc.iws.organizationManager.enumVpsTypes.OrgType.TPL_BAS);
                        }
                    }
                    else { // checking if  user logged in through enterprise
                        athoc.iws.organizationManager.viewModel.organizationCriteria.ProviderId(objModel.ProviderId);
                        athoc.iws.organizationManager.viewModel.organizationCriteria.IsEnterprise(false);
                        athoc.iws.organizationManager.viewModel.organizationCriteria.EnterpriseProviderId(athoc.iws.organizationManager.viewModel.loginVpsTypeId());
                        athoc.iws.organizationManager.viewModel.organizationCriteria.OrgType(objModel.ProvideType);
                    }
                    athoc.iws.organizationManager.viewModel.organizationCriteria.IsDuplicate(true);


                }

                //setting criteria
                var jsonData = { data: ko.mapping.toJS(athoc.iws.organizationManager.viewModel.organizationCriteria) };
                var myAjaxOptions =
                     {

                         url: athoc.iws.organizationManager.viewModel.organizationCriteria.IsDuplicate() ? athoc.iws.organizationManager.urls.DuplicateorganizationUrl : athoc.iws.organizationManager.urls.SaveorganizationUrl,
                         dataType: 'json',
                         type: 'POST',
                         contentType: "application/json; charset=utf-8",
                         data: JSON.stringify(jsonData),
                         success: function (data) {
                             athoc.iws.organizationManager.isChanged = false;
                             if (data.Success == true) {
                                 mode == 'd' ? $('#' + athoc.iws.organizationManager.pageName_Dup).modal('hide') : $('#' + athoc.iws.organizationManager.pageName_New).modal('hide');
                                 mode == 'd' ? $('#' + athoc.iws.organizationManager.pageName_Dup + ' .blockUI').remove() : $('#' + athoc.iws.organizationManager.pageName_New + ' .blockUI').remove();
                                 $('#' + athoc.iws.organizationManager.pageName_View).modal('hide');
                                 $('#' + athoc.iws.organizationManager.pageName_View + ' .blockUI').remove();
                                 athoc.iws.organizationManager.clearFilters();
                                 $("#" + athoc.iws.organizationManager.searchinput).focus();
                             }
                             else {
                                 $.AjaxLoader.hideLoader();

                                 mode == 'n' ? $("#" + athoc.iws.organizationManager.pageName_New + " .warning").html(data.Error) : $("#" + athoc.iws.organizationManager.pageName_New + " .warning").html(data.Error);
                                 mode == 'd' ? $("#" + athoc.iws.organizationManager.pageName_Dup + " .warning").html(data.Error) : $("#" + athoc.iws.organizationManager.pageName_New + " .warning").html(data.Error);
                                 mode == 'd' ? $('#' + athoc.iws.organizationManager.pageName_Dup + ' .blockUI').remove() : $('#' + athoc.iws.organizationManager.pageName_New + ' .blockUI').remove();
                                 if (data.isUnAuthOrgAccess == true || data.isCharacterValidationError==true) {
                                     $('#orgNew').modal('hide');
                                     $('#orgNew .blockUI').remove();
                                     athoc.iws.organizationManager.clearFilters();
                                     $("#" + athoc.iws.organizationManager.searchinput).focus();
                                     $("#unAuthUser li").html(data.Error);
                                     $("#unAuthUser").show();
                                     $(".kgrid-fix-top").attr('style', "top:281px!important;");
                                     $(".k-grid-header").attr('style', "top:250px!important;");
                                     $(".table-crown-center").attr('style', "top:40px!important;");
                                 }
                             }
                         },
                         error: function (e) {
                             $.AjaxLoader.hideLoader();
                             athoc.iws.organizationManager.handleError(e);
                         }
                     };
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
                return false;


            },

            // Before opening the popup, model value is resetting
            saveNewOrganizationDetailsData: function (popName) {
                athoc.iws.organizationManager.clearFiltersForPopup();


                if (popName == athoc.iws.organizationManager.pageName_Dup) {
                    athoc.iws.organizationManager.viewModel.organizationCriteria.OrgName(athoc.iws.organizationManager.viewModel.selectedorganization.ProviderName + "_copy");
                    athoc.iws.organizationManager.viewModel.organizationCriteria.ProviderLocale(athoc.iws.organizationManager.viewModel.selectedorganization.DefaultLocale);
                    $('#' + athoc.iws.organizationManager.pageName_View).append('<div id="displayShadowOrgView" class="modal-backdrop fade in"></div>');
                }
                else {
                    athoc.iws.organizationManager.viewModel.organizationCriteria.OrgName("");
                    athoc.iws.organizationManager.viewModel.organizationCriteria.OrgType("");
                    athoc.iws.organizationManager.viewModel.selectedOprator(0);
                }

                $("#" + popName + " .warning").html('');
                $('#ddlOrgType').selectpicker('refresh');
                $('#ddlOprators').selectpicker('refresh');
                $("#ddlLocale").selectpicker('refresh');
                $('#' + popName + ' .blockUI').remove();
                athoc.iws.organizationManager.subscribeMethod();
                athoc.iws.organizationManager.isChanged = false;

                if ((athoc.iws.organizationManager.viewModel.loginVpsTypeId() != athoc.iws.organizationManager.enumVpsTypes.VpsTypeIds.System) && (athoc.iws.organizationManager.viewModel.organizationCriteria.OrgType() != athoc.iws.organizationManager.enumVpsTypes.OrgType.TPL_ENT) && (athoc.iws.organizationManager.viewModel.organizationCriteria.OrgType() != athoc.iws.organizationManager.enumVpsTypes.OrgType.TPL_BAS))
                    $('[data-id=ddlLocale]').attr("disabled", "disabled");
                else
                    $('[data-id=ddlLocale]').removeAttr("disabled");




                athoc.iws.organizationManager.showModalPopup(popName, 1000);
                $("#orgView").modal("hide");
                $("#" + popName + " #Organization_name").focus();
            },

            // Cancel saving on save popup
            cancelSaving: function () {
                if ((athoc.iws.organizationManager.isChanged == true) && (athoc.iws.organizationManager.viewModel.organizationCriteria.OrgName() != "") && (athoc.iws.organizationManager.viewModel.selectedOprator() != undefined)) {
                    var confirmLeave = confirm(athoc.iws.organizationManager.resources.Unsaved_Data_Text);
                    if (confirmLeave == true) {
                        athoc.iws.organizationManager.isChanged = false;
                        $('#btnCancelDialog').click();
                    }
                }
                else
                    $('#btnCancelDialog').click();

                $('#' + athoc.iws.organizationManager.pageName_New).on('hidden.bs.modal', function (e) {
                    $("#" + athoc.iws.organizationManager.searchinput).focus();
                });

            },

            cancelView: function () {
                $("#" + athoc.iws.organizationManager.pageName_View).modal('hide');
                $('#' + athoc.iws.organizationManager.pageName_View).on('hidden.bs.modal', function (e) {
                    $("#" + athoc.iws.organizationManager.searchinput).focus();
                });
            },

            // Cancel saving on duplicate popup
            cancelSaveDuplicate: function () {
                if (athoc.iws.organizationManager.isChanged == true) {
                    var confirmLeave = confirm(athoc.iws.organizationManager.resources.Unsaved_Data_Text);
                    if (confirmLeave == true) {
                        athoc.iws.organizationManager.isChanged = false;
                        $('#btnCancelDialogd').click();
                    }
                } else
                    $('#btnCancelDialogd').click();
                $('#orgView').modal('show');
                $('#displayShadowOrgView').remove();
            },

            //
            listLoad: function () {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
            },

            // Binding the knedo grid with organization data
            bindorganizationList: function () {

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#' + athoc.iws.organizationManager.pageName_OrgMain), imageURL: athoc.iws.organizationManager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: this.resources.General_LoadingMessage }).showLoader();
                // Ajax call to server to get Organziation records
                var jsonData = { orgSettings: ko.mapping.toJS(athoc.iws.organizationManager.viewModel.organizationCriteria) };
                organizationDatasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: athoc.iws.organizationManager.urls.GetorganizationListsUrl,
                            cache: false,
                            data: JSON.stringify(jsonData),
                            contentType: "application/json; charset=utf-8",
                            type: "POST",
                        },
                        parameterMap: function (options) {
                            $.extend(options, ko.mapping.toJS(athoc.iws.organizationManager.viewModel.organizationCriteria));
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                    },
                    requestEnd: function (e) {

                        if (e.response != undefined && e.response.Success) {
                            athoc.iws.organizationManager.ListModel.set("TotalCount", e.response.TotalCount);
                            athoc.iws.organizationManager.ListModel.set("SelectedCount", 0);

                            // assign format model values to individual dropdowns
                            athoc.iws.organizationManager.viewModel.OrgType(e.response.OrgTypes);

                            athoc.iws.organizationManager.Languages = e.response.languages;
                            athoc.iws.organizationManager.viewModel.langSupports(athoc.iws.organizationManager.Languages);
                            athoc.iws.organizationManager.viewModel.organizationCriteria.ProviderLocale(e.response.ProviderLocale);

                            athoc.iws.organizationManager.viewModel.loginVpsType(e.response.ProviderType);
                            athoc.iws.organizationManager.viewModel.loginVpsTypeId(e.response.ProviderTypeId);
                            if ((e.response.ProviderType.toLowerCase() == athoc.iws.organizationManager.enumVpsTypes.System) || (e.response.ProviderType.toLowerCase() == athoc.iws.organizationManager.enumVpsTypes.Enterprise) || (e.response.ProviderType.toLowerCase() == athoc.iws.organizationManager.enumVpsTypes.Enterprisetemplate)) {
                                ko.cleanNode($("#staticorganizationListActionButtons").get(0));
                                ko.applyBindings(athoc.iws.organizationManager.viewModel, $("#staticorganizationListActionButtons").get(0));
                            }
                            $('#' + athoc.iws.organizationManager.pageName_OrgMain + ' .blockUI').remove();
                            $('#saveGroupMessagePanel').html('');
                        }
                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                    },
                    sort: { field: "ProviderName", dir: "asc" },
                    pageSize: 50,


                    error: function (e) {
                        $.AjaxLoader.hideLoader();
                        athoc.iws.organizationManager.handleError(e);
                    },
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            //when sort changes, go to first page.
                            this.page(1);
                        }
                        //scrolling to the top when paging and sorting.
                        $("html,body").scrollTop(0);
                    }

                });


                //setting all Org Data to kendo
                var grid = $("#" + athoc.iws.organizationManager.pageName_OrgMain).kendoGrid({
                    dataSource: organizationDatasource,
                    autoBind: false,
                    selectable: false,
                    width: 400,
                    sortable: {
                        allowUnsort: false
                    },


                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5, messages: {
                            display: athoc.iws.organizationManager.resources.AtHoc_Pager_Message_Summary,
                            empty: athoc.iws.organizationManager.resources.IWS_Common_NoRecordsFound,
                            itemsPerPage: athoc.iws.organizationManager.resources.AtHoc_Pager_Message_Items_Per_Page,

                            first: athoc.iws.organizationManager.resources.AtHoc_Pager_Message_Go_To_The_First_Page,
                            previous: athoc.iws.organizationManager.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page,
                            next: athoc.iws.organizationManager.resources.AtHoc_Pager_Message_Go_To_The_Next_Page,
                            last: athoc.iws.organizationManager.resources.AtHoc_Pager_Message_Go_To_The_Last_Page
                        }
                    },
                    columns: [
                                {
                                    field: "ProviderId",
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.organizationManager.resources.Settings_Organization_SortPrifix + " " + athoc.iws.organizationManager.resources.Settings_Organization_SortOrgId, athoc.iws.organizationManager.resources.Settings_Organization_SortOrgId),
                                    width: 100
                                },
                                {
                                    field: "ProviderName",
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.organizationManager.resources.Settings_Organization_SortPrifix + " " + athoc.iws.organizationManager.resources.Settings_Organization_SortOrgName, athoc.iws.organizationManager.resources.Settings_Organization_SortOrgName),
                                    width: 200
                                },
                                 {
                                     field: "ProvideType",
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.organizationManager.resources.Settings_Organization_SortPrifix + " " + athoc.iws.organizationManager.resources.Settings_Organization_SortOrgType, athoc.iws.organizationManager.resources.Settings_Organization_SortOrgType),
                                     width: 100
                                 },
                                {
                                    field: "LanguageName",
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.organizationManager.resources.Settings_Organization_SortPrifix + " " + athoc.iws.organizationManager.resources.Settings_Organization_sortOrgLocale, athoc.iws.organizationManager.resources.Settings_Organization_sortOrgLocale),
                                    //template: "#= athoc.iws.organizationManager.getLanguageName(DefaultLocale) #",
                                    width: 150,
                                },

                                {
                                    field: "CreatedDate",
                                    width: 150,
                                    type: "date",
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', athoc.iws.organizationManager.resources.Settings_Organization_sortOrgLocale + " " + athoc.iws.organizationManager.resources.Settings_Organization_SortOrgLaunchDate, athoc.iws.organizationManager.resources.Settings_Organization_SortOrgLaunchDate),
                                    format: $.vpsDateTimeFormat,
                                    template: "#= CreatedDate #",
                                },
                    ],
                    dataBound: athoc.iws.organizationManager.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                    }
                }).data().kendoGrid;



                var $template = kendo.template($("#name-tooltip-template").html());

                tooltip = $("#" + athoc.iws.organizationManager.pageName_OrgMain).kendoTooltip({
                    filter: "td:nth-child(2)", //this filter selects the first column cells                   
                    content: function (e) {
                        var dataItem = $("#" + athoc.iws.organizationManager.pageName_OrgMain).data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },

                }).data("kendoTooltip");


                $("#" + athoc.iws.organizationManager.pageName_OrgMain).kendoTooltip({
                    filter: ".cellTooltip",
                });

                $("#pageInfo").kendoPager({
                    dataSource: organizationDatasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.organizationManager.resources.OrgMgr_DisplayFolder,
                        empty: athoc.iws.organizationManager.resources.IWS_Common_NoRecordsFound
                    }
                });

                this.refreshGrid();

            },
            replaceString: function (value) {
                if (value == null)
                    return " ";
                else
                    return value;
            },
            //
            refreshGrid: function () {
                if (organizationDatasource != undefined) {
                    //show the loader when we make a request to the server..
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-filter'), imageURL: athoc.iws.organizationManager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: this.resources.General_LoadingMessage }).showLoader();
                    //Per telerik, this will set the page only after organizationDatasource refreshes.
                    organizationDatasource.one("change", function () {
                        //pagination needs to be reset after a reload
                        this.page(1);
                    });

                    organizationDatasource.read();
                    // athoc.iws.organizationManager.viewModel.selectedorganization(0);
                    $.AjaxLoader.hideLoader();
                }
            },

            errors: null,

            //Method to handle erro and session time out, this is boud with Ajax calls
            handleError: function (e) {
                $.AjaxLoader.hideLoader();
                athoc.iws.organizationManager.errors = [];
                if ((e != undefined && e.status == 401) || (e != undefined && e.xhr != undefined && e.xhr.status == 401)) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else if (e.errorThrown != "") {
                    if (athoc.iws.organizationManager.errors === null) {
                        athoc.iws.organizationManager.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.organizationManager.errors.push({ Type: '4', Value: e.errorThrown });
                    }

                    $("#" + athoc.iws.organizationManager.pageName_OrgMain + " .k-grid-header").css("top", "315px");
                    $("#" + athoc.iws.organizationManager.pageName_OrgMain + "").css('cssText', 'top: 346px !important');
                    $("#" + athoc.iws.organizationManager.pageName_Search + " .whiteout").css("height", "315px");
                    $('#saveGroupMessagePanel').messagesPanel({ messages: this.errors }, undefined, undefined, undefined, errorTitleStrings);



                    $("#saveGroupMessagePanel .close").prop("click", function () {
                        $("#" + athoc.iws.organizationManager.pageName_OrgMain + " .k-grid-header").css("top", "210px");
                        $("#" + athoc.iws.organizationManager.pageName_OrgMain).css("cssText", "top: 241px !important");
                        $("#" + athoc.iws.organizationManager.pageName_Search + " .whiteout").css("height", "210px");
                    });

                }
            },

            //
            showEditError: function (msg) {
                $.AjaxLoader.hideLoader();
                $('#saveGroupMessagePanel_edit').messagesPanel({ messages: [{ Type: '4', Value: msg }] }, undefined, undefined, undefined, errorTitleStrings);

            },

            //On Grid databound navigate to Edit page or View page w.r.t device Type
            OnDataBound: function () {

                $("#" + athoc.iws.organizationManager.pageName_OrgMain + " tbody").find("tr").attr("tabindex", "0");
                var grid = $("#" + athoc.iws.organizationManager.pageName_OrgMain).data("kendoGrid");

                $(grid.tbody).on("click", "td", function (e) {

                    var isFirstRowCheck = $(this).closest("td").find('#chkorganizationMngId');
                    if (isFirstRowCheck.length == 0) {
                        var row = $(this).closest("tr");
                        var rowIdx = $("tr", grid.tbody).index(row);
                        var colIdx = $("td", row).index(this);
                        if (colIdx >= 0) {
                            if ((colIdx == 0 && e.target.className == "") || colIdx > 0) {
                                athoc.iws.organizationManager.isRelease = false;
                                var model = organizationDatasource.view()[rowIdx];
                                model.LanguageName = athoc.iws.organizationManager.getLanguageName(model.DefaultLocale);

                                tooltip.hide();
                                athoc.iws.organizationManager.viewModel.selectedorganization = model;
                                athoc.iws.organizationManager.viewOrganizationDetail(model);
                            }
                        }
                    }
                });
                //On Grid row key press navigate to Edit page or View page w.r.t device Type
                $(grid.tbody).on("keypress", "tr", function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        // athoc.iws.organizationManager.viewModel.selectedorganization(athoc.iws.organizationManager.getSelectedItems().length);
                        athoc.iws.organizationManager.isRelease = false;
                        var row = $(this);
                        var rowIdx = $("tr", grid.tbody).index(row);
                        var model = organizationDatasource.view()[rowIdx];
                        tooltip.hide();
                        athoc.iws.organizationManager.viewModel.selectedorganization = model;
                        athoc.iws.organizationManager.viewOrganizationDetail(model);
                    }
                });

                if (athoc.iws.organizationManager.IsRightToLeft) {
                    $("#" + athoc.iws.organizationManager.pageName_OrgMain).find('.pull-right').addClass('pull-left');
                    $("#" + athoc.iws.organizationManager.pageName_OrgMain).find('.pull-right').removeClass('pull-right');
                }
                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(grid.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px;cursor:text;">' + athoc.iws.organizationManager.resources.IWS_Common_NoRecordsFound + '</td></tr>');
                }
            },

            getLanguageName: function (defaultLocale) {
                defaultLocale = (defaultLocale == null) ? "en-US" : defaultLocale;
                var languageSettings = _.find(athoc.iws.organizationManager.Languages, function (item) {
                    if (item.LocalCode.toUpperCase() == defaultLocale.toUpperCase())
                        return item;
                });
                return languageSettings.LanguageName;
            },
            //Validate the controls on Add and duplicate popup
            validateControls: function () {
                //remove old validation
                $(".warning").each(function () {
                    $(this).parent().remove();
                });
                //alert(athoc.iws.organizationManager.viewModel.organizationCriteria.OrgName.length);
                //Validate the controls on Add and duplicate popup
                athoc.iws.organizationManager.viewModel.organizationCriteria.OrgName.extend({
                    required: {
                        params: true,
                        message: athoc.iws.organizationManager.resources.Settings_Organization_Required
                    },
                    minLength: {
                        params: 3,
                        message: athoc.iws.organizationManager.resources.Settings_Organization_MinMaxLength
                    },
                    maxLength: {
                        params: 62,
                        message: athoc.iws.organizationManager.resources.Settings_Organization_MinMaxLength
                    },
                    pattern: {
                        message: athoc.iws.organizationManager.resources.Settings_Organization_SpecialCharatersAllowed,
                        //params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$"
                        params: "^[^`^!^$^^^%^(^)^=^{^}^,^;^\^:^?^\"^<^>^|]+$"
                        //param:""

                    }
                    //validation: {
                    //    validator: athoc.iws.organizationManager.lengthValidation,
                    //    message: athoc.iws.organizationManager.resources.OM_orgMinMaxLength,
                    //    params: [3, 62]
                    //},
                });


            },

            //check the length of string
            lengthValidation: function (str, minChar) {
                var maxChar;
                if (athoc.iws.organizationManager.getCharCount(str) < minChar[0] ||
                    athoc.iws.organizationManager.getCharCount(str) > minChar[1])
                    return false;
                return true;
            },

            //get character based on ascii value
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },

            //check for special characters
            isSpecialChar: function (objValue) {
                var count = 0;
                var pattr = ["\\", ":", "/", "*", "?", ">", "<", "[", "]", "{", "}", "|", "'", "=", "+"];

                while (count < pattr.length) {
                    if (objValue.indexOf(pattr[count]) > -1) {
                        return false;
                    }
                    count++;
                }
            },

            // Creating pills when search is done
            createPills: function (value) {
                var found = _.find(athoc.iws.organizationManager.viewModel.organizationCriteria.SearchString, function (item) {
                    return (item == value);
                });
                if (!found) {
                    if ((value !== undefined) && (value != ''))
                        athoc.iws.organizationManager.viewModel.organizationCriteria.SearchString.push(value);
                    athoc.iws.organizationManager.refreshGrid();
                    athoc.iws.organizationManager.listLoad();
                    athoc.iws.organizationManager.renderPills();
                }
            },

            // Rendering the pills when search is done
            renderPills: function (css) {
                var self = this;
                var html = "";
                athoc.iws.organizationManager.viewModel.htmlPillContent('');
                if (athoc.iws.organizationManager.viewModel.organizationCriteria.SearchString && athoc.iws.organizationManager.viewModel.organizationCriteria.SearchString.length > 0) {
                    _.each(athoc.iws.organizationManager.viewModel.organizationCriteria.SearchString, function (item, index) {
                        var iconCss = "";
                        var prefix = "";
                        var pillLabel = prefix + $.htmlEncode(item);
                        var pillTooltip = prefix + $.htmlEncode(item);
                        var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" href="#"></a>' : '');
                        html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                    });
                    if (html != "") {
                        $(".push").attr("style", 'margin-bottom:0px');
                    };
                    athoc.iws.organizationManager.viewModel.htmlPillContent(html);
                    $("#" + athoc.iws.organizationManager.pageName_Search + " .whiteout").removeAttr("style");
                    $("#" + athoc.iws.organizationManager.pageName_Search + " .whiteout").attr("style", "height:" + (parseInt($("#" + athoc.iws.organizationManager.pageName_Search + " .whiteout").height()) + parseInt($("#" + athoc.iws.organizationManager.pageName_Search + " .pill-container").height()) + 6) + "px");
                    $("#" + athoc.iws.organizationManager.pageName_OrgMain + " .k-grid-header").css("margin-top", (parseInt($("#" + athoc.iws.organizationManager.pageName_Search + " .pill-container").height()) + 6) + "px");
                    $("#" + athoc.iws.organizationManager.pageName_OrgMain).css("margin-top", (parseInt($("#" + athoc.iws.organizationManager.pageName_Search + " .pill-container").height()) + 6) + "px");
                    $("#" + athoc.iws.organizationManager.pageName_Search + " .table-crown-center").removeAttr("style");
                    $("#" + athoc.iws.organizationManager.pageName_Search + " .table-crown-center").attr("style", "height:" + (parseInt($("#" + athoc.iws.organizationManager.pageName_Search + " .table-crown-center").height()) + parseInt($('.pill-container').height()) + 8) + "px !important");
                    //wire up events
                    $("#" + athoc.iws.organizationManager.pageName_Search + " .pill-close").click(function (event) {
                        var parentElm = $(this).parent(".pill");
                        athoc.iws.organizationManager.deSelect(parentElm.data("index"));
                        event.stopPropagation();
                    });
                    athoc.iws.organizationManager.viewModel.searchString('');
                }
            },

            // Deleting the pills
            deSelect: function (index, onSuccess) {
                if (athoc.iws.organizationManager.viewModel.organizationCriteria.SearchString && athoc.iws.organizationManager.viewModel.organizationCriteria.SearchString.length > index) {
                    athoc.iws.organizationManager.viewModel.organizationCriteria.SearchString.splice(index, 1);
                    athoc.iws.organizationManager.refreshGrid();
                    athoc.iws.organizationManager.listLoad();
                    athoc.iws.organizationManager.renderPills();
                }

                if (athoc.iws.organizationManager.viewModel.organizationCriteria.SearchString && athoc.iws.organizationManager.viewModel.organizationCriteria.SearchString.length == 0) {
                    athoc.iws.organizationManager.viewModel.htmlPillContent('');
                    $("#" + athoc.iws.organizationManager.pageName_OrgMain + " .k-grid-header").css("margin-top", "0px");
                    $("#" + athoc.iws.organizationManager.pageName_OrgMain).css("margin-top", "0px");
                    $(".push").removeAttr("style");
                    $("#" + athoc.iws.organizationManager.pageName_Search + " .whiteout").removeAttr("style");
                    $("#" + athoc.iws.organizationManager.pageName_Search + " .table-crown-center").removeAttr("style");
                }
            },
        };
    }();
}
