﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
if (athoc.iws) {
    var mode;
   

    athoc.iws.systemsettings = function () {

        return {
            isChanged: false,
            SubjectText: "",
            UserText: "",
            PassText: "",
            ServerAddressText: "",
            StoreLocText: "",
            StoreNameText: "",
            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},
            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},
            //viewmodel to hold individual System settings record
            viewModel: {
                systemsettingmodel: ko.observable(),
                globaledit: ko.observable(true),
            },
            //editmodel to hold individual System settings record
            editModel: {
                systemsettingmodel: ko.observable(),
                StoreLocationArray: ko.observableArray(),
                StoreNameArray: ko.observableArray(),
            },

            //init method for distribution list, will be triggered before document load
            init: function () {
                athoc.iws.systemsettings.initBreadcrumb();
            },

            //load method, will be triggered on document load
            load: function () {
                athoc.iws.systemsettings.bindBreadcrumb();
                //button events!
                $("#btn_edit").click(function () { athoc.iws.systemsettings.editSystemSettings() });
                $("#btn_supportcontent").click(function () {
                    $('#dsaveMessagePanel').html('');
                    $("#dialogSupport").show();
                });
                $("#btn_supportcontent_View").click(function () {
                    $('#dsaveMessagePanel').html('');
                    $("#dialogSupportView").show();
                });

                $("#btn_save").click(function () {
                    athoc.iws.systemsettings.saveSystemSettings();
                });
                $("#btn_cancel").click(function () {
                    window.location.href = "/client/setup/settings";
                });

                $("#btn_ecancel").click(function () {
                    var isModified = athoc.iws.systemsettings.isChanged;
                    if (isModified == true) {
                        var confirmLeave = confirm(athoc.iws.systemsettings.resources.Unsaved_Data_Text);
                        if (confirmLeave == true) {
                            athoc.iws.systemsettings.isChanged = false;
                            navigateToPage('viewSystemSettings', function () { });
                            athoc.iws.systemsettings.breadcrumbModel.SelectedPage('viewSystemSettings');
                            $.titleCrumb("pageBreadcrumbs");
                            athoc.iws.systemsettings.getSystemSettings();
                        }
                    }
                    else {
                        navigateToPage('viewSystemSettings', function () { });
                        athoc.iws.systemsettings.breadcrumbModel.SelectedPage('viewSystemSettings');
                        $.titleCrumb("pageBreadcrumbs");
                        athoc.iws.systemsettings.getSystemSettings();
                    }
                });
                $("#okButton").click(function () {

                    if (athoc.iws.systemsettings.validateXML($("#txtSupportPageContent").val())) {
                        athoc.iws.systemsettings.editModel.systemsettingmodel.SupportPageContent($("#txtSupportPageContent").val());
                        $('#dsaveMessagePanel').html('');
                        $('#dialogSupport').modal('hide');
                        $('#dsaveMessagePanel').hide();
                    }
                    else {

                        $('#dsaveMessagePanel').html('');
                        $('#dsaveMessagePanel').css({ display: 'block' });
                        var reqError = new Array();
                        reqError.push({ Type: '4', Value: "Invalid XML Format." });
                        $('#dsaveMessagePanel').messagesPanel({ messages: reqError });

                    }
                });

                window.onbeforeunload = function (event) {
                    var isModified = athoc.iws.systemsettings.isChanged;

                    if (isModified) {
                        return athoc.iws.systemsettings.resources.Unsaved_Data_Text;
                    } else {
                        $(window).scrollTop(0);

                    }
                };

            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            // to initate  Breadcrumb
            initBreadcrumb: function () {
                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = athoc.iws.systemsettings.breadcrumbModel;

                //Sub-level breadcrumb
                var settingLink = new Breadcrumb('settingLink', athoc.iws.systemsettings.resources.Action_Button_Settings, '', function () {
                    window.location.href = "/client/setup/settings";
                });

                var systemsLink = new Breadcrumb('systemsLink', athoc.iws.systemsettings.resources.SystemSettings_TitleLink, '', function () {

                    navigateToPage('viewSystemSettings', function () { });
                    athoc.iws.systemsettings.breadcrumbModel.SelectedPage('viewSystemSettings');
                    $.titleCrumb("pageBreadcrumbs");
                    athoc.iws.systemsettings.getSystemSettings();
                });


                //Page breadcrumb
                var viewPageBreadcrumb = new PageBreadcrumb('viewSystemSettings', athoc.iws.systemsettings.resources.SystemSettings_TitleLink, [settingLink], '');
                var editPageBreadcrumb = new PageBreadcrumb('editSystemSettings', athoc.iws.systemsettings.resources.Action_Button_Edit, [settingLink, systemsLink], '');

                breadcrumbsModel.addPage(viewPageBreadcrumb);
                breadcrumbsModel.addPage(editPageBreadcrumb);
            },

            // to system settings
            getSystemSettings: function () {
                $('#saveMessagePanel').messagesPanel('reset');
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.systemsettings.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                var dlSuccess = function (data) {
                    
                };

                var dlAjaxOption =
                    {
                        type: "POST",
                        url: athoc.iws.systemsettings.urls.GetSystemSettingsUrl,
                        success: function (data) {
                            $(document).scrollTop(0);

                            athoc.iws.systemsettings.viewModel.systemsettingmodel = ko.mapping.fromJS(data.Data);
                            // assign format model values to individual dropdowns
                            athoc.iws.systemsettings.editModel.StoreNameArray(data.formatModel.StoreNameList);
                            athoc.iws.systemsettings.editModel.StoreLocationArray(data.formatModel.StoreLocationList);

                            //hide Edit button
                            $('#btn_edit').hide();

                            //Binding
                            ko.cleanNode($("#viewSystemSettings").get(0));
                            ko.applyBindings(athoc.iws.systemsettings.viewModel, $("#viewSystemSettings").get(0));
                            athoc.iws.systemsettings.collapsePanel();
                            mode = 0;

                            //hide Edit button
                            $('#btn_edit').hide();


                            if (mode == 0) {
                                if (athoc.iws.systemsettings.viewModel.systemsettingmodel.CCStoreName() != null) {
                                    athoc.iws.systemsettings.viewModel.systemsettingmodel.CCStoreName(athoc.iws.systemsettings.getDropdownvalue(athoc.iws.systemsettings.editModel.StoreNameArray(), athoc.iws.systemsettings.viewModel.systemsettingmodel.CCStoreName()));
                                    athoc.iws.systemsettings.StoreNameText = athoc.iws.systemsettings.getDropdownvalue(athoc.iws.systemsettings.editModel.StoreNameArray(), athoc.iws.systemsettings.viewModel.systemsettingmodel.CCStoreName());
                                }

                                if (athoc.iws.systemsettings.viewModel.systemsettingmodel.CCStoreLocation() != null) {
                                    athoc.iws.systemsettings.viewModel.systemsettingmodel.CCStoreLocation(athoc.iws.systemsettings.getDropdownvalue(athoc.iws.systemsettings.editModel.StoreLocationArray(), athoc.iws.systemsettings.viewModel.systemsettingmodel.CCStoreLocation()));
                                    athoc.iws.systemsettings.StoreLocText = athoc.iws.systemsettings.getDropdownvalue(athoc.iws.systemsettings.editModel.StoreLocationArray(), athoc.iws.systemsettings.viewModel.systemsettingmodel.CCStoreLocation());
                                }

                                if (athoc.iws.systemsettings.viewModel.systemsettingmodel.CCSubject() != null) {
                                    athoc.iws.systemsettings.SubjectText = athoc.iws.systemsettings.viewModel.systemsettingmodel.CCSubject();
                                }
                                if (athoc.iws.systemsettings.viewModel.systemsettingmodel.PSSUsername() != null) {
                                    athoc.iws.systemsettings.UserText = athoc.iws.systemsettings.viewModel.systemsettingmodel.PSSUsername();
                                }

                                if (athoc.iws.systemsettings.viewModel.systemsettingmodel.PSSPassword() != null) {
                                    athoc.iws.systemsettings.PassText = athoc.iws.systemsettings.viewModel.systemsettingmodel.PSSPassword().replace(/[ A-Za-z0-9_@#-.~!$%&()={}/|\`^:;"<>?£]/g, "*");
                                    athoc.iws.systemsettings.viewModel.systemsettingmodel.PSSPasswordText(athoc.iws.systemsettings.viewModel.systemsettingmodel.PSSPassword().replace(/[ A-Za-z0-9_@#-.~!$%&()={}/|\`^:;"<>?£]/g, "*"));
                                }
                                if (athoc.iws.systemsettings.viewModel.systemsettingmodel.PSSUrl() != null) {
                                    athoc.iws.systemsettings.ServerAddressText = athoc.iws.systemsettings.viewModel.systemsettingmodel.PSSUrl();
                                }
                            }

                            // enable Edit button for  System admin
                            if (athoc.iws.systemsettings.viewModel.systemsettingmodel.IsSystemAdmin())
                                $('#btn_edit').show();


                            if (athoc.iws.systemsettings.viewModel.systemsettingmodel.IsSystemAdmin())
                                athoc.iws.systemsettings.viewModel.globaledit(true);
                            else
                                athoc.iws.systemsettings.viewModel.globaledit(false);

                            if (data.HasErrors) {
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }
                            $.AjaxLoader.hideLoader();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.systemsettings.handleError(e);
                        }

                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },

            // to get system settings
            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.systemsettings.breadcrumbModel;
                breadcrumbsModel.SelectedPage('viewSystemSettings');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");

                athoc.iws.systemsettings.getSystemSettings();
            },

            // to initiate select pickers
            initiateSelectPicker: function () {
                $("#ddlStorelocation").selectpicker();
                $("#ddlStorename").selectpicker();
                $("#ddlServeraddress").selectpicker();
                $("#ddlUsername").selectpicker();
            },

            // to edit System Settings
            editSystemSettings: function () {

                navigateToPage('editSystemSettings', function () { });
                athoc.iws.systemsettings.breadcrumbModel.SelectedPage('editSystemSettings');
                $.titleCrumb("pageBreadcrumbs");
                $('#saveMessagePanel').messagesPanel('reset');
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.systemsettings.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();

                var dlSuccess = function (data) {
                  
                };

                var dlAjaxOption =
                    {
                        type: "POST",
                        url: athoc.iws.systemsettings.urls.GetSystemSettingsUrl,
                        success: function (data) {
                            $(document).scrollTop(0);
                            athoc.iws.systemsettings.editModel.systemsettingmodel = ko.mapping.fromJS(data.Data);


                            // assign format model values to individual dropdowns
                            athoc.iws.systemsettings.editModel.StoreNameArray(data.formatModel.StoreNameList);
                            athoc.iws.systemsettings.editModel.StoreLocationArray(data.formatModel.StoreLocationList);

                            $("#editSystemSettings").find(".bootstrap-select").remove();
                            //Binding
                            ko.cleanNode($("#editSystemSettings").get(0));
                            ko.applyBindings(athoc.iws.systemsettings.editModel, $("#editSystemSettings").get(0));
                            athoc.iws.systemsettings.collapsePanel();
                            athoc.iws.systemsettings.editSubscribeMethods();
                            $("#ddlStorename").selectpicker();
                            $("#ddlStorelocation").selectpicker();
                            mode = 1;
                            $("#txtName").focus();
                            if (data.HasErrors) {
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }

                            $.AjaxLoader.hideLoader();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.systemsettings.handleError(e);
                        }

                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },

            // to save System Settings in the database
            saveSystemSettings: function () {
                if (!athoc.iws.systemsettings.performSystemSettingsValidation(athoc.iws.systemsettings.editModel.systemsettingmodel))
                    return false;
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.systemsettings.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                var jsonData = ko.toJSON(athoc.iws.systemsettings.editModel.systemsettingmodel);
                var dlAjaxOption =
                    {
                        url: athoc.iws.systemsettings.urls.SaveSystemSettingsUrl,
                        contentType: "application/json; charset=utf-8",
                        dataType: 'json',
                        type: 'POST',
                        data: jsonData,
                        success: function (data) {
                            if (data.Success) {
                                navigateToPage('viewSystemSettings', function () { });
                                athoc.iws.systemsettings.breadcrumbModel.SelectedPage('viewSystemSettings');
                                $.titleCrumb("pageBreadcrumbs");
                                athoc.iws.systemsettings.getSystemSettings();
                                athoc.iws.systemsettings.isChanged = false;
                            } else {
                                $('#saveMessagePanel').messagesPanel({ messages: data.Messages });
                            }

                            $.AjaxLoader.hideLoader();
                        },
                        error: function (e) {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.systemsettings.handleError(e);
                        }
                    };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
                return true;
            },

            // to toggle collapse panel
            collapsePanel: function () {
                $(this).parent().find('.expand-arrow-open').toggle();
                $('.bucket-toggle h2').click(function () {
                    $(this).parent().find('.row').slideToggle(500);
                    $(this).parent().find('.expand-arrow-open').toggle();
                    $(this).parent().find('.expand-arrow-closed').toggle();
                });
            },

            //
            validateXML: function (val) {
                var status = false;


                if (val != null) {

                    try {
                        var xmlDoc = $.parseXML(val);
                        if (xmlDoc != null)
                            status = true;
                        else
                            status = false;
                    } catch (exception)
                    { status = false; }
                }
                return status;
            },

            //
            showSupportContent: function () {
                $('#dialogSupport').css({ display: 'block' });
                $('#dialogSupport').addClass('width600');
                $('#dialogSupport').modal().css(
                   {
                       'z-index': '3000'
                   });
                $('textarea#txtSupportPageContent').val(athoc.iws.systemsettings.editModel.systemsettingmodel.SupportPageContent());
                $('#dsaveMessagePanel').html('');

            },

            //
            showSupportContentView: function () {
                $('#dialogSupportView').css({ display: 'block' });
                $('#dialogSupportView').addClass('width600');
                $('#dialogSupportView').modal().css(
                   {
                       'z-index': '3000'
                   });
                $('textarea#txtSupportPageContentView').val(athoc.iws.systemsettings.viewModel.systemsettingmodel.SupportPageContent());
                $('#dsaveMessagePanel').html('');

            },

            //
            isRequired: function (val, required) {
                var stringTrimRegEx = /^\s+|\s+$/g,
                 testVal;

                if ($.trim(val) === undefined || $.trim(val) === null) {
                    return !required;
                }

                testVal = $.trim(val);
                if (typeof ($.trim(val)) == "string") {
            //
                    testVal = $.trim(val).replace(stringTrimRegEx, '');
                }

                return required && (testVal + '').length > 0;
            },

            //
            maxLength: function (val, maxLength) {
                return athoc.iws.systemsettings.isEmptyVal(val) || $.trim(val).length <= maxLength;
            },

            //
            minLength: function (val, minLength) {
                return athoc.iws.systemsettings.isEmptyVal(val) || $.trim(val).length >= minLength;
            },

            //
            isEmptyVal: function (val) {
                if ($.trim(val) == undefined) {
                    return true;
                }
                if ($.trim(val) == null) {
                    return true;
                }
                if ($.trim(val) == "") {
                    return true;
                }
            },

            //
            pattern: function (val, regex, type) {
                var pattern = regex;
                var $opts = { "rule": "format", "format": { "pattern": regex } };

                if (typeof $opts.format.pattern === "string")
                    var pattern = (typeof $opts.format.pattern === "object") ? $opts.format.pattern : new RegExp($opts.format.pattern, "g");
                return pattern.test($.trim(val));

            },

            //
            performSystemSettingsValidation: function (systemsettingmodel) {
                var reqError = new Array();
                var focusField = null;

                // Name validation
                if (!athoc.iws.systemsettings.isRequired(systemsettingmodel.Name(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemParameters_Name_Required });
                    focusField = "#txtName";
                }
                if ((systemsettingmodel.Name() != "") && ((systemsettingmodel.Name() != null))) {

                    if (!athoc.iws.systemsettings.maxLength(systemsettingmodel.Name(), 100)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemParameters_Name_MaxLength });
                        if (focusField == null)
                            focusField = "#txtName";

                    }

                    if (!athoc.iws.systemsettings.minLength(systemsettingmodel.Name(), 3)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemParameters_Name_MinLength });
                        if (focusField == null)
                            focusField = "#txtName";

                    }

                    if (!athoc.iws.systemsettings.pattern(systemsettingmodel.Name(), "^[a-zA-Z0-9 _@#-.~!$%&()={};\\\\^]+$", "1")) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemParameters_Name_SpecialChars });
                        if (focusField == null)
                            focusField = "#txtName";

                    }
                }
                //System Url
                if (!athoc.iws.systemsettings.isRequired(systemsettingmodel.SystemUrl(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemParameters_SystemUrl_Required });
                    if (focusField == null)
                        focusField = "#txtSystemUrl";
                }

                if ((systemsettingmodel.SystemUrl() != "") && ((systemsettingmodel.SystemUrl() != null))) {

                    if (!athoc.iws.systemsettings.maxLength(systemsettingmodel.SystemUrl(), 200)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemParameters_SystemUrl_MaxLength });
                        if (focusField == null)
                            focusField = "#txtSystemUrl";

                    }


                }



                if ((systemsettingmodel.DesktopTrafficUrl() != "") && ((systemsettingmodel.DesktopTrafficUrl() != null))) {

                    if (!athoc.iws.systemsettings.maxLength(systemsettingmodel.DesktopTrafficUrl(), 200)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemParameters_DesktopUrl_MaxLength });
                        if (focusField == null)
                            focusField = "#txtDesktopTrafficUrl";

                    }


                }

                //DatabaseArchiveDirectory
                if (!athoc.iws.systemsettings.isRequired(systemsettingmodel.DatabaseArchiveDirectory(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemParameters_DAD_Required });
                    if (focusField == null)
                        focusField = "#txtDatabaseArchiveDirectory";
                }

                if ((systemsettingmodel.DatabaseArchiveDirectory() != "") && ((systemsettingmodel.DatabaseArchiveDirectory() != null))) {

                    if (!athoc.iws.systemsettings.maxLength(systemsettingmodel.DatabaseArchiveDirectory(), 200)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemParameters_DAD_MaxLength });
                        if (focusField == null)
                            focusField = "#txtDatabaseArchiveDirectory";

                    }
                }


                if ($("#chkCCRequire").is(':checked')) {
                    //CCSubject
                    if (!athoc.iws.systemsettings.isRequired(systemsettingmodel.CCSubject(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_ClientCertificate_Subject_Required });
                        if (focusField == null)
                            focusField = "#txtCCSubject";
                    }

                    if ((systemsettingmodel.CCSubject() != "") && ((systemsettingmodel.CCSubject() != null))) {

                        if (!athoc.iws.systemsettings.maxLength(systemsettingmodel.CCSubject(), 100)) {
                            reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_ClientCertificate_Subject_MaxLength });
                            if (focusField == null)
                                focusField = "#txtCCSubject";
                        }

                    }
                }


                if ($("#chkPSSRequire").is(':checked')) {
                    //PSSUsername
                    if (!athoc.iws.systemsettings.isRequired(systemsettingmodel.PSSUsername(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_PSSPollingService_Username_Required });
                        if (focusField == null)
                            focusField = "#txtPSSUsername";
                    }

                    if ((systemsettingmodel.PSSUsername() != "") && ((systemsettingmodel.PSSUsername() != null))) {
                        if (!athoc.iws.systemsettings.maxLength(systemsettingmodel.PSSUsername(), 50)) {
                            reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_PSSPollingService_Username_MaxLength });
                            if (focusField == null)
                                focusField = "#txtPSSUsername";

                        }


                    }

                    //PSSPassword
                    if (!athoc.iws.systemsettings.isRequired(systemsettingmodel.PSSPassword(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_PSSPollingService_Password_Required });
                        if (focusField == null)
                            focusField = "#txtPSSPassword";
                    }

                    if ((systemsettingmodel.PSSPassword() != "") && ((systemsettingmodel.PSSPassword() != null))) {

                        if (!athoc.iws.systemsettings.maxLength(systemsettingmodel.PSSPassword(), 50)) {
                            reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_PSSPollingService_Password_MaxLength });
                            if (focusField == null)
                                focusField = "#txtPSSPassword";

                        }


                    }

                    //PSSUrl
                    if (!athoc.iws.systemsettings.isRequired(systemsettingmodel.PSSUrl(), true)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_PSSPollingService_ServerAddress_Required });
                        if (focusField == null)
                            focusField = "#txtPSSUrl";
                    }

                    if ((systemsettingmodel.PSSUrl() != "") && ((systemsettingmodel.PSSUrl() != null))) {

                        if (!athoc.iws.systemsettings.maxLength(systemsettingmodel.PSSUrl(), 100)) {
                            reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_PSSPollingService_ServerAddress_MaxLength });
                            if (focusField == null)
                                focusField = "#txtPSSUrl";

                        }
                    }
                }


                //EventViewer
                if (!athoc.iws.systemsettings.isRequired(systemsettingmodel.EventViewer(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_EventViewer_Required });
                    if (focusField == null)
                        focusField = "#txtEventViewer";
                }

                if ((systemsettingmodel.EventViewer() != "") && ((systemsettingmodel.EventViewer() != null))) {

                    if (!athoc.iws.systemsettings.maxLength(systemsettingmodel.EventViewer(), 3)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_EventViewer_MaxLength });
                        if (focusField == null)
                            focusField = "#txtEventViewer";

                    }



                    if (isNaN(systemsettingmodel.EventViewer())) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_EventViewer_Required });
                        if (focusField == null)
                            focusField = "#txtEventViewer";
                    }

                    if (systemsettingmodel.EventViewer() <= 0) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_EventViewer_Required });
                        if (focusField == null)
                            focusField = "#txtEventViewer";
                    }

                }




                //GeoHistory
                if (!athoc.iws.systemsettings.isRequired(systemsettingmodel.GeoHistory(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_GeoHistory_Required });
                    if (focusField == null)
                        focusField = "#txtGeoHistory";
                }

                if ((systemsettingmodel.GeoHistory() != "") && ((systemsettingmodel.GeoHistory() != null))) {

                    if (!athoc.iws.systemsettings.maxLength(systemsettingmodel.GeoHistory(), 3)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_GeoHistory_MaxLength });
                        if (focusField == null)
                            focusField = "#txtGeoHistory";

                    }

                    if (isNaN(systemsettingmodel.GeoHistory())) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_GeoHistory_Required });
                        if (focusField == null)
                            focusField = "#txtGeoHistory";

                    }

                    if (systemsettingmodel.GeoHistory() <= 0) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_GeoHistory_Required });
                        if (focusField == null)
                            focusField = "#txtGeoHistory";
                    }

                }

                //DesktopSession
                if (!athoc.iws.systemsettings.isRequired(systemsettingmodel.DesktopSession(), true)) {
                    reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_DesktopSessions_Required });
                    if (focusField == null)
                        focusField = "#txtDesktopSession";
                }

                if ((systemsettingmodel.DesktopSession() != "") && ((systemsettingmodel.DesktopSession() != null))) {

                    if (!athoc.iws.systemsettings.maxLength(systemsettingmodel.DesktopSession(), 3)) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_DesktopSessions_MaxLength });
                        if (focusField == null)
                            focusField = "#txtDesktopSession";

                    }



                    if (isNaN(systemsettingmodel.DesktopSession())) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_DesktopSessions_Required });
                        if (focusField == null)
                            focusField = "#txtDesktopSession";

                    }


                    if (systemsettingmodel.DesktopSession() <= 0) {
                        reqError.push({ Type: '4', Value: athoc.iws.systemsettings.resources.SystemSettings_SystemDataMaintenance_DesktopSessions_Required });
                        if (focusField == null)
                            focusField = "#txtDesktopSession";
                    }
                }




                //pop out the error message 
                if (reqError.length > 0) {
                    $('#saveMessagePanel').messagesPanel({ messages: reqError });
                    $('#saveMessagePanel').css({ display: 'block' });
                    $(focusField).focus();
                    $("html,body").scrollTop(0);
                    return false;
                }
                return true;
            },

            //
            isClientCertificateRequired: function () {
                var isClientCertificate = ko.toJSON(athoc.iws.systemsettings.editModel.systemsettingmodel.CCRequireSettings);
                return isClientCertificate;
            },

            //
            editSubscribeMethods: function () {

                athoc.iws.systemsettings.editModel.systemsettingmodel.Name.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        athoc.iws.systemsettings.isChanged = true;

                        athoc.iws.systemsettings.editModel.systemsettingmodel.Name($.trim(newValue));
                    }
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.SystemUrl.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;

                    athoc.iws.systemsettings.editModel.systemsettingmodel.SystemUrl($.trim(newValue));
                });

                athoc.iws.systemsettings.editModel.systemsettingmodel.DesktopTrafficUrl.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;

                    athoc.iws.systemsettings.editModel.systemsettingmodel.DesktopTrafficUrl($.trim(newValue));
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.DatabaseArchiveDirectory.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;

                    athoc.iws.systemsettings.editModel.systemsettingmodel.DatabaseArchiveDirectory($.trim(newValue));
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.SecurityDisclaimer.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;

                    athoc.iws.systemsettings.editModel.systemsettingmodel.SecurityDisclaimer($.trim(newValue));
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.CCRequireSettings.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;



                    if (!athoc.iws.systemsettings.editModel.systemsettingmodel.CCRequireSettings()) {

                        if (athoc.iws.systemsettings.editModel.systemsettingmodel.CCStoreName() != null) {
                            athoc.iws.systemsettings.StoreNameText = (athoc.iws.systemsettings.getDropdownvalue(athoc.iws.systemsettings.editModel.StoreNameArray(), athoc.iws.systemsettings.editModel.systemsettingmodel.CCStoreName()));

                        }

                        if (athoc.iws.systemsettings.editModel.systemsettingmodel.CCStoreLocation() != null)
                            athoc.iws.systemsettings.StoreLocText = (athoc.iws.systemsettings.getDropdownvalue(athoc.iws.systemsettings.editModel.StoreLocationArray(), athoc.iws.systemsettings.editModel.systemsettingmodel.CCStoreLocation()));

                        if (athoc.iws.systemsettings.editModel.systemsettingmodel.CCSubject() != null)
                            athoc.iws.systemsettings.editModel.systemsettingmodel.CCSubject(athoc.iws.systemsettings.SubjectText)
                    }
                    else {
                        athoc.iws.systemsettings.StoreNameText = "";
                        athoc.iws.systemsettings.StoreLocText = "";
                        $("#ddlStorename").selectpicker();
                        $("#ddlStorelocation").selectpicker();
                    }

                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.CCSubject.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;

                    athoc.iws.systemsettings.editModel.systemsettingmodel.CCSubject($.trim(newValue));
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.CCStoreName.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.CCStoreLocation.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.PSSRequireSettings.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;

                    if (!athoc.iws.systemsettings.editModel.systemsettingmodel.PSSRequireSettings()) {
                        if (athoc.iws.systemsettings.editModel.systemsettingmodel.PSSUsername() != null) {
                            athoc.iws.systemsettings.editModel.systemsettingmodel.PSSUsername(athoc.iws.systemsettings.UserText)
                        }
                        if (athoc.iws.systemsettings.editModel.systemsettingmodel.PSSPassword() != null) {
                            athoc.iws.systemsettings.editModel.systemsettingmodel.PSSPassword(athoc.iws.systemsettings.PassText)
                        }
                        if (athoc.iws.systemsettings.editModel.systemsettingmodel.PSSUrl() != null) {
                            athoc.iws.systemsettings.editModel.systemsettingmodel.PSSUrl(athoc.iws.systemsettings.ServerAddressText)
                        }
                    }
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.PSSUrl.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;
                    athoc.iws.systemsettings.editModel.systemsettingmodel.PSSUrl($.trim(newValue));
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.PSSUsername.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;
                    athoc.iws.systemsettings.editModel.systemsettingmodel.PSSUsername($.trim(newValue));
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.PSSPassword.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;

                    athoc.iws.systemsettings.editModel.systemsettingmodel.PSSPassword($.trim(newValue));
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.EventViewer.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;
                    athoc.iws.systemsettings.editModel.systemsettingmodel.EventViewer($.trim(newValue).replace(" ", ""));
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.DesktopSession.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;
                    athoc.iws.systemsettings.editModel.systemsettingmodel.DesktopSession($.trim(newValue).replace(" ", ""));
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.GeoHistory.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;
                    athoc.iws.systemsettings.editModel.systemsettingmodel.GeoHistory($.trim(newValue).replace(" ", ""));
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.ManagementHelpContent.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;

                    athoc.iws.systemsettings.editModel.systemsettingmodel.ManagementHelpContent($.trim(newValue));
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.SSTourEnabled.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.MgmtTourEnabled.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;
                });
                athoc.iws.systemsettings.editModel.systemsettingmodel.TourAnalyticsEnabled.subscribe(function (newValue) {
                    if ($.trim(newValue) != "")
                        athoc.iws.systemsettings.isChanged = true;
                });

            },

            //
            getDropdownvalue: function (objArray, val) {
                //var obj;
                //_.each(objArray, function (item) {
                //    if (item.value == val)
                //        obj = item.text;

                //});
                //if (obj != null)
                //    return obj;
                //else
                //    return val;
                var obj = _.find(objArray, function (item) {
                    return (item.Value.toLowerCase() == val.toLowerCase());
                });
                if (obj != null)
                    return obj.Text;
                else
                    return val;
            },

            // to open modalpopup of support page content
            ViewEdit: function () {
                $('#dialogSupport').css({ display: 'block' });
                $('#dialogSupport').addClass('width600');
                $('#dialogSupport').modal().css(
                   {
                       'z-index': '3000'
                   });
                $('textarea#txtSupportPageContent').val(athoc.iws.systemsettings.editModel.systemsettingmodel.SupportPageContent());

            },
            errors: null,

        //
        showMessagePanel: function () {
            if ($('body').scrollTop() > 0) {     //Chrome,Safari
                $('body').scrollTop(0);
            } else {
                if ($('html').scrollTop() > 0) { //IE, FF
                    $('html').scrollTop(0);
                }
            }
        },

        // To show erros and handle timeout error
        handleError: function (e) {
            athoc.iws.systemsettings.errors = [];
            if (e != undefined && e.status == 401) {
                window.onbeforeunload = null;
                window.location = window.location;
            } else if (e.errorThrown != "") {
                if (athoc.iws.systemsettings.errors === null) {
                    athoc.iws.systemsettings.errors = [{ Type: '4', Value: e.errorThrown }];
                } else {
                    athoc.iws.systemsettings.errors.push({ Type: '4', Value: e.errorThrown });
                }
                $('#saveMessagePanel').messagesPanel({ messages: this.errors });
                athoc.iws.systemsettings.showMessagePanel();
            }
        },
        };
    }();
}




