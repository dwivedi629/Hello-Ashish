﻿//All the common function are placed here
function submitLogout() {
    //deleteCookie();
    $("#SignOutForm").submit();
}
 
function deleteCookie() {
    var expireAt = new Date;

    expireAt.setMonth(expireAt.getMonth() - 1);
    // retrieve the cookie
    var cookieValue = getCookieByName("AtHoc_CurrentLanguage");
    // Finally, set the cookie’s new expiry date to the past time
    //document.cookie.split(";").forEach(function(c) { document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/;"); });


    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/Client;expires=" + expireAt.toGMTString();
    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/client;expires=" + expireAt.toGMTString();

    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/Client/auth;expires=" + expireAt.toGMTString();
    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/client/auth;expires=" + expireAt.toGMTString();

    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/Client/auth/login;expires=" + expireAt.toGMTString();
    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/client/auth/login;expires=" + expireAt.toGMTString();

    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/athoc-iws;expires=" + expireAt.toGMTString();
    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/AtHoc-IWS;expires=" + expireAt.toGMTString();

    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/athoc-iws/settings;expires=" + expireAt.toGMTString();
    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/athoc-iws/Settings;expires=" + expireAt.toGMTString();


    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/SelfService/Account;expires=" + expireAt.toGMTString();
    document.cookie = "AtHoc_CurrentLanguage" + "=" + cookieValue + "; path=/selfService/account;expires=" + expireAt.toGMTString();
}

function redirectToExternalUrl(url, usePost) {
    // try-catch to handle IE9 error due to use of window.onbeforeunload
    // reference: http://stackoverflow.com/questions/2499886/window-onbeforeunload-and-window-location-href-in-ie
    if (typeof usePost != "undefined" && usePost) {
        var form = $(document.createElement('form')).attr('action', url).attr('method', 'post');
        $('body').append(form);
        $(form).submit();
    } else {
        try {
            window.location.href = url;
        } catch (e) { }
    }
}

function gotoAthoc() {
    var win = window.open('http://www.athoc.com');
    //Some clients doesn't want the map window to be closed whenever page refreshes / main window closes
    //allOpenChildrenWindows.push(win);
}
function closeChildrenWindows() {
    for (i = 0; i < allOpenChildrenWindows.length; i++) {
        allOpenChildrenWindows[i].close();
    }
}

var currentDate = null;
var timerObj = null;

function update() {
    currentDate.setSeconds(currentDate.getSeconds() + 5);
    clearTimeout(timerObj);
    timerObj = setTimeout(update, 5000);
}

$(document).ready(function () {     
    var tabDropdownContainerElm = $(".tab-dropdowncontainer");
    $("html").click(function () {
        tabDropdownContainerElm.hide();
    });
    $(".header-tab,.tab-hotspot").click(function (event) {
        var self = $(this);
        var elm = self.find(".tab-dropdowncontainer");
        if (elm.length == 0) {
            elm = self.closest(".header-tab").find(".tab-dropdowncontainer");
            self = self.closest(".header-tab");
        }
        if (elm.length > 0) {
            $.athocClickTipRemoveAll();
            var isVisible = elm.is(':visible');
            tabDropdownContainerElm.hide();
            if (isVisible == false) {
                var labelElm = self.find('.tab-label');
                var headerTabPosition = self.position().left;
                var caretdropdownPosition = headerTabPosition + (self.outerWidth() / 2) - 8;

                self.find('.caretdropdown').css({ 'left': caretdropdownPosition + 'px' });

                if (self.hasClass("raised")) {
                    self.find('.navdropdown').css('top', '-16px');
                    self.find('.navdropdown').css('position', 'relative');
                    self.find('.caretdropdown').css({ 'left': caretdropdownPosition + 'px' });
                } else {
                    self.find('.caretdropdown').css({ 'left': caretdropdownPosition + 'px' });
                }

                elm.css({ 'left': 5 - headerTabPosition + 'px' });
                elm.toggle();
            }
        }
        event.stopPropagation();
    });

    $(window).resize(function () {
        resizeWalkmePlayer();
    });

    //athoc.iws.switchLanguage.load();
    // $('#selectLanguageModal').append("<div class='modal-backdrop fade in'></div>");

   
});
function walkme_ready() {

    if (getCookie("AtHoc_IWSWalkMeSetLanguage") == "true") {
        var foundLanguage = false;
        var languageToChange = (languageParams.currentCulture + "").toLowerCase();
        var supportedLanguages = WalkMeAPI.getSupportedLanguages();
        for (var i = 0; i < supportedLanguages.length; ++i) {
            if (supportedLanguages[i].shortName == languageToChange) {
                foundLanguage = true;
                break;
            }
        }

        if (foundLanguage) {
            WalkMeAPI.changeLanguage((languageParams.currentCulture + "").toLowerCase());
        } else {
            WalkMeAPI.changeLanguage("");
        }
        document.cookie = 'AtHoc_IWSWalkMeSetLanguage=false; path=/;';
    }
}


function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return "";
}