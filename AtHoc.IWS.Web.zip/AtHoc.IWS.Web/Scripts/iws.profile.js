var profile = (function () {
    return {
        //basePath: "../../../../../",
        //basePath: "C:/Source/svn.athoc.com/athoc/eng/trunk/Platform/DotNet/AtHoc.Pegasus/AtHoc.IWS.Web/Scripts/",
        basePath: arguments[0],
        releaseDir: "Release/Packages",
        action: "release",
        layerOptimize: "closure",
        optimize: "closure",
        cssOptimize: "comments",

        packages: [
            {
                name: "dojo",
                location: environment["user.dir"] + "../../../dojo"
            },
            {
                name: "common",
                location: "Common"
            },
            {
                name: "account",
                location: "Account"
            },
            {
                name: "rule",
                location: "Settings/Rule"
            },
            {
                name: "wam",
                location: "Settings/WAM"
            }
        ],

        layers: {
            "AccountLayer": {
                include: ["account/utils",
                    "account/Event/activity",
                    "account/Event/analysis",
                    "account/Event/dashboard",
                    "account/Event/details",
                    "account/Event/eventEndTimeDialog",
                    "account/Event/grid",
                    "account/Event/manager",
                    "account/Event/Reports/orgBreakdown",
                    "account/Event/responseOvertimeBox",
                    "account/Event/settings",
                    "account/Event/summaryBox",
                    "account/Event/users",
                    "account/Export/exportDialog",
                    "account/Export/exportManager",
                    "account/Template/details",
                    "account/Template/grid",
                    "account/Template/manager",
                    "account/Template/Sections/general",
                    "account/Template/Sections/info",
                    "account/Template/Sections/message",
                    "account/Template/Sections/operator",
                    "account/Template/Sections/process",
                    "account/Template/Sections/userSelection",
                    "account/Template/selectTemplateDialog",
                    "account/Template/reviewAndStartDialog",
                    "account/Template/startEventView"]
            },

            "IWSCommonLayer": {
                include: ["common/advancedSearch/search",
                    "common/advancedSearch/dateRangeSearch",
                    "common/advancedSearch/dropdownSearch",
                    "common/advancedSearch/multiSelectDropdownSearch",
                    "common/advancedSearch/searchPill",
                    "common/advancedSearch/textSearch",
                    "common/advancedSearch/quickFilterSearch",
                    "common/baseView",
                    "common/navigation",
                    "common/dialog",
                    "common/tabs",
                    "common/search",
                    "common/grid",
                    "common/search",
                    "common/confirmationDialog",
                    "common/multiSelectDropdown",
                    "common/singleSelectDropdown",
                    "common/baseGridManager"]
            },

            "IWSRuleLayer": {
                include: ["rule/utils",
                    "rule/ruleDetail",
                    "rule/alert.rules.manager",
                    "wam/grid.WAM",
                    "wam/grid.ds.counties",
                    "wam/wamCondition",
                    "wam/wamGeneral",
                    "wam/wamAction"]
            }
        }
    };
})();