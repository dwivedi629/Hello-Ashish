﻿///#source 1 1 /Scripts/jquery.filedownload.js
/*
* jQuery File Download Plugin v1.4.2 
*
* http://www.johnculviner.com
*
* Copyright (c) 2013 - John Culviner
*
* Licensed under the MIT license:
*   http://www.opensource.org/licenses/mit-license.php
*
* !!!!NOTE!!!!
* You must also write a cookie in conjunction with using this plugin as mentioned in the orignal post:
* http://johnculviner.com/jquery-file-download-plugin-for-ajax-like-feature-rich-file-downloads/
* !!!!NOTE!!!!
*/

(function ($, window) {
    // i'll just put them here to get evaluated on script load
    var htmlSpecialCharsRegEx = /[<>&\r\n"']/gm;
    var htmlSpecialCharsPlaceHolders = {
        '<': 'lt;',
        '>': 'gt;',
        '&': 'amp;',
        '\r': "#13;",
        '\n': "#10;",
        '"': 'quot;',
        "'": 'apos;' /*single quotes just to be safe*/
    };

    $.extend({
        //
        //$.fileDownload('/path/to/url/', options)
        //  see directly below for possible 'options'
        fileDownload: function (fileUrl, options) {
            //provide some reasonable defaults to any unspecified options below
            var settings = $.extend({

                //
                //Requires jQuery UI: provide a message to display to the user when the file download is being prepared before the browser's dialog appears
                //
                preparingMessageHtml: null,

                //
                //Requires jQuery UI: provide a message to display to the user when a file download fails
                //
                failMessageHtml: null,

                //
                //the stock android browser straight up doesn't support file downloads initiated by a non GET: http://code.google.com/p/android/issues/detail?id=1780
                //specify a message here to display if a user tries with an android browser
                //if jQuery UI is installed this will be a dialog, otherwise it will be an alert
                //
                androidPostUnsupportedMessageHtml: "Unfortunately your Android browser doesn't support this type of file download. Please try again with a different browser.",

                //
                //Requires jQuery UI: options to pass into jQuery UI Dialog
                //
                dialogOptions: { modal: true },

                //
                //a function to call while the dowload is being prepared before the browser's dialog appears
                //Args:
                //  url - the original url attempted
                //
                prepareCallback: function (url) { },

                //
                //a function to call after a file download dialog/ribbon has appeared
                //Args:
                //  url - the original url attempted
                //
                successCallback: function (url) { },

                //
                //a function to call after a file download dialog/ribbon has appeared
                //Args:
                //  responseHtml    - the html that came back in response to the file download. this won't necessarily come back depending on the browser.
                //                      in less than IE9 a cross domain error occurs because 500+ errors cause a cross domain issue due to IE subbing out the
                //                      server's error message with a "helpful" IE built in message
                //  url             - the original url attempted
                //
                failCallback: function (responseHtml, url) { },

                //
                // the HTTP method to use. Defaults to "GET".
                //
                httpMethod: "GET",

                //
                // if specified will perform a "httpMethod" request to the specified 'fileUrl' using the specified data.
                // data must be an object (which will be $.param serialized) or already a key=value param string
                //
                data: null,

                //
                //a period in milliseconds to poll to determine if a successful file download has occured or not
                //
                checkInterval: 100,

                //
                //the cookie name to indicate if a file download has occured
                //
                cookieName: "fileDownload",

                //
                //the cookie value for the above name to indicate that a file download has occured
                //
                cookieValue: "true",

                //
                //the cookie path for above name value pair
                //
                cookiePath: "/",

                //
                //the title for the popup second window as a download is processing in the case of a mobile browser
                //
                popupWindowTitle: "Initiating file download...",

                //
                //Functionality to encode HTML entities for a POST, need this if data is an object with properties whose values contains strings with quotation marks.
                //HTML entity encoding is done by replacing all &,<,>,',",\r,\n characters.
                //Note that some browsers will POST the string htmlentity-encoded whilst others will decode it before POSTing.
                //It is recommended that on the server, htmlentity decoding is done irrespective.
                //
                encodeHTMLEntities: true

            }, options);

            var deferred = new $.Deferred();

            //Setup mobile browser detection: Partial credit: http://detectmobilebrowser.com/
            var userAgent = (navigator.userAgent || navigator.vendor || window.opera).toLowerCase();

            var isIos;                  //has full support of features in iOS 4.0+, uses a new window to accomplish this.
            var isAndroid;              //has full support of GET features in 4.0+ by using a new window. Non-GET is completely unsupported by the browser. See above for specifying a message.
            var isOtherMobileBrowser;   //there is no way to reliably guess here so all other mobile devices will GET and POST to the current window.

            if (/ip(ad|hone|od)/.test(userAgent)) {

                isIos = true;

            } else if (userAgent.indexOf('android') !== -1) {

                isAndroid = true;

            } else {

                isOtherMobileBrowser = /avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|playbook|silk|iemobile|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(userAgent) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i.test(userAgent.substr(0, 4));

            }

            var httpMethodUpper = settings.httpMethod.toUpperCase();

            if (isAndroid && httpMethodUpper !== "GET") {
                //the stock android browser straight up doesn't support file downloads initiated by non GET requests: http://code.google.com/p/android/issues/detail?id=1780

                if ($().dialog) {
                    $("<div>").html(settings.androidPostUnsupportedMessageHtml).dialog(settings.dialogOptions);
                } else {
                    alert(settings.androidPostUnsupportedMessageHtml);
                }

                return deferred.reject();
            }

            var $preparingDialog = null;

            var internalCallbacks = {

                onPrepare: function (url) {

                    //wire up a jquery dialog to display the preparing message if specified
                    if (settings.preparingMessageHtml) {

                        $preparingDialog = $("<div>").html(settings.preparingMessageHtml).dialog(settings.dialogOptions);

                    } else if (settings.prepareCallback) {

                        settings.prepareCallback(url);

                    }

                },

                onSuccess: function (url) {

                    //remove the perparing message if it was specified
                    if ($preparingDialog) {
                        $preparingDialog.dialog('close');
                    };

                    settings.successCallback(url);

                    deferred.resolve(url);
                },

                onFail: function (responseHtml, url) {

                    //remove the perparing message if it was specified
                    if ($preparingDialog) {
                        $preparingDialog.dialog('close');
                    };

                    //wire up a jquery dialog to display the fail message if specified
                    if (settings.failMessageHtml) {
                        $("<div>").html(settings.failMessageHtml).dialog(settings.dialogOptions);
                    }

                    settings.failCallback(responseHtml, url);

                    deferred.reject(responseHtml, url);
                }
            };

            internalCallbacks.onPrepare(fileUrl);

            //make settings.data a param string if it exists and isn't already
            if (settings.data !== null && typeof settings.data !== "string") {
                settings.data = $.param(settings.data);
            }


            var $iframe,
                downloadWindow,
                formDoc,
                $form;

            if (httpMethodUpper === "GET") {

                if (settings.data !== null) {
                    //need to merge any fileUrl params with the data object

                    var qsStart = fileUrl.indexOf('?');

                    if (qsStart !== -1) {
                        //we have a querystring in the url

                        if (fileUrl.substring(fileUrl.length - 1) !== "&") {
                            fileUrl = fileUrl + "&";
                        }
                    } else {

                        fileUrl = fileUrl + "?";
                    }

                    fileUrl = fileUrl + settings.data;
                }

                if (isIos || isAndroid) {

                    downloadWindow = window.open(fileUrl);
                    downloadWindow.document.title = settings.popupWindowTitle;
                    window.focus();

                } else if (isOtherMobileBrowser) {

                    window.location(fileUrl);

                } else {

                    //create a temporary iframe that is used to request the fileUrl as a GET request
                    $iframe = $("<iframe>")
                        .hide()
                        .prop("src", fileUrl)
                        .appendTo("body");
                }

            } else {

                var formInnerHtml = "";

                if (settings.data !== null) {

                    $.each(settings.data.replace(/\+/g, ' ').split("&"), function () {

                        var kvp = this.split("=");

                        var key = settings.encodeHTMLEntities ? htmlSpecialCharsEntityEncode(decodeURIComponent(kvp[0])) : decodeURIComponent(kvp[0]);
                        if (key) {
                            var value = settings.encodeHTMLEntities ? htmlSpecialCharsEntityEncode(decodeURIComponent(kvp[1])) : decodeURIComponent(kvp[1]);
                            formInnerHtml += '<input type="hidden" name="' + key + '" value="' + value + '" />';
                        }
                    });
                }

                if (isOtherMobileBrowser) {

                    $form = $("<form>").appendTo("body");
                    $form.hide()
                        .prop('method', settings.httpMethod)
                        .prop('action', fileUrl)
                        .html(formInnerHtml);

                } else {

                    if (isIos) {

                        downloadWindow = window.open("about:blank");
                        downloadWindow.document.title = settings.popupWindowTitle;
                        formDoc = downloadWindow.document;
                        window.focus();

                    } else {

                        $iframe = $("<iframe style='display: none' src='about:blank'></iframe>").appendTo("body");
                        formDoc = getiframeDocument($iframe);
                    }

                    formDoc.write("<html><head></head><body><form method='" + settings.httpMethod + "' action='" + fileUrl + "'>" + formInnerHtml + "</form>" + settings.popupWindowTitle + "</body></html>");
                    $form = $(formDoc).find('form');
                }

                $form.submit();
            }


            //check if the file download has completed every checkInterval ms
            setTimeout(checkFileDownloadComplete, settings.checkInterval);


            function checkFileDownloadComplete() {

                //has the cookie been written due to a file download occuring?
                if (document.cookie.indexOf(settings.cookieName + "=" + settings.cookieValue) != -1) {

                    //execute specified callback
                    internalCallbacks.onSuccess(fileUrl);

                    //remove the cookie and iframe
                    document.cookie = settings.cookieName + "=; expires=" + new Date(1000).toUTCString() + "; path=" + settings.cookiePath;

                    cleanUp(false);

                    return;
                }

                //has an error occured?
                //if neither containers exist below then the file download is occuring on the current window
                if (downloadWindow || $iframe) {

                    //has an error occured?
                    try {

                        var formDoc = downloadWindow ? downloadWindow.document : getiframeDocument($iframe);

                        if (formDoc && formDoc.body != null && formDoc.body.innerHTML.length) {

                            var isFailure = true;

                            if ($form && $form.length) {
                                var $contents = $(formDoc.body).contents().first();

                                if ($contents.length && $contents[0] === $form[0]) {
                                    isFailure = false;
                                }
                            }

                            if (isFailure) {
                                internalCallbacks.onFail(formDoc.body.innerHTML, fileUrl);

                                cleanUp(true);

                                return;
                            }
                        }
                    }
                    catch (err) {

                        //500 error less than IE9
                        internalCallbacks.onFail('', fileUrl);

                        cleanUp(true);

                        return;
                    }
                }


                //keep checking...
                setTimeout(checkFileDownloadComplete, settings.checkInterval);
            }

            //gets an iframes document in a cross browser compatible manner
            function getiframeDocument($iframe) {
                var iframeDoc = $iframe[0].contentWindow || $iframe[0].contentDocument;
                if (iframeDoc.document) {
                    iframeDoc = iframeDoc.document;
                }
                return iframeDoc;
            }

            function cleanUp(isFailure) {

                setTimeout(function () {

                    if (downloadWindow) {

                        if (isAndroid) {
                            downloadWindow.close();
                        }

                        if (isIos) {
                            downloadWindow.focus(); //ios safari bug doesn't allow a window to be closed unless it is focused
                            if (isFailure) {
                                downloadWindow.close();
                            }
                        }
                    }

                    //iframe cleanup appears to randomly cause the download to fail
                    //not doing it seems better than failure...
                    //if ($iframe) {
                    //    $iframe.remove();
                    //}

                }, 0);
            }


            function htmlSpecialCharsEntityEncode(str) {
                return str.replace(htmlSpecialCharsRegEx, function (match) {
                    return '&' + htmlSpecialCharsPlaceHolders[match];
                });
            }

            return deferred.promise();
        }
    });

})(jQuery, this);

///#source 1 1 /Scripts/jquery.iframe-transport.js
/*
 * jQuery Iframe Transport Plugin 1.8.2
 * https://github.com/blueimp/jQuery-File-Upload
 *
 * Copyright 2011, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 */

/* global define, window, document */

(function (factory) {
    'use strict';
    if (typeof define === 'function' && define.amd) {
        // Register as an anonymous AMD module:
        define(['jquery'], factory);
    } else {
        // Browser globals:
        factory(window.jQuery);
    }
}(function ($) {
    'use strict';

    // Helper variable to create unique names for the transport iframes:
    var counter = 0;

    // The iframe transport accepts four additional options:
    // options.fileInput: a jQuery collection of file input fields
    // options.paramName: the parameter name for the file form data,
    //  overrides the name property of the file input field(s),
    //  can be a string or an array of strings.
    // options.formData: an array of objects with name and value properties,
    //  equivalent to the return data of .serializeArray(), e.g.:
    //  [{name: 'a', value: 1}, {name: 'b', value: 2}]
    // options.initialIframeSrc: the URL of the initial iframe src,
    //  by default set to "javascript:false;"
    $.ajaxTransport('iframe', function (options) {
        if (options.async) {
            // javascript:false as initial iframe src
            // prevents warning popups on HTTPS in IE6:
            /*jshint scripturl: true */
            var initialIframeSrc = options.initialIframeSrc || 'javascript:false;',
            /*jshint scripturl: false */
                form,
                iframe,
                addParamChar;
            return {
                send: function (_, completeCallback) {
                    form = $('<form style="display:none;"></form>');
                    form.attr('accept-charset', options.formAcceptCharset);
                    addParamChar = /\?/.test(options.url) ? '&' : '?';
                    // XDomainRequest only supports GET and POST:
                    if (options.type === 'DELETE') {
                        options.url = options.url + addParamChar + '_method=DELETE';
                        options.type = 'POST';
                    } else if (options.type === 'PUT') {
                        options.url = options.url + addParamChar + '_method=PUT';
                        options.type = 'POST';
                    } else if (options.type === 'PATCH') {
                        options.url = options.url + addParamChar + '_method=PATCH';
                        options.type = 'POST';
                    }
                    // IE versions below IE8 cannot set the name property of
                    // elements that have already been added to the DOM,
                    // so we set the name along with the iframe HTML markup:
                    counter += 1;
                    iframe = $(
                        '<iframe src="' + initialIframeSrc +
                            '" name="iframe-transport-' + counter + '"></iframe>'
                    ).bind('load', function () {
                        var fileInputClones,
                            paramNames = $.isArray(options.paramName) ?
                                    options.paramName : [options.paramName];
                        iframe
                            .unbind('load')
                            .bind('load', function () {
                                var response;
                                // Wrap in a try/catch block to catch exceptions thrown
                                // when trying to access cross-domain iframe contents:
                                try {
                                    response = iframe.contents();
                                    // Google Chrome and Firefox do not throw an
                                    // exception when calling iframe.contents() on
                                    // cross-domain requests, so we unify the response:
                                    if (!response.length || !response[0].firstChild) {
                                        throw new Error();
                                    }
                                } catch (e) {
                                    response = undefined;
                                }
                                // The complete callback returns the
                                // iframe content document as response object:
                                completeCallback(
                                    200,
                                    'success',
                                    {'iframe': response}
                                );
                                // Fix for IE endless progress bar activity bug
                                // (happens on form submits to iframe targets):
                                $('<iframe src="' + initialIframeSrc + '"></iframe>')
                                    .appendTo(form);
                                window.setTimeout(function () {
                                    // Removing the form in a setTimeout call
                                    // allows Chrome's developer tools to display
                                    // the response result
                                    form.remove();
                                }, 0);
                            });
                        form
                            .prop('target', iframe.prop('name'))
                            .prop('action', options.url)
                            .prop('method', options.type);
                        if (options.formData) {
                            $.each(options.formData, function (index, field) {
                                $('<input type="hidden"/>')
                                    .prop('name', field.name)
                                    .val(field.value)
                                    .appendTo(form);
                            });
                        }
                        if (options.fileInput && options.fileInput.length &&
                                options.type === 'POST') {
                            fileInputClones = options.fileInput.clone();
                            // Insert a clone for each file input field:
                            options.fileInput.after(function (index) {
                                return fileInputClones[index];
                            });
                            if (options.paramName) {
                                options.fileInput.each(function (index) {
                                    $(this).prop(
                                        'name',
                                        paramNames[index] || options.paramName
                                    );
                                });
                            }
                            // Appending the file input fields to the hidden form
                            // removes them from their original location:
                            form
                                .append(options.fileInput)
                                .prop('enctype', 'multipart/form-data')
                                // enctype must be set as encoding for IE:
                                .prop('encoding', 'multipart/form-data');
                            // Remove the HTML5 form attribute from the input(s):
                            options.fileInput.removeAttr('form');
                        }
                        form.submit();
                        // Insert the file input fields at their original location
                        // by replacing the clones with the originals:
                        if (fileInputClones && fileInputClones.length) {
                            options.fileInput.each(function (index, input) {
                                var clone = $(fileInputClones[index]);
                                // Restore the original name and form properties:
                                $(input)
                                    .prop('name', clone.prop('name'))
                                    .attr('form', clone.attr('form'));
                                clone.replaceWith(input);
                            });
                        }
                    });
                    form.append(iframe).appendTo(document.body);
                },
                abort: function () {
                    if (iframe) {
                        // javascript:false as iframe src aborts the request
                        // and prevents warning popups on HTTPS in IE6.
                        // concat is used to avoid the "Script URL" JSLint error:
                        iframe
                            .unbind('load')
                            .prop('src', initialIframeSrc);
                    }
                    if (form) {
                        form.remove();
                    }
                }
            };
        }
    });

    // The iframe transport returns the iframe content document as response.
    // The following adds converters from iframe to text, json, html, xml
    // and script.
    // Please note that the Content-Type for JSON responses has to be text/plain
    // or text/html, if the browser doesn't include application/json in the
    // Accept header, else IE will show a download dialog.
    // The Content-Type for XML responses on the other hand has to be always
    // application/xml or text/xml, so IE properly parses the XML response.
    // See also
    // https://github.com/blueimp/jQuery-File-Upload/wiki/Setup#content-type-negotiation
    $.ajaxSetup({
        converters: {
            'iframe text': function (iframe) {
                return iframe && $(iframe[0].body).text();
            },
            'iframe json': function (iframe) {
                return iframe && $.parseJSON($(iframe[0].body).text());
            },
            'iframe html': function (iframe) {
                return iframe && $(iframe[0].body).html();
            },
            'iframe xml': function (iframe) {
                var xmlDoc = iframe && iframe[0];
                return xmlDoc && $.isXMLDoc(xmlDoc) ? xmlDoc :
                        $.parseXML((xmlDoc.XMLDocument && xmlDoc.XMLDocument.xml) ||
                            $(xmlDoc.body).html());
            },
            'iframe script': function (iframe) {
                return iframe && $.globalEval($(iframe[0].body).text());
            }
        }
    });

}));

///#source 1 1 /Scripts/jquery.fileupload.js
/*
 * jQuery File Upload Plugin 5.40.0
 * https://github.com/blueimp/jQuery-File-Upload
 *
 * Copyright 2010, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 */

/* jshint nomen:false */
/* global define, window, document, location, Blob, FormData */

(function (factory) {
    'use strict';
    if (typeof define === 'function' && define.amd) {
        // Register as an anonymous AMD module:
        define([
            'jquery',
            'jquery.ui.widget'
        ], factory);
    } else {
        // Browser globals:
        factory(window.jQuery);
    }
}(function ($) {
    'use strict';

    // Detect file input support, based on
    // http://viljamis.com/blog/2012/file-upload-support-on-mobile/
    $.support.fileInput = !(new RegExp(
        // Handle devices which give false positives for the feature detection:
        '(Android (1\\.[0156]|2\\.[01]))' +
            '|(Windows Phone (OS 7|8\\.0))|(XBLWP)|(ZuneWP)|(WPDesktop)' +
            '|(w(eb)?OSBrowser)|(webOS)' +
            '|(Kindle/(1\\.0|2\\.[05]|3\\.0))'
    ).test(window.navigator.userAgent) ||
        // Feature detection for all other devices:
        $('<input type="file">').prop('disabled'));

    // The FileReader API is not actually used, but works as feature detection,
    // as some Safari versions (5?) support XHR file uploads via the FormData API,
    // but not non-multipart XHR file uploads.
    // window.XMLHttpRequestUpload is not available on IE10, so we check for
    // window.ProgressEvent instead to detect XHR2 file upload capability:
    $.support.xhrFileUpload = !!(window.ProgressEvent && window.FileReader);
    $.support.xhrFormDataFileUpload = !!window.FormData;

    // Detect support for Blob slicing (required for chunked uploads):
    $.support.blobSlice = window.Blob && (Blob.prototype.slice ||
        Blob.prototype.webkitSlice || Blob.prototype.mozSlice);

    // The fileupload widget listens for change events on file input fields defined
    // via fileInput setting and paste or drop events of the given dropZone.
    // In addition to the default jQuery Widget methods, the fileupload widget
    // exposes the "add" and "send" methods, to add or directly send files using
    // the fileupload API.
    // By default, files added via file input selection, paste, drag & drop or
    // "add" method are uploaded immediately, but it is possible to override
    // the "add" callback option to queue file uploads.
    $.widget('blueimp.fileupload', {

        options: {
            // The drop target element(s), by the default the complete document.
            // Set to null to disable drag & drop support:
            dropZone: $(document),
            // The paste target element(s), by the default the complete document.
            // Set to null to disable paste support:
            pasteZone: $(document),
            // The file input field(s), that are listened to for change events.
            // If undefined, it is set to the file input fields inside
            // of the widget element on plugin initialization.
            // Set to null to disable the change listener.
            fileInput: undefined,
            // By default, the file input field is replaced with a clone after
            // each input field change event. This is required for iframe transport
            // queues and allows change events to be fired for the same file
            // selection, but can be disabled by setting the following option to false:
            replaceFileInput: true,
            // The parameter name for the file form data (the request argument name).
            // If undefined or empty, the name property of the file input field is
            // used, or "files[]" if the file input name property is also empty,
            // can be a string or an array of strings:
            paramName: undefined,
            // By default, each file of a selection is uploaded using an individual
            // request for XHR type uploads. Set to false to upload file
            // selections in one request each:
            singleFileUploads: true,
            // To limit the number of files uploaded with one XHR request,
            // set the following option to an integer greater than 0:
            limitMultiFileUploads: undefined,
            // The following option limits the number of files uploaded with one
            // XHR request to keep the request size under or equal to the defined
            // limit in bytes:
            limitMultiFileUploadSize: undefined,
            // Multipart file uploads add a number of bytes to each uploaded file,
            // therefore the following option adds an overhead for each file used
            // in the limitMultiFileUploadSize configuration:
            limitMultiFileUploadSizeOverhead: 512,
            // Set the following option to true to issue all file upload requests
            // in a sequential order:
            sequentialUploads: false,
            // To limit the number of concurrent uploads,
            // set the following option to an integer greater than 0:
            limitConcurrentUploads: undefined,
            // Set the following option to true to force iframe transport uploads:
            forceIframeTransport: false,
            // Set the following option to the location of a redirect url on the
            // origin server, for cross-domain iframe transport uploads:
            redirect: undefined,
            // The parameter name for the redirect url, sent as part of the form
            // data and set to 'redirect' if this option is empty:
            redirectParamName: undefined,
            // Set the following option to the location of a postMessage window,
            // to enable postMessage transport uploads:
            postMessage: undefined,
            // By default, XHR file uploads are sent as multipart/form-data.
            // The iframe transport is always using multipart/form-data.
            // Set to false to enable non-multipart XHR uploads:
            multipart: true,
            // To upload large files in smaller chunks, set the following option
            // to a preferred maximum chunk size. If set to 0, null or undefined,
            // or the browser does not support the required Blob API, files will
            // be uploaded as a whole.
            maxChunkSize: undefined,
            // When a non-multipart upload or a chunked multipart upload has been
            // aborted, this option can be used to resume the upload by setting
            // it to the size of the already uploaded bytes. This option is most
            // useful when modifying the options object inside of the "add" or
            // "send" callbacks, as the options are cloned for each file upload.
            uploadedBytes: undefined,
            // By default, failed (abort or error) file uploads are removed from the
            // global progress calculation. Set the following option to false to
            // prevent recalculating the global progress data:
            recalculateProgress: true,
            // Interval in milliseconds to calculate and trigger progress events:
            progressInterval: 100,
            // Interval in milliseconds to calculate progress bitrate:
            bitrateInterval: 500,
            // By default, uploads are started automatically when adding files:
            autoUpload: true,

            // Error and info messages:
            messages: {
                uploadedBytes: 'Uploaded bytes exceed file size'
            },

            // Translation function, gets the message key to be translated
            // and an object with context specific data as arguments:
            i18n: function (message, context) {
                message = this.messages[message] || message.toString();
                if (context) {
                    $.each(context, function (key, value) {
                        message = message.replace('{' + key + '}', value);
                    });
                }
                return message;
            },

            // Additional form data to be sent along with the file uploads can be set
            // using this option, which accepts an array of objects with name and
            // value properties, a function returning such an array, a FormData
            // object (for XHR file uploads), or a simple object.
            // The form of the first fileInput is given as parameter to the function:
            formData: function (form) {
                return form.serializeArray();
            },

            // The add callback is invoked as soon as files are added to the fileupload
            // widget (via file input selection, drag & drop, paste or add API call).
            // If the singleFileUploads option is enabled, this callback will be
            // called once for each file in the selection for XHR file uploads, else
            // once for each file selection.
            //
            // The upload starts when the submit method is invoked on the data parameter.
            // The data object contains a files property holding the added files
            // and allows you to override plugin options as well as define ajax settings.
            //
            // Listeners for this callback can also be bound the following way:
            // .bind('fileuploadadd', func);
            //
            // data.submit() returns a Promise object and allows to attach additional
            // handlers using jQuery's Deferred callbacks:
            // data.submit().done(func).fail(func).always(func);
            add: function (e, data) {
                if (e.isDefaultPrevented()) {
                    return false;
                }
                if (data.autoUpload || (data.autoUpload !== false &&
                        $(this).fileupload('option', 'autoUpload'))) {
                    data.process().done(function () {
                        data.submit();
                    });
                }
            },

            // Other callbacks:

            // Callback for the submit event of each file upload:
            // submit: function (e, data) {}, // .bind('fileuploadsubmit', func);

            // Callback for the start of each file upload request:
            // send: function (e, data) {}, // .bind('fileuploadsend', func);

            // Callback for successful uploads:
            // done: function (e, data) {}, // .bind('fileuploaddone', func);

            // Callback for failed (abort or error) uploads:
            // fail: function (e, data) {}, // .bind('fileuploadfail', func);

            // Callback for completed (success, abort or error) requests:
            // always: function (e, data) {}, // .bind('fileuploadalways', func);

            // Callback for upload progress events:
            // progress: function (e, data) {}, // .bind('fileuploadprogress', func);

            // Callback for global upload progress events:
            // progressall: function (e, data) {}, // .bind('fileuploadprogressall', func);

            // Callback for uploads start, equivalent to the global ajaxStart event:
            // start: function (e) {}, // .bind('fileuploadstart', func);

            // Callback for uploads stop, equivalent to the global ajaxStop event:
            // stop: function (e) {}, // .bind('fileuploadstop', func);

            // Callback for change events of the fileInput(s):
            // change: function (e, data) {}, // .bind('fileuploadchange', func);

            // Callback for paste events to the pasteZone(s):
            // paste: function (e, data) {}, // .bind('fileuploadpaste', func);

            // Callback for drop events of the dropZone(s):
            // drop: function (e, data) {}, // .bind('fileuploaddrop', func);

            // Callback for dragover events of the dropZone(s):
            // dragover: function (e) {}, // .bind('fileuploaddragover', func);

            // Callback for the start of each chunk upload request:
            // chunksend: function (e, data) {}, // .bind('fileuploadchunksend', func);

            // Callback for successful chunk uploads:
            // chunkdone: function (e, data) {}, // .bind('fileuploadchunkdone', func);

            // Callback for failed (abort or error) chunk uploads:
            // chunkfail: function (e, data) {}, // .bind('fileuploadchunkfail', func);

            // Callback for completed (success, abort or error) chunk upload requests:
            // chunkalways: function (e, data) {}, // .bind('fileuploadchunkalways', func);

            // The plugin options are used as settings object for the ajax calls.
            // The following are jQuery ajax settings required for the file uploads:
            processData: false,
            contentType: false,
            cache: false
        },

        // A list of options that require reinitializing event listeners and/or
        // special initialization code:
        _specialOptions: [
            'fileInput',
            'dropZone',
            'pasteZone',
            'multipart',
            'forceIframeTransport'
        ],

        _blobSlice: $.support.blobSlice && function () {
            var slice = this.slice || this.webkitSlice || this.mozSlice;
            return slice.apply(this, arguments);
        },

        _BitrateTimer: function () {
            this.timestamp = ((Date.now) ? Date.now() : (new Date()).getTime());
            this.loaded = 0;
            this.bitrate = 0;
            this.getBitrate = function (now, loaded, interval) {
                var timeDiff = now - this.timestamp;
                if (!this.bitrate || !interval || timeDiff > interval) {
                    this.bitrate = (loaded - this.loaded) * (1000 / timeDiff) * 8;
                    this.loaded = loaded;
                    this.timestamp = now;
                }
                return this.bitrate;
            };
        },

        _isXHRUpload: function (options) {
            return !options.forceIframeTransport &&
                ((!options.multipart && $.support.xhrFileUpload) ||
                $.support.xhrFormDataFileUpload);
        },

        _getFormData: function (options) {
            var formData;
            if ($.type(options.formData) === 'function') {
                return options.formData(options.form);
            }
            if ($.isArray(options.formData)) {
                return options.formData;
            }
            if ($.type(options.formData) === 'object') {
                formData = [];
                $.each(options.formData, function (name, value) {
                    formData.push({name: name, value: value});
                });
                return formData;
            }
            return [];
        },

        _getTotal: function (files) {
            var total = 0;
            $.each(files, function (index, file) {
                total += file.size || 1;
            });
            return total;
        },

        _initProgressObject: function (obj) {
            var progress = {
                loaded: 0,
                total: 0,
                bitrate: 0
            };
            if (obj._progress) {
                $.extend(obj._progress, progress);
            } else {
                obj._progress = progress;
            }
        },

        _initResponseObject: function (obj) {
            var prop;
            if (obj._response) {
                for (prop in obj._response) {
                    if (obj._response.hasOwnProperty(prop)) {
                        delete obj._response[prop];
                    }
                }
            } else {
                obj._response = {};
            }
        },

        _onProgress: function (e, data) {
            if (e.lengthComputable) {
                var now = ((Date.now) ? Date.now() : (new Date()).getTime()),
                    loaded;
                if (data._time && data.progressInterval &&
                        (now - data._time < data.progressInterval) &&
                        e.loaded !== e.total) {
                    return;
                }
                data._time = now;
                loaded = Math.floor(
                    e.loaded / e.total * (data.chunkSize || data._progress.total)
                ) + (data.uploadedBytes || 0);
                // Add the difference from the previously loaded state
                // to the global loaded counter:
                this._progress.loaded += (loaded - data._progress.loaded);
                this._progress.bitrate = this._bitrateTimer.getBitrate(
                    now,
                    this._progress.loaded,
                    data.bitrateInterval
                );
                data._progress.loaded = data.loaded = loaded;
                data._progress.bitrate = data.bitrate = data._bitrateTimer.getBitrate(
                    now,
                    loaded,
                    data.bitrateInterval
                );
                // Trigger a custom progress event with a total data property set
                // to the file size(s) of the current upload and a loaded data
                // property calculated accordingly:
                this._trigger(
                    'progress',
                    $.Event('progress', {delegatedEvent: e}),
                    data
                );
                // Trigger a global progress event for all current file uploads,
                // including ajax calls queued for sequential file uploads:
                this._trigger(
                    'progressall',
                    $.Event('progressall', {delegatedEvent: e}),
                    this._progress
                );
            }
        },

        _initProgressListener: function (options) {
            var that = this,
                xhr = options.xhr ? options.xhr() : $.ajaxSettings.xhr();
            // Accesss to the native XHR object is required to add event listeners
            // for the upload progress event:
            if (xhr.upload) {
                $(xhr.upload).bind('progress', function (e) {
                    var oe = e.originalEvent;
                    // Make sure the progress event properties get copied over:
                    e.lengthComputable = oe.lengthComputable;
                    e.loaded = oe.loaded;
                    e.total = oe.total;
                    that._onProgress(e, options);
                });
                options.xhr = function () {
                    return xhr;
                };
            }
        },

        _isInstanceOf: function (type, obj) {
            // Cross-frame instanceof check
            return Object.prototype.toString.call(obj) === '[object ' + type + ']';
        },

        _initXHRData: function (options) {
            var that = this,
                formData,
                file = options.files[0],
                // Ignore non-multipart setting if not supported:
                multipart = options.multipart || !$.support.xhrFileUpload,
                paramName = $.type(options.paramName) === 'array' ?
                    options.paramName[0] : options.paramName;
            options.headers = $.extend({}, options.headers);
            if (options.contentRange) {
                options.headers['Content-Range'] = options.contentRange;
            }
            if (!multipart || options.blob || !this._isInstanceOf('File', file)) {
                options.headers['Content-Disposition'] = 'attachment; filename="' +
                    encodeURI(file.name) + '"';
            }
            if (!multipart) {
                options.contentType = file.type || 'application/octet-stream';
                options.data = options.blob || file;
            } else if ($.support.xhrFormDataFileUpload) {
                if (options.postMessage) {
                    // window.postMessage does not allow sending FormData
                    // objects, so we just add the File/Blob objects to
                    // the formData array and let the postMessage window
                    // create the FormData object out of this array:
                    formData = this._getFormData(options);
                    if (options.blob) {
                        formData.push({
                            name: paramName,
                            value: options.blob
                        });
                    } else {
                        $.each(options.files, function (index, file) {
                            formData.push({
                                name: ($.type(options.paramName) === 'array' &&
                                    options.paramName[index]) || paramName,
                                value: file
                            });
                        });
                    }
                } else {
                    if (that._isInstanceOf('FormData', options.formData)) {
                        formData = options.formData;
                    } else {
                        formData = new FormData();
                        $.each(this._getFormData(options), function (index, field) {
                            formData.append(field.name, field.value);
                        });
                    }
                    if (options.blob) {
                        formData.append(paramName, options.blob, file.name);
                    } else {
                        $.each(options.files, function (index, file) {
                            // This check allows the tests to run with
                            // dummy objects:
                            if (that._isInstanceOf('File', file) ||
                                    that._isInstanceOf('Blob', file)) {
                                formData.append(
                                    ($.type(options.paramName) === 'array' &&
                                        options.paramName[index]) || paramName,
                                    file,
                                    file.uploadName || file.name
                                );
                            }
                        });
                    }
                }
                options.data = formData;
            }
            // Blob reference is not needed anymore, free memory:
            options.blob = null;
        },

        _initIframeSettings: function (options) {
            var targetHost = $('<a></a>').prop('href', options.url).prop('host');
            // Setting the dataType to iframe enables the iframe transport:
            options.dataType = 'iframe ' + (options.dataType || '');
            // The iframe transport accepts a serialized array as form data:
            options.formData = this._getFormData(options);
            // Add redirect url to form data on cross-domain uploads:
            if (options.redirect && targetHost && targetHost !== location.host) {
                options.formData.push({
                    name: options.redirectParamName || 'redirect',
                    value: options.redirect
                });
            }
        },

        _initDataSettings: function (options) {
            if (this._isXHRUpload(options)) {
                if (!this._chunkedUpload(options, true)) {
                    if (!options.data) {
                        this._initXHRData(options);
                    }
                    this._initProgressListener(options);
                }
                if (options.postMessage) {
                    // Setting the dataType to postmessage enables the
                    // postMessage transport:
                    options.dataType = 'postmessage ' + (options.dataType || '');
                }
            } else {
                this._initIframeSettings(options);
            }
        },

        _getParamName: function (options) {
            var fileInput = $(options.fileInput),
                paramName = options.paramName;
            if (!paramName) {
                paramName = [];
                fileInput.each(function () {
                    var input = $(this),
                        name = input.prop('name') || 'files[]',
                        i = (input.prop('files') || [1]).length;
                    while (i) {
                        paramName.push(name);
                        i -= 1;
                    }
                });
                if (!paramName.length) {
                    paramName = [fileInput.prop('name') || 'files[]'];
                }
            } else if (!$.isArray(paramName)) {
                paramName = [paramName];
            }
            return paramName;
        },

        _initFormSettings: function (options) {
            // Retrieve missing options from the input field and the
            // associated form, if available:
            if (!options.form || !options.form.length) {
                options.form = $(options.fileInput.prop('form'));
                // If the given file input doesn't have an associated form,
                // use the default widget file input's form:
                if (!options.form.length) {
                    options.form = $(this.options.fileInput.prop('form'));
                }
            }
            options.paramName = this._getParamName(options);
            if (!options.url) {
                options.url = options.form.prop('action') || location.href;
            }
            // The HTTP request method must be "POST" or "PUT":
            options.type = (options.type ||
                ($.type(options.form.prop('method')) === 'string' &&
                    options.form.prop('method')) || ''
                ).toUpperCase();
            if (options.type !== 'POST' && options.type !== 'PUT' &&
                    options.type !== 'PATCH') {
                options.type = 'POST';
            }
            if (!options.formAcceptCharset) {
                options.formAcceptCharset = options.form.attr('accept-charset');
            }
        },

        _getAJAXSettings: function (data) {
            var options = $.extend({}, this.options, data);
            this._initFormSettings(options);
            this._initDataSettings(options);
            return options;
        },

        // jQuery 1.6 doesn't provide .state(),
        // while jQuery 1.8+ removed .isRejected() and .isResolved():
        _getDeferredState: function (deferred) {
            if (deferred.state) {
                return deferred.state();
            }
            if (deferred.isResolved()) {
                return 'resolved';
            }
            if (deferred.isRejected()) {
                return 'rejected';
            }
            return 'pending';
        },

        // Maps jqXHR callbacks to the equivalent
        // methods of the given Promise object:
        _enhancePromise: function (promise) {
            promise.success = promise.done;
            promise.error = promise.fail;
            promise.complete = promise.always;
            return promise;
        },

        // Creates and returns a Promise object enhanced with
        // the jqXHR methods abort, success, error and complete:
        _getXHRPromise: function (resolveOrReject, context, args) {
            var dfd = $.Deferred(),
                promise = dfd.promise();
            context = context || this.options.context || promise;
            if (resolveOrReject === true) {
                dfd.resolveWith(context, args);
            } else if (resolveOrReject === false) {
                dfd.rejectWith(context, args);
            }
            promise.abort = dfd.promise;
            return this._enhancePromise(promise);
        },

        // Adds convenience methods to the data callback argument:
        _addConvenienceMethods: function (e, data) {
            var that = this,
                getPromise = function (args) {
                    return $.Deferred().resolveWith(that, args).promise();
                };
            data.process = function (resolveFunc, rejectFunc) {
                if (resolveFunc || rejectFunc) {
                    data._processQueue = this._processQueue =
                        (this._processQueue || getPromise([this])).pipe(
                            function () {
                                if (data.errorThrown) {
                                    return $.Deferred()
                                        .rejectWith(that, [data]).promise();
                                }
                                return getPromise(arguments);
                            }
                        ).pipe(resolveFunc, rejectFunc);
                }
                return this._processQueue || getPromise([this]);
            };
            data.submit = function () {
                if (this.state() !== 'pending') {
                    data.jqXHR = this.jqXHR =
                        (that._trigger(
                            'submit',
                            $.Event('submit', {delegatedEvent: e}),
                            this
                        ) !== false) && that._onSend(e, this);
                }
                return this.jqXHR || that._getXHRPromise();
            };
            data.abort = function () {
                if (this.jqXHR) {
                    return this.jqXHR.abort();
                }
                this.errorThrown = 'abort';
                that._trigger('fail', null, this);
                return that._getXHRPromise(false);
            };
            data.state = function () {
                if (this.jqXHR) {
                    return that._getDeferredState(this.jqXHR);
                }
                if (this._processQueue) {
                    return that._getDeferredState(this._processQueue);
                }
            };
            data.processing = function () {
                return !this.jqXHR && this._processQueue && that
                    ._getDeferredState(this._processQueue) === 'pending';
            };
            data.progress = function () {
                return this._progress;
            };
            data.response = function () {
                return this._response;
            };
        },

        // Parses the Range header from the server response
        // and returns the uploaded bytes:
        _getUploadedBytes: function (jqXHR) {
            var range = jqXHR.getResponseHeader('Range'),
                parts = range && range.split('-'),
                upperBytesPos = parts && parts.length > 1 &&
                    parseInt(parts[1], 10);
            return upperBytesPos && upperBytesPos + 1;
        },

        // Uploads a file in multiple, sequential requests
        // by splitting the file up in multiple blob chunks.
        // If the second parameter is true, only tests if the file
        // should be uploaded in chunks, but does not invoke any
        // upload requests:
        _chunkedUpload: function (options, testOnly) {
            options.uploadedBytes = options.uploadedBytes || 0;
            var that = this,
                file = options.files[0],
                fs = file.size,
                ub = options.uploadedBytes,
                mcs = options.maxChunkSize || fs,
                slice = this._blobSlice,
                dfd = $.Deferred(),
                promise = dfd.promise(),
                jqXHR,
                upload;
            if (!(this._isXHRUpload(options) && slice && (ub || mcs < fs)) ||
                    options.data) {
                return false;
            }
            if (testOnly) {
                return true;
            }
            if (ub >= fs) {
                file.error = options.i18n('uploadedBytes');
                return this._getXHRPromise(
                    false,
                    options.context,
                    [null, 'error', file.error]
                );
            }
            // The chunk upload method:
            upload = function () {
                // Clone the options object for each chunk upload:
                var o = $.extend({}, options),
                    currentLoaded = o._progress.loaded;
                o.blob = slice.call(
                    file,
                    ub,
                    ub + mcs,
                    file.type
                );
                // Store the current chunk size, as the blob itself
                // will be dereferenced after data processing:
                o.chunkSize = o.blob.size;
                // Expose the chunk bytes position range:
                o.contentRange = 'bytes ' + ub + '-' +
                    (ub + o.chunkSize - 1) + '/' + fs;
                // Process the upload data (the blob and potential form data):
                that._initXHRData(o);
                // Add progress listeners for this chunk upload:
                that._initProgressListener(o);
                jqXHR = ((that._trigger('chunksend', null, o) !== false && $.ajax(o)) ||
                        that._getXHRPromise(false, o.context))
                    .done(function (result, textStatus, jqXHR) {
                        ub = that._getUploadedBytes(jqXHR) ||
                            (ub + o.chunkSize);
                        // Create a progress event if no final progress event
                        // with loaded equaling total has been triggered
                        // for this chunk:
                        if (currentLoaded + o.chunkSize - o._progress.loaded) {
                            that._onProgress($.Event('progress', {
                                lengthComputable: true,
                                loaded: ub - o.uploadedBytes,
                                total: ub - o.uploadedBytes
                            }), o);
                        }
                        options.uploadedBytes = o.uploadedBytes = ub;
                        o.result = result;
                        o.textStatus = textStatus;
                        o.jqXHR = jqXHR;
                        that._trigger('chunkdone', null, o);
                        that._trigger('chunkalways', null, o);
                        if (ub < fs) {
                            // File upload not yet complete,
                            // continue with the next chunk:
                            upload();
                        } else {
                            dfd.resolveWith(
                                o.context,
                                [result, textStatus, jqXHR]
                            );
                        }
                    })
                    .fail(function (jqXHR, textStatus, errorThrown) {
                        o.jqXHR = jqXHR;
                        o.textStatus = textStatus;
                        o.errorThrown = errorThrown;
                        that._trigger('chunkfail', null, o);
                        that._trigger('chunkalways', null, o);
                        dfd.rejectWith(
                            o.context,
                            [jqXHR, textStatus, errorThrown]
                        );
                    });
            };
            this._enhancePromise(promise);
            promise.abort = function () {
                return jqXHR.abort();
            };
            upload();
            return promise;
        },

        _beforeSend: function (e, data) {
            if (this._active === 0) {
                // the start callback is triggered when an upload starts
                // and no other uploads are currently running,
                // equivalent to the global ajaxStart event:
                this._trigger('start');
                // Set timer for global bitrate progress calculation:
                this._bitrateTimer = new this._BitrateTimer();
                // Reset the global progress values:
                this._progress.loaded = this._progress.total = 0;
                this._progress.bitrate = 0;
            }
            // Make sure the container objects for the .response() and
            // .progress() methods on the data object are available
            // and reset to their initial state:
            this._initResponseObject(data);
            this._initProgressObject(data);
            data._progress.loaded = data.loaded = data.uploadedBytes || 0;
            data._progress.total = data.total = this._getTotal(data.files) || 1;
            data._progress.bitrate = data.bitrate = 0;
            this._active += 1;
            // Initialize the global progress values:
            this._progress.loaded += data.loaded;
            this._progress.total += data.total;
        },

        _onDone: function (result, textStatus, jqXHR, options) {
            var total = options._progress.total,
                response = options._response;
            if (options._progress.loaded < total) {
                // Create a progress event if no final progress event
                // with loaded equaling total has been triggered:
                this._onProgress($.Event('progress', {
                    lengthComputable: true,
                    loaded: total,
                    total: total
                }), options);
            }
            response.result = options.result = result;
            response.textStatus = options.textStatus = textStatus;
            response.jqXHR = options.jqXHR = jqXHR;
            this._trigger('done', null, options);
        },

        _onFail: function (jqXHR, textStatus, errorThrown, options) {
            var response = options._response;
            if (options.recalculateProgress) {
                // Remove the failed (error or abort) file upload from
                // the global progress calculation:
                this._progress.loaded -= options._progress.loaded;
                this._progress.total -= options._progress.total;
            }
            response.jqXHR = options.jqXHR = jqXHR;
            response.textStatus = options.textStatus = textStatus;
            response.errorThrown = options.errorThrown = errorThrown;
            this._trigger('fail', null, options);
        },

        _onAlways: function (jqXHRorResult, textStatus, jqXHRorError, options) {
            // jqXHRorResult, textStatus and jqXHRorError are added to the
            // options object via done and fail callbacks
            this._trigger('always', null, options);
        },

        _onSend: function (e, data) {
            if (!data.submit) {
                this._addConvenienceMethods(e, data);
            }
            var that = this,
                jqXHR,
                aborted,
                slot,
                pipe,
                options = that._getAJAXSettings(data),
                send = function () {
                    that._sending += 1;
                    // Set timer for bitrate progress calculation:
                    options._bitrateTimer = new that._BitrateTimer();
                    jqXHR = jqXHR || (
                        ((aborted || that._trigger(
                            'send',
                            $.Event('send', {delegatedEvent: e}),
                            options
                        ) === false) &&
                        that._getXHRPromise(false, options.context, aborted)) ||
                        that._chunkedUpload(options) || $.ajax(options)
                    ).done(function (result, textStatus, jqXHR) {
                        that._onDone(result, textStatus, jqXHR, options);
                    }).fail(function (jqXHR, textStatus, errorThrown) {
                        that._onFail(jqXHR, textStatus, errorThrown, options);
                    }).always(function (jqXHRorResult, textStatus, jqXHRorError) {
                        that._onAlways(
                            jqXHRorResult,
                            textStatus,
                            jqXHRorError,
                            options
                        );
                        that._sending -= 1;
                        that._active -= 1;
                        if (options.limitConcurrentUploads &&
                                options.limitConcurrentUploads > that._sending) {
                            // Start the next queued upload,
                            // that has not been aborted:
                            var nextSlot = that._slots.shift();
                            while (nextSlot) {
                                if (that._getDeferredState(nextSlot) === 'pending') {
                                    nextSlot.resolve();
                                    break;
                                }
                                nextSlot = that._slots.shift();
                            }
                        }
                        if (that._active === 0) {
                            // The stop callback is triggered when all uploads have
                            // been completed, equivalent to the global ajaxStop event:
                            that._trigger('stop');
                        }
                    });
                    return jqXHR;
                };
            this._beforeSend(e, options);
            if (this.options.sequentialUploads ||
                    (this.options.limitConcurrentUploads &&
                    this.options.limitConcurrentUploads <= this._sending)) {
                if (this.options.limitConcurrentUploads > 1) {
                    slot = $.Deferred();
                    this._slots.push(slot);
                    pipe = slot.pipe(send);
                } else {
                    this._sequence = this._sequence.pipe(send, send);
                    pipe = this._sequence;
                }
                // Return the piped Promise object, enhanced with an abort method,
                // which is delegated to the jqXHR object of the current upload,
                // and jqXHR callbacks mapped to the equivalent Promise methods:
                pipe.abort = function () {
                    aborted = [undefined, 'abort', 'abort'];
                    if (!jqXHR) {
                        if (slot) {
                            slot.rejectWith(options.context, aborted);
                        }
                        return send();
                    }
                    return jqXHR.abort();
                };
                return this._enhancePromise(pipe);
            }
            return send();
        },

        _onAdd: function (e, data) {
            var that = this,
                result = true,
                options = $.extend({}, this.options, data),
                files = data.files,
                filesLength = files.length,
                limit = options.limitMultiFileUploads,
                limitSize = options.limitMultiFileUploadSize,
                overhead = options.limitMultiFileUploadSizeOverhead,
                batchSize = 0,
                paramName = this._getParamName(options),
                paramNameSet,
                paramNameSlice,
                fileSet,
                i,
                j = 0;
            if (limitSize && (!filesLength || files[0].size === undefined)) {
                limitSize = undefined;
            }
            if (!(options.singleFileUploads || limit || limitSize) ||
                    !this._isXHRUpload(options)) {
                fileSet = [files];
                paramNameSet = [paramName];
            } else if (!(options.singleFileUploads || limitSize) && limit) {
                fileSet = [];
                paramNameSet = [];
                for (i = 0; i < filesLength; i += limit) {
                    fileSet.push(files.slice(i, i + limit));
                    paramNameSlice = paramName.slice(i, i + limit);
                    if (!paramNameSlice.length) {
                        paramNameSlice = paramName;
                    }
                    paramNameSet.push(paramNameSlice);
                }
            } else if (!options.singleFileUploads && limitSize) {
                fileSet = [];
                paramNameSet = [];
                for (i = 0; i < filesLength; i = i + 1) {
                    batchSize += files[i].size + overhead;
                    if (i + 1 === filesLength ||
                            ((batchSize + files[i + 1].size + overhead) > limitSize) ||
                            (limit && i + 1 - j >= limit)) {
                        fileSet.push(files.slice(j, i + 1));
                        paramNameSlice = paramName.slice(j, i + 1);
                        if (!paramNameSlice.length) {
                            paramNameSlice = paramName;
                        }
                        paramNameSet.push(paramNameSlice);
                        j = i + 1;
                        batchSize = 0;
                    }
                }
            } else {
                paramNameSet = paramName;
            }
            data.originalFiles = files;
            $.each(fileSet || files, function (index, element) {
                var newData = $.extend({}, data);
                newData.files = fileSet ? element : [element];
                newData.paramName = paramNameSet[index];
                that._initResponseObject(newData);
                that._initProgressObject(newData);
                that._addConvenienceMethods(e, newData);
                result = that._trigger(
                    'add',
                    $.Event('add', {delegatedEvent: e}),
                    newData
                );
                return result;
            });
            return result;
        },

        _replaceFileInput: function (input) {
            var inputClone = input.clone(true);
            $('<form></form>').append(inputClone)[0].reset();
            // Detaching allows to insert the fileInput on another form
            // without loosing the file input value:
            input.after(inputClone).detach();
            // Avoid memory leaks with the detached file input:
            $.cleanData(input.unbind('remove'));
            // Replace the original file input element in the fileInput
            // elements set with the clone, which has been copied including
            // event handlers:
            this.options.fileInput = this.options.fileInput.map(function (i, el) {
                if (el === input[0]) {
                    return inputClone[0];
                }
                return el;
            });
            // If the widget has been initialized on the file input itself,
            // override this.element with the file input clone:
            if (input[0] === this.element[0]) {
                this.element = inputClone;
            }
        },

        _handleFileTreeEntry: function (entry, path) {
            var that = this,
                dfd = $.Deferred(),
                errorHandler = function (e) {
                    if (e && !e.entry) {
                        e.entry = entry;
                    }
                    // Since $.when returns immediately if one
                    // Deferred is rejected, we use resolve instead.
                    // This allows valid files and invalid items
                    // to be returned together in one set:
                    dfd.resolve([e]);
                },
                dirReader;
            path = path || '';
            if (entry.isFile) {
                if (entry._file) {
                    // Workaround for Chrome bug #149735
                    entry._file.relativePath = path;
                    dfd.resolve(entry._file);
                } else {
                    entry.file(function (file) {
                        file.relativePath = path;
                        dfd.resolve(file);
                    }, errorHandler);
                }
            } else if (entry.isDirectory) {
                dirReader = entry.createReader();
                dirReader.readEntries(function (entries) {
                    that._handleFileTreeEntries(
                        entries,
                        path + entry.name + '/'
                    ).done(function (files) {
                        dfd.resolve(files);
                    }).fail(errorHandler);
                }, errorHandler);
            } else {
                // Return an empy list for file system items
                // other than files or directories:
                dfd.resolve([]);
            }
            return dfd.promise();
        },

        _handleFileTreeEntries: function (entries, path) {
            var that = this;
            return $.when.apply(
                $,
                $.map(entries, function (entry) {
                    return that._handleFileTreeEntry(entry, path);
                })
            ).pipe(function () {
                return Array.prototype.concat.apply(
                    [],
                    arguments
                );
            });
        },

        _getDroppedFiles: function (dataTransfer) {
            dataTransfer = dataTransfer || {};
            var items = dataTransfer.items;
            if (items && items.length && (items[0].webkitGetAsEntry ||
                    items[0].getAsEntry)) {
                return this._handleFileTreeEntries(
                    $.map(items, function (item) {
                        var entry;
                        if (item.webkitGetAsEntry) {
                            entry = item.webkitGetAsEntry();
                            if (entry) {
                                // Workaround for Chrome bug #149735:
                                entry._file = item.getAsFile();
                            }
                            return entry;
                        }
                        return item.getAsEntry();
                    })
                );
            }
            return $.Deferred().resolve(
                $.makeArray(dataTransfer.files)
            ).promise();
        },

        _getSingleFileInputFiles: function (fileInput) {
            fileInput = $(fileInput);
            var entries = fileInput.prop('webkitEntries') ||
                    fileInput.prop('entries'),
                files,
                value;
            if (entries && entries.length) {
                return this._handleFileTreeEntries(entries);
            }
            files = $.makeArray(fileInput.prop('files'));
            if (!files.length) {
                value = fileInput.prop('value');
                if (!value) {
                    return $.Deferred().resolve([]).promise();
                }
                // If the files property is not available, the browser does not
                // support the File API and we add a pseudo File object with
                // the input value as name with path information removed:
                files = [{name: value.replace(/^.*\\/, '')}];
            } else if (files[0].name === undefined && files[0].fileName) {
                // File normalization for Safari 4 and Firefox 3:
                $.each(files, function (index, file) {
                    file.name = file.fileName;
                    file.size = file.fileSize;
                });
            }
            return $.Deferred().resolve(files).promise();
        },

        _getFileInputFiles: function (fileInput) {
            if (!(fileInput instanceof $) || fileInput.length === 1) {
                return this._getSingleFileInputFiles(fileInput);
            }
            return $.when.apply(
                $,
                $.map(fileInput, this._getSingleFileInputFiles)
            ).pipe(function () {
                return Array.prototype.concat.apply(
                    [],
                    arguments
                );
            });
        },

        _onChange: function (e) {
            var that = this,
                data = {
                    fileInput: $(e.target),
                    form: $(e.target.form)
                };
            this._getFileInputFiles(data.fileInput).always(function (files) {
                data.files = files;
                if (that.options.replaceFileInput) {
                    that._replaceFileInput(data.fileInput);
                }
                if (that._trigger(
                        'change',
                        $.Event('change', {delegatedEvent: e}),
                        data
                    ) !== false) {
                    that._onAdd(e, data);
                }
            });
        },

        _onPaste: function (e) {
            var items = e.originalEvent && e.originalEvent.clipboardData &&
                    e.originalEvent.clipboardData.items,
                data = {files: []};
            if (items && items.length) {
                $.each(items, function (index, item) {
                    var file = item.getAsFile && item.getAsFile();
                    if (file) {
                        data.files.push(file);
                    }
                });
                if (this._trigger(
                        'paste',
                        $.Event('paste', {delegatedEvent: e}),
                        data
                    ) !== false) {
                    this._onAdd(e, data);
                }
            }
        },

        _onDrop: function (e) {
            e.dataTransfer = e.originalEvent && e.originalEvent.dataTransfer;
            var that = this,
                dataTransfer = e.dataTransfer,
                data = {};
            if (dataTransfer && dataTransfer.files && dataTransfer.files.length) {
                e.preventDefault();
                this._getDroppedFiles(dataTransfer).always(function (files) {
                    data.files = files;
                    if (that._trigger(
                            'drop',
                            $.Event('drop', {delegatedEvent: e}),
                            data
                        ) !== false) {
                        that._onAdd(e, data);
                    }
                });
            }
        },

        _onDragOver: function (e) {
            e.dataTransfer = e.originalEvent && e.originalEvent.dataTransfer;
            var dataTransfer = e.dataTransfer;
            if (dataTransfer && $.inArray('Files', dataTransfer.types) !== -1 &&
                    this._trigger(
                        'dragover',
                        $.Event('dragover', {delegatedEvent: e})
                    ) !== false) {
                e.preventDefault();
                dataTransfer.dropEffect = 'copy';
            }
        },

        _initEventHandlers: function () {
            if (this._isXHRUpload(this.options)) {
                this._on(this.options.dropZone, {
                    dragover: this._onDragOver,
                    drop: this._onDrop
                });
                this._on(this.options.pasteZone, {
                    paste: this._onPaste
                });
            }
            if ($.support.fileInput) {
                this._on(this.options.fileInput, {
                    change: this._onChange
                });
            }
        },

        _destroyEventHandlers: function () {
            this._off(this.options.dropZone, 'dragover drop');
            this._off(this.options.pasteZone, 'paste');
            this._off(this.options.fileInput, 'change');
        },

        _setOption: function (key, value) {
            var reinit = $.inArray(key, this._specialOptions) !== -1;
            if (reinit) {
                this._destroyEventHandlers();
            }
            this._super(key, value);
            if (reinit) {
                this._initSpecialOptions();
                this._initEventHandlers();
            }
        },

        _initSpecialOptions: function () {
            var options = this.options;
            if (options.fileInput === undefined) {
                options.fileInput = this.element.is('input[type="file"]') ?
                        this.element : this.element.find('input[type="file"]');
            } else if (!(options.fileInput instanceof $)) {
                options.fileInput = $(options.fileInput);
            }
            if (!(options.dropZone instanceof $)) {
                options.dropZone = $(options.dropZone);
            }
            if (!(options.pasteZone instanceof $)) {
                options.pasteZone = $(options.pasteZone);
            }
        },

        _getRegExp: function (str) {
            var parts = str.split('/'),
                modifiers = parts.pop();
            parts.shift();
            return new RegExp(parts.join('/'), modifiers);
        },

        _isRegExpOption: function (key, value) {
            return key !== 'url' && $.type(value) === 'string' &&
                /^\/.*\/[igm]{0,3}$/.test(value);
        },

        _initDataAttributes: function () {
            var that = this,
                options = this.options;
            // Initialize options set via HTML5 data-attributes:
            $.each(
                $(this.element[0].cloneNode(false)).data(),
                function (key, value) {
                    if (that._isRegExpOption(key, value)) {
                        value = that._getRegExp(value);
                    }
                    options[key] = value;
                }
            );
        },

        _create: function () {
            this._initDataAttributes();
            this._initSpecialOptions();
            this._slots = [];
            this._sequence = this._getXHRPromise(true);
            this._sending = this._active = 0;
            this._initProgressObject(this);
            this._initEventHandlers();
        },

        // This method is exposed to the widget API and allows to query
        // the number of active uploads:
        active: function () {
            return this._active;
        },

        // This method is exposed to the widget API and allows to query
        // the widget upload progress.
        // It returns an object with loaded, total and bitrate properties
        // for the running uploads:
        progress: function () {
            return this._progress;
        },

        // This method is exposed to the widget API and allows adding files
        // using the fileupload API. The data parameter accepts an object which
        // must have a files property and can contain additional options:
        // .fileupload('add', {files: filesList});
        add: function (data) {
            var that = this;
            if (!data || this.options.disabled) {
                return;
            }
            if (data.fileInput && !data.files) {
                this._getFileInputFiles(data.fileInput).always(function (files) {
                    data.files = files;
                    that._onAdd(null, data);
                });
            } else {
                data.files = $.makeArray(data.files);
                this._onAdd(null, data);
            }
        },

        // This method is exposed to the widget API and allows sending files
        // using the fileupload API. The data parameter accepts an object which
        // must have a files or fileInput property and can contain additional options:
        // .fileupload('send', {files: filesList});
        // The method returns a Promise object for the file upload call.
        send: function (data) {
            if (data && !this.options.disabled) {
                if (data.fileInput && !data.files) {
                    var that = this,
                        dfd = $.Deferred(),
                        promise = dfd.promise(),
                        jqXHR,
                        aborted;
                    promise.abort = function () {
                        aborted = true;
                        if (jqXHR) {
                            return jqXHR.abort();
                        }
                        dfd.reject(null, 'abort', 'abort');
                        return promise;
                    };
                    this._getFileInputFiles(data.fileInput).always(
                        function (files) {
                            if (aborted) {
                                return;
                            }
                            if (!files.length) {
                                dfd.reject();
                                return;
                            }
                            data.files = files;
                            jqXHR = that._onSend(null, data).then(
                                function (result, textStatus, jqXHR) {
                                    dfd.resolve(result, textStatus, jqXHR);
                                },
                                function (jqXHR, textStatus, errorThrown) {
                                    dfd.reject(jqXHR, textStatus, errorThrown);
                                }
                            );
                        }
                    );
                    return this._enhancePromise(promise);
                }
                data.files = $.makeArray(data.files);
                if (data.files.length) {
                    return this._onSend(null, data);
                }
            }
            return this._getXHRPromise(false, data && data.context);
        }

    });

}));

///#source 1 1 /Scripts/Publishing/athoc.iws.alert.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
//athoc.iws.alert = athoc.iws.alert || {};

if (athoc.iws) {
    athoc.iws.alert = function () {
        return {
            parameters: {},

            //default action for deeplinking
            action: '',

            //source for deeplinking
            source: '',

            //id for deeplinking
            id: 0,

            rbt: [],

            //init method for alert list, will be triggered before document load
            init: function (args, targetUsersParameters, deviceOptionsParameters, massDeviceParameters) {
                this.parameters = args;
                this.initBreadcrumb();
                athoc.iws.publishing.targetUsers.init(targetUsersParameters);
                athoc.iws.publishing.personalDeviceOptions.init(deviceOptionsParameters);

                if (args.context && args.context == "PA") //skip initiating mass and org for PA
                    return;

                athoc.iws.publishing.massdevices.init(massDeviceParameters);
                var orgParameters = {
                    resources: athoc.iws.scenario.resources,
                    context: "Alert",
                    orgSectionDivs: this.parameters.orgSectionDivs
                }

                athoc.iws.publishing.targetOrg.init(orgParameters);
            },

            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {
                var sn = athoc.iws.alert;

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = sn.breadcrumbModel;

                //Sub-level breadcrumb
                var alertListBreadCrumb = new Breadcrumb('dlLink', athoc.iws.publishing.resources.Publishing_Alerts_PageTitle, '', function () {
                    athoc.iws.alert.list.viewAlertList();
                });

                var inboxBreadCrumb = new Breadcrumb('dlLink', "Inbox", '', function () {
                    window.location = "/athoc-iws/EventManager";
                });


                //Page breadcrumb
                var alertListPageBreadcrumb = new PageBreadcrumb('alertList', athoc.iws.publishing.resources.Publishing_Alerts_PageTitle, [], '');

                //Alert detail
                var alertDetailPageBreadcrumb = new PageBreadcrumb('alertDetail', '', [alertListBreadCrumb], '');

                //Alert create
                var alertCreatePageBreadcrumb = new PageBreadcrumb('alertCreate', '', [], '');

                //Alert detail
                var alertDuplicatePageBreadcrumb = new PageBreadcrumb('alertDuplicate', athoc.iws.publishing.resources.Publishing_Alert_DuplicateAlert, [alertListBreadCrumb], '');

                //Fowrard alert
                var forwardAlertPageBreadcrumb = new PageBreadcrumb('alertForward', athoc.iws.publishing.resources.Publishing_Alert_ForwardAlert, [inboxBreadCrumb], '');

                breadcrumbsModel.addPage(alertListPageBreadcrumb);
                breadcrumbsModel.addPage(alertDetailPageBreadcrumb);
                breadcrumbsModel.addPage(alertCreatePageBreadcrumb);
                breadcrumbsModel.addPage(alertDuplicatePageBreadcrumb);
                breadcrumbsModel.addPage(forwardAlertPageBreadcrumb);
            },

            //load method, will be tirggered on document load
            load: function () {
                var self = this;

                this.bindBreadcrumb();
                this.parameters.alertActionFunction = this.executeAlertAction(this); //preserve context within closure

                athoc.iws.alert.list.loadParam(this.parameters);

                if (this.action == "create") {
                    athoc.iws.alert.list.createAlertFromScenairo(this.id);
                } else if (this.action == "view") {
                    athoc.iws.alert.list.viewAlertSummary(this.id);
                } else if (this.action == "rbt") {
                    athoc.iws.alert.list.createAlertFromRbt(0, athoc.iws.alert.rbt);
                } else {
                    navigateToPage('alertList', function () { });
                    athoc.iws.alert.list.load();
                }
                $("#btn_edit_cancel").click(function () {
                    if (athoc.iws.publishing.detail.isChanged()) {
                        var confirmLeave = confirm(athoc.iws.publishing.resources.Unsaved_Data_Text);
                        if (!confirmLeave) {
                            return;
                        } else {
                            athoc.iws.publishing.detail.setChanged(false);

                        }
                    }

                    if (athoc.iws.alert.source == 'publisher') {
                        window.location = '/athoc-iws/scenariomanager/scenariopublisher';
                    }
                    else if (athoc.iws.alert.source == 'home') {
                        window.location = '/athoc-iws';
                    }
                    else if (athoc.iws.alert.source == 'event') {
                        window.location = '/athoc-iws/EventManager';
                    }
                    else if (athoc.iws.alert.source == 'log') {
                        window.location = '/athoc-iws/EventManager/activitylog';
                    }

                    else {
                        athoc.iws.alert.list.viewAlertList();
                    }


                });
                $("#btn_detail_standby").click(function () { athoc.iws.alert.detail.standbyAlert(); });
                $("#btn_detail_save").click(function () { athoc.iws.alert.detail.saveAlert(); $(this).removeClass("active"); });
                $("#btn_review_and_publish").click(function () { athoc.iws.alert.detail.reviewAndPublish(); });
                $("#btn_view_cancel").click(function () { athoc.iws.alert.list.viewAlertList(); });
                $("#btn_alert_summary").click(function () {
	
                    if (athoc.iws.alert.id != 0) {
                        window.location = '/client/alertmanager/summary/' + athoc.iws.alert.id;
                        } else if (athoc.iws.publishing != undefined && athoc.iws.publishing.entityId != undefined)
                            window.location = '/client/alertmanager/summary/' + athoc.iws.publishing.entityId;                 
                });
                //~M
                $("#btn_alert_save").click(function () { athoc.iws.alert.detail.saveAlertDetails(athoc.iws.alert.parameters.urls.SaveAlertUrl, true); $(this).removeClass("active"); });
                $("#btn_alert_end").click(function () {
                    var endCallBack = function () {
                        athoc.iws.alert.list.viewAlertList();
                    };

                    if (athoc.iws.alert.id != 0) {

                        var showProgressFunc = function () {
                            kendo.ui.progress($("#mainContainer"), true);
                        };
                        var hideProgressFunc = function () {
                            //$("#mainContainer").css("position", "");
                            kendo.ui.progress($("#mainContainer"), false);
                        };

                        self.executeAlertAction(self)("end", [{ AlertId: athoc.iws.alert.id, Title: athoc.iws.publishing.detail.viewModel.Content.Title }], endCallBack, showProgressFunc, hideProgressFunc);
                    }
                });

                window.onbeforeunload = function (event) {
                    var isModified = athoc.iws.publishing.detail.isChanged();

                    if (isModified) {
                        return athoc.iws.publishing.resources.Unsaved_Data_Text;
                    }
                };

            },

            bindBreadcrumb: function () {
                var breadcrumbsModel = this.breadcrumbModel;
                breadcrumbsModel.SelectedPage('alertList');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },


            executeAlertAction: function (context) {
                return function (actionType, selectedArray, deleteSuccessCallback, showProgressFunction, hideProgressFunction) {
                    var self = context;
                    var ids = selectedArray.map(function (item) { return item.AlertId; });
                    var names = selectedArray.map(function (item) { return item.Title; });

                    //check for userbase permission
                    if (typeof showProgressFunction == "function") {
                        showProgressFunction();
                    } else {
                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: self.parameters.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: self.parameters.resources.General_LoadingMessage }).showLoader();
                    }
                    var myAjaxOptionsForModifyCheck = {
                        url: self.parameters.urls.CheckCanModifyUrl,
                        contentType: 'application/json',
                        dataType: 'json',
                        data: JSON.stringify(ids),
                        type: 'POST',
                    };

                    var executeOnCanModify = self.onSuccessForModifyCheck(actionType, names, deleteSuccessCallback, self, selectedArray, ids, hideProgressFunction);

                    var onErrorForModifyCheck = function () {
                        $.AjaxLoader.hideLoader();
                    };

                    var ajaxOptionsForModifyCheck = $.extend({}, AjaxUtility(onErrorForModifyCheck, executeOnCanModify).ajaxPostOptions, myAjaxOptionsForModifyCheck);
                    $.ajax(ajaxOptionsForModifyCheck);


                }
            },


            onSuccessForModifyCheck: function (actionType, names, deleteSuccessCallback, context, selectedArray, ids, hideProgressFunction) {
                return function (data, textStatus, jqXHR) {
                    var self = context;

                    if (typeof hideProgressFunction == "function") {
                        hideProgressFunction();
                    } else {
                        $.AjaxLoader.hideLoader();
                    }
                    if (data.CanModify) {

                        self.setupAndShowDialog(names,
                            (actionType == "end") ? self.parameters.resources.Alert_EndDialog_Title : self.parameters.resources.Alert_DeleteDialog_Title,
                            (actionType == "end") ? self.parameters.resources.Alert_EndDialog_Body : self.parameters.resources.Alert_DeleteDialog_Body,
                            (actionType == "end") ? self.parameters.resources.Alert_Dialog_EndButton : self.parameters.resources.Action_Button_Delete);
                        (actionType == "end") ? $('#dialogActionButton').attr('title', self.parameters.resources.Alert_Dialog_EndButton) : $('#dialogActionButton').attr('title', self.parameters.resources.Action_Button_Delete);



                        $(self.parameters.dialogButtonLabelSelector).off('click').on('click', function (e) {
                            $(self.parameters.dialogSelector).modal('hide');
                            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: self.parameters.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000,displayText :self.parameters.resources.General_LoadingMessage }).showLoader();

                            var myAjaxOptions = {
                                url: (actionType == "end") ? self.parameters.urls.EndAlertsUrl : self.parameters.urls.DeleteAlertsUrl,
                                contentType: 'application/json',
                                dataType: 'json',
                                data: JSON.stringify(ids),
                                type: 'POST',
                            };

                            var onError = function () {
                                $.AjaxLoader.hideLoader();
                            };

                            var onSuccess = function (data, textStatus, jqXHR) {
                                $.AjaxLoader.hideLoader();
                                if (typeof deleteSuccessCallback == "function") {
                                    deleteSuccessCallback(data, textStatus, jqXHR);
                                }
                            }

                            var ajaxOptions = $.extend({}, AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                            $.ajax(ajaxOptions);

                        });

                    } else {
                        //show dialog
                        var unmodifiableNames = new Array();
                        _.each(selectedArray, function (item) {
                            var found = _.find(data.UnmodifiableAlerts, function (item2) {
                                return (item.AlertId == item2);
                            });
                            if (found) {
                                unmodifiableNames.push(item.Title);
                            }
                        });

                        self.setupAndShowDialog(unmodifiableNames,
                        (actionType == "end") ? self.parameters.resources.Alert_CouldntEndDialog_Title : self.parameters.resources.Alert_CouldntDeleteDialog_Title,
                        (actionType == "end") ? self.parameters.resources.Alert_CouldntEndDialog_Body : self.parameters.resources.Alert_CouldntDeleteDialog_Body,
                        "",
                        self.parameters.resources.Alert_Dialog_OkButton,
                        true);
                    }
                }
            },


            setupAndShowDialog: function (names, title, body, buttonLabel, cancelButtonText, hideActionButton) {
                var self = this;
                var nameTags = "";
                names.sort();
                for (var i = 0; i < names.length; i++) {
                    nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(names[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(names[i]) + "</div>";
                }

                $(self.parameters.dialogItemListSelector).html("<div class='mar-top10'>" + nameTags + "</div>");
                $(self.parameters.dialogTitleSelector).html(title);
                $(self.parameters.dialogBodySelector).html(body);
                $(self.parameters.dialogButtonLabelSelector).html(buttonLabel);

                if (typeof cancelButtonText != "undefined") {
                    $(self.parameters.dialogCancelButton).html(cancelButtonText);
                } else {
                    $(self.parameters.dialogCancelButton).html(self.parameters.resources.Action_Button_Cancel);
                }

                $(self.parameters.dialogButtonLabelSelector).show();
                if (typeof hideActionButton != "undefined") {
                    if (hideActionButton) {
                        $(self.parameters.dialogButtonLabelSelector).hide();
                    }
                }

                $(self.parameters.dialogSelector).modal('show');

            }

        }
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.alert.list.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};

if (athoc.iws.alert) {
    athoc.iws.alert.list = function () {
        var datasource = null;
        var filter = {};
        var getChannels = true;
        var sortState = null;
        var isRepeated = false;
        var isSimpleSearch = true;
        return {
            urls: {},
            resources: {},
            gridSelector: "",
            IsRightToLeft: false,
            selectedArray: new Array(),
            viewModel: null,
            parameters: {},
            filter: {},
            originalGridOffset: {},

            loadParam: function (parameters) { 
                var self = this;

                this.urls = parameters.urls;
                this.resources = parameters.resources;
                this.gridSelector = parameters.gridSelector;
                this.parameters = parameters;

            },

            resizeGrid: function () {
                var pillContainerHeight = $('.filter-col .pill-container').height();
                if (pillContainerHeight && (pillContainerHeight > 0)) {
                    $('#alertList').css({ top: (pillContainerHeight - 10 + (this.originalGridOffset.Top - 1) + 'px') });
                    $('#alertList .k-grid-header').css({ top: pillContainerHeight - 10 + this.originalGridOffset.headerTop + 'px' });
                    $('.row-fluid .whiteout').height(pillContainerHeight - 10 + this.originalGridOffset.whiteoutHeight);

                } else {
                    $('#alertList').css("margin-top", "0");
                    $('#alertList').css({ top: (this.originalGridOffset.Top - 1) + 'px' });
                    $('#alertList .k-grid-header').css({ top: this.originalGridOffset.headerTop + 'px' });
                    $('.row-fluid .whiteout').height(this.originalGridOffset.whiteoutHeight);
                }
            },
            switchView: function (view) {
                switch (view) {
                    case "simple":
                        $("#advancedSearch").css("display", "block");
                        $("#simpleSearch").css("display", "none");
                        $("#advancedPane").css("display", "none");
                        break;
                    case "advanced":
                        $("#advancedSearch").css("display", "none");
                        $("#simpleSearch").css("display", "block");
                        $("#advancedPane").css("display", "block");
                        break;
                }
            },

            search: function () {
                var self = this;
                this.switchView("simple");
                $("#advancedSearch").on("click", $.proxy(function () {
                    this.switchView("advanced");
                }, this));
                //back to simple search
                $("#simpleSearch").on("click", $.proxy(function () {
                    this.switchView("simple");
                    $("#advancedSearch").focus();
                }, this));
                $(".pill-close").on("click", $.proxy(function (e) {
                    if (e.target.id === "quickSearchPillClose") {
                        self.viewModel.quickSearchPill(false);
                        self.viewModel.quickSearchPillText("");
                        $(self.parameters.textSearchInput).val("");
                    } else if (e.target.id === "severityPillClose") {
                        self.viewModel.severityPill(false);
                        self.viewModel.severityPillSerialized("");
                        self.viewModel.ResetToAllSeverity();
                    } else if (e.target.id === "eventTypePillClose") {
                        self.viewModel.eventTypePill(false);
                        self.viewModel.eventTypePillSerialized("");
                        self.viewModel.ResetToAllEvent();
                    } else if (e.target.id === "dateFromPillClose") {
                        self.viewModel.dateFromPill(false);
                        self.viewModel.FromDateValue(undefined);
                    } else if (e.target.id === "dateToPillClose") {
                        self.viewModel.dateToPill(false);
                        self.viewModel.ToDateValue(undefined);
                    } else if (e.target.id === "dateRangePillClose") {
                        self.viewModel.dateRangePill(false);
                        self.viewModel.ToDateValue(undefined);
                        self.viewModel.FromDateValue(undefined);
                    } else if (e.target.id === "statusPillClose") {
                        self.viewModel.statusPill(false);
                        self.viewModel.ResetToAllStatus();
                    } else if (e.target.id === "channelPillClose") {
                        self.viewModel.channelPill(false);
                        self.viewModel.ResetChannel();
                    } else if (e.target.id === "publisherPillClose") {
                        self.viewModel.publisherPill(false);
                        self.viewModel.ResetPublisher();
                    }
                    self.executeSearch();


                }, this));


            },

            setPills: function () {
                var self = this;
                var searchText = $(self.parameters.textSearchInput).val();
                if (searchText !== "") {
                    self.viewModel.canClearAll(true);
                    self.viewModel.quickSearchPill(true);
                    self.viewModel.quickSearchPillText(searchText);
                } else {
                    self.viewModel.quickSearchPill(false);
                }
                if (self.viewModel.SelectedSeverityArray().length > 0) {
                    self.viewModel.canClearAll(true);
                    self.viewModel.severityPill(true);
                    self.viewModel.severityPillSerialized(self.viewModel.SelectedSerialized(self._getSelectedNames(self.viewModel.AllSeverityArray(), self.viewModel.SelectedSeverityArray())).join(", "));
                } else {
                    self.viewModel.severityPill(false);
                }
                if (self.viewModel.SelectedEventArray().length > 0) {
                    self.viewModel.canClearAll(true);
                    self.viewModel.eventTypePill(true);
                    self.viewModel.eventTypePillSerialized(self.viewModel.SelectedSerialized(self._getSelectedNames(self.viewModel.AllEventTypesArray(), self.viewModel.SelectedEventArray())).join(", "));
                } else {
                    self.viewModel.eventTypePill(false);
                }
                if (self.viewModel.ToDateValueForServer !== "" && self.viewModel.FromDateValueForServer !== "") {
                    self.viewModel.canClearAll(true);
                    self.viewModel.dateRangePill(true);
                    self.viewModel.dateToPill(false);
                    self.viewModel.dateFromPill(false);
                } else {
                    self.viewModel.dateRangePill(false);
                    if (self.viewModel.FromDateValueForServer !== "") {
                        self.viewModel.canClearAll(true);
                        self.viewModel.dateFromPill(true);
                    } else {
                        self.viewModel.dateFromPill(false);
                    }
                    if (self.viewModel.ToDateValueForServer !== "") {
                        self.viewModel.canClearAll(true);
                        self.viewModel.dateToPill(true);
                    } else {
                        self.viewModel.dateToPill(false);
                    }
                }

                if ((self.viewModel.ChannelToFilter() !== -1) && ($.isNumeric(self.viewModel.ChannelToFilter()))) {
                    self.viewModel.canClearAll(true);
                    self.viewModel.channelPill(true);
                    self.viewModel.channelPillSerialized(self._getSelectedChannelName(self.viewModel.AllChannelsArray(), self.viewModel.ChannelToFilter()));
                } else {
                    self.viewModel.channelPill(false);
                }
                if (self.viewModel.PublisherToFilter() !== this.viewModel.defaultPublisher) {
                    self.viewModel.canClearAll(true);
                    self.viewModel.publisherPill(true);
                    self.viewModel.publisherPillText(self.viewModel.PublisherToFilter());
                } else {
                    self.viewModel.publisherPill(false);
                }
                if (self.viewModel.SelectedStatusArray().length > 0 &&
                    self.viewModel.SelectedStatusArray().length < self.viewModel.SearchableStatusArray().length &&
                    self.viewModel.SelectedStatusArray()[0] !== "-1") {
                    self.viewModel.canClearAll(true);
                    self.viewModel.statusPill(true);
                    self.viewModel.statusPillSerialized(self.viewModel.SelectedSerialized(self._getSelectedStatuses(self.viewModel.SearchableStatusArray(), self.viewModel.SelectedStatusArray())).join(", "));
                } else {
                    self.viewModel.statusPill(false);
                }
                this.switchView("simple");
            },

            _getSelectedChannelName: function (allElementArray, selectedElementId) {
                for (var i = 0; i < allElementArray.length; i++) {
                    if (allElementArray[i].Id === selectedElementId) {
                        return allElementArray[i].Name;
                    }
                }
            },

            _getSelectedNames: function (allElementArray, selectedArray) {
                var selectedNames = ko.observableArray();
                for (var i = 0; i < selectedArray.length; i++) {
                    for (var j = 0; j < allElementArray.length; j++) {
                        if (selectedArray[i] === allElementArray[j].Id) {
                            selectedNames.push(allElementArray[j].Name);
                            break;
                        }
                    }
                }
                return selectedNames;
            },

            _getSelectedStatuses: function (allElementArray, selectedArray) {
                var selectedStatuses = ko.observableArray();
                for (var i = 0; i < selectedArray.length; i++) {
                    for (var j = 0; j < allElementArray.length; j++) {
                        if (selectedArray[i] === allElementArray[j].id) {
                            selectedStatuses.push(allElementArray[j].label);
                            break;
                        }
                    }
                }
                return selectedStatuses;
            },

            load: function () {
                var self = this;

                self.search();

                athoc.iws.alert.action = '';
                athoc.iws.alert.source = '';

                this.bindActionButtons();

                var url = this.urls.GetAlertListUrl;

                var initialStatusFilterArray = [];
                if (this.parameters.initialFilter.length != "") { //need status filter initially
                    initialStatusFilterArray = this.parameters.initialFilter.split(',');
                }

                this.viewModel = new this.listViewModel(this, initialStatusFilterArray);
                self.setFilter({ StatusFilter: self.viewModel.SelectedSerialized(self.viewModel.SelectedStatusArray) });

                ko.applyBindings(this.viewModel, $(this.parameters.koBoundListSelector).get(0));
                ko.applyBindings(this.viewModel, $(this.parameters.koBoundNavigationSelector).get(0));

                this.fillChannelDropdown();
                this.fillPublisherDropdown();
                this.fillEventTypeDropdown();
                this.fillSeverityDropdown();


                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, filter);
                            //$.extend(options, { "StatusFilter": ["Live"] });
                            options.getChannels = getChannels;

                            var newState = JSON.stringify(options.sort);
                            if ((sortState) && newState != sortState) {
                                sortState = newState;
                                isRepeated = true;
                                options.page = 1;
                                options.skip = 0;
                                datasource.page(1);
                            }
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                        //isRepeated flag is to save duplicate calls to 
                        //server during sorting
                        if (isRepeated) {
                            e.preventDefault();
                            isRepeated = false;
                        }
                    },
                    requestEnd: function (e) {
                        sortState = JSON.stringify(e.sender._sort);
                        if (e.response) {
                            //add IsChecked property to the data
                            _.each(e.response.Data, function (item, index) {
                                item.IsChecked = self.viewModel.IsSelected(item.AlertId);
                            });
                            $.AjaxLoader.hideLoader();
                        }
                        self.resizeGrid();
                        //remove page info from filter
                        delete filter.page;
                    },
                    schema: {
                        data: "Data",
                        total: "TotalCount",
                    },
                    serverPaging: true,
                    serverSorting: true,
                    serverFiltering: true,
                    sort: { field: "StartTime", dir: "desc" },
                    pageSize: 50,
                    error: function (e) {
                        var errorCallBack = function (returnedErrorObject) {
                            $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());;
                        };
                        AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);

                    }
                });

                $("#pageInfo").kendoPager({
                    dataSource: datasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: this.resources.Alert_List_PageInfo,
                        empty: this.resources.Alert_List_PageInfo_NoRecords
                    }
                });

                var grid = $(this.gridSelector).kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    resizable: true,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Summary),
                                empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Items_Per_Page),
                                first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                                next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        },
                    },
                    columns:
                            [
                                {
                                    field: "AlertId",
                                    hidden: true
                                },
                                {
                                    field: "IsChecked",
                                    template: $("#alert-checkbox-template").html(),
                                    width: 25,
                                    headerTemplate: kendo.format('<input type="checkbox" class="senario-select" id="alert-select-all" title="{0}" tabindex="240" />', this.resources.Alert_List_SelectAll),
                                    sortable: false,
                                    headerAttributes: {
                                        style: "cursor: default",
                                    }
                                },
                                {
                                    field: "Title",
                                    title: this.resources.Alert_List_Title,
                                    width: 175, 
                                    headerAttributes: {
                                        tabindex: "240",
                                        title: this.resources.Alert_List_Title,
                                    }

                                },
                                {
                                    field: "Status",
                                    title: $.htmlDecode(this.resources.Alert_List_Status),
                                    template: '<span title="#=StatusLabel#">#=StatusLabel#</span>',
                                    width: 80,
                                    headerAttributes: {
                                        tabindex: "240"
                                    }
                                },
                                {
                                    field: "StartTime",
                                    title: $.htmlDecode(this.resources.Alert_List_Start_Time),
                                    template: '<span class="cellTooltip" title="#=StartTimeDisplayString#">#=StartTimeDisplayString#</span>',
                                    width: 140,
                                    headerAttributes: {
                                        tabindex: "240"
                                    }
                                },
                                {
                                    field: "Publisher",
                                    title: $.htmlDecode(this.resources.Alert_List_Publisher),
                                    template: '<span title="#=Publisher#">#=Publisher#</span>',
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', $.htmlDecode(this.resources.Alert_List_Publisher), $.htmlDecode(this.resources.Alert_List_Publisher)),
                                    width: 100,
                                    headerAttributes: {
                                        tabindex: "240"
                                    }
                                },
                                {
                                    field: "Targeted",
                                    title: $.htmlDecode(this.resources.Alert_List_Targeted),
                                    width: 60,
                                    template: $("#alert-targeted-column-template").html(),
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', $.htmlDecode(this.resources.Alert_List_Targeted), $.htmlDecode(this.resources.Alert_List_Targeted)),
                                    sortable: false,
                                    attributes: {
                                        "class": "align-right"
                                    },
                                    headerAttributes: {
                                        style: "cursor: default"
                                    }
                                },
                                {
                                    field: "Sent",
                                    title: $.htmlDecode(this.resources.Alert_List_Sent),
                                    width: 60,
                                    template: $("#alert-sent-column-template").html(),
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', $.htmlDecode(this.resources.Alert_List_Sent), $.htmlDecode(this.resources.Alert_List_Sent)),
                                    sortable: false,
                                    attributes: {
                                        "class": "align-right"
                                    },
                                    headerAttributes: {
                                        style: "cursor: default"
                                    }
                                },
                                {
                                    field: "Responded",
                                    title:$.htmlDecode( this.resources.Alert_List_Responded),
                                    template: $("#alert-responded-column-template").html(),
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', $.htmlDecode(this.resources.Alert_List_Responded), $.htmlDecode(this.resources.Alert_List_Responded)),
                                    width: 70,
                                    sortable: false,
                                    attributes: {
                                        "class": "align-right"
                                    },
                                    headerAttributes: {
                                        style: "cursor: default"
                                    }
                                },
                                {
                                    field: "Error",
                                    title:$.htmlDecode( this.resources.Alert_List_Error),
                                    template: $("#alert-error-column-template").html(),
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', $.htmlDecode(this.resources.Alert_List_Error), $.htmlDecode(this.resources.Alert_List_Error)),
                                    width: 40,
                                    sortable: false,
                                    headerAttributes: {
                                        style: "cursor: default"
                                    }
                                }
                            ],
                    columnResize: function (e) { 
                        $("#alertList .k-grid-header table").css("width", "100%");
                        $("#alertList .k-grid-content table").css("width", "100%");
                    },
                    dataBound: this.OnDataBound
                }).data().kendoGrid;

                var $template = kendo.template($("#alert-tooltip-template").html());
                $("#alertList").kendoTooltip({
                    filter: "td:nth-child(3)",
                    content: function (e) {
                        var dataItem = $("#alertList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    }
                });

                this.refreshGrid();
                this.bindSelectAll();

                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");


                athoc.kendoGrid.utils.setStickyHeader();

                this.viewModel.SearchDisabled(true);
                this.viewModel.canClearAll(false);

                //this.originalGridOffset.Top = $('#alertList').offset().top;
                this.originalGridOffset.Top = $('#alertList').position().top;

                //this.originalGridOffset.headerTop = $('#alertList .k-grid-header').offset().top;
                this.originalGridOffset.headerTop = $('#alertList .k-grid-header').position().top;

                this.originalGridOffset.whiteoutHeight = $('.row-fluid .whiteout').height();

            },


            refreshGrid: function () {
                //show the loader when we make a request to the server...
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.wrap-all'), imageURL: this.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: this.resources.General_LoadingMessage }).showLoader();
                datasource.page(1);
                $('#alertList').css("margin-top", "21px");
            },

            OnDataBound: function (e) {

                $("html,body").scrollTop(0);
                athoc.iws.alert.list.bindOneCheckboxClick();
                athoc.iws.alert.list.checkAndSelectAll(); //check all if necessary



                $(athoc.iws.alert.list.gridSelector + " tbody").find("tr").attr("tabindex", "0");

                var grid = $(athoc.iws.alert.list.gridSelector).data("kendoGrid");
                var data = grid.dataSource.data();

                $(grid.tbody).unbind("click");

                $(grid.tbody).on("click", "td", function (event) {
                    var row = $(this).closest("tr");
                    var rowIdx = $("tr", grid.tbody).index(row);
                    var model = data[rowIdx];
                    var colIdx = $("td", row).index(this);
                    if (colIdx != 1) {
                        athoc.iws.alert.list.viewAlertDetail(model);
                    }
                });

                if (athoc.iws.alert.list.IsRightToLeft) {
                    $(this.gridSelector).find('.pull-right').addClass('pull-left');
                    $(this.gridSelector).find('.pull-right').removeClass('pull-right');
                }
            },

            bindSelectAll: function () {
                var self = this;
                $("#alert-select-all").change(function () {
                    var checked = $(this).is(':checked');
                    var grid = $(self.gridSelector).data().kendoGrid;
                    //dataSource.view() returns the page not the entire dataset.
                    if ($(this).is(':checked')) {
                        var array = grid.dataSource.data().toJSON();
                        self.viewModel.AddSelected(array);
                    } else {
                        var idsToDelete = grid.dataSource.data().map(function (val) { return val.AlertId; });
                        self.viewModel.RemoveSelected(idsToDelete);
                    }
                    $(".each-alert-select").prop('checked', $(this).is(':checked'));
                });
            },

            bindOneCheckboxClick: function () {
                var self = this;
                var grid = $(this.gridSelector).data("kendoGrid");
                $('.each-alert-select').on('click', function () {
                    var data = grid.dataSource.data();
                    var row = $(this).closest("tr");
                    var rowIdx = $("tr", grid.tbody).index(row);
                    var model = data[rowIdx];

                    if ($(this).is(':checked')) {
                        self.viewModel.AddSelected(new Array(model.toJSON()));
                        self.checkAndSelectAll();
                    } else {
                        self.viewModel.RemoveSelected([model.AlertId]);
                        $("#alert-select-all").prop('checked', false);
                    }
                });
            },

            checkAndSelectAll: function () {
                var checkboxes = $(this.gridSelector + " tbody").find("[type='checkbox']");
                if (checkboxes.length != 0) //if list is empty don't checkall
                {
                    var checkedCheckboxes = $(this.gridSelector + " tbody").find("input:checked");
                    if (checkedCheckboxes.length == checkboxes.length) {
                        $("#alert-select-all").prop('checked', true);
                    } else {
                        $("#alert-select-all").prop('checked', false);
                    }
                }
            },

            bindActionButtons: function () {
                var self = this;
                //new button
                $(this.parameters.newButtonSelector).on('click', function () {
                    window.location = self.parameters.urls.ScenarioPublisherUrl;
                });

                //edit button
                $(this.parameters.editButtonSelector).on('click', function () {
                    if (!self.viewModel.EditDisabled()) {
                        var alert = self.viewModel.GetSelectedAlertsArray()[0];
                        if (alert.Status == "Live") {
                            window.location = "/athoc-iws/alertmanager?nav=v&id=" + alert.AlertId;
                            return;
                        }

                        $(".alert-nav").hide();
                        $(".edit-alert").show();
                        navigateToPage('alertDetail', function () { });
                        athoc.iws.alert.detail.editAlert(alert.AlertId);
                        var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                        breadcrumbsModel.SelectedPage('alertDetail');
                        $.titleCrumb("pageBreadcrumbs");
                        $(document).scrollTop(0);
                        $.AjaxLoader.hideLoader();
                    }
                });

                //edit button
                $(this.parameters.publishButtonSelector).on('click', function () {
                    if (!self.viewModel.PublishDisabled()) {
                        athoc.iws.publishing.view.PublishAlert(self.viewModel.GetSelectedIdsArray()[0]);
                        athoc.iws.publishing.view.OnCloseAfterPublish = function () {
                            athoc.iws.alert.list.viewModel.ClearSelectedArray();
                            athoc.iws.alert.list.refreshGrid();
                            $('#dialogReviewAndPublish').modal('hide');
                        };
                    }
                });

                $(this.parameters.duplicateButtonSelector).on('click', function () {
                    if (!self.viewModel.DuplicateDisabled()) {
                        $(".alert-nav").hide();
                        $(".new-alert").show();

                        navigateToPage('alertDetail', function () { });
                        athoc.iws.alert.detail.duplicateAlert(self.viewModel.GetSelectedIdsArray()[0]);

                        var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                        breadcrumbsModel.SelectedPage('alertDuplicate');
                        $.titleCrumb("pageBreadcrumbs");
                        $(document).scrollTop(0);

                        $.AjaxLoader.hideLoader();
                    }
                });

                $(this.parameters.searchButtonSelector).on('click', function () {
                    if (!self.viewModel.SearchDisabled()) {
                        self.executeSearch();
                        self.setPills();
                    }
                });

                $(this.parameters.textSearchInput).keypress(function (e) {
                    self.viewModel.SearchDisabled(false);
                    self.viewModel.canClearAll(true);
                    if (e.which == 13) {
                        if (!self.viewModel.SearchDisabled()) {
                            self.executeSearch();
                            self.setPills();
                        }
                    }
                });

                $(this.parameters.toDateInput + "," + this.parameters.fromDateInput).keypress(function (e) {
                    self.viewModel.SearchDisabled(false);
                    self.viewModel.canClearAll(true);
                });

                $(this.parameters.textSearchInput).on('input', function (e) {
                    if ($('#textSearchInput').val() != "") {
                        self.viewModel.SearchDisabled(false);
                        self.viewModel.canClearAll(true);
                    }

                });

                $(this.parameters.btnClearAll).on('click', function (e) {
                    $(self.parameters.textSearchInput).val("");
                    self.viewModel.ResetToAllStatus();
                    self.viewModel.ResetChannel();
                    self.viewModel.ResetPublisher();
                    self.viewModel.ResetToAllSeverity();
                    self.viewModel.ResetToAllEvent();
                    self.viewModel.ToDateValue(undefined);
                    self.viewModel.FromDateValue(undefined);
                    self.viewModel.SearchDisabled(true);
                    self.viewModel.canClearAll(false);
                    self.viewModel.quickSearchPill(false);
                    self.viewModel.quickSearchPillText("");

                    self.viewModel.severityPill(false);
                    self.viewModel.severityPillSerialized("");

                    self.viewModel.eventTypePill(false);
                    self.viewModel.eventTypePillSerialized("");

                    self.viewModel.dateFromPill(false);
                    self.viewModel.dateToPill(false);
                    self.viewModel.dateRangePill(false);
                    self.viewModel.statusPill(false);
                    self.viewModel.channelPill(false);
                    self.viewModel.publisherPill(false);

                    self.executeSearch();
                });

                var actionSuccessCallback = function (data, textStatus, jqXHR) {
                    if (data.Success) {
                        self.refreshGrid();
                        //wipe out selections
                        self.viewModel.ClearSelectedArray();
                    }
                }

                $(this.parameters.deleteButtonSelector).on('click', function () {
                    if (!self.viewModel.DeleteDisabled()) {
                        self.parameters.alertActionFunction("delete", self.viewModel.GetSelectedAlertsArray(), actionSuccessCallback);
                    }
                });

                $(this.parameters.endButtonSelector).on('click', function () {
                    if (!self.viewModel.EndDisabled()) {
                        self.parameters.alertActionFunction("end", self.viewModel.GetSelectedAlertsArray(), actionSuccessCallback);
                    }
                });


            },
            executeSearch: function () {
                var self = this;
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: self.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: self.resources.General_LoadingMessage }).showLoader();

                //if "any publisher" is selected, send empty string to server for publisher
                var publisher = self.viewModel.PublisherToFilter();
                if ($(self.parameters.publisherDropDown).find("option").first().is(":selected")) {
                    publisher = "";
                }

                var from = new Date(self.viewModel.FromDateValueForServer);
                var to = new Date(self.viewModel.ToDateValueForServer);

                if (from > to) {
                    self.viewModel.FromDateValue(to);
                    $("#fromDatePicker").data("datetimepicker").setDate(to);
                }

                self.setFilter({
                    page: 1,
                    StatusFilter: self.viewModel.SelectedSerialized(self.viewModel.SelectedStatusArray),
                    SearchText: $(self.parameters.textSearchInput).val(), //binding to knockout model didn't work on IE9 with keypress, thus getting value using jq
                    FromDateString: self.viewModel.FromDateValueForServer,
                    ToDateString: self.viewModel.ToDateValueForServer,
                    ChannelId: self.viewModel.ChannelToFilter(),
                    Publisher: publisher,
                    Severities: self.viewModel.SelectedSerialized(self.viewModel.SelectedSeverityArray),
                    Events: self.viewModel.SelectedSerialized(self.viewModel.SelectedEventArray)
                });

                datasource.page(1);
                self.viewModel.ClearSelectedArray();
                $("#alert-select-all").prop('checked', false);

            },
            setFilter: function (filterOptions) {
                filter = filterOptions;
            },

            //refresh on load
            refreshOnLoad: false,

            viewAlertList: function (refresh) {
                athoc.iws.alert.action = '';
                athoc.iws.alert.source = '';

                var isModified = athoc.iws.publishing.detail.isChanged();

                if (isModified == true) {
                    var confirmLeave = confirm(athoc.iws.publishing.resources.Unsaved_Data_Text);
                    if (!confirmLeave) {
                        return;
                    } else {
                        athoc.iws.publishing.targetUsers.resetTargetingInfo();
                    }
                } else {
                    athoc.iws.publishing.targetUsers.resetTargetingInfo();
                }

                $("#btn_review_and_publish_tooltip").hide();
                athoc.iws.publishing.detail.setChanged(false);

                navigateToPage('alertList', function () { });
                var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                breadcrumbsModel.SelectedPage('alertList');
                $(document).scrollTop(0);

                //create grid if not pre-created
                if (!$(this.gridSelector).hasClass('k-grid')) {
                    athoc.iws.alert.list.load();
                }
                else if ((refresh != undefined && refresh) || athoc.iws.alert.list.refreshOnLoad) {
                    athoc.iws.alert.list.viewModel.ClearSelectedArray();
                    athoc.iws.alert.list.refreshGrid();
                }
                athoc.iws.alert.list.refreshOnLoad = false;

            },

            viewAlertDetail: function (selectedObj) {
                athoc.iws.alert.list.refreshOnLoad = false;

                if (selectedObj.Status == "Live" || selectedObj.Status == "Ended" || selectedObj.Status == "Publishing"){
                    window.location = kendo.format("/athoc-iws/AlertManager/ReportView?id={0}", selectedObj.AlertId);
                } 
                else if (athoc.iws.alert.IsAlertPublisher == 'False') {
                    window.location = "/client/alertmanager/Summary/" + selectedObj.AlertId;
                }
                else {
                    $(".alert-nav").hide();
                    $(".edit-alert").show();

                    navigateToPage('alertDetail', function () { });
                    athoc.iws.alert.detail.editAlert(selectedObj.AlertId);

                    var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                    breadcrumbsModel.SelectedPage('alertDetail');
                    $.titleCrumb("pageBreadcrumbs");
                    $(document).scrollTop(0);

                    $.AjaxLoader.hideLoader();
                }
            },

            createAlertFromScenairo: function (id) {
                $(".alert-nav").hide();
                $(".new-alert").show();

                navigateToPage('alertDetail', function () { });
                athoc.iws.alert.detail.createAlertFromScenario(id);

                var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;

                if (athoc.iws.alert.source == "event") {
                    breadcrumbsModel.SelectedPage('alertForward');
                } else {
                    breadcrumbsModel.SelectedPage('alertCreate');
                }

                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);

                $.AjaxLoader.hideLoader();
            },
            createAlertFromRbt: function (id, rbtdetails) {
                $(".alert-nav").hide();
                $(".new-alert").show();

                navigateToPage('alertDetail', function () { });
                athoc.iws.alert.detail.createAlertFromRbt(id, rbtdetails);

                var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;

                if (athoc.iws.alert.source == "event") {
                    breadcrumbsModel.SelectedPage('alertForward');
                } else {
                    breadcrumbsModel.SelectedPage('alertCreate');
                }

                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);

                $.AjaxLoader.hideLoader();
            },
            viewAlertSummary: function (id) {
                $(".alert-nav").hide();
                $(".new-alert").show();

                navigateToPage('alertView', function () { });
                athoc.iws.alert.detail.viewAlert(id);

                var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                breadcrumbsModel.SelectedPage('alertDetail');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);

                $.AjaxLoader.hideLoader();
            },

            fillSeverityDropdown: function () {
                var self = this;
                var myAjaxOptions = {
                    url: this.urls.GetSeverityUrl,
                    cache: false
                };
                var successFunction = function (data) {
                    _.each(data, function (item) {
                        self.viewModel.AllSeverityArray.push(item);
                    });
                }
                var ajaxOptions = $.extend({}, AjaxUtility(null, successFunction).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
            },


            fillEventTypeDropdown: function () {
                var self = this;
                var myAjaxOptions = {
                    url: this.urls.GetEventtypeUrl,
                    cache: false
                };
                var successFunction = function (data) {
                    _.each(data, function (item) {
                        self.viewModel.AllEventTypesArray.push(item);
                    });
                }
                var ajaxOptions = $.extend({}, AjaxUtility(null, successFunction).ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
            },


            fillChannelDropdown: function () {
                var self = this;
                var myAjaxOptions = {
                    url: this.urls.GetChannelsUrl,
                    cache: false
                };

                var successFunction = function (data) {
                    _.each(data, function (item) {
                        self.viewModel.AllChannelsArray.push(item);
                    });

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, successFunction).ajaxPostOptions, myAjaxOptions);

                $.ajax(ajaxOptions);
            },
            fillPublisherDropdown: function () {

                var self = this;

                $(self.parameters.publisherDropDown).prop('disabled', true).selectpicker('refresh');


                var myAjaxOptions = {
                    url: this.urls.GetPublishersUrl,
                    cache: false
                };

                var successFunction = function (data) {
                    _.each(data.Messages, function (item) {
                        self.viewModel.AllPublishersArray.push({ Name: item, id: 1 });
                    });
                    $(self.parameters.publisherDropDown).prop('disabled', false).selectpicker('refresh');
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, successFunction).ajaxPostOptions, myAjaxOptions);

                $.ajax(ajaxOptions);
            },
            listViewModel: function (creatorReference, intialStatusArray) { //vm for ko binding
                var self = this;

                /*Search related */
                this.quickSearchPill = ko.observable(false);
                this.quickSearchPillText = ko.observable();

                this.severityPill = ko.observable(false);
                this.severityPillSerialized = ko.observable();

                this.eventTypePill = ko.observable(false);
                this.eventTypePillSerialized = ko.observable();
                this.dateFromPill = ko.observable(false);
                this.dateToPill = ko.observable(false);

                this.statusPill = ko.observable(false);
                this.statusPillSerialized = ko.observable();
                this.channelPill = ko.observable(false);
                this.channelPillSerialized = ko.observable();
                this.publisherPill = ko.observable(false);
                this.publisherPillText = ko.observable();
                this.defaultPublisher = creatorReference.resources.Alert_List_Any_Publisher;
                this.dateRangePill = ko.observable(false);

                /*---------------*/

                this.SearchDisabled = ko.observable(true);
                this.canClearAll = ko.observable(false);
                this.SelectedArray = ko.observableArray();
                this.SearchableStatusArray = athoc.iws.publishing.settings.IsSchedulingSupported
                ? ko.observableArray([{ id: "Ended", label: creatorReference.resources.Alert_Status_Ended }, { id: "Draft", label: creatorReference.resources.Alert_Status_Standby }, { id: "Scheduled", label: creatorReference.resources.Alert_Status_Scheduled }, { id: "Live", label: creatorReference.resources.Alert_Status_Live }])
                : ko.observableArray([{ id: "Ended", label: creatorReference.resources.Alert_Status_Ended }, { id: "Draft", label: creatorReference.resources.Alert_Status_Standby }, { id: "Live", label: creatorReference.resources.Alert_Status_Live }]);

                if (intialStatusArray.length == 0) { //no filter, then select all. 
                    intialStatusArray = ko.toJS(this.SearchableStatusArray()).map(function (item) { return item.id; });
                }
                this.SelectedStatusArray = ko.observableArray(intialStatusArray);
                this.SelectedStatusArray.subscribe(function (newValue) {
                    self.SearchDisabled(false);
                    self.canClearAll(true);
                    if (newValue.length == 0) { //select all status
                        self.SelectedStatusArray.push("-1");//when no status is selected, add a bogus value to cause the alert API to return nothing
                    }
                });

                this.ResetToAllStatus = function () {
                    self.SelectedStatusArray(ko.toJS(self.SearchableStatusArray()).map(function (item) { return item.id; }));
                };

                this.SelectedSerialized = function (selectedArray) {
                    return ko.toJS(selectedArray);
                };

                this.AllEventTypesArray = ko.observableArray();
                this.AllSeverityArray = ko.observableArray();
                this.SelectedSeverityArray = ko.observable(ko.toJS(self.AllSeverityArray()).map(function (item) { return item.id; }));
                this.SelectedSeverityArray.subscribe(function (newValue) {
                    self.SearchDisabled(false);
                    self.canClearAll(true);
                });
                this.SelectedEventArray = ko.observable(ko.toJS(self.AllEventTypesArray()).map(function (item) { return item.id; }));
                this.SelectedEventArray.subscribe(function (newValue) {
                    self.SearchDisabled(false);
                    self.canClearAll(true);
                });
                this.ResetToAllSeverity = function () {
                    self.SelectedSeverityArray([]);
                }
                this.ResetToAllEvent = function () {
                    self.SelectedEventArray([]);
                }

                //channel dd
                this.ChannelToFilter = ko.observable(creatorReference.resources.Alert_List_All_Channels);
                this.ChannelToFilter.subscribe(function (newValue) {
                    self.SearchDisabled(false);
                    self.canClearAll(true);
                });
                this.AllChannelsArray = ko.observableArray([{ Id: -1, Name: creatorReference.resources.Alert_List_All_Channels }]);
                this.ResetChannel = function () {
                    $(creatorReference.parameters.channelFilter).val(-1).change();
                    this.ChannelToFilter(-1);
                }
                this.AllPublishersArray = ko.observableArray([{ Name: creatorReference.resources.Alert_List_Any_Publisher }]);

                //operator dd
                this.PublisherToFilter = ko.observable();
                this.PublisherToFilter.subscribe(function (newValue) {
                    self.SearchDisabled(false);
                    self.canClearAll(true);
                });
                this.ResetPublisher = function () {
                    $(creatorReference.parameters.publisherDropDown).val(creatorReference.resources.Alert_List_Any_Publisher).change();
                    this.PublisherToFilter(creatorReference.resources.Alert_List_Any_Publisher);
                }



                this.AddSelected = function (newSelectedArray) {
                    var self = this;
                    _.each(newSelectedArray, function (itemToAdd, index) {
                        var found = _.find(self.SelectedArray(), function (item) {
                            return (item.AlertId == itemToAdd.AlertId);
                        });
                        if (!found) {
                            self.SelectedArray.push(itemToAdd);
                        }
                    });
                };
                this.RemoveSelected = function (idsToRemove) {
                    var tempArray = ko.toJS(this.SelectedArray()); //copy array so count gets updated in UI only after array cleanup is done

                    for (i = 0; i < tempArray.length; i++) {
                        var index = idsToRemove.indexOf(tempArray[i].AlertId);
                        if (index > -1) {
                            //remove item from idsToRemove
                            idsToRemove.splice(index, 1);
                            //remove item from selected array
                            tempArray.splice(i, 1);
                            i--;
                        }
                        if (idsToRemove.length == 0) {
                            break;
                        }
                    }
                    this.SelectedArray(tempArray);
                };
                this.SelectedCount = ko.computed(function () {
                    return this.SelectedArray().length;
                }, this);
                this.IsSelected = function (alertId) {
                    var bl = false;
                    _.each(this.SelectedArray(), function (item, index) {
                        if (item.AlertId == alertId) {
                            bl = true;
                        }
                    });
                    return bl;
                };
                this.DuplicateDisabled = ko.computed(function () {
                    if (this.SelectedArray().length == 0 || this.SelectedArray().length > 1)
                        return true;
                    if (this.SelectedArray()[0].CanDuplicate) {
                        return false;
                    }
                    return true;
                }, this);
                this.EditDisabled = ko.computed(function () {
                    if (this.SelectedArray().length == 0 || this.SelectedArray().length > 1)
                        return true;
                    if (this.SelectedArray()[0].CanEdit) {
                        return false;
                    }
                    return true;
                }, this);
                this.PublishDisabled = ko.computed(function () {
                    if (this.SelectedArray().length == 0 || this.SelectedArray().length > 1)
                        return true;
                    if (this.SelectedArray()[0].CanPublish) {
                        return false;
                    }
                    return true;
                }, this);
                this.DeleteDisabled = ko.computed(function () {
                    if (this.SelectedArray().length == 0)
                        return true;
                    var found = _.find(this.SelectedArray(), function (item) {
                        return (!item.CanDelete);
                    });

                    if (!found) { //undeletable items don't exist, can enable button!
                        return false;
                    }
                    return true;
                }, this);
                this.EndDisabled = ko.computed(function () {
                    if (this.SelectedArray().length == 0)
                        return true;
                    var found = _.find(this.SelectedArray(), function (item) {
                        return (!item.CanEnd);
                    });

                    if (!found) { //undeletable items don't exist, can enable button!
                        return false;
                    }
                    return true;

                }, this);

                this.GetSelectedIdsArray = function () {
                    return this.SelectedArray().map(function (item) { return item.AlertId; });
                },
                this.GetSelectedNamesArray = function () {
                    return this.SelectedArray().map(function (item) { return item.Title; });
                },
                this.GetSelectedAlertsArray = function () {
                    return this.SelectedArray();
                }
                this.ClearSelectedArray = function () {
                    this.SelectedArray([]);
                }
                //date & datetime
                this.FromDateValueForServer = "";
                this.PreviousFromDateValue = "";

                this.FromDateValue = ko.observable();
                this.FromDateValue.subscribe(function (newValue) {

                    self.SearchDisabled(false);
                    self.canClearAll(true);

                    if (newValue == null || newValue.length == 0) {
                        $(creatorReference.parameters.toDatePicker).data("datetimepicker").setStartDate(-Infinity);
                        self.FromDateValueForServer = "";
                    } else if (typeof newValue == "string") { //ingore if not dateTime object
                        return;
                    } else {
                        var newDate = moment(newValue);
                        if (newDate.isValid()) {
                            var newDate = moment(newValue).format("M/D/YYYY");
                            self.FromDateValueForServer = newDate;
                            $(creatorReference.parameters.toDatePicker).data("datetimepicker").setStartDate(newValue);

                            //need to convert to datetime object for accurate comparison.
                            var todate = new Date(self.ToDateValue());
                            //when input is typed in and is invalid (from is after to date and vice versa), copy that value. 
                            if (todate < newValue) {
                                self.ToDateValue(newValue);
                                $(creatorReference.parameters.toDatePicker).data("datetimepicker").setDate(newValue);
                            }
                        } else {
                            $(creatorReference.parameters.toDatePicker).data("datetimepicker").setStartDate(-Infinity);
                            self.FromDateValueForServer = "";
                        }
                    }

                });
                this.ToDateValueForServer = "";
                this.PreviousToDateValue = "";
                this.ToDateValue = ko.observable();


                this.ToDateValue.subscribe(function (newValue) {

                    self.SearchDisabled(false);
                    self.canClearAll(true);

                    if (newValue == null || newValue.length == 0) {
                        $(creatorReference.parameters.fromDatePicker).data("datetimepicker").setEndDate(Infinity);
                        self.ToDateValueForServer = "";
                    } else if (typeof newValue == "string") { //ingore if not dateTime object
                        return;
                    } else {
                        var newDate = moment(newValue);
                        if (newDate.isValid()) {

                            var newDate = moment(newValue).format("M/D/YYYY");

                            self.ToDateValueForServer = newDate;
                            $(creatorReference.parameters.fromDatePicker).data("datetimepicker").setEndDate(newValue);

                            //need to convert to datetime object for accurate comparison.
                            var fromdate = new Date(self.FromDateValue());
                            //when input is typed in and is invalid (from is after to date and vice versa), copy that value. 
                            if (fromdate > newValue) {
                                self.FromDateValue(newValue);
                                $(creatorReference.parameters.fromDatePicker).data("datetimepicker").setDate(newValue);
                            }
                        } else {
                            $(creatorReference.parameters.fromDatePicker).data("datetimepicker").setEndDate(Infinity);
                            self.ToDateValueForServer = ""; 
                        }
                    }


                });

                this.DateRange = ko.computed(function () {
                    var dateRangeText = "";
                    if (self.FromDateValue() && self.ToDateValue()) {
                        dateRangeText = moment(self.FromDateValue()).format(dateformat.toUpperCase()) + " - " +
                            moment(self.ToDateValue()).format(dateformat.toUpperCase());
                    }
                    return dateRangeText;
                });

            }
        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.alert.detail.js
/// <reference path="athoc.iws.alert.detail.js" />
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};

if (athoc.iws.alert) {
    athoc.iws.alert.detail = function () {
        return {
            parameters: null,
            init: function (args) {
                this.parameters = args;
            },

            //create alert
            createAlertFromScenario: function (id, show) {
                $(".publishing-detail").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.alert.parameters.urls.CreateAlertFromScenarioUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true,id, true);

                //if id is 0 that means we are creating a blank alert.
                athoc.iws.publishing.targetUsers.Parameters.context = id == 0 ? "Alert" : "Scenario";

                //athoc.iws.publishing.targetUsers.load(id);
            },

            //create alert
            createAlertFromRbt: function (id, rbtdetails, show) {
                $(".publishing-detail").hide();
                $('#messagePanel').messagesPanel('reset');
                var loadUrl = athoc.iws.publishing.urls.CreateAlertFromRbtUrl + "?id=" + rbtdetails.AlertId + "&recipientType=" + rbtdetails.EntityFilterId + "&deviceId=" + rbtdetails.DeviceId + "&fillCount=" + rbtdetails.FillCountType + "&source=" + rbtdetails.Source + "&accEventId=" + rbtdetails.AccountabilityEventId;

                athoc.iws.publishing.targetUsers.Parameters.context = id == 0 ? "Alert" : "Scenario";
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true,id);

                //if id is 0 that means we are creating a blank alert.
               

               
            },


            //edit alert
            editAlert: function (id, show) {
                $(".publishing-detail").hide();
                $("#btn_review_and_publish").hide();
                $('#messagePanel').messagesPanel('reset');
                //IWS-14925 - hide the buttons while loading
                $("#btn_test_alert").hide();                
                $("#btn_detail_save").hide();

                var loadUrl = athoc.iws.alert.parameters.urls.GetAlertDetailUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true,id,true);
                //athoc.iws.publishing.targetUsers.load(id);
            },

            //view alert
            viewAlert: function (id, show) {
                $(".publishing-detail").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.alert.parameters.urls.GetAlertDetailUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true, id, true);
            },

            //duplicate alert
            duplicateAlert: function (id) {
                $(".publishing-detail").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.alert.parameters.urls.DuplicateAlertUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true,id, true);
                //athoc.iws.publishing.targetUsers.load(id);
                //reset Live/Ended Alerts flags when its duplicated 
                athoc.iws.alert.schedule.viewModel.isLiveAlert(false);                
                athoc.iws.alert.schedule.viewModel.isLiveorEnded(false);                
                athoc.iws.alert.schedule.viewModel.isEndedAert(false);
            },

            //save alert
            saveAlert: function () {
                athoc.iws.alert.detail.postAlert(athoc.iws.alert.parameters.urls.SaveAlertUrl);
                athoc.iws.alert.list.refreshOnLoad = true;
                return true;
            },

            //standby alert
            standbyAlert: function () {
                athoc.iws.alert.detail.postAlert(athoc.iws.alert.parameters.urls.StandbyAlertUrl, false);
                return true;
            },

            //review & publish
            reviewAndPublish: function () {
                $('#messagePanel').messagesPanel('reset');

                //check if is data valid
                var isValid = athoc.iws.publishing.content.isValid();

                if (!isValid) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.parameters.resources.Alert_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }


                //try publishing only if ready
                if (!athoc.iws.publishing.detail.isReadyToPublish()) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.parameters.resources.Alert_Validation_NotReadyForPublish }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }


                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
                var contentModel = athoc.iws.publishing.content.getModel();
                var placeholderModel = athoc.iws.publishing.content.getModel();


                var alertObj = {
                    EntityId: athoc.iws.publishing.detail.viewModel.EntityId,
                    ParentId: athoc.iws.publishing.detail.viewModel.ParentId,
                    Content: contentModel ,
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    TargetOrg: athoc.iws.publishing.targetOrg.getModel(),
                    AlertScheduleSettings: athoc.iws.alert.schedule.getModel(),
                    MassDevices: massDeviceModel == null ? [] : massDeviceModel.MassDevices,
                    MassDeviceGroupOptions: massDeviceModel == null ? [] : massDeviceModel.MassDeviceGroupOptions,
                    CustomPlaceHolders: placeholderModel,
                    AllPlaceHolderIds: athoc.iws.publishing.getPlaceholderList(),
                    //TargetingTree: athoc.iws.publishing.view.viewModel.TargetingTree(),
                    alertOrigin: athoc.iws.publishing.alertOrgin,
                    rbt: athoc.iws.publishing.rbt,
                    FillCount: athoc.iws.publishing.fillcount.getModel(),
                    EscalationAttributes:  athoc.iws.publishing.fillcount.viewModel.escalationAttributes()  ,
                    SequencingAttributes:  athoc.iws.publishing.fillcount.viewModel.phonesequencingAttributes(),
                };


               
                athoc.iws.publishing.view.ReviewAndPublish(alertObj);
                athoc.iws.publishing.view.OnCloseAfterPublish = function (id) {
                    if (athoc.iws.alert.source == 'publisher') {
                        window.location = '/athoc-iws/scenariomanager/scenariopublisher';
                    }
                    else if (athoc.iws.alert.source == 'home') {
                        window.location = '/athoc-iws';
                    }
                    else if (athoc.iws.alert.source == 'event') {
                        window.location = '/athoc-iws/EventManager';
                    }
                    else if (athoc.iws.alert.source == 'log') {
                        window.location = '/athoc-iws/EventManager/activitylog';
                    }

                    else {
                        athoc.iws.alert.list.viewAlertList(true);
                        $('#dialogReviewAndPublish').modal('hide');
                    }
                };
            },

            postAlert: function (postUrl, stayOnPage) {
                $('#messagePanel').messagesPanel('reset');
                //set the flat to reload
                //athoc.iws.alert.refreshList = true;

                //Check if all sections are valid
                var isValid = athoc.iws.publishing.content.isValid() && athoc.iws.publishing.content.isLocationMandatory(false);

                if (!isValid) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.parameters.resources.Alert_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }

                athoc.iws.publishing.detail.setChanged(false);
                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
                //If content section is readonly need to get data from Publishing.View.viewModel.data.content
                var contentModel = athoc.iws.publishing.content.getModel() == undefined ?  ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content) :  athoc.iws.publishing.content.getModel();
                //Get updated data from each section in viewmodel
                var alertObj = {
                    EntityId: athoc.iws.publishing.detail.viewModel.EntityId,
                    ParentId: athoc.iws.publishing.detail.viewModel.ParentId,
                    Content: contentModel,
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    TargetOrg: athoc.iws.publishing.targetOrg.getModel(),
                    AlertScheduleSettings: athoc.iws.alert.schedule.getModel(),
                    MassDevices: massDeviceModel == null ? [] : massDeviceModel.MassDevices,
                    MassDeviceGroupOptions: massDeviceModel == null ? [] : massDeviceModel.MassDeviceGroupOptions,
                    AllPlaceHolderIds: athoc.iws.publishing.getPlaceholderList(),
                    CustomPlaceHolders: athoc.iws.alert.placeholder.getModel(),
                    AlertOrigin: athoc.iws.publishing.alertOrgin,
                    rbt: athoc.iws.publishing.rbt != null ? athoc.iws.publishing.rbt : null,
                    FillCount: athoc.iws.publishing.fillcount.getModel(),

                };

                //Check Alert Duration while saving  Draft Alert, if empty set to default value
                if (alertObj.AlertScheduleSettings != null && ((postUrl == athoc.iws.alert.parameters.urls.StandbyAlertUrl || postUrl == athoc.iws.alert.parameters.urls.SaveAlertUrl) && alertObj.AlertScheduleSettings.ScheduleDurationInput == ""))
                    alertObj.AlertScheduleSettings.ScheduleDurationInput = "4";

                if (this.parameters.showOrganizations) {
                    alertObj.TargetOrg = athoc.iws.publishing.targetOrg.getModel();
                }

                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        url: postUrl,
                        contentType: false,
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(alertObj)
                    };

                var ajaxSuccess = function (data) {
                    $.AjaxLoader.hideLoader();
                    if (data.Success) {
                        //IWS12606
                        //redirect to Sent Alerts screen when Alert status is not Draft or Standby
                        if (data.Data.AlertStatus != 'Draft' && data.Data.AlertStatus != 'Standby')
                        {
                            $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.parameters.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);
                            redirectToExternalUrl('/athoc-iws/AlertManager/Index');
                            return true;
                        }
                        if (stayOnPage == undefined || stayOnPage) {
                            athoc.iws.publishing.detail.resetLoadedStatus();

                            athoc.iws.publishing.detail.bindModel(data, true);
                            $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.parameters.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);

                            //reset targeting selection
                            //athoc.iws.publishing.targetUsers.getTargetingSelection();
                            athoc.iws.publishing.targetUsers.load(athoc.iws.publishing.detail.viewModel.EntityId);


                        } else {
                            athoc.iws.publishing.targetUsers.Parameters.context = "Alert"; //reset context to Alert just in case you are coming from scenario publisher
                            athoc.iws.alert.list.viewAlertList(true);
                        }
                    } else {
                        $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(-200);
                    }

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;

            },
            TestAlert: function () {

                var replacementModels = null;
                var placeholders = null;
                if (athoc.iws.alert.placeholder) {
                    placeholders = athoc.iws.alert.placeholder.getModel();
                }
                var alertObj = {
                    EntityId: 0,
                    ParentId: 0,
                    Content: athoc.iws.publishing.content.getModel(),
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    AlertScheduleSettings: athoc.iws.alert.schedule.getModel(),
                    AlertOrigin: athoc.iws.publishing.alertOrgin,
                    rbt: athoc.iws.publishing.rbt
                };

                var replacementModels =
                    [{ GroupId: 0, FieldId: 'title', Value: alertObj.Content.Title, MinLength: 3, MaxLength: 100, Label: 'Title' },
                        { GroupId: 0, FieldId: 'body', Value: alertObj.Content.Body, MinLength: 0, MaxLength: 2000, Label: 'Body' }];

                if (alertObj.Content.ResponseOptionId == 0 && alertObj.Content.ResponseOptions.length) {
                    $.each(alertObj.Content.ResponseOptions, function (index, objOption) {
                        replacementModels.push({ GroupId: 0, FieldId: 'response-option-' + index, Value: objOption.ResponseText, MinLength: 1, MaxLength: 64, Label: 'Response Option ' + (index + 1) });
                    });
                }
                
                $('#alertMessagePanel').messagesPanel('reset');

                //Check if all sections are valid
                var isValid = athoc.iws.publishing.content.isValid();

                if (!isValid) {
                    $('#alertMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.parameters.resources.Alert_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }
                isValid = athoc.iws.alert.test.getModel().length > 0;
                if (!isValid) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: "At least ONE personal device should be selected." }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }

                $('#btn_send_test_alert').prop("disabled", true);

                var model = {
                    PlaceholderReplacementModels: replacementModels,
                    SelectedPlaceHolders: placeholders,
                    DeviceGroupOptions: [],
                    DeviceGroupOptionsRawXML: []
                };

                var dlAjaxOption =
                {
                    url: "/athoc-iws/publishing/ReplacePlaceholders",
                    dataType: 'json',
                    type: 'POST',
                    data: JSON.stringify(model)
                };
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#TestAlert'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                var reqError = new Array();
                var ajaxSuccess = function (data) {

                    if (data.Success) {

                        //replace values into publishing model and show any validation errors
                        var vm = alertObj;
                        var isValid = true;
                        if (data.Model && data.Model.PlaceholderReplacementModels) {
                            $.each(data.Model.PlaceholderReplacementModels, function (index, objResponse) {
                                var field = objResponse.Label;
                                if (objResponse.GroupId == 0 && objResponse.FieldId == 'title') {
                                    vm.Content.Title=objResponse.Value;
                                } else if (objResponse.GroupId == 0 && objResponse.FieldId == 'body') {
                                    vm.Content.Body=objResponse.Value;
                                    if (objResponse.Value) {
                                        athoc.iws.publishing.view.viewModel.bodyWithLineBreak($.htmlEncode(objResponse.Value.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />'));
                                    } else {
                                        athoc.iws.publishing.view.viewModel.bodyWithLineBreak('');
                                    }
                                } else if (objResponse.GroupId == 0 && objResponse.FieldId.lastIndexOf('response-option-', 0) === 0) {
                                    var id = objResponse.FieldId.split("-")[2];
                                    alertObj.Content.ResponseOptions[id].ResponseText=objResponse.Value;
                                } else if (objResponse.GroupId != 0) { //pass label (field) for localization
                                    var deviceName = athoc.iws.publishing.view.setDeviceCustomText(objResponse.GroupId, objResponse.FieldId, objResponse.Value, false, field);
                                    if (deviceName && deviceName != "") {
                                        field = deviceName;
                                        if (objResponse.Label != "") {
                                            field += ' ' + objResponse.Label;
                                        }
                                    } else {
                                        field = objResponse.Label;
                                    }
                                }

                                if (objResponse.Value!="" && !athoc.iws.publishing.view.isPlaceholderReplacementModelValid(objResponse)) {
                                    isValid = false;
                                    var errorString=kendo.format(athoc.iws.publishing.resources.Publishing_Replaceholder_ErrorMessage, field, objResponse.MinLength, objResponse.MaxLength);
                                    reqError.push({ Type: '4', Value: errorString });
                                }
                            });
                        }

                        
                        if (!isValid && reqError.length > 0) {
                            $('#alertMessagePanel').messagesPanel({ messages: reqError }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $.AjaxLoader.hideLoader();

                        } else {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.alert.detail.TestAlertSubmit(vm);
                        }
                        


                    } else {
                        reqError.push({ Type: '4', Value: data.Messages });
                        $('#alertMessagePanel').messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        
                        $.AjaxLoader.hideLoader();
                    }

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

            },
            TestAlertSubmit: function (alertObj) {
                
                // Below settings are modified to target logged in operator for test alert
                // Assign devices which operator is allowed
                alertObj.TargetUsers.Devices = athoc.iws.alert.test.getModel();
                // Remove all Targeting criterias
                alertObj.TargetUsers.TargetingNodes = [];
                alertObj.TargetUsers.TargetUsersByArea = false;
                alertObj.TargetUsers.TargetedCriteria = null;
                alertObj.TargetUsers.TargetedBlockedUsers = [];
                alertObj.AlertScheduleSettings.ScheduleAlertPublishStartModeSettime = "ASAP";
                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#TestAlert'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        url: athoc.iws.publishing.urls.CreateTestAlertUrl,
                        contentType: false,
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(alertObj)
                    };

                var ajaxSuccess = function (data) {
                    $.AjaxLoader.hideLoader();
                    if (data.Success) {
                        $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(-200);

                    } else {
                        $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(-200);
                    }
                    $("#TestAlert").hide();
                    $("#testbackshade").hide();
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;

            },


            downloadPdfFile: function (postUrl) {

                athoc.iws.publishing.detail.setChanged(false);
                var contentModel = athoc.iws.publishing.content.getModel();
                //Get updated data from each section in viewmodel
                var alertObj = {
                    Content: contentModel == undefined ? ko.mapping.toJS(athoc.iws.publishing.content.ReadonlyViewModel.data.Content) : contentModel,
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    TargetOrg: athoc.iws.publishing.targetOrg.getModel(),
                    AlertScheduleSettings: athoc.iws.publishing.settings.IsSchedulingSupported ? athoc.iws.alert.schedule.getModel() : null,
                    MassDevices: athoc.iws.publishing.massdevices.getModel() == null ? [] : athoc.iws.publishing.massdevices.getModel().MassDevices,
                    MassDeviceGroupOptions: athoc.iws.publishing.massdevices.getModel() == null ? [] : athoc.iws.publishing.massdevices.getModel().MassDeviceGroupOptions,
                };

                if (this.parameters.showOrganizations) {
                    alertObj.TargetOrg = athoc.iws.publishing.targetOrg.getModel();
                }

                //Send view model to server for saving
                var piechartData = "";
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly)
                    piechartData = $("#piechartSummaryDetail").outerHTML();
                else
                    piechartData = $("#piechartSummary").outerHTML();

                // Set the data for location map
                if ($('#miniMapHolder').html() != "")
                    locationdata = $('#miniMapHolder').outerHTML();


                var param = $.param({ feed: ko.toJSON(alertObj), pieChartData: piechartData, locationData: locationdata });
                $.fileDownload(postUrl, {
                    httpMethod: "POST",
                    data: param,
                    successCallback: function () {
                    },
                    failureCallback: function () {
                    }
                });
                return true;
            },

            saveAlertDetails: function (postUrl, stayOnPage) {
                $('#alertView').find('#messagePanel').messagesPanel('reset');
           

                if (athoc.iws.alert.schedule.viewModel.isLiveAlert());
                var isValid = athoc.iws.alert.schedule.isInErrorState;

                if (isValid) {
                    $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.parameters.resources.Alert_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }



                athoc.iws.publishing.detail.setChanged(false);
                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
                //If content section is readonly need to get data from Publishing.View.viewModel.data.content
                var contentModel = athoc.iws.publishing.content.getModel() == undefined ? ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content) : athoc.iws.publishing.content.getModel();
                //Get updated data from each section in viewmodel
                var alertObj = {
                    EntityId: athoc.iws.publishing.detail.viewModel.EntityId,
                    ParentId: athoc.iws.publishing.detail.viewModel.ParentId,
                    Content: contentModel,
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    TargetOrg: athoc.iws.publishing.targetOrg.getModel(),
                    AlertScheduleSettings: athoc.iws.alert.schedule.getModel(),
                    MassDevices: massDeviceModel == null ? [] : massDeviceModel.MassDevices,
                    MassDeviceGroupOptions: massDeviceModel == null ? [] : massDeviceModel.MassDeviceGroupOptions,
                    AllPlaceHolderIds: athoc.iws.publishing.getPlaceholderList(),
                    CustomPlaceHolders: athoc.iws.alert.placeholder.getModel(),
                    AlertOrigin: athoc.iws.publishing.detail.viewModel.AlertOrigin,
                    rbt: athoc.iws.publishing.rbt,
                };


                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        url: postUrl,
                        contentType: false,
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(alertObj)
                    };

                var ajaxSuccess = function (data) {
                    $.AjaxLoader.hideLoader();
                    if (data.Success) {
                        //IWS12606
                        //redirect to Sent Alerts screen when Alert status is not Draft or Standby
                        if (data.Data.AlertStatus != 'Draft' && data.Data.AlertStatus != 'Standby') {
                            $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.parameters.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);
                            redirectToExternalUrl('/athoc-iws/AlertManager/Index');
                            return true;
                        }
                        if (stayOnPage == undefined || stayOnPage) {
                            athoc.iws.publishing.detail.bindModel(data, true);
                            $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.parameters.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);

                            //reset targeting selection
                            //athoc.iws.publishing.targetUsers.getTargetingSelection();
                            athoc.iws.publishing.targetUsers.load(athoc.iws.publishing.detail.viewModel.EntityId);


                        } else {
                            athoc.iws.publishing.targetUsers.Parameters.context = "Alert"; //reset context to Alert just in case you are coming from scenario publisher
                            athoc.iws.alert.list.viewAlertList(true);
                        }
                    } else {
                        $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(-200);
                    }

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;

            },
                       
            saveReportAlertDetails: function (postUrl, stayOnPage) {
                $('#messagePanel').messagesPanel('reset');
                $('#alertView').find('#messagePanel').messagesPanel('reset');
                


                if (athoc.iws.alert.schedule.viewModel.isLiveAlert());
                var isValid = athoc.iws.alert.schedule.isInErrorState;

                if (isValid) {
                    $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.report.resources.Alert_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }



                athoc.iws.publishing.detail.setChanged(false);

                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();

                //If content section is readonly need to get data from Publishing.View.viewModel.data.content
                // var contentModel = athoc.iws.publishing.content.getModel() == undefined ? ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content) : athoc.iws.publishing.content.getModel();

                //Get updated data from each section in viewmodel
                var alertObj = {
                    EntityId: athoc.iws.publishing.detail.viewModel.EntityId,
                    ParentId: athoc.iws.publishing.detail.viewModel.ParentId,
                    AlertScheduleSettings: athoc.iws.alert.schedule.getModel(),
                    CustomPlaceHolders: athoc.iws.alert.placeholder.getModel(),
                    AlertOrigin: athoc.iws.publishing.detail.viewModel.AlertOrigin,
                    rbt: athoc.iws.publishing.rbt,
                };


                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        url: postUrl,
                        contentType: false,
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(alertObj)
                    };

                var ajaxSuccess = function (data) {
                    $.AjaxLoader.hideLoader();
                    if (data.Success) {
                        //IWS12606
                        //redirect to Sent Alerts screen when Alert status is not Draft or Standby
                        if (data.Data.AlertStatus != 'Draft' && data.Data.AlertStatus != 'Standby') {
                            $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.report.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);
                            //redirectToExternalUrl('/athoc-iws/AlertManager/Index');
                            return true;
                        }
                        if (stayOnPage == undefined || stayOnPage) {
                            athoc.iws.publishing.detail.bindModel(data, true);
                            $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.report.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);

                            //reset targeting selection
                            //athoc.iws.publishing.targetUsers.getTargetingSelection();
                            athoc.iws.publishing.targetUsers.load(athoc.iws.publishing.detail.viewModel.EntityId);


                        } else {
                            athoc.iws.publishing.targetUsers.Parameters.context = "Alert"; //reset context to Alert just in case you are coming from scenario publisher
                            athoc.iws.alert.list.viewAlertList(true);
                        }
                    } else {
                        $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(-200);
                    }

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;

            },
            
        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.alert.schedule.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};

if (athoc.iws.alert) {
    // Enable/disable controls in all browsers
    ko.bindingHandlers['CustomEnable'] = (function () {
        return {
            init: function (element, valueAccessor) {
                var $element = $(element);
                var value = ko.utils.unwrapObservable(valueAccessor());
                if (value)
                    $('[data-id=' + ($element[0].id) + ']').removeClass("disabled");
                else
                    $('[data-id=' + ($element[0].id) + ']').addClass("disabled"); 

            },
            update: function (element, valueAccessor) {
                var value = ko.utils.unwrapObservable(valueAccessor());
                var $element = $(element);
                if (value)
                    $('[data-id=' + ($element[0].id) + ']').removeClass("disabled");
                else
                    $('[data-id=' + ($element[0].id) + ']').addClass("disabled");
            }
        };
    }());
    athoc.iws.alert.schedule = function () {
        return {
            isReadyToPublish: false,
            isInErrorState: false,
            AMPMformat: false,
            viewModel: {
                alertschedule: ko.observableArray(),
                timeformart: ko.observableArray(),
                Visible: ko.observable(false),
                Collapsed: ko.observable(false),
                Readonly: ko.observable(false),
                Mode: "",
                isLiveAlert: ko.observable(false),
                isLiveorEnded: ko.observable(true),
                isEndedAert: ko.observable(false),
                isFillCountEnabled: ko.observable(false),
            },


            load: function () {

            },

            GetLocalizedDurationUnit: function(){
                switch (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInputUnit()) {
                case 'Minute':
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Minutes);
                case 'Hour':
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Hours);
                case 'Day':
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Days);
                }

                return athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInputUnit();
            },

        initiatePickers: function () {

                var AMPMformat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? true : false;
                //var datetimeformat = AMPMformat ? athoc.iws.alert.schedule.getVPSTimeFormat('dateformat') : athoc.iws.alert.schedule.getVPSTimeFormat('dateformat').replace("HH:", "hh:");
                var momentdatetimeformat = athoc.iws.alert.schedule.getVPSTimeFormat('momentformat');

                if (!athoc.iws.alert.schedule.viewModel.isLiveAlert()) {
                    $("#ddlAlertScheduleDurationHours").selectpicker();

                    $('#publishing-alert-edit').find('#istartDateValue').datetimepicker({
                        pick12HourFormat: AMPMformat,
                        pickSeconds: ($.vpsDateTimeFormat.indexOf('ss') > 0 ? true : false),
                        language: $.culture,
                         startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleString(), "MM/DD/YYYY")),
                         format: $.vpsDateTimeFormat
                    }).on('changeDate', function (ev) {
                        var newDate = null;
                        if (ev.localDate != null)
                            newDate = moment(ev.localDate).format(momentdatetimeformat);
                        athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput(newDate);
                    });


                } else {

                    $('#alert-detail').find('#iendDateValue').datetimepicker({
                        pick12HourFormat: AMPMformat,
                        language: $.culture,
                        pickSeconds: ($.vpsDateTimeFormat.indexOf('ss') > 0 ? true : false),
                        startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleString(), "MM/DD/YYYY")),
                        format: $.vpsDateTimeFormat
                    }).on('changeDate', function (ev) {
                        if (ev.localDate == null)
                            return;
                        var newDate = moment(ev.localDate).format(momentdatetimeformat);
                        athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEndDateInput(newDate);
                    });
                    $("#ddlviewAlertScheduleHr").selectpicker();
                    $("#ddlAlertScheduleMin").selectpicker();
                    $("#ddlAlertScheduleMer").selectpicker();

                }

                $("#publishing-alert-view .icon-calendar").click(function () { $('html,body').animate({ scrollTop: 9999 }, 'slow'); $('.bootstrap-datetimepicker-widget').css("z-index", "6"); });
                $("#publishing-alert-edit .icon-calendar").click(function () { $('html,body').animate({ scrollTop: 9999 }, 'slow'); $('.bootstrap-datetimepicker-widget').css("z-index", "6"); });
            },
            bindReadOnlyView: function (alertscheduledata, targetDiv) {

                if ((athoc.iws.publishing.detail.viewModel.AlertStatus == "Live" || athoc.iws.publishing.detail.viewModel.AlertStatus == "Ended") && (athoc.iws.alert.source != "rbt")) {
                    athoc.iws.alert.schedule.viewModel.isLiveorEnded(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Live")
                        athoc.iws.alert.schedule.viewModel.isLiveAlert(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Ended")
                        athoc.iws.alert.schedule.viewModel.isEndedAert(true);
                } else {
                    athoc.iws.alert.schedule.viewModel.isLiveorEnded(false);
                    athoc.iws.alert.schedule.viewModel.isLiveAlert(false);
                    athoc.iws.alert.schedule.viewModel.isEndedAert(false);
                }

                athoc.iws.alert.schedule.setIsFillCountEnabled();

                athoc.iws.alert.schedule.viewModel.alertschedule = ko.mapping.fromJS(alertscheduledata, athoc.iws.alert.schedule.getValidation());

                ko.cleanNode($(targetDiv).find("#publishing-alert-view").get(0));
                athoc.iws.alert.schedule.viewModel.Mode = (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() == "ASAP" ? "ASAP" : "SET TIME");
                ko.applyBindings(athoc.iws.alert.schedule.viewModel, $(targetDiv).find("#publishing-alert-view").get(0));


            },
            bind: function (data, alertscheduledata) {

                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return;

                if (athoc.iws.alert && athoc.iws.alert.action && athoc.iws.alert.action == 'rbt')
                    alertscheduledata.ScheduleAlertPublishStartModeSettime = "ASAP";

                athoc.iws.alert.schedule.viewModel.Visible(data.Advanced.Visible);
                athoc.iws.alert.schedule.viewModel.Collapsed(data.Advanced.Collapsed);
                athoc.iws.alert.schedule.viewModel.Readonly(data.Advanced.Readonly);

                athoc.iws.alert.schedule.viewModel.alertschedule = ko.mapping.fromJS(alertscheduledata, athoc.iws.alert.schedule.getValidation());
                athoc.iws.alert.schedule.viewModel.timeformart(alertscheduledata.TimeFormat);

                //If Status is live ko binding based on the target div.
                //Hiding the status span
                var status = ["Publishing", "Live", "Ended"];
                if ((status.indexOf(athoc.iws.publishing.detail.viewModel.AlertStatus) > -1) && (athoc.iws.alert.source != "rbt")) {
                    athoc.iws.alert.schedule.viewModel.isLiveorEnded(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Live")
                        athoc.iws.alert.schedule.viewModel.isLiveAlert(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Ended")
                        athoc.iws.alert.schedule.viewModel.isEndedAert(true);

                    $("#alert-detail").find(".bootstrap-select").remove();
                    if (athoc.iws.publishing.fillcountfillCountSummary != null)
                        athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);
                    ko.cleanNode($("#alert-detail").get(0));
                    ko.applyBindings(athoc.iws.alert.schedule.viewModel, $("#alert-detail").get(0));
                    athoc.iws.alert.schedule.initiatePickers();
                }
                else {
                    $("#publishing-alert-edit").find(".bootstrap-select").remove(); 
                    if (athoc.iws.publishing.fillcountfillCountSummary != null)
                        athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);
                    if (athoc.iws.publishing.fillcountfillCountSummary != null)
                        athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);
                    ko.cleanNode($("#publishing-alert-edit").get(0));
                    ko.applyBindings(athoc.iws.alert.schedule.viewModel, $("#publishing-alert-edit").get(0));
                    athoc.iws.alert.schedule.initiatePickers();
                    if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() == "ASAP")
                    athoc.iws.alert.schedule.enableDateforSetTime(athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime());
                }
                if (athoc.iws.publishing.fillcountfillCountSummary != null)
                    athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);

                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });

                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.enableDateforSetTime(newValue);
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput.extend({ notify: 'always' });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateHourSelect.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateMinuteSelect.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateAmpmSelect.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });

                athoc.iws.alert.schedule.isAlertScheduleReady();

            },
            setIsFillCountEnabled: function () {
                var fillCount = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.FillCount);
                athoc.iws.alert.schedule.viewModel.isFillCountEnabled((fillCount == null || fillCount.FillCount == 0) ? false : true);
            },
            toggleCollpase: function () {
                targetDiv = $("#publishing-alert-edit");

                ////show bucket expanded by default
                if (athoc.iws.alert.schedule.viewModel.Collapsed()) {
                    targetDiv.find(".bucket-toggle .row").hide();
                    targetDiv.find(".bucket-toggle .expand-arrow-open").hide();
                    targetDiv.find(".bucket-toggle .expand-arrow-closed").show();
                }
                else {
                    targetDiv.find(".bucket-toggle .row").show();
                    targetDiv.find(".bucket-toggle .expand-arrow-open").show();
                    targetDiv.find(".bucket-toggle .expand-arrow-closed").hide();
                }
            },
            validDateTime: function (checkStartDate) {
                var vDate;
                if (checkStartDate)
                    vDate = athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput();// + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateHourSelect() + ":" + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateMinuteSelect() + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateAmpmSelect();
                else
                    vDate = athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEndDateInput();// + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEnddateHourSelect() + ":" + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEnddateMinuteSelect() + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEnddateAmpmSelect();
                
                return 		new Date(moment(vDate,athoc.iws.alert.schedule.getVPSTimeFormat('momentformat'))).getTime() -new Date($.vpsTimeZone.CurrentVPSDate.toDateString() + ' ' + $.vpsTimeZone.CurrentVPSDate.toTimeString()).getTime() > 0;
            },
            isValid: function () {

                if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput() == "")
                    return false;
                if ($.isNumeric(athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput()) == false)
                    return false;
                if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput() < 1)
                    return false;

                if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() == "ASAP")
                    return true;
                else {
                    if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput() == "")
                        return false;
                    if (!athoc.iws.alert.schedule.isValidDate(athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput()))
                        return false;
                    //start date should not be older date from today                        


                    if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput != undefined && !athoc.iws.alert.schedule.viewModel.isLiveorEnded()) {
                        if (!athoc.iws.alert.schedule.validDateTime(true)) {
                            $("#StartDateErrorMsg").html(athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertStartDate_LessThan_CurrDate);
                            $("#StartDateErrorMsg").show();
                            athoc.iws.alert.schedule.isInErrorState = true;
                            return false;
                        }
                        else
                            $("#StartDateErrorMsg").hide();
                    }

                }
                return true;

            },
          

            isValidDate: function (val) {
                var isValid = true;
                try {
                    isValid = moment(val, $.vpsDateFormat.toUpperCase()).isValid();
                }
                catch (error) {
                    isValid = false;
                }

                return isValid;
            },
            //this method will set ready state
            isAlertScheduleReady: function () {
                if (athoc.iws.alert.schedule.isValid()) {
                    athoc.iws.alert.schedule.isReadyToPublish = true;
                    athoc.iws.alert.schedule.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#alertscheduleStatus", "ready");
                } else {
                    athoc.iws.alert.schedule.isReadyToPublish = false;
                    athoc.iws.alert.schedule.isInErrorState = true;
                    athoc.iws.publishing.SetSectionStatus("#alertscheduleStatus", "notReady");
                }
            },
            enableDateforSetTime: function (newValue) {
                if (newValue == "ASAP") {                    
                    $("#istartDateValue").datetimepicker("disable");

                } else {                    
                    $("#istartDateValue").datetimepicker("enable");
                    //$("input#istartDateValue").prop("disabled", true);
                }
            },
            //this method will be called when data is required for updating
            getModel: function () {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return null;

                return ko.mapping.toJS(athoc.iws.alert.schedule.viewModel.alertschedule);
            },
            //this method will pad chars to left of the string
            padLeft: function (value, length, char) {
                return new Array(length - (value + '').length + 1).join(char) + value;
            },
            handleError: function (e) {
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },
            validDayArrange: function (param1, param2, param3) {
                if (param2[1].indexOf('StartDate') < 0 && param2[1].indexOf('EndDate') < 0) {
                    if ($.isNumeric(param1) == false)
                        return false;
                    if (param1 < 1)
                        return false;
                }
                switch (param2[1]) {
                    case 'Duration':
                        {
                            switch (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInputUnit()) {
                                case 'Minute':
                                    if (param1 > 5256000)
                                        return false;
                                    break;
                                case 'Hour':
                                    if (param1 > 87600)
                                        return false;
                                    break;
                                case 'Day':
                                    if (param1 > 3650)
                                        return false;
                                    break;
                            }
                            break;
                        }

                    case 'AlertEndDate':
                        {
                            //iws#12687
                            if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEndDateInput != undefined && athoc.iws.alert.schedule.viewModel.isLiveAlert()) {
                                //End date should not be older date from today
                                //alert(athoc.iws.alert.schedule.validDateTime(false));
                                if (!athoc.iws.alert.schedule.validDateTime(false)) {
                                    athoc.iws.alert.schedule.isInErrorState = true;
                                    return false;
                                }
                            }
                            break;
                        }

                    case 'StartDate':
                        {

                            if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput != undefined && !athoc.iws.alert.schedule.viewModel.isLiveorEnded() && athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() != "ASAP") {
                                if (!athoc.iws.alert.schedule.validDateTime(true)) {
                                    athoc.iws.alert.schedule.isInErrorState = true;
                                    $("#StartDateErrorMsg").html(athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertStartDate_LessThan_CurrDate);
                                    $("#StartDateErrorMsg").show();
                                    return false;
                                }
                                else
                                    $("#StartDateErrorMsg").hide();
                            }
                            break;
                        }

                }
                athoc.iws.alert.schedule.isInErrorState = false;
                return true;
            },


            getVPSTimeFormat: function (formatType) {
                var timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP"));
                var meridianFormat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? " A" : "";
                var secondsIncluded = $.vpsDateTimeFormat.indexOf('ss') > 0 ? ":ss" : "";
                var dateFormat;
                switch (formatType) {
                    case "dateformat":
                        dateFormat = $.vpsDateFormat;
                            timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP").replace("hh", "HH"));
                        break;
                    case "momentformat":
                        dateFormat = $.vpsDateFormat.toUpperCase();
                        if (meridianFormat == "")
                            timeFormat = "HH:mm" + secondsIncluded;
                        else
                            timeFormat = "hh:mm" + secondsIncluded + meridianFormat;

                        break;
                }


                return dateFormat + ' ' + timeFormat;
            },

            //setup validation
            getValidation: function () {
                var validationMapping = {
                    ScheduleAlertpublishEndDateInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: { message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertEndDate_Require },
                                validation: {
                                    validator: athoc.iws.alert.schedule.validDayArrange,
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertEndDate_LessThan_CurrDate,
                                    params: [this.value, "AlertEndDate", 2]
                                }
                            });
                        }
                    },
                   

                    ScheduleAlertPublishStartModeSettime: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                validation: {
                                    validator: athoc.iws.alert.schedule.validDayArrange,
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertStartDate_LessThan_CurrDate,
                                    params: [this.value, "StartDate", 2]
                                }
                            });
                        }
                    },

                    ScheduleDurationInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: { message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertDuration },
                                maxLength: { params: 7, message: athoc.iws.publishing.resources.Publishing_Schedule_Err_MaxLength.format(7) },
                                pattern: {
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.alert.schedule.validDayArrange,
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_ValidDuration_Years.format('10'),
                                    params: [this.value, "Duration", 2]
                                }
                            });
                        }
                    },


                };

                return validationMapping;
            },
        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.alert.test.js
/* define javascript namespace for Test Alert  */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};
if (athoc.iws.alert) {
    athoc.iws.alert.test = function () {
        //
        var extraSpaceAddBlock = 55;
        return {
            //is model changed
            isChanged: false,
            IsRefered: false,
            tesDeviceList:[],
            testDevicesAddress: ko.observableArray(),
            //this method will be
            viewModel: {
                personalDeviceList: ko.observableArray(),
                
            },
            
            //called when new data will be available for this section for binding
            load: function () {             

                $("#btn_send_test_alert").click(function () {
                    athoc.iws.alert.detail.TestAlert();
                });

                $("#btn_test_alert").click(function () {
                    $("#TestAlert").show();
                    $('#alertMessagePanel').messagesPanel('reset');
                    $("#testbackshade").show();
                    athoc.iws.alert.test.resizeModalBasedOnScreen($("#TestAlert"));
                    var data = ko.mapping.toJS(athoc.iws.publishing.targetUsers.SelectedGroupedDevices().Devices);
                    

                   athoc.iws.alert.test.viewModel.personalDeviceList = ko.mapping.fromJS(athoc.iws.alert.test.formatTestDeviceList(data));
                   

                    if (athoc.iws.alert.test.viewModel.personalDeviceList().length > 0) {
                        $("#testpersonaldevicesdisplay").html("");
                        $("#testAlertMessage").css("display", "none");
                        $("#testpersonaldevicesdisplay").css("display", "");
                        ko.cleanNode($("#publishing-test-alert").get(0));
                        ko.applyBindings(athoc.iws.alert.test.viewModel, $("#testDevicesFlatList").get(0));
                    } else {
                        $("#testAlertMessage").css("display", "");
                        $("#testpersonaldevicesdisplay").css("display", "none");
                        $("#testpersonaldevicesdisplay").html("");
                    }
                    
                    athoc.iws.alert.test.enableSendAlert();

                });

                $("#btn_close_test_alert").click(function () {
                    $("#TestAlert").hide();
                    $("#testbackshade").hide();
                   
                });

                
            },
            bind: function(data) {
                athoc.iws.alert.test.testDevicesAddress(data);

            },

            enableTestAlertButton: function (flag) {

                if (flag)
                    $("#btn_test_alert").removeAttr("disabled");
                else
                    $("#btn_test_alert").attr("disabled",true);

            },

            getAddress: function (deviceId) {
                
                var filterData = ko.mapping.toJS(athoc.iws.alert.test.testDevicesAddress).filter(function (el) {
                    return el.DeviceId == deviceId;
                });

                return filterData.length > 0 ? filterData[0].Address : athoc.iws.publishing.resources.Publishing_Alert_TestAlert_Address_NotAvailable;
            },
            getModel: function (data) {
                var resultdata = [];
                var data = ko.mapping.toJS(athoc.iws.alert.test.viewModel.personalDeviceList);
                $(data).each(function (index) {
                    $(data[index].DeviceList).each(function (index2) {
                        if (data[index].DeviceList[index2].Selected)
                            resultdata.push(data[index].DeviceList[index2]);
                    });
                });

                return resultdata;
            },
            personalDeviceChanged: function (device) {
                athoc.iws.alert.test.enableSendAlert();
                return true;
            },

            enableSendAlert:function(){
                var self = this;
                var filterData = athoc.iws.alert.test.getModel();
                if (filterData != null && filterData.length>0)
                    $("#btn_send_test_alert").removeAttr("disabled");
                else
                    $("#btn_send_test_alert").attr("disabled", true);            
            },

            formatTestDeviceList: function (data) {
                var groupList = [];
                var deviceList = [];
                var list = 0;
                var groupId = 0;
                var groupName = "";
                var filterData = data;

                $(filterData).each(function (index) {
                    if (filterData[index].Selected) {
                        list++;
                        if (groupId != filterData[index].GroupId) {
                            groupId = filterData[index].GroupId;

                            if (deviceList.length > 0) {

                                groupList.push({ GroupName: groupName, DeviceList: deviceList });
                                deviceList = [];
                            }

                            filterData[index].Address = athoc.iws.alert.test.getAddress(filterData[index].DeviceId);
                            filterData[index].Enabled = true;
                            if (filterData[index].Address == athoc.iws.publishing.resources.Publishing_Alert_TestAlert_Address_NotAvailable || filterData[index].Address == "Inactive") {
                                filterData[index].Selected = false;
                                filterData[index].Enabled = false;
                            }


                            deviceList.push(filterData[index]);
                            if (filterData[index].Selected) {
                                athoc.iws.alert.test.tesDeviceList.push(filterData[index]);
                            }
                            groupName = filterData[index].GroupName;

                        } else {
                            if (filterData[index].Selected) {
                                athoc.iws.alert.test.tesDeviceList.push(filterData[index]);
                            }
                            filterData[index].Address = athoc.iws.alert.test.getAddress(filterData[index].DeviceId);
                            filterData[index].Enabled = true;
                            if (filterData[index].Address == athoc.iws.publishing.resources.Publishing_Alert_TestAlert_Address_NotAvailable || filterData[index].Address == "Inactive") {
                                filterData[index].Selected = false;
                                filterData[index].Enabled = false;
                            }
                            deviceList.push(filterData[index]);

                        }
                    }
                });
                if(list>0)
                groupList.push({ GroupName: groupName, DeviceList: deviceList });
                return groupList;

            },
            resizeModalBasedOnScreen: function (modal) {
            var extrSpace = 0;
            modal.find(".modal-body").css("max-height", 370);
            var windowHeight = $(window).height();

            if (windowHeight > 770) {
                modal.css("margin-top", 40 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                modal.find(".modal-body").css("height", windowHeight - 340);
            } else {
                modal.css("margin-top", 40 - (windowHeight / 2));
                modal.find(".modal-body").css("height", windowHeight - 240);
            }

            if (modal.height() + 170 > windowHeight) {
                var newHeight = windowHeight - 170;
                modal.find(".modal-body").css("max-height", newHeight);
            }

        },
        };

    }();
}

///#source 1 1 /Scripts/Publishing/athoc.iws.alert.print.js
/* define javascript namespace for Test Alert  */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};
if (athoc.iws.alert) {

    athoc.iws.alert.print = function () {
       
        return {
            //is model changed
            isChanged: false,
            IsRefered: false,
            alertId:0,
            //this method will be
            viewModel: {
             

            },

            //called when new data will be available for this section for binding
            load: function () {
                
                $("#btn_print_alert").click(function () {
                   athoc.iws.alert.print.redirectToPrintAlertDetailsUrl();
                });

            },
            bind: function (data) {
            },

            redirectToPrintAlertDetailsUrl: function () {
                try {
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.modal-footer'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                    athoc.iws.alert.detail.downloadPdfFile(athoc.iws.publishing.urls.CreatePrintAlertUrl);

                } catch (e) {
                    console.log(e);
                }
                finally {
                    $.AjaxLoader.hideLoader();
                };
            },
        };

    }();
}

///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.geo.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.geo = function () {
        return {
            viewModel: {
                geoTargetingEnabled: ko.observable(true),

                //geo location
                isGeoSelected: ko.observable(false),

                geoImageUrl: ko.observable(''),

                shapes: ko.observable([]),

                isUsersTargeted: ko.observable(false),

                isOrganizationsTargeted: ko.observable(false),

                usersCount: ko.observable(0),

                organizationsCount: ko.observable(0),

                onTargetUserByAreaChange: function () {
                    if (!athoc.iws.publishing.geo.viewModel.isUsersTargeted())
                        athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria(0);
                    else
                        athoc.iws.publishing.geo.updateTargetingSummary();
                    athoc.iws.publishing.geo.updateContactPieChart();
                    return true;
                }
            },

            geoJson: null, //stores geoJson for currently loaded alert/scenario
            geoTargetMap: null, //map component
            miniMap: null,

            //triggered onload, function can have any load logic
            load: function () {
                //athoc.iws.publishing.geo.loadMap();
            },

            //load map component
            loadMap: function () {

                /*IWS-19267 
                1) removed esri minimap reference. 
                2) commented minimap creation using esri
                3) commented restoring geo coordinates for minimap
                4) called new method called bindAlertMiniMap
                5) impelemted GeoTargetingSummary maps  using leaflet on screen and r&p window 
                
                */
                //require(["maps/GeoTargetMap", "maps/MiniMap"], function (GeoTargetMap, MiniMap) {
                require(["maps/GeoTargetMap"], function (GeoTargetMap) {
                    athoc.iws.publishing.geo.geoTargetMap = new GeoTargetMap({ i18n: athoc.iws.publishing.mapResources, culture: languageParams.currentCulture }, "geoTargetMapHolder");

                    /* IWS-19267 - commnted out min map code implementation using esri. */

                    //athoc.iws.publishing.geo.miniMap = new MiniMap(null, "miniMapHolder");

                    athoc.iws.publishing.geo.geoTargetMap.startup();
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.on("orgTargetComplete", function (e) {
                        if (athoc.iws.publishing.targetOrg.OrgViewMod) {
                            //e.orgIds
                            athoc.iws.publishing.targetOrg.OrgViewModel.OrgCountByArea(e.selectedOrgs);
                            athoc.iws.publishing.targetOrg.OrgViewModel.SelectedOrgsByArea(e.orgIds);
                        }
                    });

                    athoc.iws.publishing.geo.geoTargetMap.on("close", function () {
                        athoc.iws.publishing.geo.geoJson = athoc.iws.publishing.geo.geoTargetMap.toGeoJson();
                        if (!athoc.iws.publishing.geo.geoJson || !athoc.iws.publishing.geo.geoJson.features || athoc.iws.publishing.geo.geoJson.features.length === 0) {
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                            athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                            athoc.iws.publishing.geo.updateTargetingSummary();
                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(false);
                            athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(false);
                            if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                                athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(false);
                            }
                        } else {
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                            athoc.iws.publishing.content.viewModel.isGeoSelected(true);

                            /*IWS-19267 - commented out restoring selected shape coordinates using esri mini map*/

                            //athoc.iws.publishing.geo.miniMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                            //athoc.iws.publishing.geo.miniMap.restore(athoc.iws.publishing.geo.geoJson);

                            /*IWS-19267 - calling new method to bind selected shape coordinates in leaflet map*/
                            athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);

                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(athoc.iws.publishing.geo.geoTargetMap.isTargetingUser);
                            athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg);
                            if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                                athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg);
                            }
                            athoc.iws.publishing.geo.updateTargetingSummary();
                        }
                        athoc.iws.publishing.geo.updateContactPieChart();
                        athoc.iws.publishing.content.checkReadyNotReady();
                    });

                    $('#dialogGeoTargetingSummary').on('shown.bs.modal', function () {
                        /*IWS-19267 - removed olde code and impelemted using leaflet */

                        //if (!athoc.iws.publishing.geo.summaryMap) {
                        //    athoc.iws.publishing.geo.summaryMap = new MiniMap({ width: 980, height: 300 }, "dialogGeoTargetingSummaryContent");
                        //}
                        //athoc.iws.publishing.geo.summaryMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                        //athoc.iws.publishing.geo.summaryMap.restore(athoc.iws.publishing.geo.geoJson);
                        //setTimeout(function () {
                        //    athoc.iws.publishing.geo.summaryMap.resize();
                        //    athoc.iws.publishing.geo.summaryMap.zoomToFit();
                        //}, 500);


                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.geo.summaryMap) {
                                athoc.iws.publishing.geo.summaryMap = new Map("dialogGeoTargetingSummaryContent", { i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                            }
                            athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.summaryMap, athoc.iws.publishing.geo.geoJson);
                        });
                    });

                    /*IWS-19267 - removed olde code and impelemted using leaflet in R&P publish window binding to display in all places like home and alerts screen*/
                    //the second popup modal in review and publish page
                   
                    $('#dialogGeoPublish').on('shown.bs.modal', function () {
                        /* if (!athoc.iws.publishing.geo.summaryMapOnRP) {
                            athoc.iws.publishing.geo.summaryMapOnRP = new MiniMap({ width: 980, height: 300 }, "dialogGeoPublishContent");
                        }
                        athoc.iws.publishing.geo.summaryMapOnRP.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                        athoc.iws.publishing.geo.summaryMapOnRP.restore(athoc.iws.publishing.geo.geoJson);
                        setTimeout(function () {
                            athoc.iws.publishing.geo.summaryMapOnRP.resize();
                            athoc.iws.publishing.geo.summaryMapOnRP.zoomToFit();
                        }, 500); */

                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.view.summaryMapReadOnly) {
                                athoc.iws.publishing.view.summaryMapReadOnly = new Map("dialogGeoPublishContent", {
                                    i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.summaryMapReadOnly, athoc.iws.publishing.geo.geoJson);
                        });

                    });
                   


                });
            },


            /* IWS-19267 - Written new method to removing old ge coordinates then adding new geo coordinates*/
            bindAlertMiniMap: function (miniMap,geoLocationsJson) {
                if (miniMap != null || miniMap) {
                    miniMap.removeGeoJson();
                    miniMap.addGeoJson(geoLocationsJson);
                    miniMap.centerAt([0, 0]);
                    miniMap.zoomToFit();
                }
            },

            //called when geo targeting model gets binded
            bind: function (data, isUsersTargeted, isOrganizationsTargeted) {
                athoc.iws.publishing.geo.viewModel.isUsersTargeted(isUsersTargeted);
                athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(isOrganizationsTargeted);
                var geoJson = data != "" ? JSON.parse(data) : null;
                //if (data == null || data == '') {
                if (geoJson == null || geoJson.features.length == 0) {// condition to stop loading generic map.

                    athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                    athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                    athoc.iws.publishing.geo.viewModel.geoImageUrl('');
                } else {
                    if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                        athoc.iws.publishing.geo.loadMap();
                    }

                    athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                    athoc.iws.publishing.content.viewModel.isGeoSelected(true);
                    athoc.iws.publishing.geo.geoJson = JSON.parse(data);

                    athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();

                   
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.restore(athoc.iws.publishing.geo.geoJson);


                    /*IWS-19267- commented out restoring selected shape coordinates using esri mini map*/

                    //athoc.iws.publishing.geo.miniMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                    //athoc.iws.publishing.geo.miniMap.restore(athoc.iws.publishing.geo.geoJson);

                    /*IWS-19267 - written code to create mini map using leaflet and binding geo coordinates. this section will call while editing drafted alert*/
                    if (athoc.iws.publishing.geo.geoJson != "" || athoc.iws.publishing.geo.geoJson != null) {

                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.geo.miniMap) {
                                if (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content || !athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Collapsed) {
                                    athoc.iws.publishing.geo.miniMap = new Map("miniMapHolder", {i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                                    athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                                }
                            }
                            else {
                                athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                            }

                        });
                    }
                }

                //Binding
                if ($("#targetContentArea").length > 0) {
                    ko.cleanNode($("#targetContentArea").get(0));
                    ko.applyBindings(athoc.iws.publishing.geo.viewModel, $("#targetContentArea").get(0));
                }

                athoc.iws.publishing.geo.updateTargetingSummary();
            },

            //called to get model for persisting
            getModel: function () {
                //return shape data for persisting
                if (athoc.iws.publishing.geo.geoJson != null) {
                    return JSON.stringify(athoc.iws.publishing.geo.geoJson);
                } else {
                    return null;
                }
            },

            //add geo location, entry point when alert/scenario does not have any existing location
            add: function () {
                var params = {};
                params.isNewMap = false;
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap==null) {
                    athoc.iws.publishing.geo.loadMap();
                    params.isNewMap = true;
                }
                var isTargetByUserEnabled = (($("#targetArea").length > 0) && ($('#targetArea').css('display') != 'none'));
                if (isTargetByUserEnabled) {
                    isTargetByUserEnabled = (($("#publishing-user-edit").length > 0) && ($('#publishing-user-edit').css('display') != 'none'));
                }

                var isTargetOrganizationEnabled = (($(".org-by-area").length > 0) && ($('.org-by-area').css('display') != 'none'));
                if (isTargetOrganizationEnabled && ($("#alert-org-edit").length > 0)) {
                    isTargetOrganizationEnabled = ($('#alert-org-edit').css('display') != 'none');
                } else  if (isTargetOrganizationEnabled &&  ($("#targetOrgSection").length > 0)) {
                    isTargetOrganizationEnabled = ($('#targetOrgSection').css('display') != 'none');
                }

                if (isTargetByUserEnabled || isTargetOrganizationEnabled) {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(true);
                } else {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(false);
                }

                athoc.iws.publishing.geo.geoTargetMap.setUserTargetable(isTargetByUserEnabled);
                athoc.iws.publishing.geo.geoTargetMap.setOrgTargetable(isTargetOrganizationEnabled);

                athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();

                athoc.iws.publishing.geo.geoTargetMap.isTargetingUser = isTargetByUserEnabled;
                athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg = isTargetOrganizationEnabled;


                athoc.iws.publishing.geo.geoTargetMap.show(params);

                /*IWS-19267 - Creating mini map instance using leaflet*/
                require(["widget/Map"], function (Map) {

                    if (!athoc.iws.publishing.geo.miniMap) {
                        // updating map div visible
                        athoc.iws.publishing.content.viewModel.isGeoSelected(true);
                        athoc.iws.publishing.geo.miniMap = new Map("miniMapHolder", { i18n: athoc.iws.publishing.mapResources,zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                    }
                });
            },

            //remove/clear shapes
            remove: function () {
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                    athoc.iws.publishing.geo.loadMap();
                }
                athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                athoc.iws.publishing.geo.viewModel.geoImageUrl('');
                athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();
                athoc.iws.publishing.geo.geoJson = null;
                athoc.iws.publishing.geo.updateTargetingSummary();
                athoc.iws.publishing.geo.viewModel.isUsersTargeted(false);
                athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(false);
                if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                    athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(false);
                    athoc.iws.publishing.targetOrg.OrgViewModel.OrgCountByArea(0);
                    athoc.iws.publishing.targetOrg.OrgViewModel.SelectedOrgsByArea([]);
                }
                athoc.iws.publishing.geo.updateContactPieChart();
                athoc.iws.publishing.content.checkReadyNotReady();
            },

            //edit alert/scenario location
            edit: function () {
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                    athoc.iws.publishing.geo.loadMap();
                }
                var isTargetByUserEnabled = (($("#targetArea").length > 0) && ($('#targetArea').css('display') != 'none'));
                if (isTargetByUserEnabled) {
                    isTargetByUserEnabled = (($("#publishing-user-edit").length > 0) && ($('#publishing-user-edit').css('display') != 'none'));
                }

                var isTargetOrganizationEnabled = (($(".org-by-area").length > 0) && ($('.org-by-area').css('display') != 'none'));
                if (isTargetOrganizationEnabled && ($("#alert-org-edit").length > 0)) {
                    isTargetOrganizationEnabled = ($('#alert-org-edit').css('display') != 'none');
                } else if (isTargetOrganizationEnabled && ($("#targetOrgSection").length > 0)) {
                    isTargetOrganizationEnabled = ($('#targetOrgSection').css('display') != 'none');
                }

                if (isTargetByUserEnabled || isTargetOrganizationEnabled) {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(true);
                } else {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(false);
                }

                athoc.iws.publishing.geo.geoTargetMap.setUserTargetable(isTargetByUserEnabled);
                athoc.iws.publishing.geo.geoTargetMap.setOrgTargetable(isTargetOrganizationEnabled);

                /*athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();
                if (athoc.iws.publishing.geo.geoJson != null) {
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.restore(athoc.iws.publishing.geo.geoJson);
                } */

                athoc.iws.publishing.geo.geoTargetMap.isTargetingUser = athoc.iws.publishing.geo.viewModel.isUsersTargeted() && isTargetByUserEnabled;                
                athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg = athoc.iws.publishing.targetOrg.OrgViewModel && athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea() && isTargetOrganizationEnabled;

                athoc.iws.publishing.geo.geoTargetMap.show();
            },

            //reflect map selection in targeting summary
            updateTargetingSummary: function () {
                var objectCount = 0, nonPoint;
                if (athoc.iws.publishing.geo.geoJson
                    && athoc.iws.publishing.geo.geoJson.features
                    && athoc.iws.publishing.geo.viewModel.isUsersTargeted()) {
                    nonPoint = $.grep(athoc.iws.publishing.geo.geoJson.features, function (item, idx) {
                        return item.geometry.type.toLowerCase() !== 'point';
                    });
                    objectCount = nonPoint.length;
                }

                if(athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria)
                athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria(objectCount);
            },

            //update contact pie chart based on geo-location
            updateContactPieChart: function () {
                athoc.iws.publishing.targetUsers.updateContactInfo();
                athoc.iws.publishing.targetUsers.targetingChanged();
            },

            //apply map changes from add/edit dialog 
            applyMapChanges: function () {
                //TODO: apply map changes may be recalculate users (not sure yet)
            },

            //make a json call to get users and organizations based on selected area
            getUsersAndOrgsForSelectedArea: function () {
                //TODO: send shape information in ajax request and get user and organization
            },

        };
    }();
}
