﻿define([
    "common/baseView",
    "account/utils",
    "account/Event/details/Model",
    "dojo/text!account/Export/template.html",
    "account/Event/dashboard"
   
], function (BaseView, utils, Model, template, DashboardView) {
    //constructor 
    var exportManager = function (refNode, eventId, eventDetails) {
        this.base = BaseView.call(this, refNode, template, Model, []);
        this.eventId = eventId;
        this.controls = [];
        this.eventModel = eventDetails.Data;
        this.eventId = eventId;
        this.resources = userListResources;
        this.controlById = [];
        this.responseOptionId = 0;
        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
    };

    $.extend(exportManager.prototype, {
        init: function () {
            $.when(this.createTabControl(this.tabNames.dashboard, DashboardView)).then(function () {
            }).done(function () { // done terminates a chain.
                               });
        },

        createTabControl: function (name, control, params) {
            var self = this;
            var tabView = new control(this.refDomNode.find("[name='" + name + "-content']"), self.eventId, params);
            this.controlById[name] = tabView;
            tabView.startup();
            tabView.update(self.eventModel.Data);
           
        },

        update: function (data) {
            this.eventModel = data.Data;
            var self = this;
                var view = self.controlById["dashboard"];
                view.update(self.eventModel);
            this.model.isLive(this.eventModel.Status == utils.EventStatus.Live);
            this.model.status(this.eventModel.Status == utils.EventStatus.Live ? "Live" : "Ended");
            this.model.updatedOn(data.TimeStamp);
            this.model.endedOn(this.eventModel.EndedOn);
            this.model.endDate(this.eventModel.EndDate);

        },

        tabNames: {
            dashboard: "dashboard"
        }
    });

    return exportManager;
});