﻿define([
    "common/baseView",
    "account/utils",
    "account/Export/ExportDialog/Model",
    "dojo/text!account/Export/ExportDialog/template.html",
    "common/navigation",
     "common/dialog"
], function (BaseView, utils, Model, template, NavigationView, Dialog) {
    //constructor
    var dialog = function (eventId) {
        var self = this;
        this.model = Model;
        this.eventId = eventId;
        this.userSearchFilter = ko.observableArray([]);
        this.userFilterText = "";
        this.searchString = [];
        this.attriubuteCsv = "";
        this.allUserSortColumn = "";
        this.allUserSortOrder = "";
        this.queryCriteria = "";
        this.orgHrchyOptions = [];
        this.UserattributeIds = [];
        this.UserhierarchyIds = [];
        this.UserlistItemIds = [];
        this.OrgHrchyColumnHeader = "";
        this.providerId = 0;
        var refDomNode = $("<div>");
        $("body").append(refDomNode);

        this.exportingNavigationModel = {
            sections: [
           {
               dataPage: "dashboard",
               actions: [
                   {
                       id: "close", text: resources.PA_Event_Close_Button, primary: false, click: function () { self.hideExportingDialog(); }
                   }
                ]
           }
            ]
            },
        this.navigationModel = {
            sections: [
                {
                    dataPage: "dashboard",
                    actions: [
                        {
                            id: "close", text: resources.PA_Event_Close_Button, primary: false, click: function () { self.hideDialog(); }
                        },
                        {
                            id: "export", text: resources.PA_Event_Details_Export, primary: true, click: function () {
                                self.hideDialog();
                                var responseText;
                                $.each(self.model.UserStatus(), function (index, obj) {
                                    if (obj.valueId == self.model.selectedStatus()) {
                                        responseText = obj.valueName;
                                        return;
                                    }
                                });
                                var filterText;
                                if (self.userFilterText === "") {
                                    filterText = self.model.i18n.PA_Event_Export_UserStatus_Search_Text + " " + responseText;
                                } else {
                                    filterText = self.userFilterText + " " + self.model.i18n.PA_Event_Export_And_Connector + " " + self.model.i18n.PA_Event_Export_UserStatus_Search_Text + " " + responseText;
                                }
                                var parameters = {
                                    EventId: self.eventId,
                                    DownloadFormat: self.model.exportFileType(),
                                    UserResponseType: self.model.selectedStatus(),
                                    CurrentUserFilter: filterText,
                                    IncludeSummary: self.model.sections.indexOf('summary') > -1 ? true : false,
                                    IncludeHierarchy: self.model.sections.indexOf('analysis') > -1 ? true : false,
                                    IncludeUsers: self.model.sections.indexOf('user') > -1 ? true : false,
                                    ExportDescription: self.model.description(),
                                    UserAttriubuteCsv: self.attriubuteCsv,
                                    UsrrQueryCriteria: self.queryCriteria,
                                    SortUsersBy: self.allUserSortColumn,
                                    UserSortingOrder: self.allUserSortOrder,
                                    OrgHrchyFilter: self.model.hrchyFilterText(),
                                    OrgHrchyOptions: self.orgHrchyOptions,
                                    UserSearchOptions: self.userSearchFilter(),
                                    OrgHrchyHeaderTitle: self.OrgHrchyColumnHeader,
                                    UserattributeIds: self.UserattributeIds,
                                    UserhierarchyIds: self.UserhierarchyIds,
                                    UserlistItemIds: self.UserlistItemIds,
                                    ProviderId: self.providerId
                                };
                               
                                self.showExportingDialog();
                                var url = athoc.iws.account.urls.ExportEventDetails;
                                $.fileDownload(url, {
                                    httpMethod: "POST",
                                    contentType: "application/json",
                                    encodeHTMLEntities: true,
                                    data: parameters,
                                    successCallback: function () {
                                        self.hideExportingDialog();

                                    },
                                    failureCallback: function () {
                                        self.hideExportingDialog();
                                    }
                                });
                            }
                        }
                    ]
                }
            ]
        };
        this.dialog = new Dialog(this.navigationModel);
        this.dialog.startup();
        BaseView.call(this, this.dialog.getBodyNode(), template, Model, []);

        this.exportingDialog = new Dialog(this.exportingNavigationModel, "", "<div><span class='mar-right5'><img src='/athoc-cdn//Images/ajax-loader.gif'></span><span>" + self.model.i18n.PA_Event_Export_Exporting_text + "..." + "</span></div>");
        self.exportingDialog.startup();

      
        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
           this.init();
           
            $('body').on('click', function (e) {

                if (e.target.name != "viewFilter") {
                    self.model.toggleHierarchyFilterTooltip(false);
                    self.model.toggleUserFilterTooltip(false);

                    $(".pa-export-tooltip-wrap").hide();
                }
            });
        };
        this.loadUserStatus = function () {
            var self = this;
            var loadUrl = athoc.iws.account.urls.GetEventUserStatus + "?id=" + self.eventId;
            utils.makeAjaxCall(loadUrl, {}, $.proxy(function (data) {
                self.updateUserStatus(data);
            }), $.proxy(function () {
            }));
        };

        this.init = function () {
            var self = this;
            self.loadUserStatus();
            self.isInit = true;
           
            this.model.showSearchTooltip = $.proxy(function () {
                self.populateUserSearchTooltip();
                self.model.toggleUserFilterTooltip(true);
            });
            this.model.showHierarchyTooltip = $.proxy(function () {
                self.populateHierarchySearchTooltip();
                self.model.toggleHierarchyFilterTooltip(true);
            });
        };
        self.model.sections.subscribe(function (newValue) {
            if (self.model.sections().length > 0) 
                self.dialog.navigationView.getAction('export').enable(true);
            else
                self.dialog.navigationView.getAction('export').enable(false);
        });
       
    };

    $.extend(dialog.prototype, {
        populateUserSearchTooltip: function() {
        },
        populateHierarchySearchTooltip: function() {
        },
        updateDialogTitle: function (eventName) {
            var self = this;
            self.dialog.setTitle(eventName);
            self.exportingDialog.setTitle(eventName);
        },
        updateUserStatus: function (data) {
            var self = this;
            self.model.UserStatus.removeAll();
            var statusList = $.parseJSON(data.Data);
            self.model.UserStatus.push({ valueId: -1, valueName: self.model.i18n.PAEvent_AllUsers });
            self.model.UserStatus.push({ valueId: -2, valueName: self.model.i18n.PAEvent_AllResponses });
            $.each(statusList, function (index, obj) {
                self.model.UserStatus.push({ valueId: obj.SortOrder, valueName: obj.ValueName });
            });
            self.model.UserStatus.push({ valueId: 0, valueName: self.model.i18n.PAEvent_NoStatus });
            self.refDomNode.find(".selectpicker").selectpicker();
            
        },
        updateUserFilters:function(usersObj) {
            var self = this;
            usersObj.selectedFilter();
            self.model.selectedFilter(usersObj.ph.filterType);
            self.model.searchStrings(usersObj.searchStrings);
            self.attriubuteCsv = usersObj.ph.extraCommonNames;
            self.allUserSortOrder = usersObj.ph.allUserSortOrder;
            self.allUserSortColumn = usersObj.ph.allUserSortColumn;
            self.queryCriteria = usersObj.ph.queryCriteria;
            self.UserattributeIds = usersObj.ph.attributeIds;
            self.UserhierarchyIds = usersObj.ph.hierarchyIds;
            self.UserlistItemIds = usersObj.ph.listItemIds;
            self.providerId = usersObj.ph.providerId;
            if (self.model.selectedFilter() != null) {
                self.model.selectedStatus(self.model.selectedFilter());
            }
            var filterTexts = usersObj.getFilterTexts();
            self.userSearchFilter(usersObj.userSearchFilterForExport);
            self.searchString = usersObj.searchStringForExport;

            self.userFilterText = filterTexts[1];
            self.model.userFilterText(filterTexts[0]);

        },
        updateHrchyFilters: function (hrchyObj) {
            var self = this;
            self.OrgHrchyColumnHeader = hrchyObj.getHrchyColumnHeader();
            self.orgHrchyOptions = hrchyObj.getFilterValues();
            self.model.hrchyFilterText(hrchyObj.getFilterText());
        },
        showDialog: function () {
            var self = this;
            self.model.reset();
            this.dialog.showDialog();
        },
       
        hideDialog: function () {
            this.dialog.hideDialog();
        },
        showExportingDialog:function() {
            this.exportingDialog.showDialog();
        },
        hideExportingDialog: function () {
            this.exportingDialog.hideDialog();
        },
        onClose: function () { }
    });

    return dialog;
});