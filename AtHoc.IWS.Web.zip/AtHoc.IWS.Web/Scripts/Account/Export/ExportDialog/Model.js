﻿define([], function () {
    function Model(i18n) {
        var self = this;
            
        self.title = ko.observable();
        self.description = ko.observable();
        self.userFilterText = ko.observable();
        self.hrchyFilterText = ko.observable();
        self.exportFileType = ko.observable('pdf');
        self.sections = ko.observableArray(['summary', 'user', 'analysis']);
        self.UserStatus = ko.observableArray();
        self.searchStrings = ko.observableArray();
        self.selectedStatus = ko.observable();
        self.orgHrchyContent = ko.observableArray();
        self.orgHrchySelectedItem = "";
        self.selectedStatusText = ko.observable();
        self.selectedFilter = ko.observable();
        self.toggleUserFilterTooltip = ko.observable(false);
        self.toggleHierarchyFilterTooltip = ko.observable(false);
        self.usersFilterText = ko.observable();
        self.enableuseStatus = ko.computed(function() {
            if (self.sections.indexOf('user') > -1)
                return true;
            return false;
        });
        self.showSearchTooltip = function () {
            self.showSearchTooltip();
        };
        self.showHierarchyTooltip = function () {
            self.showHierarchyTooltip();
        };
        self.showUserFilterText = ko.computed(function () {
            if (self.searchStrings().length > 0 && self.sections.indexOf('user') > -1)
                return true;
            return false;
        });
        self.showHierarchyFilterText = ko.computed(function () {
            if (self.hrchyFilterText() !== undefined && self.hrchyFilterText() !== "" && self.sections.indexOf('analysis') > -1)
                return true;
            return false;
        });
       
        self.reset = function () {
            self.description('');
            self.exportFileType('pdf');
            self.sections.removeAll();
            self.sections.push('summary');
            self.sections.push('user');
            self.sections.push('analysis');
        };
       
        
    }

    return Model;
});