﻿define(["ssa/eventManagerUtil"], function (eventUtil) {
    var common = {
        EventStatus: {
            Live : "Live",
            Ended: "Ended"
        },

        makeAjaxCall: function (url, postData, successCallback, failCallback, async, elementToBlock) {
            var self = this;
            elementToBlock = (typeof elementToBlock === 'undefined') ? '.title-bar' : elementToBlock;
            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(elementToBlock), imageURL: athoc.iws.account.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
            var dlSuccess = function (data) {
                $.AjaxLoader.hideLoader();
                if (data.Success) {
                    if (successCallback) {
                        successCallback(data);
                    }                    
                } else {
                    self.handleError(data);
                    if (failCallback) {
                        failCallback(data);
                    }
                }
            };

            var dlAjaxOption =
            {
                contentType: 'application/json',
                dataType: 'json',
                type: "POST",
                data: JSON.stringify(postData),
                url: url,
                async: async == null ? true : async
            };
            var dlError = function (data) {
                $.AjaxLoader.hideLoader();
                self.handleError(data);
                if (failCallback) {
                    failCallback(data);
                }
            }
            var ajaxOptions = $.extend({}, AjaxUtility(dlError, dlSuccess).ajaxPostOptions, dlAjaxOption);
            $.ajax(ajaxOptions);
        },

        handleError: function (e) {
            var self = this;
            if (e != undefined && e.status == 401) {
                window.onbeforeunload = null;
                window.location = window.location;
            }
            var res = e.xhr ? e.xhr.responseText : e.responseText;
            if (res) {
                // load event manager util for 
                var timeOut = eventUtil.sessionTimeOut(res);
                if (timeOut) {
                    return;
                }
            }
        },

        getTemplate: function (id, successCallback, failCallback) {
            var loadUrl = athoc.iws.account.urls.GetTemplate + "?id=" + id;
            this.makeAjaxCall(loadUrl, {}, successCallback, failCallback);
        },

        getEventFromTemplate: function (id, successCallback, failCallback) {
            var loadUrl = athoc.iws.account.urls.GetEventFromTemplate + "?id=" + id;
            this.makeAjaxCall(loadUrl, {}, successCallback, failCallback);
        },

        getDuplicatedTemplate: function (id, successCallback, failCallback) {
            var loadUrl = athoc.iws.account.urls.DuplicateTemplate + "?id=" + id;
            var dlSuccess = function (data) {
                if (successCallback) {
                    successCallback(data);
                }
            };

            this.makeAjaxCall(loadUrl, {}, dlSuccess, failCallback);
        },

        getAlertTemplates: function (successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/GetScenarios?ts=" + (new Date()).getTime();
            this.makeAjaxCall(loadUrl, {}, successCallback, failCallback);
        },

        removeTemplates: function (ids, successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/RemoveTemplate";
            this.makeAjaxCall(loadUrl, { ids: ids }, successCallback, failCallback);
        },

        removeEvents: function (ids, successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/RemoveEvent";
            this.makeAjaxCall(loadUrl, { ids: ids }, successCallback, failCallback);
        },

        removeEntities: function (ids, successCallback, failCallback, loadUrl, elementToBlock) {
            var elementToBlock = (typeof elementToBlock === 'undefined') ? '.modal-publisher-edit' : elementToBlock;
            this.makeAjaxCall(loadUrl, { ids: ids }, successCallback, failCallback, null, elementToBlock);
        },

        loadStartEventPage: function (templateId) {
            var loadUrl = "/athoc-iws/account/StartEvent?id=" + templateId;
            window.location = loadUrl;
        },

        loadEventPage: function (eventId, providerId) {
            var loadUrl = "/athoc-iws/account/Events?id=" + eventId;
            window.location = loadUrl;
        },

        loadEventsPage: function () {
            var loadUrl = "/athoc-iws/account/events";
            window.location = loadUrl;
        },

        loadAlertPage: function (id) {
            var loadUrl = "/athoc-iws/AlertManager/ReportView?nav=v&id=" + id;
            //var loadUrl = "/client/alertmanager/Summary/" + id;
            window.location = loadUrl;
        },

        startEvent: function (template, successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/StartEventNow";
            this.makeAjaxCall(loadUrl, template, successCallback, failCallback, null, '.event-review-root');
        },

        endEvents: function (ids, successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/EndEvents";
            this.makeAjaxCall(loadUrl, { ids: ids }, successCallback, failCallback, null, '.modal-publisher-edit');
        },

        selectTempalte: function () {
            var loadUrl = "/athoc-iws/account/templates";
            window.location = loadUrl;
        },        

        reviewAndPublishAlert: function (id) {
            athoc.iws.publishing.view.ReviewReadOnlyScenario(id, "home");
        },

        replaceMessagePlaceholders: function (messagePlaceholderModel, successCallback, failCallback) {            
            var loadUrl = "/athoc-iws/account/ReplaceAccountabilityMessagePlaceholdersForPreview";
            this.makeAjaxCall(loadUrl, messagePlaceholderModel, successCallback, failCallback,false);
        },

        loadSeverity: function (successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/GetSeverityList";
            this.makeAjaxCall(loadUrl, {}, successCallback, failCallback);
        },

        getAccountabilityEventPublishers: function (successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/GetOperatorsWhoPublishedAccountabilityEvent";
            this.makeAjaxCall(loadUrl, {}, successCallback, failCallback);
        },

        getAccountabilityStatusAttributes: function (successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/GetAccountabilityStatusAttributes";
            this.makeAjaxCall(loadUrl, {}, successCallback, failCallback);
        },
        getAccountabilityStatus: function (successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/GetAccountabilityEventStatus";
            this.makeAjaxCall(loadUrl, {}, successCallback, failCallback);
        },
        fillFilterValues: function (providerId,filterIds, successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/PopulateAdvancedSearchFilters";
            this.makeAjaxCall(loadUrl, {providerId:providerId, filterIds: filterIds }, successCallback, failCallback);
        },
        
        wireupOpenCollapse: function() {
            //wire up open/collapse for all sections
            //calling it after sections have been bound because some sections call ko.cleanNode() before rebinding
            //which would remove jQuery event handlers...
            $('.bucket-toggle h2', ".form-horizontal").unbind("click");
            $('.bucket-toggle h2', ".form-horizontal").click(function () {
                $(this).parent().find('.row').slideToggle(500);
                $(this).parent().find('.expand-arrow-open').toggle();
                $(this).parent().find('.expand-arrow-closed').toggle();
            });
        },

        getVPSTimeFormat: function (formatType) {
            var timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP"));
            var meridianFormat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? " A" : "";
            var secondsIncluded = $.vpsDateTimeFormat.indexOf('ss') > 0 ? ":ss" : "";
            var dateFormat;
            switch (formatType) {
                case "dateformat":
                    dateFormat = $.vpsDateFormat;
                    timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP").replace("hh", "HH"));
                    break;
                case "momentformat":
                    dateFormat = $.vpsDateFormat.toUpperCase();
                    if (meridianFormat == "")
                        timeFormat = "HH:mm" + secondsIncluded;
                    else
                        timeFormat = "hh:mm" + secondsIncluded + meridianFormat;

                    break;
            }
            return dateFormat + ' ' + timeFormat;
        },

        createMultiSelectSearchOptions: function (i18n) {
            return {
                noListItemText: i18n.PA_Event_List_NoList,
                listSelectAllText: i18n.PA_Event_List_Select_All,
                selectedCountText: i18n.PA_Event_List_Selected,
                noneItemSelectedText: i18n.PA_Event_List_None,

                labelText: "", //need to override
                filterPropertyName: "" //need to override
            };
        },

        createAdvancedSearchOption: function (i18n) {
            return {
                colNumber: 2,
                isAdvancedFilter: true,
                filterPropertyName: "SearchStrings",
                pageInfoText: i18n.PA_Event_List_PageInfo,
                pageInfoNoRecordsText: i18n.PA_Event_List_PageInfo_NoRecords,
                searchByTitle: i18n.PA_Event_List_Search_By_Title,
                criteriaBuilderSelectedText: i18n.PA_Event_Criteria_Builder_selected,
                listAdvancedTitle: i18n.PA_Event_List_Advanced,
                buttonClearAllText: i18n.PA_Event_Button_ClearAll,
                cancelButtonText: i18n.PA_Template_Details_Cancel_Button_Text,
                applyButtonText: i18n.PA_Template_Details_Apply_Button_Text,
                advancedFilterPopupTitle: i18n.PA_Event_List_AdvancedFilter_Popup_Title,
                searchKeywordText: i18n.PA_Event_Search_Keyword
            };
        },

        createTemplateSearchOption: function (i18n) {
            return {
                isAdvancedFilter: false,
                filterPropertyName: "SearchStrings",
                buttonClearAllText: i18n.PA_Event_Button_ClearAll,
                pageInfoText: i18n.PA_Template_List_PageInfo,
                searchByTitle: i18n.PA_Event_List_Search_By_Title,
                pageInfoNoRecordsText: i18n.PA_Template_List_PageInfo_NoRecords,
                criteriaBuilderSelectedText: i18n.PA_Event_Criteria_Builder_selected,
                searchKeywordText: i18n.PA_Event_Search_Keyword

                //quickFilter_Events: i18n.PA_Event_List_Search_QuickFilter_AllAccountabilityEvents,
                //quickFilter_EventsFromThisOrg: i18n.PA_Event_List_Search_QuickFilter_AccountabilityEventsFromThisOrg,
                //quickFilter_EventsFromOtherOrg: i18n.PA_Event_List_Search_QuickFilter_AccountabilityEventsFromOtherOrg,
            };
        },

        createConfirmOption: function (i18n) {
            return {
                confirmButtonText: i18n.PA_Event_Manager_End,
                cancelButtonText: i18n.PA_Event_Cancel_Button,
                dialogCloseButtonText: i18n.PA_Dialog_Close_Button_Text,
                dlgClass: "width650"
            };
        },

        createDateRangeSearchOption: function (i18n) {
            return {
                labelStartDate: resources.PA_Event_List_Search_StartDate,
                labelToDate: resources.PA_Event_List_Search_Date_To,
                FromDate: resources.PA_Event_List_Search_Datepicker_Please_Enter_Date_In_Format,
                ToDate: resources.PA_Event_List_Search_Datepicker_Please_Enter_Date_In_Format,
                DateRange: resources.PA_Event_List_Search_Date_Range,
                DateAfter: resources.PA_Event_List_Search_Date_after,
                DateBefore: resources.PA_Event_List_Search_Date_before,
                filterPropertyName_FromDate: "StartDate",
                filterPropertyName_ToDate: "EndDate"
            };
        },

        formatTimespan: function (timeSpan, i18n) {
            var hours = Math.floor(timeSpan / (1000 * 60 * 60));
            timeSpan -= hours * (1000 * 60 * 60);

            var mins = Math.floor(timeSpan / (1000 * 60));
            timeSpan -= mins * (1000 * 60);

            var ret = hours > 0 ? hours + " " + i18n.DurationFormat_Hours + " " : "";
            ret += mins > 0 ? mins + " " + i18n.DurationFormat_Minutes : "";
            return ret;
        }
    };

    return common;
});
