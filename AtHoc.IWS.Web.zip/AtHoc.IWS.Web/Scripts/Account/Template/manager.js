﻿
define([        
    "account/utils",
    "account/Template/details",
    "common/navigation",
    "account/Template/grid",
    "common/baseGridManager",
    "common/advancedSearch/search",
    "common/gridConfig"
], function (utils, DetailView, NavigationView, GridDataProvider, BaseGridManager, Search,GridConfig) {
    var baseGridManager, gridDataProvider, detailView, navigationView, search;
    var templateManager = function() {        
        var navigationModel = {
            sections: [
                {
                    dataPage: "listPage",
                    actions: [
                        { id: "add", text: $.htmlDecode(resources.PA_Template_Manager_NewTemplate), primary: true },
                        { id: "duplicate", enable: false, text: $.htmlDecode(resources.PA_Template_Manager_Duplicate) },
                        { id: "remove", enable: false, text: $.htmlDecode(resources.PA_Template_Manager_Delete) }
                    ]
                },{
                    dataPage: "detailPage",
                    actions: [
                        { id: "save", text: $.htmlDecode(resources.PA_Template_Manager_Save), primary: true },
                        { id: "settings", text: $.htmlDecode(resources.PA_Template_Manager_Settings), primary: false },
                        { id: "cancel", text: $.htmlDecode(resources.PA_Template_Manager_Back), primary: false }                        
                    ]
                }
            ]
        };

        //Page breadcrumb                
        var breadcrumbModel = new BreadcrumbModel();
        //Page Breadcrumb Knockout Model            
        var breadCrumb = new Breadcrumb('aPage', resources.PA_Template_Manager_EntityNamePlural, '', function () {
            baseGridManager.showList();
        });
        var pageBreadCrumb = new PageBreadcrumb('listPage', resources.PA_Template_Manager_EntityNamePlural, [], '');
        var detailPageBreadCrumb = new PageBreadcrumb('detailPage', resources.PA_Template_Manager_NewTemplate, [breadCrumb], '');
        breadcrumbModel.addPage(pageBreadCrumb);
        breadcrumbModel.addPage(detailPageBreadCrumb);        

        gridDataProvider = new GridDataProvider();

        var param =
        {
            templateSectionNode: $("#templateDetails .template-section"),
            contentSectionNode: $("#templateDetails .template-content-section"),
            targetingSectionNode: $("#templateDetails .template-targeting-section"),
            context: 'template',
            mode: 'edit',
            breadcrumbModel: breadcrumbModel
        }

        detailView = new DetailView(param);
        detailView.startup();
        detailView.init();
        detailView.onReadyChange = function(isReady) {
            navigationView.getAction("save").enable(isReady);
        };
        
        navigationView = new NavigationView("templateListActionsButtons", navigationModel);
        navigationView.startup();

        //update labels in settings...
        $(".scenario-content span:first").text(athoc.iws.publishing.resources.Account_EventContent);
        $(".scenario-users span:first").text(athoc.iws.publishing.resources.Account_AffectedUsers);
        $(".contentVisibility").text(athoc.iws.publishing.resources.Account_Visibility);
        $(".visibilityNote").text(athoc.iws.publishing.resources.Account_Visiblity_Note_Content);

        //wire up workflow tab click
        $('.finger-tab.event-user-workflow').click(function () {
            $('.finger-tab').removeClass('selected');
            $('.finger-tab.event-user-workflow').addClass('selected');
            $('#scenarioUsers, #scenarioContent, #officerWorkflow').hide();
            $('#userWorkflow').show();
        });

        //wire up workflow tab click
        $('.finger-tab.event-officer-workflow').click(function () {
            $('.finger-tab').removeClass('selected');
            $('.finger-tab.event-officer-workflow').addClass('selected');
            $('#scenarioUsers, #scenarioContent, #userWorkflow').hide();
            $('#officerWorkflow').show();
        });
 
        navigationView.setClickHandler("settings", function (e) {
            athoc.iws.scenario.settings.bindflag = false;
            $("#ScenarioSettings").show();
            $("#backshade").show();
            athoc.iws.scenario.settings.resizeModalBasedOnScreen($("#ScenarioSettings"));
            $('.finger-tab.scenario-content').click();
        });

        athoc.iws.alert.breadcrumbModel = breadcrumbModel;

        var strings =
        {
            entityNameSingle: resources.PA_Template_Manager_EntityNameSingle,
            entityNamePlural: resources.PA_Template_Manager_EntityNamePlural
        };

        search = new Search("searchHolder", utils.createTemplateSearchOption(resources));
        search.startup();
        //GridConfig parameter to baseGridManager can not be null .
        var gridConfig = new GridConfig();
        gridConfig.showEmptyRowMessage = true;
        gridConfig.showPager = true;
        gridConfig.noScrollTop = true;
        baseGridManager = new BaseGridManager(gridDataProvider, search, detailView, breadcrumbModel, navigationView, strings, gridConfig);
        baseGridManager.startup();

        search.setSearchPageInfo(baseGridManager.kendoGrid.dataSource);

        // add/override events
        gridDataProvider.on("start", function (id) {
            alert(resources.PA_Start_Event_Message);
        });

        baseGridManager.on("remove", function (seletedIds, successCallback, failCallback) {
            utils.removeTemplates(seletedIds, successCallback, failCallback);
        });

        baseGridManager.on("selectionChanged", function (count) {
            search.setSelectedCount(count);
            navigationView.getAction("duplicate").enable(count == 1);
            navigationView.getAction("remove").enable(count > 0);
        });
    };    
       
    return templateManager;
});


    
