﻿define([
    "common/baseView",
    "account/utils",
    "account/Template/details",
    "common/navigation"
], function (BaseView, utils, DetailView, NavigationView) {
    var navigationView;
    var reviewAndStartDialog = function (refNode, params) {
        var self = this;
        BaseView.call(this, refNode, null, null, []);
        
        self.navigationModel = {
            sections: [{
                dataPage: "detailPage",
                actions: [
                    { id: "start", click: $.proxy(self.start, self), text: resources.PA_Event_Start_Button, primary: true, visible: true },
                    { id: "cancel", click: $.proxy(self.hideDialog, self), text: resources.PA_Event_Cancel_Button, primary: false, visible: true },
                    { id: "close", click: $.proxy(self.close, self), text: resources.PA_Event_Close_Button, primary: false, visible: false }
                ]
            }]
        };

        navigationView = new NavigationView(this.refDomNode.find(".review-action-buttons"), self.navigationModel);
        navigationView.startup();                
        
        params.context = "event";
        params.mode = "view";
        params.reviewAndPublish = true;
        this.detailView = new DetailView(params);
        this.detailView.startup();
        
        this.detailView.on("loadTemplateComplete", function (tempalte) {
                        
        });
    };

    $.extend(reviewAndStartDialog.prototype, {
        init: function () {
            var self = this;
            self.detailView.init();
        },

        update: function (template) {
            this.template = template;
            this.detailView.update(template.Id, template);
        },

        close: function () {            
            utils.loadEventPage(this.newEventId, this.providerId);
        },

        start: function () {
            var self = this;
            navigationView.getAction("start").enable(false);
            navigationView.getAction("cancel").enable(false);
            utils.startEvent(self.template, function (data) {
                self.newEventId = data.Data;
                self.providerId = data.providerId;

                var msg = resources.PA_Event_Start_Success_Message;
                self.refDomNode.find('.message-panel').messagesPanel({ messages: [{ Type: '8', Value: msg }] }, null, null, null, null);
                self.refDomNode.find(".modal-body").scrollTop(0);
                self.onStartEventSuccess(self.newEventId);

                self.navigationModel.sections[0].actions[0].visible(false);
                self.navigationModel.sections[0].actions[1].visible(false);
                self.navigationModel.sections[0].actions[2].visible(true);
            }, function (error) {
                navigationView.getAction("start").enable(true);
                navigationView.getAction("cancel").enable(true);
                var msg = resources.PA_Event_Start_Failed_Message;
                self.refDomNode.find('.message-panel').messagesPanel({ messages: [{ Type: '4', Value: msg }] }, null, null, null, null);
                self.refDomNode.find(".modal-body").scrollTop(0);
            });
        },

        showDialog: function () {
            this.refDomNode.find(".modal-body").css("max-height", "500px");
            this.refDomNode.find('.message-panel').messagesPanel({ messages: [] }, null, null, null, null);
            this.refDomNode.modal('show');
            this.refDomNode.find(".publishing-detail").show();

            var errorMessages = this.detailView.getErrorMessages();
            if (errorMessages.length > 0) {
                navigationView.getAction("start").enable(false);
                this.detailView.params.templateSectionNode.find("#messagePanel").messagesPanel({ messages: errorMessages }, undefined, undefined, undefined, null);
            } else {
                navigationView.getAction("start").enable(true);
                this.detailView.params.templateSectionNode.find('#messagePanel').messagesPanel({ messages: [] }, null, null, null, null);
            }
            
            this.refDomNode.find(".modal-body").scrollTop(0);
        },

        hideDialog: function () {            
            this.refDomNode.modal('hide');
            this.refDomNode.find(".publishing-detail").hide();
        },

        // events:
        onStartEventSuccess: function() {}
    });

    return reviewAndStartDialog;
});



