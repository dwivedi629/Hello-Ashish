﻿define([
    "account/utils",
    "account/Template/details",
    "account/Template/reviewAndStartDialog",
    "common/navigation"
], function (utils, DetailView, ReviewAndStartDialog, NavigationView) {
    var editDetailView, reviewAndStartDialog, navigationView, allSectionReady;

    var startEventView = function (baseTemplateId, params) {
        var breadcrumbModel = new BreadcrumbModel();
        //Page breadcrumb                
        var pageBreadCrumb = new PageBreadcrumb('detailPage', '', [], '');
        breadcrumbModel.addPage(pageBreadCrumb);
        athoc.iws.alert.breadcrumbModel = breadcrumbModel;
        // bind breadcrumb
        breadcrumbModel.SelectedPage('detailPage');
        ko.applyBindings(breadcrumbModel, params.pageBreadCrumbsNode.get(0));
        $.titleCrumb("pageBreadcrumbs");

        var reviewAndStart = function () {

            $('#messagePanel').messagesPanel('reset');

            if (!allSectionReady) {
                $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.parameters.resources.Alert_Validation_NotReadyForPublish }] });
                return false;
            }

            var model = editDetailView.getModel();
            if (!reviewAndStartDialog) {
                var url = "/athoc-iws/account/GetReviewAndStartDialog";
                $.get(url, function(html) {
                    $(document.body).append(html);
                    params.readOnlyView = {
                        templateSectionNode: $("#dialogReviewAndStart .template-section"),
                        contentSectionNode: $("#dialogReviewAndStart .start-event-content-section"),
                        targetingSectionNode: $("#dialogReviewAndStart .start-event-targeting-section")
                    };

                    reviewAndStartDialog = new ReviewAndStartDialog("dialogReviewAndStart", params.readOnlyView);
                    reviewAndStartDialog.startup();
                    reviewAndStartDialog.init();

                    reviewAndStartDialog.update(model);
                    reviewAndStartDialog.onStartEventSuccess = function () {
                        editDetailView.resetDirty(false);
                    };
                    reviewAndStartDialog.showDialog();
                });
            } else {
                reviewAndStartDialog.update(model);
                reviewAndStartDialog.showDialog(); 
            }
        };

        var cancelEvent = function () {
            var isModified = editDetailView.isDirty();
            if (isModified == true) {

                var confirmLeave = confirm(resources.PA_Template_StartEvent_Confirmation);
                if (!confirmLeave) {
                    return;
                } else {
                    editDetailView.resetDirty(false);
                    utils.loadEventsPage();
                }
            }
            else {
                editDetailView.resetDirty(false);
                utils.loadEventsPage();
            }            
        };
        var navigationModel = {
            sections: [{
                dataPage: "detailPage",
                actions: [
                    { id: "ReviewAndStart", click: $.proxy(reviewAndStart), text: resources.PA_Template_StartEvent_ReviewStart, primaryWithIndicator: true },
                    { id: "Cancel", click: $.proxy(cancelEvent), text: resources.PA_Template_StartEvent_Cancel, primary: false }
                ]
            }]
        };        

        navigationView = new NavigationView(params.actionButtonsNode, navigationModel);
        navigationView.startup();                

        var editParams = params.editOnlyView;
        editParams.context = "event";
        editParams.mode = "edit";
        editDetailView = new DetailView(editParams);
        editDetailView.startup();
        editDetailView.init();
        editDetailView.loadAsync(baseTemplateId, "edit",
            function (data) {
                editDetailView.update(baseTemplateId, data, "edit");
            },
            function (error) {
                self.showErrorMessage(error);
            }
        );
  
        editDetailView.on("loadTemplateComplete", function (tempalte) {
            var span = "<span title='{1}' class='title-crumb'>{2}</span><span class='normal-narrow mar-left5 mar-right5'>{3}</span>";
            var titlePrefix = span.format(span, resources.PA_Event_Manager_NewEvent, resources.PA_Template_StartEvent_Message,
                resources.PA_Template_StartEvent_Message_2);

            breadcrumbModel.updateTitle(tempalte.GeneralSectionModel.Name, undefined, undefined, 'detailPage', titlePrefix);            
        });

        editDetailView.on("onReadyChange", function (isReady) {
            allSectionReady = isReady;
            var action = navigationView.getAction("ReviewAndStart");
            action.enable(allSectionReady);

            if (allSectionReady) {
                action.readyStatus('ready');
                action.readyStatusTitle(resources.PA_Template_Details_Section_ReadyTooltip);
            } else {
                action.readyStatus('not-ready');
                action.readyStatusTitle(resources.PA_Template_Details_Section_NotReadyTooltip);
            }
        });
    };

    return startEventView;
});



