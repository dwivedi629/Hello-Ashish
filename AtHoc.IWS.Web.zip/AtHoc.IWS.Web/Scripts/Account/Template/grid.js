﻿
define([
    "common/baseView",
    "dojo/text!account/Template/grid/template.html",
    "account/Template/grid/Model",
    "account/utils"
], function (BaseView, template, Model, utils) {
    var grid = function () {
        BaseView.call(this, $(":root"), template, Model, []);
    };

    $.extend(grid.prototype, {
        gridNode: "templateList",
        rowTemplateId: "rowTemplate",
        selectAllCheckboxClass: "grid-select-all",
        selectionCheckboxClass: "grid-item-select",
        columns: function () {
            var columns = new Array();
            columns.push({
                field: "Id",
                hidden: true
            });

            columns.push({
                field: "IsChecked",
                width: 40,
                headerTemplate: kendo.format('<div align="center"><input type="checkbox" class="grid-select-all" title="{0}"/></div>', this.model.i18n.PA_Select_All_Checkbox_Text),
                sortable: false,
                headerAttributes: { "class": "no-pointer" }
            });

            columns.push({
                field: "Name",
                headerTemplate: this.model.i18n.PA_Template_Manager_TemplateName,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Template_Manager_TemplateName }
            });

            columns.push({
                field: "Description",
                headerTemplate: this.model.i18n.PA_Template_Manager_Description,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Template_Manager_Description }
            });

            //columns.push({
            //    field: "CreatedByName",
            //    headerTemplate: this.model.i18n.PA_Template_Manager_CreatedBy,
            //    headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Template_Manager_CreatedBy }
               
            //});
            
            columns.push({
                field: "LastEventPublishedOn", // IWS - IWS-26951
                // The Actual data displayed in this column is LastEventPublishedOnString, this filed  be used for Sorting/Grouping
                headerTemplate: this.model.i18n.PA_Template_Manager_LastEventPublishedOn,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Template_Manager_LastEventPublishedOn }
            });

            //columns.push({
            //    field: "IsReadyForPublish",
            //    title: " ",
            //    template: $("#publish-template").html(),
            //    width: 100
            //});

            return columns;
        },
        schema: {
            data: "Items",
            total: "TotalCount",
            model: {
                fields: {
                    Id: { type: "int" },
                    Name: { type: "string" },
                    Description: { type: "string" },
                    Status: { type: "string" },
                    StartTime: { type: "string" },
                    CreatedBy: { type: "string" },
                    CreatedByName: { type: "string" },
                    LastEventPublishedOnString: { type: "string" }
                }
            }
        },

        sort: {
            field: "Name",
            dir: "asc"
        },

        processData: function (item) {
            //item.CreatedByName = "Someone";
            item.Name = item.GeneralSectionModel.Name;
        },

        url: athoc.iws.account.urls.GetTemplates,
        urlOptions: {}, // todo: add params

        getClickClassHandlers: function () {
            var self = this;
            return [
                {
                    cssClass: "template-selectable",
                    handler: $.proxy(function (item) {
                        self.select(item.Id);
                    })
                },
                {
                    cssClass: "event-start",
                    handler: $.proxy(function (item) {
                        utils.loadStartEventPage(item.Id);
                    })
                }
            ];
        },

        removeSelectedEntities: function (seletedIds, successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/RemoveTemplate";
            utils.removeEntities(seletedIds, successCallback, failCallback, loadUrl);
        },

        // events
        select: function (id) { },
        start: function (id) { },

        // Paging/Sorting flags
        serverSideSort: false,
        serverSidePagination: false
    });

    // upgly
    /*athoc.iws.accoutability.template.grid = function() {

    };*/

    return grid;
});
