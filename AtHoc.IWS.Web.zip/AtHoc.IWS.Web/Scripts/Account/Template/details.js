﻿define([
    "common/baseView",
    "account/utils",
    "account/Template/details/Model",
    "dojo/text!account/Template/details/template.html",
    "account/Template/Sections/general",
    "account/Template/Sections/process",
    "account/Template/Sections/operator",
    "account/Template/Sections/info"
], function (BaseView, utils, Model, template, GeneralSection, ProcessSesction, OperatorSection, InfoSection) {
    //constructor
    /*param example
        {            
            templateSectionNode: $("#dialogReviewAndStart .template-section"),
            contentSectionNode: $("#dialogReviewAndStart .start-event-content-section"),
            targetingSectionNode: $("#dialogReviewAndStart .start-event-targeting-section")
            context: 'event'
            mode: 'view'
        }*/
    var accountabiliyTemplate = function (params) {
        /*refDomNode, templateUserContentSectionId, templateUserTargetingSectionId, context, mode*/
        this.params = params;
        BaseView.call(this, params.templateSectionNode, template, Model, []);        
        this.context = params.context;
        this.mode = params.mode;
        this.reviewAndPublish = params.reviewAndPublish != null ? params.reviewAndPublish : false;
        this.breadcrumbModel = params.breadcrumbModel;
    };

    $.extend(accountabiliyTemplate.prototype, {
        init: function() {
            var self = this;
            //create the sub components
            if (this.context == 'template') {
                this.generalSection = new GeneralSection(this.params.templateSectionNode.find(".general-section"), this.mode, this.breadcrumbModel);
                this.generalSection.startup();
                this.generalSection.onReadyChange = function(isReady) {
                    self.isGeneralSectionReady = isReady;
                    self.onReadyChange(self.checkAllSectionReady());
                };
                //set up binding for officer settings
                var officerSettings = this.params.contentSectionNode.find("#EventOfficerWorkflowSettings");
                if (officerSettings.length > 0) {
                    kendo.bind(officerSettings, athoc.iws.scenario.settings.officerVM);
                }
            }
            
            this.infoSection = new InfoSection(this.params.templateSectionNode.find(".info-section"), this.context == 'template');
            this.infoSection.startup();

            var contentSectionProvider = {
                getTitle: function() {
                    return self.getContentModel().Title;                    
                },
                getBody: function() {                    
                    return self.getContentModel().Body;
                },
                getPlaceHolders: function() {

                }
            }

            this.processSection = new ProcessSesction(this.params.templateSectionNode.find(".process-section"), this.mode, contentSectionProvider, this.reviewAndPublish);
            this.processSection.startup();
            this.processSection.onEventEndTimeChangeSuccess = function (d) {
                self.onEventEndTimeChangeSuccess(d);
            };
            this.processSection.onEventEndTimeChangeError = function () {
                self.onEventEndTimeChangeError();
            };
            this.processSection.onReadyChange = function(isReady) {
                self.isProcessSectionReady = isReady;  
                self.onReadyChange(self.checkAllSectionReady());
            }
            if (this.mode=='edit') {
                window.onbeforeunload = function (event) {
                    var isModified = self.isDirty();                    
                    if (isModified) {
                        return self.model.i18n.Unsaved_Data_Text;
                    }
                }
            }
            this.operatorSection = new OperatorSection(this.params.templateSectionNode.find(".operator-section"), this.mode, contentSectionProvider, this.reviewAndPublish);
            this.operatorSection.startup();

            //rearrange the sections now            
            this.params.templateSectionNode.find(".info-section").insertAfter(this.params.targetingSectionNode);
            this.params.templateSectionNode.find(".operator-section").insertAfter(this.params.targetingSectionNode);
            this.params.templateSectionNode.find(".process-section").insertAfter(this.params.targetingSectionNode);
            this.params.targetingSectionNode.show();
            this.params.contentSectionNode.show();
            $(".details-lnkAffectedUsers").on("click", function() {
                self.onUserSelection(-1);
            });
        },

       
        setAlertData: function(alertModel) {
            var self = this;

            //fix for IWS-29026,29208
            if (alertModel.Content.LocationGeo == "" || alertModel.Content.LocationGeo == null)
                 athoc.iws.publishing.geo.geoJson = null;
            
            athoc.iws.publishing.view.publishingModel = alertModel;
            if (this.mode == "view") {
                athoc.iws.publishing.settings.IsSchedulingSupported = false;
                //possible values of athoc.iws.publishing.source:
                //h        - homepage
                //p        - publishing
                //a        - review and publish
                //readonly - alert detail
                athoc.iws.publishing.source = '';//this flag is checked in showTargetingPieChart() in athoc.iws.publishing.view.js and TargetedGroups() in athoc.iws.alert.reviewandpublish.js
                // note:  we have to pass the entire structure for the map to be loaded thats why we traverse up the tree
                var root = this.params.templateSectionNode.closest(".event-review-root");
                athoc.iws.publishing.view.bindContentSection(alertModel, root);
                if ($("#dialogReviewAndStart").length > 0) {
                    athoc.iws.publishing.view.bindGeoLocation(alertModel.Content.LocationGeo, root);
                    athoc.iws.publishing.view.bindTargetUsers(alertModel, root);//targeting section is only applicable to new event dialog not event details
                }
                //publishing scenario with placehoder
                athoc.iws.publishing.view.replacedPlaceholder = false;
                athoc.iws.publishing.view.replacePlaceholder();
            } else {
                athoc.iws.publishing.detail.bindFingerTabs();
                athoc.iws.publishing.detail.viewModel = alertModel;
                $.AjaxLoader.hideLoader();

                athoc.iws.publishing.view.viewModel.isGeoSelected(alertModel.Content.LocationGeo.length > 0);

                athoc.iws.publishing.context = alertModel.Context;
                athoc.iws.publishing.contextName = alertModel.ContextName;
                athoc.iws.publishing.entityId = alertModel.EntityId;

                athoc.iws.publishing.targetByUserArea = alertModel.TargetUsers.TargetUsersByArea;

                //eventHandler for ready status changed
                athoc.iws.publishing.content.onReadyChange = function (isReady) {
                    var model = athoc.iws.publishing.content.viewModel.data;
                    isReady = isReady && model.ResponseOptionId() > 0;
                    athoc.iws.publishing.content.viewModel.status(isReady ? 'ready' : 'not-ready');
                    athoc.iws.publishing.content.viewModel.statusTooltip(isReady ? self.model.i18n.PA_Template_Details_Section_ReadyTooltip : self.model.i18n.PA_Template_Details_Section_NotReadyTooltip);
                    self.isContentSectionReady = isReady;
                    self.onReadyChange(self.checkAllSectionReady());
                };

                athoc.iws.publishing.onReadyChange = function (isReady) {
                    self.isTargetingSectionReady = isReady;
                    self.onReadyChange(self.checkAllSectionReady());
                };

                ////// END alert
                //if scenario bind this section, Context 1 is for scenario
                if (alertModel.Context == 1 || alertModel.Context == 3) {
                    athoc.iws.publishing.targetUsers.Parameters.context = "AccountTemplate";
                    athoc.iws.publishing.scenario.bind(alertModel.ScenarioSection);
                    // to bind scenario settings 
                    athoc.iws.scenario.settings.bind(alertModel.ScenarioSettings);

                    athoc.iws.publishing.content.bind(alertModel.Content, alertModel.Context);

                    athoc.iws.publishing.targetUsers.bind(alertModel.TargetUsers, alertModel.PresetDeviceGroupOptions);
                    athoc.iws.publishing.iut.bind(alertModel.TargetUsers.TargetedBlockedUsers);
                } else {
                    athoc.iws.publishing.targetUsers.Parameters.context = "AccountEvent";
                    if (!athoc.iws.publishing.view.viewModel.data()) {
                        athoc.iws.publishing.view.viewModel.data = ko.mapping.fromJS(alertModel);
                        athoc.iws.publishing.view.viewModel.TargetedBlockerUsersList = alertModel.TargetUsers.TargetedBlockedUsers;
                        //below is fix for IWS-29234
                        if (alertModel.TargetUsers.TargetedCriteria && alertModel.TargetUsers.TargetedCriteria.selections)
                            athoc.iws.publishing.view.viewModel.QueryCriteriaCount(alertModel.TargetUsers.TargetedCriteria.selections.length);
                        if (alertModel.Content.LocationGeo.length > 0) {
                            var geoJson = JSON.parse(alertModel.Content.LocationGeo);
                            if (geoJson && geoJson.features) {
                                athoc.iws.publishing.view.viewModel.TargetedAreaCount(geoJson.features.length);
                            }
                        }
                    }
                    //apply scenario settings on alert 
                    athoc.iws.scenario.settings.applySettingsOnAlert(alertModel.ScenarioSettings, alertModel);
                    athoc.iws.publishing.alertOrgin = alertModel.AlertOrigin;
                }
                athoc.iws.publishing.targetUsers.load(alertModel.EntityId);

                athoc.iws.scenario.settings.isFillCountEnabled = alertModel.ScenarioSettings.Targeting.FillCount;
                //for Scenario always readonly=false
                //fill count summary can be readonly=true only when readonly is set scenario settings  and section is ready  
                athoc.iws.publishing.fillcount.bind(alertModel, alertModel.Context == 1 ? false : (alertModel.ScenarioSettings.Targeting.Readonly == true && athoc.iws.publishing.targetUsers.isReadyToPublish == true));

                athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(alertModel.ScenarioSettings.Targeting.EnabledTargetingTypes);
                athoc.iws.scenario.settings.ApplyOrgsettingsOnFingerTabs(alertModel.ScenarioSettings.Organization);
                if (alertModel.Context == 1 || alertModel.Context == 3) {
                    athoc.iws.publishing.detail.bindBucketExpandCollapse($("html"));
                    // toggle schedule section 
                    // athoc.iws.scenario.schedule.toggleScheduleSection();
                    // apply content settings such as dropbox , Location, response option  on Scenario
                    athoc.iws.scenario.settings.applyScenarioContentSettings(alertModel.ScenarioSettings.Content);
                } else {
                    $("#event-container").show();//work around for event content section flickering issue.
                    // apply content settings such as dropbox , Location, response option  on Alert
                    athoc.iws.scenario.settings.applyAlertContentSettings(alertModel.ScenarioSettings.Content);

                    athoc.iws.scenario.settings.applyCollapseSettingsOnAlert();
                    this.processSection.applySettings(alertModel.ScenarioSettings.AccountabilityWorkflow);
                    this.operatorSection.applySettings(alertModel.ScenarioSettings.AccountabilityOfficer);
                }

                athoc.iws.publishing.detail.setChanged(false);

                
            }

            utils.wireupOpenCollapse();

            var contentDom = $('#publishing-content-edit');
            var contentExpandHeaderDom = $('#bucketTitle', contentDom);
            var expandArrow = $('.expand-arrow-closed', contentExpandHeaderDom);
            if (expandArrow.css('display') == 'block') {
                contentExpandHeaderDom.on('click', function () {
                    if (!athoc.iws.publishing.geo.miniMap && athoc.iws.publishing.geo.geoJson) {
                        require(["widget/Map"], function (WidgetMap) {
                            athoc.iws.publishing.geo.miniMap = new WidgetMap("miniMapHolder", {i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                            athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                        });
                    }
                });
            }
            //for readonly content
            var readOnlyContentDom = $('#publishing-content-detail');
            var readOnlyContentExpandHeaderDom = $('#bucketTitle', readOnlyContentDom);
            var readOnlyExpandArrow = $('.expand-arrow-closed', readOnlyContentExpandHeaderDom);
            if (readOnlyExpandArrow.css('display') == 'block') {
                readOnlyContentExpandHeaderDom.on('click', function() {
                    if (!athoc.iws.publishing.view.readOnlyMap && athoc.iws.publishing.view.geoJson) {
                        require(["widget/Map"], function(WidgetMap) {
                            var reviewMapHolder = readOnlyContentDom.find(".readOnlyMiniMapHolder");
                            athoc.iws.publishing.view.readOnlyMap = new WidgetMap(reviewMapHolder, { i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMap, athoc.iws.publishing.view.geoJson);
                        });
                    }
                });
            }
        },

        loadAsync: function (id, action, successCallback, failCallback) {
            var self = this;
            var func;
            var templateIdToLoad = (id ? id : 0);
            if (action == "duplicate") {
                func = utils.getDuplicatedTemplate;
                //self.model.Id = 0;                                
            } else if (this.context == 'template') {
                func = utils.getTemplate;
                //self.model.Id = templateIdToLoad;
            } else {
                func = utils.getEventFromTemplate;
            }
            func.call(utils, templateIdToLoad, function(data) {
                self.template = data.Data;
                $(document).scrollTop(0);

                if (successCallback) {
                    successCallback(self.template);
                }
            }, function(error) {
                if (failCallback) {
                    failCallback(this.model.i18n.PA_Template_Details_FailureMessage);
                }
            });
        },

        update: function(id, data, action,noScrollTop) {
            var self = this;
            if (data) {
                self.template = data;
            }
            self.model.actionType = action;
            //remove old validation for content section. for some reason it's causing binding issues...
            this.params.contentSectionNode.find(".warning").each(function() { $(this).parent().remove(); });
            // we already have the item loaded at this point
            self.setAlertData(self.template.AlertBaseModel);
            if (this.context == 'template') {
                //self.generalSection.update(id > 0 ? self.template.GeneralSectionModel : null);
                self.generalSection.update(self.template.GeneralSectionModel);
                self.infoSection.update(id > 0 ? {
                    CreatedBy: self.template.CreatedByName,
                    UpdatedBy: self.template.UpdatedByName,
                    CreatedOn: self.template.CreatedOnString,
                    UpdatedOn: self.template.UpdatedOnString,
                    CommonName: self.template.CommonName,
                    TemplateId: self.template.Id
                } : null);

            } else {
                    // disalbe the info section fro event for now
                self.infoSection.update(false && id > 0 && action != 'edit' ? { // this is UGLY. we need to exclude the case of publishing... The id here is the tempalte ID!
                    CreatedBy: self.template.StartedByName,
                    //UpdatedBy: self.template.UpdatedByName,
                    CreatedOn: self.template.StartedOnSt,
                    //UpdatedOn: self.template.UpdatedOnString,
                    CommonName: self.template.CommonName,
                    TemplateId: self.template.Id
                } : null);
                if (athoc.iws.publishing.view.viewModel && data.RuntimeModel) {
                    athoc.iws.publishing.view.viewModel.TotalUsers(data.RuntimeModel.Status.TotalUsers);
                    var root = this.params.templateSectionNode.closest(".event-review-root");
                    root.find('#affectedUsers').text(data.RuntimeModel.Status.TotalUsers);
                }
            }

            //adding event data to the process section
            self.template.ProcessSectionModel.eventId = data.Id;
            self.template.ProcessSectionModel.startTime = data.StartDate;
            self.template.ProcessSectionModel.endTime = data.EndedOn === "" ? data.EndDate : data.EndedOn; //end time will be endedOn if it was manually ended.
            self.template.ProcessSectionModel.isLive = data.Status == "Live";
            self.template.ProcessSectionModel.IsCurrentVps = data.IsCurrentVps;
            self.processSection.update(self.template.ProcessSectionModel);
            //self.operatorSection.setAccountabilityOfficers(self.template.AccountabilityOfficers);
            var enableOfficerMessages = self.template.AlertBaseModel.ScenarioSettings.AccountabilityOfficer.IsAccountabilityOfficerMessagesVisible;
            self.operatorSection.update(self.template.OfficerSectionModel, enableOfficerMessages, self.template.AccountabilityOfficers);

            self.loadTemplateComplete(self.template);

            $('#messagePanel').messagesPanel('reset');
            this.processSection.refDomNode.find(".selectpicker").selectpicker();
            if (typeof (noScrollTop) == "undefined" || !noScrollTop) {
                $(document).scrollTop(0);
            }
            this.resetDirty(false);
        },

        getContentModel: function () {
            return athoc.iws.publishing.content.getModel() == undefined ? ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content) : athoc.iws.publishing.content.getModel();            
        },

        getModel: function() {
            var self = this;
            // first get alert model            
            var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
            //If content section is readonly need to get data from Publishing.View.viewModel.data.content
            var contentModel = self.getContentModel();
            //Get updated data from each section in viewmodel
            // start from the basic template data, then fill out the rest of the data            
            var alertObj = self.template.AlertBaseModel;
            alertObj.EntityId = athoc.iws.publishing.detail.viewModel.EntityId;
            alertObj.ParentId = athoc.iws.publishing.detail.viewModel.ParentId;
            alertObj.Content = contentModel;
            alertObj.TargetUsers = athoc.iws.publishing.targetUsers.getModel();
            //TargetOrg: athoc.iws.publishing.targetOrg.getModel(),
            //AlertScheduleSettings: athoc.iws.alert.schedule.getModel(),
            alertObj.MassDevices = massDeviceModel == null ? [] : massDeviceModel.MassDevices;
            alertObj.MassDeviceGroupOptions = massDeviceModel == null ? [] : massDeviceModel.MassDeviceGroupOptions;
            alertObj.AllPlaceHolderIds = athoc.iws.publishing.getPlaceholderList();
            //CustomPlaceHolders: athoc.iws.alert.placeholder.getModel(),
            alertObj.AlertOrigin = athoc.iws.publishing.detail.viewModel.AlertOrigin;
            alertObj.rbt = athoc.iws.publishing.rbt;

            //todo: review. a bit of a hack            
            alertObj.ScenarioSection = { ChannelId: athoc.iws.publishing.view.publishingModel.ScenarioSection.ChannelId };

            if (this.context == 'template') {
                var generalModel = this.generalSection.getModel();
                alertObj.ScenarioSettings = athoc.iws.scenario.settings.getModel();
            }
            var operatorModel = this.operatorSection.getModel();
            var processModel = this.processSection.getModel();
            var acountabilityOfficers = this.operatorSection.getAccountabilityOfficers();
            var ret = {
                Id: self.template.Id,
                AlertBaseId: self.template.AlertBaseId,
                AlertBaseModel: alertObj,
                GeneralSectionModel: generalModel,
                ProcessSectionModel: processModel,
                OfficerSectionModel: operatorModel,
                AccountabilityOfficers: acountabilityOfficers
            };

            return ret;
        },

        save: function() {
            var self = this;
            var model = this.getModel();
            model.GeneralSectionModel.Name = model.GeneralSectionModel.Name.trim();
            if (self.model.actionType == "duplicate")
                model.Id = 0;
            var dlSuccess = function(data) {
                self.saveComplete(data);
                self.model.actionType = "";
            };

            var error = function(data) {
                self.saveFailed();
                self.model.actionType = "";
            };

            utils.makeAjaxCall(athoc.iws.account.urls.SaveTemplate, model, dlSuccess, error);
        },

        loadTemplateComplete: function(template) {},
        saveComplete: function(data) {},
      
        onReadyChange: function (isReady) { },
        isDirty: function () {
            if (this.context == 'template') {
                return (this.processSection.isDataChanged || this.generalSection.isDataChanged || athoc.iws.publishing.content.isChanged || athoc.iws.publishing.scenario.isChanged);
            }
            else {
                return (this.processSection.isDataChanged || athoc.iws.publishing.content.isChanged || athoc.iws.publishing.scenario.isChanged);
            }
        },
        resetDirty: function (isDirty) {
            if (this.context == 'template') {
                this.processSection.isDataChanged = isDirty;
                this.generalSection.isDataChanged = isDirty;
                athoc.iws.publishing.content.isChanged = isDirty;
                athoc.iws.publishing.scenario.isChanged = isDirty;
            }
            else {
                this.processSection.isDataChanged = isDirty;
                athoc.iws.publishing.content.isChanged = isDirty;
                athoc.iws.publishing.scenario.isChanged = isDirty;
            }
        },

        getErrorMessages: function () {
            var errorMessages = [];
            errorMessages = errorMessages.concat(this.processSection.getErrorMessages());
            errorMessages = errorMessages.concat(this.operatorSection.getErrorMessages());                        
            return errorMessages;
        },

        isGeneralSectionReady: true,
        isContentSectionReady: true,
        sTargetingSectionReady: true,
        isProcessSectionReady: true,

        checkAllSectionReady: function () {
            if (this.context == 'template') {
                return (this.isGeneralSectionReady && this.isContentSectionReady && this.isProcessSectionReady);
            }
            else {
                return (this.isContentSectionReady && this.isTargetingSectionReady && this.isProcessSectionReady);
            }
        }

    });
    return accountabiliyTemplate;
});