﻿define([
    "common/baseView",
    "account/utils",
    "account/Template/selectTemplateDialog/Model",
    "dojo/text!account/Template/selectTemplateDialog/template.html",
    "common/baseGridManager",
    "common/navigation",
    "common/dialog",
    "common/gridConfig"
], function (BaseView, utils, Model, template, BaseGridManager, NavigationView, Dialog,GridConfig) {
    //constructor
    var selectTemplateDialog = function () {
        var self = this;
        // create a context node.
        var refDomNode = $("<div>");
        $("body").append(refDomNode);
        // butttons        
        var navigationModel = {
            sections: [
                {
                    dataPage: "",
                    actions: [
                        { id: "close", text: resources.PA_Event_Cancel_Button, primary: false, click: function () { self.dialog.hideDialog(); } }
                    ]
                }
            ]
        };
        this.dialog = new Dialog(navigationModel, resources.PA_Event_SelectTemplate_DialogTitle);
        this.dialog.startup();

        BaseView.call(this, this.dialog.getBodyNode(), template, Model, []);
        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);             
        };

        this.isInit = false;
    };

    $.extend(selectTemplateDialog.prototype, {
        init: function () {
            var self = this;            
            var gridDataProvider = {
                url: athoc.iws.account.urls.GetTemplates,
                urlOptions: {},
                gridNode: self.refDomNode.find(".acct-template-list"),//self.dialog.getBodyNode(),
                rowTemplateId: "rowTemplate",
                selectAllCheckboxClass: "",
                selectionCheckboxClass: "",
                removeFixWidth: true,                
                columns: function () {
                    var columns = new Array();
                    columns.push({
                        field: "Id",
                        hidden: true
                    });

                    columns.push({
                        field: "IsReadyForPublish",
                        title: " ",
                        template: $("#publish-template").html(),
                        width: 100
                    });

                    columns.push({
                        field: "Name",
                        headerTemplate: kendo.format('{0}', resources.PA_Event_SelectTemplate_Dialog_GridColumn_TemplateName),
                        headerAttributes: { "class": "no-pointer", "title": resources.PA_Event_SelectTemplate_Dialog_GridColumn_TemplateName }
                    });

                    columns.push({
                        field: "LastEventPublishedOn", // IWS - IWS-26951
                        //The Actual data displayed in this column is LastEventPublishedOnString, this filed  be used for Sorting/Grouping
                        headerTemplate: resources.PA_Event_SelectTemplate_Dialog_GridColumn_LastEventPublishedOn,
                        headerAttributes: { "class": "no-pointer", "title": resources.PA_Event_SelectTemplate_Dialog_GridColumn_LastEventPublishedOn }
                    });

                    return columns;
                },
                schema: {
                    /*parse: function (data) {
                        return self.setGridModel(data);
                    },*/
                    data: "Items",
                    total: "TotalCount",
                    model: {
                        fields: {
                            Id: { type: "int" },
                            Name: { type: "string" },
                            Status: { type: "string" },
                            StartTime: { type: "string" },
                            CreatedBy: { type: "string" },
                            CreatedByName: { type: "string" },
                            LastEventPublishedOnString: { type: "string" }
                        }
                    }
                },
                sort: {
                    field: "Name",
                    dir: "asc"
                },
                processData: function (item) {
                    item.selectTemplateButtonText = $.htmlEncode(self.model.i18n.PA_Template_SelectTemplate_Dialog_Select_Button);
                    item.selectTemplateButtonTooltip = $.htmlEncode(kendo.format((self.model.i18n.PA_Template_SelectTemplate_Dialog_Select_Button_Tooltip), item.Name));
                },

                getClickClassHandlers: function () {
                    var self = this;
                    return [
                        {
                            cssClass: "event-start",
                            handler: $.proxy(function (item) {
                                utils.loadStartEventPage(item.Id);
                            })
                        }
                    ];
                },

                // events
                start: function (id) { }
            }

            BaseView.call(gridDataProvider, "", null, null, []);

            var strings =
            {
                entityNameSingle: resources.PA_Template_SingleEntityName,
                entityNamePlural: resources.PA_Template_SinglePluralName
            };
            //GridConfig parameter to baseGridManager can not be null .
            var gridConfig = new GridConfig();
            gridConfig.noScrollTop = true;
            this.baseGridManager = new BaseGridManager(gridDataProvider, null, null, null, null, strings, gridConfig);
            this.baseGridManager.startup();            

            this.isInit = true;
        },

        update: function () {            
            this.baseGridManager.refreshGrid();
        },

        showDialog: function () {
            if (!this.isInit) {
                this.init();
            } else {
                this.update();
            }
            this.dialog.showDialog();

            // Overriding the model margin-top and set the fix top postion. 
            // Because Asynchronously loading data in dialog box grid that why popup height is increased after popup renderd.
            // TODO: will make the generic solution in next release.
            var dlgElement = this.dialog.refDomNode.find('.modal');
            if (dlgElement) {
                dlgElement.css("top", "72px");
                dlgElement.css("margin-top", "0px");
            }            
        },

        hideDialog: function () {           
            this.dialog.hideDialog();                       
        }
        
        //events        
    });
    return selectTemplateDialog;
});