﻿define([], function () {

    var Model = function (i18n) {
        var self = this;

        var lengthValidation = function (str, minChar, maxChar) {
            if (str) {
                if (str.length < minChar[1] || str.length > minChar[2]) {
                    return false;
                }
            }
            return true;
        };


        var durationValueValidation = function (str, params) {            
            if (str == "" || !(parseInt(str) > 0)) {
                return false;
            }
            return true;
        };
        var durationMaxValueValidation = function (str, params) {
            if (str == "" || (parseInt(str) > params[0])) {
                return false;
            }
            return true;
        };

        this.id = ko.observable();

        this.title = ko.observable()
            .extend({
                required: {
                    params: true,
                    message: i18n.PA_Template_Process_Message_Title_Length_ValidationMessage
                },
                validation: {
                    validator: lengthValidation,
                    message: i18n.PA_Template_Process_Message_Title_Length_ValidationMessage,
                    params: [this.value, 3, 100]
                }
            });
        this.body = ko.observable().extend({
            validation: {
                validator: lengthValidation,
                message: i18n.PA_Template_Process_Message_Body_Length_ValidationMessage,
                params: [this.value, 0, 4000]
            }
        });

        this.durationOptions = ko.observableArray([]);

        this.messageDurationUnit = ko.observable();
        this.messageDurationValue = ko.observable().extend({
            digit: true,
            validation: [{
                validator: durationValueValidation,
                message: i18n.PA_Template_Process_ValidationMessage_ZeroOrBlank,
                params: [this.value, 0, 200]
            },
            {
                validator: durationMaxValueValidation,
                message: i18n.PA_Template_Process_ValidationMessage_MaxDurationValue,
                params: [1500]
            }
            ]
        });

        this.messageDurationValue.subscribe(function (currentValue) {
            self.validate();
        });

        this.messageDurationUnit.subscribe(function (currentValue) {
            self.validate();
        });

        //this.isReminder = ko.computed(function () {        
        //    return (self.messageDurationUnit() != null && self.messageDurationValue() != null);
        //}, this);

        this.isReminder = ko.observable();
        this.messageDurationUnitText = ko.computed(function () {
            var text = '';
            self.durationOptions().forEach(function (value) {
                if (self.messageDurationUnit() == value.Value) {
                    text = value.Text;
                }
            });
            return text;
        }, this);


        this.mode = ko.observable();

        this.title.subscribe(function (currentValue) {
            self.validate();
            self.titleLength(currentValue.length);
        });

        this.body.subscribe(function (currentValue) {
            self.validate();
            self.bodyLength(currentValue.length);
        });

        this.isTitleFocused = ko.observable(false);
        this.titleLength = ko.observable(0);

        this.isBodyFocused = ko.observable(false);
        this.bodyLength = ko.observable(0);

        this.titleWithBreak = ko.observable();
        this.bodyWithBreak = ko.observable();

        //this.errors = ko.validation.group(self);
        this.eventPlaceholders = ko.observableArray([]);
        this.validate = function () {
            var isValid = (this.title.isValid() && this.body.isValid() && (this.isReminder() == true ? this.messageDurationValue.isValid() : true));
            self.onValidationChange(isValid);
            return isValid;
        },

        this.onValidationChange = function (isValid) {

        }
    };

    return Model;
});






