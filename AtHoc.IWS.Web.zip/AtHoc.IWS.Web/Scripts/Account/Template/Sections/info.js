﻿define([
    "common/baseView",
    "account/Template/Sections/info/Model",
    "dojo/text!account/Template/Sections/info/template.html"
], function (BaseView, Model, template) {

    var info = function (refDomNode, isTemplate) {
        var self = this;
        BaseView.call(this, refDomNode, template, Model, []);
        this.isTemplate = isTemplate;
    };

    $.extend(info.prototype, {
        init: function () {

        },
        update: function (infoModel) {            
            if (infoModel != null) {
                this.model.isVisible(true);
                this.model.isTemplate(this.isTemplate);
                this.model.createdBy(infoModel.CreatedBy);
                this.model.updatedBy(infoModel.UpdatedBy);
                this.model.createdOn(infoModel.CreatedOn);
                this.model.updatedOn(infoModel.UpdatedOn);
                this.model.commonName(infoModel.CommonName);
                this.model.templateId(infoModel.TemplateId);
            } else {
                this.model.isVisible(false);
            }
        }

    });

    return info;
});