﻿define([], function () {

    function Model(i18n) {
        var self = this;

        this.readonly = ko.observable(false);

        this.readonly.subscribe(function (value) {
            self.edit(!value);
        });

        this.edit = ko.observable(true);

        this.readyStatus = ko.observable('ready');
        this.readyStatusTitle = ko.observable(i18n.PA_Template_Details_Section_ReadyTooltip);

        this.checkReadyOrNotReady = function () {
            self.readyStatusTitle(i18n.PA_Template_Details_Section_ReadyTooltip);
            self.onChange(self.readyStatus() == 'ready' ? true : false);
        };

        this.initialMessageEnabled = ko.observable(true);
        this.endMessageEnabled = ko.observable(true);


        this.initialMessageEnabled.subscribe(function () {
            self.checkReadyOrNotReady();
        });
        this.endMessageEnabled.subscribe(function () {
            self.checkReadyOrNotReady();
        });

        this.editInitialMessagePopup = function () { };
        this.editEndMessagePopup = function () { };
        this.previewInitialMessagePopup = function () { };
        this.previewEndMessagePopup = function () { };

        this.isVisible = ko.observable(true);
        this.officersCount = ko.observable(0);
        // Events
        this.onChange = function (isReady) { }
    }

    return Model;
});