﻿define([
    "common/baseView",
    "account/Template/Sections/userSelection/Model",
    "dojo/text!account/Template/Sections/userSelection/template.html",
    "common/dialog",
    "publishing/UserList/UserList",
    "widget/UserInfo"
], function (BaseView, Model, template, Dialog, UserList, userInfo) {
    //constructor
    var userSelection = function (refDomNode, userPageLayout, reviewAndPublish,isReadonly) {
        this.accountabilityOfficers = [];
        this.reviewAndPublish = reviewAndPublish;
        this.isReadonly = isReadonly;
        this.userPageLayout = userPageLayout;
        BaseView.call(this, refDomNode, template, Model, []);

        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };      

    };

    $.extend(userSelection.prototype, {
        init: function () {
            var self = this;
            this.model.setOfficers = function () {
                self.userList.selectedUsers.length = 0;
                $.grep(self.accountabilityOfficers, function (item) {
                    self.userList.selectedUsers.push(item);
                });
                self.userList.resetSearchString();
                self.refDomNode.find(".operatorsDlgClose").text(self.model.i18n.Action_Button_Close);
                self.refDomNode.find(".operatorsDlgApply").text(self.model.i18n.Action_Button_Apply);
                self.refDomNode.find("#operatorUserList").modal("show");
                self.resizeModalBasedOnScreen(self.refDomNode.find("#operatorUserList"));
            };

            this.model.getOfficers = function () {
                self.accountabilityOfficers.length = 0;
                $.grep(self.userList.selectedUsers, function (item) {
                    self.accountabilityOfficers.push(item);
                });
                self.bindOfficers();
                self.refDomNode.find("#operatorUserList").modal("hide");
            }

            this.model.operatorsDlgClose = function () {
                self.refDomNode.find("#operatorUserList").modal("hide");
            };

            this.model.preview(this.reviewAndPublish);
            this.model.readonly(this.isReadonly);
            var options = {
                srcRefNode: this.refDomNode.find('.user-listing'),
                userPageLayout: this.userPageLayout,
                resourceStrings: this.model.i18n,
                Urls: athoc.iws.account.urls,
                width: '100%',
                height:'175',
                groupRefNode: null,
                queryRefNode: null,
                hierarchyRefNode: null,
                isGroupEnabled: false,
                isAdvanceSearchEnabled: false,
                PA_Template_AllUsers_PagingInfo:  this.model.i18n.PA_Template_AllUsers_PagingInfo,
                PA_Template_ItemsPerPage: this.model.i18n.PA_Template_ItemsPerPage,
                isModal: true
            }

            this.userList = new UserList(options, userInfo, this);
            this.userList.startUp();

            
            //this.userInfo = new userInfo(this.refDomNode.find("#officerCompactPopup"), "#userInfoModalBody");
            //this.userInfo.startup();
        },
      
        applySettings: function (settings) {
            if (!this.isReadonly)
                    this.isReadonly = settings.Readonly;
            this.model.readonly(this.isReadonly);
            this.model.isVisible(settings.Visible);
        },

        bindOfficers: function () {
            var self = this;
           
            this.model.totalSelectedUsers(self.accountabilityOfficers.length);
            self.onChange(self.accountabilityOfficers.length);
            var grid = self.refDomNode.find(".officers-listing").kendoGrid({
                dataSource: self.accountabilityOfficers,
                selectable: false,
                scrollable: true,
                sortable: { allowUnsort: false },
                pageable: false,
                columns:
                        [
                             {
                                 field: "Name",
                                 title: "Display Name",
                                 template: '<a id="userInfomation" value="#= UserId #" title="#= Name#" class="userInfomation" >#=Name#</a>',
                                 width: "95%",
                                 headerAttributes: {
                                     tabindex: "3"
                                 }
                             },
                              {
                                  field: "",
                                  title: "",
                                  template:this.model.readonly()?"": $("#officers-imgremove-template").html(),
                                  headerTemplate: kendo.format('<span title="{0}">{1}</span>', "", ""),
                                  width: "5%",
                                  headerAttributes: {
                                      tabindex: "5"
                                  },
                                  hidden: this.model.readonly()
                              }
                        ],
                change: function (e) {
                }
            }).data().kendoGrid;          
            $('.officers-listing .k-grid-header').hide();
            $('.officers-listing .k-pager-wrap').hide();

            $(self.refDomNode.find(".officers-listing")).on("click", ".remove", function () {
                var userId = this.getAttribute("userId");
                var raw = $(".officers-listing").data("kendoGrid").dataSource.data();
                var length = raw.length;
                var item, i;
                for (i = length - 1; i >= 0; i--) {
                    if (raw[i].UserId == userId) {
                        item = raw[i];
                        $(".officers-listing").data("kendoGrid").dataSource.remove(item);
                        _.each(self.accountabilityOfficers, function (obj, index) {
                            if (obj.UserId == item.UserId) {
                                self.accountabilityOfficers.splice(index, 1);
                            }
                        });
                        break;
                    }
                }
                self.model.totalSelectedUsers(self.accountabilityOfficers.length);
                self.onChange(self.accountabilityOfficers.length);

                if (item != undefined) {
                    $(".officers-listing").data("kendoGrid").refresh();
                }

            });

            self.refDomNode.find(".userInfomation").click(function () {
                self.getOfficerInfo(this);
            });
        },
       
        startup: function () {
                    
        },

        getAccountabilityOfficers: function () {
            var selectedUsers = [];
            $.grep(this.accountabilityOfficers, function (item) {
                selectedUsers.push({ UserId: item.UserId, Name: item.Name, IsBlocked: false });
            });
            return selectedUsers;
        },

        setAccountabilityOfficers: function (accountabilityOfficers) {
            var self = this;
            if (accountabilityOfficers == null)
                return;
            self.accountabilityOfficers = [];
            $.grep(accountabilityOfficers, function (item) {
                self.accountabilityOfficers.push({ UserId: item.UserId, Name: item.Name, IsBlocked: false });
            });
            this.bindOfficers();
        },

        resizeModalBasedOnScreen: function (modal) {

            modal.find(".modal-body").css("max-height", 600);
            var windowHeight = $(window).height();

            if (windowHeight > 770) {
                modal.css("margin-top", 40 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                modal.find(".modal-body").first().css("height", windowHeight - 340);
            } else {
                modal.css("margin-top", 40 - (windowHeight / 2));
                modal.find(".modal-body").first().css("height", windowHeight - 300);
            }

            if (modal.height() + 170 > windowHeight) {
                var newHeight = windowHeight - 170;
                modal.find(".modal-body").css("max-height", newHeight);

            }
            modal.find(".modal-body").css("overflow","hidden");
        },

        // Get user info for the compact popup
        getOfficerInfo: function (obj) {
            var self = this;
            var id = obj.getAttribute('value');
            var name = obj.getAttribute('title');
            self.userList.userInfo.update({ userId: id, userName: name }, $('#userInfoModal').find('#showProgress'));
            self.refDomNode.find("#userCompactPopup").find("#userInfoModal").modal();
            //$(self.refDomNode).append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
            //self.refDomNode.find("#userCompactPopup").find('#userInfoModal').on('hidden.bs.modal', function () {
              //  $("body").find('.modal-backdrop').hide();
            //});
        },
        onReadyChange: function (isReady) { }
    });

    return userSelection;
});