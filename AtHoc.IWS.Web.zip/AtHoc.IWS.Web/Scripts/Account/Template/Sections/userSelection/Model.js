﻿define([], function () {

    function Model(i18n) {
        var self = this;
        this.readonly = ko.observable(false);
        this.isVisible = ko.observable(true);
        this.readonly.subscribe(function (value) {
            self.edit(!value);
        });
        this.edit = ko.observable(true);
        this.preview = ko.observable(false);
        this.totalSelectedUsers=ko.observable(0);
        this.getOfficers = function () { };
        this.setOfficers = function () { };
        this.operatorsDlgClose = function () { };    
        this.onChange = function (isReady) { }
    }

    return Model;
});