﻿define([
    "common/baseView",
    "account/Template/Sections/process/Model",
    "dojo/text!account/Template/Sections/process/template.html",
    "account/Template/Sections/message",
    "common/dialog",
    "account/utils",
    "account/Event/eventEndTimeDialog"
], function (BaseView, Model, template, Message, Dialog, utils, EventEndTimeDialog) {
    //constructor
    var processSection = function (refDomNode, mode, contentSectionProvider, reviewAndPublish) {
        var self = this;
        this.contentSectionProvider = contentSectionProvider;
        this.isReadOnly = (mode != "edit");
        this.reviewAndPublish = reviewAndPublish;
        BaseView.call(this, refDomNode, template, Model, []);

        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
       
    };

    $.extend(processSection.prototype, {
        init: function () {
            this.setToggle();
            var self = this;

            this.model.onChange = function (isReady) {
                self.isDataChanged = true;
                self.onReadyChange(isReady);
            };
            this.model.refreshPastStatusValidityDurationUnit = function () {
                $("#pastStatusValidityDurationUnit").prop('disabled', !self.model.pastStatusValidityDurationEnabled()).selectpicker('refresh');
            };

            var editNavigationModel = {
                sections: [
                    {
                        dataPage: "",
                        actions: [
                            { id: "cancel", text: self.model.i18n.PA_Template_Details_Cancel_Button_Text, primary: false, click: function () { self.hideEditDialog(); } },
                            { id: "apply", text: self.model.i18n.PA_Template_Details_Apply_Button_Text, primary: true, click: function () { self.applyMessage(); } }
                        ]
                    }
                ]
            };

            var previewNavigationModel = {
                sections: [
                    {
                        dataPage: "",
                        actions: [
                            { id: "cancel", text: self.model.i18n.PA_Template_Details_Close_Button_Text, primary: false, click: function () { self.hidePreviewDialog(); } }
                        ]
                    }
                ]
            };


            this.initialMessage = new Message(this.refDomNode.find(".process-initial-message"), null, 'readOnly');
            this.initialMessage.startup();

            this.reminderMessage = new Message(this.refDomNode.find(".process-reminder-message"), null, 'readOnly', true);
            this.reminderMessage.startup();

            this.closingMessage = new Message(this.refDomNode.find(".process-end-message"), null, 'readOnly');
            this.closingMessage.startup();

            this.editDialog = new Dialog(editNavigationModel, "Edit", null, null, { dlgClass: 'width940' });
            this.editDialog.startup();
            this.previewDialog = new Dialog(previewNavigationModel, "Preview", null, null, { dlgClass: 'width970' });
            this.previewDialog.startup();

            this.model.editInitialMessagePopup = function () {
                self.editDialog.update(self.model.i18n.PA_Template_Details_Edit_Initial_Message_Text);
                var mess = new Message(self.editDialog.getBodyNode(), self.initialMessage.getModel(), 'edit');
                mess.startup();
                self.applyMessage = function () {
                    if (mess.isValid()) {
                        self.isDataChanged = mess.isDataChanged;
                        self.initialMessage.update(mess.getModel());
                        self.hideEditDialog();
                    }
                };
                mess.on("validationChange", function (isValid) {
                    self.editDialog.navigationView.getAction('apply').enable(isValid);
                });
                self.editDialog.showDialog();
            };

            this.model.editReminderMessagePopup = function () {
                self.editDialog.setTitle(self.model.i18n.PA_Template_Details_Edit_Reminder_Message_Text);
                var mess = new Message(self.editDialog.getBodyNode(), self.reminderMessage.getModel(), 'edit', true);
                mess.startup();
                self.applyMessage = function () {
                    if (mess.isValid()) {
                        self.isDataChanged = mess.isDataChanged;
                        self.reminderMessage.update(mess.getModel());
                        self.hideEditDialog();
                        self.model.checkReadyOrNotReady();
                    }
                };
                mess.on("validationChange", function (isValid) {
                    self.editDialog.navigationView.getAction('apply').enable(isValid);
                });
                self.editDialog.showDialog();
            };

            this.model.editEndMessagePopup = function () {
                self.editDialog.setTitle(self.model.i18n.PA_Template_Details_Edit_End_Message_Text);
                var mess = new Message(self.editDialog.getBodyNode(), self.closingMessage.getModel(), 'edit');
                mess.startup();
                self.applyMessage = function () {
                    if (mess.isValid()) {
                        self.isDataChanged = mess.isDataChanged;
                        self.closingMessage.update(mess.getModel());
                        self.hideEditDialog();
                    }
                };
                mess.on("validationChange", function (isValid) {
                    self.editDialog.navigationView.getAction('apply').enable(isValid);
                });
                self.editDialog.showDialog();
            };

            var getPreviewDialogBodyHtml = function (model, isEnding) {
                var url = "/athoc-iws/account/GetEventContentPreview";
                $.get(url, function(html) {
                    self.previewDialog.setBodyNode(html);
                    var root = self.previewDialog.getBodyNode2();
                    //making a copy of publishing model for binding
                    var pModel = jQuery.extend(true, {}, athoc.iws.publishing.view.publishingModel);
                    pModel.Content = ko.toJS(athoc.iws.publishing.content.viewModel.data);//get the latest values from the content section
                    pModel.Content.ResponseOptions = isEnding ? [] : pModel.Content.ResponseOptions;
                    pModel.Content.Title = model.title;
                    pModel.Content.Body = model.body;
                    self.previewDialog.showDialog();
                    athoc.iws.publishing.view.bindContentSection(pModel, root);
                    var geoSelected = athoc.iws.publishing.content.viewModel.isGeoSelected();
                    //need to get the geo json from athoc.iws.publishing.content in case of user editing the location
                    pModel.Content.LocationGeo = geoSelected ? athoc.iws.publishing.content.viewModel.data.LocationGeo() : null;
                    athoc.iws.publishing.view.readOnlyMapOtherCases = null;//need to re-initialize mini-map
                    athoc.iws.publishing.view.bindGeoLocation(pModel.Content.LocationGeo, root);
                    athoc.iws.utilities.resizeModalBasedOnScreen(root);
                    root.css("max-height", "400px");
                    utils.wireupOpenCollapse();
                });
            };

            this.model.previewInitialMessagePopup = function () {
                self.previewDialog.setTitle(self.model.i18n.PA_Template_Details_Preview_Initial_Message_Text);
                self.previewDialog.setHeader('');
                var model = self.getPreviewMessageModel(self.initialMessage.getModel());
                getPreviewDialogBodyHtml(model);
            };
            this.model.previewReminderMessagePopup = function () {
                self.previewDialog.setTitle(self.model.i18n.PA_Template_Details_Preview_Reminder_Message_Text);
                var reminderMsgModel = self.reminderMessage.getModel();
                var header = kendo.format("{0} {1} {2}", self.model.i18n.PA_Template_Process_Message_Reminder_Text, reminderMsgModel.messageDuration.Value, reminderMsgModel.messageDuration.UnitText);
                self.previewDialog.setHeader(header);
                var model = self.getPreviewMessageModel(reminderMsgModel);
                getPreviewDialogBodyHtml(model);
            };
            this.model.previewEndMessagePopup = function () {
                self.previewDialog.setTitle(self.model.i18n.PA_Template_Details_Preview_End_Message_Text);
                self.previewDialog.setHeader('');
                var model = self.getPreviewMessageModel(self.closingMessage.getModel());
                getPreviewDialogBodyHtml(model, true);
            };

            this.applyMessage = function () {
            };


            this.hideEditDialog = function () {
                self.editDialog.navigationView.getAction('apply').enable(true);
                self.editDialog.hideDialog();
            };

            this.hidePreviewDialog = function () {
                self.previewDialog.hideDialog();
            };

            this.model.onValidationWithReminderDuration = function () {                
                var reminderMessageModel = self.reminderMessage.getModel();
                if (self.durationValueInMinutes({ Unit: reminderMessageModel.messageDuration.Unit, Value: reminderMessageModel.messageDuration.Value }) >= self.durationValueInMinutes({ Unit: self.model.durationUnit(), Value: self.model.durationValue() }) &&
                    this.reminderMessageEnabled()) {
                    return true;
                }
                return false;
            };
            this.durationValueInMinutes = function (duration) {
                var result = null;
                switch (duration.Unit) {
                    case 'Minute':
                        result = duration.Value;
                        break;
                    case 'Hour':
                        result = 60 * duration.Value;
                        break;
                    case 'Day':
                        result = 24 * 60 * duration.Value;
                        break;
                }
                return parseInt(result);
            };

            this.model.changeEndTime = function () {
                var dialog = new EventEndTimeDialog({
                    id: self.model.eventId(), endTime: self.model.endTime()
                });
                dialog.startup();
                dialog.showDialog();
                //todo: bubble this up and refresh page...
                dialog.on("successCallback", function (e) {
                    self.model.endTime(e);
                    self.onEventEndTimeChangeSuccess(e);
                    $(document).scrollTop(0);
                });
                dialog.on("errorCallback", function () {
                    self.onEventEndTimeChangeError();
                    $(document).scrollTop(0);
                });
            };
        },

        applySettings: function (settings) {
            if (settings) {
                this.model.isVisible(settings.IsAccountabilityMessagesVisible);
                this.refDomNode.find(".bucket-toggle .row").toggle(!settings.IsAccountabilityMessagesCollapsed);
                this.refDomNode.find(".bucket-toggle .expand-arrow-open").toggle(!settings.IsAccountabilityMessagesCollapsed);
                this.refDomNode.find(".bucket-toggle .expand-arrow-closed").toggle(settings.IsAccountabilityMessagesCollapsed);
                if (!this.isReadOnly)
                    this.isReadOnly = settings.IsAccountabilityMessagesReadonly;
                //this.model.readonly(!settings.IsAccountabilityMessagesEnabled);                
            }
        },

        update: function (processSectionModel) {
            if (processSectionModel) {
                if (this.model.durationOptions().length == 0) {
                    var arrayObject = processSectionModel.TimeFormat;
                    for (var i = 0; i < arrayObject.length; i++) {
                        this.model.durationOptions.push(arrayObject[i]);
                    }
                }
                if (processSectionModel.LiveDuration != null) {
                    this.model.durationUnit(processSectionModel.LiveDuration.Unit);
                    this.model.durationValue(processSectionModel.LiveDuration.Value);
                }
                if (processSectionModel.PastStatusValidityDuration != null) {
                    this.model.pastStatusValidityDurationUnit(processSectionModel.PastStatusValidityDuration.Unit);
                    this.model.pastStatusValidityDurationValue(processSectionModel.PastStatusValidityDuration.Value);
                }
                this.model.pastStatusValidityDurationEnabled(processSectionModel.PastStatusValidityDurationEnabled);
                if (processSectionModel.FirstAlertUserMessage != null) {
                    this.model.initialMessageEnabled(processSectionModel.FirstAlertUserMessage.IsEnabled);
                    this.initialMessage.update({ id: processSectionModel.FirstAlertUserMessage.MessageId, title: processSectionModel.FirstAlertUserMessage.Title, body: processSectionModel.FirstAlertUserMessage.Body, eventPlaceholders: processSectionModel.EventPlaceholderList });

                }
                if (processSectionModel.ReminderAlertUserMessage != null) {
                    this.model.reminderMessageEnabled(processSectionModel.ReminderAlertUserMessage.IsEnabled);
                    //this.reminderMessage.update({ id: processSectionModel.ReminderAlertUserMessage.MessageId, title: processSectionModel.ReminderAlertUserMessage.Title, body: processSectionModel.ReminderAlertUserMessage.Body });
                    var reminderDurationUnit = 0;
                    var reminderDurationValue = 0;
                    if (processSectionModel.ReminderAlertUserMessage.AlertRepeatDuration != null) {
                        reminderDurationUnit = processSectionModel.ReminderAlertUserMessage.AlertRepeatDuration.Unit;
                        reminderDurationValue = processSectionModel.ReminderAlertUserMessage.AlertRepeatDuration.Value;
                    }
                    this.reminderMessage.update({ id: processSectionModel.ReminderAlertUserMessage.MessageId, title: processSectionModel.ReminderAlertUserMessage.Title, body: processSectionModel.ReminderAlertUserMessage.Body, eventPlaceholders: processSectionModel.EventPlaceholderList, messageDuration: { Unit: reminderDurationUnit, Value: reminderDurationValue, durationOptions: this.model.durationOptions() } });
                } else {
                    this.reminderMessage.update({ messageDuration: { durationOptions: this.model.durationOptions() } });
                }
                if (processSectionModel.CloseAlertUserMessage != null) {
                    this.model.endMessageEnabled(processSectionModel.CloseAlertUserMessage.IsEnabled);
                    this.closingMessage.update({ id: processSectionModel.CloseAlertUserMessage.MessageId, title: processSectionModel.CloseAlertUserMessage.Title, body: processSectionModel.CloseAlertUserMessage.Body, eventPlaceholders: processSectionModel.EventPlaceholderList });
                }

                //change event end time button
                this.model.eventId(processSectionModel.eventId);
                this.model.startTime(processSectionModel.startTime);
                this.model.endTime(processSectionModel.endTime);
                this.model.isLive(processSectionModel.isLive);
                this.model.isReviewAndStart(this.reviewAndPublish);
                this.model.showChangeEndTime(processSectionModel.isLive && processSectionModel.IsCurrentVps && !this.reviewAndPublish && IsPAManagerRole);
            } else {
                this.model.durationOptions([]);
                this.model.durationUnit('');
                this.model.durationValue('');
                this.model.pastStatusValidityDurationUnit('');
                this.model.pastStatusValidityDurationValue('');
                this.model.initialMessageEnabled(false);
                this.model.reminderMessageEnabled(false);
                this.model.endMessageEnabled(false);
            }

            this.model.checkReadyOrNotReady();
            this.model.readonly(this.isReadOnly);

            if (this.reviewAndPublish || this.isReadOnly) {
                this.model.readyStatus("");
            }
            if (this.reviewAndPublish) {
                this.model.readyStatus("");
                //this.initialMessage.setEditMode('preview');
                var replacePlaceholderInitialMessage = this.getPreviewMessageModel(this.initialMessage.getModel());
                this.initialMessage.update({ id: replacePlaceholderInitialMessage.id, title: replacePlaceholderInitialMessage.title, body: replacePlaceholderInitialMessage.body });
                //this.reminderMessage.setEditMode('preview');
                var replacePlaceholderReminderMessage = this.getPreviewMessageModel(this.reminderMessage.getModel());
                this.reminderMessage.update({ id: replacePlaceholderReminderMessage.id, title: replacePlaceholderReminderMessage.title, body: replacePlaceholderReminderMessage.body });
                //this.closingMessage.setEditMode('preview');
                var replacePlaceholderClosingMessage = this.getPreviewMessageModel(this.closingMessage.getModel());
                this.closingMessage.update({ id: replacePlaceholderClosingMessage.id, title: replacePlaceholderClosingMessage.title, body: replacePlaceholderClosingMessage.body });
            }

            this.refDomNode.find(".selectpicker").selectpicker('refresh');
            this.isDataChanged = false;
        },


        getModel: function () {
            var retModel = {
                TimeFormat: this.model.durationOptions(),
                LiveDuration: {
                    Unit: this.model.durationUnit(),
                    Value: this.model.durationValue()
                },
                PastStatusValidityDuration: {
                    Unit: this.model.pastStatusValidityDurationUnit(),
                    Value: parseInt(this.model.pastStatusValidityDurationValue()) || 0
                },
                PastStatusValidityDurationEnabled: this.model.pastStatusValidityDurationEnabled()
            };
            var initialMsgModel = this.initialMessage.getModel();
            retModel.FirstAlertUserMessage = {
                MessageId: initialMsgModel.id,
                Title: initialMsgModel.title,
                Body: initialMsgModel.body,
                IsEnabled: this.model.initialMessageEnabled()
            };
            if (initialMsgModel.eventPlaceholders != null) {
                retModel.EventPlaceholderList = initialMsgModel.eventPlaceholders;
            }            
            var remiderMsgModel = this.reminderMessage.getModel();
            retModel.ReminderAlertUserMessage = {
                MessageId: remiderMsgModel.id,
                Title: remiderMsgModel.title,
                Body: remiderMsgModel.body,
                IsEnabled: this.model.reminderMessageEnabled(),
                AlertRepeatDuration: {
                    Unit: remiderMsgModel.messageDuration.Unit,
                    Value: remiderMsgModel.messageDuration.Value
                }
            };

            var closingMsgModel = this.closingMessage.getModel();
            retModel.CloseAlertUserMessage = {
                MessageId: closingMsgModel.id,
                Title: closingMsgModel.title,
                Body: closingMsgModel.body,
                IsEnabled: this.model.endMessageEnabled()
            };

            return retModel;
        },

        getPreviewMessageModel: function (messageModel) {
            var title = this.contentSectionProvider.getTitle();
            var body = this.contentSectionProvider.getBody();
            var replacementText = "";
            $.each(messageModel.eventPlaceholders, function (id, value) {
                switch (value.EventPlaceholderId) {
                    case "AccountabilityName":
                        replacementText = title;
                        break;
                    case "AccountabilityDescription":
                        replacementText = body;
                        break;
                    case "AccountabilityStartTime":
                        replacementText = value.EventPlaceholderDisplayName;
                        break;
                }
                messageModel.title = messageModel.title.split(value.EventPlaceholderDisplayName).join(replacementText);
                messageModel.body = messageModel.body.split(value.EventPlaceholderDisplayName).join(replacementText);
            });
            var replacementModels =
            [
                { GroupId: 0, FieldId: 'messageTitle', Value: messageModel.title, MinLength: 3, MaxLength: 100, Label: this.model.i18n.PA_Template_Details_Message_Title_Label },
                { GroupId: 0, FieldId: 'messageBody', Value: messageModel.body, MinLength: 0, MaxLength: 4000, Label: this.model.i18n.PA_Template_Details_Message_Body_Label }
            ];

            var placeholderModel = {
                PlaceholderReplacementModels: replacementModels,
                SelectedPlaceHolders: null
            };

            utils.replaceMessagePlaceholders(placeholderModel, function (data) {
                $.each(data.Model.PlaceholderReplacementModels, function (index, responseModel) {
                    if (responseModel.GroupId == 0 && responseModel.FieldId == 'messageTitle') {
                        messageModel.title = responseModel.Value;
                        //messageModel.title = $.htmlEncode(responseModel.Value.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />');
                    } else if (responseModel.GroupId == 0 && responseModel.FieldId == 'messageBody') {
                        messageModel.body = responseModel.Value;
                        //messageModel.body = $.htmlEncode(responseModel.Value.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />');                        
                    }
                });
            });
            return messageModel;
        },
        getErrorMessages: function() {
            var errorMessage = [];                        
            errorMessage = errorMessage.concat(this.getErrors(this.initialMessage.getErrorFieldInfo(), this.model.i18n.PA_Template_Process_Send_InitialMessage_Title));
            errorMessage = errorMessage.concat(this.getErrors(this.reminderMessage.getErrorFieldInfo(), this.model.i18n.PA_Template_Process_Send_ReminderMessage_Title));
            errorMessage = errorMessage.concat(this.getErrors(this.closingMessage.getErrorFieldInfo(), this.model.i18n.PA_Template_Process_Send_EndMessage_Title));    
            return errorMessage;
        },

        getErrors: function (errorInfo, messageLabel) {
            var self = this;
            var errorMessage = [];            
            $.each(errorInfo, function (ind, val) {                
                if (val.Field == 'Title') {
                    errorMessage.push({ Type: 4, Value: kendo.format(self.model.i18n.PA_Event_AfterPlaceholderReplaced_Validation, self.model.i18n.PA_Event_User_Messages, messageLabel, val.Label, 3, 100) });
                }
                if (val.Field == 'Body') {
                    errorMessage.push({ Type: 4, Value: kendo.format(self.model.i18n.PA_Event_AfterPlaceholderReplaced_Validation, self.model.i18n.PA_Event_User_Messages, messageLabel, val.Label, 0, 4000) });
                }                
            });
            return errorMessage;
        },

        isDataChanged: false,

        onReadyChange: function (isReady) { },
        onEventEndTimeChangeSuccess: function (d) { },
        onEventEndTimeChangeError: function () { }
    });
    return processSection;
});