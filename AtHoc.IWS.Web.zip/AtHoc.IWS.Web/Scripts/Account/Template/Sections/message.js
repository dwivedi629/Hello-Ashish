﻿define([
    "common/baseView",
    "account/Template/Sections/message/Model",
    "dojo/text!account/Template/Sections/message/template.html"
], function (BaseView, Model, template) {

    var message = function (refDomNode, messageModel, mode, isReminder) {
        var self = this;
        BaseView.call(this, refDomNode, template, Model, []);

        this.model.isReminder((isReminder != null ? isReminder : false));

        if (messageModel!=null)
            this.update(messageModel);

        this.model.mode(mode);
                
        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
    };


    $.extend(message.prototype, {
        init: function() {
            var self = this;

            this.model.onValidationChange = function (isValid) {
                self.isDataChanged = true;
                self.validationChange(isValid);
            };

            if (this.model.mode() == 'edit') {

                require(["publishing/Placeholder/Placeholder"], function(Placeholder) {
                    var placeHolderItems = [];
                    var placeHolderTitle = self.model.i18n.PA_Event_Alert_Placeholder_Default_Item_Text;
                    var txt = self.refDomNode.find(".content-title-message")[0];
                    $.each(self.model.eventPlaceholders(), function (id, value) {
                        placeHolderItems.push({ DisplayName:  value.EventPlaceholderDisplayName, Id: value.EventPlaceholderId, IsSystem: true, Name: value.EventPlaceholderName });
                    });
                    var options = { textField: txt, items: placeHolderItems, placeHolderTitle: placeHolderTitle, isEventPlaceholder: true }
                    var ph = new Placeholder(options, $(".divMessageTitlePlaceholder", txt.parentNode)[0]);
                    ph.startup();

                    var txtBody = self.refDomNode.find(".content-body-message")[0];
                    var optionsBody = { textField: txtBody, items: placeHolderItems, placeHolderTitle: placeHolderTitle, isEventPlaceholder: true }
                    var phBody = new Placeholder(optionsBody, $(".divAccountTemplateBodyPlaceholder", txtBody.parentNode)[0]);
                    phBody.startup();

                });
                self.refDomNode.find(".selectpicker").selectpicker();
                self.refDomNode.find("#content-title-message").focus(function () {    
                    self.setTooltipPosition(this);
                });
                          
                self.refDomNode.find("#content-body-message").focus(function () {
                    self.setTooltipPosition(this);
                });
            }            
        },
        update: function (msg) {
            if (msg) {

                this.model.id(msg.id);
                this.model.title(msg.title);
                this.model.titleWithBreak($.htmlEncode(msg.title.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />'));
                this.model.body(msg.body);
                this.model.bodyWithBreak($.htmlEncode(msg.body.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />'));
                if (msg.eventPlaceholders != undefined)
                    this.model.eventPlaceholders(msg.eventPlaceholders);
                if (this.model.isReminder() && msg.messageDuration != null) {
                    this.model.durationOptions(msg.messageDuration.durationOptions);
                    this.model.messageDurationUnit(msg.messageDuration.Unit);
                    this.model.messageDurationValue(msg.messageDuration.Value);
                }

            } else {
                this.model.id('');
                this.model.title('');
                this.model.titleWithBreak('');
                this.model.body('');
                this.model.bodyWithBreak('');
                if (this.model.isReminder()) {
                    this.model.durationOptions([]);
                    this.model.messageDurationUnit('');
                    this.model.messageDurationValue('');
                }
            }
			this.isDataChanged = false;
        },
        getModel: function() {
            var retModel = {
                id: this.model.id(),
                title: this.model.title(),
                body: this.model.body(),
                eventPlaceholders: this.model.eventPlaceholders()
            };
            if (this.model.isReminder()) {
                retModel.messageDuration = {
                    Unit: this.model.messageDurationUnit(),
                    Value: this.model.messageDurationValue(),
                    durationOptions: this.model.durationOptions(),
                    UnitText: this.model.messageDurationUnitText()
                }
            }
            return retModel;
        },
        setEditMode: function(mode) {
            this.model.mode(mode);
        },

        isValid: function() {
            return (this.model.title.isValid() && this.model.body.isValid());
        },
        getErrorFieldInfo: function() {
            var errorMessages = [];
            if (!this.model.title.isValid()) {
                errorMessages.push({ Field: 'Title', Label: this.model.i18n.PA_Template_Process_Message_Title_Label });
            }
            if (!this.model.body.isValid()) {
                errorMessages.push({ Field: 'Body', Label: this.model.i18n.PA_Template_Process_Message_Body_Label });
            }            
            return errorMessages;
        },

        validationChange: function(isValid) { },
        isDataChanged: false,
        setTooltipPosition: function(inputField) {
            var tooltipId = "#" + inputField.id + "-tooltip-template";
            var tooltip = $(inputField).parent().find(tooltipId);
            var inputFieldHeight = $(inputField).outerHeight();
            var tooltipHeight = tooltip.height();
            var caretHeight = 7;
            if (inputField.id === "content-title-message") {
                tooltip.find('.dark-tooltip-caret').addClass('caret-up');
                tooltip.css({ top: inputFieldHeight + caretHeight + 'px' });
            } else {
                tooltip.css({ top: -(tooltipHeight + caretHeight) + 'px' });
            }
        }
    });

    return message;
});