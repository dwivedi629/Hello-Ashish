﻿define([
    "common/baseView",
    "account/Template/Sections/general/Model",
    "dojo/text!account/Template/Sections/general/template.html"
], function (BaseView, Model, template) {
    //constructor
    var generalSection = function (refDomNode, mode, breadcrumbModel) {
        var self = this;
        BaseView.call(this, refDomNode, template, Model, []);
        this.model.readOnly(mode != "edit");
        this.setToggle();

        this.model.onChange = function (isReady) {
            self.isDataChanged = true;
            self.onReadyChange(isReady);
        };

        this.model.save = function (publish) {
            self.save(publish);
        };

        this.model.onNameChanged = function (newValue) {
            var name = newValue;
            if (name == "") {
                name = self.model.i18n.BreadCrumb_Untitled;
            }

            breadcrumbModel.updateTitle(name);
        };
    };

    $.extend(generalSection.prototype, {
        update: function (generalSection) {
            if (generalSection != null) {
                this.model.Name(generalSection.Name);
                this.model.Description(generalSection.Description);
            }
            else {
                this.model.Name('');
                this.model.Description('');
            }
            this.isDataChanged = false;
        },

        getModel: function () {
            return {
                Name: this.model.Name(),
                Description: this.model.Description()
            }
        },
        isDataChanged: false,
        onReadyChange: function (isReady) { }
    });
    return generalSection;
});