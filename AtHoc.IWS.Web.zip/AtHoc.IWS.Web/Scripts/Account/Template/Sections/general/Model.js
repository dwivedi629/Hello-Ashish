﻿define([], function () {
    function Model(i18n) {
        var self = this;

        this.readOnly = ko.observable();

        this.edit = ko.computed(function() {
            return !self.readOnly();
        }, this);


        var lengthValidation = function (str, minChar, maxChar) {
            if (str) {
                if (str.length < minChar[1] || str.length > minChar[2]) {
                    return false;
                }
            }
            return true;
        };

        this.Name = ko.observable().extend({
            required: {
                params: true,
                message: i18n.PA_Template_Details_Name_Validation_Message
            },
            validation: {
                validator: lengthValidation,
                message: i18n.PA_Template_Details_Name_Validation_Message,
                params: [this.value, 0, 200]
            }
        });
        this.Description = ko.observable().extend({
            validation: {
                validator: lengthValidation,
                message: i18n.PA_Template_Details_Descr_Validation_Message,
                params: [this.value, 0, 200]
            }            
        });
        this.readyStatus = ko.observable();

        this.readyStatusTitle = ko.observable();

        this.Name.subscribe(function (newValue) {
            self.checkReadyOrNotReady();
            self.onNameChanged(newValue);
        });

        this.Description.subscribe(function () {
            self.checkReadyOrNotReady();
        });

        this.checkReadyOrNotReady = function () {
            if (self.Name.isValid() && self.Description.isValid()) {
                self.readyStatus('ready');
                self.readyStatusTitle(i18n.PA_Template_Details_Section_ReadyTooltip);
            }
            else {
                self.readyStatus('not-ready');
                self.readyStatusTitle(i18n.PA_Template_Details_Section_NotReadyTooltip);
            }
            self.onChange(self.readyStatus() == 'ready' ? true : false);
        };

        this.onNameChanged = function (newValue) {
        };

        this.onChange = function (isReady) {
        };

        //this.errors = ko.validation.group(self);
    }

    return Model;
});