﻿define([], function () {
    function Model() {
        var self = this;

        this.isTemplate = ko.observable(true);
        this.isVisible = ko.observable(false);
        this.createdBy = ko.observable();        
        this.updatedBy = ko.observable();
        this.createdOn = ko.observable();
        this.updatedOn = ko.observable();
        this.commonName = ko.observable();
        this.templateId = ko.observable();

    }

    return Model;
});