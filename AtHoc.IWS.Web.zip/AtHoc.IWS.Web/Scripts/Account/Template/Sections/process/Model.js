﻿define(["account/Event/eventEndTimeDialog", "account/utils"], function (EventEndTimeDialog, utils) {

    function Model(i18n) {
        var self = this;

        var durationMaxValueValidation = function (str, params) {
            if (str == "" || (parseInt(str) > params[0])) {
                return false;
            }
            return true;
        };

        var durationValueValidation = function (str, params) {
            if (str == "" || !(parseInt(str) > 0)) {
                return false;
            }
            return true;
        };
        ko.validation.rules['validatePastStatusValidityDurationEnabled'] = {
            validator: durationValueValidation
        };
        ko.validation.rules['validatePastStatusValidityDurationMaxValue'] = {
            validator: durationMaxValueValidation
        };

        ko.validation.registerExtenders();

        var validationWithReminderDuration = function (str, params) {            
            if (self.onValidationWithReminderDuration()) {
                return false;
            }
            return true;
        };

        this.onValidationWithReminderDuration = function() {};

        this.durationOptions = ko.observableArray([]);
        this.durationValue = ko.observable().extend({
            digit: true,
            validation: [{
                validator: durationValueValidation,
                message: i18n.PA_Template_Process_ValidationMessage_ZeroOrBlank,
                params: [this.value, 0, 200]
            },
            {
                validator: durationMaxValueValidation,
                message: i18n.PA_Template_Process_ValidationMessage_MaxDurationValue,
                params: [1500]
            }]

        });

        this.durationValue.subscribe(function () {
            self.checkReadyOrNotReady();
        });
        this.durationUnit = ko.observable().extend({
            validation: [
                {
                    validator: validationWithReminderDuration,
                    message: i18n.PA_Template_Process_ValidationMessage_EventDuration_GreaterThan_ReminderDuration,
                    params: [1500]
                }
            ]
        });
        this.durationUnit.subscribe(function () {
            self.checkReadyOrNotReady();
        });

        this.durationUnitText = ko.computed(function () {
            var text = '';
            self.durationOptions().forEach(function (value) {
                if (self.durationUnit() == value.Value) {
                    text = value.Text;
                }
            });
            return text;
        }, this);
        this.readonly = ko.observable(false);

        this.readonly.subscribe(function (value) {
            self.edit(!value);
        });

        this.edit = ko.observable(true);

        this.readyStatus = ko.observable('ready');
        this.readyStatusTitle = ko.observable();

        this.pastStatusValidityDurationEnabled = ko.observable(true);

        this.pastStatusValidityDurationEnabled.subscribe(function () {
            self.refreshPastStatusValidityDurationUnit();
            self.checkReadyOrNotReady();
        });

        this.checkReadyOrNotReady = function () {            
            if (self.pastStatusValidityDurationEnabled() && (!durationValueValidation(self.pastStatusValidityDurationValue()) || !durationMaxValueValidation(self.pastStatusValidityDurationValue(), [1500]) || !self.pastStatusValidityDurationValue.isValid())) {
                self.readyStatus('not-ready');
                self.readyStatusTitle(i18n.PA_Template_Details_Section_NotReadyTooltip);
            }            
            else if (self.durationValue() === '' || !self.durationValue.isValid()) {                
                self.readyStatus('not-ready');
                self.readyStatusTitle(i18n.PA_Template_Details_Section_NotReadyTooltip);
            }
            else if (self.onValidationWithReminderDuration()) {
                self.readyStatus('not-ready');
                self.readyStatusTitle(i18n.PA_Template_Details_Section_NotReadyTooltip);
            }
            else {
                self.readyStatus('ready');
                self.readyStatusTitle(i18n.PA_Template_Details_Section_ReadyTooltip);
            }
            self.onChange(self.readyStatus() == 'ready' ? true : false);
        };
        this.pastStatusValidityDurationValue = ko.observable().extend({
            digit: true,
            validatePastStatusValidityDurationEnabled: {
                message: i18n.PA_Template_Process_ValidationMessage_ZeroOrBlank,
                onlyIf: function () {
                    return self.pastStatusValidityDurationEnabled() === true;
                }
            },
            validatePastStatusValidityDurationMaxValue:
            {
                message: i18n.PA_Template_Process_ValidationMessage_MaxDurationValue,
                onlyIf: function () {
                    return self.pastStatusValidityDurationEnabled() === true;
                },
                params: [1500]
            }
            //validation: {
            //    validator: durationValueValidation,
            //    message: i18n.PA_Template_Process_ValidationMessage_ZeroOrBlank,
            //    params: [this.value, 0, 200],
            //    onlyIf: function () {
            //        return self.pastStatusValidityDurationEnabled() === true;
            //    }
            //}
            //required: {
            //    message: "Value is required",
            //    onlyIf: function () {
            //        return self.pastStatusValidityDurationEnabled() === true;
            //    }
            //}
        });

        this.pastStatusValidityDurationValue.subscribe(function () {
            self.checkReadyOrNotReady();
        });

        this.pastStatusValidityDurationUnit = ko.observable('');
        this.pastStatusValidityDurationUnit.subscribe(function () {
            self.checkReadyOrNotReady();
        });

        this.pastStatusValidityDurationUnitText = ko.computed(function () {
            var text = '';
            self.durationOptions().forEach(function (value) {
                if (self.pastStatusValidityDurationUnit() == value.Value) {
                    text = value.Text;
                }
            });
            return text;
        }, this);

        this.initialMessageEnabled = ko.observable(true);
        this.endMessageEnabled = ko.observable(true);
        this.reminderMessageEnabled = ko.observable(true);


        this.initialMessageEnabled.subscribe(function () {
            self.checkReadyOrNotReady();
        });
        this.endMessageEnabled.subscribe(function () {
            self.checkReadyOrNotReady();
        });
        this.reminderMessageEnabled.subscribe(function () {
            self.checkReadyOrNotReady();
        });


        this.editInitialMessagePopup = function () { };
        this.editReminderMessagePopup = function () { };
        this.editEndMessagePopup = function () { };
        this.previewInitialMessagePopup = function () { };
        this.previewReminderMessagePopup = function () { };
        this.previewEndMessagePopup = function () { };

        this.isVisible = ko.observable(true);

        // Events
        this.onChange = function (isReady) { }
        this.refreshPastStatusValidityDurationUnit = function () { }

        // Event end time 
        this.startTime = ko.observable();
        this.endTime = ko.observable();
        this.duration = ko.observable("");
        this.endTime.subscribe(function (d) {
            //todo: update duration value per the duration unit
            var startTime = new Date(moment(self.startTime(), utils.getVPSTimeFormat('momentformat')));
            var endTime = new Date(moment(d, utils.getVPSTimeFormat('momentformat')));
            var duration = utils.formatTimespan(endTime - startTime, self.i18n);
            self.duration(duration);
        });
        this.endTimeStr = ko.pureComputed(function () {
            return self.isLive() ? kendo.format("({0}: {1})", i18n.PA_Event_Details_Ends_At_Text, self.endTime())
                : kendo.format("({0}: {1})", i18n.PA_Event_Details_Ended_At_Text, self.endTime());
        });
        this.eventId = ko.observable();
        this.isLive = ko.observable(false);
        this.isReviewAndStart = ko.observable(false);
        this.showChangeEndTime = ko.observable(false);
        this.changeEndTime = function () { };
    }

    return Model;
});