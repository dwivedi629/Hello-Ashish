﻿define([    
    "common/baseView",
    "account/Template/Sections/operator/Model",
    "dojo/text!account/Template/Sections/operator/template.html",
    "account/Template/Sections/message",
    "common/dialog",
    "account/utils",
    "account/Template/Sections/userSelection"   
], function (BaseView, Model, template, Message, Dialog, utils, userSelection) {
    //constructor
    var operatorsSection = function (refDomNode, mode, contentSectionProvider, reviewAndPublish) {
        this.contentSectionProvider = contentSectionProvider;
        this.isReadOnly = (mode != "edit");
        this.reviewAndPublish = reviewAndPublish;
        this.accountabilityOfficers = [];
        BaseView.call(this, refDomNode, template, Model, []);

        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };

       
    };

    $.extend(operatorsSection.prototype, {
        init: function () {
            this.setToggle();
            var self = this;

            this.model.onChange = function (isReady) {
                self.isDataChanged = true;
                self.onReadyChange(isReady);
            };

            var editNavigationModel = {
                sections: [
                    {
                        dataPage: "",
                        actions: [
                            { id: "cancel", text: self.model.i18n.PA_Template_Details_Cancel_Button_Text, primary: false, click: function () { self.hideEditDialog(); } },
                            { id: "apply", text: self.model.i18n.PA_Template_Details_Apply_Button_Text, primary: true, click: function () { self.applyMessage(); } }
                        ]
                    }
                ]
            };

            var previewNavigationModel = {
                sections: [
                    {
                        dataPage: "",
                        actions: [
                            { id: "cancel", text: self.model.i18n.PA_Template_Details_Close_Button_Text, primary: false, click: function () { self.hidePreviewDialog(); } }
                        ]
                    }
                ]
            };


            this.initialMessage = new Message(this.refDomNode.find(".operator-initial-message"), null, 'readOnly');
            this.initialMessage.startup();

            this.closingMessage = new Message(this.refDomNode.find(".operator-end-message"), null, 'readOnly');
            this.closingMessage.startup();

            this.editDialog = new Dialog(editNavigationModel, "Edit", null, null, { dlgClass: 'width940' });
            this.editDialog.startup();
            this.previewDialog = new Dialog(previewNavigationModel, "Preview",null, null, { dlgClass: 'width970' });
            this.previewDialog.startup();

        
            this.model.editInitialMessagePopup = function () {
                self.editDialog.update(self.model.i18n.PA_Template_Details_Edit_Initial_Message_Text);
                var mess = new Message(self.editDialog.getBodyNode(), self.initialMessage.getModel(), 'edit');
                mess.startup();
                self.applyMessage = function () {
                    if (mess.isValid()) {
                        self.isDataChanged = mess.isDataChanged;
                        self.initialMessage.update(mess.getModel());
                        self.hideEditDialog();
                    }
                };
                mess.on("validationChange", function (isValid) {
                    self.editDialog.navigationView.getAction('apply').enable(isValid);
                });
                self.editDialog.showDialog();
            };

            this.model.editEndMessagePopup = function () {
                self.editDialog.setTitle(self.model.i18n.PA_Template_Details_Edit_End_Message_Text);
                var mess = new Message(self.editDialog.getBodyNode(), self.closingMessage.getModel(), 'edit');
                mess.startup();
                self.applyMessage = function () {
                    if (mess.isValid()) {
                        self.isDataChanged = mess.isDataChanged;
                        self.closingMessage.update(mess.getModel());
                        self.hideEditDialog();
                    }
                };
                mess.on("validationChange", function (isValid) {
                    self.editDialog.navigationView.getAction('apply').enable(isValid);
                });
                self.editDialog.showDialog();
            };

            var getPreviewDialogBodyHtml = function (model) {
                var url = "/athoc-iws/account/GetEventContentPreview";
                $.get(url, function (html) {
                    self.previewDialog.setBodyNode(html);
                    var root = self.previewDialog.getBodyNode2();
                    //making a copy of publishing model for binding
                    var pModel = jQuery.extend(true, {}, athoc.iws.publishing.view.publishingModel);
                    pModel.Content = ko.toJS(athoc.iws.publishing.content.viewModel.data);//get the latest values from the content section
                    pModel.Content.ResponseOptions = [];//no response options for officers
                    pModel.Content.Title = model.title;
                    pModel.Content.Body = model.body;
                    self.previewDialog.showDialog();
                    athoc.iws.publishing.view.bindContentSection(pModel, root);
                    var geoSelected = athoc.iws.publishing.content.viewModel.isGeoSelected();
                    //need to get the geo json from athoc.iws.publishing.content in case of user editing the location
                    pModel.Content.LocationGeo = geoSelected ? athoc.iws.publishing.content.viewModel.data.LocationGeo() : null;
                    athoc.iws.publishing.view.readOnlyMapOtherCases = null;//need to re-initialize mini-map
                    athoc.iws.publishing.view.bindGeoLocation(pModel.Content.LocationGeo, root);
                    athoc.iws.utilities.resizeModalBasedOnScreen(root);
                    root.css("max-height", "400px");
                    utils.wireupOpenCollapse();
                });
            };

            this.model.previewInitialMessagePopup = function () {
                self.previewDialog.setTitle(self.model.i18n.PA_Template_Details_Preview_Initial_Message_Text);
                var model = self.getPreviewMessageModel(self.initialMessage.getModel());
                getPreviewDialogBodyHtml(model);
            };
            this.model.previewEndMessagePopup = function () {
                self.previewDialog.setTitle(self.model.i18n.PA_Template_Details_Preview_End_Message_Text);
                var model = self.getPreviewMessageModel(self.closingMessage.getModel());
                getPreviewDialogBodyHtml(model);
            };

            this.applyMessage = function () {
            };


            this.hideEditDialog = function () {
                self.editDialog.navigationView.getAction('apply').enable(true);
                self.editDialog.hideDialog();
            };

            this.hidePreviewDialog = function () {
                self.previewDialog.hideDialog();
            };

            this.userSelection = new userSelection(self.refDomNode.find(".user-selection"), "FromUserManager", this.reviewAndPublish, this.isReadOnly);
            this.userSelection.startup();
            this.userSelection.onChange=function (cnt) {
                self.model.officersCount(cnt);
            };


        },      

        applySettings: function (settings) {
            if (settings) {
                this.model.isVisible(settings.Visible);
                this.refDomNode.find(".bucket-toggle .row").toggle(!settings.Collapsed);
                this.refDomNode.find(".bucket-toggle .expand-arrow-open").toggle(!settings.Collapsed);
                this.refDomNode.find(".bucket-toggle .expand-arrow-closed").toggle(settings.Collapsed);
                if (!this.isReadOnly)
                    this.isReadOnly = settings.Readonly;

                this.userSelection.applySettings(settings);
            }
        },

        update: function (operatorSectionModel, enableOfficerMessages,accountabilityOfficers) {
            enableOfficerMessages = enableOfficerMessages !== false; //flag from settings, optional defaults to true
            if (operatorSectionModel) {
                if (operatorSectionModel.InitialMessage != null) {
                    this.model.initialMessageEnabled(operatorSectionModel.InitialMessage.IsEnabled && enableOfficerMessages);
                    this.initialMessage.update({ id: operatorSectionModel.InitialMessage.MessageId, title: operatorSectionModel.InitialMessage.Title, body: operatorSectionModel.InitialMessage.Body, eventPlaceholders: operatorSectionModel.EventPlaceholderList });
                }
                if (operatorSectionModel.EndingMessage != null) {
                    this.model.endMessageEnabled(operatorSectionModel.EndingMessage.IsEnabled && enableOfficerMessages);
                    this.closingMessage.update({ id: operatorSectionModel.EndingMessage.MessageId, title: operatorSectionModel.EndingMessage.Title, body: operatorSectionModel.EndingMessage.Body, eventPlaceholders: operatorSectionModel.EventPlaceholderList });
                }
            } else {
                this.model.initialMessageEnabled(false);
                this.model.endMessageEnabled(false);
            }

            this.model.readonly(this.isReadOnly);

            if (this.reviewAndPublish || this.isReadOnly) {
                this.model.readyStatus("");
            }
            if (this.reviewAndPublish) {
                this.model.readyStatus("");
                var replacePlaceholderInitialMessage = this.getPreviewMessageModel(this.initialMessage.getModel());
                this.initialMessage.update({ id: replacePlaceholderInitialMessage.id, title: replacePlaceholderInitialMessage.title, body: replacePlaceholderInitialMessage.body });
                var replacePlaceholderClosingMessage = this.getPreviewMessageModel(this.closingMessage.getModel());
                this.closingMessage.update({ id: replacePlaceholderClosingMessage.id, title: replacePlaceholderClosingMessage.title, body: replacePlaceholderClosingMessage.body });
            }
            this.userSelection.setAccountabilityOfficers(accountabilityOfficers);
            this.isDataChanged = false;
        },

        getAccountabilityOfficers:function()
        {           
            return this.userSelection.getAccountabilityOfficers();
        },

        /*setAccountabilityOfficers: function (accountabilityOfficers) {
            var self = this;
            self.accountabilityOfficers = [];
            $.grep(accountabilityOfficers, function (item) {
                self.accountabilityOfficers.push({ UserId: item.UserId, Name: item.Name, IsBlocked: false});
            });
            this.bindOfficers();
        },*/

        getModel: function () {
            var retModel = {};
            var initialMsgModel = this.initialMessage.getModel();
            retModel.InitialMessage = {
                MessageId: initialMsgModel.id,
                Title: initialMsgModel.title,
                Body: initialMsgModel.body,
                IsEnabled: this.model.initialMessageEnabled()
            };
            if (initialMsgModel.eventPlaceholders != null) {
                retModel.EventPlaceholderList = initialMsgModel.eventPlaceholders;
            }
            
            var closingMsgModel = this.closingMessage.getModel();
            retModel.EndingMessage = {
                MessageId: closingMsgModel.id,
                Title: closingMsgModel.title,
                Body: closingMsgModel.body,
                IsEnabled: this.model.endMessageEnabled()
            };
            return retModel;
        },

        getPreviewMessageModel: function (messageModel) {
            var title = this.contentSectionProvider.getTitle();
            var body = this.contentSectionProvider.getBody();
            var replacementText = "";
            $.each(messageModel.eventPlaceholders, function (id, value) {
                switch (value.EventPlaceholderId) {
                    case "AccountabilityName":
                        replacementText = title;
                        break;
                    case "AccountabilityDescription":
                        replacementText = body;
                        break;
                    case "AccountabilityStartTime":
                        replacementText = value.EventPlaceholderDisplayName;
                        break;
                }
                messageModel.title = messageModel.title.split(value.EventPlaceholderDisplayName).join(replacementText);
                messageModel.body = messageModel.body.split(value.EventPlaceholderDisplayName).join(replacementText);
            });
            var replacementModels =
            [
                { GroupId: 0, FieldId: 'messageTitle', Value: messageModel.title, MinLength: 3, MaxLength: 100, Label: this.model.i18n.PA_Template_Details_Message_Title_Label },
                { GroupId: 0, FieldId: 'messageBody', Value: messageModel.body, MinLength: 0, MaxLength: 4000, Label: this.model.i18n.PA_Template_Details_Message_Body_Label }
            ];

            var placeholderModel = {
                PlaceholderReplacementModels: replacementModels,
                SelectedPlaceHolders: null
            };

            utils.replaceMessagePlaceholders(placeholderModel, function (data) {
                $.each(data.Model.PlaceholderReplacementModels, function (index, responseModel) {
                    if (responseModel.GroupId == 0 && responseModel.FieldId == 'messageTitle') {
                        messageModel.title = responseModel.Value;
                        //messageModel.title = $.htmlEncode(responseModel.Value.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />');
                    } else if (responseModel.GroupId == 0 && responseModel.FieldId == 'messageBody') {
                        messageModel.body = responseModel.Value;
                        //messageModel.body = $.htmlEncode(responseModel.Value.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />');                        
                    }
                });
            });
            return messageModel;
        },

        getErrorMessages: function () {
            var errorMessage = [];
            errorMessage = errorMessage.concat(this.getErrors(this.initialMessage.getErrorFieldInfo(), this.model.i18n.PA_Template_Process_Send_InitialMessage_Title));            
            errorMessage = errorMessage.concat(this.getErrors(this.closingMessage.getErrorFieldInfo(), this.model.i18n.PA_Template_Process_Send_EndMessage_Title));
            return errorMessage;
        },

        getErrors: function (errorInfo, messageLabel) {
            var self = this;
            var errorMessage = [];
            $.each(errorInfo, function (ind, val) {
                if (val.Field == 'Title') {
                    errorMessage.push({ Type: 4, Value: kendo.format(self.model.i18n.PA_Event_AfterPlaceholderReplaced_Validation, self.model.i18n.PA_Event_AccoutabilityOfficer_Messages, messageLabel, val.Label, 3, 100) });
                }
                if (val.Field == 'Body') {
                    errorMessage.push({ Type: 4, Value: kendo.format(self.model.i18n.PA_Event_AfterPlaceholderReplaced_Validation, self.model.i18n.PA_Event_AccoutabilityOfficer_Messages, messageLabel, val.Label, 0, 4000) });
                }
            });
            return errorMessage;
        },

        isDataChanged: false,

        onReadyChange: function (isReady) { }
    });

   
    return operatorsSection;
});