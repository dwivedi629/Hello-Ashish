﻿define([], function () {
    function Model() {
        var self = this;        
    }

    return Model;
});