﻿define([], function () {
    function Model() {        
        var self = this;
        var actionType = "";
    }
    
    return Model;
});