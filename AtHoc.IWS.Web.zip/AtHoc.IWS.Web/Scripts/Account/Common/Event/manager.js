﻿define([        
    "account/utils",
    "account/Template/details",
    "account/Common/navigation",
    "account//Event/grid",
    "account/Common/baseGridManager",
    "account/Template/selectTemplateDialog",
    "account/Common/search",
    "account/common/confirmationDialog",
], function (utils, DetailView, NavigationView, EventGridProvider, BaseGridManager, SelectTemplateDialog, Search, ConfirmationDialog) {
    var baseGridManager, eventGridProvider, detailView, navigationView, selectTemplateDialog, search, isCommand = false;
    this.confirmationDialog = new ConfirmationDialog(resources.PA_Event_Manager_End);
    var eventManager = function (gridNode, showNewDlgOnStart) {
        var breadcrumbModel = new BreadcrumbModel();
        //Page Breadcrumb Knockout Model            
        var breadCrumb = new Breadcrumb('aPage', resources.PA_Event_Manager_EntityNamePlural, '', function () {
            baseGridManager.showList();
        });

        var navigationModel = {
            sections: [
                {
                    dataPage: "listPage",
                    actions: [
                        { id: "addEvent", text: $.htmlDecode(resources.PA_Event_Manager_NewEvent), primary: true, click: function() {
                            selectTemplateDialog.showDialog();
                            isCommand = true;
                        } },
                        // Commenting out duplicate functionality as it is ot of scope for Release 90
                        //{ id: "duplicate", enable: false, text: $.htmlDecode(resources.PA_Event_Manager_Duplicate) },
                        { id: "end", enable: false, text: $.htmlDecode(resources.PA_Event_Manager_End), click: function() {
                            var ids = [];
                                var names = [];
                                baseGridManager.getSelectedItems().forEach(function(eventModel) {
                                    ids.push(eventModel.Id);
                                    names.push(eventModel.Name);
                                });
                                if (ids.length == 0) {
                                    return;
                                }

                                var nameTags = "";
                                for (var i = 0; i < names.length; i++) {
                                    nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(names[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(names[i]) + "</div>";
                                }

                                self.confirmationDialog.showConfirmationMessage(
                                kendo.format($.htmlDecode(resources.PA_Event_Manager_EndEvent)),
                                kendo.format($.htmlDecode(resources.PA_Event_Manager_EndEventConfirmation)),
                                kendo.format("{0}", nameTags),

                                    function() {
                                        var successCallback = function(data) {
                                            self.confirmationDialog.hideConfirmationMessage();
                                            baseGridManager.showSuccessMessage(kendo.format("{0} {1}", name, $.htmlDecode(resources.PA_Event_Manager_EndEventSuccess)));
                                            baseGridManager.refreshGrid();
                                        };

                                        var failCallback = function(data) {
                                            self.confirmationDialog.hideConfirmationMessage();
                                            baseGridManager.showErrorMessage(kendo.format("{0} {1}", $.htmlDecode(resources.PA_Event_Manager_EndEventFailure, name)));
                                        };

                                        utils.endEvents(ids, successCallback, failCallback);
                                    }
                                );
                            }
                        },
                        { id: "remove", enable: false, text: $.htmlDecode(resources.PA_Event_Manager_Delete) },
                        /*{ id: "export", enable: false, text: $.htmlDecode(resources.PA_Event_Manager_Export) }*/
                    ]
                }
            ]
        };
        
        //Page breadcrumb                
        var pageBreadCrumb = new PageBreadcrumb('listPage', resources.PA_Event_Manager_EntityNamePlural, [], '');
        var detailPageBreadCrumb = new PageBreadcrumb('detailPage', resources.PA_Event_Manager_NewEvent, [breadCrumb], '');
        breadcrumbModel.addPage(pageBreadCrumb);
        breadcrumbModel.addPage(detailPageBreadCrumb);        

        var eventGridProvider = new EventGridProvider(gridNode);

        var param =
        {
            templateSectionNode: $("#templateDetails .template-section"),
            contentSectionNode: $("#templateDetails .template-content-section"),
            targetingSectionNode: $("#templateDetails .template-targeting-section"),
            context: 'template',
            mode: 'edit'
        }

        detailView = new DetailView(param);
        detailView.startup();
        detailView.init();

        selectTemplateDialog = new SelectTemplateDialog("selectTemplateToBeRemove");
        selectTemplateDialog.startup();

        if (showNewDlgOnStart) {
            selectTemplateDialog.showDialog();
        }

        navigationView = new NavigationView("eventListActionsButtons", navigationModel);
        navigationView.startup();

        athoc.iws.alert.breadcrumbModel = breadcrumbModel;

        var strings =
        {
            entityNameSingle: resources.PA_Event_Manager_EntityNameSingle,
            entityNamePlural: resources.PA_Event_Manager_EntityNamePlural,
        };

        search = new Search("searchHolder");
        search.startup();

        baseGridManager = new BaseGridManager(eventGridProvider, search, detailView, breadcrumbModel, navigationView, strings, false, true);
        baseGridManager.startup();
        
        baseGridManager.on("selectionChanged", function (count) {
            var allLive = true;
            var live = false;
            baseGridManager.getSelectedItems().forEach(function(eventModel) {
                if (eventModel.Status != "Live") { // todo: user constands for that.
                    allLive = false;
                } else {
                    live = true;
                }
            });

            //navigationView.getAction("duplicate").enable(count == 1);
            navigationView.getAction("remove").enable(count > 0 && !live);
            navigationView.getAction("end").enable(count > 0 && allLive);
            /*navigationView.getAction("export").enable(count == 1);*/
        });
        
    };    
       
    return eventManager;
});


    
