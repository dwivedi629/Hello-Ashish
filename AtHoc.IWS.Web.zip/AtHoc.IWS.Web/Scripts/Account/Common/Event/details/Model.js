﻿define([], function () {
    function Model(i18n) {
        var self = this;
        this.isLive = ko.observable(true);
        this.status = ko.observable("");
        this.responseTypes = ko.observableArray([]),
        this.updatedOn = ko.observable("");
        this.endedOn = ko.observable("");
        this.endDate = ko.observable("");        
        this.responseId = ko.observable();
        this.isAllowedToUpdateStatus = ko.observable();
        this.statusText = ko.computed(function () {
            if (self.isLive()) {
                return i18n.PA_Event_Details_Ends_At_Text + ": " + self.endDate();
            } else {
                return i18n.PA_Event_Details_Ended_At_Text + ": " + self.endedOn();
            }

        });
        this.updatedText = ko.computed(function () {
            return userListResources.PAEvent_Updated_Text + ":" + self.updatedOn();
           

        });

        this.refresh = function () {
            self.loadEventData();

        };
        /*this.changeStatusSection = function () {
        };

        this.showChangeStatus = ko.observable(false);
        this.enableChangeStatus = ko.observable(false);*/

    }

    return Model;
});