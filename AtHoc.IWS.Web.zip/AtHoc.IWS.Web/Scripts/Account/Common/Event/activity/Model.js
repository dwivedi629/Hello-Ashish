﻿define([], function () {
    function Model() {
        var self = this;
        this.showPendingAlertsMessage = ko.observable(false);
        this.numberOfPendingAlerts = ko.observable(0);
    }

    return Model;
});