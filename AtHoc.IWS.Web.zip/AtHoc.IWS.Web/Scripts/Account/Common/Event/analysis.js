﻿define([    
    "account/Common/BaseView",
    "account/Event/analysis/model",
    "vendors/text!account/Event/analysis/template.html",
    "account/Event/Reports/orgBreakdown"
], function (BaseView, Model, template, OrgBreakdown) {
    //constructor
    var analysisView = function (refDomNode, eventId) {
        BaseView.call(this, refDomNode, template, Model, []);
        this.eventId = eventId;

        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
    };

    $.extend(analysisView.prototype, {
        init: function () {
            var self = this;
            this.orgBreakdown = new OrgBreakdown(this.refDomNode.find(".org-report"), this.eventId);
            this.orgBreakdown.startup();

            this.orgBreakdown.on("onUserSelection", function (filter) {
                self.onUserSelection(filter);
            });

            this.orgBreakdown.on("onAlertSelection", function (filter) {
                self.onAlertSelection(filter);
            });
        },
        update: function (eventModel) {
            this.orgBreakdown.update(eventModel);
        },

        canRefresh: function () { return true }, // a flag that can block UI from refreshing. i.e user is editing...

        //events
        onUserSelection: function (filter) { },
        onAlertSelection: function (filter) { },
        onChange: function () { }, //fires when there is a change that requires refresh
    });
    return analysisView;
});