﻿define([
    "account/Common/BaseView",
    "account/utils",
    "account/Event/Details/Model",
    "vendors/text!account/Event/Details/template.html",
    "account/Event/dashboard",
    "account/Event/users",
    "account/Event/analysis",
    "account/Event/settings",
    "account/Event/activity",
    "account/Common/navigation",
    "account/Common/tabs",
     "account/Export/exportDialog",
     "account/common/confirmationDialog",
], function (BaseView, utils, Model, template, DashboardView, UsersView, AnalysisView, SettingsView, ActivityView, NavigationView, TabsControl, ExportDialog, ConfirmationDialog) {
    //constructor 
    var eventDetails = function (refNode, navigationRefNode, eventId, eventSettingParams) {
        this.base = BaseView.call(this, refNode, template, Model, []);
        this.eventSettingParams = eventSettingParams;
        this.eventId = eventId;
        this.resources = userListResources;
        var self = this;
        this.navigationRefNode = navigationRefNode;
        this.controlById = [];
        this.responseOptionId = 0;
        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
        this.requireRefresh = false;
        this.canRefresh = true;
    };

    $.extend(eventDetails.prototype, {
        loadEventData: function () {
            var self = this;
            var loadUrl = athoc.iws.account.urls.GetEvent + "?id=" + self.eventId;
            utils.makeAjaxCall(loadUrl, {}, $.proxy(function (data) {
                self.update(data);
            }), $.proxy(function (e) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.Messages }] });
            }));
        },

        init: function () {
            var self = this;
            self.loadEventData();

            this.changeStatusSection = $.proxy(function () {
                $(".btn-info", self.controlById[self.tabNames.users].dialog.refDomNode).eq(0)[0].lastChild.nodeValue = "Cancel";
                self.controlById[self.tabNames.users].showDialog();
            });

            this.model.refresh = $.proxy(function () {
                self.loadEventData();
            });

            this.showChangeStatus = function(show) {
                this.navigationView.getAction("export").visible(show);
            };
            this.enableChangeStatus = function(enable) {
                this.navigationView.getAction("export").enable(enable);
            };
           
            this.navigationModel = {
                sections: [
                    {
                        dataPage: "dashboard",
                        actions: [
                            {
                                click: $.proxy(function () {
                                    self.confirmationDialog = new ConfirmationDialog(self.model.i18n.PA_Event_Manager_End);

                                    self.confirmationDialog.showConfirmationMessage(
                                        kendo.format(self.model.i18n.PA_Event_Manager_EndEvent),
                                        kendo.format(self.model.i18n.PA_Event_Manager_EndEventConfirmation),
                                        kendo.format("{0}", [self.eventModel.Name]),
                                        function() {
                                            var successCallback = function() {
                                                self.confirmationDialog.hideConfirmationMessage();
                                                self.showSuccessMessage(self.model.i18n.PA_Event_Details_EndEventMessage_Success);
                                                self.loadEventData();
                                            };

                                            var failCallback = function() {
                                                self.confirmationDialog.hideConfirmationMessage();
                                                self.showErrorMessage(self.model.i18n.PA_Event_Details_EndEventMessage_Failure);
                                            };

                                            utils.endEvents([self.eventModel.Id], successCallback, failCallback);
                                        });
                                }), text: this.model.i18n.PA_Event_Details_EndEvent, enable: false
                            },
                            {
                                click: $.proxy(function () {
                                    self.controlById[self.tabNames.users].selectedFilter();
                                    ExportDialog.model.selectedFilter(self.controlById[self.tabNames.users].ph.filterType);
                                    ExportDialog.model.searchStrings(self.controlById[self.tabNames.users].searchStrings);
                                    ExportDialog.attriubuteCsv = self.controlById[self.tabNames.users].ph.extraCommonNames;
                                    ExportDialog.allUserSortOrder = self.controlById[self.tabNames.users].ph.allUserSortOrder;
                                    ExportDialog.allUserSortColumn = self.controlById[self.tabNames.users].ph.allUserSortColumn;
                                    ExportDialog.queryCriteria = self.controlById[self.tabNames.users].ph.queryCriteria;
                                    ExportDialog.model.title(self.model.i18n.PA_Event_Export_Dialog_Title + " - " + self.eventModel.Name);
                                    ExportDialog.orgHrchyOptions = self.controlById[self.tabNames.analysis].orgBreakdown.urlOptions;
                                    ExportDialog.model.orgHrchyContent (self.controlById[self.tabNames.analysis].orgBreakdown.model.hierarchyContext());
                                    ExportDialog.model.orgHrchySelectedItem = self.controlById[self.tabNames.analysis].orgBreakdown.model.selectedItem();
                                    ExportDialog.showDialog();
                                }), text: this.model.i18n.PA_Event_Details_Export, primary: false
                            },                            
                            {
                                id: "export",
                                click: $.proxy(function () {
                                    self.changeStatusSection();
                                }), text: userListResources.PAEvent_ChangeStatus_Button, primary: true, enable: false
                            }
                        ]
                    }
                ]
            };

            this.navigationView = new NavigationView(this.navigationRefNode, this.navigationModel);
            this.navigationView.startup();
            //initialize exporDialog once we have responseOptionId
            ExportDialog = new ExportDialog(self.eventId);
            ExportDialog.startup();

            this.tabsModel = [
                { id: this.tabNames.dashboard, Name: this.model.i18n.PA_Event_Details_Summary },
                { id: this.tabNames.users, Name: this.model.i18n.PA_Event_Details_Users },
                { id: this.tabNames.analysis, Name: this.model.i18n.PA_Event_Details_Analysis },
                { id: this.tabNames.activity, Name: this.model.i18n.PA_Event_Details_Activity },
                { id: this.tabNames.setting, Name: this.model.i18n.PA_Event_Details_Details }
            ];

            this.tabsControl = new TabsControl(this.refDomNode.find(".event-tabs"), this.tabsModel);
            this.tabsControl.startup();

            this.tabsControl.on("onSelect", function (prevSelecededTabName, selectedTabName, params) {                
                //var tabView = self.controlById[selectedTabName];
                if (prevSelecededTabName !== selectedTabName) {
                    var prevTabView = self.controlById[prevSelecededTabName];
                    if (prevTabView && prevTabView.onHide) {
                        prevTabView.onHide();
                    }
                    
                    var tabView = self.controlById[selectedTabName];
                    if (tabView && tabView.onShow) {
                        tabView.onShow();
                    }                    
                }

                if (selectedTabName == self.tabNames.users) {                    
                    if (self.model.isLive() && self.model.isAllowedToUpdateStatus())
                        self.showChangeStatus(true);
                } else {                    
                    self.showChangeStatus(false);
                }

                if (self.requireRefresh) {
                    self.loadEventData();
                }
            });

            this.tabsControl.on("onShow", function (prevSelecededTabName, selectedTabName, params) {
                if (selectedTabName == self.tabNames.setting) {
                    var tabView = self.controlById[selectedTabName];
                    tabView.onVisible();
                }
            });

            this.createTabControl(this.tabNames.dashboard, DashboardView);
            this.createTabControl(this.tabNames.users, UsersView);
            this.createTabControl(this.tabNames.analysis, AnalysisView);
            this.createTabControl(this.tabNames.activity, ActivityView);
            this.createTabControl(this.tabNames.setting, SettingsView, this.eventSettingParams);

            this.controlById[this.tabNames.users].on("onEnableDisableChangeStatus", function (enable) {
                self.enableChangeStatus(enable);
            });

            this.tabsControl.select(this.tabNames.dashboard);
            var breadcrumbModel = new BreadcrumbModel();
            //Page breadcrumb
            var pageBreadCrumb = new PageBreadcrumb('eventList', this.model.i18n.PA_Event_Manager_EntityNamePlural, [], '');
            var listBreadCrumb = new Breadcrumb('eventList', this.model.i18n.PA_Event_Manager_EntityNamePlural, '', function () {
                utils.loadEventsPage();
            });

            this.detailPageBreadCrumb = new PageBreadcrumb('eventPage', '', [listBreadCrumb], '');
            breadcrumbModel.addPage(pageBreadCrumb);
            breadcrumbModel.addPage(this.detailPageBreadCrumb);

            // bind breadcrumb
            breadcrumbModel.SelectedPage('eventPage');
            ko.applyBindings(breadcrumbModel, $("#pageBreadcrumbs").get(0));
            $.titleCrumb("pageBreadcrumbs");            
        },

        setRefreshTimer: function () {
            var self = this;
            if (!self.model.isLive()) {
                return;
            }
            if (self.refreshTimer) {
                clearTimeout(self.refreshTimer);
            }
            self.refreshTimer = setTimeout(function () {
               
                var canRefresh = true;
                $.each(self.tabNames, function (key, value) {
                    // check first all tabs
                    var tabView = self.controlById[value];
                    if (tabView.canRefresh && !tabView.canRefresh()) {
                        canRefresh = false;                            
                    }
                });
                if (canRefresh) {
                    self.loadEventData();
                } else {
                    // if can't update from some reason, we will again in 60 sec
                    self.setRefreshTimer();
                }                    
            }, 60000);            
        },

        createTabControl: function (name, control, params) {
            var self = this;
            var tabView = new control(self.tabsControl.getTabContentElement(name), self.eventId, params);
            this.controlById[name] = tabView;
            tabView.startup();
            tabView.on("onUserSelection", function (filter) {
                self.selectTab(self.tabNames.users, filter);
            });
            tabView.on("onAlertSelection", function (filter) {
                self.selectTab(self.tabNames.activity, filter);
            });
            tabView.on("onChange", function () {
                // set the flag to refresh next time
                self.requireRefresh = true;
            });            
        },

        update: function (data) {
            this.eventModel = data.Data;
            // update the breadcrumb
            this.detailPageBreadCrumb.Title(this.eventModel.Name);
            var self = this;
            $.each(self.tabNames, function (key, value) {
                var view = self.controlById[value];
                view.update(self.eventModel);
            });
            this.model.isLive(this.eventModel.Status == utils.EventStatus.Live);
            this.navigationModel.sections[0].actions[0].enable(this.model.isLive());
            this.model.status(this.eventModel.Status == utils.EventStatus.Live ? this.model.i18n.PA_Event_Details_LiveStatus : this.model.i18n.PA_Event_Details_EndedStatus);
            this.model.updatedOn(data.TimeStamp);
            this.model.endedOn(this.eventModel.EndedOn);
            this.model.endDate(this.eventModel.EndDate);
            this.model.isAllowedToUpdateStatus(this.eventModel.IsAllowedToUpdateStatus);

            // set refresh timers
            this.setRefreshTimer(this.eventModel);
            self.requireRefresh = false;
        },
        
        showErrorMessage: function (msg) {
            var self = this;
            $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: msg }] }, null);
        },

        showSuccessMessage: function (msg) {
            var self = this;
            $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: msg }] }, null);
        },


        getModel: function () {
            var self = this;
            return {};
        },

        // by the user;)
             
        selectTab: function (tabName, filter) {
            this.tabsControl.select(tabName);
            var view = this.controlById[tabName];
            if (view.onShow && filter!=null && tabName=="users") {
                view.onChangeStatus(filter);
            }
        },
        tabNames: {
            dashboard: "dashboard",
            activity: "activity",
            users: "users",
            analysis: "analysis",
            setting: "setting",
        }
    });

    return eventDetails;
});