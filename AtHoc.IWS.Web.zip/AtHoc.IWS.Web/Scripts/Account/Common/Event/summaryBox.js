﻿define([    
    "account/Common/BaseView",
    "account/utils",
    "account/Event/summaryBox/Model",
    "vendors/text!account/Event/summaryBox/template.html",
], function (BaseView, utils, Model, template) {
    //constructor
    var CreateEvent = function (refDomNode) {
        BaseView.call(this, refDomNode, template, Model, []);

        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
    };

    $.extend(CreateEvent.prototype, {
        init: function (model) {
            var self = this;

              self.model.selectUsers = function (c, event) {
                var element = event.target;
                var SortOrder = element.getAttribute('status');
                // This is already written and i am changing to next call
                /*self.onUserSelection({
                    status: "with", response:"all"});*/
                self.onUserSelection({
                    status: SortOrder == null ? this.SortOrder : SortOrder,
                    response: "all"
                });
            };            
            $(".menu").kendoMenu({
                openOnClick: true,
            });
            /*self.refDomNode.find(".total-status-chart").kendoChart({
                title: {
                    visible: false,                    
                },
                dataSource: new kendo.data.DataSource({ data: [] }),
                legend: {
                    visible: false
                },
                plotArea: { margin: 1 },
                chartArea: {
                    margin: 1,
                    background: "",                  
                },
                seriesDefaults: {
                    type: "donut",
                    startAngle: -90,
                    holeSize: 75,
                    padding: 0
                },                
                series: [{
                    name: "Total Responses",
                    field: "value"
                }],
                tooltip: {  
                    visible: true,
                    template: "#= category # : #= value # users",                                       
                },
                seriesHover: function(){
                    self.refDomNode.find(".total-status-chart").css("cursor", "pointer");
                },
                processData: function (item) {
                    item.ViewLinkText = self.model.i18n.PA_Event_Summary_View_Link_Text;
                    item.SendAlertText = self.model.i18n.PA_Event_Summary_Send_Alert_Link_Text;
                },
                seriesClick: function (e) { self.onSeriesClick(e) }
            });*/

            
            self.refDomNode.find(".statuses-chart").kendoChart({
                transitions: false,
                title: {
                    visible: false
                },
                dataSource: new kendo.data.DataSource({ data: [] }),
                legend: {
                    visible: false
                },
                plotArea: { margin: 1 },
                chartArea: {
                    margin: 1,
                    background: "",
                    width: 262, 
                    /*height: 26*/
                },
                seriesDefaults: {
                    type: "donut",
                    startAngle: -90,
                    holeSize: 90,
                },
                series: [{
                    overlay: { gradient: "none" },
                    name: "Responses",
                    field: "value",
                    padding: 0
                }],
                tooltip: {
                    visible: true,                    
                    template: "#= category # : #= value # users",                                        
                },
                seriesHover: function () {
                    self.refDomNode.find(".statuses-chart").css("cursor", "pointer");
                },
                seriesClick: function (e) { self.onSeriesClick(e) }
            });            
        },

        onSeriesClick: function (e) {
            if (e.dataItem.statusId == -1) {
                // all responses
                this.onUserSelection({                    
                    response: "all"
                });
            } else {                
                this.onUserSelection({
                    status: e.dataItem.statusId,
                });
            }             
        },

        update: function (data) {
            var self = this;
            var statusModel = data.RuntimeModel.Status;
            self.model.responses([]);            
            statusModel.StatusByResponse.forEach($.proxy(function (response) {
                self.model.responses.push(response);                
            }));
            this.model.alertId(data.InitialAlertId);
            this.model.eventId(data.Id);
            this.model.isAllowedToUpdateStatus(data.IsAllowedToUpdateStatus && data.Status == utils.EventStatus.Live);
            this.model.isAlertPublisher(data.IsAlertPublisher);
            this.model.totalUsers(statusModel.TotalUsers);
            this.model.usersWithResponse(statusModel.UsersWithStatus.Value);
            this.model.usersWithResponsePercent(statusModel.UsersWithStatus.Percent);

            this.model.usersWithoutResponse(statusModel.UsersWithoutStatus.Value);         
            this.model.usersWithoutResponsePercent(statusModel.UsersWithoutStatus.Percent);

            this.model.responsesByUser(statusModel.ResponsesByUser.Value);
            this.model.responsesByUserPercent(statusModel.ResponsesByUser.Percent);

            this.model.responsesByOperator(statusModel.ResponsesByOperator.Value);
            this.model.responsesByOperatorPercent(statusModel.ResponsesByOperator.Percent);
                         
            /*var dataSource = $(".total-status-chart").data("kendoChart").dataSource;
            dataSource.data().empty();
            dataSource.data().push({
                statusId: -1,
                category: "Total Responses",
                value: statusModel.UsersWithStatus.Value,
                color: "green"
            });

            dataSource.data().push({
                statusId: 0,
                category: "No Status",
                value: statusModel.UsersWithoutStatus.Value,
                color: "#BBBBBB"
            });
            dataSource.sync();*/
                       
            $(".menu").kendoMenu({
                openOnClick: true,
            });

            var responsesDataSource = $(".statuses-chart").data("kendoChart").dataSource;
            responsesDataSource.data().empty();            
            statusModel.StatusByResponse.forEach($.proxy(function (response) {
                responsesDataSource.data().push({
                    category: response.Name,
                    value: response.Value.Value,
                    color: response.Color,
                    statusId: response.SortOrder,
                });
            }));

            responsesDataSource.data().push({
                category: "No Status",
                value: statusModel.UsersWithoutStatus.Value,
                color: "#BBBBBB",                
                statusId: 0
            });

            responsesDataSource.sync();            
        },

        //events
        onUserSelection: function (filter) { },
        onAlertSelection: function (filter) { },
        canRefresh: function () { return true; }, // a flag that can block UI from refreshing. i.e user is editing...

        //events
        onChange: function () { }, //fires when there is a change that requires refresh

    });

    return CreateEvent;
});