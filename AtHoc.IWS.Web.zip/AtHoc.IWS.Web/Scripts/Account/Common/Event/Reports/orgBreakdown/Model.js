﻿define([], function () {
    function Model(i18n) {
        var self = this;
        this.hierarchyContext = ko.observableArray([]);
        this.selectedItem = ko.observable();
        this.selectHierarchy = function () {
            self.onSelectHierarchy(this.Id);
        }

        // event
        this.onSelectHierarchy = function(id) {};
    }

    return Model;
});