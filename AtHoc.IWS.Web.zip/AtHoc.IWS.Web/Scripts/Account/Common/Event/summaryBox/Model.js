﻿define([], function () {
    function Model(i18n) {
        var self = this;
        this.totalUsers = ko.observable(0);
        this.usersWithResponse = ko.observable(0);
        this.usersWithResponsePercent = ko.observable(0);
        
        this.usersWithoutResponse = ko.observable(0);
        this.usersWithoutResponsePercent = ko.observable(0);

        this.responsesByUser = ko.observable(0);
        this.responsesByUserPercent = ko.observable(0);

        this.responsesByOperator = ko.observable(0);
        this.responsesByOperatorPercent = ko.observable(0);

        this.responses = ko.observableArray([]);
        this.alertId = ko.observable(0);
        this.eventId = ko.observable(0);
        this.isAllowedToUpdateStatus = ko.observable(0);
        this.isAlertPublisher = ko.observable(0);
        this.selectUsers = function () { };
    }

    return Model;
});