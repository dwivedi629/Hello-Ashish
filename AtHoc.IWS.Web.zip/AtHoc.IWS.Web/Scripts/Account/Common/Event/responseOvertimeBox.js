﻿define([    
    "account/Common/BaseView",
        "account/utils",
    "account/Event/responseOvertimeBox/Model",
    "vendors/text!account/Event/responseOvertimeBox/template.html",
], function (BaseView, utils, Model, template) {
    //constructor
    var AlertBox = function (refDomNode) {
        BaseView.call(this, refDomNode, template, Model, []);

        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
    };

    $.extend(AlertBox.prototype, {
        init: function () {
            var self = this;
            this.model.onAlertSelection = function(filter) {
                self.onAlertSelection(filter);
            }
                        
            this.dataSource = new kendo.data.DataSource({
                data: [],
                sort: {
                    field: "datetime",
                    dir: "asc"
                },
            });


            this.refDomNode.find(".response-overtime-chart").kendoChart({
                dataSource: new kendo.data.DataSource({ data: [] }),
                title: {
                    //text: "User Respones and Sent Alerts"
                
                },
                legend: {
                    position: "bottom"
                },
                series: [
                    {
                        type: "line",
                        width: 3,                        
                        //style: "smooth",
                        markers: {
                            visible: false
                        },
                        name: self.model.i18n.PA_Event_Details_Graph_Users_With_Status_Text,
                        color: "#00CC30",
                        field: "responses"
                    }, {                        
                        type: "column",
                        //stack: true,
                        name: self.model.i18n.PA_Event_Details_Graph_Alert_Targeted_Users_Text,
                        color: "#FFFFFF",
                        field: "targeted",                        
                        //spacing: 0,
                        //gap: 0                        
                    }
                ],
                valueAxes: [
                    {
                        title: { text: self.model.i18n.PA_Event_Details_Graph_Number_Of_Users_Text },

                        min: 0,
                        labels: {
                            format: "{0:n0}", // make sure no decimals
                            //template: "#= (value) #"
                        }
                    }
                ],
                chartArea: {
                    background: "#F5F5F5"
                },
                plotArea: {
                    background: "#F5F5F5"
                },
                categoryAxis: {
                    /*axis.Categories(model => model.Date);
                    axis.Axis.BaseUnit = ChartAxisBaseUnit.Minutes;
                    axis.Axis.BaseUnitStep = 10;
                    axis.Labels(label => label.Step(12));
                    axis.Axis.Min = DateTime.Parse( "2013-06-28 07:00:00" );
                    axis.Axis.Max = DateTime.Parse( "2013-06-28 20:00:00" );
                    axis.Axis.MajorGridLines.Visible = false;*/
                    /*majorTicks: {
                        majorTicks: {
                            step: 10
                        },
                    },*/
                    majorGridLines: { visible: false },
                    minorGridLines: { visible: false },
                    minorTicks: {
                        visible: false
                    },
                    majorTicks: {
                        visible: false
                    },
                    labels:
                    {
                        step: 1, // this is being overide in code
                        rotation: -90,
                        dateFormats:
                            {
                                //minutes: $.vpsDateTimeFormat,
                                minutes: self.model.i18n.PA_Date_Time_Format_MM_Text, // override by code
                                hours: self.model.i18n.PA_Date_Time_Format_HH_Text,
                                days: self.model.i18n.PA_Date_Time_Format_ddMM_Text,
                                months: self.model.i18n.PA_Date_Time_Format_MMMyy_Text,
                                years: self.model.i18n.PA_Date_Time_Format_yyyy_Text
                            }
                    },
                    type: "Date",
                    field: "datetime",
                    /*baseUnit and baseUnitStep make sure that we do not aggeagate, we cant aggregate alexs series*/
                    //baseUnit: "minutes",
                    //baseUnitStep: 1,                    
                    //baseUnitStep: "auto",
                    //baseUnit: "fit",
                    //maxDateGroups: 100,
                    /*autoBaseUnitSteps: {
                        //days: [3]
                    }*/
                },
                tooltip: {
                    visible: true,
                    format: "{0}%",
                    template: "#= dataItem.tooltip  #"
                },
                seriesClick: function (e) { self.onSeriesClick(e) }
            });
        },

        onSeriesClick: function (e) {
            var ser = e.series.name;
            var cat = e.category;
            var val = e.value;            
        },

        jsonTimeToDate: function (time) {
            //In order to keep compatibility with the output of moment#zone, a numeric input to moment#zone actually needs to be the negative of the string input.
            return new Date(moment(time).zone(-1 * $.vpsTimeZone.UtcOffsetInMinutes));            
        },

        utcDateToVpsTimeStr: function (time) {
            //In order to keep compatibility with the output of moment#zone, a numeric input to moment#zone actually needs to be the negative of the string input.
            return moment(time.getTime()).zone(-1 * $.vpsTimeZone.UtcOffsetInMinutes).format('YYYY-MM-DD HH:mm');            
        },

        update: function(data) {
            var self = this;
            var isLive = data.Status == utils.EventStatus.Live;
            var activityModel = data.RuntimeModel.Activity;
            var overtimeModel = data.RuntimeModel.Overtime;
            var statusModel = data.RuntimeModel.Status;

            this.model.sentAlertCount(activityModel.SentAlerts.length);
            this.model.pendingAlertCount(activityModel.PendingAlerts.length);            
            this.model.hasNextReminderAlert(isLive && activityModel.PendingAlerts.length > 0);
            this.model.nextAlertTime(this.model.hasNextReminderAlert() ? activityModel.PendingAlerts[0].CreatedOn : "");            

            var nowUtc = this.jsonTimeToDate(data.RuntimeModel.CurrentTimeUtc);
            var endEventDateUtc = this.jsonTimeToDate(data.EndDateUtc);
            var startDateUtc = this.jsonTimeToDate(data.StartDateUtc);

            var chart = $(".response-overtime-chart").data("kendoChart");

            if (data.RuntimeModel.Status.TotalUsers < 10) {
                chart.options.valueAxis.majorUnit = 1;
            }

            var durationInSeconds = (endEventDateUtc.getTime() - startDateUtc.getTime()) / 1000;
            var steps = 20;
            /*if (durationInSeconds < 600) { // if less than min, will switch to sec                
                chart.options.categoryAxis.labels.step = Math.floor(durationInSeconds / steps);
                chart.options.categoryAxis.baseUnit = "seconds";
            } else {*/
            // in minutes
            chart.options.categoryAxis.labels.step = Math.floor(durationInSeconds / 60 / steps);
            chart.options.categoryAxis.baseUnit = "minutes";
            //}
            chart.options.categoryAxis.baseUnitStep = 1;

            var minFormat = "HH:mm";
            var secFormat = "HH:mm:ss";
            if (endEventDateUtc.getDate() !== startDateUtc.getDate()) { // if not the same date (of month) make sure to add the day of the week  as well.
                minFormat = "ddd HH:mm";
                secFormat = "ddd HH:mm:ss";
            }
            chart.options.categoryAxis.labels.dateFormats.minutes = minFormat;
            chart.options.categoryAxis.labels.dateFormats.seconds = secFormat;

            // we add the half a step before and after to make sure the first alert is visible, and some later alerts are visible.
            var chartMaxDate = new Date(endEventDateUtc.getTime() + durationInSeconds * 1000 / steps);
            var chartMinDate = new Date(startDateUtc.getTime() - durationInSeconds * 1000 / steps);

            // Update
            var tooltipFormat = '{0}: {1}';
            var chartData = [];
            var maxUserCount = statusModel.TotalUsers;            
            activityModel.SentAlerts.forEach($.proxy(function(alert) {                
                if (!(alert.Status == 3 || alert.Status == 6)) {
                    // hide schedule alert etc... only life and ended.
                    return;
                }
                var d = self.jsonTimeToDate(alert.CreatedOnUtc);
                if (d < chartMinDate) {
                    // something is wrong
                    return;
                }

                if (d > chartMaxDate) {
                    // ssometmes alerts might be trigggered with delay
                    chartMaxDate = d;
                }
                
                chartData.push({
                    "targeted": alert.TargetedUsers,
                    "datetime": self.utcDateToVpsTimeStr(d),// d,
                    "tooltip": kendo.format(tooltipFormat, self.model.i18n.PA_Event_Details_Graph_Alert_Targeted_Users_Tooltip, alert.TargetedUsers)
                });
            }));

            // add the begining as 0:
            chartData.push({
                "responses": 0,
                "datetime": self.utcDateToVpsTimeStr(new Date(startDateUtc.getTime() - 60000)),
                "tooltip": kendo.format(tooltipFormat, self.model.i18n.PA_Event_Details_Graph_Users_With_Status_Tooltip, 0)
            });

            overtimeModel.StatusOverTime.forEach($.proxy(function (responseModel) {
                var d = self.jsonTimeToDate(responseModel.DateTimeUtc);
                if (d < chartMinDate || d > chartMaxDate) {
                    // something is wrong
                    return;
                }
                                      
                chartData.push({
                    "responses": responseModel.Value,
                    "datetime": self.utcDateToVpsTimeStr(d),
                    "tooltip": kendo.format(tooltipFormat, self.model.i18n.PA_Event_Details_Graph_Users_With_Status_Tooltip, responseModel.Value)
                });
            }));
            
            // add the current values:
            chartData.push({
                "responses": statusModel.UsersWithStatus.Value,
                "datetime": self.utcDateToVpsTimeStr(nowUtc < endEventDateUtc ? nowUtc : endEventDateUtc),
                "tooltip": kendo.format(tooltipFormat, self.model.i18n.PA_Event_Details_Graph_Users_With_Status_Tooltip, statusModel.UsersWithStatus.Value)
            });
                       
            // add half a step to the chart
            chart.options.categoryAxis.max = self.utcDateToVpsTimeStr(chartMaxDate);
            chart.options.categoryAxis.min = self.utcDateToVpsTimeStr(chartMinDate);            

            // set value axes:
            chart.options.valueAxis.min = 0;
            chart.options.valueAxis.max = maxUserCount + 1;
            // set the data
            chart.dataSource.data(chartData);
        },

        //events
        onUserSelection: function (filter) { },
        onAlertSelection: function (filter) { },
    });
    return AlertBox;
});