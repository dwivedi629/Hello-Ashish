﻿define([    
    "account/Common/BaseView",
    "account/utils",
    "account/Event/activity/model",
    "vendors/text!account/Event/activity/template.html",
    "account/Common/baseGridManager"
], function (BaseView, utils, Model, template, BaseGridManager) {
    //constructor
    var activityView = function (refDomNode, eventId) {
        BaseView.call(this, refDomNode, template, Model, []);
        this.eventId = eventId;
        var self = this;

        var gridDataProvider = {
            url: athoc.iws.account.urls.GetEventAlerts,
            urlOptions: { id: eventId }, 
            gridNode: this.refDomNode.find(".grid"),
            rowTemplateId: "activityRowEvent",
            selectAllCheckboxClass: "",
            selectionCheckboxClass: "",
            removeFixWidth: true,
            columns: function () {
                var columns = new Array();
                columns.push({
                    field: "Id",
                    hidden: true,
                });               
                
                columns.push({
                    field: " ",
                    width: "30px",
                    headerAttributes: { "title": self.model.i18n.PA_Event_Details_Activity_Error_Label },
                    sortable: false,
                });

                columns.push({
                    field: "Name",
                    headerTemplate: kendo.format('<div>{0}</div>', 'Alert Name'),
                    headerAttributes: { "class": "no-pointer", "title": self.model.i18n.PA_Event_Details_Activity_AlertName_Column_Header },
                    sortable: false,
                });

                columns.push({
                    field: "AlertType",
                    headerTemplate: kendo.format('<div>{0}</div>', 'Type'),
                    headerAttributes: { "class": "no-pointer", "title": self.model.i18n.PA_Event_Details_Activity_AlertType_Column_Header },
                    width: "140px",
                    sortable: false,                    
                });

                columns.push({
                    field: "Status",
                    headerTemplate: kendo.format('<div>{0}</div>', 'Status'),
                    headerAttributes: { "class": "no-pointer", "title": self.model.i18n.PA_Event_Details_Activity_Status_Column_Header },
                    width: "120px",
                    sortable: false,
                });

                columns.push({
                    field: "CreatedOn",
                    headerTemplate: kendo.format('<div>{0}</div>', 'Time Sent'),
                    headerAttributes: { "class": "no-pointer", "title": self.model.i18n.PA_Event_Details_Activity_TimeSent_Column_Header },
                    width: "180px",
                    sortable: false,
                });

                columns.push({
                    field: " ",
                    headerTemplate: kendo.format('<div>{0}</div>', 'Actions'),
                    headerAttributes: { "class": "no-pointer", "title": self.model.i18n.PA_Event_Details_Activity_Actions_Column_Header },
                    width: "140px",
                    sortable: false,
                }); 
                
                return columns;
            },
            schema: {
                /*parse: function (data) {
                    return self.setGridModel(data);
                },*/
                data: "Items",
                total: "TotalCount",                
            },

            onLoadData: function (data) {
                return self.setGridModel(data);
            },

            processData: function (item) {
                if (item.Status == 3) {
                    item.StatusStr = self.model.i18n.PA_Event_Details_Activity_Live_Label;
                } else if (item.Status == 6) {
                    item.StatusStr = self.model.i18n.PA_Event_Details_Activity_Ended_Label;
                } else {
                    if (item.ErrorCount > 0) {
                        item.StatusStr = self.model.i18n.PA_Event_Details_Activity_Queded_Error_Message;
                    } else {
                        item.StatusStr = self.model.i18n.PA_Event_Details_Activity_Queded_Label;
                    }                    
                }

                if (item.AlertEventType == "Start") {
                    item.AlertEventTypeStr = self.model.i18n.PA_Event_Details_Activity_StartAlert_Label;
                } else if (item.AlertEventType == "Reminder") {
                    item.AlertEventTypeStr = self.model.i18n.PA_Event_Details_Activity_ReminderAlert_Label;
                } else {
                    item.AlertEventTypeStr = self.model.i18n.PA_Event_Details_Activity_EndingAlert_Label;
                }

                item.ShowDate = (item.ErrorCount > 0 || item.IsNextAlert || item.Status == 1 || item.Status == 3 || item.Status == 6);
                item.ShowLinkToAlert = (item.Status == 1 || item.Status == 3 || item.Status == 6);
                item.ShowSendAction = false;//item.IsNextAlert;
                item.ViewAlert = self.model.i18n.PA_Event_Details_Activity_ViewAlert_Link_Text;
                item.StartNow = self.model.i18n.PA_Event_Details_Activity_Send_Link_Text;
                item.TotalMessage = self.model.i18n.PA_Event_Details_Activity_TotalAlert_Initial_Text;
                item.ScheduledAlerts = self.model.i18n.PA_Event_Details_Activity_TotalAlert_Later_Text;
            },            

            getClickClassHandlers: function () {
                var self = this;
                return [
                    {
                        cssClass: "view-alert-selectable",
                        handler: $.proxy(function (item) {                            
                            utils.loadAlertPage(item.AlertId);
                        })
                    },
                    {
                        cssClass: "edit-alert-selectable",
                        handler: $.proxy(function (item) {
                            utils.loadAlertPage(item.AlertId);
                        })
                    },

                ];
            },
            // Paging/Sorting flags
            serverSideSort: false,
            serverSidePagination: false
        }
        

        BaseView.call(gridDataProvider, "", null, null, []);

        var strings =
        {
            entityNameSingle: "Alert",
            entityNamePlural: "Alerts",
        };

        this.baseGridManager = new BaseGridManager(gridDataProvider, null, null, null, null, strings, null, null, true,true);
        this.baseGridManager.startup();
    };

    $.extend(activityView.prototype, {
        setGridModel: function (data) {
            var items = $.merge($.merge([], data.SentAlerts), data.PendingAlerts);
            data.Items = items;
            data.TotalCount = items.length;

            this.model.showPendingAlertsMessage(data.PendingAlerts > 1);
            this.model.numberOfPendingAlerts(data.PendingAlerts);

            return data;
        },

        update: function (data) {
            this.setGridModel(data.RuntimeModel.Activity);
            this.baseGridManager.setLocalDataSource(data.RuntimeModel.Activity);
        },

        onShow: function () {
            // do something...
            this.baseGridManager.refreshGrid();
        },

        canRefresh: function () { return true }, // a flag that can block UI from refreshing. i.e user is editing...

        //events
        onUserSelection: function (filter) { },
        onAlertSelection: function (filter) { },
        onChange: function () { }, //fires when there is a change that requires refresh                              
    });
    return activityView;
});