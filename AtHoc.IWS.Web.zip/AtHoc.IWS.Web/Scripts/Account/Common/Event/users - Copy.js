﻿define([
    "account/Common/BaseView",
	"account/utils",
    "account/Event/users/model",
    "vendors/text!account/Event/users/template.html",
    "publishing/UserList/UserList",
     "widget/UserInfo",
     "account/Common/dialog",
], function (BaseView, utils, Model, template, UserList, UserInfo, Dialog) {
    //constructor
    var usersView = function (refDomNode, id) {
        BaseView.call(this, refDomNode, template, Model, []);
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };

        this.isActive = false;

        var options = {
            srcRefNode: this.refDomNode.find('.user-listing'),
            userPageLayout: "FromUserManager",
            resourceStrings: userListResources,
            Urls: userListUrls,
            width: '100%',
            eventId: id,
            groupRefNode: this.refDomNode.find('.group-search-popup-container'),
            queryRefNode: this.refDomNode.find('.query-search-popup-container'),
            hierarchyRefNode: this.refDomNode.find('.hierarchy-selector-popup-container'),
            isGroupEnabled: true,
            isAdvanceSearchEnabled: true,
        }

        this.ph = new UserList(options, UserInfo, this);
        this.searchStrings = [];
        this.selectedStatus;
        this.ph.on("ready", function () {

        });
        this.queryCriteria = [];
        this.listItemIds = [];
    };

    $.extend(usersView.prototype, {
        init: function () {
            var self = this;
            // butttons
            var navigationModel = {
                sections: [
                    {
                        dataPage: "",
                        actions: [
                            { id: "close", text: self.model.i18n.PAEvent_Cancel, primary: false, click: function () { self.dialog.hideDialog(); } },
                            { id: "confirm", text: self.model.i18n.PAEvent_Apply, primary: true, click: function () { self.onStatusDlgApply(); } },
                        ]
                    }
                ]
            };

            this.dialog = new Dialog(navigationModel, "", "");

            this.dialog.startup();

            this.dialog.setBodyNode(this.refDomNode.find('.change-status-dlg-content'));
            this.dialog.setTitleNode(this.refDomNode.find('.change-status-dlg-title'));
        },

        update: function (data) {
            this.ph.eventStatus = data.Status;
            this.ph.isAllowedToUpdateStatus = data.IsAllowedToUpdateStatus;
            this.ph.startUp();
        },

        onShow: function () {
            this.isActive = true;
        },
        onChangeStatus: function (filter) {
            if (!filter) {
                filter = {};
            }
            this.filter = filter;
            this.model.filterStr(JSON.stringify(filter));
            this.ph.changeStatus(filter);
            this.isActive = true;
        },

        onHide: function () {
            this.isActive = false;
        },

        //Gets the selected filter to the Export Dailog
        selectedFilter: function () {
            var self = this;
            var selectedFilterId = self.ph.filterType;
            var rType = self.ph.responseTypes;
            rType.push({ ValueId: -1, ValueName: self.model.i18n.PA_Any_Status_Item_Text, SortOrder: -1 });
            rType.push({ ValueId: 0, ValueName: self.model.i18n.PA_No_Status_Item_Text, SortOrder: 0 });
            var selectedFilter = _.find(rType, function (i) {
                return i.SortOrder == selectedFilterId;
            });
            if (selectedFilter != null)
                this.selectedStatus = selectedFilter.ValueId;
            this.searchStrings = self.ph.searchString;
        },

        getAllResponseTypes: function () {
            var self = this;
            self.model.responseId(self.ph.responseId);
            self.model.responseTypes(self.ph.responseTypes);
            //self.selectedFilter();
        },

        onUserSelectionChange: function (count) {
            this.onEnableDisableChangeStatus(count > 0);
            this.model.userCount(count);
        },

        onStatusDlgApply: function () {
            var self = this;
            var selectedUserIds = self.ph.selectedUsers;
            var seletedIds = [];
            selectedUserIds.forEach(function (selecteditem) {
                seletedIds.push(selecteditem.UserId);
            });
            var attributeId;
            var selectedValueId;
            //Getting tthe selected valus id.
            $("[name='rbResponseTypes']").each(function () {
                if (this.checked) {
                    selectedValueId = this.value;
                    var uAttribute = _.find(self.model.responseTypes(), function (i) {
                        return i.ValueId == selectedValueId;
                    });
                    attributeId = uAttribute.AttributeId;
                }
            });

            var statusComments = $(".status-comments").val();
            if (attributeId == "" || attributeId == 0 || attributeId == undefined) {
                $(".save-message-panel", self.dialog.refDomNode).messagesPanel({ messages: [{ Type: '4', Value: self.model.i18n.PA_Select_Status_Error_Message }] }, null);
                return true;
            } else {
                var userStatus = { ids: seletedIds, attributeId: attributeId, valueId: selectedValueId, comments: statusComments };
                var loadUrl = athoc.iws.account.urls.UpdateEventUsersStatus;
                utils.makeAjaxCall(loadUrl, userStatus, $.proxy(function (data) {
                    self.dialog.hideDialog();
                    self.ph.selectedUsers.length = 0;
                    self.ph.createGrid();
                    self.ph.responseId = -1;
                    self.ph.comments = "";
                    self.onUserSelectionChange(0);
                    self.onChange();
                }), $.proxy(function () {
                    $(".save-message-panel", self.dialog.refDomNode).messagesPanel({ messages: [{ Type: '4', Value: self.model.i18n.PA_Failed_Status_Error_Message }] }, null);
                }));
            }
        },

        showDialog: function () {
            var self = this;
            self.getAllResponseTypes();
            self.model.userCount("(" + self.ph.selectedUsers.length + ")");
            if (self.ph.comments != undefined && self.ph.comments != "")
                self.model.comments(self.ph.comments);
            else
                self.model.comments("");
            this.dialog.showDialog();
            $(".save-message-panel", this.dialog.refDomNode).hide();
        },

        // a flag that can block UI from refreshing. i.e user is editing...
        canRefresh: function () {
            return !this.isActive;
        },

        // events!!!
        onEnableDisableChangeStatus: function (enable) { },
        onChange: function () { }, //fires when there is a change that requires refresh
    });
    return usersView;
});