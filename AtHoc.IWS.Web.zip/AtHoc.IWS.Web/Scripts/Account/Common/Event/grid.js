﻿
define([
    "account/Common/BaseView",
    "vendors/text!account/Event/grid/template.html",
    "account/Event/grid/Model",
    "account/utils",
], function (BaseView, template, Model, utils) {
    var grid = function (gridNode) {
        BaseView.call(this, $(":root"), template, Model, []);
        this.gridNode = gridNode;
    };

    $.extend(grid.prototype, {
        gridNode: this.gridNode,
        rowTemplateId: "rowEvent",
        selectAllCheckboxClass: "grid-select-all",
        selectionCheckboxClass: "grid-item-select",
        columns: function () {
            var columns = new Array();
            columns.push({
                field: "Id",
                hidden: true,
            });
            
            columns.push({
                field: "IsChecked",
                width: 40,
                headerTemplate: kendo.format('<div align="center"><input type="checkbox" class="grid-select-all" title="{0}"/></div>', 'Select All'),
                sortable: false,
                headerAttributes: { "class": "no-pointer" }
            });
            
            columns.push({
                field: "Name",
                headerTemplate: this.model.i18n.PA_Event_Manager_EventTitle,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Event_Manager_EventTitle },
                width: 240,
            });

            columns.push({
                field: "Status",
                headerTemplate: this.model.i18n.PA_Event_Manager_Status,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Event_Manager_Status },
                width: 80,
            });

            columns.push({
                field: "CreatedOn",
                headerTemplate: this.model.i18n.PA_Event_Manager_StartTime,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Event_Manager_StartTime },
                width: 140,
            });

            columns.push({
                field: "StartedByName",
                headerTemplate: this.model.i18n.PA_Event_Manager_StartedBy,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Event_Manager_StartedBy },
                width: 100,
            });

            columns.push({
                field: "Affected",
                headerTemplate: this.model.i18n.PA_Event_Manager_AffectedUsers,
                sortable: false,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Event_Manager_AffectedUsers_Tooltip },
                width: 60,
            });

            columns.push({
                title: this.model.i18n.PA_Event_Manager_HaveStatus,
                sortable: false,
                attributes: { "class": "align-center" },
                headerAttributes: { style: "cursor: default" },
                width: 110,
            });

            return columns;
        },
        schema: {
            data: "Items",
            total: "TotalCount",
            model: {
                fields: {
                    Id: { type: "int" },
                    Name: { type: "string" },
                    Status: { type: "string" },
                    StartTime: { type: "string" },
                    CreatedBy: { type: "string" },
                    CreatedByName: { type: "string" },
                    CreatedOn: { type: "string" },
                    StartedBy: { type: "string" },
                    StartedByName: { type: "string" },
                    Affected: { type: "int" }
                }
            }
        },

        sort: {
            field: "CreatedOn",
            dir: "desc"
        },

        processData: function (item) {
            item.ResponseColumnTooltip = kendo.format(
                "{0} {1} {2} {3}",
                item.UsersResponded,
                this.model.i18n.PA_Event_Manager_Tooltip_Users,
                item.Affected,
                this.model.i18n.PA_Event_Manager_Tooltip_Users_2);
        },

        url: athoc.iws.account.urls.GetEvents,
        urlOptions: {}, // todo: add params

        getClickClassHandlers: function () {
            var self = this;
            return [
                {
                    cssClass: "event-selectable",
                    handler: $.proxy(function (item) {
                        utils.loadEventPage(item.Id);
                    })
                },                
            ];
        },

        // events
        select: function (id) { },

        // Paging/Sorting flags
        serverSideSort: true,
        serverSidePagination: true,

        //dataBound event handler
        onDataBound: function (e) {
            //var id = "#" + this.gridNode;
            var grid = this.gridNode.data("kendoGrid");
            this.gridNode.find(".chart").each(function () {
                var chartContainer = $(this);
                var tr = chartContainer.closest('tr');
                var model = grid.dataItem(tr);
                chartContainer.kendoChart({
                    chartArea: {
                        width: 50,
                        height: 50,
                        background: "",
                    },
                    theme: "flat",
                    series: [
                        {
                            type: "donut",
                            startAngle: 270,
                            holeSize: 18,
                            data: [
                                {
                                    category: "Users Responded",
                                    value: model.UsersResponded,
                                    color: "#00cc03"
                                },
                                {
                                    category: "Users Not Responded",
                                    value: model.UsersNotResponded,
                                    color: "#eeeeee"
                                }
                            ]
                        }
                    ],
                    legend: {
                        visible: false
                    },
                    tooltip: {
                        visible: true,
                        template: "#: category  #: #: value #"
                    },
                });
                $(tr).find(".inner-content").html(kendo.format("{0:n0}%", model.Affected > 0 ? (model.UsersResponded / model.Affected) * 100 : 0));
            });
        }
    });

    // upgly
    /*athoc.iws.accoutability.template.grid = function() {

    };*/

    return grid;
});
