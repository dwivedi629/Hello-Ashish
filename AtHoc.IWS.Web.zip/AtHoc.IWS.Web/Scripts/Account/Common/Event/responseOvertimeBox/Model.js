﻿define([], function () {
    function Model() {
        var self = this;
        this.sentAlertCount = ko.observable();
        this.pendingAlertCount = ko.observable();        

        this.hasNextReminderAlert = ko.observable(true);
        this.nextAlertTime = ko.observable();
        /*this.nextAlertValue = ko.observable();
        this.nextAlertUnit = ko.observable("");*/

        this.sentAlertClicked = function() {
            this.onAlertSelection();
        }

        this.pendingAlertClicked = function () {
            this.onAlertSelection();
        }

        //events
        this.onAlertSelection = function() {};
    }

    return Model;
});