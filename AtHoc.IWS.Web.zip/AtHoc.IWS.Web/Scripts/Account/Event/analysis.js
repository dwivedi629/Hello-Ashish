﻿define([    
    "common/baseView",
    "account/Event/analysis/Model",
    "dojo/text!account/Event/analysis/template.html",
    "account/Event/Reports/orgBreakdown"
], function (BaseView, Model, template, OrgBreakdown) {
    //constructor
    var analysisView = function (refDomNode, dashboardConfig, params) {
        BaseView.call(this, refDomNode, template, Model, []);
        this.dashboardConfig = dashboardConfig;        
        this.params = params;
        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
    };

    $.extend(analysisView.prototype, {
        init: function () {
            var self = this;
            this.orgBreakdown = new OrgBreakdown(this.refDomNode.find(".org-report"), this.dashboardConfig.Ids);
            this.orgBreakdown.startup();

            this.orgBreakdown.on("onUserSelection", function (filter) {
                self.onUserSelection(filter);
            });

            this.orgBreakdown.on("onAlertSelection", function (filter) {
                self.onAlertSelection(filter);
            });
        },
        update: function (data) {
            this.orgBreakdown.update(data);
        },

        canRefresh: function () { return true }, // a flag that can block UI from refreshing. i.e user is editing...

        //events
        onUserSelection: function (filter) { },
        onAlertSelection: function (filter) { },
        onChange: function () { } //fires when there is a change that requires refresh
    });
    return analysisView;
});