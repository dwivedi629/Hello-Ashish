﻿
define([
    "common/baseView",
    "dojo/text!account/Event/grid/template.html",
    "account/Event/grid/Model",
    "account/utils"
], function (BaseView, template, Model, utils) {
    var grid = function (gridNode, options) {
        BaseView.call(this, $(":root"), template, Model, []);
        this.gridNode = gridNode;

        var defaultOptions = {
            sortable: true,
            isStatic: false,
            showSelectionCol: true,
            showStartTimeCol: true,
            showEndTimeCol: false,
            showStartedBy: true,
            showStatusAttrName: true
    }
        this.options = $.extend(defaultOptions, options);
    };

    $.extend(grid.prototype, {        
        gridNode: this.gridNode,
        rowTemplateId: "rowEvent",
        selectAllCheckboxClass: "grid-select-all",
        selectionCheckboxClass: "grid-item-select",
        columns: function () {
            var columns = new Array();
            columns.push({
                field: "Id",
                hidden: true
            });

            if (IsPAManagerRole) {
                columns.push({
                    field: "IsChecked",
                    width: 40,
                    headerTemplate: kendo.format('<div align="center"><input type="checkbox" class="grid-select-all" title="{0}"/></div>', 'Select All'),
                    sortable: false,
                    hidden: !this.options.showSelectionCol,
                    headerAttributes: { "class": "no-pointer" }
                });
            }
            
            columns.push({
                sortable: this.options.sortable,
                field: "Name",
                headerTemplate: this.model.i18n.PA_Event_Manager_EventTitle,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Event_Manager_EventTitle },
                width: 240
            });

            columns.push({
                sortable: this.options.sortable,
                field: "Status", // The actual values shown is LocalizedStatus IWS-28860
                headerTemplate: this.model.i18n.PA_Event_Manager_Status,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Event_Manager_Status },
                width: 80
            });

            columns.push({
                sortable: this.options.sortable,
                field: "StartedOn",
                headerTemplate: this.model.i18n.PA_Event_Manager_StartTime,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Event_Manager_StartTime },
                width: 140
            });

            /*columns.push({
                field: "StartedByName",
                headerTemplate: this.model.i18n.PA_Event_Manager_StartedBy,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Event_Manager_StartedBy },
                width: 100
            });*/
        // This feature is moved to 92 release so commenting it for now
           columns.push({
                field: "ProviderName",
                headerTemplate: this.model.i18n.PA_Event_Details_Analysis_VpsHierarchy,//"Organization",
                sortable: false,
                attributes: { "class": "align-center" },
                headerAttributes: { style: "cursor: default" },
                width: 110,
                hidden: false
            }); 
            columns.push({
                field: "Affected",
                headerTemplate: this.model.i18n.PA_Event_Manager_AffectedUsers,
                sortable: false,
                headerAttributes: { "class": "no-pointer", "title": this.model.i18n.PA_Event_Manager_AffectedUsers_Tooltip },
                width: 60
            });

            columns.push({
                title: this.model.i18n.PA_Event_Manager_HaveStatus,
                sortable: false,
                attributes: { "class": "align-center" },
                headerAttributes: { style: "cursor: default" },
                width: 120
            });

            return columns;
        },
        schema: {
            data: "Items",
            total: "TotalCount",
            model: {
                fields: {
                    ProviderId: { type: "int" },
                    Id: { type: "int" },
                    Name: { type: "string" },
                    Status: { type: "string" },
                    StartTime: { type: "string" },
                    CreatedBy: { type: "string" },
                    CreatedByName: { type: "string" },
                    CreatedOn: { type: "string" },
                    StartedBy: { type: "string" },
                    //StartedByName: { type: "string" },
                    Affected: { type: "int" },
                    // This feature is moved to 92 release so commenting it for now
                    ProviderName: { type: "string" },
                    IncludeSubVps: { type: "bool" }
                }
            }
        },

        sort: {
            field: "CreatedOn",
            dir: "desc"
        },

        processData: function (item) {
            item.options = this.options;
            item.showSelectionCol = false;
            item.ResponseColumnTooltip = kendo.format(
                "{0} {1} {2} {3}",
                item.UsersResponded,
                this.model.i18n.PA_Event_Manager_Tooltip_Users,
                item.Affected,
                this.model.i18n.PA_Event_Manager_Tooltip_Users_2);
            item.IncludeSubVps = this.model.IncludeSubVps();
        },

        url: athoc.iws.account.urls.GetEvents,
        urlOptions: {
            NameString: "",
            Severity: "",
            Status: "",
            OperatorId: "",
            AttributeId: "",
            VpsId: 0,
            IncludeSubVps: false,
            StartDate: "",
            EndDate: "",
            DebugFlag: 0
        },

        getClickClassHandlers: function () {
            var self = this;
            if (this.options.isStatic) {
                return [];
            }
            return [
                {
                    cssClass: "event-selectable",
                    handler: $.proxy(function (item) {
                        utils.loadEventPage(item.Id, item.ProviderId);
                    })
                }
            ];
        },

        // events
        select: function (id) { },

        // Paging/Sorting flags
        serverSideSort: true,
        serverSidePagination: true,

        //dataBound event handler
        onDataBound: function (e) {
            //var id = "#" + this.gridNode;
            var grid = this.gridNode.data("kendoGrid");

            this.gridNode.find(".chart").each(function () {
                var chartContainer = $(this);
                var tr = chartContainer.closest('tr');
                var model = grid.dataItem(tr);
                chartContainer.kendoChart({
                    chartArea: {
                        width: 50,
                        height: 50,
                        background: ""
                    },
                    theme: "flat",
                    series: [
                        {
                            type: "donut",
                            startAngle: 270,
                            holeSize: 18,
                            data: [
                                {
                                    category: "Users Responded",
                                    value: model.UsersResponded,
                                    color: "#00cc03"
                                },
                                {
                                    category: "Users Not Responded",
                                    value: model.UsersNotResponded,
                                    color: "#eeeeee"
                                }
                            ]
                        }
                    ],
                    legend: {
                        visible: false
                    },
                    tooltip: {
                        visible: true,
                        template: "#: category  #: #: value #"
                    }
                });
                $(tr).find(".inner-content").html(kendo.format("{0:n0}%", model.Affected > 0 ? (model.UsersResponded / model.Affected) * 100 : 0));
            });

            var providerColumnIndex = 0;
            for (i = 0; i < grid.columns.length; i++) {
                if (grid.columns[i].field == "ProviderName") {
                    providerColumnIndex = grid.columns.indexOf(grid.columns[i]);
                }
            }

            if (!this.model.IncludeSubVps()) {
                grid.hideColumn(grid.columns[providerColumnIndex]);
            } else
                grid.showColumn(grid.columns[providerColumnIndex]);
        },

        removeSelectedEntities: function (seletedIds, successCallback, failCallback) {
            var loadUrl = "/athoc-iws/account/RemoveEvent";
            utils.removeEntities(seletedIds, successCallback, failCallback, loadUrl);
        }
    });


    // upgly
    /*athoc.iws.accoutability.template.grid = function() {

    };*/

    return grid;
});
