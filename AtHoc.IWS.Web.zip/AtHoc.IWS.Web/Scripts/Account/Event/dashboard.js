﻿define([
    "common/baseView",
    "account/utils",
    "account/Event/dashboard/Model",
    "dojo/text!account/Event/dashboard/template.html",
    "account/Event/summaryBox",
    "account/Event/responseOvertimeBox"
], function (BaseView, utils, Model, template, SummaryBox, AlertBox) {
    //constructor   
    var dashboard = function (refNode, eventViewConfig, params) {
        this.eventViewConfig = eventViewConfig;
        BaseView.call(this, refNode, template, Model, []);

        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
    };

    $.extend(dashboard.prototype, {
        init: function () {
            var self = this;
            this.summaryBox = new SummaryBox(this.refDomNode.find(".summary-box"));
            this.summaryBox.startup();
            this.summaryBox.on("onUserSelection", function (filter) {
                self.onUserSelection(filter);
            });
            this.summaryBox.on("onAlertSelection", function (filter) {
                self.onAlertSelection(filter);
            });

            this.alertBox = new AlertBox(this.refDomNode.find(".alert-box"));
            this.alertBox.startup();
            this.alertBox.on("onUserSelection", function (filter) {
                self.onUserSelection(filter);
            });
            this.alertBox.on("onAlertSelection", function (filter) {
                self.onAlertSelection(filter);
            });
        },

        update: function (data) {
            this.summaryBox.update(data);
            this.alertBox.update(data);
        },

        getModel: function () {
            return {};
        },

        canRefresh: function () { return true }, // a flag that can block UI from refreshing. i.e user is editing...

        //events
        onUserSelection: function (filter) { },
        onAlertSelection: function (filter) { },
        onChange: function () { } //fires when there is a change that requires refresh
    });
    return dashboard;
});