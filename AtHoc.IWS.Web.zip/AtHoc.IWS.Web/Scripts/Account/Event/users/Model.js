﻿define([], function () {
    function Model() {
        var self = this;
        this.filterStr = ko.observable("");
        this.responseTypes = ko.observableArray([]);
        this.userCount = ko.observable(0);
        this.responseId = ko.observable();
        this.selectedFilter = [];
        this.comments = ko.observable();
    }

    return Model;
});