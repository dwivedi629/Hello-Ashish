﻿define([
    "common/baseView",
    "account/utils",
    "account/Event/details/Model",
    "dojo/text!account/Event/details/template.html",
    "account/Event/dashboard",
    "account/Event/users",
    "account/Event/analysis",
    "account/Event/settings",
    "account/Event/activity",
    "common/navigation",
    "common/tabs",
    "account/Export/exportDialog",
    "common/confirmationDialog",
    "account/Event/eventEndTimeDialog"
], function (BaseView, utils, Model, template, DashboardView, UsersView, AnalysisView, SettingsView, ActivityView, NavigationView, TabsControl, ExportDialog, ConfirmationDialog, EventEndTimeDialog) {
    //constructor 
    var eventDetails = function (refNode, navigationRefNode, dashboardConfig, eventSettingParams, selectedTab) {
        this.base = BaseView.call(this, refNode, template, Model, []);
        this.eventSettingParams = eventSettingParams;
        this.dashboardConfig = dashboardConfig;
        this.resources = userListResources;
        this.selectedTab = selectedTab;
        var self = this;
        this.navigationRefNode = navigationRefNode;
        this.controlById = [];
        this.responseOptionId = 0;
        this.exportDialog = null;
        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
        this.requireRefresh = false;
        this.canRefresh = true;
    };

    $.extend(eventDetails.prototype, {
        loadData: function () {
            // need to abstruct this:            
            var self = this;
            var loadUrl = athoc.iws.account.urls.GetEventsReport;
             var postData = {                    
                    ids: self.dashboardConfig.Ids,
                    Type: self.dashboardConfig.Type,
                    Name: self.dashboardConfig.Name,
                    Description: self.dashboardConfig.Description,
                    StatusAttributeId: self.dashboardConfig.StatusAttributeId,
                    SessionId: self.eventModel == undefined ? 0 : self.eventModel.SessionId
                };
             utils.makeAjaxCall(loadUrl, postData, $.proxy(function (data) {
                self.update(data);
            }), $.proxy(function (e) {
                $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.Messages }] });
            }));
        },

        init: function () {
            var self = this;
            self.loadData();

            this.changeStatusSection = $.proxy(function () {
                $(".btn-info", self.controlById[self.tabNames.users].dialog.refDomNode).eq(0)[0].lastChild.nodeValue = self.model.i18n.PA_Event_Manager_Cancel;
                self.controlById[self.tabNames.users].showDialog();
            });

            this.changeEndTime = $.proxy(function () {
                self.eventEndTimeDialog = new EventEndTimeDialog({ id: self.eventModel.RuntimeModel.EventModel.Id, endTime: this.model.endDate() });
                self.eventEndTimeDialog.startup();
                self.eventEndTimeDialog.showDialog();
                self.eventEndTimeDialog.on("successCallback", function (e) {
                    self.model.endDate(e);
                    self.eventModel.RuntimeModel.EventModel.EndDate = e;
                    self.controlById[self.tabNames.setting].update(self.eventModel);
                    self.showSuccessMessage(self.model.i18n.PAEvent_ChangeEndTime_Success);
                });
                self.eventEndTimeDialog.on("errorCallback", function () {
                    self.showErrorMessage(self.model.i18n.PAEvent_ChangeEndTime_Error);
                });
            });

            this.model.refresh = $.proxy(function () {
                self.loadData();
            });

            this.showChangeStatus = function (show) {
                this.navigationView.getAction("export").visible(show);
            };
            this.enableChangeStatus = function (enable) {
                //IWS-29115
                if (self.controlById[self.tabNames.users].ph.selectedUsers.length > 0) {
                    if (self.model.isLive() && self.model.isAllowedToUpdateStatus())
                        enable = true;
                    else
                        enable = false;
                }
                this.navigationView.getAction("export").enable(enable);
            };

            this.navigationModel = {
                sections: [
                    {
                        dataPage: "dashboard",
                        actions: [
                            {
                                id: "end-event",
                                visible: IsPAManagerRole,
                                click: $.proxy(function () {
                                    self.confirmationDialog = new ConfirmationDialog(self.model.i18n.PA_Event_Manager_End);
                                    self.confirmationDialog = new ConfirmationDialog({ confirmButtonText: self.model.i18n.PA_Event_Manager_End, cancelButtonText: resources.PA_Event_Cancel_Button });

                                    self.confirmationDialog.showConfirmationMessage(
                                        kendo.format(self.model.i18n.PA_Event_Manager_EndEvent),
                                        kendo.format(self.model.i18n.PA_Event_Manager_EndEventConfirmation),
                                        kendo.format("{0}", [self.eventModel.RuntimeModel.EventModel.Name]),
                                        function () {
                                            var successCallback = function () {
                                                self.confirmationDialog.hideConfirmationMessage();
                                                self.showSuccessMessage(self.model.i18n.PA_Event_Details_EndEventMessage_Success);
                                                self.setRefreshTimer();
                                                self.loadData();
                                            };

                                            var failCallback = function () {
                                                self.confirmationDialog.hideConfirmationMessage();
                                                self.showErrorMessage(self.model.i18n.PA_Event_Details_EndEventMessage_Failure);
                                            };

                                            utils.endEvents([self.eventModel.RuntimeModel.EventModel.Id], successCallback, failCallback);
                                        });
                                }), text: this.model.i18n.PA_Event_Details_EndEvent, promoted: true, enable: false
                            },
                            {
                                visible: IsPAManagerRole,
                                id: "change-end-time",
                                click: $.proxy(function () {
                                    self.changeEndTime();
                                }), text: this.model.i18n.PAEvent_ChangeEndTime_ModalTitle, enable: false
                            },
                            {
                                id: "exportEvent",
                                click: $.proxy(function () {
                                    self.exportDialog.updateDialogTitle(self.model.i18n.PA_Event_Export_Dialog_Title + " - " + self.eventModel.RuntimeModel.EventModel.Name);
                                    self.exportDialog.updateHrchyFilters(self.controlById[self.tabNames.analysis].orgBreakdown);
                                    self.exportDialog.updateUserFilters(self.controlById[self.tabNames.users]);
                                    self.exportDialog.showDialog();
                                }), text: this.model.i18n.PA_Event_Details_Export
                            },
                            {
                                id: "export",
                                click: $.proxy(function () {
                                    self.changeStatusSection();
                                }), text: userListResources.PAEvent_ChangeStatus_Button, primary: true, enable: false
                            }
                        ]
                    }
                ]
            };
           
            this.navigationView = new NavigationView(this.navigationRefNode, this.navigationModel, { moreActionsLinkText: this.model.i18n.PA_Event_Summary_More_Actions_Link_Text});
            this.navigationView.startup();

            this.tabsModel = [
                { id: this.tabNames.dashboard, Name: this.model.i18n.PA_Event_Details_Summary },
                { id: this.tabNames.users, Name: this.model.i18n.PA_Event_Details_Users },
                { id: this.tabNames.analysis, Name: this.model.i18n.PA_Event_Details_Analysis },
                { id: this.tabNames.activity, Name: this.model.i18n.PA_Event_Details_Activity },
                { id: this.tabNames.setting, Name: this.model.i18n.PA_Event_Details_Details }
            ];

            this.tabsControl = new TabsControl(this.refDomNode.find(".event-tabs"), this.tabsModel);
            this.tabsControl.startup();

            this.tabsControl.on("onSelect", function (prevSelecededTabName, selectedTabName, params, filter) {
                //var tabView = self.controlById[selectedTabName];
                if (prevSelecededTabName !== selectedTabName) {
                    var prevTabView = self.controlById[prevSelecededTabName];
                    if (prevTabView && prevTabView.onHide) {
                        prevTabView.onHide();
                    }

                    var tabView = self.controlById[selectedTabName];
                    if (tabView && tabView.onShow) {
                        tabView.onShow();

                    }
                }

                self.showChangeStatus(false);
                if (selectedTabName == self.tabNames.users) {

                    if (self.model.isLive() && self.model.isAllowedToUpdateStatus())
                    self.showChangeStatus(true);
                    if (filter != undefined) {
                        var view = self.controlById[selectedTabName];
                        view.onChangeStatus(filter);
                    }
                }

                if (self.requireRefresh) {
                    self.loadData();
                }
            });
            this.tabsControl.on("onShow", function (prevSelecededTabName, selectedTabName, params) {
                if (selectedTabName == self.tabNames.setting) {
                    var tabView = self.controlById[selectedTabName];
                    tabView.onVisible();
                }
            });
            this.eventSettingParams.IsCurrentVps = this.model.IsCurrentVps();
            this.createTabControl(this.tabNames.dashboard, DashboardView, { IsCurrentVps: this.model.IsCurrentVps() });
            this.createTabControl(this.tabNames.users, UsersView, { IsCurrentVps: this.model.IsCurrentVps() });
            this.createTabControl(this.tabNames.analysis, AnalysisView, { IsCurrentVps: this.model.IsCurrentVps() });
            this.createTabControl(this.tabNames.activity, ActivityView, { IsCurrentVps: this.model.IsCurrentVps() });
            this.createTabControl(this.tabNames.setting, SettingsView, this.eventSettingParams);

			this.controlById[this.tabNames.users].on("onEnableDisableChangeStatus", function (enable) {
                self.enableChangeStatus(enable);
            });

            this.tabsControl.select(this.tabNames.dashboard);			
			//initialize exporDialog once we have responseOptionId
            self.exportDialog = new ExportDialog(self.dashboardConfig.Ids[0]);
            self.exportDialog.startup();
            var breadcrumbModel = new BreadcrumbModel();
            //Page breadcrumb
            var pageBreadCrumb = new PageBreadcrumb('eventList', this.model.i18n.PA_Event_Manager_EntityNamePlural, [], '');
            var listBreadCrumb = new Breadcrumb('eventList', this.model.i18n.PA_Event_Manager_EntityNamePlural, '', function () {
                utils.loadEventsPage();
            });

            this.detailPageBreadCrumb = new PageBreadcrumb('eventPage', '', [listBreadCrumb], '');
            breadcrumbModel.addPage(pageBreadCrumb);
            breadcrumbModel.addPage(this.detailPageBreadCrumb);

            // bind breadcrumb
            breadcrumbModel.SelectedPage('eventPage');
            ko.applyBindings(breadcrumbModel, $("#pageBreadcrumbs").get(0));
            $.titleCrumb("pageBreadcrumbs");
            /*if (self.selectedTab !== "") {
                self.selectedTab = self.selectedTab.toLowerCase();
                if (self.isValidTab(self.selectedTab)) {
                    var filter = null;

                    if (self.selectedTab == self.tabNames.users) {
                        filter = { status: 0, deepLink: true };
                        self.tabsControl.select(self.selectedTab, filter);
                    }
                    else
                        self.tabsControl.select(self.selectedTab);
                }
            }*/
        },
        isValidTab: function (tabName) {
            var self = this;
            var isValid = false;
            $.each(self.tabNames, function (key, value) {
                if (tabName === value)
                    isValid = true;
            });
            return isValid;
        },
        setRefreshTimer: function () {
            var self = this;
            if (!self.model.isLive()) {
                return;
            }
            if (self.refreshTimer) {
                clearTimeout(self.refreshTimer);
            }
            self.refreshTimer = setTimeout(function () {
                var canRefresh = true;
                $.each(self.tabNames, function (key, value) {
                    // check first all tabs
                    var tabView = self.controlById[value];
                    if (tabView.canRefresh && !tabView.canRefresh()) {
                        canRefresh = false;
                    }
                });
                if (canRefresh) {
                    self.loadData();
                } else {
                    // if can't update from some reason, we will again in 60 sec
                    self.setRefreshTimer();
                }
            }, 60000);
        },

        createTabControl: function (name, control, params) {
            var self = this;
            var tabView = new control(self.tabsControl.getTabContentElement(name), self.dashboardConfig, params);
            this.controlById[name] = tabView;
            tabView.startup();
            tabView.on("onUserSelection", function (filter) {
                self.selectTab(self.tabNames.users, filter);
            });
            tabView.on("onAlertSelection", function (filter) {
                self.selectTab(self.tabNames.activity, filter);
            });
            tabView.on("onChange", function () {
                // set the flag to refresh next time
                self.requireRefresh = true;
            });
            tabView.on("onEventEndTimeChangeSuccess", function (d) {
                self.model.endDate(d);
                self.showSuccessMessage(self.model.i18n.PAEvent_ChangeEndTime_Success);
            });
        },

        update: function (data) {
            this.eventModel = data.Data;
            // update the breadcrumb            
            this.detailPageBreadCrumb.Title(this.eventModel.RuntimeModel.EventModel.Name);
            var self = this;
            $.each(self.tabNames, function (key, value) {
                var view = self.controlById[value];
                if (self.dashboardConfig.Tabs[value].Visible) {
                    view.update(self.eventModel);
                }
            });
            this.model.isLive(this.eventModel.RuntimeModel.EventModel.Status == utils.EventStatus.Live);
            //End Event button
            this.navigationModel.sections[0].actions[0].enable(this.model.isLive() && this.eventModel.RuntimeModel.EventModel.IsCurrentVps);
            //Change End Time button
            this.navigationModel.sections[0].actions[1].enable(this.model.isLive() && this.eventModel.RuntimeModel.EventModel.IsCurrentVps);
            this.model.status(this.eventModel.RuntimeModel.EventModel.Status == utils.EventStatus.Live ? this.model.i18n.PA_Event_Details_LiveStatus : this.model.i18n.PA_Event_Details_EndedStatus);
            
            this.model.updatedOn(data.TimeStamp);
            this.model.endedOn(this.eventModel.RuntimeModel.EventModel.EndedOn);
            this.model.endDate(this.eventModel.RuntimeModel.EventModel.EndDate);
            this.model.isAllowedToUpdateStatus(this.eventModel.RuntimeModel.EventModel.IsAllowedToUpdateStatus);
            this.model.IsCurrentVps(this.eventModel.RuntimeModel.EventModel.IsCurrentVps);
            // set refresh timers
            this.setRefreshTimer(this.eventModel.RuntimeModel.EventModel);
            self.requireRefresh = false;
            var warningMsg = new Array();
            // show warning for not current vps 
			if (!this.eventModel.RuntimeModel.EventModel.IsCurrentVps) {
			    var subVpsWarningMsg = kendo.format(this.model.i18n.PA_Event_Details_SubVPS_Initiated, this.eventModel.RuntimeModel.EventModel.ProviderName);
			    warningMsg.push({ Type: '1', Value: subVpsWarningMsg });
            }

            //show restricted use warning
            if (this.eventModel.RuntimeModel.Status.IsRestrictedUser) {
                if (this.eventModel.RuntimeModel.Status.TotalUsers !== this.eventModel.RuntimeModel.Status.TotalAffectedUsers) {
                   var restrictedUserWarningMsg = kendo.format(self.model.i18n.PA_Event_Manager_Restricted_User_Message, this.eventModel.RuntimeModel.Status.TotalUsers, this.eventModel.RuntimeModel.Status.TotalAffectedUsers);
                   warningMsg.push({ Type: '1', Value: restrictedUserWarningMsg });
                }
            }

          
            if (warningMsg.length > 0) {
                self.showWarningMessage(warningMsg);
            }
            if (self.selectedTab !== "") {
                self.selectedTab = self.selectedTab.toLowerCase();
                if (self.isValidTab(self.selectedTab)) {
                    var filter = null;

                    if (self.selectedTab == self.tabNames.users) {
                        filter = { status: 0, deepLink: true };
                        self.tabsControl.select(self.selectedTab, filter);
                    }
                    else
                        self.tabsControl.select(self.selectedTab);

                    self.selectedTab = "";
                }
            }
        },

        showErrorMessage: function (msg) {
            var self = this;
            $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: msg }] }, null);
        },

        showSuccessMessage: function (msg) {
            var self = this;
            $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: msg }] }, null);
        },

        showWarningMessage: function (msg) {
            if (typeof msg =='string')
                $('#messagePanel').messagesPanel({ messages: [{ Type: '1', Value: msg }] }, null);
            else
                $('#messagePanel').messagesPanel(({ messages: msg }));
        },
        //getModel: function () {
        //    var self = this;
        //    return {};
        //},

        // by the user;)
        selectTab: function (tabName, filter) {
            var view = this.controlById[tabName];
            view.lazyLoading = false;
            this.tabsControl.select(tabName);           
            if (view.onShow && filter != null && tabName == "users") {                
                view.onChangeStatus(filter);
            }
        },
        tabNames: {
            dashboard: "dashboard",
            activity: "activity",
            users: "users",
            analysis: "analysis",
            setting: "setting"
        }
    });

    return eventDetails;
});