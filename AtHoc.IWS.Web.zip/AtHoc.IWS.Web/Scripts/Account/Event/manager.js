﻿define([        
    "account/utils",
    "account/Template/details",
    "common/navigation",
    "account/Event/grid",
    "common/baseGridManager",
    "account/Template/selectTemplateDialog",
    "common/advancedSearch/search",
    "common/confirmationDialog",
    "common/advancedSearch/dropdownSearch",
    "common/advancedSearch/multiSelectDropdownSearch",
    "common/advancedSearch/dateRangeSearch",
    "common/advancedSearch/quickFilterSearch",
    "common/gridConfig"
], function (utils, DetailView, NavigationView, EventGridProvider, BaseGridManager, SelectTemplateDialog, Search, ConfirmationDialog, DropdownSearch, MultiSelectDropdownSearch, DateRangeSearch, QuickFilterSearch, GridConfig) {
    var baseGridManager, eventGridProvider, detailView, navigationView, selectTemplateDialog, search, isCommand = false;
    var isEnterpriseVps = providerType == "Enterprise";
    //var isEnterpriseVps = false;
    this.confirmationDialog = new ConfirmationDialog(utils.createConfirmOption(resources));
    var eventManager = function (gridNode, showNewDlgOnStart) {
        var breadcrumbModel = new BreadcrumbModel();
        //Page Breadcrumb Knockout Model            
        var breadCrumb = new Breadcrumb('aPage', resources.PA_Event_Manager_EntityNamePlural, '', function () {
            baseGridManager.showList();
        });

        var navigationModel = {
            sections: [
                {
                    dataPage: "listPage",
                    actions: [
                        {
                            id: "addEvent", text: $.htmlDecode(resources.PA_Event_Manager_NewEvent), primary: true, visible: IsPAManagerRole, click: function () {
                            selectTemplateDialog.showDialog();
                            isCommand = true;
                            }
                        },
                        {
                            id: "live-map", visible: hasAccessToAccountability, promoted: true, text: $.htmlDecode(resources.PA_Event_Manager_Live_Map), click: function () {
                                window.open(athoc.iws.account.urls.EventsLiveMap + '?layerNames=AlertLayer,IncomingAlertLayer,EventAlertLayer', '_blank');
                            }
                        },
                        // Commenting out duplicate functionality as it is ot of scope for Release 90
                        //{ id: "duplicate", enable: false, text: $.htmlDecode(resources.PA_Event_Manager_Duplicate) },
                        {
                            id: "end", enable: false, visible: IsPAManagerRole, text: $.htmlDecode(resources.PA_Event_Manager_End), click: function () {
                            var ids = [];
                                var names = [];
                                baseGridManager.getSelectedItems().forEach(function(eventModel) {
                                    ids.push(eventModel.Id);
                                    names.push(eventModel.Name);
                                });
                                if (ids.length == 0) {
                                    return;
                                }

                                var nameTags = "";
                                for (var i = 0; i < names.length; i++) {
                                    nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(names[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(names[i]) + "</div>";
                                }

                                self.confirmationDialog.showConfirmationMessage(
                                kendo.format($.htmlDecode(resources.PA_Event_Manager_EndEvent)),
                                kendo.format($.htmlDecode(resources.PA_Event_Manager_EndEventConfirmation)),
                                kendo.format("{0}", nameTags),

                                    function() {
                                        var successCallback = function(data) {
                                            self.confirmationDialog.hideConfirmationMessage();
                                            baseGridManager.showSuccessMessage(kendo.format("{0} {1}", name, $.htmlDecode(resources.PA_Event_Manager_EndEventSuccess)));
                                            baseGridManager.refreshGrid();
                                        };

                                        var failCallback = function(data) {
                                            self.confirmationDialog.hideConfirmationMessage();
                                            baseGridManager.showErrorMessage(kendo.format("{0} {1}", $.htmlDecode(resources.PA_Event_Manager_EndEventFailure, name)));
                                        };

                                        utils.endEvents(ids, successCallback, failCallback);
                                    }
                                );
                            }
                        },
                        { id: "remove", enable: false, visible: IsPAManagerRole, text: $.htmlDecode(resources.PA_Event_Manager_Delete) }
                        /*{ id: "export", enable: false, text: $.htmlDecode(resources.PA_Event_Manager_Export) }*/
                    ]
                }
            ]
        };
        
        //Page breadcrumb                
        var pageBreadCrumb = new PageBreadcrumb('listPage', resources.PA_Event_Manager_EntityNamePlural, [], '');
        var detailPageBreadCrumb = new PageBreadcrumb('detailPage', resources.PA_Event_Manager_NewEvent, [breadCrumb], '');
        breadcrumbModel.addPage(pageBreadCrumb);
        breadcrumbModel.addPage(detailPageBreadCrumb);        

        var eventGridProvider = new EventGridProvider(gridNode);

        var param =
        {
            templateSectionNode: $("#templateDetails .template-section"),
            contentSectionNode: $("#templateDetails .template-content-section"),
            targetingSectionNode: $("#templateDetails .template-targeting-section"),
            context: 'template',
            mode: 'edit'
        }

        detailView = new DetailView(param);
        detailView.startup();
        detailView.init();

        selectTemplateDialog = new SelectTemplateDialog("selectTemplateToBeRemove");
        selectTemplateDialog.startup();

        if (showNewDlgOnStart) {
            selectTemplateDialog.showDialog();
        }

        navigationView = new NavigationView("eventListActionsButtons", navigationModel, { moreActionsLinkText: resources.PA_Event_Summary_More_Actions_Link_Text });
        navigationView.startup();

        athoc.iws.alert.breadcrumbModel = breadcrumbModel;

        var strings =
        {
            entityNameSingle: resources.PA_Event_Manager_EntityNameSingle,
            entityNamePlural: resources.PA_Event_Manager_EntityNamePlural
        };

        var searchOptions = $.extend(utils.createAdvancedSearchOption(resources), {
            isQuickFilterEnabled: isEnterpriseVps
        });
        search = new Search("searchHolder", searchOptions);
        search.startup();

        var severityOptions = $.extend(utils.createMultiSelectSearchOptions(resources), {
            labelText: resources.PA_Event_List_Search_Severity, filterPropertyName: "Severity"
        });

        this.severityDropdown = new MultiSelectDropdownSearch(search.createContextRow(1), severityOptions);
        this.severityDropdown.startup();
        
        var statusyOptions = $.extend(utils.createMultiSelectSearchOptions(resources), { labelText: resources.PA_Event_List_Search_EventStatus, filterPropertyName: "Status" });
        this.statusDropdown = new MultiSelectDropdownSearch(search.createContextRow(2), statusyOptions);
        this.statusDropdown.startup();

        //isEnterpriseVps = false;
        if (isEnterpriseVps == true) {
            this.organizationDropdown = new DropdownSearch(search.createContextRow(1), {
                labelText: resources.PA_Event_List_Search_EventFrom, filterPropertyName: "VpsId"
            });
            this.organizationDropdown.startup();
            eventGridProvider.model.IncludeSubVps(true);
        }
       
        
        //this.publisherDropdown = new DropdownSearch(search.createContextRow(1), { labelText: resources.PA_Event_List_Search_StartedBy, filterPropertyName: "OperatorId" });
        //this.publisherDropdown.startup();       

        var statusAttributeOptions = $.extend(utils.createMultiSelectSearchOptions(resources), { labelText: resources.PA_Event_List_Search_StatusAttribute, filterPropertyName: "AttributeId" });
        this.statusAttributeDropdown = new MultiSelectDropdownSearch(search.createContextRow(2), statusAttributeOptions);
        this.statusAttributeDropdown.startup();       
                
        this.dateRange = new DateRangeSearch(search.createContextRow(1), utils.createDateRangeSearchOption(resources));
        this.dateRange.startup();

        if (isEnterpriseVps == true) {
            this.fillFilterValues("", ["Severity", "StatusAttribute",  "Organization", "Status"]);
            search.setAdvancedFilters([this.severityDropdown, this.statusAttributeDropdown, this.statusDropdown, this.dateRange, this.organizationDropdown]);
        }
        else {
            this.fillFilterValues("", ["Severity", "StatusAttribute", "Status"]);
            search.setAdvancedFilters([this.severityDropdown, this.statusAttributeDropdown, this.statusDropdown, this.dateRange]);
        }
        
        //quickFilter_Events: resources.PA_Event_List_Search_QuickFilter_AllAccountabilityEvents,
        //quickFilter_EventsFromThisOrg: resources.PA_Event_List_Search_QuickFilter_AccountabilityEventsFromThisOrg,
        //quickFilter_EventsFromOtherOrg: resources.PA_Event_List_Search_QuickFilter_AccountabilityEventsFromOtherOrg,

        var quickFilterOption = {
            filterPropertyName : "QuickFilterValue",
            //quickFilterTooltip: 'tooltip',

            quickFilterValues: [{ value: -1, text: resources.PA_Event_List_Search_QuickFilter_AllAccountabilityEvents, IsDefault: true },
                { value: 0, text: resources.PA_Event_List_Search_QuickFilter_AccountabilityEventsFromThisOrg },
                { value: 1, text: resources.PA_Event_List_Search_QuickFilter_AccountabilityEventsFromOtherOrg }]
        };

        this.quickFilter = new QuickFilterSearch($('.quickFilter'), [quickFilterOption]);
        search.setQuickFilter(this.quickFilter);

        var gridConfig = new GridConfig();
        gridConfig.showPager = true;
        gridConfig.noScrollTop = true;
        baseGridManager = new BaseGridManager(eventGridProvider, search, detailView, breadcrumbModel, navigationView, strings, gridConfig);
        baseGridManager.startup();

        search.setSearchPageInfo(baseGridManager.kendoGrid.dataSource);
                        
        baseGridManager.on("selectionChanged", function (count) {
            var allLive = true;
            var live = false;
            var isSubEventExists = false;
            baseGridManager.getSelectedItems().forEach(function (eventModel) {
                
                if (eventModel.Status != "Live") { // todo: user constands for that.
                    allLive = false;
                } else {
                    live = true;
                }

                if (!eventModel.IsCurrentVps) {
                    isSubEventExists = true;
                    return false;
                }
            });

            search.setSelectedCount(count);
            //navigationView.getAction("duplicate").enable(count == 1);
            //navigationView.getAction("remove").enable(count > 0 && !live);
            navigationView.getAction("remove").enable(!isSubEventExists ? count > 0 && !live : false);
            //navigationView.getAction("end").enable(count > 0 && allLive);
            navigationView.getAction("end").enable(!isSubEventExists ? count > 0 && allLive : false);
            /*navigationView.getAction("export").enable(count == 1);*/
        });
                
    };

    $.extend(eventManager.prototype, {

        fillFilterValues: function (providerId,filterIds) {
            var self = this;
            var successFunction = function (data) {
                                
                $.each(data.Data, function(index, item) {                    
                    if (item.FilterId == "Severity") {
                        self.severityDropdown.fillDropdown(item.Data);
                        self.severityDropdown.setInitialSelectedValues(item.Data.map(function (x) { return x.Id; }));
                    }
                    else if (item.FilterId == "StatusAttribute") {                        
                        self.statusAttributeDropdown.fillDropdown(item.Data);
                        self.statusAttributeDropdown.setInitialSelectedValues(item.Data.map(function (x) { return x.Id; }));
                    }
                    else if (item.FilterId == "Publisher") {
                        var mergedPublisherData = $.merge([{
                        Name: resources.PA_Event_List_Search_Any_Publisher, Id: resources.PA_Event_List_Search_Any_Publisher
                        }], item.Data);                        
                        self.publisherDropdown.fillDropdown(mergedPublisherData);
                        self.publisherDropdown.setInitialSelectedValue(resources.PA_Event_List_Search_Any_Publisher);
                    }
                    else if (item.FilterId == "Organization") {
                        var mergedOrganizationData = $.merge([{ Name: resources.PA_Event_List_Search_AllOrganizations, Id: ""}], item.Data);
                        self.organizationDropdown.fillDropdown(mergedOrganizationData);
                        self.organizationDropdown.setInitialSelectedValue("");
                        self.organizationDropdown.onChange = function() {            
                            self.fillFilterValues(this.getSelectedValue(), ["StatusAttribute"]);
                        };
                    }
                    else if (item.FilterId == "Status") {
                        self.statusDropdown.fillDropdown(item.Data);
                        self.statusDropdown.setInitialSelectedValues(item.Data.map(function (x) { return x.Id; }));
                    }
                });
                                
            }
            var onerror = function () { };
            utils.fillFilterValues(providerId,filterIds, successFunction, onerror);
        }

        
    });

    return eventManager;
});


    
