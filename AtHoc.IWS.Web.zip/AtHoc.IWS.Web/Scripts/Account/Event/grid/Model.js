﻿define([], function () {
    function Model() {
        var self = this;

        this.IncludeSubVps = ko.observable(false);
    }
    
    return Model;
});