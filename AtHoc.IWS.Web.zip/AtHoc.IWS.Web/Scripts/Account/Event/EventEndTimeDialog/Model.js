﻿define(["account/utils"], function (utils) {
    function Model(i18n) {
        var self = this;    
        this.currentEndTime = ko.observable();
        this.newEndTime = ko.observable().extend({
            validation: {
                validator: function (val) {
                    var ret = moment(val, utils.getVPSTimeFormat('momentformat')).isValid() && new Date(moment(val, utils.getVPSTimeFormat('momentformat'))).getTime() - new Date($.vpsTimeZone.CurrentVPSDate.toDateString() + ' ' + $.vpsTimeZone.CurrentVPSDate.toTimeString()).getTime() >= 0;
                    return ret;
                },
                message: i18n.PAEvent_ChangeEndTime_ValidationMsg,
                params: [this.value]
            }
        });
    }

    return Model;
});