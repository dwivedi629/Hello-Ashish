﻿define([
    "common/baseView",
    "account/Event/Reports/orgBreakdown/Model",
    "dojo/text!account/Event/Reports/orgBreakdown/template.html"
], function (BaseView, Model, template) {
    //constructor
    var OrgBreakdown = function (refDomNode, eventIds) {
        var self = this;
        self.isOrgHierarchy = false;
        self.columnHeader = "";
        BaseView.call(this, refDomNode, template, Model, []);
        
        this.eventIds = eventIds;

        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            //this.init();                      
        };
    };

    $.extend(OrgBreakdown.prototype, {
        init: function () {
            var self = this;

            self.model.onSelectHierarchy = function (id) {
                self.urlOptions.hierarchyId = id;
                self.refreshList();
            };
            var IsCurrentVps = this.eventModel.RuntimeModel.EventModel.IsCurrentVps;
            this.isInit = true;
            var url = "/athoc-iws/account/GetHeirarchyBreakdown";
            this.urlOptions = { id: this.eventIds[0] };
            var columns = [
                { field: "dummy", hidden: true },
                { field: "Name", title: this.model.i18n.PA_Event_Details_Analysis_OrgHierarchy, width: 140, template: this.refDomNode.find(".name-cell-template").html() },
                {
                    field: "All", title: this.model.i18n.PA_Event_Details_Analysis_All, width: 140, template: function (dataItem) {
                        return kendo.template(self.refDomNode.find(".users-cell-template").html())({ valueKey: "All", sortOrder: -1, cellValue: dataItem.TotalCount, IsCurrentVps: IsCurrentVps });
                    }
                }
            ];

            var noResponse = { ResponseText: this.model.i18n.PA_Event_Details_Analysis_NoResponse, sortOrder: 0 };
            var responseOptions = [noResponse];


            $.each(this.eventModel.ResponseOptions, function (index, value) {
                responseOptions.push({ ResponseText: value.ResponseText, sortOrder: (index + 1) });
            });

            $.each(responseOptions, function (index, value) {
                columns.push({
                    field: "res" + index, title: value.ResponseText, width: 140, template: function (dataItem) {
                        return kendo.template(self.refDomNode.find(".users-cell-template").html())({ valueKey: value.ResponseText, sortOrder: value.sortOrder, IsCurrentVps: IsCurrentVps, cellValue: dataItem["res" + index] == undefined ? 0 : dataItem["res" + index] });
                    }
                });
            });

            self.kendoTreeList = this.refDomNode.find(".org-tree-list").kendoTreeList({
                dataSource: {
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                            /*complete: function (jqXhr, textStatus) {
                                alert("asdsa");
                            }*/
                        },
                        parameterMap: function (options) {
                            $.extend(options, self.urlOptions);
                            return kendo.stringify(options);
                        }
                    },
                    schema: {
                        /*parse: function (data) {
                            data.Items = data.Data.Entries;
                            return data;                            
                        },*/
                        data: "Items",
                        total: "TotalCount"
                        //id: "Id",
                        //parentId: "ParentId"
                        //model: model,
                    },
                    requestEnd: function (e) {
                        if (e.response) {
                            e.response.Items = e.response.Data.Entries;
                            self.urlOptions.sessionId = e.response.Data.SessionId;
                            self.setBreadCrumbModel(e.response.Data.Hierarchy);
                            self.setColumnHeader(e.response.Items);
                            e.response.Items.forEach(function (item) {
                                if (self.processData) {
                                    self.processData(item);
                                }
                            });
                        }
                        try {
                            $.AjaxLoader.hideLoader();
                        } catch (err) {

                        }
                    },
                    sort: { field: "SortOrder", dir: "asc" }
                },
                dataBound: function () {
                    self.OnDataBound();
                },
                //height: 540,
                filterable: false,
                sortable: false,
                columns: columns
            }).data("kendoTreeList");

            this.refDomNode.find(".org-tree-list thead tr th").each(function () {
                $(this).attr('title', $(this).data('title'));
            });

        },

        clickHandlers: function () {
            var self = this;
            return [
                {
                    cssClass: 'users-cell',
                    handler: function (item, cell) {
                        var ihierarchyId = (self.model.hierarchyContext().length == 0 && item.ParentId == 0) ? item.Id : null;
                        //var ilistItemId = item.ParentId > 0 ? item.Id : null;
                        var ilistItemId = (self.model.hierarchyContext().length > 0 || item.ParentId > 0) ? item.Id : null;

                        var sortOrder = $(cell).attr("sortOrder");
                        var filter = { status: sortOrder, hierarchyId: ihierarchyId, listItemId: ilistItemId, pillText: item.Name, IsSubVps: !self.isOrgHierarchy };
                        self.onUserSelection(filter);
                    }
                }, {
                    cssClass: 'org-cell',
                    handler: function (item, cell) {
                        self.urlOptions.hierarchyId = item.Id;
                        self.refreshList();
                    }
                }
            ];
        },

        OnDataBound: function () {
            this.bindClickHandlers();

            // This was part of fit and finish. 
            // As this is causing bug#28855 - commmneting out for now
            // this.autoFitColumns();
        },

        bindClickHandlers: function () {
            /*if (self.gridDataProvider.getClickClassHandlers) {
                self.gridDataProvider.getClickClassHandlers().forEach(function (clickHandlerItem) {*/
            var self = this;
            var clickHandlers = self.clickHandlers();
            clickHandlers.forEach(function (clickHandlerItem) {
                self.kendoTreeList.tbody.off("click", "." + clickHandlerItem.cssClass);
                self.kendoTreeList.tbody.on("click", "." + clickHandlerItem.cssClass, function (e) {
                    var row = $(e.target).closest("tr");
                    var item = self.kendoTreeList.dataItem(row);
                    clickHandlerItem.handler(item, $(e.target));
                });
            });
            /*    });
            }*/
        },

        autoFitColumns: function () {
            this.kendoTreeList.autoFitColumn("Name");
            this.kendoTreeList.autoFitColumn("All");
        },

        setBreadCrumbModel: function (hierarchyContext) {
            var self = this;
            // clear
            this.model.hierarchyContext([]);
            this.model.selectedItem('');

            if (hierarchyContext && hierarchyContext.length > 0) {
                $.each(hierarchyContext, function (index, value) {
                    self.model.hierarchyContext.push({ Id: value.Id, Name: value.Name });
                });

                var leafNode = self.model.hierarchyContext.pop();
                self.model.selectedItem(leafNode.Name);
            }
        },

        update: function (data) {
            this.eventModel = data;
            if (!this.kendoTreeList) {
                this.init();
            } else {
                this.refreshList();
            }
        },

        processData: function (item) {
            $.each(item.ResponseValues, function (index, value) {
                item["res" + index] = value;
            });
            item.expanded = true;
            item.id = item.Id;
            item.parentId = item.ParentId == 0 ? null : item.ParentId;
            item.totalCount = item.TotalCount;
        },

        setColumnHeader: function (items) {
            var self = this;
            this.isOrgHierarchy = items.some(function (e) {
                return (e.ParentId != 0 && e.ParentId != 1) || items.length == 1;
            });

            //var root = this.model.i18n.PA_Event_Details_Analysis_Root;
            var vps = this.model.i18n.PA_Event_Details_Analysis_VpsHierarchy;

            // Set Org Column to Organization Hierarchy name given at root level
            if (this.isOrgHierarchy) {
                if (this.urlOptions.hierarchyId == undefined || this.urlOptions.hierarchyId == 0) {
                    $.each(items, function (index, hierarchyNode) {
                        if (hierarchyNode.ParentId == 0) {
                            self.columnHeader = hierarchyNode.Name;
                            //hierarchyNode.Name = root;
                        }
                    });
                }
            } else {
                this.columnHeader = vps;
            }

            this.refDomNode.find(".org-tree-list th[data-field=Name]").html(this.columnHeader);
            this.refDomNode.find(".org-tree-list th[data-field=Name]").attr('title', this.columnHeader);
        },

        refreshList: function () {
            var self = this;
            //show the loader when we make a request to the server...
            //$.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: athoc.iws.account.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: this.model.i18n.General_LoadingMessage }).showLoader();
            //Per telerik, this will set the page only asfter datasource refreshes.
            self.kendoTreeList.dataSource.one("change", function () {
                //scrolling to the top when paging and sorting.
                // $("html,body").scrollTop(0);
            });

            self.kendoTreeList.dataSource.read();
        },
        getFilterText:function() {
            var self = this;
            var hrchyFilterText = "";
            self.model.hierarchyContext().forEach(function (selecteditem) {

                hrchyFilterText = (hrchyFilterText === "" ? hrchyFilterText : hrchyFilterText + " / ") + selecteditem.Name;
            });
            if (hrchyFilterText !== "")
                hrchyFilterText = hrchyFilterText + " / " + self.model.selectedItem();
            return hrchyFilterText;
        },
        getFilterValues: function () {
            var self = this;
            return self.urlOptions;
        },
        getHrchyColumnHeader: function () {
            var self = this;
            return self.columnHeader;
        },


        //events
        onUserSelection: function (filter) { },
        onAlertSelection: function (filter) { }
    });
    return OrgBreakdown;
});