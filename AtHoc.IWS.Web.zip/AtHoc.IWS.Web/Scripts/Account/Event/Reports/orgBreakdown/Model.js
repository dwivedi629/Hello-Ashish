﻿define([], function () {
    function Model(i18n) {
        var self = this;
        this.hierarchyContext = ko.observableArray([]);
        this.selectedItem = ko.observable();
        this.selectHierarchy = function () {
            self.onSelectHierarchy(this.Id);
        }
        this.IsCurrentVps = ko.observable(false);
        // event
        this.onSelectHierarchy = function(id) {};
    }

    return Model;
});