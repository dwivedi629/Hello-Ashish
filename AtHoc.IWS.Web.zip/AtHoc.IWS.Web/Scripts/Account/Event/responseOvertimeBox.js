﻿define([    
    "common/baseView",
        "account/utils",
    "account/Event/responseOvertimeBox/Model",
    "dojo/text!account/Event/responseOvertimeBox/template.html"
], function (BaseView, utils, Model, template) {
    //constructor
    var AlertBox = function (refDomNode) {
        BaseView.call(this, refDomNode, template, Model, []);

        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };
    };

    $.extend(AlertBox.prototype, {
        init: function () {
            var self = this;
            this.model.onAlertSelection = function(filter) {
                self.onAlertSelection(filter);
            }

            this.initChart();
        },

        initChart: function (dataSource) {
            var self = this;

            this.dataSource = dataSource;
            if (!this.dataSource) {
                this.dataSource = new kendo.data.DataSource({
                    data: [],
                    sort: {
                        field: "datetime",
                        dir: "asc"
                    }
                });
            }            

            this.refDomNode.find(".response-overtime-chart").kendoChart({
                dataSource: new kendo.data.DataSource({ data: [] }),
                title: {
                    //text: "User Respones and Sent Alerts"

                },
                legend: {
                    position: "bottom"
                },
                series: [
                    {
                        type: "line",
                        width: 3,
                        //style: "smooth",
                        markers: {
                            visible: false
                        },
                        name: self.model.i18n.PA_Event_Details_Graph_Users_With_Status_Text,
                        color: "#00CC30",
                        field: "responses"
                    }, {
                        type: "column",
                        //stack: true,
                        name: self.model.i18n.PA_Event_Details_Graph_Alert_Targeted_Users_Text,
                        color: "#FFFFFF",
                        field: "targeted"
                        //spacing: 0,
                        //gap: 0                        
                    }
                ],
                valueAxes: [
                    {
                        title: { text: self.model.i18n.PA_Event_Details_Graph_Number_Of_Users_Text },

                        min: 0,
                        labels: {
                            format: "{0:n0}" // make sure no decimals
                            //template: "#= (value) #"
                        }
                    }
                ],
                chartArea: {
                    background: "#F5F5F5"
                },
                plotArea: {
                    background: "#F5F5F5"
                },
                categoryAxis: {
                    /*axis.Categories(model => model.Date);
                    axis.Axis.BaseUnit = ChartAxisBaseUnit.Minutes;
                    axis.Axis.BaseUnitStep = 10;
                    axis.Labels(label => label.Step(12));
                    axis.Axis.Min = DateTime.Parse( "2013-06-28 07:00:00" );
                    axis.Axis.Max = DateTime.Parse( "2013-06-28 20:00:00" );
                    axis.Axis.MajorGridLines.Visible = false;*/
                    /*majorTicks: {
                        majorTicks: {
                            step: 10
                        },
                    },*/
                    majorGridLines: { visible: false },
                    minorGridLines: { visible: false },
                    minorTicks: {
                        visible: false
                    },
                    majorTicks: {
                        visible: false
                    },
                    labels:
                    {
                        step: 1, // this is being overide in code
                        rotation: -90,
                        dateFormats:
                            {
                                //minutes: $.vpsDateTimeFormat,
                                minutes: self.model.i18n.PA_Date_Time_Format_MM_Text, // override by code
                                hours: self.model.i18n.PA_Date_Time_Format_HH_Text,
                                days: self.model.i18n.PA_Date_Time_Format_ddMM_Text,
                                months: self.model.i18n.PA_Date_Time_Format_MMMyy_Text,
                                years: self.model.i18n.PA_Date_Time_Format_yyyy_Text
                            }
                    },
                    type: "Date",
                    field: "datetime"
                    /*baseUnit and baseUnitStep make sure that we do not aggeagate, we cant aggregate alexs series*/
                    //baseUnit: "minutes",
                    //baseUnitStep: 1,                    
                    //baseUnitStep: "auto",
                    //baseUnit: "fit",
                    //maxDateGroups: 100,
                    /*autoBaseUnitSteps: {
                        //days: [3]
                    }*/
                },
                tooltip: {
                    visible: true,
                    format: "{0}%",
                    template: "#= dataItem.hasOwnProperty('targeted') ? kendo.format('{0}: {1}', athoc.iws.resources.PA_Event_Details_Graph_Alert_Targeted_Users_Tooltip, dataItem.targeted) : kendo.format('{0}: {1}', athoc.iws.resources.PA_Event_Details_Graph_Users_With_Status_Tooltip, dataItem.responses) #"
                },
                seriesClick: function (e) { self.onSeriesClick(e) }
            });
        },

        onSeriesClick: function (e) {
            var ser = e.series.name;
            var cat = e.category;
            var val = e.value;            
        },

        jsonTimeToDate: function (time, dstDelta) {
            //In order to keep compatibility with the output of moment#zone, a numeric input to moment#zone actually needs to be the negative of the string input.
            return new Date(moment(time).zone(-1 * $.vpsTimeZone.UtcOffsetInMinutes - dstDelta));
        },

        utcDateToVpsTimeStr: function (time, dstDelta) {
            //In order to keep compatibility with the output of moment#zone, a numeric input to moment#zone actually needs to be the negative of the string input.
            return moment(time.getTime()).zone(-1 * $.vpsTimeZone.UtcOffsetInMinutes - dstDelta).format('YYYY-MM-DD HH:mm');
        },

        update: function (data) {                      

            var self = this;
            var isLive = data.RuntimeModel.EventModel.Status == utils.EventStatus.Live;
            var activityModel = data.RuntimeModel.Activity;
            var sentAlertCountForUser = data.RuntimeModel.Activity.SentAlertCountForUser;
            var overtimeModel = data.RuntimeModel.Overtime;
            var statusModel = data.RuntimeModel.Status;

            this.model.sentAlertCount(sentAlertCountForUser);
            this.model.pendingAlertCount(activityModel.PendingAlerts.length);            
            this.model.hasNextReminderAlert(isLive && activityModel.PendingAlerts.length > 0);
            this.model.nextAlertTime(this.model.hasNextReminderAlert() ? activityModel.PendingAlerts[0].CreatedOn : "");            

            var nowUtc = this.jsonTimeToDate(data.RuntimeModel.CurrentTimeUtc, 0);
            var endEventDateUtc = this.jsonTimeToDate(data.RuntimeModel.EventModel.EndDateUtc, data.RuntimeModel.EventModel.EndDateDstDelta);
            var startDateUtc = this.jsonTimeToDate(data.RuntimeModel.EventModel.StartDateUtc, data.RuntimeModel.EventModel.StartDateDstDelta);

            var chart = $(".response-overtime-chart").data("kendoChart");

            if (data.RuntimeModel.Status.TotalUsers < 10) {
                chart.options.valueAxis.majorUnit = 1;
            }

            var durationInSeconds = (endEventDateUtc.getTime() - startDateUtc.getTime()) / 1000;
            var steps = 20;

            // TODO: refctor this area. it should not be that involved. 
            // we must set the baseUnitStep according to the total duration since it causes performance issues when rendering especially IE.
            var baseSteps = 120;
            var baseUnitStepInMin = 1;
            if (durationInSeconds >= 43200) { // if more than a 12H 
                baseUnitStepInMin = 15;
            } else if (durationInSeconds >= 86400) { // if more than a day
                baseUnitStepInMin = 30;
            } else if (durationInSeconds >= 604800) { // if more than a week
                baseUnitStepInMin = 600; 
            }
            chart.options.categoryAxis.baseUnit = "minutes";
            chart.options.categoryAxis.baseUnitStep = baseUnitStepInMin;
            
            // set the label steps in minutes
            chart.options.categoryAxis.labels.step = Math.floor(durationInSeconds / 60 / baseUnitStepInMin / steps);                                           

            var minFormat = "HH:mm";
            var secFormat = "HH:mm:ss";
            if (endEventDateUtc.getDate() !== startDateUtc.getDate()) { // if not the same date (of month) make sure to add the day of the week  as well.
                minFormat = "ddd HH:mm";
                secFormat = "ddd HH:mm:ss";
            }
            chart.options.categoryAxis.labels.dateFormats.minutes = minFormat;
            chart.options.categoryAxis.labels.dateFormats.seconds = secFormat;

            // we add the half a step before and after to make sure the first alert is visible, and some later alerts are visible.
            var chartMaxDate = new Date(endEventDateUtc.getTime() + durationInSeconds * 1000 / steps);
            var chartMinDate = new Date(startDateUtc.getTime() - durationInSeconds * 1000 / steps);

            // Update
            var tooltipFormat = '{0}: {1}';
            var chartData = [];
            var maxUserCount = statusModel.TotalUsers;            
            activityModel.SentAlerts.forEach($.proxy(function(alert) {                
                if (!(alert.Status == 3 || alert.Status == 6)) {
                    // hide schedule alert etc... only life and ended.
                    return;
                }
                var d = self.jsonTimeToDate(alert.CreatedOnUtc, alert.CreatedOnDstDelta);
                if (d < chartMinDate) {
                    // something is wrong
                    return;
                }

                if (d > chartMaxDate) {
                    // ssometmes alerts might be trigggered with delay
                    chartMaxDate = d;
                }
                
                chartData.push({
                    "targeted": alert.TargetedUsers,
                    "datetime": self.utcDateToVpsTimeStr(d, alert.CreatedOnDstDelta)
                });
            }));

            // add the begining as 0:
            chartData.push({
                "responses": 0,
                "datetime": self.utcDateToVpsTimeStr(new Date(startDateUtc.getTime() - 60000), data.RuntimeModel.EventModel.StartDateDstDelta)
            });

            overtimeModel.StatusOverTime.forEach($.proxy(function (responseModel) {
                var d = self.jsonTimeToDate(responseModel.DateTimeUtc, responseModel.DstDelta);
                if (d < chartMinDate || d > chartMaxDate) {
                    // something is wrong
                    return;
                }
                                      
                chartData.push({
                    "responses": responseModel.Value,
                    "datetime": self.utcDateToVpsTimeStr(d, responseModel.DstDelta)
                });
            }));
            
            // add the current values:
            chartData.push({
                "responses": statusModel.UsersWithStatus.Value,
                "datetime": self.utcDateToVpsTimeStr(nowUtc < endEventDateUtc ? nowUtc : endEventDateUtc, nowUtc < endEventDateUtc ? 0 : data.RuntimeModel.EventModel.EndDateDstDelta)
            });
                       
            // add half a step to the chart
            chart.options.categoryAxis.max = self.utcDateToVpsTimeStr(chartMaxDate, data.RuntimeModel.EventModel.EndDateDstDelta);
            chart.options.categoryAxis.min = self.utcDateToVpsTimeStr(chartMinDate, data.RuntimeModel.EventModel.StartDateDstDelta);

            // set value axes:
            chart.options.valueAxis.min = 0;
            chart.options.valueAxis.max = maxUserCount + 1;
            // set the data
            var d = []; // <- potentially a fix for IE memory leak
            chart.dataSource.data(d); 

            chart.dataSource.data(chartData);
        },

        //events
        onUserSelection: function (filter) { },
        onAlertSelection: function (filter) { }
    });
    return AlertBox;
});