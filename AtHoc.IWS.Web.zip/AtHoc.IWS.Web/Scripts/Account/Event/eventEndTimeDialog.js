﻿define([
    "common/baseView",
    "account/utils",
    "account/Event/EventEndTimeDialog/Model",
    "dojo/text!account/Event/EventEndTimeDialog/template.html",
    "common/navigation",
    "common/dialog"
], function (BaseView, utils, Model, template, NavigationView, Dialog) {
    //constructor
    var eventEndTimeDialog = function (event) {
        var self = this;
        this.model = Model;
        this.eventId = event.id;
        var refDomNode = $("<div>");
        $("body").append(refDomNode);
        BaseView.call(this, refDomNode, template, Model, []);

        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };

        this.init = function () {
            this.model.currentEndTime(event.endTime);
            var momentdatetimeformat = utils.getVPSTimeFormat('momentformat');
            var currDateTime = moment($.vpsTimeZone.CurrentVPSDate).format(momentdatetimeformat);
            this.model.newEndTime(currDateTime);
            var navigationModel = {
                sections: [
                    {
                        dataPage: "",
                        actions: [
                            { id: "close", text: self.model.i18n.PAEvent_Cancel, primary: false, click: function () { self.dialog.hideDialog(); } },
                            { id: "confirm", text: self.model.i18n.PAEvent_Apply, primary: true, click: function () { self.changeEventEndTime(); } }

                        ]
                    }
                ]
            };

            var options = {
                dlgClass: 'width500'
            };

            this.dialog = new Dialog(navigationModel, "", "", "", options);

            this.dialog.startup();

            this.dialog.setBodyNode(this.refDomNode.find('.change-status-dlg-content'));
            this.dialog.setTitleNode(this.refDomNode.find('.change-status-dlg-title'));
        };
    };

    $.extend(eventEndTimeDialog.prototype, {
        changeEventEndTime: function () {
            var self = this;
            if (this.model.newEndTime.isValid()) {
                utils.makeAjaxCall("/athoc-iws/account/ChangeEventEndDate", { EventId: this.eventId, NewDate: this.model.newEndTime() }, $.proxy(function () {
                    self.successCallback(self.model.newEndTime());
                }), $.proxy(function () {
                    self.errorCallback();
                }));
            }
            self.dialog.hideDialog();
        },
        showDialog: function () {
            var self = this;
            this.dialog.showDialog();
            $(".save-message-panel", this.dialog.refDomNode).hide();
            this.dialog.refDomNode.find('#DBDateTimeValue').datetimepicker({
                pick12HourFormat: $.vpsDateTimeFormat.indexOf('tt') > 0 ? true : false,
                language: $.culture,
                pickSeconds: ($.vpsDateTimeFormat.indexOf('ss') > 0 ? true : false),
                startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleString(), "MM/DD/YYYY")),
                format: $.vpsDateTimeFormat
            }).on('changeDate', function (ev) {
                if (ev.localDate == null)
                    return;
                var momentdatetimeformat = utils.getVPSTimeFormat('momentformat');
                var newDate = moment(ev.localDate).format(momentdatetimeformat);
                self.model.newEndTime(newDate);
            });

            $(".icon-calendar").click(function () { $('.bootstrap-datetimepicker-widget').css("z-index", "10000"); });
        },
        //events
        successCallback: function (d) { },
        errorCallback: function () { }
    });

    return eventEndTimeDialog;
});