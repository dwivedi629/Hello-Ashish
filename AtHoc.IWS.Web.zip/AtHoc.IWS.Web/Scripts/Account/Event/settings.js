﻿define([    
    "common/baseView",
    "account/Event/settings/Model",
    "dojo/text!account/Event/settings/template.html",
    "account/Template/details"
], function (BaseView, Model, template, DetailView) {
    //constructor
    var settingsView = function (refDomNode, dashboardConfig, params) {
        BaseView.call(this, refDomNode, template, Model, []);

        this.params = params;

        // todo: ugly, should be done via prototype
        this.baseStartup = this.startup;
        this.startup = function () {
            this.baseStartup.call(this);
            this.init();
        };        
    };

    $.extend(settingsView.prototype, {
        init: function () {
            var self = this;
            this.params.context= 'event';
            this.params.mode= 'view';
            this.params.reviewAndPublish= false;
            
            /*var params =
            {
                templateSectionNode: $("#dialogReviewAndStart .template-section"),
                //  templateSectionNode: this.refDomNode,
                contentSectionNode: $("#dialogReviewAndStart .start-event-content-section"),
                targetingSectionNode: $("#dialogReviewAndStart .start-event-targeting-section"),
                context: 'event',
                mode: 'view',
                reviewAndPublish : true
            }*/
                       
            this.detailView = new DetailView(this.params,true);
            this.detailView.startup();
            this.detailView.init();
            this.detailView.on("onUserSelection", function (filter) {
                self.onUserSelection(filter);
            });

            this.detailView.on("onEventEndTimeChangeSuccess", function (d) {
                self.onEventEndTimeChangeSuccess(d);
            });
            this.detailView.on("onEventEndTimeChangeError", function () {
                self.onEventEndTimeChangeError();
            });

            $("#settingsTab").find(".span12").toggleClass("span11c");
            // copy the init under the root.
            // todo refactor this.
            this.detailView.refDomNode.parent().parent().appendTo(this.refDomNode);
        },

        update: function (eventData) {
            // for now: supports only single event mode
            this.detailView.update(eventData.RuntimeModel.EventModel.Id, eventData.RuntimeModel.EventModel, null, true);
        },
       
        canRefresh: function () { return true; }, // a flag that can block UI from refreshing. i.e user is editing...

        //events
        onUserSelection: function (filter) { },
        onChange: function () { }, //fires when there is a change that requires refresh

        onVisible: function() {
            if (athoc.iws.publishing.view.viewModel.data.Content.LocationGeo) {
                var geoData = athoc.iws.publishing.view.viewModel.data.Content.LocationGeo();
                athoc.iws.publishing.view.bindGeoLocation(geoData, $('.event-content-section'));
            }
        },
        //change event end time events
        onEventEndTimeChangeSuccess: function (d) { },
        onEventEndTimeChangeError: function () { }
    });
    return settingsView;
});