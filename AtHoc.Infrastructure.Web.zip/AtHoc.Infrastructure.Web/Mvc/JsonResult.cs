﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using AtHoc.Infrastructure.Serialization;

namespace AtHoc.Infrastructure.Web.Mvc
{
    public class JsonResult : System.Web.Mvc.JsonResult
    {
        public override void ExecuteResult(ControllerContext context)
        {
            if (context == null)
                throw new ArgumentNullException("context");

            HttpResponseBase response = context.HttpContext.Response;

            //ContentType
            if (String.IsNullOrEmpty(this.ContentType) == false)
            {
                response.ContentType = this.ContentType;
            }
            else
            {
                response.ContentType = "application/json";
            }

            //ContentEncoding
            if (this.ContentEncoding != null)
            {
                response.ContentEncoding = this.ContentEncoding;
            }

            //Data
            if (this.Data != null)
            {
                response.Write(JsonSerializerService.Current.Serialize(this.Data, this.Data.GetType()));
            }
        }
    }
}
