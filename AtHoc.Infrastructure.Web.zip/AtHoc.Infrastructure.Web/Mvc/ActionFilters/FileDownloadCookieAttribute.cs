﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace AtHoc.Infrastructure.Web.Mvc.ActionFilters
{
    public class FileDownloadCookieAttribute: ActionFilterAttribute
    {
        private string contentType;

        /// <summary>
        /// Construtor
        /// </summary>
        /// <param name="_contentType">Content Type</param>
        public FileDownloadCookieAttribute(string _contentType = "")
        {
            contentType = _contentType;
        }
        private const string FileDownloadCookieName = "fileDownload";
        
        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
            var httpContext = filterContext.HttpContext;
            if (filterContext.Result is ActionResult)
            {
                //jquery.fileDownload uses this cookie to determine that a file download has completed successfully
                httpContext.Response.SetCookie(new HttpCookie(FileDownloadCookieName, "true") {Path = "/"});
                
                //if passing Content Type as Filter parameter, then Update Content Type
                if (!string.IsNullOrEmpty(contentType))
                {
                    httpContext.Response.ContentType = contentType;
                }
            }
            else
            {
                //ensure that the cookie is removed in case someone did a file download without using jquery.fileDownload
                if (httpContext.Request.Cookies[FileDownloadCookieName] != null)
                {
                    httpContext.Response.Cookies[FileDownloadCookieName].Expires = DateTime.Now.AddYears(-1);
                }
            }

            base.OnResultExecuting(filterContext);
        }

    }
}
