﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace AtHoc.Infrastructure.Web.Mvc.ActionFilters
{

    public class PostXmlAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var httpContext = filterContext.HttpContext;
            var httpBodyStream = httpContext.Request.InputStream;
            if (httpBodyStream.Length > int.MaxValue)
            {
                throw new ArgumentException("HTTP InputStream too large.");
            }
            var xmlBody = string.Empty;
            using (var streamReader = new StreamReader(httpBodyStream, Encoding.UTF8))
            {
                xmlBody = streamReader.ReadToEnd();
                streamReader.Close();
            }
            //Sends XML Data To Model so it could be available on the ActionResult
            filterContext.ActionParameters["xml"] = xmlBody;
            base.OnActionExecuting(filterContext);
        }
    }
}
