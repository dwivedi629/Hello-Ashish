﻿using System.Security.Principal;
using System.Text;
using System.Web.Mvc;

namespace AtHoc.Infrastructure.Web.Mvc
{
    public abstract class Controller : System.Web.Mvc.Controller
    {
        protected T GetUser<T>() where T : IPrincipal
        {
            return (T)this.HttpContext.User;
        }

        protected override System.Web.Mvc.JsonResult Json(object data, string contentType, Encoding contentEncoding)
        {
            return this.Json(data, contentType, contentEncoding, JsonRequestBehavior.DenyGet);
        }

        protected override System.Web.Mvc.JsonResult Json(object data, string contentType, Encoding contentEncoding, JsonRequestBehavior jsonRequestBehavior)
        {
            return new JsonResult
            {
                Data = data,
                ContentType = contentType,
                ContentEncoding = contentEncoding,
                JsonRequestBehavior = jsonRequestBehavior
            };
        }

        public XmlResult Xml(object data, string contentType = "application/xml", Encoding contentEncoding = null)
        {
            return new XmlResult
            {
                Data = data,
                ContentType = contentType,
                ContentEncoding = contentEncoding,
            };
        }
    }
}
