﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace AtHoc.Infrastructure.Web.Security
{
    /// <summary>
    /// AntiForgery class
    /// </summary>
    public static class AtHocAntiForgery
    {
        private const int TokenLength = 128 / 8;
        private static readonly RNGCryptoServiceProvider Prng = new RNGCryptoServiceProvider();

        /// <summary>
        /// Generates new token using RNGCryptoServiceProvider
        /// </summary>
        /// <returns></returns>
        public static string NewToken()
        {
            string tokenString = GenerateRandomTokenString();
            return Base64EncodeForCookieName(tokenString);
        }


        private static string Base64EncodeForCookieName(string s)
        {
            byte[] rawBytes = Encoding.UTF8.GetBytes(s);
            string base64String = Convert.ToBase64String(rawBytes);
            // replace base64-specific characters with characters that are safe for a cookie name
            return base64String.Replace('+', '.').Replace('/', '-').Replace('=', '_');
        }

        private static string GenerateRandomTokenString()
        {
            byte[] tokenBytes = new byte[TokenLength];
            Prng.GetBytes(tokenBytes);

            string token = Convert.ToBase64String(tokenBytes);
            return token;
        }

        public static bool Validate(ActionExecutingContext filterContext = null)
        {
            //kutsumi - we don't need to validate if debugging. 

            string antiForgeryTokenCookie = string.Empty;
            string antiForgeryToken = string.Empty;

            if (filterContext != null)
            {
                antiForgeryToken = filterContext.HttpContext.Request["__RequestVerificationToken"];
                if(antiForgeryToken==null)
                    antiForgeryToken = filterContext.HttpContext.Request.Headers["__RequestVerificationToken"];
                // this value will be used to pass to Classic asp request to generate the Antiforgery token...
                var httpCookie = filterContext.HttpContext.Request.Cookies["__AntiForgeryToken"];
                var sessionToken = HttpContext.Current.Session["__RequestVerificationToken"].ToString();
                if (httpCookie != null)
                {
                    antiForgeryTokenCookie = httpCookie.Value;
                }
                if (antiForgeryToken == antiForgeryTokenCookie && antiForgeryTokenCookie == sessionToken) return true;

            }
            else
            {
                antiForgeryToken = HttpContext.Current.Request["__RequestVerificationToken"]; // this value will be used to pass to Classic asp request to generate the Antiforgery token...
                var httpCookie = HttpContext.Current.Request.Cookies["__AntiForgeryToken"];
                if (httpCookie != null)
                {
                    antiForgeryTokenCookie = httpCookie.Value;
                }
                if (antiForgeryToken == antiForgeryTokenCookie) return true;
                        
            }

            return false;


        }

        public static void EndSession()
        {
            try
            {
                //EventLogger.WriteVerbose("Force Logout: calling FormsAuthentication.SignOut due to Cross-Site Request Forgery!");
                FormsAuthentication.SignOut();

                //EventLogger.WriteVerbose("Force Logout: calling Session.Abandon due to Cross-Site Request Forgery!");
                System.Web.HttpContext.Current.Session.Abandon();

                // clear session cookies
                HttpCookie formsAuthenticationCookie = new HttpCookie(FormsAuthentication.FormsCookieName, "");
                formsAuthenticationCookie.HttpOnly = true;
                HttpCookie aspNetSessionCookie = new HttpCookie("ASP.NET_SessionId", null);
                aspNetSessionCookie.HttpOnly = true;
                HttpCookie requestVerificationTokenCookie = new HttpCookie("RequestVerificationToken", null);
                requestVerificationTokenCookie.HttpOnly = true;
                HttpCookie antiForgeryTokenCookie = new HttpCookie("__AntiForgeryToken", null);
                antiForgeryTokenCookie.HttpOnly = true;

                // make sure that browser deletes them....
                formsAuthenticationCookie.Expires = DateTime.Now.AddYears(-10);
                aspNetSessionCookie.Expires = DateTime.Now.AddYears(-10);
                requestVerificationTokenCookie.Expires = DateTime.Now.AddYears(-10);
                antiForgeryTokenCookie.Expires = DateTime.Now.AddYears(-10);

                System.Web.HttpContext.Current.Response.Cookies.Add(formsAuthenticationCookie);
                System.Web.HttpContext.Current.Response.Cookies.Add(aspNetSessionCookie);
                System.Web.HttpContext.Current.Response.Cookies.Add(requestVerificationTokenCookie);
                System.Web.HttpContext.Current.Response.Cookies.Add(antiForgeryTokenCookie);
            }
            catch (Exception)
            {
                //EventLogger.WriteError("Force Logout: auth.Logout called, due to Cross-Site Request Forgery", ex);
            }
          
        }
    }

    public class ValidateAntiForgeryTokenFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (AtHocAntiForgery.Validate(filterContext)) return;
            // suppress..
            // role was not found! go to access denied page

            AtHocAntiForgery.EndSession();

            //filterContext.Result = new RedirectResult("/client/error/accessdenied");
            filterContext.Result = new HttpStatusCodeResult(403); //per request from Kevin, retruning 403 to make some security app like AppScan not raise a false alarm
        }
    }
}
