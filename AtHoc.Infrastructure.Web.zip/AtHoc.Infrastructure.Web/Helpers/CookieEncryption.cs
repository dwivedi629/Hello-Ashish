﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Settings.Impl;

namespace AtHoc.Infrastructure.Web.Helpers
{
    public static class CookieEncryption
    {
        public static string Protect(string text)
        {
            if (string.IsNullOrEmpty(text))
                return null;

            byte[] stream = Encoding.UTF8.GetBytes(text);
            // byte[] encodedValue = MachineKey.Protect(stream, purpose);
            return HttpServerUtility.UrlTokenEncode(stream);
        }
        public static string UnProtect(string text)
        {
            if (string.IsNullOrEmpty(text))
                return null;

            byte[] stream = HttpServerUtility.UrlTokenDecode(text);
            //byte[] decodedValue = MachineKey.Unprotect(stream, purpose);
            return Encoding.UTF8.GetString(stream);
        }
        public static CultureInfo GetCultureInfoByBaseLocale(string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                var cookie = UnProtect(value);
                try
                {
                    return CultureInfo.CreateSpecificCulture(cookie);
                }
                catch (Exception)
                {

                }
            }
            return System.Threading.Thread.CurrentThread.CurrentUICulture;
        }

        public static string GetProviderLocale(int providerId)
        {
            return LanguageManager.GetProviderLocale(providerId);
        }
    }
}

