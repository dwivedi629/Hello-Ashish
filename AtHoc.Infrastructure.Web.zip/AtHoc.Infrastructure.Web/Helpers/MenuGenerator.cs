﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.SSA.Impl;

namespace AtHoc.Infrastructure.Web.Helpers
{
    public class MenuGenerator
    {
        private static bool _isOperator = false;

        public static XElement GetMenuXML(bool forOperator)
        {
            _isOperator = forOperator;

            XElement menuXML;

            //' Loading navigation bar XML file
            //set xmlObj = CreateObject("MSXML2.DOMDocument")
            //xmlObj.async = false
            //xmlObj.load(C_XML_NAVIGATION)
            //set rootNode = xmlObj.documentElement
            XElement menuTemplate = XElement.Parse(AtHoc.Infrastructure.Web.Properties.Resources.navigationBarIWS);

            //' Creating a new XML object (this object will be returned)
            //menuXML = CreateObject("MSXML2.DOMDocument")
            //set xmlNode = outXmlObj.createElement("topiclist")
            //xmlNode.setAttribute "type", "sections"
            //outXmlObj.appendChild(xmlNode)
            menuXML = new XElement("topiclist",
                new XAttribute("type", "sections")
                );

            //' Calling parseTreeNode private function for each of the top
            //' level child nodes
            //for each child in rootNode.childNodes
            //    status = parseTreeNode(child, outXmlObj, xmlNode)
            //next
            foreach (var element in menuTemplate.Elements())
            {
                parseTreeNode(ref menuXML, element, forOperator);
            }




            //set rootNode = nothing
            //set xmlNode = nothing
            //set xmlObj = nothing

            //closeObjects("ATH")
            //set getTreeXML = outXmlObj

            return menuXML;
        }

        public static void parseTreeNode(ref XElement elementToAddTo, XElement menuElement, bool forOperator)
        {
            XElement xmlNode = new XElement(menuElement.Name.LocalName);

            switch (menuElement.Name.LocalName)
            {
                case "Topics":
                    xmlNode.Add(menuElement.Element("Title"));
                    xmlNode.Add(menuElement.Element("IconCssclass"));
                    xmlNode.Add(menuElement.Attribute("id"));
                    if (menuElement.Element("Url") != null)
                    {
                        xmlNode.Add(menuElement.Element("Url"));
                    }
                    foreach (var children in menuElement.Elements())
                    {
                        parseTreeNode(ref xmlNode, children, forOperator);
                    }

                    if ((xmlNode.Elements("Main").Count() != 0))
                    {
                        if (forOperator == false)
                        {
                            //only append element if there is any "Main" children
                            if (menuElement.Attribute("id").Value == "myprofile" ||
                                menuElement.Attribute("id").Value == "myactivity" ||
                                menuElement.Attribute("id").Value == "iwsOperator")
                            {
                                elementToAddTo.Add(xmlNode);
                            }
                        }
                        else
                        {
                            if (menuElement.Attribute("id").Value != "myprofile" &&
                                menuElement.Attribute("id").Value != "myactivity")
                                elementToAddTo.Add(xmlNode);
                        }
                    }
                    break;
                case "Topic":
                    if (!menuElement.Elements("Topic").Count().Equals(0))
                    {
                        xmlNode.Add(menuElement.Element("Title"));
                        xmlNode.Add(menuElement.Element("IconCssclass"));
                        xmlNode.Add(menuElement.Attribute("id"));

                        foreach (var children in menuElement.Elements())
                        {
                            parseTreeNode(ref xmlNode, children, forOperator);
                        }

                        if (xmlNode.Elements().Count() != 0)
                        {
                            //only append element if there is any children
                            elementToAddTo.Add(xmlNode);
                        }

                    }
                    else if (!menuElement.Elements("Topic").Count().Equals(0))
                    {
                    }
                    else
                    {

                        int objectId;
                        bool addToList = true;




                        if (Int32.TryParse(menuElement.Element("Object").Value, out objectId))
                        {
                            int actionId;
                            if (Int32.TryParse(menuElement.Element("Action").Value, out actionId))
                            {

                                // var operatorObj = RuntimeContext.Operator;
                                //operatorObj.H
                                //if (!Operator.HasPermission()
                                //    doesOperatorHaveAccess(objectId, actionId))
                                //    addToList = false;

                                if (
                                    !doesOperatorHaveAccess(menuElement.Element("Object").Value,
                                        menuElement.Element("Action").Value))
                                {
                                    addToList = false;
                                }
                                else if (objectId.Equals((int) SystemObject.SSATeam))
                                    //operator has access; now check to see if this ssa object show these items only if opr is member of team
                                {
                                    addToList = false;
                                    if (RuntimeContext.Operator != null && RuntimeContext.Operator.IsTeamMember)
                                    {
                                        var team = SSAManager.GetMyTeam(RuntimeContext.Operator.Id,
                                            RuntimeContext.Provider.Id);
                                        if (team != null && team.HasLog)
                                            addToList = true;
                                    }

                                }

                            }

                        }

                        if (menuElement.Attribute("IsIEOnly").Value.Equals("Y"))
                        {
                            if (!OnInternetExplorer(new HttpRequestWrapper(HttpContext.Current.Request)))
                            {
                                addToList = false;
                            }

                        }

                        if (menuElement.Attribute("ShowForMultipleVPSAccess") != null &&
                            menuElement.Attribute("ShowForMultipleVPSAccess").Value.Equals("Y"))
                        {

                            //                            if (GetVpsList().Count().Equals(1)) //don't show change vps menu if access to one vps only
                            if ((RuntimeContext.Operator != null && !RuntimeContext.Operator.HasMultipleVpsAccess) ||
                                (forOperator == false))
                            {
                                addToList = false;
                            }
                        }

                        if (menuElement.Attribute("IsV1Manager") != null)
                        {
                            string url =
                                String.Format(
                                    "/client/home/V1Manager?objectId={0}&actionId={1}&title={2}&topicName={3}",
                                    menuElement.Element("Object").Value, menuElement.Element("Action").Value,
                                    GetResourceString(menuElement.Element("Title").Value),
                                    menuElement.Attribute("IdToHighlight").Value);

                            if (menuElement.Element("Url") == null)
                            {
                                menuElement.Add(new XElement("Url", url));
                            }
                            else
                            {
                                menuElement.Element("Url").Value = url;
                            }
                        }
                        else if (menuElement.Attribute("IsV1Page") != null)
                        {
                            string url =
                                String.Format(
                                    "/client/home/V1Page?url={0}&topicName={1}",
                                    menuElement.Element("Url").Value,
                                    menuElement.Attribute("IdToHighlight").Value);

                            menuElement.Element("Url").Value = url;
                        }

                        //no need to do this in pegsus, setup page is in legacy only. 
                        /*
                        List<XElement> elements = new List<XElement>();
                        if (menuElement.Attribute("AttachGateways") != null && AtHoc.Web.Common.Infrastracture.Utilities.OnInternetExplorer(
                                    new HttpRequestWrapper(HttpContext.Current.Request))) //attach gateway in the gateway list + Desktop Client Menu (not a gateway)
                        {
                            //see if operator can modify gateways first
                            if (doesOperatorHaveAccess(SystemObject.VirtualSystemDeliveryProtocols,ActionType.Modify)
                            {
                                foreach (DeviceProtocol dp in SetupContext.DeviceProtocols.OrderBy(s => s.DisplayName))
                                {
                                    if (!string.IsNullOrEmpty(dp.DeliveryAgent))
                                    {
                                        XElement newElem = new XElement("Topic",
                                            new XAttribute("IsPopup", "N"),
                                            new XAttribute("IsIEOnly", "Y"),
                                            new XElement("Title", dp.DisplayName));

                                        string explanation = "The settings for this gateway are not available from this page. See the AtHoc Installation Guide to learn how to configure these settings";
                                        if (dp.UIContextExtensionMap.Count > 0)
                                        {
                                            newElem.Add(new XElement("Url",
                                                         String.Format(
                                                             "/client/Setup/Protocol?protocolId={0}&defaultsFlag=false",
                                                             dp.Id)));

                                            explanation = string.IsNullOrEmpty(dp.Description) ? "Click here to setup" : dp.Description;
                                        }

                                        newElem.Add(new XElement("Explanation", explanation));
                                        elements.Add(newElem);
                                    }
                                }
                            }

                            if (addToList)
                            {
                                elements.Add(menuElement);
                            }
                            elements = elements.OrderBy(e => e.Element("Title").Value).ToList(); //sort by title

                            foreach (XElement el in elements)
                            {
                                elementToAddTo.Add(el);
                            }
                        }
                        else
                        {*/
                        if (addToList)
                        {
                            elementToAddTo.Add(menuElement);
                        }
                        /*}*/
                    }
                    break;
                case "Settings":
                case "Main":

                    if (menuElement.Attribute("HideInMenu") != null)
                    {
                        xmlNode.SetAttributeValue("HideInMenu", menuElement.Attribute("HideInMenu").Value);
                    }
                    foreach (var children in menuElement.Elements())
                    {
                        parseTreeNode(ref xmlNode, children, forOperator);
                    }

                    if (xmlNode.Elements().Count() != 0)
                    {
                        //only append element if there is any children
                        elementToAddTo.Add(xmlNode);
                    }
                    break;
                case "Section": //settings page main bucket
                    xmlNode.Add(menuElement.Element("Title"));
                    xmlNode.Add(menuElement.Element("IconCssclass"));
                    xmlNode.Add(menuElement.Attribute("id"));
                    foreach (var children in menuElement.Elements())
                    {
                        parseTreeNode(ref xmlNode, children, forOperator);
                    }

                    if (xmlNode.Elements("Subsection").Count() != 0)
                    {
                        //only append element if there is any children
                        elementToAddTo.Add(xmlNode);
                    }
                    break;
                case "Subsection": //settings page section within bucket (delimited by --)
                    foreach (var children in menuElement.Elements())
                    {
                        parseTreeNode(ref xmlNode, children, forOperator);
                    }

                    if (xmlNode.Elements("Topic").Count() != 0)
                    {
                        //only append element if there is any children
                        elementToAddTo.Add(xmlNode);
                    }
                    break;

            }


        }

        public static bool doesOperatorHaveAccess(string objectId, string actionType)
        {

            var sysObject = EnumUtils<SystemObject>.Parse(objectId);
            var actionEnum = EnumUtils<ActionType>.Parse(actionType);

            return doesOperatorHaveAccess(sysObject, actionEnum);

        }

        public static bool doesOperatorHaveAccess(SystemObject so, ActionType at)
        {

            var operatorObj = RuntimeContext.Operator;
            if (operatorObj == null)
                return true;
            return operatorObj.HasPermission(so, at);

        }

        //keeping this func here so we can keep all the junk from legacy in one place
        public static bool OnInternetExplorer(HttpRequestBase request)
        {
            if (request.Browser.Type.ToUpper().Contains("IE"))
            {
                return true;
            }
            return request.UserAgent != null && request.UserAgent.ToUpper().Contains("TRIDENT");
        }

        //keeping this func here so we can keep all the junk from legacy in one place
        public static string GetLegacyLink(string url)
        {
            return ("/client/{0}".FormatWith(url));
        }

        public static string GetLinkString(XElement topicElement, int tabIndexCounter = 0)
        {
            string linkTag = "<a href=\"#\" onclick=\"{0}\" tabIndex=\"{2}\">{1}</a>";
            var javascriptToExecute = "";
            if (topicElement.Element("Url") != null)
            {
                bool UsePost = false;
                if (topicElement.Element("Url").Attribute("UsePost") != null)
                {
                    UsePost = topicElement.Element("Url").Attribute("UsePost").Value == "Y";
                }

                javascriptToExecute = String.Format("redirectToExternalUrl('{0}',{1})", topicElement.Element("Url").Value, UsePost.ToString().ToLower());
                return String.Format(linkTag, javascriptToExecute,
                    HttpUtility.HtmlEncode(GetResourceString(topicElement.Element("Title").Value)),
                    tabIndexCounter);

            }
            else if (topicElement.Element("Script") != null)
            {
                javascriptToExecute = topicElement.Element("Script").Value;
                return String.Format(linkTag, javascriptToExecute,
                    HttpUtility.HtmlEncode(GetResourceString(topicElement.Element("Title").Value)),
                    tabIndexCounter);
            }
            else if (topicElement.Element("MailTo") != null)
            {
                string mailLinkTag = "<a href=\"{0}\" tabIndex={2}>{1}</a>";

                javascriptToExecute = topicElement.Element("MailTo").Value;
                return String.Format(mailLinkTag, javascriptToExecute,
                    HttpUtility.HtmlEncode(GetResourceString(topicElement.Element("Title").Value)),
                    tabIndexCounter);
            }
            else
            {
                return String.Format("<div class=\"link-disabled\">{0}</div>",
                    GetResourceString(HttpUtility.HtmlEncode(topicElement.Element("Title").Value)));
            }

        }

        public static string GetResourceString(string resourceIndex)
        {
            return IWSResources.ResourceManager.GetString(String.Concat("NavBar_", resourceIndex));
        }
    }

    public enum MenuTopicsId
    {
            alerting,
            users,
            situation,
            settings,
            iwsOperator,
            reports,
            myprofile,
            myactivity,
            inbox,
        
    }
}
