﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web.Helpers;
using AtHoc.Infrastructure.Web.Security;
using System.Web;


namespace AtHoc.Infrastructure.Web.Helpers
{
    public static class AntiForgeryHelper
    {

        public static MvcHtmlString AntiCrossSiteForgeryToken(this HtmlHelper helper)
        {
            return MvcHtmlString.Create(CreateHiddenInputText());
        }

        private static string CreateHiddenInputText()
        {
            return string.Format("<input name='__RequestVerificationToken' type='hidden' value='{0}' />", TokenValue());
        }

        private static string TokenValue()
        {
            string token = AtHocAntiForgery.NewToken();

            if (HttpContext.Current.Session["__RequestVerificationToken"] == null)
            {
                SetupAntiForgeryToken();
            }
            return HttpContext.Current.Session["__RequestVerificationToken"].ToString();
        }

        public static void SetupAntiForgeryToken()
        {
            String antiForgeryCookieName = "__AntiForgeryToken";

           // if (HttpContext.Current.Request.Cookies["__AntiForgeryToken"]) != null.Value

            if (HttpContext.Current.Session["__RequestVerificationToken"] == null)
            {

                var requestHttpCookie = HttpContext.Current.Request.Cookies[antiForgeryCookieName];
                if (requestHttpCookie == null)
                {
                    string token = AtHocAntiForgery.NewToken();
                    HttpContext.Current.Session["__RequestVerificationToken"] = token;

                    requestHttpCookie = new HttpCookie(antiForgeryCookieName, token);
                    requestHttpCookie.HttpOnly = true;
                    requestHttpCookie.Expires = DateTime.Now.AddYears(10);
                    HttpContext.Current.Response.Cookies.Add(requestHttpCookie);
                }
                else
                {
                    HttpContext.Current.Session["__RequestVerificationToken"] = requestHttpCookie.Value;

                    var httpCookie = HttpContext.Current.Response.Cookies[antiForgeryCookieName];
                    if (httpCookie != null)
                    {
                        httpCookie.HttpOnly = true;
                        httpCookie.Value = requestHttpCookie.Value;
                        httpCookie.Expires = DateTime.Now.AddYears(10);

                    }
                    else
                    {
                        httpCookie = new HttpCookie(antiForgeryCookieName, requestHttpCookie.Value);
                        httpCookie.HttpOnly = true;
                        httpCookie.Expires = DateTime.Now.AddYears(10);
                        HttpContext.Current.Response.Cookies.Add(httpCookie);
                    }
                }
            }
        }

    }
}
