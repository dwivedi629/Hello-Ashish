﻿using System.Reflection;
using System.Web.Mvc;

using SimpleInjector;
using SimpleInjector.Integration.Web.Mvc;

namespace AtHoc.Infrastructure.Ioc.SimpleInjector
{
	public static class SimpleInjectorServiceLocatorExtensions
	{
		public static void InitializeDependencyResolver(this IServiceLocator instance, Assembly assembly)
		{
			var container = instance.IocContainer as Container;

			// This is an extension method from the integration package.
			container.RegisterMvcControllers(assembly);

			// This is an extension method from the integration package as well.
			container.RegisterMvcAttributeFilterProvider();

			container.Verify();

			DependencyResolver.SetResolver(new SimpleInjectorDependencyResolver(container));
		}
	}
}