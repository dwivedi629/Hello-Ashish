﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Mvc;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Configurations;
using AtHoc.Infrastructure.Resources;
using System.Text.RegularExpressions;
using System.Web;

namespace AtHoc.Infrastructure.Web
{
    public static class HtmlHelperExtensions
    {
        public static MvcHtmlString CdnScript(this HtmlHelper instance, string relativeUrl)
        {
            var protocol = HttpContext.Current.Request.IsSecureConnection ? "https" : "http";

            return MvcHtmlString.Create("<script src='{0}://{1}/{2}?v={3}' type='text/javascript'></script>"
                .FormatWith(protocol, ConfigService.Current.CdnBaseUrl, relativeUrl, ConfigService.Current.Version));
        }

        public static MvcHtmlString CdnScript(this HtmlHelper instance, string relativeUrl, string[] lang)
        {
            var protocol = HttpContext.Current.Request.IsSecureConnection ? "https" : "http";
            if (lang == null) lang = new[] { "en-us" };
            
            
            return lang.Count() > 0 && lang[0].ToLowerInvariant() != "en-us"?
                                 MvcHtmlString.Create("<script src='{0}://{1}/{2}/{3}?v={4}' type='text/javascript'></script>"
                                .FormatWith(protocol, ConfigService.Current.CdnBaseUrl, relativeUrl, lang[0] + ".js", ConfigService.Current.Version))
                                : MvcHtmlString.Empty;
        }

        public static MvcHtmlString CdnCss(this HtmlHelper instance, string relativeUrl)
        {
            var protocol = HttpContext.Current.Request.IsSecureConnection ? "https" : "http";

            return MvcHtmlString.Create("<link href='{0}://{1}/{2}?v={3}' rel='stylesheet' />"
                .FormatWith(protocol, ConfigService.Current.CdnBaseUrl, relativeUrl, ConfigService.Current.Version));
        }

        public static MvcHtmlString CdnImage(this HtmlHelper instance, string relativeUrl, string title,string className="")
        {
            var protocol = HttpContext.Current.Request.IsSecureConnection ? "https" : "http";

            return MvcHtmlString.Create("<img src='{0}://{1}/{2}' title='{3}' alt='{3}' class='{4}'/>"
                .FormatWith(protocol, ConfigService.Current.CdnBaseUrl, relativeUrl, title,className));
        }

        /// <summary>
        /// IWS script with versioning to avoid cache
        /// </summary>
        /// <param name="instance"></param>
        /// <param name="relativeUrl"></param>
        /// <returns></returns>
        public static MvcHtmlString LocalScript(this HtmlHelper instance, string relativeUrl)
        {
            return MvcHtmlString.Create("<script src='Scripts/{0}?v={1}' type='text/javascript'></script>"
                .FormatWith(relativeUrl, ConfigService.Current.Version));
        }


        public static string CdnUrl(string relativeUrl)
        {
            var protocol = HttpContext.Current.Request.IsSecureConnection ? "https" : "http";

            return "{0}://{1}/{2}".FormatWith(protocol, ConfigService.Current.CdnBaseUrl, relativeUrl);
    
        }

        public static MvcHtmlString IwsScripts(this HtmlHelper instance, string relativeUrl)
        {
            var protocol = HttpContext.Current.Request.IsSecureConnection ? "https" : "http";

            return MvcHtmlString.Create("<script src='{0}://{1}/{2}?locale={3}&v={4}' type='text/javascript'></script>"
                .FormatWith(protocol, ConfigService.Current.IwsBaseUrl, relativeUrl, Thread.CurrentThread.CurrentUICulture.Name, ConfigService.Current.Version));
        }

      

        /* Begin - following functions are used to retrieve resource from legacy cdn. Once we get rid of legacy, we can remove this
         */

        private const string SCRIPT_TAG_TEMPLATE = "<script type=\"text/javascript\" src=\"{0}?version={1}\"></script>";
        /// <summary>
        /// 
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="scriptResource"></param>
        /// <returns></returns>
        /// 
        public static MvcHtmlString LegacyCDNScripts(this HtmlHelper instance, params string[] scriptResources)
        {
            StringBuilder output = new StringBuilder();
            foreach (var resource in scriptResources)
            {
                var targetedUrl = GetRootUrlPart(HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority)) + (resource.StartsWith("/") ? resource : "/" + resource);
                output.AppendFormat(SCRIPT_TAG_TEMPLATE, targetedUrl, ConfigService.Current.Version);
                output.AppendLine();
            }
            return MvcHtmlString.Create(output.ToString());
        }

        const string CDN_ROOT = "CDN";
        const string CDN_ROOT_FOLDER = "Content";
        /// <summary>
        /// 
        /// </summary>
        /// <param name="root"></param>
        /// <returns></returns>
        public static string GetRootUrlPart(string root)
        {
            var cdnPath = CDN_ROOT;
            var ret = string.Empty;
#if (DEBUG)
                var uri = HttpContext.Current.Request.Url;
                var port = ":" + uri.Port;
                var index = root.IndexOf(port);
                if (index > 0) ret = root.Substring(0, index);
                else ret = root;
#else
                ret = "/client/"; //point to legacy cdn
                cdnPath = CDN_ROOT_FOLDER + "/" + CDN_ROOT;
#endif


                return ret + (ret.EndsWith("/") ? cdnPath : "/" + cdnPath);
        }


        /* END - above functions are used to retrieve resource from legacy cdn. Once we get rid of legacy, we can remove this
 */


        public static MvcHtmlString DropDownListForEnum<EnumType>(this HtmlHelper instance, string name, object value, ResourceManager resourceManager)
            where EnumType : struct
        {
            var enumType = typeof(EnumType);

            if (enumType.IsNullable())
                enumType = Nullable.GetUnderlyingType(enumType);

            if (enumType.IsEnum == false)
                throw (new InvalidOperationException("Type ({0}) is not a enum".FormatWith(enumType.FullName)));

            var html = new StringBuilder();
            html.Append("<select id='").Append(name).Append("'>");
            html.Append("<option value=''></option>");

            foreach (var enumValue in Enum.GetValues(enumType))
            {
                html.Append("<option value='").Append(enumValue).Append("'");
                if (enumValue.Equals(value))
                    html.Append(" selected");
                html.Append(">");
                html.Append(resourceManager.GetString(enumValue));
                html.Append("</option>");
            }

            html.Append("</select>");
            return MvcHtmlString.Create(html.ToString());
        }

        public static MvcHtmlString MessagesPanel(this HtmlHelper instance, Messages messages, string id = null)
        {
            var html = new StringBuilder();

            if (id.IsNotNullOrEmpty())
                html.Append("<div id='{0}'>".FormatWith(id));

            if (messages != null && messages.Count > 0)
            {
                var hash = new Dictionary<MessageType, StringBuilder>();
                foreach (var message in messages)
                {
                    if (hash.ContainsKey(message.Type) == false)
                        hash[message.Type] = new StringBuilder();

                    hash[message.Type].Append("<li>").Append(message.Value).Append("</li>");
                }

                if (hash.ContainsKey(MessageType.Information))
                    html.Append("<div class='alert alert-info'><button type='button' class='close' data-dismiss='alert'>&times;</button><h4>Information</h4><ul>")
                        .Append(hash[MessageType.Information].ToString()).Append("</ul></div>");

                if (hash.ContainsKey(MessageType.Warning))
                    html.Append("<div class='alert alert-block'><button type='button' class='close' data-dismiss='alert'>&times;</button><h4>Warning</h4><ul>")
                        .Append(hash[MessageType.Warning].ToString()).Append("</ul></div>");

                if (hash.ContainsKey(MessageType.Error))
                    html.Append("<div class='alert alert-error'><button type='button' class='close' data-dismiss='alert'>&times;</button><h4>Error</h4><ul>")
                        .Append(hash[MessageType.Error].ToString()).Append("</ul></div>");

                if (hash.ContainsKey(MessageType.Success))
                    html.Append("<div class='alert alert-success'><button type='button' class='close' data-dismiss='alert'>&times;</button><h4>Success</h4><ul>")
                        .Append(hash[MessageType.Success].ToString()).Append("</ul></div>");
            }

            if (id.IsNotNullOrEmpty())
                html.Append("</div>");

            return MvcHtmlString.Create(html.ToString());
        }

        public static MvcHtmlString ResourceStrings(this HtmlHelper instance, Type enumType, ResourceManager resourceManager)
        {
            if (enumType == null)
                throw (new ArgumentNullException("enumType"));

            if (enumType.IsEnum == false && (enumType.IsNullable() == false || Nullable.GetUnderlyingType(enumType).IsEnum == false))
                throw (new ArgumentException("enumType ({0}) is not an enum type".FormatWith(enumType.FullName)));

            if (resourceManager == null)
                throw (new ArgumentNullException("resourceManager"));

            var actualEnumType = enumType.IsEnum ? enumType : Nullable.GetUnderlyingType(enumType);

            var html = new StringBuilder();
            bool looped = false;
            html.Append("var ").Append(actualEnumType.Name).Append(" = {");
            foreach (var value in Enum.GetValues(actualEnumType))
            {
                if (looped)
                    html.Append(",");

                html.Append("\"").Append((int)value).Append("\":\"").Append(resourceManager.GetString(value)).Append("\"");
                looped = true;
            }
            html.Append("};");

            return MvcHtmlString.Create(html.ToString());
        }

        public static MvcHtmlString ResourceStrings(this HtmlHelper instance, string keyPattern, ResourceManager resourceManager)
        {
            var html = GetResourceSetByPattern(keyPattern, resourceManager);

            return MvcHtmlString.Create(html.ToString());
        }

        public static StringBuilder GetResourceSetByPattern(string keyPattern, ResourceManager resourceManager)
        {
            if (keyPattern.IsNullOrEmpty())
            {
                throw (new ArgumentNullException("keyPattern"));
            }
            if (resourceManager == null)
            {
                throw (new ArgumentNullException("resourceManager"));
            }

            var html = new StringBuilder();
            bool looped = false;
            html.Append("").Append("{");
            foreach (var key in resourceManager.Keys().Where(x => Regex.IsMatch(x, keyPattern)))
            {
                if (looped)
                    html.Append(",");
                html.Append(key).Append(":\"").Append(resourceManager.GetString(key)).Append("\"");
                looped = true;
            }
            html.Append("}");
            return html;
        }

        public static bool IsRtlLanguage(this HtmlHelper instance)
        {
            var request = HttpContext.Current.Request;
            return (request.UserLanguages != null && request.UserLanguages.Length > 0 &&
                   (request.UserLanguages[0].Substring(0, 2).ToLower() == "ar" || request.UserLanguages[0].Substring(0, 2).ToLower() == "he"));
        }

        /// <summary>
        /// Returns the Html after replacing these Html tags (script|embed|input|object|frameset|frame|iframe|meta|link|style) with empty strings
        /// </summary>
        /// <param name="inputString"></param>
        /// <returns></returns>
        public static string SanitizeHtml(string inputString)
        {
            const string HTML_TAG_PATTERN = "</?(?i:script|embed|input|object|frameset|frame|iframe|meta|link|style)(.|\n)*?>";
            return Regex.Replace
              (inputString, HTML_TAG_PATTERN, string.Empty);
        }

    }
}
