﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace AtHoc.Infrastructure.Web
{
    public static class ControllerExtensions
    {
        public static bool IsPosted(this Controller instance)
        {
            if (instance != null &&
                instance.Request.ServerVariables["REQUEST_METHOD"] == "POST")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
