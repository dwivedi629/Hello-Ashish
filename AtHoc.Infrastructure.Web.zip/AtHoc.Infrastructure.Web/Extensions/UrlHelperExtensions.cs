﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Configurations;

namespace AtHoc.Infrastructure.Web
{
    public static class UrlHelperExtensions
    {
        public static string Cdn(this UrlHelper instance, string relativeUrl)
        {
            var protocol = HttpContext.Current.Request.IsSecureConnection ? "https" : "http";

            return "{0}://{1}/{2}".FormatWith(protocol, ConfigService.Current.CdnBaseUrl, relativeUrl);
        }

        public static string HelpLink(this UrlHelper instance, System.Resources.ResourceManager resourceManager)
        {
            if (instance == null) throw new ArgumentNullException("instance");
            if (resourceManager == null) throw new ArgumentNullException("resourceManager");

            var controllerName = instance.RequestContext.RouteData.GetRequiredString("controller");
            var actionName = instance.RequestContext.RouteData.GetRequiredString("action");

            resourceManager.IgnoreCase = true;

            var helpLink = resourceManager.GetString(string.Format("HelpLinks_{0}_{1}", controllerName, actionName));
            if (string.IsNullOrEmpty(helpLink))
            {

                helpLink = resourceManager.GetString(string.Format("HelpLinks_{0}_Index", controllerName));

                if (string.IsNullOrEmpty(helpLink))
                {
                    var areaName = instance.RequestContext.RouteData.DataTokens["area"];
                    helpLink = resourceManager.GetString(string.Format("HelpLinks_{0}_{1}_{2}", areaName, controllerName, actionName));
                }

                if (string.IsNullOrEmpty(helpLink))
                    helpLink = resourceManager.GetString("HelpLinks_Home_Index");
            }

            return helpLink;
        }
    }
}
