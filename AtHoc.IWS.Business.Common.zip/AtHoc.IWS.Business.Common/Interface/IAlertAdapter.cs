﻿namespace AtHoc.IWS.Business.Common.Interface
{
    public interface IAlertAdapter
    {
        int PopulateRecipients(int alertId, int providerId,string providerBaseLocale, int operatorId);
        void PopulateBatch(int alertId, bool isRegularAlert, bool isMassDevice);
        void OnAlertPubished(int alertId,int providerId, int operatorId);
    }
}
