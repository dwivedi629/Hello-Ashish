﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Reports;
using System.Xml;

namespace AtHoc.IWS.Business.Common.Interface
{
    public interface IReportAdapter
    {

        int GetMobileAppUserCount(int providerId,
                        string deviceIDList,
                        int userSearchSessionId,
                        XmlDocument targetedUsersXml,
                        int operatorId, string deviceId);
        int GetNoDeviceUserCount();

    }
}
