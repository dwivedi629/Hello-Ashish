﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Ioc.SimpleInjector;
using AtHoc.IWS.Business.Common.Interface;

namespace AtHoc.IWS.Business.Common.Impl
{
    public class AlertPublishHelper
    {
        private readonly IAlertAdapter _adapter;

        public AlertPublishHelper()
        {
            _adapter = ServiceLocator.Resolve<IAlertAdapter>();
        }

        public int PopulateRecipients(int alertId, int providerId,string providerLocale, int operatorId)
        {
            return _adapter.PopulateRecipients(alertId, providerId,providerLocale, operatorId);
        }

        public void PopulateBatch(int alertId, bool isRegularAlert, bool isMassDevice)
        {
            _adapter.PopulateBatch(alertId, isRegularAlert, isMassDevice);
        }

        public void OnPublishAlert(int alertId, int providerId, int operatorId)
        {
            _adapter.OnAlertPubished(alertId, providerId, operatorId);
        }
    }
}
