﻿using AtHoc.IWS.Business.Common.Interface;
using AtHoc.Reports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace AtHoc.IWS.Business.Common.Impl
{
    public class ReportAdapter : IReportAdapter
    {

        private ReportData _deviceSummaryData = null;

        private ReportData DeviceSummaryData
        {
            get { return _deviceSummaryData; }
            set { _deviceSummaryData = value; }
        }

        public int GetMobileAppUserCount(int providerId,
                        string deviceIDList,
                        int userSearchSessionId,
                        XmlDocument targetedUsersXml,
                        int operatorId,string deviceId)
        {
            var reportObj = new ReportGenerator();
            _deviceSummaryData = reportObj.GetUserDeviceCoverageSummaryOverall(providerId, deviceIDList, userSearchSessionId, targetedUsersXml, operatorId);
            return _deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == deviceId) != null ? Convert.ToInt32(_deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == deviceId).Value) : 0;
        }

        public int GetNoDeviceUserCount()
        {
            string totalUsersId = "totalUsers";
            int totalUsers = _deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == totalUsersId) != null ? Convert.ToInt32(_deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == totalUsersId).Value) : 0;
            string totalCoveredId = "totalCovered";
            int totalCovered= _deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == totalCoveredId) != null ? Convert.ToInt32(_deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == totalCoveredId).Value) : 0;
            return totalUsers - totalCovered;
        }
    }
}
