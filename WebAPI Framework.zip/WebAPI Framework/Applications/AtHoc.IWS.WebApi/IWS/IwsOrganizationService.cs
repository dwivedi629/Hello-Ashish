﻿using System;
using System.Collections.Generic;
using System.IO;
using AtHoc.IWS.Extensions;
using AtHoc.IWS.WebApi.Models;
using AtHoc.MediaServices;
using AtHoc.VirtualSystems;
using WebGrease.Css.Extensions;

namespace AtHoc.IWS.WebApi.IWS
{
    public class IwsOrganizationService
    {
        private readonly VirtualSystemService _vpsSvc;
        public IwsOrganizationService()
        {
            _vpsSvc = new VirtualSystemService();
        }
        public bool OrgExists(int orgId)
        {
            return !string.IsNullOrEmpty(_vpsSvc.GetProviderNameById(orgId));
        }
        public bool OrgExists(string orgName)
        {
            return _vpsSvc.GetProviderIdByName(orgName) > 0;
        }

        public int CreateOrganization(OrgTemplateType orgTemplateType, string locale, string name, string orgCode, bool isEnterprise, int? enterpriseProviderId, LogoInfo logo)
        {
            var vpsId = _vpsSvc.DuplicateProviderByLocale(orgTemplateType.GetEnumDescription(), locale, name, orgCode, 1, isEnterprise, enterpriseProviderId);
            
            var webLogoImageGuid = UploadImage(logo);
            if (webLogoImageGuid != Guid.Empty)
            {
                var vps = _vpsSvc.GetById(vpsId);
                vps.WebLogoImageId = webLogoImageGuid.ToString().ToUpper();
                _vpsSvc.UpdateVps(vps);
            }

            return vpsId;
        }

        public IEnumerable<VpsInfo> GetOrganizations()
        {
            var vs = _vpsSvc.GetAll();
            var list = new List<VpsInfo>();
            vs.ForEach(v => list.Add(new VpsInfo(v.Id, v.Name, v.OrgCode, v.ProviderType)));
            return list;
        }

        public VpsInfo GetOrganizationById(int id)
        {
            var vs = _vpsSvc.GetById(id);

            return new VpsInfo(vs.Id, vs.Name, vs.OrgCode, vs.ProviderType);
        }

        public Guid UploadImage(LogoInfo logo)
        {
            if (logo == null || String.IsNullOrEmpty(logo.LogoContent) || String.IsNullOrEmpty(logo.LogoContent.Trim())) return Guid.Empty;

            //http://stackoverflow.com/questions/351126/convert-a-string-to-stream

            var rawLogo = Convert.FromBase64String(logo.LogoContent);
            var streamLogo = new MemoryStream(rawLogo);

            var wMediaInfo = new MediaInfo
            {
                Source = @"Web Logo",
                Description = "",
                AllowWebAccess = true,
                ContentType = "image/" + logo.Extension,
                Extension = logo.Extension,
                Height = 0,
                Width = 0,
                Rotation = 0
            };

            Guid mediaId;
            var service = new MediaService();
            var content = service.CreateMedia(wMediaInfo, out mediaId);
            content.SetContent(streamLogo);
            return mediaId;
        }
    }

    public class VpsInfo
    {
        public VpsInfo(int providerId)
        {
            ProviderId = providerId;
        }

        public VpsInfo(int providerId, string name) : this(providerId)
        {
            Name = name;
        }

        public VpsInfo(int providerId, string name, string orgCode) : this(providerId, name)
        {
            OrgCode = orgCode;
        }

        public VpsInfo(int providerId, string name, string orgCode, VPSType providerType) : this(providerId, name, orgCode)
        {
            switch (providerType)
            {
                case VPSType.Parking:
                    ProviderType = "PARKING";
                    break;
                case VPSType.System:
                    ProviderType = "SYSTEM";
                    break;
                case VPSType.EnterpriseTemplate:
                    ProviderType = "ENTTEMPLATE";
                    break;
                case VPSType.Enterprise:
                    ProviderType = "ENTERPRISE";
                    break;
                case VPSType.Sub:
                    ProviderType = "SUB";
                    break;
                case VPSType.Affiliate25Template:
                    ProviderType = "AFF25TEMPLATE";
                    break;
                case VPSType.Affiliate25:
                    ProviderType = "AFF25";
                    break;
                default:
                    throw new Exception("Invalid ProviderType Encountered in PRV_EXTENDED_PARAMS_TAB");
            }
        }

        public VpsInfo(int providerId, string name, string orgCode, VPSType providerType, string base64Logo) : this(providerId, name, orgCode, providerType)
        {
            Base64Logo = base64Logo;
        }

        public int ProviderId { get; set; }
        public string Name { get; set; }
        public string OrgCode { get; set; }
        public string ProviderType { get; set; }
        public string Base64Logo { get; set; }
    }
}