﻿#region Pegasus References

//using AtHoc.Global.Resources.Implementations;
//using AtHoc.Global.Resources.Interfaces;
//using AtHoc.Infrastructure.Accessor;
//using AtHoc.Infrastructure.Accessor.Default;
//using AtHoc.Infrastructure.Cache;
//using AtHoc.Infrastructure.Configurations;
//using AtHoc.Infrastructure.Converter;
//using AtHoc.Infrastructure.Converter.Default;
//using AtHoc.Infrastructure.Csv;
//using AtHoc.Infrastructure.Csv.CsvHelper;
//using AtHoc.Infrastructure.Encryption;
//using AtHoc.Infrastructure.Encryption.Default;
//using AtHoc.Infrastructure.Ioc;
//using AtHoc.Infrastructure.Log;
//using AtHoc.Infrastructure.Log.EventLog;
//using AtHoc.Infrastructure.Serialization;
//using AtHoc.Infrastructure.Serialization.DataContract;
//using AtHoc.Infrastructure.Serialization.JsonNet;
//using AtHoc.Infrastructure.Sql;
//using AtHoc.Infrastructure.Validation;
//using AtHoc.Infrastructure.Validation.Default;
//using AtHoc.IWS.Business.Cache.Impl;
//using AtHoc.IWS.Business.Common.Interface;
//using AtHoc.IWS.Business.Configurations;
//using AtHoc.IWS.Business.Context;
//using AtHoc.IWS.Business.Converter;
//using AtHoc.IWS.Business.Data;
//using AtHoc.IWS.Business.Database;
//using AtHoc.IWS.Business.Domain;
//using AtHoc.IWS.Business.Domain.Audit;
//using AtHoc.IWS.Business.Domain.Authorization;
//using AtHoc.IWS.Business.Domain.Authorization.Impl;
//using AtHoc.IWS.Business.Domain.CustomAttributes;
//using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
//using AtHoc.IWS.Business.Domain.Devices;
//using AtHoc.IWS.Business.Domain.Devices.Impl;
//using AtHoc.IWS.Business.Domain.Events;
//using AtHoc.IWS.Business.Domain.Map;
//using AtHoc.IWS.Business.Domain.Map.Impl;
//using AtHoc.IWS.Business.Domain.Media;
//using AtHoc.IWS.Business.Domain.Media.Impl;
//using AtHoc.IWS.Business.Domain.Notification;
//using AtHoc.IWS.Business.Domain.Organization;
//using AtHoc.IWS.Business.Domain.Organization.Impl;
//using AtHoc.IWS.Business.Domain.PageLayout;
//using AtHoc.IWS.Business.Domain.PageLayout.Impl;
//using AtHoc.IWS.Business.Domain.Publishing;
//using AtHoc.IWS.Business.Domain.Publishing.Impl;
//using AtHoc.IWS.Business.Domain.Reports;
//using AtHoc.IWS.Business.Domain.Reports.Impl;
//using AtHoc.IWS.Business.Domain.RuleModel;
//using AtHoc.IWS.Business.Domain.RuleModel.Impl;
//using AtHoc.IWS.Business.Domain.SelfService;
//using AtHoc.IWS.Business.Domain.SelfService.Impl;
//using AtHoc.IWS.Business.Domain.Settings;
//using AtHoc.IWS.Business.Domain.Settings.Impl;
//using AtHoc.IWS.Business.Domain.Systems;
//using AtHoc.IWS.Business.Domain.Systems.Impl;
//using AtHoc.IWS.Business.Domain.Targeting;
//using AtHoc.IWS.Business.Domain.Targeting.Impl;
//using AtHoc.IWS.Business.Domain.Users;
//using AtHoc.IWS.Business.Domain.Users.Impl;
//using AtHoc.IWS.Business.Domain.VirtualSystem;
//using AtHoc.IWS.Business.Domain.VirtualSystem.Impl;
//using AtHoc.IWS.Business.Encryption;
//using AtHoc.IWS.Business.Ioc;
//using AtHoc.IWS.Business.Service;
//using AtHoc.IWS.Business.Shedule;
//using AtHoc.IWS.Business.Shedule.Impl;

#endregion

using AtHoc.IWS.Devices.Business;
using AtHoc.IWS.Devices.Services;
using AtHoc.IWS.Global.DataAccess;
using AtHoc.IWS.Interfaces.Business;
using AtHoc.IWS.Interfaces.Business.Devices;
using AtHoc.IWS.Interfaces.Business.Users;
using AtHoc.IWS.Interfaces.DataAccess;
using AtHoc.IWS.Interfaces.DataAccess.Devices;
using AtHoc.IWS.Interfaces.DataAccess.Global;
using AtHoc.IWS.Interfaces.DataAccess.Users;
using AtHoc.IWS.Interfaces.Services;
using AtHoc.IWS.Interfaces.Services.Devices;
using AtHoc.IWS.Interfaces.Services.Users;
using AtHoc.IWS.Users.Business;
using AtHoc.IWS.Users.DataAccess;
using AtHoc.IWS.Users.Services;
using SimpleInjector;
using SimpleInjector.Integration.WebApi;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace AtHoc.IWS.WebApi
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            //// 1. Create a new Simple Injector container
            var container = new Container();

            container.Options.DefaultScopedLifestyle = new WebApiRequestLifestyle();
            container.Options.ResolveUnregisteredCollections = false;

            // 2. Configure the container (register)
            container.Register<IDbConnection>(() => new SqlConnection(), Lifestyle.Scoped);
            container.Register<IConfigSettings, ConfigSettings>(Lifestyle.Singleton);

            container.Register<IUserService, UserService>();
            container.Register<IUserSyncService, UserSyncService>();
            container.Register<IUserSearchService, UserSearchService>();
            container.Register<IDeviceGroupService, DeviceGroupService>();
            container.Register<IDeviceService, DeviceService>();

            container.Register<IUserManager, UserManager>();
            container.Register<IUserSyncManager, UserSyncManager>();
            container.Register<IUserSearchManager, UserSearchManager>();
            container.Register<IOperatorManager, OperatorManager>();
            container.Register<IDeviceGroupManager, DeviceGroupManager>();
            container.Register<IDeviceManager, DeviceManager>();

            container.Register<IUserRepository, UserRepository>();
            container.Register<IUserSearchRepository, UserSearchRepository>();
            container.Register<IGlobalRepository, GlobalRepository>();
            container.Register<IUserAttributesRepository, UserAttributesRepository>();
            container.Register<IUserDevicesRepository, UserDevicesRepository>();
            container.Register<IUserRolesRepository, UserRolesRepository>();
            container.Register<IOperatorRepository, OperatorRepository>();
            container.Register<IDeviceGroupRepository, DeviceGroupRepository>();
            container.Register<IDeviceRepository, DeviceRepository>();

            // 3. Optionally verify the container's configuration.
            container.RegisterWebApiControllers(GlobalConfiguration.Configuration);
            container.Verify();
            
            // 4. Register the container as MVC3 IDependencyResolver.
            //DependencyResolver.SetResolver(container);
            GlobalConfiguration.Configuration.DependencyResolver = new SimpleInjectorWebApiDependencyResolver(container);
        }

        protected void Application_PreRequestHandlerExecute(Object sender, EventArgs e)
        {
            
        }
    }

    public class ConfigSettings : IConfigSettings
    {
        public string DatabaseConnectionString
        {
            get
            {
                const string registry = @"HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\AtHocServer";
                var value = (string)Microsoft.Win32.Registry.GetValue(registry, "OleDbConnectionString", string.Empty);
                return value.Replace("Provider=SQLOLEDB.1;", "");
            }
        }

        public int CacheTimeout { get; set; }

        public int LogLevel { get; set; }
    }
}
