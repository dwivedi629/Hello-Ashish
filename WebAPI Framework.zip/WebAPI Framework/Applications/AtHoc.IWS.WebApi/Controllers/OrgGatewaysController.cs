﻿using AtHoc.Devices;
using AtHoc.Diagnostics;
using AtHoc.EntityExtension;
using AtHoc.IWS.WebApi.IWS;
using AtHoc.IWS.WebApi.Models;
using AtHoc.Utilities;
using System;
using System.ComponentModel;
using System.Web.Http;

namespace AtHoc.IWS.WebApi.Controllers
{
    public class OrgGatewaysController : ApiController
    {
        #region Private Members

        private enum OrganizationGatewayErrors
        {
            [Description("None")]
            None = -1,
            [Description("Organization not found")]
            OrganizationNotFound = 1,
            [Description("Invalid Gateway ID")]
            InvalidGatewayId = 2,
            [Description("Invalid Gateway Service Url")]
            InvalidGatewayServiceUrl = 3,
            [Description("Invalid Gateway Username")]
            InvalidGatewayUsername = 4,
            [Description("Invalid Gateway Password")]
            InvalidGatewayPassword = 5,
            [Description("Gateway Settings Not Found")]
            GatewaySettingsNotFound = 6
        }

        #endregion

        #region Public Methods

        [HttpGet]
        [Route("organizations/{orgId}/gateways/{gatewayId?}")]
        public IHttpActionResult Get(int orgId, string gatewayId = null)
        {
            try
            {
                return Ok("OrganizationGateways : GET : SUCCESS" + gatewayId);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Get gateway request: {0}, ", ex.Message));
                return InternalServerError(ex);
            }
        }

        [HttpPut]
        [Route("organizations/{orgId}/gateways/{gatewayId}")]
        public IHttpActionResult Put(int orgId, string gatewayId, [FromBody]Gateway gateway)
        {
            try
            {
                var validationResult = ValidateGatewayParameters(orgId, gatewayId, gateway);
                if (validationResult != OrganizationGatewayErrors.None) return BadRequest(validationResult.GetEnumDescription());

                var updateResult = UpdateOrganizationGateway(orgId, gatewayId, gateway);
                if (updateResult == OrganizationGatewayErrors.None) return Ok(gateway);

                return BadRequest(updateResult.GetEnumDescription());
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Update gateway request: {0}, ", gateway.Serialize()), ex);
                return InternalServerError(ex);
            }
        }

        #endregion

        #region Private Methods

        private static OrganizationGatewayErrors ValidateGatewayParameters(int orgId, string gatewayId, Gateway g)
        {
            var svc = new IwsOrganizationService();
            
            if (!svc.OrgExists(orgId)) return OrganizationGatewayErrors.OrganizationNotFound;
            if (string.IsNullOrEmpty(gatewayId)) return OrganizationGatewayErrors.InvalidGatewayId;
            if (string.IsNullOrEmpty(g.Url)) return OrganizationGatewayErrors.InvalidGatewayServiceUrl;
            if (string.IsNullOrEmpty(g.Username)) return OrganizationGatewayErrors.InvalidGatewayUsername;
            if (string.IsNullOrEmpty(g.Password)) return OrganizationGatewayErrors.InvalidGatewayPassword;

            return OrganizationGatewayErrors.None;
        }

        private static OrganizationGatewayErrors UpdateOrganizationGateway(int orgId, string gatewayId, Gateway g)
        {
            var protocolCn = gatewayId;
            //protocolCN = GetProtocolCN(g.DeviceType);

            var protocol = DeviceProtocol.GetProtocol(protocolCn);
            if (protocol == null) return OrganizationGatewayErrors.InvalidGatewayId;

            var mgr = new ExtensionManager();
            
            var settings = mgr.GetSettings(protocol, protocol.Id, "Setup", orgId, protocol.UIContextExtensionMap["Setup"]);

            if (settings != null)
            {
                SetSettings(settings, g.Url, g.Username, g.Password);

                var def = mgr.GetDefinition(protocol, protocol.Id, "Setup", orgId);
                mgr.SetSettings(protocol, protocol.Id, "Setup", orgId, def.Id, settings);

                // Disable device if username is empty
                //if (string.IsNullOrEmpty(g.Username))
                //    DisableDevice(vpsId, GetDeviceId(g.DeviceType));

                return OrganizationGatewayErrors.None;
            }

            return OrganizationGatewayErrors.GatewaySettingsNotFound;
        }

        private static void SetSettings(ExtensionSettings settings, string url, string username, string password)
        {
            var urlNode = settings.Transformed.SelectSingleNode("//endPoint");
            if (urlNode != null) urlNode.InnerText = url;

            var unNode = settings.Transformed.SelectSingleNode("//username");
            if (unNode != null) unNode.InnerText = username;

            var pswNode = settings.Transformed.SelectSingleNode("//password");
            if (pswNode != null) pswNode.InnerText = password;

            var list = settings.Raw.SelectNodes("//data/element");
            if (list != null)
            {
                for (var i = 0; i < list.Count; i++)
                {
                    var node = list[i];
                    if (node.Attributes != null)
                    {
                        var attr = node.Attributes["id"];
                        if (attr.Value.Contains("ServerURL"))
                        {
                            node.InnerText = url;
                        }
                        else if (attr.Value.Contains("Username"))
                        {
                            node.InnerText = username;
                        }
                        else if (attr.Value.Contains("Password"))
                        {
                            node.InnerText = password;
                        }
                    }
                }
            }
        }

        //private void DisableDevice(int vpsId, int deviceId)
        //{
        //    var mgr = new DeviceManager(vpsId);
        //    var device = mgr.GetDevice(deviceId);
        //    var list = new List<Device>();
        //    list.Add(device);
        //    DeviceManager.Disable(list, vpsId);
        //}

        //private string GetProtocolCN(string deviceType)
        //{
        //    switch (deviceType)
        //    {
        //        case "TAS":
        //            return "ATHOC-NDMS-EAST";
        //        case "SMS":
        //            return "ATHOC-NDMS-WEST";
        //        case "EMAIL":
        //            return "UAP_SMTP";
        //        case "MPN":
        //            return "UAP_MPN";
        //        default:
        //            return "";
        //    }
        //}

        //private int GetDeviceId(string deviceType)
        //{
        //    switch (deviceType)
        //    {
        //        case "TAS":
        //            return 1001;
        //        case "SMS":
        //            return 1006;
        //        case "EMAIL":
        //            return 11;
        //        case "MPN":
        //            return 1033;
        //        default:
        //            return 0;
        //    }
        //}

        #endregion
    }
}