﻿using System.Web.Http;
using AtHoc.Diagnostics;
using AtHoc.IWS.Models.Orgs;
using AtHoc.IWS.WebApi.IWS;
using AtHoc.IWS.WebApi.Models;
using AtHoc.Utilities;
using System;
using System.Linq;
using System.Threading;

namespace AtHoc.IWS.WebApi.Controllers
{
    public class OrganizationsController : ApiController
    {
        #region Constants

        private const string OrganizationTypeIsUnknown = "Organization:TypeIsUnknown";
        private const string OrganizationLocaleIsNullOrEmpty = "Organization:LocaleIsNullOrEmpty";
        private const string OrganizationNameIsNullOrEmpty = "Organization:NameIsNullOrEmpty";
        private const string OrganizationNameAlreadyExists = "Organization:NameAlreadyExists";
        private const string SubOrganizationMustHaveEnterprise = "Organization:SubOrganizationMustHaveEnterprise";

        #endregion

        #region Public Methods

        [HttpGet]
        [Route("organizations/{orgId?}")]
        public IHttpActionResult Get(int? orgId = null)
        {
            try
            {
                var svc = new IwsOrganizationService();
                var orgs = svc.GetOrganizations();
                var result = (from o in orgs where (orgId == null || o.ProviderId == orgId) select new Organization { Id = o.ProviderId, Name = o.Name, OrgCode = o.OrgCode, Type = o.ProviderType }).ToList();
                if (result.Count == 0) return NotFound();
                return Ok(result);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Organizations: GET"), ex);
                return InternalServerError(ex);
            }
        }

        [HttpPost]
        [Route("organizations")]
        public IHttpActionResult Post([FromBody]OrganizationSpec org)
        {
            try
            {
                var locale = Thread.CurrentThread.CurrentCulture.Name;

                var svc = new IwsOrganizationService();

                if (org.OrgTemplateType == OrgTemplateType.Unknown) return BadRequest(OrganizationTypeIsUnknown);
                if (string.IsNullOrEmpty(org.Locale)) return BadRequest(OrganizationLocaleIsNullOrEmpty);
                if (string.IsNullOrEmpty(org.Name)) return BadRequest(OrganizationNameIsNullOrEmpty);
                if (svc.OrgExists(org.Name)) return BadRequest(OrganizationNameAlreadyExists);
                if (org.OrgTemplateType == OrgTemplateType.Sub && (org.EnterpriseProviderId == null || org.EnterpriseProviderId <= 2000000)) return BadRequest(SubOrganizationMustHaveEnterprise);

                var isEnterprise = org.OrgTemplateType == OrgTemplateType.Enterprise || org.OrgTemplateType == OrgTemplateType.Basic;

                org.Id = svc.CreateOrganization(org.OrgTemplateType, locale, org.Name, org.OrgCode, isEnterprise, org.EnterpriseProviderId, org.Logo);

                if (org.Id > 0)
                {
                    return Created(Request.RequestUri + "/" + org.Id, org);
                }

                return InternalServerError();
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Organizations: NEW - {0}, ", org.Serialize()), ex);
                return InternalServerError(ex);
            }
        }

        #endregion
    }
}