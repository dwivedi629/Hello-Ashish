﻿using System.Collections.Generic;
using System.Threading;
using AtHoc.Diagnostics;
using AtHoc.IWS.Interfaces.Services;
using AtHoc.IWS.Interfaces.Services.Users;
using AtHoc.IWS.Models.Users;
using AtHoc.IWS.Models.UserSearch;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Linq;
using System.Web.Http;
using Newtonsoft.Json.Linq;

namespace AtHoc.IWS.WebApi.Controllers
{
    public class OrgUsersController : ApiController
    {
        #region Private Members

        private readonly IUserService _userService;
        private readonly IUserSyncService _userSyncService;
        private readonly IUserSearchService _userSearchService;

        #endregion

        #region Constructors

        public OrgUsersController(IUserService userService, IUserSyncService userSyncService, IUserSearchService userSearchService)
        {
            _userService = userService;
            _userSyncService = userSyncService;
            _userSearchService = userSearchService;
        }

        #endregion

        #region Public Methods

        [HttpPost]
        [Route("organizations/{orgId}/users")]
        public IHttpActionResult Post(int orgId, [FromBody]DataTable payload)
        {
            EventLogger.WriteInformation(string.Format("SyncByCommonNames {0}", JsonConvert.SerializeObject(payload)));

            try
            {
                var locale = Thread.CurrentThread.CurrentCulture.Name;

                var result = _userSyncService.SyncByCommonNames(payload, orgId, locale);

                if (result.Status == Status.Success) return Ok(result.Value);

                return BadRequest(String.Join(";", result.Errors));
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Create User(s) by Common Names: {0}, ", JsonConvert.SerializeObject(payload)), ex);
                return InternalServerError(ex);
            }
        }

        [HttpPost]
        [Route("organizations/{orgId}/users/SearchWithinContext")]
        public IHttpActionResult SearchWithinContext(int orgId, [FromBody]UserSearchArgs args)
        {
            try
            {
                var result = _userSearchService.SearchUsersWithinContext(args);

                if (result.Status == Status.Failure)
                {
                    return BadRequest(result.Errors.Aggregate("", (current, error) => current + (error + ";")));
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("SearchWithinContext: EXCEPTION {0}, ", JsonConvert.SerializeObject(new { args })), ex);
                return InternalServerError(ex);
            }
        }

        [HttpPost]
        [Route("organizations/{orgId}/users/SearchWithinSession")]
        public IHttpActionResult SearchWithinSession(int orgId, [FromBody]UserSearchSession args)
        {
            try
            {
                var result = _userSearchService.SearchUsersWithinSession(args);

                if (result.Status == Status.Failure)
                {
                    return BadRequest(result.Errors.Aggregate("", (current, error) => current + (error + ";")));
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("SearchWithinSession: EXCEPTION {0}, ", JsonConvert.SerializeObject(new { args })), ex);
                return InternalServerError(ex);
            }
        }

        [HttpPost]
        [Route("organizations/{orgId}/users/SearchWithinAlert")]
        public IHttpActionResult SearchWithinAlert(int orgId, [FromBody]UserSearchAlert args)
        {
            try
            {
                var result = _userSearchService.SearchUsersWithinAlert(args);

                if (result.Status == Status.Failure)
                {
                    return BadRequest(result.Errors.Aggregate("", (current, error) => current + (error + ";")));
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("SearchWithinAlert: EXCEPTION {0}, ", JsonConvert.SerializeObject(new { args })), ex);
                return InternalServerError(ex);
            }
        }

        [HttpPut]
        [Route("organizations/{orgId}/users/MoveUserToOrg")]
        public IHttpActionResult MoveUserToOrg([FromBody]User user)
        {
            try
            {
                var result = _userService.MoveUserToOrg(user);

                if (result.Status == Status.Failure)
                {
                    return BadRequest(result.Errors.Aggregate("", (current, error) => current + (error + ";")));
                }

                return Ok(user);
                //EventLogger.WriteError(string.Format("Move User to Organization: {0}, ", JsonConvert.SerializeObject(new { user })), );
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("MoveUserToOrg: EXCEPTION {0}, ", JsonConvert.SerializeObject(new { user })), ex);
                return InternalServerError(ex);
            }
        }

        [HttpGet]
        [Route("organizations/{orgId}/users/SearchSampleJson")]
        public IHttpActionResult SearchSampleJson(int orgId)
        {
            var args = new UserSearchArgs
            {
                ProviderId = orgId,
                ProviderCriteria = new VPSCriteria(0, CriteriaOperator.Contains, orgId),
                TargetAllUserBase = true,
                AttributeNames = new List<string> { "LOGIN_ID", "FIRSTNAME", "LASTNAME", "DISPLAYNAME", "STATUS" },
                TargetCriteria = new AttributeCriteria(128, CriteriaOperator.StartsWith, "T") & new AttributeCriteria(126, CriteriaOperator.Contains, "BB"),
                DeviceNames = new List<string>()
            };

            return Ok(args);
        }

        #endregion

        #region Private Methods



        #endregion
    }
}
