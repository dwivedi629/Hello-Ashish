﻿using System.Collections.Generic;
using System.Threading;
using AtHoc.Diagnostics;
using AtHoc.IWS.Interfaces.Services;
using AtHoc.IWS.Interfaces.Services.Devices;
using System;
using System.Web.Http;

namespace AtHoc.IWS.WebApi.Controllers
{
    public class DevicesController : ApiController
    {
        #region Private Members

        private readonly IDeviceService _deviceService;

        #endregion

        #region Constructors

        public DevicesController(IDeviceService deviceGroupService)
        {
            _deviceService = deviceGroupService;
        }

        #endregion

        #region Public Methods

        [HttpGet]
        [Route("devices/{deviceId?}")]
        public IHttpActionResult Get(int? deviceId = null)
        {
            var locale = Thread.CurrentThread.CurrentCulture.Name;

            var result = _deviceService.GetDevices(deviceId, locale);

            if (result.Status == Status.Success) return Ok(result.Value);

            return BadRequest(String.Join(";", result.Errors));
        }

        #endregion

        #region Private Methods



        #endregion
    }
}
