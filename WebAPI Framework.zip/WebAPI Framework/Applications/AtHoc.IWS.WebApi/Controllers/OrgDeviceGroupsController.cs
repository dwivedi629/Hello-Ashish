﻿using System.Collections.Generic;
using AtHoc.Diagnostics;
using AtHoc.IWS.Interfaces.Services;
using AtHoc.IWS.Interfaces.Services.Devices;
using System;
using System.Web.Http;

namespace AtHoc.IWS.WebApi.Controllers
{
    public class OrgDeviceGroupsController : ApiController
    {
        #region Private Members

        private readonly IDeviceGroupService _deviceGroupService;

        #endregion

        #region Constructors

        public OrgDeviceGroupsController(IDeviceGroupService deviceGroupService)
        {
            _deviceGroupService = deviceGroupService;
        }

        #endregion

        #region Public Methods

        [HttpPut]
        [Route("organizations/{orgId}/deviceGroups/{deviceGroupCommonName}/UpdateGatewayOrder")]
        public IHttpActionResult UpdateGatewayOrder(int orgId, string deviceGroupCommonName, [FromBody]List<string> gatewayIds)
        {
            try
            {
                var result = _deviceGroupService.UpdateGatewayOrder(orgId, deviceGroupCommonName, gatewayIds);

                if (result.Status == Status.Success) return Ok(result.Value);

                return BadRequest(String.Join(";", result.Errors));
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Update Gateway Order for Device Group: {0}, ", deviceGroupCommonName), ex);
                return InternalServerError(ex);
            }
        }

        #endregion

        #region Private Methods



        #endregion
    }
}
