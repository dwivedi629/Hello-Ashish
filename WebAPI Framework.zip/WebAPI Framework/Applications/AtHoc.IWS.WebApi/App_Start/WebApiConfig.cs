﻿using System.Configuration;
using System.Net.Http.Headers;
using System.Web.Http;

namespace AtHoc.IWS.WebApi
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            // REMOVING XML AS A MEDIA TYPE FROM THE WEBAPI, WE DONT REALLY NEED TO DO THIS
            config.Formatters.XmlFormatter.SupportedMediaTypes.Clear();

            // ADDING JSON AS THE DEFAULT MEDIA TYPE (SO JSON IS RETURNED FOR BROWSER REQUESTS FROM IE)
            config.Formatters.JsonFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/html"));

            // FORMATTING THE OUTPUT WITH INDENTATION
            config.Formatters.JsonFormatter.SerializerSettings.Formatting = Newtonsoft.Json.Formatting.Indented;

            // SETTING JSON OUTPUT PROPERTY NAMES CASE TO CAMEL CASE
            //config.Formatters.JsonFormatter.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();

            // REQUIRE CLIENT CERTIFICATE
            GlobalConfiguration.Configuration.MessageHandlers.Add(new RequireCertificateMessageHandler(ConfigurationManager.AppSettings["AcceptCertThumbprint"]));
        }
    }
}
