﻿using System;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using AtHoc.Diagnostics;

namespace AtHoc.IWS.WebApi
{
    public class RequireCertificateMessageHandler : DelegatingHandler
    {
        private readonly string _acceptedThumbprint = string.Empty;
        private bool ValidateCertificate(X509Certificate2 cert, out string message)
        {
            if (cert == null)
            {
                message = "A trusted client certificate was not provided.";
                return false;
            }
            if (cert.Thumbprint != null && !cert.Thumbprint.Equals(_acceptedThumbprint, StringComparison.OrdinalIgnoreCase))
            {
                message = "\"" + cert.Thumbprint + "\" is not a trusted client certificate thumbprint.";
                return false;
            }
            message = string.Empty;
            return true;
        }

        public RequireCertificateMessageHandler(string thumbprint)
        {
            if (string.IsNullOrEmpty(thumbprint))
            {
                throw new Exception("A client certificate thumbprint must be configured.");
            }
            _acceptedThumbprint = thumbprint;
        }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var cert = request.GetClientCertificate();
            string message;

            if (!ValidateCertificate(cert, out message))
            {
                EventLogger.WriteError(message);
                return Task.Factory.StartNew(() => request.CreateResponse(HttpStatusCode.Unauthorized), cancellationToken);
            }

            Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity(cert.Subject, "ClientCertificate"), null);
            return base.SendAsync(request, cancellationToken);
        }
    }
}