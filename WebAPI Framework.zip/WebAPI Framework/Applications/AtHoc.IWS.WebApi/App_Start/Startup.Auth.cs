﻿using Owin;

namespace AtHoc.IWS.WebApi
{
    public partial class Startup
    {
        public void ConfigureAuth(IAppBuilder app)
        {
            // this is the public key from the identity server which is available at http://localhost/oauth2/.well-known/jwks which intern is available from http://localhost/oauth2/.well-known/openid-configuration
            //var certificate = new X509Certificate2(Convert.FromBase64String("MIIFAzCCAuugAwIBAgIQD7bsdPNLfrtDRhX0st9yGzANBgkqhkiG9w0BAQ0FADARMQ8wDQYDVQQDEwZDQVJvb3QwHhcNMTYwNTAzMTgzOTA2WhcNMzkxMjMxMjM1OTU5WjARMQ8wDQYDVQQDEwZDQVJvb3QwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCutnNbfqlUrygRffDW7WhfK3GzQ+JElM7mm3wurk03VhHnDhuLqGwhOIP5LWJjmD/HFMStL2AiyxwT6XEmsWeFJ5N/RTzeXzkrrMQwnDRDclt0c9oVHwys6SfpUpq4ILiWlxy1TwIQOxlAQKBsse3/seDhL0TFm+PFT1SEDZU2FBwGkBdWwnQP8ASIQV8DqXeA7qee0do3v2fFpIbCEP4yxKApqr6mEaU6deuaJYiHEHrWrDD54Xj8RxGnrdZOvQKyhCk5bDFnVL+Dx75sq/jB9VwOwcBLrmnJMpksM9ht3qrfTDG8KfZvzagokyePy/sVM41c9G4yRYuVTpbdHleQVvRNt0R2n2hGykQCA1YO3GctcIOqxKtJMJgkPoyueTtplba7jgFwrHx4W7IMdJQFRROxCC3uhOFPtJtS0nvg1cJVb2U3a+cKnO/Fdsu/0Vv6NQ4J8ae4a5oX5ppq2wH3/SS7U5de+5+dUJfhJ/EHYydKDXYy3ziaF6nER1immyQo+gFGDW7KXX89vjAdvXnYgCUlK8dpco/8IKRIf6lMz0FSyKk1+IfFVzO7H9bRkAzQnB0skl6huklbIY6j2kJNDxRB86ZBg4hbACxije+/RF20dKF9zP/0MOVAPstT1/owYBdNhWw7BRXbsoj5D/aZh4QIi7hZtf5F7DDPL1IwzQIDAQABo1cwVTAPBgNVHRMBAf8EBTADAQH/MEIGA1UdAQQ7MDmAEGUaX3k1iDhpDd+KUr5zj7GhEzARMQ8wDQYDVQQDEwZDQVJvb3SCEA+27HTzS367Q0YV9LLfchswDQYJKoZIhvcNAQENBQADggIBAFiAeEn4jbGX6W4IU6FAfW1DM04Slfoc+zhBn8c3mHJv09iNG6YbFeo+dTlWDxsfJR1cAHXkKf7dtylcYnQsqRuux8Ukfu/rtoN70yueAqFujAnXM2rHQZwkWkrptfoHUkobGI/J8cCeTewlotHUvdaSNuk7Ym6ldtTmS+8f9XVFpLZ0alQcf7jUCv77CHBa3eBaLlvn+IqY+AXj4TweKx+rRqqZrcqxKmvxzBFnz7JcaOp6oiqxRr/SpcQaD0T7m5WNKeqoJ7UIaX3dXFZhyLQvxwsdulRQoqipiqli+5kkJ45W5tjeT4IBmB7RbS9yG9HN9p3igjK4fQe/CX/Vi1EwLg//WGqtnicvVa63smKwsPc1NNUeFCXeAzbpPFZpdsgofpfrrJ6zXyFlHJM7X4ktz59uP5SqIXWs/5Yto2WcwOtAIjNndAfsmL3Mp6nOIrqOgC1S0TlTLnZThs+Z9BRIPEUvAQ3mrH6aa4CYAHCcf52XDPFOOByYV1BROrAFxBJu+QGiwOiCm6SiQhgfbH/1Q+7m0aAqTmt2F44UQjJbO3gAqxZbg6JIIR3S/eQFe+83GjarohgX8amhozTs0vbFS+1ljGLZ50JYzqYE7bjymuSaWbp+poTFc43i7z8Bh8vtfih/Yus+25F0XB36Poic81s6VNHlJkXdY+o2EABd"));

            // >>>> YOU CAN USE THIS for initializing the AuthorizationServer on the resource server
            //app.UseJwtBearerAuthentication(new JwtBearerAuthenticationOptions
            //{
            //    AllowedAudiences = new[] { "http://localhost/OAuth2/resources" },
            //    TokenValidationParameters = new TokenValidationParameters
            //    {
            //        ValidAudience = "http://localhost/OAuth2/resources",
            //        ValidIssuer = "http://localhost/OAuth2",
            //        IssuerSigningKey = new X509SecurityKey(certificate)
            //    }
            //});

            // >>>> OR you can use the below if you Install-Package IdentityServer3.AccessTokenValidation from NuGet
            //app.UseIdentityServerBearerTokenAuthentication(new IdentityServerBearerTokenAuthenticationOptions
            //{
            //    Authority = "http://localhost/OAuth2"
            //});
        }
    }
}