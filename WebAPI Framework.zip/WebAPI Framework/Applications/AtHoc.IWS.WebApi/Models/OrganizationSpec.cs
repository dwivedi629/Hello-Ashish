﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using AtHoc.IWS.Models.Orgs;

namespace AtHoc.IWS.WebApi.Models
{
    public class OrganizationSpec : Organization
    {
        public OrganizationSpec()
        {
            OrgTemplateType = OrgTemplateType.Unknown;

            Logo = new LogoInfo();
        }

        public OrgTemplateType OrgTemplateType { get; set; }

        public LogoInfo Logo { get; set; }
    }

    public enum OrgTemplateType
    {
        [Description("UNKNOWN")]
        Unknown,
        [Description("TPL_ENT")]
        Enterprise,
        [Description("TPL_BAS")]
        Basic,
        [Description("TPL_SUB")]
        Sub
    }

    public class LogoInfo
    {
        public LogoInfo()
        {
            LogoContent = String.Empty;
            Extension = "jpg";
        }

        public string LogoContent { get; set; }
        public string Extension { get; set; }
    }
}