﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using AtHoc.IWS.Global.DataAccess;
using AtHoc.IWS.Interfaces.Business;
using AtHoc.IWS.Interfaces.Business.Users;
using AtHoc.IWS.Interfaces.DataAccess;
using AtHoc.IWS.Interfaces.DataAccess.Users;
using AtHoc.IWS.Models.Users;
using AtHoc.IWS.Tests;
using AtHoc.IWS.Users.Business;
using AtHoc.IWS.Users.DataAccess;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;

namespace AtHoc.IWS.Users.Services.Tests
{
    [TestClass]
    public class UserServiceTests
    {
        [TestMethod]
        public void MiscellaneousTest()
        {
            var configSettings = new ConfigSettings();
            var cn = new SqlConnection();
            var userSyncManager = new UserSyncManager(configSettings, new UserRepository(configSettings, cn), new UserAttributesRepository(configSettings, cn), new UserDevicesRepository(configSettings, cn), new UserRolesRepository(configSettings, cn), new GlobalRepository(configSettings, cn));
            var userSyncService = new UserSyncService(configSettings, userSyncManager);

            var dt = new DataTable();
            dt.Columns.Add("FIRSTNAME");
            dt.Columns.Add("LASTNAME");
            dt.Columns.Add("LOGIN_ID");
            dt.Columns.Add("Email-Work");
            dt.Columns.Add("workPhone");
            dt.Columns.Add("sms");
            dt.Columns.Add("USR_PSWD");
            dt.Columns.Add("STATUS");
            dt.Columns.Add("ATTRP02");
            dt.Columns.Add("USER_ROLES");
            dt.Columns.Add("SYSTARUNMULTI");

            dt.Rows.Add(new object[] { "SyncUser", "00", "SyncUser00", "syncuser01@email.com", "6086092425", "6086092425", "athoc123", "DEL", "100", "RENTADM, RORGADM", "MULTIVAL1, MULTIVAL2, MULTIVAL3" });
            dt.Rows.Add(new object[] { "SyncUser", "01", "SyncUser01", "syncuser01@email.com", "6086092425", "6086092425", "athoc123", "VLD", "60", "RORGADM", "MULTIVAL1" });
            dt.Rows.Add(new object[] { "SyncUser", "02", "SyncUser02", "syncuser02@email.com", "6086092425", "6086092425", "athoc123", "VLD", "60", "RSDK", "MULTIVAL2" });
            dt.Rows.Add(new object[] { "SyncUser", "03", "SyncUser03", "syncuser03@email.com", "6086092425", "6086092425", "athoc123", "VLD", "60", "RSDK", "" });
            dt.Rows.Add(new object[] { "SyncUser", "04", "SyncUser04", "syncuser04@email.com", "6086092425", "6086092425", "athoc123", "VLD", "60", "", "" });

            string jsonPayload = JsonConvert.SerializeObject(dt, Formatting.Indented);

            for (var i = 5; i < 20000; i++)
            {
                dt.Rows.Add(new object[] { "SyncUser", i.ToString("D2"), "SyncUser" + i.ToString("D2"), "syncuser" + i.ToString("D2") + "@email.com", "6086092425", "6086092425", "athoc123", "Enabled", "60", "Enterprise Admin", "MultiVal1, MultiVal2" });
            }

            var startTime = DateTime.Now;
            var result = userSyncService.SyncByCommonNames(dt, 2050639, "en-US");
            var endTime = DateTime.Now;

            var duration =endTime.Subtract(startTime);

        }

        [TestMethod]
        public void IntegrationTest()
        {
            var configSettings = new ConfigSettings();
            var cn = new SqlConnection();
            var userLogic = new UserManager(configSettings, new UserRepository(configSettings, cn));
            var operatorLogic = new OperatorManager(configSettings, new OperatorRepository(configSettings, cn));
            
            var userService = new UserService(configSettings, userLogic, operatorLogic);

            var user = new User { Id = 1, OrgId = 3 };
            var result = userService.MoveUserToOrg(user);
        }
    }
}
