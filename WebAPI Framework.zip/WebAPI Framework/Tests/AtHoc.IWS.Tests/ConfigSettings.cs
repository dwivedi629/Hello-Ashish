﻿namespace AtHoc.IWS.Tests
{
    public class ConfigSettings : IConfigSettings
    {
        public string DatabaseConnectionString
        {
            get { return "Server=platformdev.athocdevo.com;Initial Catalog=ngaddata;User Id=ngad;Password=@THOC123;Connection Timeout=0"; }
        }
        public int CacheTimeout { get; set; }
        public int LogLevel { get; set; }
    }
}
