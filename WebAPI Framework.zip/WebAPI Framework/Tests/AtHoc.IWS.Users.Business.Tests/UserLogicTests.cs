﻿using System;
using AtHoc.IWS.Interfaces.DataAccess;
using AtHoc.IWS.Interfaces.DataAccess.Users;
using AtHoc.IWS.Tests;
using AtHoc.IWS.Users.Business;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace AtHoc.IWS.Users.DataAccess.Tests
{
    [TestClass]
    public class UserLogicTests
    {


    }
}
