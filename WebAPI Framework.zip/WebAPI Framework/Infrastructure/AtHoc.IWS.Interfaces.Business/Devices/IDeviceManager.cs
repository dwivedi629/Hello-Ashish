﻿using System.Collections.Generic;
using AtHoc.IWS.Models.Devices;

namespace AtHoc.IWS.Interfaces.Business.Devices
{
    public interface IDeviceManager
    {
        IEnumerable<Device> GetDevices(int? deviceId, string locale);
    }
}
