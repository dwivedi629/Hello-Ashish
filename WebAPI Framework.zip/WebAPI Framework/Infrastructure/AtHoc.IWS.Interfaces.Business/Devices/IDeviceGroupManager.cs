﻿using System.Collections.Generic;

namespace AtHoc.IWS.Interfaces.Business.Devices
{
    public interface IDeviceGroupManager
    {
        bool UpdateGatewayOrder(int orgId, string deviceGroupCommonName, List<string> gatewayIds);
    }
}
