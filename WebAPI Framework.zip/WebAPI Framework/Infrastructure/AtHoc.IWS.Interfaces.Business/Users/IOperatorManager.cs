﻿
namespace AtHoc.IWS.Interfaces.Business.Users
{
    public interface IOperatorManager
    {
        bool ValidateOperatorCredentials(string username, string password);

        bool RemoveAllOperatorRolesForUser(int userId);
    }
}
