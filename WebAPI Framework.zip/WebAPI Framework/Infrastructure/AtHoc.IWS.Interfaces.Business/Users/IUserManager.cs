﻿namespace AtHoc.IWS.Interfaces.Business.Users
{
    public interface IUserManager
    {
        bool CheckUserExists(int userId);
        int GetProviderForUser(int userId);
        bool MoveUserToOrg(int userId, int orgId);
    }
}
