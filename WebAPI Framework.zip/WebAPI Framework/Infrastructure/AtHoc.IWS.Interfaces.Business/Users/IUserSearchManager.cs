﻿using AtHoc.IWS.Models.UserSearch;

namespace AtHoc.IWS.Interfaces.Business.Users
{
    public interface IUserSearchManager
    {
        ContextSearchResult SearchUsersV2ByContext(UserSearchArgs args);
        SessionSearchResult SearchUsersV2BySession(UserSearchSession args);
        AlertSearchResult SearchUsersV2ByAlert(UserSearchAlert args);
    }
}
