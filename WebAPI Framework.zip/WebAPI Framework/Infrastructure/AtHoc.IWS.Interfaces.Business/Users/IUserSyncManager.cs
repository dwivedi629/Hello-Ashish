﻿using System.Collections.Generic;
using System.Data;
using AtHoc.IWS.Models.UserSync;

namespace AtHoc.IWS.Interfaces.Business.Users
{
    public interface IUserSyncManager
    {
        List<string> ValidatePayloadAndPopulateMetadata(ref DataTable payload, int orgId, string locale);

        DataTable SyncByCommonNames(ref DataTable payload, int orgId, string locale);
    }
}
