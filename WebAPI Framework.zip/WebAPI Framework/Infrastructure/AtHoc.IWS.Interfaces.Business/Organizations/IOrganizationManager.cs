﻿
namespace AtHoc.IWS.Interfaces.Business.Organizations
{
    public interface IOrganizationManager
    {

    }
}
