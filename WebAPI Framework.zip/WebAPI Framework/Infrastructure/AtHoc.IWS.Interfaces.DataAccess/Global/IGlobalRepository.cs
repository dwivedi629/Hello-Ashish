﻿using System.Data;
using AtHoc.IWS.Models.Global;

namespace AtHoc.IWS.Interfaces.DataAccess.Global
{
    public interface IGlobalRepository
    {
        int GetSequence(SequenceType type, int range);
        void BulkCopyToDatabase(string table, DataTable dt);
    }
}
