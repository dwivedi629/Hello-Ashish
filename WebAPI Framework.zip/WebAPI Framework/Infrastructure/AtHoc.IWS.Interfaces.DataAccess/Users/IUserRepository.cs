﻿
using System.Data;

namespace AtHoc.IWS.Interfaces.DataAccess.Users
{
    public interface IUserRepository
    {
        bool CheckUserExistsByUserId(int userId);

        bool CheckUserExistsByUsername(string username);

        bool CheckUserExistsByUsernameAndPassword(string username, string password);

        int GetProviderForUser(int userId);

        bool MoveUserToOrg(int userId, int orgId);

        DataTable CheckUsersExist(DataTable userList, int orgId);

        DataTable CheckUsernameUniquenessInSystem(DataTable userList);

        DataTable CheckUsernameUniquenessInEnterprise(DataTable userList, int orgId);

        DataTable CheckMappingIdUniquenessInSystem(DataTable userList);

        DataTable CheckMappingIdUniquenessInEnterprise(DataTable userList, int orgId);
    }
}
