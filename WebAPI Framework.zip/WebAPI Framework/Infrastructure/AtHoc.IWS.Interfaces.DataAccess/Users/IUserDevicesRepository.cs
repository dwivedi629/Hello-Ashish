﻿
using AtHoc.IWS.Models.Devices;

namespace AtHoc.IWS.Interfaces.DataAccess.Users
{
    public interface IUserDevicesRepository
    {
        Device GetUserDeviceMetadataByDisplayName(string name, int orgId, string locale);
        Device GetUserDeviceMetadataByCommonName(string commonName, int orgId, string locale);
    }
}
