﻿
using AtHoc.IWS.Models.Users;

namespace AtHoc.IWS.Interfaces.DataAccess.Users
{
    public interface IOperatorRepository
    {
        Operator GetOperatorFromUsername(string username);

        bool RemoveAllOperatorRolesForUser(int userId);
    }
}
