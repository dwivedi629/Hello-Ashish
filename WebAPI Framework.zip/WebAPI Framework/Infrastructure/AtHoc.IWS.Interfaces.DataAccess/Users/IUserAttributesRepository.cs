﻿using System.Collections.Generic;
using AtHoc.IWS.Models.Attributes;

namespace AtHoc.IWS.Interfaces.DataAccess.Users
{
    public interface IUserAttributesRepository
    {
        Attribute GetUserAttributeMetadataByDisplayName(string name, int orgId, string locale);
        Attribute GetUserAttributeMetadataByCommonName(string commonName, int orgId, string locale);
        IEnumerable<AttributeValue> GetUserAttributeValueMetadataByAttributeId(int attributeId, string locale);
    }
}
