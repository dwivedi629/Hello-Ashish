﻿using System.Collections.Generic;
using AtHoc.IWS.Models.UserRoles;

namespace AtHoc.IWS.Interfaces.DataAccess.Users
{
    public interface IUserRolesRepository
    {
        IEnumerable<UserRole> GetUserRolesMetadataByOrg(int orgId, string locale);
    }
}
