﻿using AtHoc.IWS.Models.UserSearch;

namespace AtHoc.IWS.Interfaces.DataAccess.Users
{
    public interface IUserSearchRepository
    {
        ContextSearchResult SearchUsersV2ByContext(UserSearchArgs args);
        SessionSearchResult SearchUsersV2BySession(UserSearchSession args);
        AlertSearchResult SearchUsersV2ByAlert(UserSearchAlert args);
    }
}
