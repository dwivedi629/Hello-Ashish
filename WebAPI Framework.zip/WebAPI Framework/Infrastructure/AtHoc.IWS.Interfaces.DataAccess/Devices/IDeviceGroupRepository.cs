﻿using System.Collections.Generic;
using System.Data;

namespace AtHoc.IWS.Interfaces.DataAccess.Devices
{
    public interface IDeviceGroupRepository
    {
        bool UpdateGatewayOrder(int orgId, string deviceGroupCommonName, IEnumerable<string> gatewayIds);
    }
}
