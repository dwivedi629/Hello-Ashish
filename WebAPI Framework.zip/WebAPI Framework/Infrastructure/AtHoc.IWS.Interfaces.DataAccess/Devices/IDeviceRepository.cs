﻿using System.Collections.Generic;
using System.Data;
using AtHoc.IWS.Models.Devices;

namespace AtHoc.IWS.Interfaces.DataAccess.Devices
{
    public interface IDeviceRepository
    {
        IEnumerable<Device> GetDevices(int? deviceId, string locale);
    }
}
