﻿using System.Data;
using System.Data.SqlClient;

namespace AtHoc.IWS
{
    public abstract class RepositoryBase
    {
        protected IConfigSettings ConfigSettings;
        private IDbConnection _cn;

        protected RepositoryBase(IConfigSettings configSettings, IDbConnection cn)
        {
            ConfigSettings = configSettings;
            _cn = cn;
            _cn.ConnectionString = configSettings.DatabaseConnectionString;
        }

        protected IDbConnection OpenConnection()
        {
            // Check SQL Connection state, return open connection
            // http://stackoverflow.com/questions/6943933/check-if-sql-connection-is-open-or-closed
            
            if (_cn.State != ConnectionState.Open)
            {
                _cn.Close();
                _cn.Open();
            }

            return _cn;
        }

        protected void CloseConnection()
        {
            if (_cn != null)
            {
                _cn.Dispose();
                _cn = null;
            }
        }

        public void CopyData(string table, DataRow dr)
        {
            var dt = new DataTable();
            dt.ImportRow(dr);
            CopyData(table, dt);
        }

        public void CopyData(string table, DataTable dt)
        {
            // Set SQL Bulk Copy command to fire triggers. By Default, it does not. This is needed for MemOpt Schema Triggers
            // http://stackoverflow.com/questions/373057/sqlbulkinsert-how-to-set-fire-triggers-check-constraints
            using (var bulkCopy = new SqlBulkCopy(ConfigSettings.DatabaseConnectionString, SqlBulkCopyOptions.FireTriggers | SqlBulkCopyOptions.CheckConstraints))
            {
                bulkCopy.ColumnMappings.Clear();

                for (var i = 0; i < dt.Columns.Count; i++) bulkCopy.ColumnMappings.Add(dt.Columns[i].ColumnName, dt.Columns[i].ColumnName);

                bulkCopy.BulkCopyTimeout = 0;
                bulkCopy.DestinationTableName = table;
                bulkCopy.WriteToServer(dt);
            }
        }
    }
}
