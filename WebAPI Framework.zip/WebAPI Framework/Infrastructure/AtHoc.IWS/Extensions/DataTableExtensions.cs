﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Reflection;

namespace AtHoc.IWS.Extensions
{
    public static class DataTableExtensions
    {
        public static DataTable ToDataTable<T>(this IEnumerable<T> collection)
        {
            var dt = new DataTable();
            var t = typeof(T);
            var pia = t.GetProperties();

            //Create the columns in the DataTable
            foreach (var pi in pia) dt.Columns.Add(pi.Name, pi.PropertyType);

            //Populate the table
            foreach (var item in collection)
            {
                var dr = dt.NewRow();
                dr.BeginEdit();
                foreach (var pi in pia) dr[pi.Name] = pi.GetValue(item, null);
                dr.EndEdit();
                dt.Rows.Add(dr);
            }

            return dt;
        }
    }
}
