﻿namespace AtHoc.IWS
{
    public abstract class ServiceBase
    {
        protected IConfigSettings ConfigSettings;

        protected ServiceBase(IConfigSettings configSettings)
        {
            ConfigSettings = configSettings;
        }
    }
}
