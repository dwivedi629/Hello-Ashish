﻿namespace AtHoc.IWS
{
    public abstract class ManagerBase
    {
        protected IConfigSettings ConfigSettings;

        protected ManagerBase(IConfigSettings configSettings)
        {
            ConfigSettings = configSettings;
        }
    }
}
