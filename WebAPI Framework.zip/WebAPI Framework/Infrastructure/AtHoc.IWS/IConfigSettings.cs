﻿namespace AtHoc.IWS
{
    public interface IConfigSettings
    {
        string DatabaseConnectionString { get; }
        int CacheTimeout { get; set; }
        int LogLevel { get; set; }
    }
}
