﻿using System;

namespace AtHoc.IWS.Models.Orgs
{
    public class Organization : EntityBase
    {
        public Organization()
        {
            Name = String.Empty;
            OrgCode = String.Empty;
            EnterpriseProviderId = null;
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Locale { get; set; }
        public string OrgCode { get; set; }
        public int? EnterpriseProviderId { get; set; }
    }
}
