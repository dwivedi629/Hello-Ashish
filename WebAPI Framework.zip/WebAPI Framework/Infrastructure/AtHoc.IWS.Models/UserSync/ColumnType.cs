﻿using System.ComponentModel;

namespace AtHoc.IWS.Models.UserSync
{
    public enum ColumnType
    {
        [Description("USER_ID")]
        UserId,
        [Description("ATTRIBUTE")]
        Attribute,
        [Description("DEVICE")]
        Device,
        [Description("USER_ROLES")]
        UserRoles,
        [Description("STATIC_LIST")]
        StaticList,
        [Description("ORGANIZATION")]
        Organization,
        [Description("OPERATIONAL")]
        Operational,
        [Description("VALIDATION")]
        Validation,
        [Description("IDENTIFIER_VALUES")]
        ValueIdentifiers,
        [Description("SYNC_STATUS")]
        SyncStatus
    }
}
