﻿using System.ComponentModel;

namespace AtHoc.IWS.Models.Global
{
    public enum SequenceType
    {
        // ReSharper disable InconsistentNaming

        [Description("")]
        ACTION_ID,

        [Description("ADDRESSID")]
        ADDRESS_ID,

        [Description("AGENTID")]
        AGENT_ID,

        [Description("ALERT")]
        SCENARIO_ALERT_ID,

        [Description("ATTRIBUTEID")]
        ATTRIBUTE_ID,

        [Description("ATTRIBUTEVALUEID")]
        ATTRIBUTE_VALUE_ID,

        [Description("AUDIO")]
        AUDIO_ID,

        [Description("BUTTON")]
        BUTTON_ID,

        [Description("SERVICE")]
        CHANNEL_ID,

        [Description("PUBLISH_LAYOUT_CONFIG")]
        CONFIG_ID,

        [Description("MSFILTER")]
        CONTENT_FILTER_ID,

        [Description("DEVICEID")]
        DEVICE_ID,

        [Description("GLB_EXTENSION")]
        EXTENSION_ID,

        [Description("")]
        EVENT_CATEGORY_ID,

        [Description("")]
        EVENT_ID,

        [Description("DEVICEGROUP")]
        GROUP_ID,

        [Description("HIERARCHY")]
        HIERARCHY_ID,

        [Description("IMAGE")]
        IMAGE_ID,

        [Description("LISTID")]
        LIST_ID,

        [Description("MAP")]
        MAP_ID,

        [Description("SSA_MAP_CONFIGURATION_ID")]
        MAP_CONFIGURATION_ID,

        [Description("SSA_MAP_LAYER_ID")]
        MAP_LAYER_ID,

        [Description("MAP_ZONE")]
        MAP_ZONE_ID,

        [Description("")]
        MEDIA_ID,

        [Description("MONITORID")]
        MONITOR_ID,

        [Description("")]
        NOTIFIER_TEMPLATE_ID,

        [Description("")]
        PROVIDER_ID,

        [Description("REPORT")]
        REPORT_ID,

        [Description("ALERTMSGTEMPLATE")]
        SCENARIO_ID,

        [Description("SCD_JOB")]
        SCHEDULE_ID,

        [Description("SCD_SCHEDULED")]
        SCHEDULED_ID,

        [Description("SCD_SCHEDULED_JOB")]
        SCHEDULEDJOB_ID,

        [Description("")]
        SEARCH_ENTITY_ID,

        [Description("")]
        SEARCH_CRITERIA_ID,

        [Description("")]
        SEARCH_QUERY_ID,

        [Description("")]
        SEARCH_QUERY_VALUE_ID,

        [Description("SERVICE")]
        SERVICE_ID,

        [Description("SSA_MAP_LAYER_SPATIAL_ID")]
        SPATIAL_ID,

        [Description("")]
        SUB_PROVIDER_ID,

        [Description("SYSTEM")]
        SYSTEM_ID,

        [Description("DEVICETEMPLATE")]
        TEMPLATE_ID,

        [Description("")]
        TEST_ID,

        [Description("USER")]
        USER_ID,

        [Description("USERSCHEDULEID")]
        USER_SCHEDULE_ID,

        // ReSharper restore InconsistentNaming
    }
}
