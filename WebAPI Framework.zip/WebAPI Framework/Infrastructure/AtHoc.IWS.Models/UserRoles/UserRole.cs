﻿namespace AtHoc.IWS.Models.UserRoles
{
    public class UserRole : EntityBase
    {
        public int RoleId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string CommonName { get; set; }
        public bool UnrestrictedAlertFolders { get; set; }
        public bool UnrestrictedUserbase { get; set; }
        public bool UnrestrictedEntityAccess { get; set; }
    }
}
