﻿namespace AtHoc.IWS.Models
{
    public abstract class EntityBase
    {
    }
}