﻿using System.ComponentModel;

namespace AtHoc.IWS.Models.Attributes
{
    public enum AttributeEntity
    {
        [Description("UNKNOWN")]
        Unknown = 0,
        [Description("USER")]
        User = 1,
        [Description("PLACEHOLDER")]
        Placeholder = 2,
        [Description("ALERT")]
        Alert = 3
    }
}
