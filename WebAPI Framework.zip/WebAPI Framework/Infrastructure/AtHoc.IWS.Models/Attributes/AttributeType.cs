﻿namespace AtHoc.IWS.Models.Attributes
{
    public enum AttributeType
    {
        Unknown = 0,
        Number = 1,
        String = 2,
        Memo = 3,
        Date = 4,
        DateTime = 5,
        Picklist = 6,
        MultiPicklist = 7,
        Checkbox = 8,
        Path = 9,
        Geography = 10,
        Time = 11
    }
}
