﻿using System.Collections.Generic;

namespace AtHoc.IWS.Models.Attributes
{
    public class Attribute : EntityBase
    {
        public int AttributeId { get; set; }
        public AttributeEntity Entity { get; set; }
        public AttributeType AttributeType { get; set; }
        public string Name { get; set; }
        public string CommonName { get; set; }
        public int? HierarchyId { get; set; }
        public bool IsReadOnly { get; set; }
        public bool IsMandatory { get; set; }
        public bool IsSystem { get; set; }
        public bool IsStandard { get; set; }
        public string MinValue { get; set; }
        public string MaxValue { get; set; }
        public string DefaultValue { get; set; }
        public bool SaveHistory { get; set; }
        public IEnumerable<AttributeValue> ValuesMetadata { get; set; }
    }
}
