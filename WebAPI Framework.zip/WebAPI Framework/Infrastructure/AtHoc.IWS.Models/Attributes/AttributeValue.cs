﻿namespace AtHoc.IWS.Models.Attributes
{
    public class AttributeValue : EntityBase
    {
        public int AttributeId { get; set; }
        public int ValueId { get; set; }
        public string Name { get; set; }
        public string CommonName { get; set; }
        public int SortOrder { get; set; }
    }
}
