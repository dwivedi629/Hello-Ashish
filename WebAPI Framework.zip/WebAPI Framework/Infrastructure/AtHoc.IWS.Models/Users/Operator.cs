﻿using System.Collections.Generic;
using AtHoc.IWS.Models.Orgs;
using AtHoc.IWS.Models.UserRoles;

namespace AtHoc.IWS.Models.Users
{
    public class Operator : User
    {
        public IDictionary<Organization, IList<UserRole>> Roles { get; set; }
    }
}