﻿using System.Collections.Generic;
using AtHoc.IWS.Models.Attributes;
using AtHoc.IWS.Models.Devices;

namespace AtHoc.IWS.Models.Users
{
    public class User : EntityBase
    {
        public int Id { get; set; }
        public IDictionary<Attribute, object> Attributes { get; set; }
        public IDictionary<Device, object> Devices { get; set; }
        public int OrgId { get; set; }
    }
}