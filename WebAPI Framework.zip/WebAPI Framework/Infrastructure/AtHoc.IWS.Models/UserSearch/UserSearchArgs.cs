﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using AtHoc.IWS.Extensions;

namespace AtHoc.IWS.Models.UserSearch
{
    #region Expression
    public abstract class ExpressionElement
    {
        public override string ToString()
        {
            throw new NotImplementedException();
        }

        #region Operator Overloads

        public static ExpressionElement operator |(ExpressionElement e1, ExpressionElement e2)
        {
            if (e1 == null && e2 == null) return null;
            if (e1 == null) return e2;
            if (e2 == null) return e1;

            if (e1 is ExpressionGroup) return Or((ExpressionGroup)e1, e2);

            if (e1 is GenericCriteria) return Or((GenericCriteria)e1, e2);

            throw new ApplicationException("ExpressionElement Operator | (OR). Unknown error encountered.");
        }

        public static ExpressionElement operator &(ExpressionElement e1, ExpressionElement e2)
        {
            if (e1 == null && e2 == null) return null;
            if (e1 == null) return e2;
            if (e2 == null) return e1;

            if (e1 is ExpressionGroup) return And((ExpressionGroup)e1, e2);

            if (e1 is GenericCriteria) return And((GenericCriteria)e1, e2);

            throw new ApplicationException("ExpressionElement Operator & (AND). Unknown error encountered.");
        }

        #endregion

        #region Private Methods

        private static ExpressionElement Or(ExpressionGroup e1, ExpressionElement e2)
        {
            var retGroup = new ExpressionGroup(ExpressionOperator.Or);

            if (e2 is GenericCriteria)
            {
                if (e1.Operation == null || e1.Operation == ExpressionOperator.Or)
                {
                    retGroup.AddRange(e1.Elements);
                    retGroup.Add(e2);
                }
                else if (e1.Operation == ExpressionOperator.And)
                {
                    retGroup.Add(e1);
                    retGroup.Add(e2);
                }
            }
            else if (e2 is ExpressionGroup)
            {
                if (e1.Operation == ExpressionOperator.Or && ((ExpressionGroup)e2).Operation == ExpressionOperator.Or)
                {
                    retGroup.AddRange(e1.Elements);
                    retGroup.AddRange(((ExpressionGroup)e2).Elements);
                }
                else
                {
                    retGroup.Add(e1);
                    retGroup.Add(e2);
                }
            }

            return retGroup;
        }

        private static ExpressionElement Or(GenericCriteria g1, ExpressionElement e2)
        {
            var retGroup = new ExpressionGroup(ExpressionOperator.Or);

            if (e2 is GenericCriteria) // Criteria WITH Criteria
            {
                retGroup.Add(g1);
                retGroup.Add(e2);
            }
            else if (e2 is ExpressionGroup) // Criteria WITH ExpGroup
            {
                if (((ExpressionGroup)e2).Operation == null || ((ExpressionGroup)e2).Operation == ExpressionOperator.Or)
                {
                    retGroup.Add(g1);
                    retGroup.AddRange(((ExpressionGroup)e2).Elements);
                }
                else if (((ExpressionGroup)e2).Operation == ExpressionOperator.And)
                {
                    retGroup.Add(g1);
                    retGroup.Add(e2);
                }
            }

            return retGroup;
        }

        private static ExpressionElement And(ExpressionGroup e1, ExpressionElement e2)
        {
            var retGroup = new ExpressionGroup(ExpressionOperator.And);

            if (e2 is GenericCriteria)
            {
                if (e1.Operation == null || e1.Operation == ExpressionOperator.And)
                {
                    retGroup.AddRange(e1.Elements);
                    retGroup.Add(e2);
                }
                else if (e1.Operation == ExpressionOperator.Or)
                {
                    retGroup.Add(e1);
                    retGroup.Add(e2);
                }

            }
            else if (e2 is ExpressionGroup)
            {
                if (e1.Operation == ExpressionOperator.And && ((ExpressionGroup)e2).Operation == ExpressionOperator.And)
                {
                    retGroup.AddRange(e1.Elements);
                    retGroup.AddRange(((ExpressionGroup)e2).Elements);
                }
                else
                {
                    retGroup.Add(e1);
                    retGroup.Add(e2);
                }
            }

            return retGroup;
        }

        private static ExpressionElement And(GenericCriteria g1, ExpressionElement e2)
        {
            var retGroup = new ExpressionGroup(ExpressionOperator.And);

            if (e2 is GenericCriteria)
            {
                retGroup.Add(g1);
                retGroup.Add(e2);
            }
            else if (e2 is ExpressionGroup)
            {
                if (((ExpressionGroup)e2).Operation == null || ((ExpressionGroup)e2).Operation == ExpressionOperator.And)
                {
                    retGroup.Add(g1);
                    retGroup.AddRange(((ExpressionGroup)e2).Elements);
                }
                else if (((ExpressionGroup)e2).Operation == ExpressionOperator.Or)
                {
                    retGroup.Add(g1);
                    retGroup.Add(e2);
                }
            }

            return retGroup;
        }

        #endregion
    }

    public enum ExpressionOperator
    {
        [Description("&&")]
        And,
        [Description("||")]
        Or
    }

    public class ExpressionGroup : ExpressionElement
    {
        #region Constructors

        public ExpressionGroup(ExpressionOperator opr)
        {
            Elements = new List<ExpressionElement>();
            Operation = opr;
        }

        #endregion

        #region Public Members

        public ExpressionOperator? Operation { get; set; }

        public List<ExpressionElement> Elements { get; set; }

        #endregion

        #region Public Methods

        public bool HasItems()
        {
            return Elements.Any();
        }

        public void Add(ExpressionElement expression)
        {
            if (expression != null)
            {
                Elements.Add(expression);
            }
        }

        public void AddRange(IEnumerable<ExpressionElement> collection)
        {
            if (collection != null)
            {
                Elements.AddRange(collection);
            }
        }

        public void Insert(int index, ExpressionElement expression)
        {
            if (expression != null)
            {
                Elements.Insert(index, expression);
            }
        }

        public void InsertRange(int index, IEnumerable<ExpressionElement> collection)
        {
            if (collection != null)
            {
                Elements.InsertRange(index, collection);
            }
        }

        #endregion

        #region Interface Methods

        public override string ToString()
        {
            string grpString = String.Empty;

            if (Elements.Count > 1) grpString = "{";

            var ctr = 0;

            foreach (var expElement in Elements)
            {
                if (ctr == 0)
                {
                    grpString += expElement.ToString();
                }
                else
                {
                    if (Operation == null) throw new ApplicationException("GroupExpression Operation cannot be null when the object has multiple ExpressionElements");

                    grpString += " " + Operation.GetDescription() + " " + expElement.ToString();
                }

                ctr++;
            }

            if (Elements.Count > 1) grpString += "}";

            return grpString;
        }

        #endregion
    }

    public enum SearchFlow
    {
        FromUserManager,
        FromPublisherSearch,
        FromPublisherPieChart,
        FromDistributionListManagerDynamic,
        FromDistributionListManagerStatic,
        FromMaps,
        FromAlertReports
    }

    #endregion

    #region Search Classes
    public class UserSearchArgs
    {
        #region Constructor

        public UserSearchArgs()
        {
            TargetAllUserBase = false;

            Options = new QueryOptions()
            {
                GetCountsOnly = false,
                GetUsers = true,
                GetMassDevices = false,
            };
            Paging = new PagingParameters()
            {
                UsersPerPage = 25,
                PageNo = 1,
                SortColumn = "USER_ID",
                IsAsc = true,
            };
        }

        public UserSearchArgs(bool getCountsOnly, bool getUsers, bool getMassDevices)
        {
            TargetAllUserBase = false;

            Options = new QueryOptions()
            {
                GetCountsOnly = getCountsOnly,
                GetUsers = getUsers,
                GetMassDevices = getMassDevices,
            };
            Paging = new PagingParameters()
            {
                UsersPerPage = 25,
                PageNo = 1,
                SortColumn = "USER_ID",
                IsAsc = true,
            };
        }

        public UserSearchArgs(bool getCountsOnly, bool getUsers, bool getMassDevices, int pageNo, int pageSize, string sortColumn, string sortOrder)
        {
            TargetAllUserBase = false;

            Options = new QueryOptions()
            {
                GetCountsOnly = getCountsOnly,
                GetUsers = getUsers,
                GetMassDevices = getMassDevices,
            };
            Paging = new PagingParameters()
            {
                UsersPerPage = pageSize,
                PageNo = pageNo,
                SortColumn = sortColumn,
                IsAsc = !sortOrder.Equals("DESC", StringComparison.CurrentCultureIgnoreCase),
            };
        }

        #endregion

        #region Properties

        public int ProviderId { get; set; }
        public ExpressionElement ProviderCriteria { get; set; }
        public ExpressionElement OperatorCriteria { get; set; }
        public bool TargetAllUserBase { get; set; }
        public ExpressionElement TargetCriteria { get; set; }
        public List<int> TargetUsers { get; set; }
        public ExpressionElement BlockCriteria { get; set; }
        public List<int> BlockUsers { get; set; }
        public int ChannelId { get; set; }
        public List<string> DeviceNames { get; set; }
        public List<string> AttributeNames { get; set; }
        public QueryOptions Options { get; set; }
        public PagingParameters Paging { get; set; }

        #endregion

        #region Nested Classes

        public class QueryOptions
        {
            #region Constructor

            public QueryOptions()
            {
                GetUsers = false;
                GetMassDevices = false;
                GetCountsOnly = false;
                EnableSession = false;
                ProcessNestedList = true;
            }

            #endregion

            #region Properties

            public bool GetCountsOnly { get; set; }
            public bool GetUsers { get; set; }
            public bool GetMassDevices { get; set; }
            public bool EnableSession { get; set; }
            public int DebugLevel { get { return 0; } }

            public bool ProcessNestedList { get; set; }

            #endregion
        }

        #endregion
    }

    public class UserSearchSession : UserSearchArgs
    {
        public UserSearchSession(bool getCountsOnly, bool getUsers, bool getMassDevices)
            : base(getCountsOnly, getUsers, getMassDevices)
        {
        }

        public UserSearchSession(bool getCountsOnly, bool getUsers, bool getMassDevices, int pageNo, int pageSize, string sortColumn, string sortOrder)
            : base(getCountsOnly, getUsers, getMassDevices, pageNo, pageSize, sortColumn, sortOrder)
        {
        }

        public int SessionId { get; set; }
    }

    public class UserSearchAlert : UserSearchArgs
    {
        public UserSearchAlert(bool getCountsOnly, bool getUsers, bool getMassDevices)
            : base(getCountsOnly, getUsers, getMassDevices)
        {
        }

        public UserSearchAlert(bool getCountsOnly, bool getUsers, bool getMassDevices, int pageNo, int pageSize, string sortColumn, string sortOrder)
            : base(getCountsOnly, getUsers, getMassDevices, pageNo, pageSize, sortColumn, sortOrder)
        {
        }

        public ExpressionElement AlertCriteria { get; set; }
    }

    #endregion

    #region Criterias

    /// <summary>
    /// Query Conditions
    /// </summary>
    public enum CriteriaOperator
    {
        Equals = 1,
        NotEquals = 2,
        Contains = 3,
        DoesNotContain = 4,
        StartsWith = 5,
        EndsWith = 6,
        LessThan = 7,
        GreaterThan = 8,
        LessThanEqual = 9,
        GreaterThanEqual = 10,
        IsEmpty = 11,
        IsNotEmpty = 12,
        IsInsideArea = 13,
        IsOutsideArea = 14,
    }

    public enum AlertCriteriaOperator
    {
        // ReSharper disable InconsistentNaming
        TARGETED,
        SENT,
        RESPONDED,
        RESPONSE1,
        RESPONSE2,
        RESPONSE3,
        RESPONSE4,
        RESPONSE5,
        RESPONSE6,
        RESPONSE7,
        RESPONSE8,
        RESPONSE9,
        ANYRESPONSE,
        NORESPONSE,
        NOTSENT
        // ReSharper restore InconsistentNaming
    }

    public enum ResultBasedCriteriaOperator
    {
        // ReSharper disable InconsistentNaming
        FILLCOUNT,
        ABOVEFILLCOUNT
        // ReSharper restore InconsistentNaming
    }

    /// <summary>
    /// Query Type can either be Attribute or Device
    /// </summary>
    public enum CriteriaType
    {
        // ReSharper disable InconsistentNaming
        ATTRIBUTE = 1,
        DEVICE = 2,
        ROLE = 3,
        GEO = 4,
        VPS = 5,
        USER = 6,
        ALERT = 7
        // ReSharper restore InconsistentNaming
    }

    /// <summary>
    /// This class defines the various criteria for targeting end users
    /// </summary>
    public class GenericCriteria : ExpressionElement
    {
        #region Constructors

        public GenericCriteria()
        {

        }

        public GenericCriteria(CriteriaType type, int id, CriteriaOperator opr, object value)
        {
            Type = type;
            Id = id;
            Operator = opr;
            Value = value;
        }

        public GenericCriteria(CriteriaType type, int id, int opr, object value)
        {
            Type = type;
            Id = id;
            Operator = (CriteriaOperator)opr;
            Value = value;
        }

        public GenericCriteria(string type)
        {
            Type = (CriteriaType)Enum.Parse(typeof(CriteriaType), type.ToUpper());
        }

        public GenericCriteria(string type, int id)
        {
            Type = (CriteriaType)Enum.Parse(typeof(CriteriaType), type.ToUpper());
            Id = id;
        }

        public GenericCriteria(string type, int id, int opr)
        {
            Type = (CriteriaType)Enum.Parse(typeof(CriteriaType), type.ToUpper());
            Id = id;
            Operator = (CriteriaOperator)opr;
        }

        public GenericCriteria(string type, int id, int opr, object value)
        {
            Type = (CriteriaType)Enum.Parse(typeof(CriteriaType), type.ToUpper());
            Id = id;
            Operator = (CriteriaOperator)opr;
            Value = value;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Query Type can either be Attribute or Device
        /// </summary>
        public CriteriaType Type { get; set; }

        /// <summary>
        /// ID of the device or attribute to search
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Query Conditions
        /// </summary>
        public CriteriaOperator Operator { get; set; }

        /// <summary>
        /// The Value to search for
        /// </summary>
        public object Value { get; set; }

        #endregion

        #region Interface Methods

        public override string ToString()
        {
            return Type + "-" + Id + "!" + (int)Operator + "!" + Value;
        }

        #endregion
    }

    public class AttributeCriteria : GenericCriteria
    {
        #region Constructors

        public AttributeCriteria()
        {
            Type = CriteriaType.ATTRIBUTE;
        }

        public AttributeCriteria(int id, CriteriaOperator opr, object value)
        {
            Type = CriteriaType.ATTRIBUTE;
            Id = id;
            Operator = opr;
            Value = value;
        }

        public AttributeCriteria(int id, int opr, object value)
        {
            Type = CriteriaType.ATTRIBUTE;
            Id = id;
            Operator = (CriteriaOperator)opr;
            Value = value;
        }

        #endregion
    }

    public class GeoCriteria : GenericCriteria
    {
        #region Constructors

        public GeoCriteria(int id, CriteriaOperator opr, object value)
        {
            if (opr != CriteriaOperator.IsInsideArea && opr != CriteriaOperator.IsOutsideArea) throw new Exception("Criteria Operator for a Geo-Attribute can only be IsInsideArea (13) or IsOutsideArea (14)");

            Type = (Id == 0 ? CriteriaType.GEO : CriteriaType.ATTRIBUTE);
            Id = id;
            Operator = opr;
            Value = value;
        }

        public GeoCriteria(int id, int opr, object value)
        {
            if (opr != 13 && opr != 14) throw new Exception("Criteria Operator for a Geo-Attribute can only be IsInsideArea (13) or IsOutsideArea (14)");

            Type = (Id == 0 ? CriteriaType.GEO : CriteriaType.ATTRIBUTE);
            Id = id;
            Operator = (CriteriaOperator)opr;
            Value = value;
        }

        #endregion
    }

    public class VPSCriteria : GenericCriteria
    {
        #region Constructors

        public VPSCriteria()
        {
            Type = CriteriaType.VPS;
        }

        public VPSCriteria(int id, CriteriaOperator opr, object value)
        {
            Type = CriteriaType.VPS;
            Id = id;
            Operator = opr;
            Value = value;
        }

        public VPSCriteria(int id, int opr, object value)
        {
            Type = CriteriaType.VPS;
            Id = id;
            Operator = (CriteriaOperator)opr;
            Value = value;
        }

        #endregion
    }

    public class RoleCriteria : GenericCriteria
    {
        #region Constructors

        public RoleCriteria()
        {
            Type = CriteriaType.ROLE;
        }

        public RoleCriteria(int id, CriteriaOperator opr, object value)
        {
            Type = CriteriaType.ROLE;
            Id = id;
            Operator = opr;
            Value = value;
        }

        public RoleCriteria(int id, int opr, object value)
        {
            Type = CriteriaType.ROLE;
            Id = id;
            Operator = (CriteriaOperator)opr;
            Value = value;
        }

        #endregion
    }

    public class DeviceCriteria : GenericCriteria
    {
        #region Constructors

        public DeviceCriteria()
        {
            Type = CriteriaType.DEVICE;
        }

        public DeviceCriteria(int id, CriteriaOperator opr, object value)
        {
            Type = CriteriaType.DEVICE;
            Id = id;
            Operator = opr;
            Value = value;
        }

        public DeviceCriteria(int id, int opr, object value)
        {
            Type = CriteriaType.DEVICE;
            Id = id;
            Operator = (CriteriaOperator)opr;
            Value = value;
        }

        #endregion
    }

    public class UserCriteria : GenericCriteria
    {
        #region Constructors

        public UserCriteria()
        {
            Type = CriteriaType.USER;
        }

        public UserCriteria(int id, CriteriaOperator opr, object value)
        {
            Type = CriteriaType.USER;
            Id = id;
            Operator = opr;
            Value = value;
        }

        public UserCriteria(int id, int opr, object value)
        {
            Type = CriteriaType.USER;
            Id = id;
            Operator = (CriteriaOperator)opr;
            Value = value;
        }

        #endregion
    }

    public class AlertCriteria : GenericCriteria
    {
        #region Constructors

        public AlertCriteria()
        {
            Type = CriteriaType.ALERT;
        }

        public AlertCriteria(int alertId, AlertCriteriaOperator opr, IEnumerable<int> deviceIds)
        {
            Type = CriteriaType.ALERT;
            Id = alertId;
            Operator = opr;
            Value = deviceIds;
        }

        public AlertCriteria(int alertId, string opr, IEnumerable<int> deviceIds)
        {
            Type = CriteriaType.ALERT;
            Id = alertId;
            Operator = (AlertCriteriaOperator)Enum.Parse(typeof(AlertCriteriaOperator), opr.ToUpper());
            Value = deviceIds;
        }

        #endregion

        #region Properties

        public new AlertCriteriaOperator Operator { get; set; }

        #endregion

        #region Interface Methods

        public override string ToString()
        {
            return Type + "-" + Id + "!" + Operator + "!" + ((IEnumerable<int>)Value).CsvParamString();
        }

        #endregion

    }

    public class ResultBasedCriteria : GenericCriteria
    {
        #region Constructors

        public ResultBasedCriteria()
        {
            Type = CriteriaType.ALERT;
        }

        public ResultBasedCriteria(int alertId, AlertCriteriaOperator alertOpr, ResultBasedCriteriaOperator rbOpr, IEnumerable<int> deviceIds)
        {
            Type = CriteriaType.ALERT;
            Id = alertId;
            Operator = alertOpr;
            ResultBasedOperator = rbOpr;
            Value = deviceIds;
        }

        public ResultBasedCriteria(int alertId, string alertOpr, string rbOpr, IEnumerable<int> deviceIds)
        {
            Type = CriteriaType.ALERT;
            Id = alertId;
            Operator = (AlertCriteriaOperator)Enum.Parse(typeof(AlertCriteriaOperator), alertOpr.ToUpper());
            ResultBasedOperator = (ResultBasedCriteriaOperator)Enum.Parse(typeof(ResultBasedCriteriaOperator), rbOpr.ToUpper());
            Value = deviceIds;
        }

        #endregion

        #region Properties

        public new AlertCriteriaOperator Operator { get; set; }

        public ResultBasedCriteriaOperator ResultBasedOperator { get; set; }

        #endregion

        #region Interface Methods

        public override string ToString()
        {
            return Type + "-" + Id + "!" + Operator + "-" + ResultBasedOperator + "!" + ((IEnumerable<int>)Value).CsvParamString();
        }

        #endregion
    }

    #endregion

    #region Paging Parameters

    public class PagingParameters
    {
        private int usersPerPage;

        #region Constructor

        public PagingParameters()
        {
            UsersPerPage = 25;
            PageNo = 1;
            SortColumn = "";
            IsAsc = true;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Users per Page (default 50)
        /// </summary>
        public int UsersPerPage
        {
            get { return usersPerPage; }
            set { usersPerPage = value > 99999999 ? 99999999 : value; }
        }

        /// <summary>
        /// The requested Page Number (default 1)
        /// </summary>
        public int PageNo { get; set; }


        /// <summary>
        /// Column to sort the output resultset on
        /// </summary>
        public string SortColumn { get; set; }

        /// <summary>
        /// Sort ascending or descending (deafult ASC)
        /// </summary>
        public bool IsAsc { get; set; }

        #endregion
    }

    #endregion

    #region Search Result Model

    public class UserSearchResultItem
    {
        public UserSearchResultItem()
        {
            UserDevice = new Dictionary<string, string>();
            UserAttributes = new Dictionary<string, string>();
        }

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserName { get; set; }
        public string DisplayName { get; set; }
        public IDictionary<string, string> UserDevice { get; set; }
        public IDictionary<string, string> UserAttributes { get; set; }
    }

    public abstract class UserSearchResult
    {
        protected UserSearchResult()
        {
            UsersDataTable = new DataTable();
            Users = new List<UserSearchResultItem>();
        }

        public DataTable UsersDataTable { get; set; }
        public List<UserSearchResultItem> Users { get; set; }
    }

    public class ContextSearchResult : UserSearchResult
    {
        public int UserBaseCount { get; set; }
        public int SearchResultCount { get; set; }
        public int MassDeviceCount { get; set; }
        public int RegularUserCount { get; set; }
        public int EnabledUserCount { get; set; }
        public int MaxEnabledUserCount { get; set; }
        public int SessionId { get; set; }
        public int EnabledUserBaseCount { get; set; }
    }

    public class SessionSearchResult : UserSearchResult
    {
        public int UserBaseCount { get; set; }
        public int SearchResultCount { get; set; }
        public int MassDeviceCount { get; set; }
        public int RegularUserCount { get; set; }
        public int EnabledUserCount { get; set; }
        public int MaxEnabledUserCount { get; set; }
    }

    public class AlertSearchResult : UserSearchResult
    {
        public int Targeted { get; set; }
        public int Sent { get; set; }
        public int Responded { get; set; }
        public List<int> Response { get; set; }
        public int NotResponded { get; set; }
    }

    #endregion
}
