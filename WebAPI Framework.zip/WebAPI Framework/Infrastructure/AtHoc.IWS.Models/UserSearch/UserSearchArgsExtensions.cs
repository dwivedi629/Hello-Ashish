﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Models.UserSearch
{
    public static class UserSearchArgsExtensionMethods
    {
        public static string CriterionParamString(this IEnumerable<GenericCriteria> criterion)
        {
            return String.Join("^", criterion.Select(x => x.ToString()).ToArray());
        }

        public static string CriterionParamString(this IEnumerable<GeoCriteria> criterion)
        {
            return String.Join(Environment.NewLine, criterion.Select(x => x.ToString()).ToArray());
        }

        public static string CriterionParamString(this IEnumerable<List<GenericCriteria>> criterions)
        {
            return criterions.Aggregate("", (current, criterion) => current + (criterion.CriterionParamString() + Environment.NewLine));
        }

        public static string CsvQuotedParamString(this IEnumerable<string> criterion)
        {
            return String.Join(",", criterion.Select(x => "'" + x.ToString(CultureInfo.InvariantCulture) + "'").ToArray());
        }

        public static string CsvParamString(this IEnumerable<string> criterion)
        {
            return String.Join(",", criterion.Select(x => x.ToString(CultureInfo.InvariantCulture)).ToArray());
        }

        public static string CsvParamString(this IEnumerable<int> criterion)
        {
            return String.Join(",", criterion);
        }

        public static bool HasColumn(this IDataRecord dr, string columnName)
        {
            for (int i = 0; i < dr.FieldCount; i++)
            {
                if (dr.GetName(i).Equals(columnName, StringComparison.InvariantCultureIgnoreCase))
                    return true;
            }
            return false;
        }
    }
}
