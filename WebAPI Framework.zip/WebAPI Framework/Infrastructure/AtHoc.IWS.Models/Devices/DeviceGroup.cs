﻿using System.Collections.Generic;

namespace AtHoc.IWS.Models.Devices
{
    public class DeviceGroup : EntityBase
    {
        public int Id { get; set; }
        public string CommonName { get; set; }
        public string Name { get; set; }
        public int SortOrder { get; set; }
        public IEnumerable<Device> Devices { get; set; }
    }
}
