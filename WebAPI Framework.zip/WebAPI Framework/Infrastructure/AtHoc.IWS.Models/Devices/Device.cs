﻿namespace AtHoc.IWS.Models.Devices
{
    public class Device : EntityBase
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string CommonName { get; set; }
        public int AddressMaxLength { get; set; }
        public string AddressFormat { get; set; }
        public DeviceGroup DeviceGroup { get; set; }
    }
}
