﻿using System.Collections.Generic;
using AtHoc.IWS.Models.Devices;

namespace AtHoc.IWS.Interfaces.Services.Devices
{
    public interface IDeviceService
    {
        ServiceResult<IEnumerable<Device>> GetDevices(int? deviceId, string locale);
    }
}
