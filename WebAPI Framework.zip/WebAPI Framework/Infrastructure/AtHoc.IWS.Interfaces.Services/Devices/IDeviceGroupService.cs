﻿using System.Collections.Generic;

namespace AtHoc.IWS.Interfaces.Services.Devices
{
    public interface IDeviceGroupService
    {
        ServiceResult<List<string>> UpdateGatewayOrder(int orgId, string deviceGroupCommonName, List<string> gatewayIds);
    }
}
