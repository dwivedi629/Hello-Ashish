﻿using System.Collections.Generic;

namespace AtHoc.IWS.Interfaces.Services
{
    public class ServiceResult<T> where T : class
    {
        public T Value;

        public List<string> Errors { get; set; }

        public ServiceResult(T value) : this()
        {
            Value = value;
        }

        public ServiceResult()
        {
            Errors = new List<string>();
        }
        
        public Status Status 
        {
            get { return Errors.Count > 0 ? Status.Failure : Status.Success; }
        }
    }



    public enum Status
    {
        Success = 0,
        Failure = -1
    }
}
