﻿using AtHoc.IWS.Models.UserSearch;
using System.Data;

namespace AtHoc.IWS.Interfaces.Services.Users
{
    public interface IUserSearchService
    {
        ServiceResult<ContextSearchResult> SearchUsersWithinContext(UserSearchArgs args);
        ServiceResult<SessionSearchResult> SearchUsersWithinSession(UserSearchSession args);
        ServiceResult<AlertSearchResult> SearchUsersWithinAlert(UserSearchAlert args);
    }
}
