﻿using System.Data;

namespace AtHoc.IWS.Interfaces.Services.Users
{
    public interface IUserSyncService
    {
        ServiceResult<DataTable> SyncByCommonNames(DataTable payload, int orgId, string locale);
    }
}
