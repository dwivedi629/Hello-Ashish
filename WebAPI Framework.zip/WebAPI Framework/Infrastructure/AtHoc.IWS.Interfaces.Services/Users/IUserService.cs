﻿using AtHoc.IWS.Models.Users;

namespace AtHoc.IWS.Interfaces.Services.Users
{
    public interface IUserService
    {
        ServiceResult<User> MoveUserToOrg(User user);
    }
}
