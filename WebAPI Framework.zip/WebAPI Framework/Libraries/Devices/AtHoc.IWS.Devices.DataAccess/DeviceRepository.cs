﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using AtHoc.IWS.Extensions;
using AtHoc.IWS.Interfaces.DataAccess.Devices;
using AtHoc.IWS.Models.Devices;
using Dapper;

namespace AtHoc.IWS.Users.DataAccess
{
    public class DeviceRepository : RepositoryBase, IDeviceRepository
    {
        public DeviceRepository(IConfigSettings configSettings, IDbConnection cn) : base(configSettings, cn)
        {

        }

        public IEnumerable<Device> GetDevices(int? deviceId, string locale)
        {
            var cn = OpenConnection();

            var devices = cn.Query<Device, DeviceGroup, Device>(@"
/* GetDevices */
SELECT
    d.DEVICE_ID as Id,
    l.ENTITY_VALUE as Name,
    d.COMMON_NAME as CommonName,
	ISNULL(dg.ADDRESS_VALIDATION_PAYLOAD.value('(/validations/length)[1]', 'int'), 2000) as AddressMaxLength,
	dg.ADDRESS_VALIDATION_PAYLOAD.value('(/validations/format)[1]', 'varchar(MAX)') as AddressFormat,
    dg.GROUP_ID as Id,
    dg.COMMON_NAME as CommonName,
    dg.NAME as Name,
    dg.SORT_ORDER as SortOrder
FROM
	DLV_DEVICE_TAB d (nolock)
	INNER JOIN ENTITY_LOCALE_TAB l (nolock) ON (l.ENTITY_TYPE = 'DEVICE' AND l.ENTITY_ID = d.DEVICE_ID AND l.LOCALE_CODE = @LOCALE)
    INNER JOIN DLV_DEVICE_GROUP_TAB dg (nolock) ON (dg.GROUP_ID = d.GROUP_ID)
WHERE
    (@DEVICE_ID IS NULL OR d.DEVICE_ID = @DEVICE_ID)
", (d, dg) => { d.DeviceGroup = dg; return d; }, new { LOCALE = locale, DEVICE_ID = deviceId }).ToList();

            return devices;
        }
    }
}
