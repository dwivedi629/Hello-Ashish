﻿using System.Collections.Generic;
using System.Data;
using AtHoc.IWS.Extensions;
using AtHoc.IWS.Interfaces.DataAccess.Devices;
using Dapper;

namespace AtHoc.IWS.Users.DataAccess
{
    public class DeviceGroupRepository : RepositoryBase, IDeviceGroupRepository
    {
        public DeviceGroupRepository(IConfigSettings configSettings, IDbConnection cn) : base(configSettings, cn)
        {

        }

        public bool UpdateGatewayOrder(int orgId, string deviceGroupCommonName, IEnumerable<string> gatewayIds)
        {
            var cn = OpenConnection();

            var dtGatewayIds = new DataTable();
            dtGatewayIds.Columns.Add("ENTITY");
            foreach (var gatewayId in gatewayIds) dtGatewayIds.Rows.Add(gatewayId);

            cn.Execute(@"[dbo].[DLV_SET_PRV_GATEWAY_ORDER]", new { PROVIDER_ID = orgId, DEVICE_GROUP_COMMON_NAME = deviceGroupCommonName, GATEWAYIDs = dtGatewayIds.AsTableValuedParameter("dbo.STRING_ENTITIES") }, commandType: CommandType.StoredProcedure);

            return true;
        }
    }
}
