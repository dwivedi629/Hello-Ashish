﻿using System.Collections.Generic;
using AtHoc.IWS.Interfaces.Business.Devices;
using AtHoc.IWS.Interfaces.DataAccess.Devices;

namespace AtHoc.IWS.Devices.Business
{
    public class DeviceManager : ManagerBase, IDeviceManager
    {
        private readonly IDeviceRepository _deviceRepository;

        public DeviceManager(IConfigSettings configSettings, IDeviceRepository deviceRepository) : base(configSettings)
        {
            _deviceRepository = deviceRepository;
        }

        public IEnumerable<Models.Devices.Device> GetDevices(int? deviceId, string locale)
        {
            return _deviceRepository.GetDevices(deviceId, locale);
        }
    }
}
