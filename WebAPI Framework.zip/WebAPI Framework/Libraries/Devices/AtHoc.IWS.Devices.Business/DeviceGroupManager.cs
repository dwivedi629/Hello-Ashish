﻿using System.Collections.Generic;
using AtHoc.IWS.Interfaces.Business.Devices;
using AtHoc.IWS.Interfaces.DataAccess.Devices;

namespace AtHoc.IWS.Devices.Business
{
    public class DeviceGroupManager : ManagerBase, IDeviceGroupManager
    {
        private readonly IDeviceGroupRepository _deviceGroupRepository;

        public DeviceGroupManager(IConfigSettings configSettings, IDeviceGroupRepository deviceGroupRepository) : base(configSettings)
        {
            _deviceGroupRepository = deviceGroupRepository;
        }
        
        public bool UpdateGatewayOrder(int orgId, string deviceGroupCommonName, List<string> gatewayIds)
        {
            return _deviceGroupRepository.UpdateGatewayOrder(orgId, deviceGroupCommonName, gatewayIds);
        }
    }
}
