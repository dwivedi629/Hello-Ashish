﻿using System.Collections.Generic;
using System.Transactions;
using AtHoc.IWS.Interfaces.Business.Devices;
using AtHoc.IWS.Interfaces.Services;
using AtHoc.IWS.Interfaces.Services.Devices;
using AtHoc.IWS.Models.Devices;
using AtHoc.IWS.Resources;

namespace AtHoc.IWS.Devices.Services
{
    public class DeviceService : ServiceBase, IDeviceService
    {
        private readonly IDeviceManager _deviceManager;

        public DeviceService(IConfigSettings configSettings, IDeviceManager deviceManager) : base(configSettings)
        {
            _deviceManager = deviceManager;
        }

        public ServiceResult<IEnumerable<Device>> GetDevices(int? deviceId, string locale)
        {
            return new ServiceResult<IEnumerable<Device>>(_deviceManager.GetDevices(deviceId, locale));
        }
    }
}
