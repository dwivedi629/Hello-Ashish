﻿using System.Collections.Generic;
using System.Transactions;
using AtHoc.IWS.Interfaces.Business.Devices;
using AtHoc.IWS.Interfaces.Services;
using AtHoc.IWS.Interfaces.Services.Devices;
using AtHoc.IWS.Resources;

namespace AtHoc.IWS.Devices.Services
{
    public class DeviceGroupService : ServiceBase, IDeviceGroupService
    {
        private readonly IDeviceGroupManager _deviceGroupManager;

        public DeviceGroupService(IConfigSettings configSettings, IDeviceGroupManager deviceGroupManager) : base(configSettings)
        {
            _deviceGroupManager = deviceGroupManager;
        }

        public ServiceResult<List<string>> UpdateGatewayOrder(int orgId, string deviceGroupCommonName, List<string> gatewayIds)
        {
            var result = new ServiceResult<List<string>>(gatewayIds);

            // TODO: VALIDATE PAYLOAD

            using (var scope = new TransactionScope())
            {
                // UPDATES
                var deviceGroupGatewaysUpdated = _deviceGroupManager.UpdateGatewayOrder(orgId, deviceGroupCommonName, gatewayIds);

                if (deviceGroupGatewaysUpdated)
                {
                    // AUDIT LOG ENTRIES

                    // COMMIT TRANSACTION
                    scope.Complete();
                }
                else
                {
                    // ROLLBACK TRANSACTION AND RETURN ERROR
                    result.Errors.Add(UserResources.USERMOVE_ERROR_USER_MOVE_FAILED);
                }

                return result;
            }
        }
    }
}
