﻿using System.Data;
using System.Transactions;
using AtHoc.IWS.Interfaces.Business.Users;
using AtHoc.IWS.Interfaces.Services;
using AtHoc.IWS.Interfaces.Services.Users;
using AtHoc.IWS.Models.UserSearch;
using AtHoc.IWS.Resources;
using AtHoc.IWS.Models.Users;

namespace AtHoc.IWS.Users.Services
{
    public class UserSearchService : ServiceBase, IUserSearchService
    {
        private readonly IUserSearchManager _userSearchManager;

        public UserSearchService(IConfigSettings configSettings, IUserSearchManager userSearchManager) : base(configSettings)
        {
            _userSearchManager = userSearchManager;
        }

        public ServiceResult<ContextSearchResult> SearchUsersWithinContext(UserSearchArgs args)
        {
            return new ServiceResult<ContextSearchResult>(_userSearchManager.SearchUsersV2ByContext(args));
        }

        public ServiceResult<SessionSearchResult> SearchUsersWithinSession(UserSearchSession args)
        {
            return new ServiceResult<SessionSearchResult>(_userSearchManager.SearchUsersV2BySession(args));
        }

        public ServiceResult<AlertSearchResult> SearchUsersWithinAlert(UserSearchAlert args)
        {
            return new ServiceResult<AlertSearchResult>(_userSearchManager.SearchUsersV2ByAlert(args));
        }
    }
}
