﻿using System.Transactions;
using AtHoc.IWS.Interfaces.Business.Users;
using AtHoc.IWS.Interfaces.Services;
using AtHoc.IWS.Interfaces.Services.Users;
using AtHoc.IWS.Resources;
using AtHoc.IWS.Models.Users;

namespace AtHoc.IWS.Users.Services
{
    public class UserService : ServiceBase, IUserService
    {
        private readonly IUserManager _userManager;
        private readonly IOperatorManager _operatorManager;

        public UserService(IConfigSettings configSettings, IUserManager userManager, IOperatorManager operatorManager) : base(configSettings)
        {
            _userManager = userManager;
            _operatorManager = operatorManager;
        }

        public ServiceResult<User> MoveUserToOrg(User user)
        {
            var result = new ServiceResult<User>(user);

            // PAYLOAD VALIDATIONS
            if (!_userManager.CheckUserExists(user.Id))
            {
                result.Errors.Add(UserResources.USERMOVE_ERROR_USER_DOES_NOT_EXIST);
                return result;
            }

            using (var scope = new TransactionScope())
            {
                // UPDATES
                var usrMoved = _userManager.MoveUserToOrg(user.Id, user.OrgId);
                var oprPermissionsRevoked = _operatorManager.RemoveAllOperatorRolesForUser(user.Id);

                if (usrMoved && oprPermissionsRevoked)
                {
                    // AUDIT LOG ENTRIES

                    // COMMIT TRANSACTION
                    scope.Complete();
                }
                else
                {
                    // ROLLBACK TRANSACTION AND RETURN ERROR
                    if (!usrMoved) result.Errors.Add(UserResources.USERMOVE_ERROR_USER_MOVE_FAILED);
                    if (!oprPermissionsRevoked) result.Errors.Add(UserResources.USERMOVE_ERROR_USER_PERMISSIONS_REMOVE_FAILED);
                }

                return result;
            }
        }
    }
}
