﻿using System.Linq;
using System.Transactions;
using AtHoc.IWS.Interfaces.Business.Users;
using AtHoc.IWS.Interfaces.Services;
using System.Data;
using AtHoc.IWS.Interfaces.Services.Users;
using AtHoc.IWS.Models.UserSync;

namespace AtHoc.IWS.Users.Services
{
    public class UserSyncService : ServiceBase, IUserSyncService
    {
        #region Private Members

        private readonly IUserSyncManager _userSyncManager;

        #endregion

        #region Constructors

        public UserSyncService(IConfigSettings configSettings, IUserSyncManager userSyncManager) : base(configSettings)
        {
            _userSyncManager = userSyncManager;
        }

        #endregion

        #region Public Methods

        public ServiceResult<DataTable> SyncByCommonNames(DataTable payload, int orgId, string locale)
        {
            var errors = _userSyncManager.ValidatePayloadAndPopulateMetadata(ref payload, orgId, locale);

            if (errors.Any()) return new ServiceResult<DataTable> {Errors = errors, Value = payload};

            return new ServiceResult<DataTable>(_userSyncManager.SyncByCommonNames(ref payload, orgId, locale));
        }

        // WE CANNOT DO USER SYNC BY ID AS DEVICES AND ATTRIBUTES COULD SHARE COMMON ID(s)

        #endregion
    }
}
