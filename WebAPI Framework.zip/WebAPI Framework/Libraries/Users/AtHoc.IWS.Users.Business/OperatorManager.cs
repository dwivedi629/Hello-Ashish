﻿using AtHoc.IWS.Interfaces.Business.Users;
using AtHoc.IWS.Interfaces.DataAccess.Users;

namespace AtHoc.IWS.Users.Business
{
    public class OperatorManager : ManagerBase, IOperatorManager
    {
        private readonly IOperatorRepository _operatorRepository;

        public OperatorManager(IConfigSettings configSettings, IOperatorRepository operatorRepository) : base(configSettings)
        {
            _operatorRepository = operatorRepository;
        }

        public bool ValidateOperatorCredentials(string username, string password)
        {
            return false;
        }

        public bool RemoveAllOperatorRolesForUser(int userId)
        {
            return _operatorRepository.RemoveAllOperatorRolesForUser(userId);
        }
    }
}
