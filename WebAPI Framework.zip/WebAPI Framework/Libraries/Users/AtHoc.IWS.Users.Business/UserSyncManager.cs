﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Transactions;
using AtHoc.IWS.Extensions;
using AtHoc.IWS.Interfaces.Business.Users;
using AtHoc.IWS.Interfaces.DataAccess.Global;
using AtHoc.IWS.Interfaces.DataAccess.Users;
using AtHoc.IWS.Models.Attributes;
using AtHoc.IWS.Models.Devices;
using AtHoc.IWS.Models.Global;
using AtHoc.IWS.Models.UserRoles;
using AtHoc.IWS.Models.UserSync;
using AtHoc.IWS.Resources;
using AtHoc.IWS.Users.Business.Helpers;
using Attribute = AtHoc.IWS.Models.Attributes.Attribute;

namespace AtHoc.IWS.Users.Business
{
    public class UserSyncManager : ManagerBase, IUserSyncManager
    {
        #region Private Members

        private readonly IUserRepository _userRepository;
        private readonly IUserAttributesRepository _userAttributesRepository;
        private readonly IUserDevicesRepository _userDevicesRepository;
        private readonly IUserRolesRepository _userRolesRepository;
        private readonly IGlobalRepository _globalRepository;

        #endregion

        #region Constants

        private const string XPropDisplayName = "DISPLAY_NAME";
        private const string XPropType = "TYPE";
        private const string XPropMetadata = "METADATA";

        private const string ColLoginId = "LOGIN_ID";
        private const string ColMappingId = "MAPPING_ID";
        private const string ColStatus = "STATUS";
        private const string ColUserRoles = "USER_ROLES";
        private const string ColUserPassword = "USR_PSWD";
        private const string ColUserRandomId = "USER_RANDOM_ID";
        private const string ColUserPasswordUpdatedOn = "PASSWORD_UPDATED_ON";
        private const string ColIsMassCommunicationDevice = "NPD";
        private const string ColSystemGroups = "SYSTEM-GROUPS";
        private const string ColCreatedOn = "CREATEDON";
        private const string ColUserId = "USER_ID";
        private const string ColOperation = ":Operation";
        private const string ColSyncStatus = ":SyncStatus";
        private const string ColSyncDetails = ":SyncDetails";
        
        private const string AttrValStatusDel = "DEL";

        private const string TblUsrUserTab = "USR_USER_TAB";
        private const string TblUsrAttributeValueTab = "USR_ATTRIBUTE_VALUE_TAB";
        private const string TblUpsUserRoleTab = "UPS_USER_ROLE_TAB";
        private const string TblUpsEntityAccessTab = "UPS_ENTITY_ACCESS_TAB";
        private const string TblUsrDeviceAddressTab = "USR_DEVICE_ADDRESS_TAB";

        private const string UpdatedFrom = "API";

        #endregion

        #region Constructors

        public UserSyncManager(
            IConfigSettings configSettings,
            IUserRepository userRepository,
            IUserAttributesRepository userAttributesRepository,
            IUserDevicesRepository userDevicesRepository,
            IUserRolesRepository userRolesRepository,
            IGlobalRepository globalRepository
            ) : base(configSettings)
        {
            _userRepository = userRepository;
            _userAttributesRepository = userAttributesRepository;
            _userDevicesRepository = userDevicesRepository;
            _userRolesRepository = userRolesRepository;
            _globalRepository = globalRepository;
        }

        #endregion

        #region Public Methods

        public List<string> ValidatePayloadAndPopulateMetadata(ref DataTable payload, int orgId, string locale)
        {
            // duplicate columns verification is not required since a DataTable will not support duplicates and will throw an exception

            var errors = new List<string>();
            var operationalColumns = new List<DataColumn>();

            #region Verify Columns + Add Metadata

            // lookup common names from column headers and verify that the attributes and devices exist wrt to the current org context
            // TODO: Organizations, StaticLists in future release

            // add the column metadata as an extended property to the column
            foreach (DataColumn column in payload.Columns)
            {
                column.ExtendedProperties.Add(XPropDisplayName, column.ColumnName);

                #region Attributes and Static Lists

                // TODO: Static Lists

                var attributeMetadata = _userAttributesRepository.GetUserAttributeMetadataByCommonName(column.ColumnName, orgId, locale);

                if (attributeMetadata != null)
                {
                    // check if attribute is readonly
                    if (attributeMetadata.IsReadOnly) errors.Add(string.Format(UserResources.USERSYNC_ERROR_PAYLOAD_COLUMN_IS_A_READ_ONLY_ATTRIBUTE, column.ColumnName));

                    column.ColumnName = attributeMetadata.CommonName;
                    column.ExtendedProperties.Add(XPropType, ColumnType.Attribute);
                    column.ExtendedProperties.Add(XPropMetadata, attributeMetadata);
                    
                    // for picklist type columns, we have to add value verification and identifier columns
                    if (attributeMetadata.AttributeType == AttributeType.Picklist || attributeMetadata.AttributeType == AttributeType.MultiPicklist || attributeMetadata.AttributeType == AttributeType.Checkbox)
                    {
                        var valColumn = new DataColumn(":" + attributeMetadata.CommonName, typeof(String));
                        valColumn.ExtendedProperties[XPropType] = ColumnType.Validation;
                        operationalColumns.Add(valColumn);

                        var idColumn = new DataColumn("$" + attributeMetadata.CommonName, typeof(String));
                        idColumn.ExtendedProperties[XPropType] = ColumnType.ValueIdentifiers;
                        operationalColumns.Add(idColumn);
                    }
                    else if (attributeMetadata.AttributeType == AttributeType.Path)
                    {
                        var valColumn = new DataColumn(":" + attributeMetadata.CommonName, typeof(String));
                        valColumn.ExtendedProperties[XPropType] = ColumnType.Validation;
                        operationalColumns.Add(valColumn);
                    }

                    // for password column, we also need to update the USER_RANDOM_ID and PASSWORD_UPDATED_ON
                    if (attributeMetadata.CommonName == ColUserPassword)
                    {
                        var usrRandomIdMetadata = _userAttributesRepository.GetUserAttributeMetadataByCommonName(ColUserRandomId, orgId, locale);
                        var usrRandomIdColumn = new DataColumn(ColUserRandomId, typeof(String));
                        usrRandomIdColumn.ExtendedProperties[XPropType] = ColumnType.Operational;
                        usrRandomIdColumn.ExtendedProperties.Add(XPropMetadata, usrRandomIdMetadata);
                        operationalColumns.Add(usrRandomIdColumn);

                        var usrPasswordUpdatedOnMetadata = _userAttributesRepository.GetUserAttributeMetadataByCommonName(ColUserPasswordUpdatedOn, orgId, locale);
                        var usrPasswordUpdatedOnColumn = new DataColumn(ColUserPasswordUpdatedOn, typeof(String));
                        usrPasswordUpdatedOnColumn.ExtendedProperties[XPropType] = ColumnType.Operational;
                        usrPasswordUpdatedOnColumn.ExtendedProperties.Add(XPropMetadata, usrPasswordUpdatedOnMetadata);
                        operationalColumns.Add(usrPasswordUpdatedOnColumn);
                    }

                    continue;
                }

                #endregion

                #region Devices

                var deviceMetadata = _userDevicesRepository.GetUserDeviceMetadataByCommonName(column.ColumnName, orgId, locale);

                if (deviceMetadata != null)
                {
                    column.ColumnName = deviceMetadata.CommonName;
                    column.ExtendedProperties.Add(XPropType, ColumnType.Device);
                    column.ExtendedProperties.Add(XPropMetadata, deviceMetadata);
                    continue;
                }

                #endregion

                #region User Roles

                if (column.ColumnName == ColUserRoles)
                {
                    var rolesMetadata = _userRolesRepository.GetUserRolesMetadataByOrg(orgId, locale);

                    column.ColumnName = ColUserRoles;
                    column.ExtendedProperties.Add(XPropType, ColumnType.UserRoles);
                    column.ExtendedProperties.Add(XPropMetadata, rolesMetadata);

                    // USER_ROLES is a multi-picklist type column, and so we have to add value verification and identifier columns

                    var valColumn = new DataColumn(":" + ColUserRoles, typeof(String));
                    valColumn.ExtendedProperties[XPropType] = ColumnType.Validation;
                    operationalColumns.Add(valColumn);

                    var idColumn = new DataColumn("$" + ColUserRoles, typeof(String));
                    idColumn.ExtendedProperties[XPropType] = ColumnType.ValueIdentifiers;
                    operationalColumns.Add(idColumn);

                    continue;
                }

                #endregion

                errors.Add(string.Format(UserResources.USERSYNC_ERROR_COLUMN_WAS_NOT_FOUND, column.ColumnName));
            }

            #endregion

            #region Check if the Username column exists in the Payload

            if (!payload.Columns.Contains(ColLoginId)) errors.Add(string.Format(UserResources.USERSYNC_ERROR_USERNAME_IS_MANDATORY_IN_IMPORT_PAYLOAD, UserResources.ATTRIBUTENAME_USERNAME));

            #endregion

            #region Check if duplicate Usernames are there in the Payload

            if (payload.Columns.Contains(ColLoginId))
            {
                var duplicateLoginIds = from row in payload.AsEnumerable()
                                        group row by row.Field<string>(ColLoginId)
                                        into rows
                                        where rows.Count() > 1
                                        select rows.Key;

                var loginIds = duplicateLoginIds as string[] ?? duplicateLoginIds.ToArray();

                if (loginIds.Any()) errors.Add(string.Format(UserResources.USERSYNC_ERROR_DUPLICATE_USERNAMES_FOUND_IN_PAYLOAD, UserResources.ATTRIBUTENAME_USERNAME, String.Join(", ", loginIds)));
            }

            #endregion

            #region Check if duplicate MappingIDs are there in the Payload

            if (payload.Columns.Contains(ColMappingId))
            {
                var duplicateMappingIds =   from row in payload.AsEnumerable()
                                            group row by row.Field<string>(ColMappingId)
                                            into rows
                                            where rows.Count() > 1
                                            select rows.Key;

                var mappingIds = duplicateMappingIds as string[] ?? duplicateMappingIds.ToArray();

                if (mappingIds.Any()) errors.Add(string.Format(UserResources.USERSYNC_ERROR_DUPLICATE_MAPPING_IDS_FOUND_IN_PAYLOAD, UserResources.ATTRIBUTENAME_MAPPINGID, String.Join(", ", mappingIds)));
            }

            #endregion

            // TODO: CHECK IF THE OPERATOR CAN EDIT THE COLUMN

            #region If no errors are found in the Payload, add the Operational Columns

            if (errors.Count == 0)
            { 
                var operationColumn = new DataColumn(ColOperation, typeof(String)) { DefaultValue = String.Empty };
                operationColumn.ExtendedProperties[XPropType] = ColumnType.Operational;
                operationColumn.ExtendedProperties[XPropDisplayName] = ColOperation;
                payload.Columns.Add(operationColumn);

                var userIdColumn = new DataColumn(ColUserId, typeof(Int32)) { DefaultValue = null };
                userIdColumn.ExtendedProperties[XPropType] = ColumnType.UserId;
                userIdColumn.ExtendedProperties[XPropDisplayName] = ColUserId;
                payload.Columns.Add(userIdColumn);

                var syncStatusStatus = new DataColumn(ColSyncStatus, typeof(String)) { DefaultValue = String.Empty };
                syncStatusStatus.ExtendedProperties[XPropType] = ColumnType.SyncStatus;
                syncStatusStatus.ExtendedProperties[XPropDisplayName] = ColSyncStatus;
                payload.Columns.Add(syncStatusStatus);

                var syncStatusDetails = new DataColumn(ColSyncDetails, typeof(String)) { DefaultValue = String.Empty };
                syncStatusDetails.ExtendedProperties[XPropType] = ColumnType.SyncStatus;
                syncStatusDetails.ExtendedProperties[XPropDisplayName] = ColSyncDetails;
                payload.Columns.Add(syncStatusDetails);

                payload.Columns.AddRange(operationalColumns.ToArray());
            }

            #endregion

            return errors;
        }

        public DataTable SyncByCommonNames(ref DataTable payload, int orgId, string locale)
        {
            ValidateAttributesData(ref payload);
            ValidateUserRolesData(ref payload);
            ValidateDevicesData(ref payload);

            MarkNewAndExistingUsersInUserSyncPayload(ref payload, orgId);

            var newUsers = (new DataView(payload) { RowFilter = "USER_ID IS NULL" }).ToTable(); // USER_ID IS NULL, INSERT THESE USERS
            var existingUsers = (new DataView(payload) { RowFilter = "USER_ID IS NOT NULL" }).ToTable(); // USER_ID IS NOT NULL, UPDATE THESE USERS

            ValidateNewUsers(ref newUsers, orgId, locale);
            ValidateExistingUsers(ref existingUsers, orgId);

            using (var scope = new TransactionScope())
            {
                InsertNewUsers(ref newUsers, orgId, locale);
                UpdateExistingUsers(ref existingUsers, orgId);

                scope.Complete();
            }

            var resultsPayload = new DataTable();
            resultsPayload.Merge(newUsers);
            resultsPayload.Merge(existingUsers);

            return resultsPayload;
        }

        #endregion

        #region Private members

        private void ValidateAttributesData(ref DataTable payload)
        {
            foreach (DataColumn column in payload.Columns)
            {
                if ((ColumnType)column.ExtendedProperties[XPropType] == ColumnType.Attribute)
                {
                    var attributeMetadata = (Attribute)column.ExtendedProperties[XPropMetadata];

                    #region Mandatory Attribute Check

                    // IF ATTRIBUTE IS MANDATORY BUT VALUE IS NOT GIVEN, REJECT THE ROW
                    if (attributeMetadata.IsMandatory)
                    {
                        payload
                        .AsEnumerable()
                        .Where(row => row.Field<string>(attributeMetadata.CommonName) == String.Empty).ToList()
                        .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_ATTRIBUTE_MANDATORY_BUT_NO_VALUE_PROVIDED + "; ", attributeMetadata.CommonName));
                    }

                    #endregion

                    #region Number Attribute Validations (Minimum, Maximum)

                    if (attributeMetadata.AttributeType == AttributeType.Number)
                    {
                        int minValue;

                        if (Int32.TryParse(attributeMetadata.MinValue, out minValue))
                        {
                            payload
                            .AsEnumerable()
                            .Where(row => row.Field<string>(attributeMetadata.CommonName) != String.Empty && Int32.Parse(row.Field<string>(attributeMetadata.CommonName)) < minValue).ToList()
                            .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_ATTRIBUTE_VALUE_LESS_THAN_DEFINED_CONSTRAINT + "; ", attributeMetadata.CommonName, minValue));
                        }

                        int maxValue;

                        if (Int32.TryParse(attributeMetadata.MaxValue, out maxValue))
                        {
                            payload
                            .AsEnumerable()
                            .Where(row => row.Field<string>(attributeMetadata.CommonName) != String.Empty && Int32.Parse(row.Field<string>(attributeMetadata.CommonName)) > maxValue).ToList()
                            .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_ATTRIBUTE_VALUE_MORE_THAN_DEFINED_CONSTRAINT + "; ", attributeMetadata.CommonName, maxValue));
                        }
                    }

                    #endregion

                    #region String Attribute Validations (Min Length, Max Length)

                    else if (attributeMetadata.AttributeType == AttributeType.String)
                    {
                        int minLength;

                        if (Int32.TryParse(attributeMetadata.MinValue, out minLength))
                        {
                            payload
                            .AsEnumerable()
                            .Where(row => row.Field<string>(attributeMetadata.CommonName) != String.Empty && row.Field<string>(attributeMetadata.CommonName).Length < minLength).ToList()
                            .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_ATTRIBUTE_VALUE_LENGTH_LESS_THAN_DEFINED_CONSTRAINT + "; ", attributeMetadata.CommonName, minLength));
                        }

                        int maxLength;

                        if (Int32.TryParse(attributeMetadata.MaxValue, out maxLength))
                        {
                            payload
                            .AsEnumerable()
                            .Where(row => row.Field<string>(attributeMetadata.CommonName) != String.Empty && row.Field<string>(attributeMetadata.CommonName).Length > maxLength).ToList()
                            .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_ATTRIBUTE_VALUE_LENGTH_MORE_THAN_DEFINED_CONSTRAINT + "; ", attributeMetadata.CommonName, maxLength));
                        }
                    }

                    #endregion

                    #region Date and DateTime Validations (Minimum, Maximum)
                    
                    else if (attributeMetadata.AttributeType == AttributeType.Date || attributeMetadata.AttributeType == AttributeType.DateTime)
                    {
                        DateTime minDateTime;

                        if (DateTime.TryParse(attributeMetadata.MinValue, out minDateTime))
                        {
                            payload
                            .AsEnumerable()
                            .Where(row => row.Field<string>(attributeMetadata.CommonName) != String.Empty && DateTime.Parse(row.Field<string>(attributeMetadata.CommonName)) < minDateTime).ToList()
                            .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_ATTRIBUTE_VALUE_LESS_THAN_DEFINED_DATE_CONSTRAINT + "; ", attributeMetadata.CommonName, minDateTime));
                        }

                        DateTime maxDateTime;

                        if (DateTime.TryParse(attributeMetadata.MaxValue, out maxDateTime))
                        {
                            payload
                            .AsEnumerable()
                            .Where(row => row.Field<string>(attributeMetadata.CommonName) != String.Empty && DateTime.Parse(row.Field<string>(attributeMetadata.CommonName)) > maxDateTime).ToList()
                            .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_ATTRIBUTE_VALUE_MORE_THAN_DEFINED_DATE_CONSTRAINT + "; ", attributeMetadata.CommonName, maxDateTime));
                        }
                    }

                    #endregion

                    #region List-Type Attribute Validations (List of Values)

                    else if (attributeMetadata.AttributeType == AttributeType.Picklist || attributeMetadata.AttributeType == AttributeType.MultiPicklist || attributeMetadata.AttributeType == AttributeType.Checkbox)
                    {
                        var columnName = attributeMetadata.CommonName;
                        var valColumnName = ":" + attributeMetadata.CommonName;
                        var idColumnName = "$" + attributeMetadata.CommonName;

                        // Clone the column values to the :VALIDATION and $ID columns added while validating the Payload
                        payload
                        .AsEnumerable().ToList()
                        .ForEach(r => {
                            r[valColumnName] = r[columnName];
                            r[idColumnName] = r[columnName];
                        });

                        // Find out invalid values using the :VALIDATION column by replacing value names with empty in :VALIDATION column for each value
                        // Convert the values found to VALUE_IDs in the $ID column by replacing value names with VALUE_IDs in the $ID column
                        foreach (var valueMetadata in attributeMetadata.ValuesMetadata)
                        {
                            payload
                            .AsEnumerable()
                            .Where(row => row.Field<string>(valColumnName) != String.Empty).ToList()
                            .ForEach(r =>
                            {
                                r[valColumnName] = r[valColumnName].ToString().Replace(valueMetadata.CommonName, "");
                                r[idColumnName] = r[idColumnName].ToString().Replace(valueMetadata.CommonName, valueMetadata.ValueId.ToString(CultureInfo.InvariantCulture));
                            });
                        }

                        // Cleanup the value string and check if anything still exists, this value is not found in the database
                        payload
                        .AsEnumerable().ToList()
                        .ForEach(b => b[valColumnName] = string.Join(",", b[valColumnName].ToString().Split(',').Where(x => x.Trim().Length != 0)));

                        // Mark these rows as error rows where the validation column is not empty
                        payload
                        .AsEnumerable()
                        .Where(row => row.Field<string>(valColumnName) != String.Empty).ToList()
                        .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_UNRECOGNIZED_STRINGS_FOUND_FOR_PICKLIST_ATTRIBUTE + "; ", attributeMetadata.CommonName, b.Field<string>(valColumnName)));
                    }

                    #endregion

                    #region Organizational Hierarchy (Value)

                    else if (attributeMetadata.AttributeType == AttributeType.Path)
                    {
                        var columnName = attributeMetadata.CommonName;
                        var valColumnName = ":" + attributeMetadata.CommonName;

                        // Clone the column values to the :VALIDATION column added while validating the Payload
                        payload
                        .AsEnumerable().ToList()
                        .ForEach(r => r[valColumnName] = r[columnName]);

                        // Find out invalid values using :VALIDATION column by replacing value names with empty in :VALIDATION column for each value
                        // Replace user given Org Hierarchy values with actual values from DB thus eliminating the small vs CAPS difference
                        foreach (var valueMetadata in attributeMetadata.ValuesMetadata)
                        {
                            var metadata = valueMetadata;

                            payload
                            .AsEnumerable()
                            .Where(row => row.Field<string>(valColumnName) != String.Empty && string.Equals(row.Field<string>(valColumnName), metadata.Name, StringComparison.CurrentCultureIgnoreCase)).ToList()
                            .ForEach(r => {
                                r[valColumnName] = "";
                                r[columnName] = metadata.Name;
                            });
                        }

                        // Mark these rows as error rows where the validation column is not empty
                        payload
                        .AsEnumerable()
                        .Where(row => row.Field<string>(valColumnName) != String.Empty).ToList()
                        .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_UNRECOGNIZED_STRINGS_FOUND_FOR_PATH_ATTRIBUTE + "; ", attributeMetadata.CommonName, b.Field<string>(valColumnName)));
                    }

                    #endregion
                    
                    //TODO:GEOGRAPHY (Geolocation)
                    else if (attributeMetadata.AttributeType == AttributeType.Geography)
                    {

                    }
                }
            }
        }

        private void ValidateUserRolesData(ref DataTable payload)
        {
            foreach (DataColumn column in payload.Columns)
            {
                if ((ColumnType)column.ExtendedProperties[XPropType] == ColumnType.UserRoles)
                {
                    const string columnName = ColUserRoles;
                    const string valColumnName = ":" + ColUserRoles;
                    const string idColumnName = "$" + ColUserRoles;

                    // Clone the column values to the :VALIDATION and $ID columns added while validating the Payload
                    payload.AsEnumerable().ToList()
                    .ForEach(r =>
                    {
                        r[valColumnName] = r[columnName];
                        r[idColumnName] = r[columnName];
                    });

                    // Find out invalid values using the :VALIDATION column by replacing value names with empty in :VALIDATION column for each value
                    // Convert the values found to VALUE_IDs in the $ID column by replacing value names with VALUE_IDs in the $ID column
                    foreach (var roleMetadata in (IEnumerable<UserRole>)column.ExtendedProperties[XPropMetadata])
                    {
                        payload.AsEnumerable()
                        .Where(row => row.Field<string>(valColumnName) != String.Empty).ToList()
                        .ForEach(r =>
                        {
                            r[valColumnName] = r.Field<string>(valColumnName).Replace(roleMetadata.CommonName, "");
                            r[idColumnName] = r.Field<string>(idColumnName).Replace(roleMetadata.CommonName, roleMetadata.RoleId.ToString(CultureInfo.InvariantCulture));
                        });
                    }

                    // Cleanup the value string and check if anything still exists, this value is not found in the database
                    payload.AsEnumerable().ToList().ForEach(b => b[valColumnName] = string.Join(",", b[valColumnName].ToString().Split(',').Where(x => x.Trim().Length != 0)));

                    // Mark these rows as error rows where the validation column is not empty
                    payload.AsEnumerable()
                    .Where(row => row.Field<string>(valColumnName) != String.Empty).ToList()
                    .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_UNRECOGNIZED_STRINGS_FOUND_FOR_COLUMN + "; ", ColUserRoles, b.Field<string>(valColumnName)));
                }
            }
        }

        private void ValidateDevicesData(ref DataTable payload)
        {
            foreach (DataColumn column in payload.Columns)
            {
                if ((ColumnType)column.ExtendedProperties[XPropType] == ColumnType.Device)
                {
                    var deviceMetadata = (Device)column.ExtendedProperties[XPropMetadata];

                    payload
                    .AsEnumerable()
                    .Where(row => row.Field<string>(deviceMetadata.CommonName) != String.Empty && row.Field<string>(deviceMetadata.CommonName).Length > deviceMetadata.AddressMaxLength).ToList()
                    .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_DEVICE_ADDRESS_LENGTH_IS_LONGER_THAN_DEFINED_CONSTRAINT + "; ", deviceMetadata.CommonName, deviceMetadata.AddressMaxLength));

                    if (deviceMetadata.AddressFormat != null && deviceMetadata.AddressFormat.Trim() != String.Empty)
                    {
                        var validationRegex = new Regex(deviceMetadata.AddressFormat);

                        payload
                        .AsEnumerable()
                        .Where(row => row.Field<string>(deviceMetadata.CommonName) != String.Empty && !validationRegex.IsMatch(row.Field<string>(deviceMetadata.CommonName))).ToList()
                        .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_DEVICE_ADDRESS_FORMAT_DOES_NOT_COMPLY + "; ", deviceMetadata.CommonName));    
                    }
                }
            }
        }

        private void MarkNewAndExistingUsersInUserSyncPayload(ref DataTable payload, int orgId)
        {
            var usersExist = _userRepository.CheckUsersExist(payload.DefaultView.ToTable(false, payload.Columns[ColLoginId].ColumnName), orgId);

            #region Mark Users to Update

            payload.AsEnumerable()
                .Join(
                    usersExist.AsEnumerable(),
                    lMaster => lMaster[ColLoginId], lChild => lChild[ColLoginId],
                    (lMaster, lChild) => new { lMaster, lChild }
                )
                .ToList()
                .ForEach(o => {
                    o.lMaster.SetField(ColUserId, o.lChild["USER_ID"]);
                    o.lMaster.SetField(ColOperation, "UPDATE");
                });

            #endregion

            #region Mark Users to Insert

            payload.AsEnumerable()
                .Where(r => r.Field<string>(ColOperation) == String.Empty).ToList()
                .ForEach(o => o.SetField(ColOperation, "INSERT"));

            #endregion
        }

        private void ValidateNewUsers(ref DataTable inserts, int orgId, string locale)
        {
            #region Remove STATUS = DEL records from the New Users Payload
            
            if (inserts.Columns.Contains(ColStatus))
            {
                var attributeMetadata = (Attribute)inserts.Columns[ColStatus].ExtendedProperties[XPropMetadata];
                var valueMetadata = attributeMetadata.ValuesMetadata;
                var deletedStatusValueMetadata = valueMetadata.First(o => o.CommonName == AttrValStatusDel);

                inserts
                .AsEnumerable()
                .Where(row => row.Field<string>("$" + ColStatus) != String.Empty && row.Field<string>("$" + ColStatus) == deletedStatusValueMetadata.ValueId.ToString(CultureInfo.InvariantCulture)).ToList()
                .ForEach(b => b[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_CANNOT_IMPORT_NEW_USER_WITH_STATUS_AS_DELETED + "; ", attributeMetadata.CommonName, deletedStatusValueMetadata.CommonName));
            }

            #endregion

            #region Username and MappingId Uniqueness Check in the System for New Operators

            if (inserts.Columns.Contains(ColUserRoles))
            {
                var newUsersWithRoles = (new DataView(inserts) { RowFilter = ColUserRoles + " <> ''" }).ToTable(false, new[] { ColLoginId });
                var newUsersWithRolesHavingUsernameExistingInIws = _userRepository.CheckUsernameUniquenessInSystem(newUsersWithRoles);

                inserts.AsEnumerable()
                    .Join(
                        newUsersWithRolesHavingUsernameExistingInIws.AsEnumerable(),
                        lMaster => lMaster[ColLoginId], lChild => lChild[ColLoginId],
                        (lMaster, lChild) => new { lMaster, lChild }
                    )
                    .ToList()
                    .ForEach(o => o.lMaster[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_USERNAME_ALREADY_EXISTS_IN_SYSTEM + "; ", UserResources.ATTRIBUTENAME_USERNAME));

                if (inserts.Columns.Contains(ColMappingId))
                {
                    var newUsersWithRolesHavingMappingIdExistingInIws = _userRepository.CheckMappingIdUniquenessInSystem(newUsersWithRoles);

                    inserts.AsEnumerable()
                        .Join(
                            newUsersWithRolesHavingMappingIdExistingInIws.AsEnumerable(),
                            lMaster => lMaster[ColMappingId], lChild => lChild[ColMappingId],
                            (lMaster, lChild) => new { lMaster, lChild }
                        )
                        .ToList()
                        .ForEach(o => o.lMaster[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_MAPPING_ID_ALREADY_EXISTS_IN_SYSTEM + "; ", UserResources.ATTRIBUTENAME_MAPPINGID));
                }
            }

            #endregion

            #region Username and MappingId Uniqueness Check in the Enterprise for all New Users

            var allNewUsers = new DataView(inserts).ToTable(false, new[] { ColLoginId });
            var allNewUsersHavingUsernamesExistingInEnterprise = _userRepository.CheckUsernameUniquenessInEnterprise(allNewUsers, orgId);

            inserts.AsEnumerable()
                .Join(
                    allNewUsersHavingUsernamesExistingInEnterprise.AsEnumerable(),
                    lMaster => lMaster[ColLoginId], lChild => lChild[ColLoginId],
                    (lMaster, lChild) => new { lMaster, lChild }
                )
                .ToList()
                .ForEach(o => o.lMaster[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_USERNAME_ALREADY_EXISTS_IN_ENTERPRISE_TREE + "; ", UserResources.ATTRIBUTENAME_USERNAME));

            if (inserts.Columns.Contains(ColMappingId))
            {
                var allNewUsersHavingMappingIdExistingInEnterprise = _userRepository.CheckMappingIdUniquenessInEnterprise(allNewUsers, orgId);

                inserts.AsEnumerable()
                        .Join(
                            allNewUsersHavingMappingIdExistingInEnterprise.AsEnumerable(),
                            lMaster => lMaster[ColMappingId], lChild => lChild[ColMappingId],
                            (lMaster, lChild) => new { lMaster, lChild }
                        )
                        .ToList()
                        .ForEach(o => o.lMaster[ColSyncDetails] += string.Format(UserResources.USERSYNC_ERROR_MAPPING_ID_ALREADY_EXISTS_IN_ENTERPRISE_TREE + "; ", UserResources.ATTRIBUTENAME_MAPPINGID));
            }

            #endregion

            // TODO: GET VALUES FOR MANDATORY ATTRIBUTES WITH DEFAULTS DEFINED THAT ARE NOT IN THE PAYLOAD AND ADD THE COLUMN TO THE DATATABLE
            #region Get default value(s) for missing mandatory Attributes and add to Payload

            #endregion

            #region Add required columns if they are not already present : SYSTEM-GROUPS, NPD, CREATEDON

            if (!inserts.Columns.Contains(ColIsMassCommunicationDevice))
            {
                var isMassCommunicationDeviceAttributeMetadata = _userAttributesRepository.GetUserAttributeMetadataByCommonName(ColIsMassCommunicationDevice, orgId, locale);
                var isMassCommDevice = new DataColumn(ColIsMassCommunicationDevice, typeof(String)) { DefaultValue = "NO" };
                isMassCommDevice.ExtendedProperties[XPropType] = ColumnType.Attribute;
                isMassCommDevice.ExtendedProperties[XPropMetadata] = isMassCommunicationDeviceAttributeMetadata;
                isMassCommDevice.ExtendedProperties[XPropDisplayName] = isMassCommunicationDeviceAttributeMetadata.Name;
                inserts.Columns.Add(isMassCommDevice);

                var idColumn = new DataColumn("$" + ColIsMassCommunicationDevice, typeof(String)) { DefaultValue = isMassCommunicationDeviceAttributeMetadata.ValuesMetadata.Single(x => x.CommonName == "NO").AttributeId };
                idColumn.ExtendedProperties[XPropType] = ColumnType.ValueIdentifiers;
                inserts.Columns.Add(idColumn);
            }

            if (!inserts.Columns.Contains(ColCreatedOn))
            {
                var createdOnAttributeMetadata = _userAttributesRepository.GetUserAttributeMetadataByCommonName(ColCreatedOn, orgId, locale);
                var createdOn = new DataColumn(ColCreatedOn, typeof(String)) { DefaultValue = DateTime.Now.ToString() };
                createdOn.ExtendedProperties[XPropType] = ColumnType.Attribute;
                createdOn.ExtendedProperties[XPropMetadata] = createdOnAttributeMetadata;
                createdOn.ExtendedProperties[XPropDisplayName] = createdOnAttributeMetadata.Name;
                inserts.Columns.Add(createdOn);
            }

            if (!inserts.Columns.Contains(ColSystemGroups))
            {
                var systemGroupsAttributeMetadata = _userAttributesRepository.GetUserAttributeMetadataByCommonName(ColSystemGroups, orgId, locale);
                var systemGroups = new DataColumn(ColSystemGroups, typeof(String)) { DefaultValue = "ACU,RGU" };
                systemGroups.ExtendedProperties[XPropType] = ColumnType.Attribute;
                systemGroups.ExtendedProperties[XPropMetadata] = systemGroupsAttributeMetadata;
                systemGroups.ExtendedProperties[XPropDisplayName] = systemGroupsAttributeMetadata.Name;
                inserts.Columns.Add(systemGroups);

                var idColumn = new DataColumn("$" + ColSystemGroups, typeof(String)) { DefaultValue = String.Join(",", systemGroupsAttributeMetadata.ValuesMetadata.Where(x => x.CommonName == "ACU" || x.CommonName == "RGU").Select(x => x.ValueId)) };
                idColumn.ExtendedProperties[XPropType] = ColumnType.ValueIdentifiers;
                inserts.Columns.Add(idColumn);
            }

            #endregion
        }

        private void ValidateExistingUsers(ref DataTable updates, int orgId)
        {
            // UPDATE DELETED RECORDS AND REMOVE FROM DATATABLE
        }

        private void InsertNewUsers(ref DataTable inserts, int orgId, string locale)
        {
            var allValidNewUsers = inserts.AsEnumerable().Where(row => row.Field<string>(ColSyncDetails) == String.Empty);
            var startUserId = _globalRepository.GetSequence(SequenceType.USER_ID, allValidNewUsers.Count());

            foreach (var row in allValidNewUsers) row[ColUserId] = startUserId++; // add USER_ID to all importable rows

            InsertUsers(ref inserts, orgId);
            InsertAttributes(ref inserts);
            InsertUserRoles(ref inserts, orgId);
            InsertDevices(ref inserts);

            RemoveOperationalColumns(ref inserts);
            FinalizeAndCleanupSyncStatusColumns(ref inserts, "INSERT");
        }

        private void UpdateExistingUsers(ref DataTable updates, int orgId)
        {
            // DATATABLE TRANSFORM TO DB TABLES FROM PAYLOAD CACHE. TRANSFORM PICKLIST VALUES TO VALUE IDs
            // BULK INSERT TO DATABASE

            RemoveOperationalColumns(ref updates);
            FinalizeAndCleanupSyncStatusColumns(ref updates, "UPDATE");
        }

        private void InsertUsers(ref DataTable inserts, int orgId)
        {
            var query = from row in inserts.AsEnumerable()
                        where row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>(ColOperation) == "INSERT"
                        select new
                        {
                            USER_ID = row.Field<int>(ColUserId),
                            TOKEN = Path.GetRandomFileName().Replace(".", "").Substring(0, 8),
                            USER_TYPE_ID = "RG",
                            PROVIDER_ID = orgId,
                            CREATE_TYPE = "NA"
                        };

            _globalRepository.BulkCopyToDatabase(TblUsrUserTab, query.ToDataTable());
        }

        private void InsertAttributes(ref DataTable inserts)
        {
            foreach (DataColumn column in inserts.Columns)
            {
                if ((ColumnType) column.ExtendedProperties[XPropType] == ColumnType.Attribute)
                {
                    var attributeMetadata = (Attribute) column.ExtendedProperties[XPropMetadata];

                    #region Number Attributes

                    if (attributeMetadata.AttributeType == AttributeType.Number)
                    {
                        var query = from row in inserts.AsEnumerable()
                            where row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>(attributeMetadata.CommonName) != String.Empty
                            select new
                            {
                                USER_ID = row.Field<int>(ColUserId),
                                ATTRIBUTE_ID = attributeMetadata.AttributeId,
                                INTEGER_VALUE = Int32.Parse(row.Field<string>(attributeMetadata.CommonName)),
                                IS_NEW = "Y",
                                UPDATED_ON = DateTime.Now.Subtract(new DateTime(2000, 1, 1)).TotalSeconds,
                                UPDATED_BY = 1, // TODO: UPDATED_BY
                                UPDATED_FROM = UpdatedFrom
                            };

                        _globalRepository.BulkCopyToDatabase(TblUsrAttributeValueTab, query.ToDataTable());
                    }

                    #endregion

                    #region String Attributes

                    else if (attributeMetadata.AttributeType == AttributeType.String)
                    {
                        #region For User Password column, we need to HASH the password and also need to update the USER_RANDOM_ID and PASSWORD_UPDATED_ON

                        if (attributeMetadata.CommonName == ColUserPassword)
                        {
                            // TODO : Verify Password Complexity

                            inserts
                            .AsEnumerable()
                            .Where(row => row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>(ColUserPassword) != String.Empty).ToList()
                            .ForEach(r =>
                            {
                                r[ColUserRandomId] = PasswordEncryptionHelper.GenerateSalt();
                                r[ColUserPasswordUpdatedOn] = (int) DateTime.Now.Subtract(new DateTime(2000, 1, 1)).TotalSeconds;
                            });

                            var usrRandomIdMetadata = (Attribute)inserts.Columns[ColUserRandomId].ExtendedProperties[XPropMetadata];
                            var usrRandomId = from row in inserts.AsEnumerable()
                                              where row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>(ColUserRandomId) != String.Empty
                                              select new
                                              {
                                                  USER_ID = row.Field<int>(ColUserId),
                                                  ATTRIBUTE_ID = usrRandomIdMetadata.AttributeId,
                                                  STRING_VALUE = row.Field<string>(ColUserRandomId),
                                                  IS_NEW = "Y",
                                                  UPDATED_ON = DateTime.Now.Subtract(new DateTime(2000, 1, 1)).TotalSeconds,
                                                  UPDATED_BY = 1, // TODO: UPDATED_BY
                                                  UPDATED_FROM = UpdatedFrom
                                              };

                            _globalRepository.BulkCopyToDatabase(TblUsrAttributeValueTab, usrRandomId.ToDataTable());

                            var usrPasswordUpdatedOnMetadata = (Attribute)inserts.Columns[ColUserPasswordUpdatedOn].ExtendedProperties[XPropMetadata];
                            var usrPasswordUpdatedOn = from row in inserts.AsEnumerable()
                                                       where row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>(ColUserPasswordUpdatedOn) != String.Empty
                                                       select new
                                                       {
                                                           USER_ID = row.Field<int>(ColUserId),
                                                           ATTRIBUTE_ID = usrPasswordUpdatedOnMetadata.AttributeId,
                                                           INTEGER_VALUE = Int32.Parse(row.Field<string>(ColUserPasswordUpdatedOn)),
                                                           IS_NEW = "Y",
                                                           UPDATED_ON = DateTime.Now.Subtract(new DateTime(2000, 1, 1)).TotalSeconds,
                                                           UPDATED_BY = 1, // TODO: UPDATED_BY
                                                           UPDATED_FROM = UpdatedFrom
                                                       };

                            _globalRepository.BulkCopyToDatabase(TblUsrAttributeValueTab, usrPasswordUpdatedOn.ToDataTable());

                            var usrPassword = from row in inserts.AsEnumerable()
                                              where row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>(ColUserPassword) != String.Empty
                                              select new
                                              {
                                                  USER_ID = row.Field<int>(ColUserId),
                                                  ATTRIBUTE_ID = attributeMetadata.AttributeId,
                                                  STRING_VALUE = PasswordEncryptionHelper.HashPassword(row.Field<int>(ColUserId), row.Field<string>(ColUserRandomId), row.Field<string>(ColUserPassword)),
                                                  IS_NEW = "Y",
                                                  UPDATED_ON = DateTime.Now.Subtract(new DateTime(2000, 1, 1)).TotalSeconds,
                                                  UPDATED_BY = 1, // TODO: UPDATED_BY
                                                  UPDATED_FROM = UpdatedFrom
                                              };

                            _globalRepository.BulkCopyToDatabase(TblUsrAttributeValueTab, usrPassword.ToDataTable());

                            continue;
                        }

                        #endregion

                        var query = from row in inserts.AsEnumerable()
                                    where row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>(attributeMetadata.CommonName) != String.Empty
                                    select new
                                    {
                                        USER_ID = row.Field<int>(ColUserId),
                                        ATTRIBUTE_ID = attributeMetadata.AttributeId,
                                        STRING_VALUE = row.Field<string>(attributeMetadata.CommonName),
                                        IS_NEW = "Y",
                                        UPDATED_ON = DateTime.Now.Subtract(new DateTime(2000, 1, 1)).TotalSeconds,
                                        UPDATED_BY = 1, // TODO: UPDATED_BY
                                        UPDATED_FROM = UpdatedFrom
                                    };

                        _globalRepository.BulkCopyToDatabase(TblUsrAttributeValueTab, query.ToDataTable());
                    }

                    #endregion

                    #region Date and DateTime Attributes

                    else if (attributeMetadata.AttributeType == AttributeType.Date || attributeMetadata.AttributeType == AttributeType.DateTime)
                    {
                        var query = from row in inserts.AsEnumerable()
                            where row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>(attributeMetadata.CommonName) != String.Empty
                            select new
                            {
                                USER_ID = row.Field<int>(ColUserId),
                                ATTRIBUTE_ID = attributeMetadata.AttributeId,
                                DATE_VALUE = DateTime.Parse(row.Field<string>(attributeMetadata.CommonName)),
                                IS_NEW = "Y",
                                UPDATED_ON = DateTime.Now.Subtract(new DateTime(2000, 1, 1)).TotalSeconds,
                                UPDATED_BY = 1, // TODO: UPDATED_BY
                                UPDATED_FROM = UpdatedFrom
                            };

                        _globalRepository.BulkCopyToDatabase(TblUsrAttributeValueTab, query.ToDataTable());
                    }

                    #endregion

                    #region List-Type Attributes

                    else if (attributeMetadata.AttributeType == AttributeType.Picklist || attributeMetadata.AttributeType == AttributeType.MultiPicklist || attributeMetadata.AttributeType == AttributeType.Checkbox)
                    {
                        var query = from row in inserts.AsEnumerable()
                            where row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>("$" + attributeMetadata.CommonName) != String.Empty
                            select new
                            {
                                USER_ID = row.Field<int>(ColUserId),
                                ATTRIBUTE_ID = attributeMetadata.AttributeId,
                                VALUE_ID = row.Field<string>("$" + attributeMetadata.CommonName),
                                IS_NEW = "Y",
                                UPDATED_ON = DateTime.Now.Subtract(new DateTime(2000, 1, 1)).TotalSeconds,
                                UPDATED_BY = 1, // TODO: UPDATED_BY
                                UPDATED_FROM = UpdatedFrom
                            };

                        var usrAttributeValueTable = new DataTable();
                        usrAttributeValueTable.Columns.Add("USER_ID", typeof (int));
                        usrAttributeValueTable.Columns.Add("ATTRIBUTE_ID", typeof (int));
                        usrAttributeValueTable.Columns.Add("VALUE_ID", typeof (int));
                        usrAttributeValueTable.Columns.Add("IS_NEW", typeof (string));
                        usrAttributeValueTable.Columns.Add("UPDATED_ON", typeof (int));
                        usrAttributeValueTable.Columns.Add("UPDATED_BY", typeof (int));
                        usrAttributeValueTable.Columns.Add("UPDATED_FROM", typeof (string));

                        foreach (var row in query.AsEnumerable())
                        {
                            foreach (var valueId in row.VALUE_ID.Split(',').Distinct())
                            {
                                var insertRow = usrAttributeValueTable.NewRow();

                                insertRow["USER_ID"] = row.USER_ID;
                                insertRow["ATTRIBUTE_ID"] = row.ATTRIBUTE_ID;
                                insertRow["VALUE_ID"] = valueId;
                                insertRow["IS_NEW"] = row.IS_NEW;
                                insertRow["UPDATED_ON"] = row.UPDATED_ON;
                                insertRow["UPDATED_BY"] = row.UPDATED_BY;
                                insertRow["UPDATED_FROM"] = row.UPDATED_FROM;

                                usrAttributeValueTable.Rows.Add(insertRow);
                            }
                        }

                        _globalRepository.BulkCopyToDatabase(TblUsrAttributeValueTab, usrAttributeValueTable);
                    }

                    #endregion

                    #region Organizational Hierarchy Attribute

                    else if (attributeMetadata.AttributeType == AttributeType.Path)
                    {
                        var query = from row in inserts.AsEnumerable()
                                    where row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>(attributeMetadata.CommonName) != String.Empty
                                    select new
                                    {
                                        USER_ID = row.Field<int>(ColUserId),
                                        ATTRIBUTE_ID = attributeMetadata.AttributeId,
                                        STRING_VALUE = row.Field<string>(attributeMetadata.CommonName),
                                        IS_NEW = "Y",
                                        UPDATED_ON = DateTime.Now.Subtract(new DateTime(2000, 1, 1)).TotalSeconds,
                                        UPDATED_BY = 1, // TODO: UPDATED_BY
                                        UPDATED_FROM = UpdatedFrom
                                    };

                        _globalRepository.BulkCopyToDatabase(TblUsrAttributeValueTab, query.ToDataTable());
                    }

                    #endregion

                    //TODO:GEOGRAPHY (Geolocation)
                    else if (attributeMetadata.AttributeType == AttributeType.Geography)
                    {
                    }
                }
            }
        }

        private void InsertUserRoles(ref DataTable inserts, int orgId)
        {
            foreach (DataColumn column in inserts.Columns)
            {
                if ((ColumnType) column.ExtendedProperties[XPropType] == ColumnType.UserRoles)
                {
                    //var rolesMetadata = (IEnumerable<UserRoleMetadata>)column.ExtendedProperties[XPropMetadata];

                    var query = from row in inserts.AsEnumerable()
                                where row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>("$" + ColUserRoles) != String.Empty
                                select new
                                {
                                    USER_ID = row.Field<int>(ColUserId),
                                    ROLE_ID = row.Field<string>("$" + ColUserRoles),
                                    PROVIDER_FILTER = orgId
                                };

                    var upsUserRoleTab = new DataTable();
                    upsUserRoleTab.Columns.Add("ROLE_ID", typeof(int));
                    upsUserRoleTab.Columns.Add("USER_ID", typeof(int));
                    upsUserRoleTab.Columns.Add("PROVIDER_FILTER", typeof(string));

                    upsUserRoleTab.PrimaryKey = new[] { upsUserRoleTab.Columns["ROLE_ID"], upsUserRoleTab.Columns["USER_ID"], upsUserRoleTab.Columns["PROVIDER_FILTER"] };

                    var upsEntityAccessTab = new DataTable();
                    upsEntityAccessTab.Columns.Add("USER_ID", typeof(int));
                    upsEntityAccessTab.Columns.Add("PROVIDER_ID", typeof(int));
                    upsEntityAccessTab.Columns.Add("ACCESS_TYPE", typeof(string));
                    upsEntityAccessTab.Columns.Add("ENTITY_TYPE", typeof(string));
                    upsEntityAccessTab.Columns.Add("ENTITY_ID", typeof(int));

                    upsEntityAccessTab.PrimaryKey = new[] { upsEntityAccessTab.Columns["USER_ID"], upsEntityAccessTab.Columns["PROVIDER_ID"], upsEntityAccessTab.Columns["ACCESS_TYPE"], upsEntityAccessTab.Columns["ENTITY_TYPE"], upsEntityAccessTab.Columns["ENTITY_ID"] };

                    foreach (var row in query.AsEnumerable())
                    {
                        foreach (var roleId in row.ROLE_ID.Split(',').Distinct())
                        {
                            var upsUserRoleTabRow = upsUserRoleTab.NewRow();

                            upsUserRoleTabRow["ROLE_ID"] = roleId;
                            upsUserRoleTabRow["USER_ID"] = row.USER_ID;
                            upsUserRoleTabRow["PROVIDER_FILTER"] = orgId;

                            var upsEntityAccessTabTrgRow = upsEntityAccessTab.NewRow();

                            upsEntityAccessTabTrgRow["USER_ID"] = row.USER_ID;
                            upsEntityAccessTabTrgRow["PROVIDER_ID"] = orgId;
                            upsEntityAccessTabTrgRow["ACCESS_TYPE"] = "TRG";
                            upsEntityAccessTabTrgRow["ENTITY_TYPE"] = "LST";
                            upsEntityAccessTabTrgRow["ENTITY_ID"] = -1;

                            var upsEntityAccessTabMgtRow = upsEntityAccessTab.NewRow();

                            upsEntityAccessTabMgtRow["USER_ID"] = row.USER_ID;
                            upsEntityAccessTabMgtRow["PROVIDER_ID"] = orgId;
                            upsEntityAccessTabMgtRow["ACCESS_TYPE"] = "MGT";
                            upsEntityAccessTabMgtRow["ENTITY_TYPE"] = "LST";
                            upsEntityAccessTabMgtRow["ENTITY_ID"] = -1;

                            if (!upsUserRoleTab.Rows.Contains(new[] { upsUserRoleTabRow["ROLE_ID"], upsUserRoleTabRow["USER_ID"], upsUserRoleTabRow["PROVIDER_FILTER"] })) upsUserRoleTab.Rows.Add(upsUserRoleTabRow);
                            if (!upsEntityAccessTab.Rows.Contains(new[] { upsEntityAccessTabTrgRow["USER_ID"], upsEntityAccessTabTrgRow["PROVIDER_ID"], upsEntityAccessTabTrgRow["ACCESS_TYPE"], upsEntityAccessTabTrgRow["ENTITY_TYPE"], upsEntityAccessTabTrgRow["ENTITY_ID"] })) upsEntityAccessTab.Rows.Add(upsEntityAccessTabTrgRow);
                            if (!upsEntityAccessTab.Rows.Contains(new[] { upsEntityAccessTabMgtRow["USER_ID"], upsEntityAccessTabMgtRow["PROVIDER_ID"], upsEntityAccessTabMgtRow["ACCESS_TYPE"], upsEntityAccessTabMgtRow["ENTITY_TYPE"], upsEntityAccessTabMgtRow["ENTITY_ID"] })) upsEntityAccessTab.Rows.Add(upsEntityAccessTabMgtRow);
                        }
                    }

                    _globalRepository.BulkCopyToDatabase(TblUpsUserRoleTab, upsUserRoleTab);
                    _globalRepository.BulkCopyToDatabase(TblUpsEntityAccessTab, upsEntityAccessTab);
                }
            }
        }

        private void InsertDevices(ref DataTable inserts)
        {
            foreach (DataColumn column in inserts.Columns)
            {
                if ((ColumnType)column.ExtendedProperties[XPropType] == ColumnType.Device)
                {
                    var cryptoProvider = new SHA1CryptoServiceProvider();
                    var deviceMetadata = (Device)column.ExtendedProperties[XPropMetadata];

                    var newDevices = inserts.AsEnumerable().Where(row => row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>(deviceMetadata.CommonName) != String.Empty);
                    var startAddressId = _globalRepository.GetSequence(SequenceType.ADDRESS_ID, newDevices.Count());

                    var query = from row in inserts.AsEnumerable()
                                where row.Field<string>(ColSyncDetails) == String.Empty && row.Field<string>(deviceMetadata.CommonName) != String.Empty
                                select new
                                {
                                    ADDRESS_ID = startAddressId++,
                                    USER_ID = row.Field<int>(ColUserId),
                                    ADDRESS = row.Field<string>(deviceMetadata.CommonName),
                                    DEVICE_ID = deviceMetadata.Id,
                                    IS_PRIMARY = "Y",
                                    UPDATED_ON = DateTime.Now,
                                    UPDATED_BY_USERNAME = "athocadmin", // TODO: UPDATED_BY_USERNAME
                                    HASHED_CLEAN_ADDRESS = cryptoProvider.ComputeHash(Encoding.Unicode.GetBytes(row.Field<string>(deviceMetadata.CommonName).ToLower()))
                                };

                    _globalRepository.BulkCopyToDatabase(TblUsrDeviceAddressTab, query.ToDataTable());
                }
            }
        }

        private void RemoveOperationalColumns(ref DataTable payload)
        {
            #region Remove operational and validation columns
            
            var columnsToRemove = (
                from DataColumn column in payload.Columns 
                let columnType = (ColumnType) column.ExtendedProperties[XPropType] 
                where columnType == ColumnType.Operational || columnType == ColumnType.Validation || columnType == ColumnType.ValueIdentifiers 
                select column
                ).ToList();

            foreach (var column in columnsToRemove) payload.Columns.Remove(column);

            #endregion
        }

        private void FinalizeAndCleanupSyncStatusColumns(ref DataTable payload, string payloadType)
        {
            #region Finalize and cleanup Sync-Status column

            payload
            .AsEnumerable().ToList()
            .ForEach(b => { b[ColSyncStatus] = b.Field<string>(ColSyncDetails) == String.Empty ? UserResources.USERSYNC_RESULT_OK : UserResources.USERSYNC_RESULT_ERROR; });

            payload
            .AsEnumerable()
            .Where(row => row.Field<string>(ColSyncDetails) == String.Empty).ToList()
            .ForEach(b => { b[ColSyncDetails] = payloadType == "INSERT" ? UserResources.USERSYNC_RESULT_USER_IMPORTED_SUCCESSFULLY : UserResources.USERSYNC_RESULT_USER_UPDATED_SUCCESSFULLY; });

            payload
            .AsEnumerable().ToList()
            .ForEach(b => b[ColSyncDetails] = b.Field<string>(ColSyncDetails).ReplaceLastOccurrence("; ", ""));

            #endregion
        }

        #endregion
    }
}
