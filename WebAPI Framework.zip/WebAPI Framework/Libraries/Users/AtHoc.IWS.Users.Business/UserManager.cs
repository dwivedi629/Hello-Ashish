﻿using AtHoc.IWS.Interfaces.Business.Users;
using AtHoc.IWS.Interfaces.DataAccess.Users;

namespace AtHoc.IWS.Users.Business
{
    public class UserManager : ManagerBase, IUserManager
    {
        private readonly IUserRepository _userRepository;

        public UserManager(IConfigSettings configSettings, IUserRepository userRepository) : base(configSettings)
        {
            _userRepository = userRepository;
        }

        public bool CheckUserExists(int userId)
        {
            return _userRepository.CheckUserExistsByUserId(userId);
        }

        public int GetProviderForUser(int userId)
        {
            return _userRepository.GetProviderForUser(userId);
        }

        public bool MoveUserToOrg(int userId, int orgId)
        {
            return _userRepository.MoveUserToOrg(userId, orgId);
        }
    }
}
