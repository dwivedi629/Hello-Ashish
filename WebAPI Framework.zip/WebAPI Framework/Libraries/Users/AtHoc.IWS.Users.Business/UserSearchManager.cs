﻿using AtHoc.IWS.Interfaces.Business.Users;
using AtHoc.IWS.Interfaces.DataAccess.Users;

namespace AtHoc.IWS.Users.Business
{
    public class UserSearchManager : ManagerBase, IUserSearchManager
    {
        private readonly IUserSearchRepository _userSearchRepository;

        public UserSearchManager(IConfigSettings configSettings, IUserSearchRepository userSearchRepository) : base(configSettings)
        {
            _userSearchRepository = userSearchRepository;
        }

        public Models.UserSearch.ContextSearchResult SearchUsersV2ByContext(Models.UserSearch.UserSearchArgs args)
        {
            return _userSearchRepository.SearchUsersV2ByContext(args);
        }

        public Models.UserSearch.SessionSearchResult SearchUsersV2BySession(Models.UserSearch.UserSearchSession args)
        {
            return _userSearchRepository.SearchUsersV2BySession(args);
        }

        public Models.UserSearch.AlertSearchResult SearchUsersV2ByAlert(Models.UserSearch.UserSearchAlert args)
        {
            return _userSearchRepository.SearchUsersV2ByAlert(args);
        }
    }
}
