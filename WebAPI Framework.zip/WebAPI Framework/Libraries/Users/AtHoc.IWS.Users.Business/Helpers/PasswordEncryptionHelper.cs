﻿using System;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace AtHoc.IWS.Users.Business.Helpers
{
    public static class PasswordEncryptionHelper
    {
        public static string GenerateSalt()
        {
            // Generate a cryptographic random number using the cryptographic service provider
            var rng = new RNGCryptoServiceProvider();
            var buff = new byte[16];
            rng.GetBytes(buff);

            // Return a Base64 string representation of the random number
            return Convert.ToBase64String(buff);
        }

        public static string HashPassword(int userId, string salt, string password)
        {
            var randomizerBytes = Encoding.Unicode.GetBytes(userId.ToString(CultureInfo.InvariantCulture));
            var saltBytes = Convert.FromBase64String(salt);
            var pwdBytes = Encoding.Unicode.GetBytes(password);
            var combinedBytes = new byte[randomizerBytes.Length + saltBytes.Length + pwdBytes.Length];

            Buffer.BlockCopy(randomizerBytes, 0, combinedBytes, 0, randomizerBytes.Length);
            Buffer.BlockCopy(saltBytes, 0, combinedBytes, randomizerBytes.Length, saltBytes.Length);
            Buffer.BlockCopy(pwdBytes, 0, combinedBytes, randomizerBytes.Length + saltBytes.Length, pwdBytes.Length);

            var sha1 = SHA1.Create();
            var inArray = sha1.ComputeHash(combinedBytes);

            return Convert.ToBase64String(inArray);
        }
    }
}
