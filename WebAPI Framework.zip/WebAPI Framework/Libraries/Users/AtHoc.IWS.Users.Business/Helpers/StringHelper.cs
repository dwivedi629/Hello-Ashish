﻿
namespace AtHoc.IWS.Users.Business.Helpers
{
    public static class StringHelper
    {
        public static string ReplaceLastOccurrence(this string source, string find, string replace)
        {
            var place = source.LastIndexOf(find, System.StringComparison.Ordinal);

            return place == -1 ? source : source.Remove(place, find.Length).Insert(place, replace);
        }
    }
}
