﻿using System.Collections.Generic;
using System.Data;
using AtHoc.IWS.Interfaces.DataAccess.Users;
using AtHoc.IWS.Models.UserRoles;
using Dapper;

namespace AtHoc.IWS.Users.DataAccess
{
    public class UserRolesRepository : RepositoryBase, IUserRolesRepository
    {
        public UserRolesRepository(IConfigSettings configSettings, IDbConnection cn) : base(configSettings, cn)
        {

        }

        public IEnumerable<UserRole> GetUserRolesMetadataByOrg(int orgId, string locale)
        {
            var cn = OpenConnection();

            var metadata = cn.Query<UserRole>(@"
/* GetUserRolesMetadataByOrg */
SELECT
	r.ROLE_ID as RoleId, 
	r.ROLE_NAME as Name, 
	r.[DESCRIPTION] as [Description], 
	r.[COMMON_NAME] as CommonName, 
	CASE WHEN r.UNRESTRICTED_ALERTFOLDERS = 'Y' THEN 'true' ELSE 'false' END AS UnrestrictedAlertFolders,
	CASE WHEN r.UNRESTRICTED_USERBASE = 'Y' THEN 'true' ELSE 'false' END AS UnrestrictedUserbase,
	CASE WHEN r.UNRESTRICTED_ENTITYACCESS = 'Y' THEN 'true' ELSE 'false' END AS UnrestrictedEntityAccess
FROM
	PRV_EXTENDED_PARAMS_TAB ep (nolock)
	INNER JOIN PRV_TYPE_LOOKUP_TAB tl (nolock) ON (tl.COMMON_NAME = ep.PROVIDER_TYPE)
	INNER JOIN UPS_ROLE_PRV_TYPE_MAP_TAB rptm (nolock) ON (rptm.PROVIDER_TYPE_ID = tl.TYPE_ID)
	INNER JOIN UPS_ROLE_TAB r (nolock) ON (r.ROLE_ID = rptm.ROLE_ID)
WHERE
	ep.PROVIDER_ID = @PROVIDER_ID
	AND STATUS = 'ACT'
",
 new { PROVIDER_ID = orgId });

            return metadata;
        }
    }
}
