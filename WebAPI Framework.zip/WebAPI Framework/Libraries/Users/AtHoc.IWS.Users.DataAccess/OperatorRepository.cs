﻿using System.Data;
using System.Linq;
using AtHoc.IWS.Interfaces.DataAccess.Users;
using AtHoc.IWS.Models.Users;
using Dapper;

namespace AtHoc.IWS.Users.DataAccess
{
    public class OperatorRepository : RepositoryBase, IOperatorRepository
    {
        public OperatorRepository(IConfigSettings configSettings, IDbConnection cn) : base(configSettings, cn)
        {

        }

        public Operator GetOperatorFromUsername(string username)
        {
            var cn = OpenConnection();

            return cn.Query<Operator>(@"
/* GetOperatorFromUsername */
DECLARE @ATTRIBUTE_ID INT = (SELECT ATTRIBUTE_ID FROM PRV_ATTRIBUTE_TAB WHERE COMMON_NAME = 'LOGIN_ID')

SELECT
	u.USER_ID as Id, u.PROVIDER_ID as OrgId
FROM
	USR_ATTRIBUTE_VALUE_TAB av
	INNER JOIN USR_USER_TAB u ON (av.USER_ID = u.USER_ID)
WHERE
	av.ATTRIBUTE_ID = @ATTRIBUTE_ID
	AND av.STRING_VALUE = @LOGIN_ID
	AND EXISTS (SELECT 0 FROM UPS_ENTITY_ACCESS_TAB WHERE USER_ID = u.USER_ID)"
            , new { LOGIN_ID = username }
            ).FirstOrDefault();
        }

        public bool RemoveAllOperatorRolesForUser(int userId)
        {
            var cn = OpenConnection();

            cn.Execute(@"
/* RemoveAllOperatorRolesForUser */
DELETE FROM UPS_ENTITY_ACCESS_TAB WHERE USER_ID = @USER_ID
DELETE FROM UPS_USER_BASE_TAB WHERE USER_ID = @USER_ID
DELETE FROM UPS_USER_ROLE_TAB WHERE USER_ID = @USER_ID"
            , new { USER_ID = userId }
            );

            return true;
        }
    }
}
