﻿using System;
using System.Data;
using AtHoc.IWS.Interfaces.DataAccess.Users;
using Dapper;

namespace AtHoc.IWS.Users.DataAccess
{
    public class UserRepository : RepositoryBase, IUserRepository
    {
        public UserRepository(IConfigSettings configSettings, IDbConnection cn) : base(configSettings, cn)
        {

        }

        public bool CheckUserExistsByUserId(int userId)
        {
            var cn = OpenConnection();

            return cn.ExecuteScalar<bool>(@"
/* CheckUserExistsByUserId */
IF EXISTS (SELECT 0 FROM USR_USER_TAB (nolock) WHERE USER_ID = @USER_ID) SELECT 1 ELSE SELECT 0
", new { USER_ID = userId });
        }

        public bool CheckUserExistsByUsername(string username)
        {
            throw new NotImplementedException();
        }

        public bool CheckUserExistsByUsernameAndPassword(string username, string password)
        {
            throw new NotImplementedException();
        }

        public DataTable CheckUsersExist(DataTable userList, int orgId)
        {
            var cn = OpenConnection();

            var usersReader = cn.ExecuteReader(@"[dbo].[USERSYNC_GET_EXISTING_USERNAMES_IN_ENTERPRISE_TREE]", new { USERNAMES = userList.AsTableValuedParameter("dbo.STRING_ENTITIES"), PROVIDER_ID = orgId }, commandType: CommandType.StoredProcedure);

            var users = new DataTable();

            users.Load(usersReader);

            return users;
        }

        public int GetProviderForUser(int userId)
        {
            var cn = OpenConnection();

            return cn.ExecuteScalar<int>(@"
/* GetProviderForUser */
SELECT PROVIDER_ID FROM USR_USER_TAB (nolock) WHERE USER_ID = @USER_ID
", new { USER_ID = userId });
        }

        public bool MoveUserToOrg(int userId, int orgId)
        {
            var cn = OpenConnection();

            var rowsAffected = cn.Execute(@"
/* MoveUserToOrg */
UPDATE USR_USER_TAB SET PROVIDER_ID = @PROVIDER_ID WHERE USER_ID = @USER_ID
", new { USER_ID = userId, PROVIDER_ID = orgId });

            return rowsAffected > 0;
        }

        public DataTable CheckUsernameUniquenessInSystem(DataTable userList)
        {
            var cn = OpenConnection();

            var usernamesReader = cn.ExecuteReader("[dbo].[USERSYNC_CHECK_USERNAMES_UNIQUENESS_IN_SYSTEM]", new { USERNAMES = userList.AsTableValuedParameter("dbo.STRING_ENTITIES") }, commandType: CommandType.StoredProcedure);

            var usernames = new DataTable();

            usernames.Load(usernamesReader);

            return usernames;
        }

        public DataTable CheckUsernameUniquenessInEnterprise(DataTable userList, int orgId)
        {
            var cn = OpenConnection();

            var usernamesReader = cn.ExecuteReader("[dbo].[USERSYNC_CHECK_USERNAMES_UNIQUENESS_IN_ENTERPRISE]", new { USERNAMES = userList.AsTableValuedParameter("dbo.STRING_ENTITIES"), PROVIDER_ID = orgId }, commandType: CommandType.StoredProcedure);

            var usernames = new DataTable();

            usernames.Load(usernamesReader);

            return usernames;
        }

        public DataTable CheckMappingIdUniquenessInSystem(DataTable userList)
        {
            var cn = OpenConnection();

            var mappingIdsReader = cn.ExecuteReader("[dbo].[USERSYNC_CHECK_MAPPINGIDs_UNIQUENESS_IN_SYSTEM]", new { USERNAMES = userList.AsTableValuedParameter("dbo.STRING_ENTITIES") }, commandType: CommandType.StoredProcedure);

            var mappingIds = new DataTable();

            mappingIds.Load(mappingIdsReader);

            return mappingIds;
        }

        public DataTable CheckMappingIdUniquenessInEnterprise(DataTable userList, int orgId)
        {
            var cn = OpenConnection();

            var mappingIdsReader = cn.ExecuteReader("[dbo].[USERSYNC_CHECK_MAPPINGIDs_UNIQUENESS_IN_ENTERPRISE]", new { USERNAMES = userList.AsTableValuedParameter("dbo.STRING_ENTITIES"), PROVIDER_ID = orgId }, commandType: CommandType.StoredProcedure);

            var mappingIds = new DataTable();

            mappingIds.Load(mappingIdsReader);

            return mappingIds;
        }


        
    }
}
