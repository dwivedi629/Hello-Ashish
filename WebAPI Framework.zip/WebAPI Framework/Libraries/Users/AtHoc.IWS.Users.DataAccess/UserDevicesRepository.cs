﻿using System.Data;
using System.Linq;
using AtHoc.IWS.Interfaces.DataAccess.Users;
using AtHoc.IWS.Models.Devices;
using Dapper;

namespace AtHoc.IWS.Users.DataAccess
{
    public class UserDevicesRepository : RepositoryBase, IUserDevicesRepository
    {
        public UserDevicesRepository(IConfigSettings configSettings, IDbConnection cn) : base(configSettings, cn)
        {

        }

        public Device GetUserDeviceMetadataByDisplayName(string name, int orgId, string locale)
        {
            var cn = OpenConnection();

            var metadata = cn.Query<Device>(@"
/* GetUserDeviceMetadataByDisplayName */
SELECT
    d.DEVICE_ID as Id,
    l.ENTITY_VALUE as Name,
    d.COMMON_NAME as CommonName,
	ISNULL(dg.ADDRESS_VALIDATION_PAYLOAD.value('(/validations/length)[1]', 'int'), 2000) as AddressMaxLength,
	dg.ADDRESS_VALIDATION_PAYLOAD.value('(/validations/format)[1]', 'varchar(MAX)') as AddressFormat
FROM
	DLV_DEVICE_TAB d (nolock)
	INNER JOIN ENTITY_LOCALE_TAB l (nolock) ON (l.ENTITY_TYPE = 'DEVICE' AND l.ENTITY_ID = d.DEVICE_ID AND l.LOCALE_CODE = @LOCALE)
    INNER JOIN DLV_DEVICE_GROUP_TAB dg (nolock) ON (dg.GROUP_ID = d.GROUP_ID)
WHERE
	l.ENTITY_VALUE = @NAME
",
 new { LOCALE = locale, NAME = name }).FirstOrDefault();

            return metadata;
        }

        public Device GetUserDeviceMetadataByCommonName(string commonName, int orgId, string locale)
        {
            var cn = OpenConnection();

            var metadata = cn.Query<Device>(@"
/* GetUserDeviceMetadataByCommonName */
SELECT
    d.DEVICE_ID as Id,
    l.ENTITY_VALUE as Name,
    d.COMMON_NAME as CommonName,
	ISNULL(dg.ADDRESS_VALIDATION_PAYLOAD.value('(/validations/length)[1]', 'int'), 2000) as AddressMaxLength,
	dg.ADDRESS_VALIDATION_PAYLOAD.value('(/validations/format)[1]', 'varchar(MAX)') as AddressFormat
FROM
	DLV_DEVICE_TAB d (nolock)
	INNER JOIN ENTITY_LOCALE_TAB l (nolock) ON (l.ENTITY_TYPE = 'DEVICE' AND l.ENTITY_ID = d.DEVICE_ID AND l.LOCALE_CODE = @LOCALE)
    INNER JOIN DLV_DEVICE_GROUP_TAB dg (nolock) ON (dg.GROUP_ID = d.GROUP_ID)
WHERE
	d.COMMON_NAME = @COMMON_NAME
",
 new { LOCALE = locale, COMMON_NAME = commonName }).FirstOrDefault();

            return metadata;
        }
    }
}
