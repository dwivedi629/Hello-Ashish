﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Caching;
using AtHoc.IWS.Interfaces.DataAccess.Users;
using AtHoc.IWS.Models.UserSearch;
using Dapper;

namespace AtHoc.IWS.Users.DataAccess
{
    public class UserSearchRepository : RepositoryBase, IUserSearchRepository
    {
        #region Constructors

        public UserSearchRepository(IConfigSettings configSettings, IDbConnection cn) : base(configSettings, cn)
        {

        }

        #endregion

        #region Public Methods

        public ContextSearchResult SearchUsersV2ByContext(UserSearchArgs args)
        {
            var searchResult = new ContextSearchResult();

            if (args == null) return searchResult;

            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@providerId", args.ProviderId),
                new SqlParameter("@prvCriteria", args.ProviderCriteria.ToString()),
                new SqlParameter("@oprCriteria", args.OperatorCriteria != null ? QuickFixCriteriaDefinitions(args.OperatorCriteria.ToString()) :  String.Empty),
                new SqlParameter("@tgtCriteria", args.TargetCriteria != null ? QuickFixCriteriaDefinitions(args.TargetCriteria.ToString()) :  String.Empty),
                new SqlParameter("@tgtUsersCsv", args.TargetUsers != null ? args.TargetUsers.CsvParamString() : String.Empty),
                new SqlParameter("@blkCriteria", args.BlockCriteria != null ? QuickFixCriteriaDefinitions(args.BlockCriteria.ToString()) :  String.Empty),
                new SqlParameter("@blkUsersCsv", args.BlockUsers != null ? args.BlockUsers.CsvParamString() : String.Empty),
                new SqlParameter("@channelId", args.ChannelId),
                new SqlParameter("@enableSession", args.Options.EnableSession),
                new SqlParameter("@getUsers", args.Options.GetUsers),
                new SqlParameter("@getMassDevices", args.Options.GetMassDevices),
                new SqlParameter("@getCountsOnly", args.Options.GetCountsOnly),
                new SqlParameter("@attributeNames", args.AttributeNames != null ? args.AttributeNames.Distinct().CsvQuotedParamString() : String.Empty),
                new SqlParameter("@deviceNames", args.DeviceNames != null ? args.DeviceNames.Distinct().CsvQuotedParamString() : String.Empty),
                new SqlParameter("@usersPerPage", args.Paging.UsersPerPage),
                new SqlParameter("@pageNo", args.Paging.PageNo),
                new SqlParameter("@sortColumn", args.Paging.SortColumn),
                new SqlParameter("@isAsc", args.Paging.IsAsc),
                new SqlParameter("@debugLevel", args.Options.DebugLevel)
            };

            var cn = OpenConnection();
            var cmd = new SqlCommand("USR_SEARCH_WITHIN_PROVIDER", (SqlConnection)cn) { CommandType = CommandType.StoredProcedure };
            cmd.Parameters.AddRange(parameters.ToArray());
            var reader = cmd.ExecuteReader();

            if (!args.Options.GetCountsOnly) searchResult.UsersDataTable.Load(reader);

            if (reader.Read())
            {
                searchResult.UserBaseCount = Int32.Parse(reader["UserBaseCount"].ToString());
                searchResult.SearchResultCount = Int32.Parse(reader["SearchResultCount"].ToString());
                searchResult.MassDeviceCount = Int32.Parse(reader["MassDeviceCount"].ToString());
                searchResult.RegularUserCount = Int32.Parse(reader["RegularUserCount"].ToString());
                searchResult.EnabledUserCount = Int32.Parse(reader["EnabledUserCount"].ToString());
                searchResult.SessionId = Int32.Parse(reader["SessionId"].ToString());
                searchResult.EnabledUserBaseCount = Int32.Parse(reader["EnabledUserBaseCount"].ToString());
            }

            return searchResult;
        }

        public SessionSearchResult SearchUsersV2BySession(UserSearchSession args)
        {
            var searchResult = new SessionSearchResult();

            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@sessionId", args.SessionId),
                new SqlParameter("@tgtCriteria", args.TargetCriteria != null ? QuickFixCriteriaDefinitions(args.TargetCriteria.ToString()) : String.Empty),
                new SqlParameter("@getUsers", args.Options.GetUsers),
                new SqlParameter("@getMassDevices", args.Options.GetMassDevices),
                new SqlParameter("@getCountsOnly", args.Options.GetCountsOnly),
                new SqlParameter("@attributeNames", args.AttributeNames != null ? args.AttributeNames.Distinct().CsvQuotedParamString() : String.Empty),
                new SqlParameter("@deviceNames", args.DeviceNames != null ? args.DeviceNames.Distinct().CsvQuotedParamString() : String.Empty),
                new SqlParameter("@usersPerPage", args.Paging.UsersPerPage),
                new SqlParameter("@pageNo", args.Paging.PageNo),
                new SqlParameter("@sortColumn", args.Paging.SortColumn),
                new SqlParameter("@isAsc", args.Paging.IsAsc),
                new SqlParameter("@debugLevel", args.Options.DebugLevel)
            };

            var cn = OpenConnection();
            var cmd = new SqlCommand("USR_SEARCH_WITHIN_SESSION", (SqlConnection)cn) { CommandType = CommandType.StoredProcedure };
            cmd.Parameters.AddRange(parameters.ToArray());
            var reader = cmd.ExecuteReader();

            if (!args.Options.GetCountsOnly) searchResult.UsersDataTable.Load(reader);

            if (reader.Read())
            {
                searchResult.UserBaseCount = Int32.Parse(reader["UserBaseCount"].ToString());
                searchResult.SearchResultCount = Int32.Parse(reader["SearchResultCount"].ToString());
                searchResult.MassDeviceCount = Int32.Parse(reader["MassDeviceCount"].ToString());
                searchResult.RegularUserCount = Int32.Parse(reader["RegularUserCount"].ToString());
                searchResult.EnabledUserCount = Int32.Parse(reader["EnabledUserCount"].ToString());
            }

            return searchResult;
        }

        public AlertSearchResult SearchUsersV2ByAlert(UserSearchAlert args)
        {
            var searchResult = new AlertSearchResult();

            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@altCriteria", args.AlertCriteria != null ? QuickFixCriteriaDefinitions(args.AlertCriteria.ToString()) : String.Empty),
                new SqlParameter("@tgtCriteria", args.TargetCriteria != null ? QuickFixCriteriaDefinitions(args.TargetCriteria.ToString()) : String.Empty),
                new SqlParameter("@oprCriteria",args.OperatorCriteria != null ? QuickFixCriteriaDefinitions(args.OperatorCriteria.ToString()) : String.Empty),
                new SqlParameter("@getUsers", args.Options.GetUsers),
                new SqlParameter("@getMassDevices", args.Options.GetMassDevices),
                new SqlParameter("@getCountsOnly", args.Options.GetCountsOnly),
                new SqlParameter("@attributeNames", args.AttributeNames != null ? args.AttributeNames.Distinct().CsvQuotedParamString() : String.Empty),
                new SqlParameter("@deviceNames", args.DeviceNames != null ? args.DeviceNames.Distinct().CsvQuotedParamString() : String.Empty),
                new SqlParameter("@usersPerPage", args.Paging.UsersPerPage),
                new SqlParameter("@pageNo", args.Paging.PageNo),
                new SqlParameter("@sortColumn", args.Paging.SortColumn),
                new SqlParameter("@isAsc", args.Paging.IsAsc),
                new SqlParameter("@debugLevel", args.Options.DebugLevel)
            };

            var cn = OpenConnection();
            var cmd = new SqlCommand("USR_SEARCH_WITHIN_ALERT", (SqlConnection)cn) { CommandType = CommandType.StoredProcedure };
            cmd.Parameters.AddRange(parameters.ToArray());
            var reader = cmd.ExecuteReader();

            if (!args.Options.GetCountsOnly) searchResult.UsersDataTable.Load(reader);

            if (reader.Read())
            {
                searchResult.Targeted = Int32.Parse(reader["Targeted"].ToString());
                searchResult.Sent = Int32.Parse(reader["Sent"].ToString());
                searchResult.Responded = Int32.Parse(reader["Responded"].ToString());
                searchResult.Response = null;
                searchResult.NotResponded = Int32.Parse(reader["NotResponded"].ToString());
            }

            return searchResult;
        }

        #endregion

        #region Private Methods

        private string QuickFixCriteriaDefinitions(string criteriaString)
        {
            criteriaString = ReplaceDesktopDeviceCriteria(criteriaString);
            criteriaString = ReplaceMobileDeviceCriteria(criteriaString);

            return criteriaString;
        }

        //TODO: THIS IS A QUICK FIX FOR IWS-13004 Desktop App query returns 0 at all times. Sujay will fix this issue in M2
        //For M1, we will have this temporary fix solve this issue
        //Desktop App is Active -> DEVICE-15!1!Active <## IS SAME AS ##> Desktop Last Sign On Time is within last 30 days -> ATTRIBUTE-10966!8!D:-30
        //Desktop App is Inactive -> DEVICE-15!1!InActive <## IS SAME AS ##> Desktop Last Sign On Time is before last 30 days -> ATTRIBUTE-10966!7!D:-30
        //Desktop App is Active,Inactive -> DEVICE-15!1!Active,InActive <## IS SAME AS ##> Desktop Last Sign On Time has some value -> ATTRIBUTE-10966!8!1/1/2000
        private string ReplaceDesktopDeviceCriteria(string criteriaString)
        {
            ObjectCache cache = MemoryCache.Default;

            var dt = cache["ReplaceDesktopDeviceStatusDefinition_DataTable"];

            if (dt == null)
            {
                #region DefinitionsSql

                const string definitionSql = @"
/* From UserSearchDbRepository > ReplaceDesktopDeviceStatusDefinition Method */
DECLARE @DEVICE_ID INT = (SELECT top 1 DEVICE_ID FROM DLV_DEVICE_TAB d (NOLOCK) WHERE d.GROUP_ID in (select GROUP_ID from  DLV_DEVICE_GROUP_TAB  where COMMON_NAME ='DESKTOP-POPUP') AND STATUS != 'DEL')
DECLARE @ATTRIBUTE_ID INT = (SELECT dbo.Get_System_Attribute_ValueID('DSW-SIGNON-TIME', ''))

SELECT
	DEVICEDEF, ATTRIBUTEDEF
FROM
(
	SELECT 1 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!1!Active,Inactive' AS DEVICEDEF, 
		'ATTRIBUTE-' + CAST(@ATTRIBUTE_ID AS VARCHAR(MAX)) + '!8!1/1/2000' AS ATTRIBUTEDEF
	UNION
	SELECT 2, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!1!Inactive,Active', 
		'ATTRIBUTE-' + CAST(@ATTRIBUTE_ID AS VARCHAR(MAX)) + '!8!1/1/2000'
	UNION
	SELECT 3, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!1!Active', 'ATTRIBUTE-' + 
		CAST(@ATTRIBUTE_ID AS VARCHAR(MAX)) + '!8!D:-30'
	UNION
	SELECT 4, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!1!Inactive', 'ATTRIBUTE-' + 
		CAST(@ATTRIBUTE_ID AS VARCHAR(MAX)) + '!7!D:-30' 
) AS X
ORDER BY
	ID
";

                #endregion

                var cn = OpenConnection();

                var reader = cn.ExecuteReader(definitionSql);

                dt = new DataTable();

                ((DataTable)dt).Load(reader);

                cache["ReplaceDesktopDeviceStatusDefinition_DataTable"] = dt;
            }

            foreach (DataRow row in ((DataTable)dt).Rows)
            {
                criteriaString = criteriaString.Replace(row["DEVICEDEF"].ToString(), row["ATTRIBUTEDEF"].ToString());
            }

            return criteriaString;
        }

        //TODO: THIS IS A QUICK FIX FOR IWS-14580 Mobile App column does not work in Advanced User Search
        private string ReplaceMobileDeviceCriteria(string criteriaString)
        {
            ObjectCache cache = MemoryCache.Default;

            var dt = cache["ReplaceMobileDeviceStatusDefinition_DataTable"];

            if (dt == null)
            {
                #region DefinitionsSql

                const string definitionSql = @"
/* From UserSearchDbRepository > ReplaceMobileDeviceStatusDefinition Method */
/* 5 EQUALS, 4 NOT EQUALS, 11 EMPTY, 12 NOT EMPTY */
DECLARE @DEVICE_ID INT = (SELECT DEVICE_ID FROM DLV_DEVICE_TAB d (NOLOCK) WHERE d.COMMON_NAME = 'mobileNotification' AND STATUS != 'DEL')

SELECT
	DEVICEDEF, FIXDEVICEDEF
FROM
(
	SELECT 1 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!5!Active,Inactive' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!11! || DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!12!' AS FIXDEVICEDEF
	UNION
	SELECT 2 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!5!Active' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!12!' AS FIXDEVICEDEF
	UNION
	SELECT 3 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!5!Inactive' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!11!' AS FIXDEVICEDEF
	UNION
	SELECT 4 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!4!Active,Inactive' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!11! || DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!12!' AS FIXDEVICEDEF
	UNION
	SELECT 5 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!4!Active' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!11!' AS FIXDEVICEDEF
	UNION
	SELECT 6 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!4!Inactive' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!12!' AS FIXDEVICEDEF
	UNION
	SELECT 7 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!11!Active,Inactive' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!11!' AS FIXDEVICEDEF
	UNION
	SELECT 8 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!11!Active' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!11!' AS FIXDEVICEDEF
	UNION
	SELECT 9 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!11!Inactive' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!11!' AS FIXDEVICEDEF
	UNION
	SELECT 10 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!12!Active,Inactive' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!12!' AS FIXDEVICEDEF
	UNION
	SELECT 11 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!12!Active' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!12!' AS FIXDEVICEDEF
	UNION
	SELECT 12 AS ID, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!12!Inactive' AS DEVICEDEF, 'DEVICE-' + CAST(@DEVICE_ID AS VARCHAR(MAX)) + '!12!' AS FIXDEVICEDEF
) AS X
ORDER BY
	ID
";
                #endregion

                var cn = OpenConnection();

                var reader = cn.ExecuteReader(definitionSql);

                dt = new DataTable();

                ((DataTable)dt).Load(reader);

                cache["ReplaceMobileDeviceStatusDefinition_DataTable"] = dt;
            }

            foreach (DataRow row in ((DataTable)dt).Rows)
            {
                criteriaString = criteriaString.Replace(row["DEVICEDEF"].ToString(), row["FIXDEVICEDEF"].ToString());
            }

            return criteriaString;
        }

        #endregion
    }
}