﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using AtHoc.IWS.Interfaces.DataAccess.Users;
using AtHoc.IWS.Models.Attributes;
using Dapper;

namespace AtHoc.IWS.Users.DataAccess
{
    public class UserAttributesRepository : RepositoryBase, IUserAttributesRepository
    {
        public UserAttributesRepository(IConfigSettings configSettings, IDbConnection cn) : base(configSettings, cn)
        {

        }

        public Attribute GetUserAttributeMetadataByDisplayName(string name, int orgId, string locale)
        {
            var cn = OpenConnection();

            var metadata = cn.Query<Attribute>(@"
/* GetUserAttributeMetadataByDisplayName */
SELECT
    a.ATTRIBUTE_ID as AttributeId,
	a.ENTITY_ID as Entity,
    a.ATTRIBUTE_TYPE_ID as AttributeType,
	al.ATTRIBUTE_NAME as Name,
    a.COMMON_NAME as CommonName,
    a.HIERARCHY_ID as HierarchyId,
	CASE WHEN a.EDIT_LEVEL = 0 THEN 'true' ELSE 'false' END AS IsReadOnly,
    CASE WHEN a.IS_MANDATORY = 'Y' THEN 'true' ELSE 'false' END AS IsMandatory,
    CASE WHEN a.IS_SYSTEM_ATTRIBUTE = 'Y' THEN 'true' ELSE 'false' END AS IsSystem,
    CASE WHEN a.IS_STANDARD = 'Y' THEN 'true' ELSE 'false' END AS IsStandard,
	a.MIN_VALUE as MinValue,
	a.MAX_VALUE as MaxValue,
	a.DEFAULT_VALUE as DefaultValue,
	CASE WHEN a.SUPPORTS_HISTORICAL_VALUES = 'Y' THEN 'true' ELSE 'false' END AS SaveHistory
FROM
	PRV_GET_ATTRIBUTES(@ORG_ID) a
	INNER JOIN PRV_ATTRIBUTE_LOCALE_TAB al (nolock) ON (al.ATTRIBUTE_ID = a.ATTRIBUTE_ID AND al.LOCALE_CODE = @LOCALE AND ISNULL([STATUS],'') != 'DEL')
WHERE
	al.ATTRIBUTE_NAME = @DISPLAYNAME
",
 new { ORG_ID = orgId, LOCALE = locale, DISPLAYNAME = name }).FirstOrDefault();

            if (metadata != null && (metadata.AttributeType == AttributeType.Picklist || metadata.AttributeType == AttributeType.MultiPicklist || metadata.AttributeType == AttributeType.Checkbox))
            {
                metadata.ValuesMetadata = GetUserAttributeValueMetadataByAttributeId(metadata.AttributeId, locale);
            }
            else if (metadata != null && (metadata.AttributeType == AttributeType.Path))
            {
                metadata.ValuesMetadata = GetValidHierarchyValues(metadata.AttributeId, locale);
            }

            return metadata;
        }

        public Attribute GetUserAttributeMetadataByCommonName(string commonName, int orgId, string locale)
        {
            var cn = OpenConnection();

            var metadata = cn.Query<Attribute>(@"
/* GetUserAttributeMetadataByCommonName */
SELECT
    a.ATTRIBUTE_ID as AttributeId,
	a.ENTITY_ID as Entity,
    a.ATTRIBUTE_TYPE_ID as AttributeType,
	al.ATTRIBUTE_NAME as Name,
    a.COMMON_NAME as CommonName,
	CASE WHEN a.EDIT_LEVEL = 0 THEN 'true' ELSE 'false' END AS IsReadOnly,
    CASE WHEN a.IS_MANDATORY = 'Y' THEN 'true' ELSE 'false' END AS IsMandatory,
    CASE WHEN a.IS_SYSTEM_ATTRIBUTE = 'Y' THEN 'true' ELSE 'false' END AS IsSystem,
    CASE WHEN a.IS_STANDARD = 'Y' THEN 'true' ELSE 'false' END AS IsStandard,
	a.MIN_VALUE as MinValue,
	a.MAX_VALUE as MaxValue,
	a.DEFAULT_VALUE as DefaultValue,
	CASE WHEN a.SUPPORTS_HISTORICAL_VALUES = 'Y' THEN 'true' ELSE 'false' END AS SaveHistory
FROM
	PRV_GET_ATTRIBUTES(@ORG_ID) a
	INNER JOIN PRV_ATTRIBUTE_LOCALE_TAB al (nolock) ON (al.ATTRIBUTE_ID = a.ATTRIBUTE_ID AND al.LOCALE_CODE = @LOCALE AND ISNULL([STATUS],'') != 'DEL')
WHERE
	a.COMMON_NAME = @COMMON_NAME AND a.ENTITY_ID='USER'
",
 new { ORG_ID = orgId, LOCALE = locale, COMMON_NAME = commonName }).FirstOrDefault();

            if (metadata != null && (metadata.AttributeType == AttributeType.Picklist || metadata.AttributeType == AttributeType.MultiPicklist || metadata.AttributeType == AttributeType.Checkbox))
            {
                metadata.ValuesMetadata = GetUserAttributeValueMetadataByAttributeId(metadata.AttributeId, locale);
            }
            else if (metadata != null && (metadata.AttributeType == AttributeType.Path))
            {
                metadata.ValuesMetadata = GetValidHierarchyValues(metadata.AttributeId, locale);
            }

            return metadata;
        }

        public IEnumerable<AttributeValue> GetUserAttributeValueMetadataByAttributeId(int attributeId, string locale)
        {
            var cn = OpenConnection();

            var metadata = cn.Query<AttributeValue>(@"
/* GetUserAttributeValueMetadataByAttributeId */
SELECT
	av.ATTRIBUTE_ID as AttributeId,
	av.VALUE_ID as ValueId,
	avl.VALUE_NAME as Name,
	av.COMMON_NAME as CommonName,
	SORT_ORDER as SortOrder
FROM
	PRV_ATTRIBUTE_VALUE_TAB av (nolock)
	INNER JOIN PRV_ATTRIBUTE_VALUE_LOCALE_TAB avl (nolock) ON (avl.ATTRIBUTE_ID = av.ATTRIBUTE_ID AND avl.VALUE_ID = av.VALUE_ID AND avl.LOCALE_CODE = @LOCALE AND ISNULL([STATUS],'') != 'DEL')
WHERE
	av.ATTRIBUTE_ID = @ATTRIBUTE_ID
",
 new { ATTRIBUTE_ID = attributeId, LOCALE = locale }).AsEnumerable();

            return metadata;
        }

        public IEnumerable<AttributeValue> GetValidHierarchyValues(int attributeId, string locale)
        {
            var cn = OpenConnection();

            var metadata = cn.Query<AttributeValue>(@"
/* GetValidHierarchyValues */
SELECT
	@ATTRIBUTE_ID AS AttributeId,
	NULL as ValueId,
	'/' as Name,
	'/' as CommonName,
	NULL as SortOrder
UNION ALL
SELECT
	a.ATTRIBUTE_ID as AttributeId,
	NULL as ValueId,
	h.LINEAGE + h.Name + '/' as Name,
	h.LINEAGE + h.Name + '/' as CommonName,
	NULL as SortOrder
FROM
	PRV_ATTRIBUTE_TAB a (nolock)
	INNER JOIN PDL_LIST_TAB h (nolock) ON (h.HIERARCHY_ID = a.HIERARCHY_ID)
WHERE
	a.ATTRIBUTE_ID = @ATTRIBUTE_ID
",
 new { ATTRIBUTE_ID = attributeId, LOCALE = locale }).AsEnumerable();

            return metadata;
        }
    }
}
