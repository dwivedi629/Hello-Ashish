﻿using System.Data;
using AtHoc.IWS.Extensions;
using AtHoc.IWS.Interfaces.DataAccess.Global;
using AtHoc.IWS.Models.Global;
using Dapper;

namespace AtHoc.IWS.Global.DataAccess
{
    public class GlobalRepository : RepositoryBase, IGlobalRepository
    {
        public GlobalRepository(IConfigSettings configSettings, IDbConnection cn) : base(configSettings, cn)
        {

        }

        public int GetSequence(SequenceType type, int range)
        {
            var cn = OpenConnection();

            var parameters = new DynamicParameters();
            parameters.Add("seqType", type.GetDescription());
            parameters.Add("seqRange", range);
            parameters.Add("startSeq", dbType: DbType.Int32, direction: ParameterDirection.Output);
            cn.Query<int>("dbo.GET_NEW_SEQUENCE", parameters, commandType: CommandType.StoredProcedure);

            return parameters.Get<int>("startSeq");
        }

        public void BulkCopyToDatabase(string table, DataTable dt)
        {
            CopyData(table, dt);
        }
    }
}
